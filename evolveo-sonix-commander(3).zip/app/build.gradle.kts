plugins {
    id("com.android.application")
}

android {
    namespace = "sk.strechostav.sonixcommander"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.sonixcommander"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
