package sk.strechostav.sonixcommander;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.Normalizer;

public final class ZoneStore {
    public static final String PREFS = "sonix_prefs";
    public static final String KEY_LAST_ALERT = "last_alert";
    public static final String KEY_LAST_ALERT_ORIGINAL = "last_alert_original";
    public static final String KEY_LAST_ALERT_TIME = "last_alert_time";

    private ZoneStore() { }

    public static String getZoneName(Context context, int zone) {
        return prefs(context).getString(zoneKey(zone), defaultName(zone));
    }

    public static void setZoneName(Context context, int zone, String name) {
        String cleaned = name == null ? "" : name.trim();
        if (cleaned.isEmpty()) cleaned = defaultName(zone);
        prefs(context).edit().putString(zoneKey(zone), cleaned).apply();
    }

    public static String getAlarmPhone(Context context) {
        return prefs(context).getString("alarmPhone", "+421940166128");
    }

    public static String getPassword(Context context) {
        return prefs(context).getString("password", "123456");
    }

    public static void saveLastAlert(Context context, int zone, String translated, String original) {
        prefs(context).edit()
                .putString(KEY_LAST_ALERT, String.format("Zóna %02d: %s", zone, translated))
                .putString(KEY_LAST_ALERT_ORIGINAL, original == null ? "" : original)
                .putLong(KEY_LAST_ALERT_TIME, System.currentTimeMillis())
                .apply();
    }

    public static String sanitizeForAlarm(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .replaceAll("[^\\x20-\\x7E]", "")
                .replace('#', ' ')
                .replaceAll("\\s+", " ")
                .trim();
        if (normalized.length() > 24) normalized = normalized.substring(0, 24).trim();
        return normalized;
    }

    public static String defaultName(int zone) {
        switch (zone) {
            case 4: return "Pohyb v karavane aktívny";
            case 5: return "Dvere karavanu otvorené";
            case 6: return "Šoférove dvere otvorené";
            default: return "Bezdrôtová zóna " + zone;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static String zoneKey(int zone) {
        return "zone_name_" + zone;
    }
}
