package sk.strechostav.sonixcommander;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.res.ColorStateList;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_SEND_SMS = 301;
    private static final int REQ_POST_NOTIFICATIONS = 302;
    private static final String PREFS = ZoneStore.PREFS;

    private EditText alarmPhoneInput;
    private EditText passwordInput;
    private Spinner commandSpinner;
    private LinearLayout dynamicFields;
    private TextView commandPreview;
    private TextView helpText;
    private TextView converterStatus;
    private TextView lastAlertText;

    private final List<CommandSpec> commands = new ArrayList<>();
    private final List<EditText> activeInputs = new ArrayList<>();
    private String pendingDirectSms;
    private String pendingSmsLabel = "SMS príkaz";
    private boolean pendingOpenListenerSettings;

    static class FieldSpec {
        final String key, label, hint;
        final int inputType;
        final boolean ascii24;

        FieldSpec(String key, String label, String hint, int inputType, boolean ascii24) {
            this.key = key;
            this.label = label;
            this.hint = hint;
            this.inputType = inputType;
            this.ascii24 = ascii24;
        }
    }

    static class CommandSpec {
        final String title, description, template;
        final FieldSpec[] fields;

        CommandSpec(String title, String description, String template, FieldSpec... fields) {
            this.title = title;
            this.description = description;
            this.template = template;
            this.fields = fields;
        }

        @Override public String toString() { return title; }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannel(this);
        seedCommands();
        buildUi();
        loadPrefs();
        renderDynamicFields();
        updatePreview();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (converterStatus != null) refreshConverterStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(28));
        scroll.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.motorhome_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(96), dp(96));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        logo.setLayoutParams(logoParams);
        root.addView(logo);

        TextView title = new TextView(this);
        title.setText("Sonix Motorhome Commander");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(22, 28, 32));
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(4), 0, dp(4));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Rýchle zapnutie a vypnutie alarmu. Ostatné funkcie sú v rozbaľovacom zozname.");
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, 0, 0, dp(14));
        root.addView(subtitle);

        alarmPhoneInput = input("Telefónne číslo SIM v alarme", "+421940166128", android.text.InputType.TYPE_CLASS_PHONE);
        root.addView(alarmPhoneInput);
        passwordInput = input("Heslo alarmu", "123456", android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(passwordInput);

        TextView quickLabel = sectionTitle("Hlavné ovládanie");
        root.addView(quickLabel);

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setWeightSum(2f);

        Button armButton = coloredButton("ZAPNÚŤ ALARM", Color.rgb(46, 125, 50));
        LinearLayout.LayoutParams armParams = new LinearLayout.LayoutParams(0, dp(58), 1f);
        armParams.setMargins(0, 0, dp(5), 0);
        armButton.setLayoutParams(armParams);
        armButton.setOnClickListener(v -> sendQuickCommand("1#1#", "Zapnutie alarmu"));
        quickRow.addView(armButton);

        Button disarmButton = coloredButton("VYPNÚŤ ALARM", Color.rgb(198, 40, 40));
        LinearLayout.LayoutParams disarmParams = new LinearLayout.LayoutParams(0, dp(58), 1f);
        disarmParams.setMargins(dp(5), 0, 0, 0);
        disarmButton.setLayoutParams(disarmParams);
        disarmButton.setOnClickListener(v -> sendQuickCommand("1#0#", "Vypnutie alarmu"));
        quickRow.addView(disarmButton);
        root.addView(quickRow);

        root.addView(sectionTitle("Názvy zón a prevodník 6–16"));

        converterStatus = new TextView(this);
        converterStatus.setTextSize(14);
        converterStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        converterStatus.setBackgroundColor(Color.rgb(238, 238, 238));
        root.addView(converterStatus);

        Button zoneSettings = button("NASTAVIŤ NÁZVY ZÓN 1–16");
        zoneSettings.setOnClickListener(v -> startActivity(new Intent(this, ZoneSettingsActivity.class)));
        root.addView(zoneSettings);

        Button enableConverter = button("POVOLIŤ PREVODNÍK UPOZORNENÍ");
        enableConverter.setOnClickListener(v -> requestConverterAccess());
        root.addView(enableConverter);

        lastAlertText = new TextView(this);
        lastAlertText.setTextSize(13);
        lastAlertText.setPadding(0, dp(10), 0, dp(4));
        root.addView(lastAlertText);

        TextView privacyNote = new TextView(this);
        privacyNote.setText("Prevodník číta iba obsah systémových upozornení, hľadá správu typu Wireless Activated(06–16) a lokálne zobrazí tvoj názov zóny. Údaje neopúšťajú telefón.");
        privacyNote.setTextSize(12);
        privacyNote.setPadding(0, 0, 0, dp(8));
        root.addView(privacyNote);

        root.addView(sectionTitle("Ostatné príkazy"));
        TextView choose = label("Vyber požadovanú operáciu");
        root.addView(choose);

        commandSpinner = new Spinner(this);
        ArrayAdapter<CommandSpec> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, commands);
        commandSpinner.setAdapter(adapter);
        root.addView(commandSpinner);

        helpText = new TextView(this);
        helpText.setTextSize(13);
        helpText.setPadding(0, dp(8), 0, dp(8));
        root.addView(helpText);

        dynamicFields = new LinearLayout(this);
        dynamicFields.setOrientation(LinearLayout.VERTICAL);
        root.addView(dynamicFields);

        TextView previewLabel = label("Pripravená SMS");
        previewLabel.setPadding(0, dp(12), 0, 0);
        root.addView(previewLabel);

        commandPreview = new TextView(this);
        commandPreview.setTextSize(18);
        commandPreview.setTextColor(Color.rgb(20, 20, 20));
        commandPreview.setPadding(dp(12), dp(10), dp(12), dp(10));
        commandPreview.setBackgroundColor(Color.rgb(238, 238, 238));
        commandPreview.setTextIsSelectable(true);
        root.addView(commandPreview);

        Button directSms = coloredButton("ODOSLAŤ PRÍKAZ", Color.rgb(51, 105, 30));
        directSms.setOnClickListener(v -> sendDirectSms());
        root.addView(directSms);

        Button openSms = button("Otvoriť SMS aplikáciu s príkazom");
        openSms.setOnClickListener(v -> openSmsApp());
        root.addView(openSms);

        Button copy = button("Kopírovať príkaz");
        copy.setOnClickListener(v -> copyCommand());
        root.addView(copy);

        TextView note = new TextView(this);
        note.setText("Názvy odosielané priamo do alarmu sa automaticky prevedú bez diakritiky a skrátia na maximálne 24 znakov. Zóny 6–16 majú vo firmvéri jeden spoločný text, preto ich individuálne názvy rieši prevodník v aplikácii.");
        note.setTextSize(12);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scroll);

        TextWatcher watcher = new SimpleWatcher() {
            @Override public void afterTextChanged(Editable s) {
                savePrefs();
                updatePreview();
            }
        };
        alarmPhoneInput.addTextChangedListener(watcher);
        passwordInput.addTextChangedListener(watcher);

        commandSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                renderDynamicFields();
                updatePreview();
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        refreshConverterStatus();
    }

    private void seedCommands() {
        FieldSpec phone = new FieldSpec("phone", "Telefónne číslo", "0905514643 alebo +421905514643", android.text.InputType.TYPE_CLASS_PHONE, false);
        FieldSpec text = new FieldSpec("text", "Text SMS názvu zóny", "Dvere karavanu otvorene", android.text.InputType.TYPE_CLASS_TEXT, true);
        FieldSpec zone = new FieldSpec("zone", "Číslo zóny", "1–16 bezdrôtové, 21–23 drôtové", android.text.InputType.TYPE_CLASS_NUMBER, false);
        FieldSpec delay = new FieldSpec("value", "Hodnota 00–99", "napríklad 10", android.text.InputType.TYPE_CLASS_NUMBER, false);
        FieldSpec pass = new FieldSpec("newpass", "Nové heslo", "1 až 6 číslic", android.text.InputType.TYPE_CLASS_NUMBER, false);

        add("Čiastočná aktivácia – Home arm", "Stráži iba časť senzorov. Vhodné keď si vnútri a vnútorný PIR nemá reagovať.", "1#2#");

        add("Zapnúť varovný tón pri vonkajšej aktivácii", "Pípnutie pri aktivácii vonkajšieho alarmu.", "21#1#");
        add("Vypnúť varovný tón pri vonkajšej aktivácii", "Vypnutie pípnutia pri aktivácii vonkajšieho alarmu.", "21#0#");
        add("Zapnúť varovný tón pri vnútornej aktivácii", "Pípnutie pri vnútornej alebo čiastočnej aktivácii.", "22#1#");
        add("Vypnúť varovný tón pri vnútornej aktivácii", "Vypnutie pípnutia pri vnútornej alebo čiastočnej aktivácii.", "22#0#");
        add("Zapnúť tón pri deaktivácii", "Pípnutie pri vypnutí alarmu.", "23#1#");
        add("Vypnúť tón pri deaktivácii", "Vypnutie pípnutia pri vypnutí alarmu.", "23#0#");

        add("Nastaviť oneskorenie alarmu – príkaz 27", "Hodnota 00–99 podľa manuálu. Nepoužívať pre trvalé čidlá typu dym alebo SOS.", "27#%value%#", delay);
        add("Nastaviť oneskorenie – príkaz 28", "Hodnota 00–99 podľa manuálu. Nepoužívať pre trvalé čidlá typu dym alebo SOS.", "28#%value%#", delay);

        add("Okamžite spustiť sirénu alebo zvuk", "Test alebo ručné spustenie zvuku.", "3#1#");
        add("Vypnúť sirénu alebo zvuk", "Zastaví okamžitý zvukový signál.", "3#0#");
        add("Aktivovať načúvanie", "Zapne odpočúvanie cez mikrofón alarmu.", "4#1#");
        add("Vypnúť načúvanie", "Vypne odpočúvanie.", "4#0#");

        add("Siréna pri poplachu ON", "Pri poplachu bude siréna húkať.", "11#1#");
        add("Siréna pri poplachu OFF", "Pri poplachu nebude siréna húkať.", "11#0#");
        add("SMS pri poplachu ON", "Alarm bude posielať SMS pri poplachu.", "12#1#");
        add("SMS pri poplachu OFF", "Alarm nebude posielať SMS pri poplachu.", "12#0#");
        add("Telefonovanie pri poplachu ON", "Alarm bude volať na uložené čísla.", "15#1#");
        add("Telefonovanie pri poplachu OFF", "Alarm nebude volať, iba spustí poplach.", "15#0#");
        add("Automatické relé po poplachu OFF", "Deaktivuje automatické zopnutie relé do troch minút po poplachu.", "16#1#");
        add("Automatické relé po poplachu ON", "Aktivuje automatické zopnutie relé do troch minút po poplachu.", "16#0#");

        add("Zobraziť stav zón", "Alarm odpovie stavom aktivácie alebo deaktivácie každej zóny. Iba SMS.", "30##");
        add("Zmeniť heslo", "Nové heslo má mať 1–6 číslic. Po zmene ho prepíš aj v hornom poli aplikácie.", "31#%newpass%#", pass);
        add("Aktivovať konkrétnu zónu", "Bezdrôtové zóny 1–16, drôtové zóny 21–23.", "38#%zone%#", zone);
        add("Deaktivovať konkrétnu zónu", "Bezdrôtové zóny 1–16, drôtové zóny 21–23.", "39#%zone%#", zone);

        add("Zobraziť uložené telefónne čísla", "Vypíše Tel1 až Tel5. Iba SMS.", "50##");
        add("Nastaviť Tel1", "Prvé číslo pre SMS a hovory.", "51#%phone%#", phone);
        add("Nastaviť Tel2", "Druhé číslo pre SMS a hovory.", "52#%phone%#", phone);
        add("Nastaviť Tel3", "Tretie číslo pre SMS a hovory.", "53#%phone%#", phone);
        add("Nastaviť Tel4", "Štvrté číslo pre SMS a hovory.", "54#%phone%#", phone);
        add("Nastaviť Tel5", "Piate číslo pre SMS a hovory.", "55#%phone%#", phone);

        add("Zobraziť názvy SMS zón", "Vypíše aktuálne texty správ 1 až 7. Iba SMS.", "80##");
        add("Pomenovať zónu 1 priamo v alarme", "Text pre prvý bezdrôtový senzor.", "81#%text%#", text);
        add("Pomenovať zónu 2 priamo v alarme", "Text pre druhý bezdrôtový senzor.", "82#%text%#", text);
        add("Pomenovať zónu 3 priamo v alarme", "Text pre tretí bezdrôtový senzor.", "83#%text%#", text);
        add("Pomenovať zónu 4 priamo v alarme", "Text pre štvrtý bezdrôtový senzor.", "84#%text%#", text);
        add("Pomenovať zónu 5 priamo v alarme", "Text pre piaty bezdrôtový senzor.", "85#%text%#", text);
        add("Spoločný text zón 6–16 v alarme", "Firmware má pre zóny 6–16 iba jeden text. Pre individuálne názvy používaj obrazovku Nastaviť názvy zón a prevodník.", "86#%text%#", text);
        add("Pomenovať drôtové vstupy 1–3", "Spoločný text pre drôtové porty I1, I2 a I3.", "87#%text%#", text);

        add("Zobraziť stav výstupov", "Vypíše stav výstupov O1, O2, O3 a relé. Iba SMS.", "90##");
        add("Výstup 1 na vysoko", "Nastaví O1 na vysokú úroveň.", "91#1#");
        add("Výstup 1 na nízko", "Nastaví O1 na nízku úroveň.", "91#0#");
        add("Výstup 2 na vysoko", "Nastaví O2 na vysokú úroveň.", "92#1#");
        add("Výstup 2 na nízko", "Nastaví O2 na nízku úroveň.", "92#0#");
        add("Povoliť hovor cez reproduktor O3", "Umožní hovoriť cez alarm a reproduktor.", "93#1#");
        add("Zakázať hovor cez reproduktor O3", "Vypne hovor cez alarm a reproduktor.", "93#0#");
        add("Relé prepojené", "Manuálne zopne relé.", "94#1#");
        add("Relé odpojené", "Manuálne rozopne relé.", "94#0#");
        add("Vstup 1: poplach pri otvorení", "Nastaví I1 tak, že poplach nastane pri otvorení vstupu.", "95#1#");
        add("Vstup 1: poplach pri uzemnení GND", "Nastaví I1 tak, že poplach nastane pri uzemnení.", "95#0#");
        add("Vstup 2: poplach pri otvorení", "Nastaví I2 tak, že poplach nastane pri otvorení vstupu.", "96#1#");
        add("Vstup 2: poplach pri uzemnení GND", "Nastaví I2 tak, že poplach nastane pri uzemnení.", "96#0#");
        add("Vstup 3: poplach pri otvorení", "Nastaví I3 tak, že poplach nastane pri otvorení vstupu.", "97#1#");
        add("Vstup 3: poplach pri uzemnení GND", "Nastaví I3 tak, že poplach nastane pri uzemnení.", "97#0#");
    }

    private void add(String title, String desc, String template, FieldSpec... fields) {
        commands.add(new CommandSpec(title, desc, template, fields));
    }

    private void renderDynamicFields() {
        if (dynamicFields == null || commandSpinner == null || commandSpinner.getSelectedItem() == null) return;
        dynamicFields.removeAllViews();
        activeInputs.clear();
        CommandSpec spec = selectedCommand();
        helpText.setText(spec.description);

        for (FieldSpec field : spec.fields) {
            EditText editText = input(field.label, field.hint, field.inputType);
            editText.setTag(field);
            editText.addTextChangedListener(new SimpleWatcher() {
                @Override public void afterTextChanged(Editable s) { updatePreview(); }
            });
            activeInputs.add(editText);
            dynamicFields.addView(editText);
        }
    }

    private CommandSpec selectedCommand() {
        return (CommandSpec) commandSpinner.getSelectedItem();
    }

    private String buildCommand() {
        CommandSpec spec = selectedCommand();
        String command = spec.template;
        for (EditText input : activeInputs) {
            FieldSpec field = (FieldSpec) input.getTag();
            String value = input.getText().toString().trim();
            if (field.ascii24) value = ZoneStore.sanitizeForAlarm(value);
            if ("value".equals(field.key) && value.length() == 1) value = "0" + value;
            command = command.replace("%" + field.key + "%", value);
        }
        return passwordInput.getText().toString().trim() + "#" + command;
    }

    private String validateCore() {
        String alarmPhone = alarmPhoneInput.getText().toString().trim();
        if (alarmPhone.isEmpty()) return "Doplň telefónne číslo SIM v alarme.";
        String password = passwordInput.getText().toString().trim();
        if (password.isEmpty()) return "Doplň heslo alarmu.";
        if (password.length() > 6) return "Heslo podľa manuálu má mať najviac 6 znakov.";
        return null;
    }

    private String validateForm() {
        String core = validateCore();
        if (core != null) return core;

        for (EditText input : activeInputs) {
            FieldSpec field = (FieldSpec) input.getTag();
            String value = input.getText().toString().trim();
            if (value.isEmpty()) return "Doplň pole: " + field.label;

            if ("value".equals(field.key)) {
                try {
                    int parsed = Integer.parseInt(value);
                    if (parsed < 0 || parsed > 99) return "Hodnota musí byť od 00 do 99.";
                } catch (Exception ex) {
                    return "Hodnota musí byť číslo 00–99.";
                }
            }

            if ("zone".equals(field.key)) {
                try {
                    int parsed = Integer.parseInt(value);
                    boolean valid = (parsed >= 1 && parsed <= 16) || (parsed >= 21 && parsed <= 23);
                    if (!valid) return "Zóna musí byť 1–16 alebo 21–23.";
                } catch (Exception ex) {
                    return "Zóna musí byť číslo.";
                }
            }

            if ("newpass".equals(field.key) && value.length() > 6) {
                return "Nové heslo má mať najviac 6 číslic.";
            }

            if (field.ascii24 && ZoneStore.sanitizeForAlarm(value).isEmpty()) {
                return "Text po prevode nesmie zostať prázdny.";
            }
        }
        return null;
    }

    private void updatePreview() {
        try {
            if (commandPreview != null && commandSpinner != null && commandSpinner.getSelectedItem() != null) {
                commandPreview.setText(buildCommand());
            }
        } catch (Exception ignored) {
            if (commandPreview != null) commandPreview.setText("—");
        }
    }

    private void sendQuickCommand(String commandCode, String label) {
        String error = validateCore();
        if (error != null) {
            toast(error);
            return;
        }
        savePrefs();
        pendingSmsLabel = label;
        pendingDirectSms = passwordInput.getText().toString().trim() + "#" + commandCode;
        requestOrSendDirect();
    }

    private void sendDirectSms() {
        String error = validateForm();
        if (error != null) {
            toast(error);
            return;
        }
        savePrefs();
        pendingSmsLabel = selectedCommand().title;
        pendingDirectSms = buildCommand();
        requestOrSendDirect();
    }

    private void requestOrSendDirect() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
            return;
        }
        doSendDirect();
    }

    private void doSendDirect() {
        try {
            String phone = alarmPhoneInput.getText().toString().trim();
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(pendingDirectSms);
            smsManager.sendMultipartTextMessage(phone, null, parts, null, null);
            toast(pendingSmsLabel + " – SMS odoslaná.");
        } catch (Exception e) {
            toast("Priame odoslanie zlyhalo. Otváram SMS aplikáciu.");
            openSmsWithBody(pendingDirectSms);
        }
    }

    private void openSmsApp() {
        String error = validateForm();
        if (error != null) {
            toast(error);
            return;
        }
        savePrefs();
        openSmsWithBody(buildCommand());
    }

    private void openSmsWithBody(String body) {
        try {
            String phone = alarmPhoneInput.getText().toString().trim();
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + Uri.encode(phone)));
            intent.putExtra("sms_body", body);
            startActivity(intent);
        } catch (Exception e) {
            toast("Nepodarilo sa otvoriť SMS aplikáciu: " + e.getMessage());
        }
    }

    private void requestConverterAccess() {
        pendingOpenListenerSettings = true;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIFICATIONS);
            return;
        }
        openNotificationListenerSettings();
    }

    private void openNotificationListenerSettings() {
        pendingOpenListenerSettings = false;
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            toast("V zozname povoľ prístup aplikácii Sonix Motorhome Commander.");
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private boolean isNotificationListenerEnabled() {
        ComponentName component = new ComponentName(this, AlarmNotificationListener.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return manager != null && manager.isNotificationListenerAccessGranted(component);
        }
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(component.flattenToString());
    }

    private void refreshConverterStatus() {
        boolean enabled = isNotificationListenerEnabled();
        converterStatus.setText(enabled
                ? "Prevodník je aktívny. Zóny 6–16 sa budú zobrazovať pod vlastnými názvami."
                : "Prevodník nie je povolený. Otvor prístup k upozorneniam a povoľ túto aplikáciu.");
        converterStatus.setTextColor(enabled ? Color.rgb(27, 94, 32) : Color.rgb(183, 28, 28));

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String last = prefs.getString(ZoneStore.KEY_LAST_ALERT, "");
        long time = prefs.getLong(ZoneStore.KEY_LAST_ALERT_TIME, 0L);
        if (last.isEmpty()) {
            lastAlertText.setText("Posledné preložené upozornenie: zatiaľ žiadne.");
        } else {
            String when = time > 0 ? DateFormat.format("dd.MM.yyyy HH:mm", new Date(time)).toString() : "";
            lastAlertText.setText("Posledné upozornenie: " + last + (when.isEmpty() ? "" : "\n" + when));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doSendDirect();
            } else {
                toast("Priame SMS nebolo povolené. Otváram systémovú SMS aplikáciu.");
                if (pendingDirectSms != null) openSmsWithBody(pendingDirectSms);
            }
            return;
        }

        if (requestCode == REQ_POST_NOTIFICATIONS && pendingOpenListenerSettings) {
            openNotificationListenerSettings();
        }
    }

    private void copyCommand() {
        String error = validateForm();
        if (error != null) {
            toast(error);
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Sonix SMS", buildCommand()));
        toast("Príkaz skopírovaný.");
    }

    private EditText input(String label, String hint, int type) {
        EditText editText = new EditText(this);
        editText.setHint(label + " — " + hint);
        editText.setInputType(type);
        editText.setSingleLine(true);
        editText.setPadding(0, dp(6), 0, dp(6));
        return editText;
    }

    private TextView label(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(14);
        view.setTextColor(Color.rgb(45, 45, 45));
        view.setPadding(0, dp(10), 0, dp(2));
        return view;
    }

    private TextView sectionTitle(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(18);
        view.setTextColor(Color.rgb(30, 50, 30));
        view.setPadding(0, dp(18), 0, dp(8));
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dp(9), 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private Button coloredButton(String value, int color) {
        Button button = button(value);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        return button;
    }

    private void savePrefs() {
        if (alarmPhoneInput == null || passwordInput == null) return;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("alarmPhone", alarmPhoneInput.getText().toString().trim())
                .putString("password", passwordInput.getText().toString().trim())
                .apply();
    }

    private void loadPrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarmPhoneInput.setText(prefs.getString("alarmPhone", "+421940166128"));
        passwordInput.setText(prefs.getString("password", "123456"));
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }

    abstract static class SimpleWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
    }
}
