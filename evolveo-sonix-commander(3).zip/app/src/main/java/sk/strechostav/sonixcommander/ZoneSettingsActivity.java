package sk.strechostav.sonixcommander;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.res.ColorStateList;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ZoneSettingsActivity extends Activity {
    private static final int REQ_SEND_SMS = 401;
    private static final int REQ_POST_NOTIFICATIONS = 402;

    private final EditText[] zoneInputs = new EditText[17];
    private TextView converterStatus;
    private Spinner testZoneSpinner;

    private String pendingCommand;
    private String pendingLabel;
    private int pendingTestZone = -1;
    private boolean pendingOpenListenerSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NotificationHelper.createChannel(this);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshConverterStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(30));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Názvy zón alarmu");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(25, 35, 25));
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Zóny 1–5 sa dajú pomenovať priamo vo firmvéri alarmu. Zóny 6–16 sa ukladajú samostatne v aplikácii a prevodník ich priradí podľa čísla v prijatej správe.");
        intro.setTextSize(14);
        intro.setPadding(0, dp(8), 0, dp(8));
        root.addView(intro);

        root.addView(sectionTitle("Zóny 1–5 – priamo v alarme"));

        for (int zone = 1; zone <= 5; zone++) {
            final int currentZone = zone;
            TextView label = label("Zóna " + zone);
            root.addView(label);

            EditText input = zoneInput(zone);
            root.addView(input);

            Button send = coloredButton("ULOŽIŤ A ODOSLAŤ ZÓNU " + zone, Color.rgb(51, 105, 30));
            send.setOnClickListener(v -> sendDirectZoneName(currentZone));
            root.addView(send);
        }

        root.addView(sectionTitle("Zóny 6–16 – individuálne cez prevodník"));

        TextView converterInfo = new TextView(this);
        converterInfo.setText("Tieto názvy sa neposielajú do alarmu. Alarm musí v správe ponechať číslo zóny, napríklad Wireless Activated(08). Aplikácia potom zobrazí názov uložený nižšie.");
        converterInfo.setTextSize(13);
        converterInfo.setPadding(0, 0, 0, dp(6));
        root.addView(converterInfo);

        for (int zone = 6; zone <= 16; zone++) {
            root.addView(label("Zóna " + zone));
            root.addView(zoneInput(zone));
        }

        Button saveAll = coloredButton("ULOŽIŤ VŠETKY NÁZVY DO APLIKÁCIE", Color.rgb(46, 125, 50));
        saveAll.setOnClickListener(v -> {
            saveAllNames();
            toast("Názvy zón 1–16 sú uložené v telefóne.");
        });
        root.addView(saveAll);

        Button restoreGeneric = button("Nastaviť spoločný text 6–16 na Wireless Activated");
        restoreGeneric.setOnClickListener(v -> {
            saveAllNames();
            sendAlarmCommand("86#Wireless Activated#", "Spoločný text zón 6–16");
        });
        root.addView(restoreGeneric);

        TextView restoreNote = new TextView(this);
        restoreNote.setText("Použi iba vtedy, keď si už spoločný text zón 6–16 prepísal. Po odoslaní otestuj, či alarm stále dopĺňa číslo v zátvorke; bez čísla aplikácia nevie rozlíšiť konkrétnu zónu.");
        restoreNote.setTextSize(12);
        restoreNote.setPadding(0, dp(4), 0, dp(8));
        root.addView(restoreNote);

        root.addView(sectionTitle("Aktivácia a test prevodníka"));

        converterStatus = new TextView(this);
        converterStatus.setTextSize(14);
        converterStatus.setPadding(dp(12), dp(10), dp(12), dp(10));
        converterStatus.setBackgroundColor(Color.rgb(238, 238, 238));
        root.addView(converterStatus);

        Button access = button("POVOLIŤ PRÍSTUP K UPOZORNENIAM");
        access.setOnClickListener(v -> requestNotificationAccess());
        root.addView(access);

        TextView testLabel = label("Testovať lokálne upozornenie pre zónu");
        root.addView(testLabel);

        testZoneSpinner = new Spinner(this);
        List<String> testZones = new ArrayList<>();
        for (int zone = 6; zone <= 16; zone++) testZones.add("Zóna " + zone);
        testZoneSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, testZones));
        root.addView(testZoneSpinner);

        Button test = button("TEST PREVODNÍKA");
        test.setOnClickListener(v -> testConverter());
        root.addView(test);

        Button back = button("SPÄŤ NA HLAVNÉ OVLÁDANIE");
        back.setOnClickListener(v -> finish());
        root.addView(back);

        setContentView(scroll);
        refreshConverterStatus();
    }

    private EditText zoneInput(int zone) {
        EditText editText = new EditText(this);
        editText.setSingleLine(true);
        editText.setHint("Názov zóny " + zone);
        editText.setText(ZoneStore.getZoneName(this, zone));
        editText.setPadding(0, dp(4), 0, dp(4));
        zoneInputs[zone] = editText;
        return editText;
    }

    private void sendDirectZoneName(int zone) {
        saveAllNames();
        String localName = zoneInputs[zone].getText().toString().trim();
        String alarmName = ZoneStore.sanitizeForAlarm(localName);
        if (alarmName.isEmpty()) {
            toast("Názov zóny nesmie byť prázdny.");
            return;
        }
        int operation = 80 + zone;
        sendAlarmCommand(operation + "#" + alarmName + "#", "Názov zóny " + zone);
        if (!alarmName.equals(localName)) {
            toast("Do alarmu sa odošle upravený text: " + alarmName);
        }
    }

    private void saveAllNames() {
        for (int zone = 1; zone <= 16; zone++) {
            if (zoneInputs[zone] != null) {
                ZoneStore.setZoneName(this, zone, zoneInputs[zone].getText().toString());
            }
        }
    }

    private void sendAlarmCommand(String commandCode, String label) {
        String phone = ZoneStore.getAlarmPhone(this).trim();
        String password = ZoneStore.getPassword(this).trim();
        if (phone.isEmpty() || password.isEmpty()) {
            toast("Na hlavnej obrazovke najprv nastav číslo alarmu a heslo.");
            return;
        }

        pendingCommand = password + "#" + commandCode;
        pendingLabel = label;
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
            return;
        }
        doSendCommand();
    }

    private void doSendCommand() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            ArrayList<String> parts = smsManager.divideMessage(pendingCommand);
            smsManager.sendMultipartTextMessage(ZoneStore.getAlarmPhone(this), null, parts, null, null);
            toast(pendingLabel + " – SMS odoslaná.");
        } catch (Exception e) {
            toast("Priame odoslanie zlyhalo. Otváram SMS aplikáciu.");
            openSmsApp(pendingCommand);
        }
    }

    private void openSmsApp(String body) {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + Uri.encode(ZoneStore.getAlarmPhone(this))));
            intent.putExtra("sms_body", body);
            startActivity(intent);
        } catch (Exception e) {
            toast("Nepodarilo sa otvoriť SMS aplikáciu.");
        }
    }

    private void requestNotificationAccess() {
        pendingOpenListenerSettings = true;
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIFICATIONS);
            return;
        }
        openNotificationListenerSettings();
    }

    private void openNotificationListenerSettings() {
        pendingOpenListenerSettings = false;
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
            toast("Povoľ Sonix Motorhome Commander.");
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_SETTINGS));
        }
    }

    private void testConverter() {
        saveAllNames();
        pendingTestZone = 6 + testZoneSpinner.getSelectedItemPosition();
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_POST_NOTIFICATIONS);
            return;
        }
        showTestNotification();
    }

    private void showTestNotification() {
        if (pendingTestZone < 6 || pendingTestZone > 16) return;
        String name = ZoneStore.getZoneName(this, pendingTestZone);
        ZoneStore.saveLastAlert(this, pendingTestZone, name, "Test prevodníka");
        NotificationHelper.showZoneNotification(this, pendingTestZone, name, "Test prevodníka");
        toast("Testovacie upozornenie bolo vytvorené.");
        pendingTestZone = -1;
    }

    private boolean isNotificationListenerEnabled() {
        ComponentName component = new ComponentName(this, AlarmNotificationListener.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return manager != null && manager.isNotificationListenerAccessGranted(component);
        }
        String enabled = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(component.flattenToString());
    }

    private void refreshConverterStatus() {
        if (converterStatus == null) return;
        boolean enabled = isNotificationListenerEnabled();
        converterStatus.setText(enabled
                ? "Prevodník je aktívny."
                : "Prevodník nie je aktívny. Povoľ aplikácii prístup k upozorneniam.");
        converterStatus.setTextColor(enabled ? Color.rgb(27, 94, 32) : Color.rgb(183, 28, 28));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQ_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                doSendCommand();
            } else if (pendingCommand != null) {
                toast("Priame SMS nebolo povolené. Otváram SMS aplikáciu.");
                openSmsApp(pendingCommand);
            }
            return;
        }

        if (requestCode == REQ_POST_NOTIFICATIONS) {
            if (pendingTestZone >= 6) showTestNotification();
            if (pendingOpenListenerSettings) openNotificationListenerSettings();
        }
    }

    private TextView label(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(14);
        view.setTextColor(Color.rgb(45, 45, 45));
        view.setPadding(0, dp(8), 0, 0);
        return view;
    }

    private TextView sectionTitle(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(18);
        view.setTextColor(Color.rgb(30, 50, 30));
        view.setPadding(0, dp(18), 0, dp(6));
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, dp(8), 0, 0);
        button.setLayoutParams(params);
        return button;
    }

    private Button coloredButton(String value, int color) {
        Button button = button(value);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        return button;
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}
