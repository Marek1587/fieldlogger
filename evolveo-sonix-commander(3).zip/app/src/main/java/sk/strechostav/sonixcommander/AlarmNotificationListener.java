package sk.strechostav.sonixcommander;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AlarmNotificationListener extends NotificationListenerService {
    private static final Pattern ZONE_IN_BRACKETS = Pattern.compile("\\(\\s*0?((?:1[0-6])|[1-9])\\s*\\)");
    private static final Pattern ZONE_WORD = Pattern.compile("(?i)(?:zone|zona|zóna)\\s*[:#-]?\\s*0?((?:1[0-6])|[1-9])");
    private static final long DUPLICATE_WINDOW_MS = 15_000L;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;
        if (getPackageName().equals(sbn.getPackageName())) return;

        Notification notification = sbn.getNotification();
        Bundle extras = notification.extras;
        if (extras == null) return;

        String title = safe(extras.getCharSequence(Notification.EXTRA_TITLE));
        String content = collectNotificationText(extras);
        String combined = (title + "\n" + content).trim();
        if (combined.isEmpty()) return;

        String lower = combined.toLowerCase(Locale.ROOT);
        boolean looksLikeSonix = lower.contains("wireless activated")
                || (lower.contains("wireless") && lower.contains("activated"))
                || lower.contains("bezdrôt")
                || lower.contains("bezdrot");

        boolean senderMatches = phoneLooksEqual(title, ZoneStore.getAlarmPhone(this));
        if (!looksLikeSonix && !senderMatches) return;

        int zone = extractZone(combined);
        if (zone < 1 || zone > 16) return;

        // Zóny 6–16 sú hlavný dôvod prevodníka. Zóny 1–5 sa preložia tiež,
        // ak pôvodná správa ešte obsahuje číslo zóny.
        String zoneName = ZoneStore.getZoneName(this, zone);
        if (isRecentDuplicate(sbn, combined, zone)) return;

        ZoneStore.saveLastAlert(this, zone, zoneName, content);
        NotificationHelper.showZoneNotification(this, zone, zoneName, content);
    }

    private String collectNotificationText(Bundle extras) {
        StringBuilder out = new StringBuilder();
        append(out, extras.getCharSequence(Notification.EXTRA_TEXT));
        append(out, extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        append(out, extras.getCharSequence(Notification.EXTRA_SUB_TEXT));
        append(out, extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT));

        Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (messages != null) {
            for (Parcelable parcelable : messages) {
                if (parcelable instanceof Bundle) {
                    Bundle message = (Bundle) parcelable;
                    append(out, message.getCharSequence("text"));
                }
            }
        }
        return out.toString().trim();
    }

    private void append(StringBuilder out, CharSequence value) {
        String s = safe(value).trim();
        if (s.isEmpty()) return;
        if (out.indexOf(s) >= 0) return;
        if (out.length() > 0) out.append('\n');
        out.append(s);
    }

    private int extractZone(String text) {
        int found = -1;
        Matcher brackets = ZONE_IN_BRACKETS.matcher(text);
        while (brackets.find()) found = parseInt(brackets.group(1));
        if (found > 0) return found;

        Matcher word = ZONE_WORD.matcher(text);
        while (word.find()) found = parseInt(word.group(1));
        return found;
    }

    private boolean isRecentDuplicate(StatusBarNotification sbn, String combined, int zone) {
        String fingerprint = sbn.getPackageName() + "|" + zone + "|" + combined;
        long now = System.currentTimeMillis();
        String previous = getSharedPreferences(ZoneStore.PREFS, MODE_PRIVATE)
                .getString("converter_last_fingerprint", "");
        long previousTime = getSharedPreferences(ZoneStore.PREFS, MODE_PRIVATE)
                .getLong("converter_last_fingerprint_time", 0L);
        if (fingerprint.equals(previous) && now - previousTime < DUPLICATE_WINDOW_MS) return true;

        getSharedPreferences(ZoneStore.PREFS, MODE_PRIVATE).edit()
                .putString("converter_last_fingerprint", fingerprint)
                .putLong("converter_last_fingerprint_time", now)
                .apply();
        return false;
    }

    private boolean phoneLooksEqual(String a, String b) {
        String da = digits(a);
        String db = digits(b);
        if (da.length() < 9 || db.length() < 9) return false;
        return da.substring(da.length() - 9).equals(db.substring(db.length() - 9));
    }

    private String digits(String value) {
        return value == null ? "" : value.replaceAll("\\D", "");
    }

    private int parseInt(String value) {
        try { return Integer.parseInt(value); }
        catch (Exception ignored) { return -1; }
    }

    private String safe(CharSequence value) {
        return value == null ? "" : value.toString();
    }
}
