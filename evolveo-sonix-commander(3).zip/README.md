# Sonix Motorhome Commander 1.2.0

Android aplikácia na ovládanie a programovanie GSM alarmu EVOLVEO Sonix cez SMS.

## Kompatibilita s existujúcim GitHub workflowom

ZIP nemá nadradený projektový priečinok. Po rozbalení príkazom:

```bash
unzip -o evolveo-sonix-commander.zip -d project
```

vznikne priamo:

```text
project/app/build.gradle.kts
project/build.gradle.kts
project/settings.gradle.kts
```

Existujúci workflow môže bez zmeny použiť:

```bash
gradle :app:assembleDebug --stacktrace
```

Výsledné APK:

```text
project/app/build/outputs/apk/debug/app-debug.apk
```

## Hlavné zmeny vo verzii 1.2.0

- nová motorhome ikona so zeleným bezpečnostným štítom a signálom,
- veľké tlačidlo **ZAPNÚŤ ALARM** – príkaz `1#1#`,
- veľké tlačidlo **VYPNÚŤ ALARM** – príkaz `1#0#`,
- ostatné príkazy zostávajú v rozbaľovacom zozname,
- samostatná obrazovka pre názvy zón 1–16,
- zóny 1–5 sa dajú pomenovať priamo v alarme cez príkazy 81–85,
- zóny 6–16 majú vlastné lokálne názvy cez prevodník upozornení,
- test lokálneho upozornenia pre každú zónu 6–16,
- zobrazenie posledného preloženého upozornenia.

## Ako funguje prevodník zón 6–16

Firmware alarmu má pre bezdrôtové zóny 6–16 iba jeden spoločný text. Aplikácia preto sleduje systémové upozornenia SMS aplikácie. Keď nájde správu napríklad:

```text
Wireless Activated(08)
```

z čísla zóny vyhľadá lokálny názov a vytvorí vlastné upozornenie, napríklad:

```text
Alarm karavanu – zóna 08
Zadné dvere otvorené
```

Po inštalácii treba v aplikácii stlačiť **POVOLIŤ PREVODNÍK UPOZORNENÍ** a v systémových nastaveniach povoliť prístup aplikácii **Sonix Motorhome Commander**. Na Android 13 a novšom treba povoliť aj zobrazovanie upozornení.

Aplikácia neskenuje databázu SMS. Spracovanie prebieha lokálne z textu systémového upozornenia a údaje sa nikam neodosielajú.

## Dôležité pre zóny 6–16

Prijatá správa musí obsahovať číslo zóny v zátvorke, napríklad `(06)`, `(08)` alebo `(16)`. Ak bol spoločný text v slote 86 zmenený a alarm prestal číslo dopĺňať, aplikácia ponúka príkaz:

```text
123456#86#Wireless Activated#
```

Po jeho použití treba fyzicky otestovať jednu zo zón 6–16 a overiť, či alarm naďalej dopĺňa číslo.

## Prednastavené údaje

- číslo SIM alarmu: `+421940166128`
- heslo: `123456`
- zóna 4: `Pohyb v karavane aktívny`
- zóna 5: `Dvere karavanu otvorené`
- zóna 6: `Šoférove dvere otvorené`

## Povolenia

- `SEND_SMS` – priame odosielanie príkazov,
- `POST_NOTIFICATIONS` – lokálne preložené upozornenia,
- prístup k upozorneniam – rozpoznanie správ `Wireless Activated(nn)` zo SMS aplikácie.

Pri zamietnutí priameho odosielania aplikácia otvorí systémovú SMS aplikáciu s pripraveným príkazom.
