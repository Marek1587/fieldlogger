# Field Manual Logger TILES + Google

## New
- square tile UI with emoji
- note field is explicitly read before each action
- local XLSX
- optional Google Sheets sync via Apps Script Web App

## Google Sheets
Direct edit link is not enough for Android write.
Use `docs/google_apps_script.gs`, deploy as Web App, then paste Web App URL into the app.
