package sk.strechostav.fieldmanual

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private val reqPerm = 1001
    private val reqPhoto = 2001
    private val reqExcelDocument = 3001

    private lateinit var noteEdit: EditText
    private lateinit var statusText: TextView

    private var pendingPhotoNote: String = ""
    private var pendingPhotoFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                File(getExternalFilesDir(null), "field_manual_crash.txt")
                    .appendText("${ManualLogStore.now()} ${e.stackTraceToString()}\n\n", Charsets.UTF_8)
            } catch (_: Exception) {}
        }
        requestPermissionsIfNeeded()
        buildUi()
        safeRefreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) safeRefreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Field Manual Logger"
        title.textSize = 25f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "Ručný terénny denník do Excelu + Google Sheets"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Poznámka k záznamu..."
        noteEdit.minLines = 3
        noteEdit.gravity = Gravity.TOP
        root.addView(noteEdit, full())

        val grid = GridLayout(this)
        grid.columnCount = 2
        root.addView(grid, full())

        addTile(grid, "📄\nExcel", "#455A64") { createExcelDocument() }
        addTile(grid, "☁️\nGoogle URL", "#3367D6") { showGoogleUrlDialog() }
        addTile(grid, "🏗️\nPríchod", "#2E7D32") { writeEvent("SITE_ARRIVAL", "Príchod na stavbu / miesto", readTopNote()) }
        addTile(grid, "🔍\nObhliadka", "#1565C0") { writeEvent("INSPECTION", "Obhliadka / kontrola", readTopNote()) }
        addTile(grid, "📏\nMeranie", "#6A1B9A") { writeEvent("MEASUREMENT", "Meranie / zameranie", readTopNote()) }
        addTile(grid, "☎️\nTelefonát", "#EF6C00") { writeEvent("PHONE_CALL", "Telefonát / komunikácia", readTopNote()) }
        addTile(grid, "🚗\nOdchod", "#C62828") { writeEvent("SITE_DEPARTURE", "Odchod zo stavby / miesta", readTopNote()) }
        addTile(grid, "📝\nPoznámka", "#5D4037") { writeEvent("MANUAL_NOTE", "Vlastná poznámka", readTopNote()) }
        addTile(grid, "📍\nGPS", "#00838F") { writeEvent("GPS_CHECK", "Rýchly GPS zápis", "") }
        addTile(grid, "📷\nFotka", "#283593") {
            pendingPhotoNote = readTopNote()
            openCamera()
        }
        addTile(grid, "🔄\nObnoviť Excel", "#546E7A") {
            val ok = ManualLogStore.rebuildLocalXlsx(this)
            ManualLogStore.exportToConfiguredDocument(this)
            Toast.makeText(this, if (ok) "Excel obnovený." else "Excel sa nepodarilo obnoviť.", Toast.LENGTH_SHORT).show()
            safeRefreshStatus()
        }
        addTile(grid, "📤\nZdieľať Excel", "#00796B") { shareExcel() }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, dp(14), 0, 0)
        root.addView(statusText, full())

        setContentView(scroll)
    }

    private fun addTile(grid: GridLayout, text: String, color: String, fn: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.isAllCaps = false
        b.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor(color))
        bg.cornerRadius = dp(14).toFloat()
        b.background = bg
        b.setOnClickListener { fn() }

        val lp = GridLayout.LayoutParams()
        lp.width = 0
        lp.height = dp(112)
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        lp.setMargins(dp(6), dp(6), dp(6), dp(6))
        grid.addView(b, lp)
    }

    private fun full(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun readTopNote(): String {
        noteEdit.clearFocus()
        val note = noteEdit.text?.toString()?.trim() ?: ""
        noteEdit.setText("")
        return note
    }

    private fun requestPermissionsIfNeeded() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), reqPerm)
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null

        return try {
            lm.getProviders(true).mapNotNull { provider ->
                try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeEvent(eventType: String, title: String, note: String, photoPath: String = "") {
        val entry = ManualLogStore.append(
            context = this,
            eventType = eventType,
            title = title,
            note = note,
            location = bestLocation(),
            photoPath = photoPath
        )

        if (entry == null) {
            Toast.makeText(this, "Zápis zlyhal.", Toast.LENGTH_SHORT).show()
            safeRefreshStatus()
            return
        }

        Toast.makeText(this, "Zapísané: $title", Toast.LENGTH_SHORT).show()

        GoogleSync.syncAsync(this, entry) { ok, msg ->
            runOnUiThread {
                if (GoogleSync.url(this).isNotBlank()) {
                    Toast.makeText(this, if (ok) "Google sync OK" else "Google sync zlyhal: $msg", Toast.LENGTH_SHORT).show()
                }
            }
        }

        safeRefreshStatus()
    }

    private fun safeRefreshStatus() {
        try {
            val local = ManualLogStore.localXlsxFile(this)
            val data = ManualLogStore.dataFile(this)
            val configured = ManualLogStore.configuredDocumentUri(this)
            val gUrl = GoogleSync.url(this)
            statusText.text =
                "Excel v Dokumentoch: ${if (configured != null) "nastavený" else "nenastavený"}\n" +
                "Google sync: ${if (gUrl.isNotBlank()) "nastavený" else "nenastavený"}\n" +
                "Lokálny Excel: ${local.absolutePath}\n" +
                "Veľkosť: ${if (local.exists()) local.length() else 0} B\n" +
                "Dáta: ${data.absolutePath}\n" +
                "Fotky: ${ManualLogStore.photoDir(this).absolutePath}"
        } catch (e: Exception) {
            statusText.text = "Stav sa nepodarilo načítať: ${e.message}"
        }
    }

    private fun createExcelDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_TITLE, "field_manual_log.xlsx")
        startActivityForResult(intent, reqExcelDocument)
    }

    private fun showGoogleUrlDialog() {
        val input = EditText(this)
        input.hint = "Apps Script Web App URL"
        input.setText(GoogleSync.url(this))
        AlertDialog.Builder(this)
            .setTitle("Google Sheets sync")
            .setMessage("Sem vlož URL z Google Apps Script Web App. Priamy Google Sheets edit link nestačí.")
            .setView(input)
            .setPositiveButton("Uložiť") { _, _ ->
                GoogleSync.setUrl(this, input.text.toString())
                Toast.makeText(this, "Google URL uložené.", Toast.LENGTH_SHORT).show()
                safeRefreshStatus()
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun openCamera() {
        val f = File(cacheDir, "camera_${ManualLogStore.stamp()}.jpg")
        pendingPhotoFile = f
        val uri: Uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            startActivityForResult(intent, reqPhoto)
        } catch (e: Exception) {
            Toast.makeText(this, "Nepodarilo sa otvoriť fotoaparát.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android framework")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == reqPhoto) {
            val f = pendingPhotoFile
            if (resultCode == RESULT_OK && f != null && f.exists()) {
                val small = compressImage(f)
                writeEvent("PHOTO_NOTE", "Fotodokumentácia", pendingPhotoNote, small.absolutePath)
                pendingPhotoNote = ""
            } else {
                Toast.makeText(this, "Fotka nebola uložená.", Toast.LENGTH_SHORT).show()
            }
        }

        if (requestCode == reqExcelDocument) {
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri = data.data!!
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                } catch (_: Exception) {}
                ManualLogStore.setConfiguredDocumentUri(this, uri)
                val ok = ManualLogStore.exportToConfiguredDocument(this)
                Toast.makeText(this, if (ok) "Excel v Dokumentoch nastavený." else "Excel nastavený, export zatiaľ zlyhal.", Toast.LENGTH_LONG).show()
                safeRefreshStatus()
            }
        }
    }

    private fun compressImage(src: File): File {
        val out = File(ManualLogStore.photoDir(this), "photo_${ManualLogStore.stamp()}_compressed.jpg")
        val bmp = BitmapFactory.decodeFile(src.absolutePath) ?: return src
        val maxSide = 1600
        val scale = minOf(1.0f, maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat())
        val resized = if (scale < 1.0f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        FileOutputStream(out).use { stream -> resized.compress(Bitmap.CompressFormat.JPEG, 82, stream) }
        if (resized != bmp) resized.recycle()
        bmp.recycle()
        return out
    }

    private fun shareExcel() {
        ManualLogStore.rebuildLocalXlsx(this)
        val f = ManualLogStore.localXlsxFile(this)
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Zdieľať Excel"))
    }
}
