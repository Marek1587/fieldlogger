package sk.strechostav.fieldmanual

import android.content.Context
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GoogleSync {
    private const val PREF = "field_manual_logger"
    private const val KEY_URL = "google_script_url"

    fun url(context: Context): String {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URL, "") ?: ""
    }

    fun setUrl(context: Context, url: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_URL, url.trim()).apply()
    }

    fun syncAsync(context: Context, entry: ManualLogEntry, callback: (Boolean, String) -> Unit) {
        val target = url(context)
        if (target.isBlank()) {
            callback(false, "Google URL nie je nastavené.")
            return
        }

        Thread {
            try {
                val conn = URL(target).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                val payload = json(entry)

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(payload) }

                val code = conn.responseCode
                val ok = code in 200..299
                callback(ok, "HTTP $code")
                conn.disconnect()
            } catch (e: Exception) {
                callback(false, e.message ?: "sync error")
            }
        }.start()
    }

    private fun json(entry: ManualLogEntry): String {
        val fields = mapOf(
            "timestamp" to entry.timestamp,
            "event_type" to entry.eventType,
            "lat" to entry.lat,
            "lon" to entry.lon,
            "accuracy_m" to entry.accuracy,
            "provider" to entry.provider,
            "title" to entry.title,
            "note" to entry.note,
            "photo_path" to entry.photoPath
        )
        return fields.entries.joinToString(prefix = "{", postfix = "}") {
            "\"" + esc(it.key) + "\":\"" + esc(it.value) + "\""
        }
    }

    private fun esc(v: String): String {
        return v
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", " ")
            .replace("\r", " ")
    }
}
