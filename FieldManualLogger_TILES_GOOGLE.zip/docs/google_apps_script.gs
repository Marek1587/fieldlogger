// Field Manual Logger -> Google Sheets
// Spreadsheet ID is from the provided Google Sheets link:
// https://docs.google.com/spreadsheets/d/1Au0i0eGEmRgWYh1JwJEYOsbOl_bGpdiu/edit

const SPREADSHEET_ID = '1Au0i0eGEmRgWYh1JwJEYOsbOl_bGpdiu';
const SHEET_NAME = 'Manual Log';

const HEADER = [
  'timestamp',
  'event_type',
  'lat',
  'lon',
  'accuracy_m',
  'provider',
  'title',
  'note',
  'photo_path'
];

function doPost(e) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME);
    if (!sh) sh = ss.insertSheet(SHEET_NAME);

    if (sh.getLastRow() === 0) {
      sh.appendRow(HEADER);
    }

    const d = JSON.parse(e.postData.contents || '{}');

    sh.appendRow([
      d.timestamp || '',
      d.event_type || '',
      d.lat || '',
      d.lon || '',
      d.accuracy_m || '',
      d.provider || '',
      d.title || '',
      d.note || '',
      d.photo_path || ''
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput('Field Manual Logger endpoint OK')
    .setMimeType(ContentService.MimeType.TEXT);
}
