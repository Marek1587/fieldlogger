package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

final class DocumentCombiner {
    interface ProgressListener {
        void onProgress(int currentFile, int totalFiles, String fileName);
    }

    private static final Paint BITMAP_PAINT =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private DocumentCombiner() {
    }

    static File combineToPdf(
            Context context,
            List<Uri> inputUris,
            boolean imageLandscape,
            ProgressListener progressListener
    ) throws IOException {
        if (inputUris == null || inputUris.isEmpty()) {
            throw new IOException("Nebol vybraný žiadny dokument.");
        }

        File output = File.createTempFile("pdf_podpisovac_", ".pdf", context.getCacheDir());
        PdfDocument document = new PdfDocument();
        PageCounter pageCounter = new PageCounter();
        boolean success = false;
        try {
            for (int index = 0; index < inputUris.size(); index++) {
                Uri uri = inputUris.get(index);
                String name = DocumentFiles.displayName(context, uri);
                String mime = DocumentFiles.mimeType(context, uri, null);
                if (progressListener != null) {
                    progressListener.onProgress(index + 1, inputUris.size(), name);
                }
                appendSource(
                        context,
                        document,
                        pageCounter,
                        uri,
                        name,
                        mime,
                        imageLandscape
                );
            }
            if (pageCounter.value == 0) {
                throw new IOException("Vybrané súbory neobsahujú žiadne použiteľné strany.");
            }
            try (FileOutputStream stream = new FileOutputStream(output)) {
                document.writeTo(stream);
                stream.flush();
            }
            success = true;
            return output;
        } finally {
            document.close();
            if (!success) {
                //noinspection ResultOfMethodCallIgnored
                output.delete();
            }
        }
    }

    private static void appendSource(
            Context context,
            PdfDocument output,
            PageCounter counter,
            Uri uri,
            String name,
            String mime,
            boolean imageLandscape
    ) throws IOException {
        String lowerName = name.toLowerCase(Locale.ROOT);
        if (DocumentFiles.isPdf(mime, name)) {
            appendPdf(context, output, counter, uri);
            return;
        }
        if (mime.startsWith("image/")
                || lowerName.endsWith(".jpg")
                || lowerName.endsWith(".jpeg")
                || lowerName.endsWith(".png")
                || lowerName.endsWith(".webp")) {
            appendImage(context, output, counter, uri, imageLandscape);
            return;
        }
        if (lowerName.endsWith(".docx")
                || "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                .equalsIgnoreCase(mime)) {
            OfficeDocumentImporter.appendDocx(context, uri, output, counter);
            return;
        }
        if (lowerName.endsWith(".xlsx")
                || "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                .equalsIgnoreCase(mime)) {
            OfficeDocumentImporter.appendXlsx(context, uri, output, counter);
            return;
        }
        throw new IOException(
                "Nepodporovaný súbor „" + name
                        + "“. Použite PDF, obrázok, DOCX alebo XLSX."
        );
    }

    private static void appendPdf(
            Context context,
            PdfDocument output,
            PageCounter counter,
            Uri uri
    ) throws IOException {
        File localCopy = copyToCache(context, uri, ".pdf");
        try {
            ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                    localCopy,
                    ParcelFileDescriptor.MODE_READ_ONLY
            );
            try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
                for (int index = 0; index < renderer.getPageCount(); index++) {
                    try (PdfRenderer.Page sourcePage = renderer.openPage(index)) {
                        int pageWidth = Math.max(1, sourcePage.getWidth());
                        int pageHeight = Math.max(1, sourcePage.getHeight());
                        float scale = Math.min(
                                2.1f,
                                2400f / Math.max(pageWidth, pageHeight)
                        );
                        scale = Math.max(0.35f, scale);
                        int bitmapWidth = Math.max(1, Math.round(pageWidth * scale));
                        int bitmapHeight = Math.max(1, Math.round(pageHeight * scale));
                        Bitmap bitmap = Bitmap.createBitmap(
                                bitmapWidth,
                                bitmapHeight,
                                Bitmap.Config.ARGB_8888
                        );
                        bitmap.eraseColor(Color.WHITE);
                        Matrix matrix = new Matrix();
                        matrix.setScale(scale, scale);
                        sourcePage.render(
                                bitmap,
                                null,
                                matrix,
                                PdfRenderer.Page.RENDER_MODE_FOR_PRINT
                        );
                        addBitmapPage(output, counter, bitmap, pageWidth, pageHeight);
                        bitmap.recycle();
                    }
                }
            } catch (SecurityException exception) {
                throw new IOException(
                        "Jedno z PDF je chránené heslom alebo nepodporovaným zabezpečením.",
                        exception
                );
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            localCopy.delete();
        }
    }

    private static void appendImage(
            Context context,
            PdfDocument output,
            PageCounter counter,
            Uri uri,
            boolean landscape
    ) throws IOException {
        Bitmap image = DocumentFiles.decodeImage(context, uri, 5000);
        try {
            int pageWidth = landscape ? 842 : 595;
            int pageHeight = landscape ? 595 : 842;
            addBitmapPage(output, counter, image, pageWidth, pageHeight);
        } finally {
            image.recycle();
        }
    }

    private static void addBitmapPage(
            PdfDocument output,
            PageCounter counter,
            Bitmap bitmap,
            int pageWidth,
            int pageHeight
    ) {
        counter.value++;
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                pageWidth,
                pageHeight,
                counter.value
        ).create();
        PdfDocument.Page page = output.startPage(pageInfo);
        Canvas canvas = page.getCanvas();
        canvas.drawColor(Color.WHITE);
        RectF destination = fitInside(
                bitmap.getWidth(),
                bitmap.getHeight(),
                pageWidth,
                pageHeight
        );
        canvas.drawBitmap(bitmap, null, destination, BITMAP_PAINT);
        output.finishPage(page);
    }

    static PdfDocument.Page startA4Page(
            PdfDocument document,
            PageCounter counter,
            boolean landscape
    ) {
        counter.value++;
        int width = landscape ? 842 : 595;
        int height = landscape ? 595 : 842;
        PdfDocument.PageInfo pageInfo =
                new PdfDocument.PageInfo.Builder(width, height, counter.value).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        page.getCanvas().drawColor(Color.WHITE);
        return page;
    }

    static void finishPage(PdfDocument document, PdfDocument.Page page) {
        document.finishPage(page);
    }

    private static RectF fitInside(
            int sourceWidth,
            int sourceHeight,
            int pageWidth,
            int pageHeight
    ) {
        float scale = Math.min(
                (float) pageWidth / sourceWidth,
                (float) pageHeight / sourceHeight
        );
        float width = sourceWidth * scale;
        float height = sourceHeight * scale;
        float left = (pageWidth - width) / 2f;
        float top = (pageHeight - height) / 2f;
        return new RectF(left, top, left + width, top + height);
    }

    static File copyToCache(Context context, Uri uri, String suffix) throws IOException {
        File file = File.createTempFile("office_import_", suffix, context.getCacheDir());
        boolean success = false;
        try (InputStream input = context.getContentResolver().openInputStream(uri);
             FileOutputStream output = new FileOutputStream(file)) {
            if (input == null) {
                throw new IOException("Súbor sa nepodarilo otvoriť.");
            }
            byte[] buffer = new byte[64 * 1024];
            int read;
            long total = 0;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > 200L * 1024L * 1024L) {
                    throw new IOException("Súbor je väčší ako povolených 200 MB.");
                }
                output.write(buffer, 0, read);
            }
            output.flush();
            success = true;
            return file;
        } finally {
            if (!success) {
                //noinspection ResultOfMethodCallIgnored
                file.delete();
            }
        }
    }

    static final class PageCounter {
        int value;
    }
}
