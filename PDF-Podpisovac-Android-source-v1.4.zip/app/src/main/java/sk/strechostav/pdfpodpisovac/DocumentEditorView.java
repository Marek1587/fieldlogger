package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class DocumentEditorView extends View {
    public interface ChangeListener {
        void onSelectionChanged(Placement activePlacement);

        void onPlacementChanged();
    }

    private final Paint pagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint overlayPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF pageRect = new RectF();
    private final RectF temporaryRect = new RectF();
    private final ArrayList<Placement> placements = new ArrayList<>();

    private Bitmap pageBitmap;
    private float pageWidth = 1f;
    private float pageHeight = 1f;
    private int currentPage;
    private Placement activePlacement;
    private ChangeListener changeListener;

    private float lastTouchX;
    private float lastTouchY;
    private boolean pinching;
    private float pinchStartDistance;
    private float pinchStartAngle;
    private float pinchStartWidth;
    private float pinchStartHeight;
    private float pinchStartRotation;

    public DocumentEditorView(Context context) {
        this(context, null);
    }

    public DocumentEditorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(226, 231, 238));
        setFocusable(true);
        setClickable(true);

        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(Ui.dp(context, 2));
        selectionPaint.setColor(Color.rgb(211, 47, 47));

        shadowPaint.setStyle(Paint.Style.FILL);
        shadowPaint.setColor(Color.argb(42, 0, 0, 0));
    }

    public void setChangeListener(ChangeListener listener) {
        changeListener = listener;
    }

    public void setPage(Bitmap bitmap, int pageIndex, float sourceWidth, float sourceHeight) {
        pageBitmap = bitmap;
        currentPage = pageIndex;
        pageWidth = Math.max(1f, sourceWidth);
        pageHeight = Math.max(1f, sourceHeight);
        if (activePlacement != null && activePlacement.pageIndex != currentPage) {
            activePlacement = null;
            notifySelectionChanged();
        }
        invalidate();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public List<Placement> getPlacements() {
        return Collections.unmodifiableList(placements);
    }

    public Placement getActivePlacement() {
        return activePlacement;
    }

    public void addPlacement(Bitmap bitmap, String label, float widthFraction) {
        addPlacement(bitmap, label, widthFraction, false);
    }

    public void addPlacementAtBottomRight(
            Bitmap bitmap,
            String label,
            float widthFraction
    ) {
        addPlacement(bitmap, label, widthFraction, true);
    }

    private void addPlacement(
            Bitmap bitmap,
            String label,
            float widthFraction,
            boolean bottomRight
    ) {
        if (bitmap == null || bitmap.getWidth() <= 0 || bitmap.getHeight() <= 0) {
            return;
        }
        float normalizedWidth = clamp(widthFraction, 0.06f, 0.90f);
        float normalizedHeight = normalizedWidth
                * ((float) bitmap.getHeight() / (float) bitmap.getWidth())
                * (pageWidth / pageHeight);
        if (normalizedHeight > 0.72f) {
            float factor = 0.72f / normalizedHeight;
            normalizedWidth *= factor;
            normalizedHeight *= factor;
        }

        Placement placement = new Placement(
                bitmap,
                label,
                currentPage,
                0.50f,
                0.72f,
                normalizedWidth,
                normalizedHeight
        );
        if (bottomRight) {
            float margin = 0.035f;
            placement.centerX = 1f - normalizedWidth / 2f - margin;
            placement.centerY = 1f - normalizedHeight / 2f - margin;
            clampPlacement(placement);
        }
        placements.add(placement);
        activePlacement = placement;
        notifySelectionChanged();
        notifyPlacementChanged();
        invalidate();
    }

    public void removeActivePlacement() {
        if (activePlacement == null) {
            return;
        }
        placements.remove(activePlacement);
        activePlacement = null;
        notifySelectionChanged();
        notifyPlacementChanged();
        invalidate();
    }

    public void clearCurrentPage() {
        boolean removed = placements.removeIf(item -> item.pageIndex == currentPage);
        activePlacement = null;
        notifySelectionChanged();
        if (removed) {
            notifyPlacementChanged();
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        calculatePageRect();
        if (pageBitmap == null || pageRect.isEmpty()) {
            Paint messagePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            messagePaint.setColor(Color.DKGRAY);
            messagePaint.setTextSize(Ui.dp(getContext(), 16));
            messagePaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Načítavam dokument…", getWidth() / 2f, getHeight() / 2f, messagePaint);
            return;
        }

        RectF shadow = new RectF(pageRect);
        shadow.offset(Ui.dp(getContext(), 3), Ui.dp(getContext(), 4));
        canvas.drawRect(shadow, shadowPaint);
        canvas.drawColor(Color.TRANSPARENT);
        canvas.drawBitmap(pageBitmap, null, pageRect, pagePaint);

        for (Placement placement : placements) {
            if (placement.pageIndex != currentPage) {
                continue;
            }
            drawPlacement(canvas, placement, placement == activePlacement);
        }
    }

    private void drawPlacement(Canvas canvas, Placement placement, boolean selected) {
        RectF destination = placementRectOnScreen(placement);
        float cx = destination.centerX();
        float cy = destination.centerY();

        canvas.save();
        canvas.rotate(placement.rotationDegrees, cx, cy);
        canvas.drawBitmap(placement.bitmap, null, destination, overlayPaint);
        if (selected) {
            canvas.drawRect(destination, selectionPaint);
            float radius = Ui.dp(getContext(), 5);
            Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            handlePaint.setColor(Color.WHITE);
            handlePaint.setStyle(Paint.Style.FILL);
            canvas.drawCircle(destination.left, destination.top, radius, handlePaint);
            canvas.drawCircle(destination.right, destination.bottom, radius, handlePaint);
            handlePaint.setStyle(Paint.Style.STROKE);
            handlePaint.setStrokeWidth(Ui.dp(getContext(), 2));
            handlePaint.setColor(Color.rgb(211, 47, 47));
            canvas.drawCircle(destination.left, destination.top, radius, handlePaint);
            canvas.drawCircle(destination.right, destination.bottom, radius, handlePaint);
        }
        canvas.restore();
    }

    private RectF placementRectOnScreen(Placement placement) {
        float width = placement.width * pageRect.width();
        float height = placement.height * pageRect.height();
        float centerX = pageRect.left + placement.centerX * pageRect.width();
        float centerY = pageRect.top + placement.centerY * pageRect.height();
        temporaryRect.set(
                centerX - width / 2f,
                centerY - height / 2f,
                centerX + width / 2f,
                centerY + height / 2f
        );
        return new RectF(temporaryRect);
    }

    private void calculatePageRect() {
        if (pageBitmap == null || getWidth() == 0 || getHeight() == 0) {
            pageRect.setEmpty();
            return;
        }
        float padding = Ui.dp(getContext(), 12);
        float availableWidth = Math.max(1f, getWidth() - padding * 2f);
        float availableHeight = Math.max(1f, getHeight() - padding * 2f);
        float bitmapAspect = (float) pageBitmap.getWidth() / (float) pageBitmap.getHeight();
        float availableAspect = availableWidth / availableHeight;

        float width;
        float height;
        if (bitmapAspect > availableAspect) {
            width = availableWidth;
            height = width / bitmapAspect;
        } else {
            height = availableHeight;
            width = height * bitmapAspect;
        }
        float left = (getWidth() - width) / 2f;
        float top = (getHeight() - height) / 2f;
        pageRect.set(left, top, left + width, top + height);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled()) {
            return false;
        }
        calculatePageRect();
        if (pageBitmap == null || pageRect.isEmpty()) {
            return true;
        }

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                lastTouchX = event.getX();
                lastTouchY = event.getY();
                activePlacement = findPlacementAt(lastTouchX, lastTouchY);
                notifySelectionChanged();
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (activePlacement != null && event.getPointerCount() >= 2) {
                    pinching = true;
                    pinchStartDistance = pointerDistance(event);
                    pinchStartAngle = pointerAngle(event);
                    pinchStartWidth = activePlacement.width;
                    pinchStartHeight = activePlacement.height;
                    pinchStartRotation = activePlacement.rotationDegrees;
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (activePlacement == null) {
                    return true;
                }
                if (pinching && event.getPointerCount() >= 2) {
                    float distance = pointerDistance(event);
                    if (pinchStartDistance > 1f) {
                        float scale = distance / pinchStartDistance;
                        float newWidth = clamp(pinchStartWidth * scale, 0.04f, 0.95f);
                        float appliedScale = newWidth / pinchStartWidth;
                        activePlacement.width = newWidth;
                        activePlacement.height = clamp(pinchStartHeight * appliedScale, 0.02f, 0.95f);
                    }
                    activePlacement.rotationDegrees =
                            pinchStartRotation + normalizeAngle(pointerAngle(event) - pinchStartAngle);
                    clampPlacement(activePlacement);
                    notifyPlacementChanged();
                    invalidate();
                    return true;
                }

                float x = event.getX();
                float y = event.getY();
                activePlacement.centerX += (x - lastTouchX) / pageRect.width();
                activePlacement.centerY += (y - lastTouchY) / pageRect.height();
                lastTouchX = x;
                lastTouchY = y;
                clampPlacement(activePlacement);
                notifyPlacementChanged();
                invalidate();
                return true;

            case MotionEvent.ACTION_POINTER_UP:
                pinching = false;
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pinching = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                return true;

            default:
                return super.onTouchEvent(event);
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private Placement findPlacementAt(float x, float y) {
        for (int index = placements.size() - 1; index >= 0; index--) {
            Placement placement = placements.get(index);
            if (placement.pageIndex != currentPage) {
                continue;
            }
            RectF rect = placementRectOnScreen(placement);
            Matrix inverse = new Matrix();
            inverse.setRotate(-placement.rotationDegrees, rect.centerX(), rect.centerY());
            float[] point = new float[]{x, y};
            inverse.mapPoints(point);
            float slop = Ui.dp(getContext(), 12);
            RectF expanded = new RectF(rect);
            expanded.inset(-slop, -slop);
            if (expanded.contains(point[0], point[1])) {
                return placement;
            }
        }
        return null;
    }

    private void clampPlacement(Placement placement) {
        float halfWidth = placement.width / 2f;
        float halfHeight = placement.height / 2f;
        placement.centerX = clamp(placement.centerX, halfWidth, 1f - halfWidth);
        placement.centerY = clamp(placement.centerY, halfHeight, 1f - halfHeight);
    }

    private static float pointerDistance(MotionEvent event) {
        float dx = event.getX(0) - event.getX(1);
        float dy = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float pointerAngle(MotionEvent event) {
        return (float) Math.toDegrees(Math.atan2(
                event.getY(1) - event.getY(0),
                event.getX(1) - event.getX(0)
        ));
    }

    private static float normalizeAngle(float angle) {
        while (angle > 180f) {
            angle -= 360f;
        }
        while (angle < -180f) {
            angle += 360f;
        }
        return angle;
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private void notifySelectionChanged() {
        if (changeListener != null) {
            changeListener.onSelectionChanged(activePlacement);
        }
    }

    private void notifyPlacementChanged() {
        if (changeListener != null) {
            changeListener.onPlacementChanged();
        }
    }
}
