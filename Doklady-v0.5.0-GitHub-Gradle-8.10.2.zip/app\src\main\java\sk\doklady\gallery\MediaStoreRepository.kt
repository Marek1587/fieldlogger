package sk.doklady.gallery

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class MediaAlbum(
    val bucketId: String,
    val name: String,
    val count: Int,
    val coverUri: Uri,
)

data class MediaPhoto(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val bucketId: String,
    val dateAdded: Long,
)

class MediaStoreRepository(private val context: Context) {
    fun loadAlbums(): List<MediaAlbum> {
        val grouped = linkedMapOf<String, MutableList<MediaPhoto>>()
        queryPhotos().forEach { grouped.getOrPut(it.bucketId) { mutableListOf() } += it }
        return grouped.map { (bucketId, photos) ->
            MediaAlbum(
                bucketId = bucketId,
                name = bucketName(bucketId) ?: "Ostatné",
                count = photos.size,
                coverUri = photos.first().uri,
            )
        }.sortedByDescending { album -> grouped[album.bucketId]?.firstOrNull()?.dateAdded ?: 0L }
    }

    fun loadPhotos(bucketId: String): List<MediaPhoto> = queryPhotos(bucketId)

    private fun bucketName(bucketId: String): String? {
        val projection = arrayOf(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)
        return context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            "${MediaStore.Images.Media.BUCKET_ID} = ?",
            arrayOf(bucketId),
            "${MediaStore.Images.Media.DATE_ADDED} DESC",
        )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }

    private fun queryPhotos(bucketId: String? = null): List<MediaPhoto> {
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.BUCKET_ID,
            MediaStore.Images.Media.DATE_ADDED,
        )
        val result = mutableListOf<MediaPhoto>()
        context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection,
            bucketId?.let { "${MediaStore.Images.Media.BUCKET_ID} = ?" },
            bucketId?.let { arrayOf(it) },
            "${MediaStore.Images.Media.DATE_ADDED} DESC",
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val bucketColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.BUCKET_ID)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                result += MediaPhoto(
                    id = id,
                    uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id),
                    displayName = cursor.getString(nameColumn) ?: "Fotografia $id",
                    bucketId = cursor.getString(bucketColumn) ?: "0",
                    dateAdded = cursor.getLong(dateColumn),
                )
            }
        }
        return result
    }
}
