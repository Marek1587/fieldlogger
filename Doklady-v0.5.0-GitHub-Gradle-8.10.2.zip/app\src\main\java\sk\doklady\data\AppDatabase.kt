package sk.doklady.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        DocumentEntity::class,
        DocumentItemEntity::class,
        OcrElementEntity::class,
        VatSummaryEntity::class,
        SupplierEntity::class,
        ProcessingLogEntity::class,
        DocumentFrameEntity::class,
    ],
    version = 4,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun documents(): DocumentDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "doklady.db",
            ).addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4).build()

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val columns = listOf(
                    "batchId TEXT DEFAULT NULL", "workId TEXT DEFAULT NULL", "attemptCount INTEGER NOT NULL DEFAULT 0",
                    "stageProgress INTEGER NOT NULL DEFAULT 0", "phaseStartedAt INTEGER DEFAULT NULL", "finishedAt INTEGER DEFAULT NULL",
                    "errorStage TEXT DEFAULT NULL", "errorStackTrace TEXT DEFAULT NULL", "processedImagePath TEXT DEFAULT NULL", "rawOcrText TEXT DEFAULT NULL",
                    "supplierName TEXT DEFAULT NULL", "supplierRegistrationId TEXT DEFAULT NULL", "documentNumber TEXT DEFAULT NULL", "purchaseDate TEXT DEFAULT NULL",
                    "currency TEXT DEFAULT NULL", "netTotalCents INTEGER DEFAULT NULL", "vatTotalCents INTEGER DEFAULT NULL", "grossTotalCents INTEGER DEFAULT NULL",
                    "confidence INTEGER NOT NULL DEFAULT 0", "itemCount INTEGER NOT NULL DEFAULT 0",
                    "importDurationMs INTEGER NOT NULL DEFAULT 0", "preprocessingDurationMs INTEGER NOT NULL DEFAULT 0",
                    "ocrDurationMs INTEGER NOT NULL DEFAULT 0", "parsingDurationMs INTEGER NOT NULL DEFAULT 0",
                    "validationDurationMs INTEGER NOT NULL DEFAULT 0", "totalDurationMs INTEGER NOT NULL DEFAULT 0",
                )
                columns.forEach { db.execSQL("ALTER TABLE documents ADD COLUMN $it") }
                db.execSQL("CREATE TABLE IF NOT EXISTS document_items (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, documentId TEXT NOT NULL, position INTEGER NOT NULL, originalText TEXT NOT NULL, productCode TEXT, ean TEXT, name TEXT NOT NULL, quantity TEXT, unit TEXT, unitPriceNetCents INTEGER, unitPriceGrossCents INTEGER, vatRate TEXT, totalNetCents INTEGER, totalGrossCents INTEGER, confidence INTEGER NOT NULL, manualEdited INTEGER NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_document_items_documentId ON document_items(documentId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS ocr_elements (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, documentId TEXT NOT NULL, pageNumber INTEGER NOT NULL, blockIndex INTEGER NOT NULL, lineIndex INTEGER NOT NULL, elementIndex INTEGER NOT NULL, text TEXT NOT NULL, `left` INTEGER NOT NULL, `top` INTEGER NOT NULL, `right` INTEGER NOT NULL, `bottom` INTEGER NOT NULL, confidence REAL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_ocr_elements_documentId ON ocr_elements(documentId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS vat_summaries (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, documentId TEXT NOT NULL, rate TEXT NOT NULL, baseCents INTEGER, vatCents INTEGER, totalCents INTEGER)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_vat_summaries_documentId ON vat_summaries(documentId)")
                db.execSQL("CREATE TABLE IF NOT EXISTS suppliers (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, normalizedName TEXT NOT NULL, registrationId TEXT)")
                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_suppliers_normalizedName ON suppliers(normalizedName)")
                db.execSQL("CREATE TABLE IF NOT EXISTS processing_logs (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, documentId TEXT NOT NULL, workId TEXT, workerName TEXT NOT NULL, stage TEXT NOT NULL, status TEXT NOT NULL, startTime INTEGER NOT NULL, endTime INTEGER, durationMs INTEGER, errorMessage TEXT)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_processing_logs_documentId ON processing_logs(documentId)")
            }
        }

        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE documents ADD COLUMN ocrStrategy TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE documents ADD COLUMN ocrPassCount INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE documents ADD COLUMN ocrQualityScore INTEGER NOT NULL DEFAULT 0")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                val columns = listOf(
                    "captureMode TEXT NOT NULL DEFAULT 'SINGLE_IMAGE'",
                    "frameCount INTEGER NOT NULL DEFAULT 0",
                    "selectedFrameCount INTEGER NOT NULL DEFAULT 0",
                    "bestFrameScore REAL DEFAULT NULL",
                    "averageFrameScore REAL DEFAULT NULL",
                    "imageQualityConfidence REAL DEFAULT NULL",
                    "consensusConfidence REAL DEFAULT NULL",
                    "ocrConsistencyConfidence REAL DEFAULT NULL",
                    "parserConfidence REAL DEFAULT NULL",
                    "validationConfidence REAL DEFAULT NULL",
                    "finalConfidence REAL DEFAULT NULL",
                    "conflictingTokens INTEGER NOT NULL DEFAULT 0",
                    "secondPassUsed INTEGER NOT NULL DEFAULT 0",
                    "mathValidationResult TEXT DEFAULT NULL",
                    "parserValidationResult TEXT DEFAULT NULL",
                )
                columns.forEach { db.execSQL("ALTER TABLE documents ADD COLUMN $it") }
                db.execSQL("ALTER TABLE document_items ADD COLUMN nameConfidence INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE document_items ADD COLUMN quantityConfidence INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE document_items ADD COLUMN unitConfidence INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE document_items ADD COLUMN unitPriceConfidence INTEGER DEFAULT NULL")
                db.execSQL("ALTER TABLE document_items ADD COLUMN totalConfidence INTEGER DEFAULT NULL")
                db.execSQL("CREATE TABLE IF NOT EXISTS document_frames (id TEXT NOT NULL, documentId TEXT NOT NULL, sequence INTEGER NOT NULL, capturedAt INTEGER NOT NULL, filePath TEXT, qualityScore REAL NOT NULL, sharpness REAL NOT NULL, exposure REAL NOT NULL, contrast REAL NOT NULL, perspective REAL NOT NULL, stability REAL NOT NULL, glare REAL NOT NULL, coverage REAL NOT NULL, clipping REAL NOT NULL, selectedForOcr INTEGER NOT NULL, ocrText TEXT, ocrConfidence REAL, ocrDurationMs INTEGER, PRIMARY KEY(id))")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_document_frames_documentId ON document_frames(documentId)")
            }
        }
    }
}
