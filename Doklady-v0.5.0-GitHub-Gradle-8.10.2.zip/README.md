# Doklady

Natívna offline-first Android aplikácia v Kotlin/Jetpack Compose na evidenciu bločkov a faktúr.

## Spracovanie

Každá fotografia sa najprv skopíruje do interného úložiska. Room záznam prejde cez skutočné stavy:

`CAPTURED → QUEUED → PREPROCESSING → OCR → PARSING → VALIDATING → PROCESSED/REVIEW_REQUIRED/ERROR`

WorkManager používa jednu persistentnú unique work reťaz `document-processing-sequential-queue`. Jednotlivé doklady majú samostatný `DocumentProcessingWorker`, ale náročné OCR úlohy sa vykonávajú po jednom. Worker nemá network constraint a pokračuje aj bez otvoreného ViewModelu.

OCR používa bundled `com.google.mlkit:text-recognition`, teda model je súčasťou APK a základná pipeline nevyžaduje internet. Pred OCR sa konzervatívne nájde a vyreže plocha dokladu, úzky doklad sa zväčší a vytvoria sa varianty `ENHANCED_GRAY`, `COLOR_CROP` a `ADAPTIVE_BINARY`. Pri dlhých dokladoch sa pridajú prekrývajúce sa zoomované výrezy. Aplikácia vykoná reálne OCR nad každým variantom, odstráni duplicitné riadky výrezov a vyberie výsledok s najlepším skóre podľa čitateľnosti, cien a typických polí dokladu. Zvolená stratégia, počet priechodov a skóre sú uložené v Room a viditeľné v diagnostike.

Výber OCR výsledku obsahuje aj ekonomickú kontrolu: parser spočíta riadkové sumy vrátane zliav a záloh a hľadá rovnakú hodnotu pri `MEDZISÚČET`, `NA ÚHRADU`, `CELKOM` alebo `KARTA`. Texty o úspore sa nesmú použiť ako celková suma ani položka. Ak sa žiadny bežný OCR variant matematicky nezhoduje, automaticky sa spustí detailný retry s menšími a viac zväčšenými výrezmi. Nezhodný výsledok je označený `REVIEW_REQUIRED` a nemôže dostať vysokú confidence iba preto, že OCR našlo veľa textu.

## Multi-frame kamera

Nové fotografovanie používa súčasne CameraX `Preview`, `ImageAnalysis` a kvalitný archívny `ImageCapture`. `ImageAnalysis` má `STRATEGY_KEEP_ONLY_LATEST` a je obmedzený približne na 7–8 vyhodnotených frameov za sekundu. Metadata posledných 24 frameov tvoria pevný rolling buffer; v pamäti sa nehromadia `ImageProxy`. Z TOP 8 sa do interného úložiska zachová najviac 6 geometricky alebo časovo odlišných frameov pre sekvenčné offline OCR.

Frame quality je vážený geometrický súčin normalizovanej ostrosti (variance of Laplacian), pokrytia dokumentu, perspektívy, expozície, kontrastu a stability s odpočítaním odlesku a orezania. Váhy sú `0.28 / 0.18 / 0.14 / 0.11 / 0.11 / 0.18`; penalty odlesku je `0.18` a clippingu `0.15`. Auto-capture vyžaduje minimálne 15 analyzovaných frameov, 5 prijatých záberov, stabilitu aspoň 750 ms a quality najmenej 0,72. Po spustení capture pokračuje zber ešte 400 ms.

Vybrané frame-y sú perspektívne narovnané do spoločného dokumentového priestoru. ML Kit OCR nad nimi beží sekvenčne. Riadky sa párujú podľa normalizovaných súradníc, výšky a textovej podobnosti. Text používa fuzzy hlasovanie, finančné čísla prísne normalizované hlasovanie. Consensus tokenu je počet frameov podporujúcich víťaza delený počtom OCR frameov. Konfliktné finančné tokeny sa ukladajú do diagnostiky. Pri chýbajúcom kritickom poli alebo matematickej nezhode sa druhý OCR priechod spustí len nad potrebnými oblasťami `HEADER`, `ITEMS` a/alebo `TOTALS`, zväčšenými na efektívnu šírku 2500–2600 px.

`finalConfidence` je vážený geometrický priemer dostupných skutočných metrík: image quality 16 %, temporal consensus 22 %, OCR consistency 14 %, parser 12 %, matematika 18 %, hlavička 8 % a položky 10 %. Chýbajúci výsledok je `null/NEZNÁMA`, nikdy automatických 50 %. Hodnota 100 % je povolená iba pre multi-frame capture s aspoň 15/4 frameami, image quality ≥ 97 %, úplným kritickým consensus, OCR consistency ≥ 99 %, bez konfliktov, s jednoznačným dodávateľom/číslom/dátumom/IČO, presnou položkovou a DPH matematikou a bez second-pass zásahu. Inak je výsledok najviac 99 %.

Ukladajú sa RAW text, geometrické OCR elementy, parsované polia, položky, confidence, chybová fáza, stack trace a časy jednotlivých krokov.

## Galéria

Hlavné tlačidlo galérie otvára vlastný MediaStore albumový browser cez `BUCKET_ID` a `BUCKET_DISPLAY_NAME`. Podporuje multiselect. Systémový Photo Picker zostáva dostupný ako sekundárna voľba.

## Excel

Aplikácia generuje platný XLSX lokálne a bez Excelu. Obsahuje listy `DOKLADY`, `POLOŽKY`, `DPH` a `DODÁVATELIA`. Výsledok možno zdieľať cez FileProvider alebo uložiť cez Android Storage Access Framework.

## Zostavenie

Projekt vyžaduje JDK 17, Android SDK 35 a je zladený s Gradle 8.10.2.

```powershell
.\gradlew.bat testDebugUnitTest :app:assembleDebug lintDebug
```

Debug APK vznikne v `app/build/outputs/apk/debug/app-debug.apk`.

## Diagnostika

Tlačidlo **Diagnostika** na hlavnej obrazovke zobrazuje Work UUID, počet pokusov, stav, chybovú fázu, správu, stack trace a časy importu/preprocessingu/OCR/parsera/validácie. Recovery Worker kontroluje staré aktívne záznamy každých 15 minút a legacy záznamy `CAPTURED` po aktualizácii automaticky zaradí do fronty.
