package sk.doklady.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sk.doklady.ExportPeriod
import sk.doklady.ExportUiState

@Composable
fun ExportScreen(
    state: ExportUiState,
    suppliers: List<String>,
    onBack: () -> Unit,
    onPeriod: (ExportPeriod) -> Unit,
    onSupplier: (String?) -> Unit,
    onProcessed: (Boolean) -> Unit,
    onReview: (Boolean) -> Unit,
    onCreate: () -> Unit,
    onShare: () -> Unit,
    onSaveAs: () -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Späť") }
        Text("EXPORT DO EXCELU", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Obdobie", fontWeight = FontWeight.Bold)
        PeriodRow("Všetko", ExportPeriod.ALL, state.period, onPeriod)
        PeriodRow("Dnes", ExportPeriod.TODAY, state.period, onPeriod)
        PeriodRow("Tento mesiac", ExportPeriod.MONTH, state.period, onPeriod)
        Text("Dodávateľ", fontWeight = FontWeight.Bold)
        var expanded by remember { mutableStateOf(false) }
        Column {
            OutlinedButton(onClick = { expanded = true }, Modifier.fillMaxWidth()) { Text(state.selectedSupplier ?: "Všetci") }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                DropdownMenuItem(text = { Text("Všetci") }, onClick = { onSupplier(null); expanded = false })
                suppliers.forEach { supplier -> DropdownMenuItem(text = { Text(supplier) }, onClick = { onSupplier(supplier); expanded = false }) }
            }
        }
        Text("Doklady", fontWeight = FontWeight.Bold)
        CheckRow("Spracované", state.includeProcessed, onProcessed)
        CheckRow("Na kontrolu", state.includeReview, onReview)
        Button(onClick = onCreate, enabled = !state.creating && (state.includeProcessed || state.includeReview), modifier = Modifier.fillMaxWidth()) {
            Text(if (state.creating) "VYTVÁRAM…" else "VYTVORIŤ XLSX")
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        state.createdFile?.let { file ->
            Text("Excel vytvorený", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Názov: ${file.name}")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = onShare, Modifier.weight(1f)) { Text("ZDIEĽAŤ") }
                OutlinedButton(onClick = onSaveAs, Modifier.weight(1f)) { Text("ULOŽIŤ AKO") }
            }
        }
    }
}

@Composable private fun PeriodRow(label: String, value: ExportPeriod, selected: ExportPeriod, onSelect: (ExportPeriod) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onSelect(value) }) { RadioButton(selected == value, { onSelect(value) }); Text(label, Modifier.padding(top = 12.dp)) }
}

@Composable private fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }) { Checkbox(checked, onChange); Text(label, Modifier.padding(top = 12.dp)) }
}
