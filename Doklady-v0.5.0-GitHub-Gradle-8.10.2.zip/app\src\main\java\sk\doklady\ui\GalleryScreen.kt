package sk.doklady.ui

import android.graphics.BitmapFactory
import android.os.Build
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sk.doklady.GalleryUiState
import sk.doklady.gallery.MediaAlbum
import sk.doklady.gallery.MediaPhoto

@Composable
fun GalleryScreen(
    state: GalleryUiState,
    importing: Boolean,
    onBack: () -> Unit,
    onAlbum: (MediaAlbum) -> Unit,
    onPhoto: (android.net.Uri) -> Unit,
    onProcess: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← Späť") }
            Column(Modifier.weight(1f)) {
                Text(state.currentAlbum?.name ?: "ALBUMY", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (state.selected.isNotEmpty()) Text("Vybrané: ${state.selected.size}")
            }
        }
        state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
        if (state.loading) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        else if (state.currentAlbum == null) {
            LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(8.dp)) {
                items(state.albums, key = { it.bucketId }) { album -> AlbumCard(album) { onAlbum(album) } }
            }
        } else {
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(3.dp)) {
                items(state.photos, key = { it.id }) { photo ->
                    PhotoCell(photo, state.selected.indexOf(photo.uri).takeIf { it >= 0 }?.plus(1)) { onPhoto(photo.uri) }
                }
            }
        }
        if (state.selected.isNotEmpty()) {
            Button(onClick = onProcess, enabled = !importing, modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text(if (importing) "IMPORTUJEM…" else "SPRACOVAŤ ${state.selected.size} DOKLADOV")
            }
        }
    }
}

@Composable private fun AlbumCard(album: MediaAlbum, onClick: () -> Unit) {
    Column(Modifier.padding(6.dp).clickable(onClick = onClick)) {
        MediaStoreThumbnail(album.coverUri, Modifier.fillMaxWidth().aspectRatio(1f))
        Text(album.name, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
        Text(album.count.toString(), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun PhotoCell(photo: MediaPhoto, selectedNumber: Int?, onClick: () -> Unit) {
    Box(Modifier.padding(2.dp).aspectRatio(1f).clickable(onClick = onClick)) {
        MediaStoreThumbnail(photo.uri, Modifier.fillMaxSize())
        selectedNumber?.let {
            Surface(Modifier.align(Alignment.TopEnd).padding(5.dp), shape = androidx.compose.foundation.shape.CircleShape, color = Color(0xFF1E5B45)) {
                Text(it.toString(), color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable private fun MediaStoreThumbnail(uri: android.net.Uri, modifier: Modifier) {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<android.graphics.Bitmap?>(null) }
    LaunchedEffect(uri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(uri, Size(360, 360), null)
                else context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
        }
    }
    Box(modifier.background(Color(0xFFE1E5E2)), contentAlignment = Alignment.Center) {
        bitmap?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}
