package sk.doklady.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import sk.doklady.DokladyApplication
import sk.doklady.data.DocumentStatus
import java.util.concurrent.TimeUnit

class QueueRecoveryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val app = applicationContext as DokladyApplication
        val dao = app.database.documents()
        val manager = WorkManager.getInstance(applicationContext)
        val now = System.currentTimeMillis()
        dao.getRecoverable().forEach { document ->
            if (document.status == DocumentStatus.CAPTURED) {
                app.scheduler.enqueue(document.id, dao)
                return@forEach
            }
            if (now - document.updatedAt < STALE_MS) return@forEach
            val infos = runCatching { manager.getWorkInfosByTag("document:${document.id}").get() }.getOrDefault(emptyList())
            val active = infos.any { it.state in setOf(WorkInfo.State.ENQUEUED, WorkInfo.State.BLOCKED, WorkInfo.State.RUNNING) }
            if (!active) {
                dao.markError(
                    id = document.id,
                    stage = "STALE_WORK",
                    message = "Spracovanie bolo prerušené a WorkManager už nemá aktívnu úlohu. Použite Skúsiť znova.",
                    stackTrace = "Recovery check: no active WorkInfo for persisted status ${document.status}",
                    totalDuration = document.totalDurationMs,
                    now = now,
                )
            }
        }
        Result.success()
    }

    companion object { private val STALE_MS = TimeUnit.MINUTES.toMillis(20) }
}
