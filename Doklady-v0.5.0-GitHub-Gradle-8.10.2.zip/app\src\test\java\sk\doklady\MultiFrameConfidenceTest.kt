package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.data.CaptureMode
import sk.doklady.processing.ConfidenceEngine
import sk.doklady.processing.ConfidenceInput
import sk.doklady.processing.ConsensusVote
import sk.doklady.processing.ParsedDocument
import sk.doklady.processing.ParsedItem
import sk.doklady.processing.TextVote

class MultiFrameConfidenceTest {
    @Test
    fun `numeric consensus selects four of five frames but records conflict`() {
        val result = ConsensusVote.resolve(
            listOf(
                TextVote("21,90", "f1", 0.95f), TextVote("21,90", "f2", 0.92f),
                TextVote("27,90", "f3", 0.96f), TextVote("21,90", "f4", 0.91f),
                TextVote("21,90", "f5", 0.93f),
            ),
            totalFrames = 5,
        )

        assertEquals("21,90", result.text)
        assertEquals(0.80f, result.consensus, 0.001f)
        assertTrue(result.conflict)
    }

    @Test
    fun `one hundred requires every strict multi frame condition`() {
        val result = ConfidenceEngine().calculate(
            completeInput(captureMode = CaptureMode.MULTI_FRAME),
        )

        assertTrue(result.strictHundredConditionsMet)
        assertEquals(100f, result.finalConfidence ?: 0f, 0.001f)
        assertFalse(result.requiresReview)
    }

    @Test
    fun `single image is capped below one hundred`() {
        val result = ConfidenceEngine().calculate(
            completeInput(captureMode = CaptureMode.SINGLE_IMAGE).copy(
                frameCount = 0,
                selectedFrameCount = 0,
                temporalConsensusConfidence = null,
                criticalConsensus = null,
            ),
        )

        assertFalse(result.strictHundredConditionsMet)
        assertTrue((result.finalConfidence ?: 0f) < 100f)
    }

    @Test
    fun `missing total is unknown not fake fifty`() {
        val result = ConfidenceEngine().calculate(
            ConfidenceInput(
                captureMode = CaptureMode.SINGLE_IMAGE,
                frameCount = 0,
                selectedFrameCount = 0,
                imageQualityConfidence = 0.8f,
                temporalConsensusConfidence = null,
                ocrConsistencyConfidence = 0.8f,
                criticalConsensus = null,
                conflictingTokens = 0,
                secondPassUsed = false,
                parsed = ParsedDocument("LIDL", null, null, "2026-08-15", "EUR", null, null, null, emptyList()),
            ),
        )

        assertNull(result.finalConfidence)
        assertTrue(result.requiresReview)
    }

    private fun completeInput(captureMode: CaptureMode) = ConfidenceInput(
        captureMode = captureMode,
        frameCount = 20,
        selectedFrameCount = 5,
        imageQualityConfidence = 0.98f,
        temporalConsensusConfidence = 1f,
        ocrConsistencyConfidence = 1f,
        criticalConsensus = 1f,
        conflictingTokens = 0,
        secondPassUsed = false,
        parsed = ParsedDocument(
            supplier = "LIDL",
            registrationId = "35793783",
            documentNumber = "3376",
            purchaseDate = "2026-08-15",
            currency = "EUR",
            netTotalCents = 166,
            vatTotalCents = 34,
            grossTotalCents = 200,
            items = listOf(
                ParsedItem("A", "A", quantity = "1", unit = "KS", unitPriceGrossCents = 100, totalGrossCents = 100, confidence = 99),
                ParsedItem("B", "B", quantity = "1", unit = "KS", unitPriceGrossCents = 100, totalGrossCents = 100, confidence = 99),
            ),
        ),
    )
}
