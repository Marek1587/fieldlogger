package sk.doklady

import android.app.Application
import sk.doklady.data.AppDatabase
import sk.doklady.storage.DocumentStorage
import sk.doklady.work.DocumentWorkScheduler
import sk.doklady.gallery.MediaStoreRepository
import sk.doklady.export.XlsxExporter

class DokladyApplication : Application() {
    val database by lazy { AppDatabase.create(this) }
    val storage by lazy { DocumentStorage(this) }
    val scheduler by lazy { DocumentWorkScheduler(this) }
    val mediaStore by lazy { MediaStoreRepository(this) }
    val xlsxExporter by lazy { XlsxExporter(this) }

    override fun onCreate() {
        super.onCreate()
        scheduler.scheduleRecovery()
    }
}
