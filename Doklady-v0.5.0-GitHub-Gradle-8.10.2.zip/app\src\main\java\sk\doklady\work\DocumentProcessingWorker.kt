package sk.doklady.work

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import sk.doklady.DokladyApplication
import sk.doklady.data.DocumentStatus
import sk.doklady.data.CaptureMode
import sk.doklady.data.ProcessingLogEntity
import sk.doklady.data.SupplierEntity
import sk.doklady.data.VatSummaryEntity
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.processing.ImagePreprocessor
import sk.doklady.processing.MultiPassOcrEngine
import sk.doklady.processing.MultiFrameOcrEngine
import sk.doklady.processing.ConfidenceEngine
import sk.doklady.processing.ConfidenceInput
import sk.doklady.processing.asUnified
import sk.doklady.processing.toEntity
import java.io.File
import kotlin.math.roundToInt

class DocumentProcessingWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    private val app = applicationContext as DokladyApplication
    private val dao = app.database.documents()
    private var currentStage = DocumentStatus.QUEUED.name
    private var totalStartedAt = 0L

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val documentId = inputData.getString(DOCUMENT_ID) ?: return@withContext Result.failure()
        totalStartedAt = System.currentTimeMillis()
        try {
            val document = dao.get(documentId) ?: return@withContext Result.success()
            dao.incrementAttempt(documentId, totalStartedAt)
            Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME START_TIME=$totalStartedAt STATUS=STARTED")

            val preprocessed = measuredStage(documentId, DocumentStatus.PREPROCESSING, 15) {
                val target = app.storage.processedTarget(documentId)
                val started = System.currentTimeMillis()
                val bundle = ImagePreprocessor().process(File(document.originalImagePath), target)
                dao.savePreprocessing(
                    documentId,
                    bundle.primary.absolutePath,
                    System.currentTimeMillis() - started,
                    System.currentTimeMillis(),
                )
                Log.i(
                    TAG,
                    "DOCUMENT_ID=$documentId WORKER_NAME=ImagePreprocessor STATUS=SUCCESS " +
                        "CROP=${bundle.cropApplied} SCALE=${"%.2f".format(bundle.scaleFactor)} VARIANTS=${bundle.variants.size}",
                )
                bundle
            }

            val ocrResult = measuredStage(documentId, DocumentStatus.OCR, 40) {
                val started = System.currentTimeMillis()
                val frames = dao.getSelectedFrames(documentId)
                val result = if (document.captureMode == CaptureMode.MULTI_FRAME && frames.size >= 2) {
                    MultiFrameOcrEngine(applicationContext).recognize(documentId, frames)
                } else {
                    MultiPassOcrEngine(applicationContext).recognize(documentId, preprocessed).asUnified()
                }
                result.frameResults.forEach { frame ->
                    dao.saveFrameOcr(frame.frameId, frame.rawText, frame.meanConfidence, frame.durationMs)
                }
                result.passSummaries.forEach { pass ->
                    val ended = System.currentTimeMillis()
                    dao.insertLog(ProcessingLogEntity(
                        documentId = documentId,
                        workId = id.toString(),
                        workerName = "MultiPassOcrEngine",
                        stage = "OCR_PASS_${pass.name}",
                        status = "SUCCESS_SCORE_${pass.qualityScore}",
                        startTime = ended - pass.durationMs,
                        endTime = ended,
                        durationMs = pass.durationMs,
                        errorMessage = "riadky=${pass.lineCount}, znaky=${pass.characterCount}, " +
                            "confidence=${pass.meanConfidence}%, súčet=${pass.itemSumCents}, " +
                            "celkom=${pass.totalCents}, rozdiel=${pass.differenceCents}, zhoda=${pass.financiallyConsistent}",
                    ))
                    Log.i(
                        TAG,
                        "DOCUMENT_ID=$documentId WORKER_NAME=MultiPassOcrEngine STATUS=PASS " +
                            "STRATEGY=${pass.name} SCORE=${pass.qualityScore} LINES=${pass.lineCount} " +
                            "CHARS=${pass.characterCount} CONFIDENCE=${pass.meanConfidence} " +
                            "ITEM_SUM=${pass.itemSumCents} TOTAL=${pass.totalCents} " +
                            "FINANCIAL_MATCH=${pass.financiallyConsistent} DURATION_MS=${pass.durationMs}",
                    )
                }
                dao.replaceOcr(documentId, result.elements)
                dao.saveOcr(
                    id = documentId,
                    rawText = result.rawText,
                    duration = System.currentTimeMillis() - started,
                    strategy = result.strategy,
                    passCount = result.passCount,
                    qualityScore = result.qualityScore,
                    now = System.currentTimeMillis(),
                )
                Log.i(
                    TAG,
                    "DOCUMENT_ID=$documentId WORKER_NAME=MultiPassOcrEngine STATUS=SELECTED " +
                        "STRATEGY=${result.strategy} SCORE=${result.qualityScore} PASSES=${result.passCount} " +
                        "ITEM_SUM=${result.itemSumCents} TOTAL=${result.totalCents} " +
                        "FINANCIAL_MATCH=${result.financiallyConsistent} RETRY=${result.retryTriggered}",
                )
                result
            }

            val parsed = measuredStage(documentId, DocumentStatus.PARSING, 70) {
                val started = System.currentTimeMillis()
                val value = GenericDocumentParser().parse(ocrResult.lines)
                val items = value.items.mapIndexed { index, item -> item.toEntity(documentId, index + 1) }
                dao.replaceItems(documentId, items)
                dao.saveParsed(
                    id = documentId,
                    supplier = value.supplier,
                    registrationId = value.registrationId,
                    documentNumber = value.documentNumber,
                    purchaseDate = value.purchaseDate,
                    currency = value.currency,
                    netTotal = value.netTotalCents,
                    vatTotal = value.vatTotalCents,
                    grossTotal = value.grossTotalCents,
                    itemCount = items.size,
                    duration = System.currentTimeMillis() - started,
                    now = System.currentTimeMillis(),
                )
                value.supplier?.let { supplier ->
                    dao.insertSupplier(
                        SupplierEntity(
                            name = supplier,
                            normalizedName = supplier.trim().uppercase(),
                            registrationId = value.registrationId,
                        ),
                    )
                }
                dao.deleteVatSummaries(documentId)
                if (value.vatTotalCents != null || value.netTotalCents != null) {
                    dao.insertVatSummaries(listOf(
                        VatSummaryEntity(
                            documentId = documentId,
                            rate = "nezistená",
                            baseCents = value.netTotalCents,
                            vatCents = value.vatTotalCents,
                            totalCents = value.grossTotalCents,
                        ),
                    ))
                }
                value
            }

            measuredStage(documentId, DocumentStatus.VALIDATING, 90) {
                val started = System.currentTimeMillis()
                val confidence = ConfidenceEngine().calculate(ConfidenceInput(
                    captureMode = document.captureMode,
                    frameCount = document.frameCount,
                    selectedFrameCount = document.selectedFrameCount,
                    imageQualityConfidence = document.imageQualityConfidence ?: (ocrResult.qualityScore / 100f),
                    temporalConsensusConfidence = ocrResult.consensusConfidence,
                    ocrConsistencyConfidence = ocrResult.ocrConsistencyConfidence,
                    criticalConsensus = ocrResult.criticalConsensus,
                    conflictingTokens = ocrResult.conflictingTokens,
                    secondPassUsed = ocrResult.retryTriggered,
                    parsed = parsed,
                ))
                val now = System.currentTimeMillis()
                dao.saveConfidenceDiagnostics(
                    id = documentId,
                    imageQuality = confidence.imageQuality,
                    consensus = confidence.temporalConsensus,
                    ocrConsistency = confidence.ocrConsistency,
                    parserConfidence = confidence.parserConfidence,
                    validationConfidence = confidence.mathematicalValidation,
                    finalConfidence = confidence.finalConfidence,
                    conflictingTokens = ocrResult.conflictingTokens,
                    secondPassUsed = ocrResult.retryTriggered,
                    mathResult = confidence.mathResult,
                    parserResult = confidence.parserResult,
                    now = now,
                )
                dao.finish(
                    id = documentId,
                    status = if (confidence.requiresReview) DocumentStatus.REVIEW_REQUIRED else DocumentStatus.PROCESSED,
                    confidence = confidence.finalConfidence?.roundToInt() ?: 0,
                    validationDuration = now - started,
                    totalDuration = now - totalStartedAt,
                    now = now,
                )
                Log.i(
                    TAG,
                    "DOCUMENT_ID=$documentId WORKER_NAME=ConfidenceEngine FINAL=${confidence.finalConfidence} " +
                        "IMAGE=${confidence.imageQuality} CONSENSUS=${confidence.temporalConsensus} " +
                        "OCR=${confidence.ocrConsistency} PARSER=${confidence.parserConfidence} " +
                        "MATH=${confidence.mathematicalValidation} REVIEW=${confidence.requiresReview}",
                )
            }
            val ended = System.currentTimeMillis()
            Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME END_TIME=$ended STATUS=SUCCESS")
            Result.success()
        } catch (error: Throwable) {
            val ended = System.currentTimeMillis()
            val message = error.message ?: error.javaClass.simpleName
            runCatching {
                dao.markError(
                    id = documentId,
                    stage = currentStage,
                    message = message,
                    stackTrace = error.stackTraceToString().take(16_000),
                    totalDuration = (ended - totalStartedAt).coerceAtLeast(0),
                    now = ended,
                )
            }
            Log.e(
                TAG,
                "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME END_TIME=$ended STATUS=ERROR ERROR_MESSAGE=$message",
                error,
            )
            // The document owns the error state. Success keeps the global sequential queue moving.
            Result.success()
        }
    }

    private suspend fun <T> measuredStage(
        documentId: String,
        status: DocumentStatus,
        progress: Int,
        block: suspend () -> T,
    ): T {
        currentCoroutineContext().ensureActive()
        currentStage = status.name
        val started = System.currentTimeMillis()
        dao.transition(documentId, status, progress, started)
        val logId = dao.insertLog(ProcessingLogEntity(
            documentId = documentId,
            workId = id.toString(),
            workerName = WORKER_NAME,
            stage = status.name,
            status = "STARTED",
            startTime = started,
        ))
        Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME START_TIME=$started STATUS=${status.name}")
        return try {
            block().also {
                val ended = System.currentTimeMillis()
                dao.finishLog(logId, "SUCCESS", ended, ended - started)
            }
        } catch (error: Throwable) {
            val ended = System.currentTimeMillis()
            dao.finishLog(logId, "ERROR", ended, ended - started, error.message)
            throw error
        }
    }

    companion object {
        const val DOCUMENT_ID = "document_id"
        const val WORKER_NAME = "DocumentProcessingWorker"
        private const val TAG = "DokladyPipeline"
    }
}
