package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.processing.OcrLine
import sk.doklady.processing.ReceiptReconciler
import sk.doklady.processing.ValidationEngine

class DocumentParserTest {
    @Test
    fun `parses multiline receipt item and real totals`() {
        val lines = listOf(
            "HORNBACH", "IČO: 12345678", "Dátum 26.08.2026",
            "OSB 3 P+D 18MM 2500X625", "4 KS x 16,40", "65,60",
            "Základ 54,67", "DPH 10,93", "CELKOM 65,60 EUR",
        ).mapIndexed { index, text -> OcrLine(text, 0, index * 20, 500, index * 20 + 18) }

        val parsed = GenericDocumentParser().parse(lines)

        assertEquals("HORNBACH", parsed.supplier)
        assertEquals("2026-08-26", parsed.purchaseDate)
        assertEquals(6560L, parsed.grossTotalCents)
        assertEquals(6560L, GenericDocumentParser.parseCents("65.60"))
        assertEquals(123456L, GenericDocumentParser.parseCents("1.234,56"))
        assertEquals(1, parsed.items.size)
        assertEquals("4", parsed.items.single().quantity)
        assertEquals(1640L, parsed.items.single().unitPriceGrossCents)
        assertEquals(6560L, parsed.items.single().totalGrossCents)
        assertFalse(ValidationEngine().validate(parsed, lines.joinToString(" ") { it.text }).requiresReview)
    }

    @Test
    fun `blank unstructured OCR requires review`() {
        val parsed = GenericDocumentParser().parse(listOf(OcrLine("nečitateľné", 0, 0, 10, 10)))
        val validation = ValidationEngine().validate(parsed, "nečitateľné")
        assertTrue(validation.requiresReview)
        assertTrue(validation.confidence < 70)
    }

    @Test
    fun `lidl receipt uses arithmetic total and excludes savings`() {
        val rawLines = listOf(
            "LIDL", "Lidl Slovenská republika, s.r.o.", "IČO: 35793783", "15-08-2026 20:22:53", "Č.bloku: 3376",
            "Šalát Rosso", "1 ks", "0,89 E", "ZLAVA", "-0,27 E",
            "Dojčenská voda", "4 ks * 0,39", "1,56 E",
            "Záloh. fľaša plast", "4 ks * 0,15", "0,60 A",
            "Smoothie jah-ban", "2 ks * 2,29", "4,58 C",
            "Záloh. fľaša plast", "2 ks * 0,15", "0,30 A",
            "Šunková saláma", "2 ks * 2,89", "5,78 E",
            "Zmrazené jahody", "x", "2 ks x 3,19", "6,38 E",
            "Gr.jogurt 2%,1kg", "3 ks * 1,89", "5,67 C",
            "Morcacia šunka", "2 ks * 1,69", "3,38 E",
            "Cottage light", "2 ks x 1,19", "2,38 E",
            "Tvaroh odtučneny", "1 ks", "0,69 E",
            "MEDZISÚČET", "31,94", "NA ÚHRADU EUR", "KARTA", "31,94",
            "Základ:", "DPH:", "SPOLU:", "28,13", "3,81",
            "Týmto nákupom ste", "celkovo ušetrili 0,27 EUR",
        )
        val lines = rawLines.mapIndexed { index, text -> OcrLine(text, 0, index * 20, 500, index * 20 + 18) }

        val parsed = GenericDocumentParser().parse(lines)
        val reconciliation = ReceiptReconciler.evaluate(parsed)
        val validation = ValidationEngine().validate(parsed, rawLines.joinToString("\n"))

        assertEquals(3194L, parsed.grossTotalCents)
        assertEquals(2813L, parsed.netTotalCents)
        assertEquals(381L, parsed.vatTotalCents)
        assertEquals(12, parsed.items.size)
        assertEquals(3194L, reconciliation.itemSumCents)
        assertTrue(reconciliation.financiallyConsistent)
        assertFalse(parsed.items.any { it.name.contains("ušetrili", ignoreCase = true) })
        assertFalse(validation.requiresReview)
        assertTrue(validation.confidence >= 90)
    }

    @Test
    fun `large item total mismatch always requires review`() {
        val lines = listOf(
            "LIDL", "Dojčenská voda", "4 ks x 0,39", "1,56", "NA ÚHRADU", "31,94",
        ).mapIndexed { index, text -> OcrLine(text, 0, index * 20, 500, index * 20 + 18) }
        val parsed = GenericDocumentParser().parse(lines)
        val validation = ValidationEngine().validate(parsed, lines.joinToString("\n") { it.text })

        assertTrue(validation.requiresReview)
        assertTrue(validation.confidence < 70)
    }
}
