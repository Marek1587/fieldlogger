package sk.doklady.ui

import android.util.Size
import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import sk.doklady.capture.LiveQuality
import sk.doklady.capture.LiveScannerState
import sk.doklady.capture.MultiFrameAnalyzer
import sk.doklady.capture.MultiFrameCaptureSnapshot
import java.util.concurrent.Executor
import java.util.concurrent.Executors

@Composable
fun CameraScanner(
    onBack: () -> Unit,
    onCapture: (ImageCapture, Executor, MultiFrameCaptureSnapshot) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val mainExecutor = remember(context) { ContextCompat.getMainExecutor(context) }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }
    var scannerState by remember { mutableStateOf(LiveScannerState()) }
    var captureRequested by remember { mutableStateOf(false) }
    var snapshotSubmitted by remember { mutableStateOf(false) }
    val analyzer = remember(context) {
        MultiFrameAnalyzer(
            context = context,
            onState = { state -> mainExecutor.execute { scannerState = state } },
            onAutoCaptureReady = { mainExecutor.execute { captureRequested = true } },
        )
    }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setJpegQuality(100)
            .build()
    }
    val imageAnalysis = remember {
        ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setTargetResolution(Size(1920, 1080))
            .build()
            .also { it.setAnalyzer(analysisExecutor, analyzer) }
    }
    val cameraProviderFuture = remember { ProcessCameraProvider.getInstance(context) }

    LaunchedEffect(captureRequested) {
        if (!captureRequested || snapshotSubmitted) return@LaunchedEffect
        analyzer.requestCapture()
        delay(400)
        snapshotSubmitted = true
        onCapture(imageCapture, mainExecutor, analyzer.snapshot())
    }

    DisposableEffect(lifecycleOwner) {
        onDispose {
            imageAnalysis.clearAnalyzer()
            if (cameraProviderFuture.isDone) cameraProviderFuture.get().unbindAll()
            analyzer.dispose(deleteSelected = !snapshotSubmitted)
            analysisExecutor.shutdown()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PreviewView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                    cameraProviderFuture.addListener({
                        val provider = cameraProviderFuture.get()
                        val preview = Preview.Builder().build().also { it.surfaceProvider = surfaceProvider }
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            lifecycleOwner,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageAnalysis,
                            imageCapture,
                        )
                    }, mainExecutor)
                }
            },
        )

        Box(
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.90f)
                .fillMaxHeight(0.76f)
                .border(
                    3.dp,
                    when (scannerState.quality) {
                        LiveQuality.EXCELLENT -> Color(0xFF58E6A9)
                        LiveQuality.GOOD -> Color(0xFFFFC857)
                        LiveQuality.WEAK -> Color.White.copy(alpha = 0.75f)
                    },
                    RoundedCornerShape(12.dp),
                ),
        )

        TextButton(
            onClick = onBack,
            enabled = !captureRequested,
            modifier = Modifier.align(Alignment.TopStart).padding(12.dp),
        ) { Text("Späť", color = Color.White) }

        Surface(
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 64.dp),
            color = Color.Black.copy(alpha = 0.68f),
            shape = RoundedCornerShape(14.dp),
        ) {
            Column(
                Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Text(
                    if (captureRequested) "Doklad zachytený" else scannerState.instruction,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                )
                Text(
                    when (scannerState.quality) {
                        LiveQuality.WEAK -> "Slabá kvalita"
                        LiveQuality.GOOD -> "Dobrá kvalita"
                        LiveQuality.EXCELLENT -> "Výborná kvalita"
                    },
                    color = when (scannerState.quality) {
                        LiveQuality.WEAK -> Color(0xFFFFC6C6)
                        LiveQuality.GOOD -> Color(0xFFFFD978)
                        LiveQuality.EXCELLENT -> Color(0xFF79E2B8)
                    },
                    style = MaterialTheme.typography.bodySmall,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Zábery ${scannerState.acceptedFrames}/5", color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Text("Frame-y ${scannerState.analyzedFrames}", color = Color.White, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 30.dp)
                .size(76.dp)
                .background(if (captureRequested) Color.Gray else Color.White, CircleShape)
                .border(7.dp, Color(0xFFB7C5BE), CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            TextButton(
                onClick = { if (!captureRequested) captureRequested = true },
                enabled = !captureRequested,
                modifier = Modifier.fillMaxSize(),
            ) { Text("") }
        }
    }
}
