package sk.doklady.export

import android.content.Context
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentItemEntity
import sk.doklady.data.SupplierEntity
import sk.doklady.data.VatSummaryEntity
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExportData(
    val documents: List<DocumentEntity>,
    val items: List<DocumentItemEntity>,
    val vat: List<VatSummaryEntity>,
    val suppliers: List<SupplierEntity>,
)

class XlsxExporter(private val context: Context? = null) {
    fun create(data: ExportData): File {
        val today = LocalDate.now().toString()
        val directory = File(requireNotNull(context).cacheDir, "exports").apply { mkdirs() }
        val file = File(directory, "Doklady_$today.xlsx")
        return createAt(data, file)
    }

    internal fun createAt(data: ExportData, file: File): File {
        file.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(file)).use { zip ->
            zip.text("[Content_Types].xml", contentTypes())
            zip.text("_rels/.rels", rootRelations())
            zip.text("xl/workbook.xml", workbook())
            zip.text("xl/_rels/workbook.xml.rels", workbookRelations())
            zip.text("xl/styles.xml", styles())
            zip.text("xl/worksheets/sheet1.xml", sheet(documentRows(data.documents)))
            zip.text("xl/worksheets/sheet2.xml", sheet(itemRows(data.documents, data.items)))
            zip.text("xl/worksheets/sheet3.xml", sheet(vatRows(data.vat)))
            zip.text("xl/worksheets/sheet4.xml", sheet(supplierRows(data.suppliers)))
        }
        require(file.isFile && file.length() > 0L) { "XLSX súbor sa nepodarilo vytvoriť." }
        return file
    }

    private fun documentRows(documents: List<DocumentEntity>): List<List<Cell>> = buildList {
        add(textRow("ID", "Typ", "Dodávateľ", "IČO", "Číslo dokladu", "Dátum", "Základ", "DPH", "Celkom", "Mena", "Confidence", "Stav"))
        documents.forEach { d -> add(listOf(
            Cell.Text(d.id), Cell.Text("Doklad"), Cell.Text(d.supplierName.orEmpty()), Cell.Text(d.supplierRegistrationId.orEmpty()),
            Cell.Text(d.documentNumber.orEmpty()), Cell.Text(d.purchaseDate ?: dateFromMillis(d.createdAt)),
            Cell.Number(money(d.netTotalCents)), Cell.Number(money(d.vatTotalCents)), Cell.Number(money(d.grossTotalCents)),
            Cell.Text(d.currency ?: "EUR"), Cell.Number(d.finalConfidence?.toString().orEmpty()), Cell.Text(d.status.name),
        )) }
    }

    private fun itemRows(documents: List<DocumentEntity>, items: List<DocumentItemEntity>): List<List<Cell>> {
        val byId = documents.associateBy { it.id }
        return buildList {
            add(textRow("Document ID", "Dátum", "Dodávateľ", "Číslo dokladu", "Kód položky", "EAN", "Názov položky", "Množstvo", "MJ", "Cena/MJ bez DPH", "Cena/MJ s DPH", "DPH %", "Celkom bez DPH", "Celkom s DPH", "Confidence"))
            items.forEach { item ->
                val d = byId[item.documentId] ?: return@forEach
                add(listOf(
                    Cell.Text(item.documentId), Cell.Text(d.purchaseDate ?: dateFromMillis(d.createdAt)), Cell.Text(d.supplierName.orEmpty()),
                    Cell.Text(d.documentNumber.orEmpty()), Cell.Text(item.productCode.orEmpty()), Cell.Text(item.ean.orEmpty()), Cell.Text(item.name),
                    Cell.Number(item.quantity.orEmpty()), Cell.Text(item.unit.orEmpty()), Cell.Number(money(item.unitPriceNetCents)),
                    Cell.Number(money(item.unitPriceGrossCents)), Cell.Number(item.vatRate.orEmpty()), Cell.Number(money(item.totalNetCents)),
                    Cell.Number(money(item.totalGrossCents)), Cell.Number(item.confidence.toString()),
                ))
            }
        }
    }

    private fun vatRows(rows: List<VatSummaryEntity>): List<List<Cell>> = buildList {
        add(textRow("Document ID", "DPH %", "Základ", "DPH", "Celkom"))
        rows.forEach { add(listOf(Cell.Text(it.documentId), Cell.Text(it.rate), Cell.Number(money(it.baseCents)), Cell.Number(money(it.vatCents)), Cell.Number(money(it.totalCents)))) }
    }

    private fun supplierRows(rows: List<SupplierEntity>): List<List<Cell>> = buildList {
        add(textRow("ID", "Dodávateľ", "IČO"))
        rows.forEach { add(listOf(Cell.Number(it.id.toString()), Cell.Text(it.name), Cell.Text(it.registrationId.orEmpty()))) }
    }

    private fun sheet(rows: List<List<Cell>>): String = buildString {
        append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>")
        rows.forEachIndexed { rowIndex, row ->
            append("<row r=\"${rowIndex + 1}\">")
            row.forEachIndexed { columnIndex, cell ->
                val ref = "${columnName(columnIndex)}${rowIndex + 1}"
                when (cell) {
                    is Cell.Text -> append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${escape(cell.value)}</t></is></c>")
                    is Cell.Number -> if (cell.value.toBigDecimalOrNull() != null) append("<c r=\"$ref\"><v>${cell.value}</v></c>")
                        else append("<c r=\"$ref\" t=\"inlineStr\"><is><t>${escape(cell.value)}</t></is></c>")
                }
            }
            append("</row>")
        }
        append("</sheetData></worksheet>")
    }

    private fun contentTypes() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet3.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet4.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>"""
    private fun rootRelations() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>"""
    private fun workbook() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="DOKLADY" sheetId="1" r:id="rId1"/><sheet name="POLOŽKY" sheetId="2" r:id="rId2"/><sheet name="DPH" sheetId="3" r:id="rId3"/><sheet name="DODÁVATELIA" sheetId="4" r:id="rId4"/></sheets></workbook>"""
    private fun workbookRelations() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/><Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet3.xml"/><Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet4.xml"/><Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""
    private fun styles() = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf/></cellStyleXfs><cellXfs count="1"><xf xfId="0"/></cellXfs></styleSheet>"""

    private fun textRow(vararg values: String) = values.map { Cell.Text(it) }
    private fun money(cents: Long?): String = cents?.let { "${it / 100}.${(kotlin.math.abs(it) % 100).toString().padStart(2, '0')}" }.orEmpty()
    private fun dateFromMillis(value: Long): String = Instant.ofEpochMilli(value).atZone(ZoneId.systemDefault()).toLocalDate().toString()
    private fun escape(value: String) = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
    private fun columnName(index: Int): String { var n = index + 1; var out = ""; while (n > 0) { n--; out = ('A'.code + n % 26).toChar() + out; n /= 26 }; return out }
    private fun ZipOutputStream.text(path: String, value: String) { putNextEntry(ZipEntry(path)); write(value.toByteArray(Charsets.UTF_8)); closeEntry() }
    private sealed interface Cell { data class Text(val value: String) : Cell; data class Number(val value: String) : Cell }
}
