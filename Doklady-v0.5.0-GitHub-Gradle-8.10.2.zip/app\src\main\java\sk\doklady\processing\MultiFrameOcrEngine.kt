package sk.doklady.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import sk.doklady.data.DocumentFrameEntity
import sk.doklady.data.OcrElementEntity
import java.io.File
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class FrameOcrDebug(
    val frameId: String,
    val rawText: String,
    val meanConfidence: Float?,
    val durationMs: Long,
)

data class UnifiedOcrResult(
    val strategy: String,
    val rawText: String,
    val lines: List<OcrLine>,
    val elements: List<OcrElementEntity>,
    val qualityScore: Int,
    val passCount: Int,
    val passSummaries: List<OcrPassSummary>,
    val financiallyConsistent: Boolean,
    val itemSumCents: Long?,
    val totalCents: Long?,
    val retryTriggered: Boolean,
    val consensusConfidence: Float?,
    val ocrConsistencyConfidence: Float?,
    val criticalConsensus: Float?,
    val conflictingTokens: Int,
    val frameResults: List<FrameOcrDebug>,
)

fun MultiPassOcrResult.asUnified(): UnifiedOcrResult = UnifiedOcrResult(
    strategy = strategy,
    rawText = rawText,
    lines = lines,
    elements = elements,
    qualityScore = qualityScore,
    passCount = passCount,
    passSummaries = passSummaries,
    financiallyConsistent = financiallyConsistent,
    itemSumCents = itemSumCents,
    totalCents = totalCents,
    retryTriggered = retryTriggered,
    consensusConfidence = null,
    ocrConsistencyConfidence = qualityScore / 100f,
    criticalConsensus = null,
    conflictingTokens = 0,
    frameResults = emptyList(),
)

class MultiFrameOcrEngine(private val context: Context) {
    fun recognize(documentId: String, frames: List<DocumentFrameEntity>): UnifiedOcrResult {
        require(frames.isNotEmpty()) { "Multi-frame OCR nemá žiadne vybrané frame-y." }
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val results = mutableListOf<FrameResult>()
        var secondPassUsed = false
        try {
            frames.take(MAX_OCR_FRAMES).forEach { frame ->
                val file = frame.filePath?.let(::File)
                if (file == null || !file.isFile) return@forEach
                val bounds = bitmapBounds(file)
                val started = System.currentTimeMillis()
                val text = Tasks.await(recognizer.process(InputImage.fromFilePath(context, Uri.fromFile(file))))
                val duration = System.currentTimeMillis() - started
                results += FrameResult(
                    frame = frame,
                    rawText = text.text.orEmpty(),
                    tokens = text.textBlocks.flatMap { block -> block.lines }.mapNotNull { line ->
                        val box = line.boundingBox ?: return@mapNotNull null
                        FrameToken(
                            frameId = frame.id,
                            text = line.text,
                            left = box.left.toFloat() / bounds.first,
                            top = box.top.toFloat() / bounds.second,
                            right = box.right.toFloat() / bounds.first,
                            bottom = box.bottom.toFloat() / bounds.second,
                            confidence = line.confidence,
                        )
                    },
                    meanConfidence = text.textBlocks.flatMap { it.lines }.mapNotNull { it.confidence }
                        .takeIf { it.isNotEmpty() }?.average()?.toFloat(),
                    durationMs = duration,
                )
            }

            require(results.size >= 2) { "Pre multi-frame OCR sa nepodarilo načítať aspoň dva frame-y." }
            var consensus = fuse(results)
            var parsed = GenericDocumentParser().parse(consensus.lines)
            var reconciliation = ReceiptReconciler.evaluate(parsed)
            val criticalLow = consensus.criticalConsensus < MINIMUM_CRITICAL_CONSENSUS
            if (!reconciliation.financiallyConsistent || criticalLow || parsed.grossTotalCents == null) {
                val best = results.maxBy { it.frame.qualityScore }
                val requestedRegions = buildSet {
                    if (parsed.supplier.isNullOrBlank() || parsed.purchaseDate == null || parsed.documentNumber == null) add(TargetRegion.HEADER)
                    if (parsed.items.isEmpty() || !reconciliation.financiallyConsistent) add(TargetRegion.ITEMS)
                    if (parsed.grossTotalCents == null || !reconciliation.financiallyConsistent) add(TargetRegion.TOTALS)
                }
                val targeted = targetedSecondPass(best, requestedRegions, recognizer)
                if (targeted != null) {
                    secondPassUsed = true
                    val targetedParsed = GenericDocumentParser().parse(targeted)
                    val targetedReconciliation = ReceiptReconciler.evaluate(targetedParsed)
                    if (targetedReconciliation.semanticScore > reconciliation.semanticScore) {
                        val elements = targeted.mapIndexed { index, line ->
                            OcrElementEntity(
                                documentId = documentId,
                                blockIndex = 0,
                                lineIndex = index,
                                elementIndex = 0,
                                text = line.text,
                                left = line.left,
                                top = line.top,
                                right = line.right,
                                bottom = line.bottom,
                                confidence = best.meanConfidence,
                            )
                        }
                        consensus = consensus.copy(
                            lines = targeted,
                            rawText = targeted.joinToString("\n") { it.text },
                            elements = elements,
                        )
                        parsed = targetedParsed
                        reconciliation = targetedReconciliation
                    }
                }
            }

            val quality = (
                frames.take(results.size).map { it.qualityScore }.average() * 0.30 +
                    consensus.consensusConfidence * 0.45 +
                    consensus.ocrConsistency * 0.25
                ).toFloat().coerceIn(0f, 1f)
            return UnifiedOcrResult(
                strategy = if (secondPassUsed) "MULTI_FRAME_CONSENSUS_TARGETED" else "MULTI_FRAME_CONSENSUS",
                rawText = consensus.rawText,
                lines = consensus.lines,
                elements = consensus.elements.map { it.copy(documentId = documentId) },
                qualityScore = (quality * 100).roundToInt(),
                passCount = results.size + if (secondPassUsed) 1 else 0,
                passSummaries = results.map { result ->
                    val frameParsed = GenericDocumentParser().parse(toOcrLines(result.tokens))
                    val frameMath = ReceiptReconciler.evaluate(frameParsed)
                    OcrPassSummary(
                        name = "FRAME_${result.frame.sequence}",
                        qualityScore = (result.frame.qualityScore * 100).roundToInt(),
                        financiallyConsistent = frameMath.financiallyConsistent,
                        itemSumCents = frameMath.itemSumCents,
                        totalCents = frameMath.totalCents,
                        differenceCents = frameMath.differenceCents,
                        lineCount = result.tokens.size,
                        characterCount = result.rawText.length,
                        meanConfidence = ((result.meanConfidence ?: 0f) * 100).roundToInt(),
                        durationMs = result.durationMs,
                    )
                },
                financiallyConsistent = reconciliation.financiallyConsistent,
                itemSumCents = reconciliation.itemSumCents,
                totalCents = reconciliation.totalCents,
                retryTriggered = secondPassUsed,
                consensusConfidence = consensus.consensusConfidence,
                ocrConsistencyConfidence = consensus.ocrConsistency,
                criticalConsensus = consensus.criticalConsensus,
                conflictingTokens = consensus.conflictingTokens,
                frameResults = results.map {
                    FrameOcrDebug(it.frame.id, it.rawText, it.meanConfidence, it.durationMs)
                },
            )
        } finally {
            recognizer.close()
        }
    }

    private fun fuse(results: List<FrameResult>): ConsensusResult {
        val clusters = mutableListOf<TokenCluster>()
        results.sortedByDescending { it.frame.qualityScore }.forEach { result ->
            result.tokens.forEach { token ->
                val cluster = clusters.filter { existing -> existing.members.none { it.frameId == token.frameId } }
                    .filter { geometryMatches(it.prototype, token) }
                    .maxByOrNull { textCompatibility(it.prototype.text, token.text) }
                if (cluster != null && textCompatibility(cluster.prototype.text, token.text) >= MINIMUM_TEXT_COMPATIBILITY) {
                    cluster.members += token
                } else clusters += TokenCluster(token, mutableListOf(token))
            }
        }

        val resolved = clusters.map { cluster -> resolveCluster(cluster, results) }
            .filter { it.text.isNotBlank() }
            .sortedWith(compareBy<ResolvedToken> { it.top }.thenBy { it.left })
        val lines = resolved.map { token ->
            OcrLine(token.text, (token.left * 1000).roundToInt(), (token.top * 2000).roundToInt(),
                (token.right * 1000).roundToInt(), (token.bottom * 2000).roundToInt())
        }
        val elements = resolved.mapIndexed { index, token ->
            OcrElementEntity(
                documentId = "",
                blockIndex = 0,
                lineIndex = index,
                elementIndex = 0,
                text = token.text,
                left = (token.left * 1000).roundToInt(),
                top = (token.top * 2000).roundToInt(),
                right = (token.right * 1000).roundToInt(),
                bottom = (token.bottom * 2000).roundToInt(),
                confidence = token.consensus,
            )
        }
        val weighted = resolved.map { token -> token.consensus to if (isCritical(token.text)) 2f else 1f }
        val consensus = weighted.takeIf { it.isNotEmpty() }
            ?.let { values -> values.sumOf { (it.first * it.second).toDouble() }.toFloat() / values.sumOf { it.second.toDouble() }.toFloat() }
            ?: 0f
        val critical = resolved.filter { isCritical(it.text) }.map { it.consensus }
            .takeIf { it.isNotEmpty() }?.average()?.toFloat() ?: consensus
        val conflicts = resolved.count { it.conflict }
        return ConsensusResult(
            rawText = lines.joinToString("\n") { it.text },
            lines = lines,
            elements = elements,
            consensusConfidence = consensus.coerceIn(0f, 1f),
            criticalConsensus = critical.coerceIn(0f, 1f),
            ocrConsistency = (1f - conflicts.toFloat() / max(1, resolved.size)).coerceIn(0f, 1f),
            conflictingTokens = conflicts,
        )
    }

    private fun resolveCluster(cluster: TokenCluster, results: List<FrameResult>): ResolvedToken {
        val outcome = ConsensusVote.resolve(
            votes = cluster.members.map { member ->
                val quality = results.first { it.frame.id == member.frameId }.frame.qualityScore
                TextVote(member.text, member.frameId, quality * (member.confidence ?: 0.72f))
            },
            totalFrames = results.size,
        )
        val winner = cluster.members.filter { equivalentForVote(it.text, outcome.text) }
        val representative = winner.maxBy { member ->
            results.first { it.frame.id == member.frameId }.frame.qualityScore * (member.confidence ?: 0.72f)
        }
        return ResolvedToken(
            text = representative.text,
            left = winner.map { it.left }.average().toFloat(),
            top = winner.map { it.top }.average().toFloat(),
            right = winner.map { it.right }.average().toFloat(),
            bottom = winner.map { it.bottom }.average().toFloat(),
            consensus = outcome.consensus,
            conflict = outcome.conflict,
        )
    }

    private fun targetedSecondPass(
        best: FrameResult,
        regions: Set<TargetRegion>,
        recognizer: com.google.mlkit.vision.text.TextRecognizer,
    ): List<OcrLine>? {
        if (regions.isEmpty()) return null
        val path = best.frame.filePath ?: return null
        val bitmap = BitmapFactory.decodeFile(path) ?: return null
        try {
            val retained = toOcrLines(best.tokens).filter { line ->
                val center = (line.top + line.bottom) / 2f / 2000f
                regions.none { center in it.start..it.end }
            }.toMutableList()
            regions.sortedBy { it.start }.forEach { region ->
                val top = (bitmap.height * region.start).roundToInt().coerceIn(0, bitmap.height - 1)
                val bottom = (bitmap.height * region.end).roundToInt().coerceIn(top + 1, bitmap.height)
                val crop = Bitmap.createBitmap(bitmap, 0, top, bitmap.width, bottom - top)
                val scale = (TARGETED_WIDTH.toFloat() / crop.width).coerceIn(1f, MAX_TARGETED_SCALE)
                val enlarged = if (scale > 1.02f) Bitmap.createScaledBitmap(
                    crop, (crop.width * scale).roundToInt(), (crop.height * scale).roundToInt(), true,
                ).also { crop.recycle() } else crop
                val sharpened = sharpen(enlarged)
                enlarged.recycle()
                val result = Tasks.await(recognizer.process(InputImage.fromBitmap(sharpened, 0)))
                result.textBlocks.flatMap { it.lines }.forEach { line ->
                    val box = line.boundingBox ?: return@forEach
                    val mappedTop = region.start + (box.top / scale) / bitmap.height
                    val mappedBottom = region.start + (box.bottom / scale) / bitmap.height
                    retained += OcrLine(
                        line.text,
                        (box.left / scale / bitmap.width * 1000).roundToInt(),
                        (mappedTop * 2000).roundToInt(),
                        (box.right / scale / bitmap.width * 1000).roundToInt(),
                        (mappedBottom * 2000).roundToInt(),
                    )
                }
                sharpened.recycle()
            }
            return retained.distinctBy { "${normalize(it.text)}:${it.top / 20}" }
                .sortedWith(compareBy<OcrLine> { it.top }.thenBy { it.left })
        } finally {
            bitmap.recycle()
        }
    }

    private fun sharpen(bitmap: Bitmap): Bitmap {
        val width = bitmap.width; val height = bitmap.height
        val source = IntArray(width * height); bitmap.getPixels(source, 0, width, 0, 0, width, height)
        val output = source.copyOf()
        for (y in 1 until height - 1) for (x in 1 until width - 1) {
            val index = y * width + x
            val center = Color.red(source[index])
            val value = (center * 5 - Color.red(source[index - 1]) - Color.red(source[index + 1]) -
                Color.red(source[index - width]) - Color.red(source[index + width])).coerceIn(0, 255)
            output[index] = Color.rgb(value, value, value)
        }
        return Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun geometryMatches(a: FrameToken, b: FrameToken): Boolean {
        val centerDistance = hypot((a.left + a.right - b.left - b.right) / 2f, (a.top + a.bottom - b.top - b.bottom) / 2f)
        val heightA = max(0.005f, a.bottom - a.top); val heightB = max(0.005f, b.bottom - b.top)
        return centerDistance <= max(0.035f, max(heightA, heightB) * 1.8f) && min(heightA, heightB) / max(heightA, heightB) >= 0.45f
    }

    private fun textCompatibility(a: String, b: String): Float {
        if (isStrictNumber(a) && isStrictNumber(b)) return 1f
        val first = normalize(a); val second = normalize(b)
        if (first.isEmpty() || second.isEmpty()) return 0f
        val distance = levenshtein(first, second)
        return 1f - distance.toFloat() / max(first.length, second.length)
    }

    private fun equivalentForVote(a: String, b: String): Boolean {
        if (isStrictNumber(a) || isStrictNumber(b)) return normalizeNumber(a) == normalizeNumber(b)
        return textCompatibility(a, b) >= 0.82f
    }

    private fun isCritical(value: String): Boolean = isStrictNumber(value) ||
        normalize(value).contains(Regex("CELKOM|UHRAD|DPH|DATUM|ICO|BLOK|TOTAL"))
    private fun isStrictNumber(value: String): Boolean = value.contains(Regex("[-+]?\\d+[,.]\\d{2}"))
    private fun normalizeNumber(value: String): String = value.replace('O', '0', true).replace('I', '1', true)
        .replace('l', '1').filter { it.isDigit() || it == ',' || it == '.' || it == '-' }.replace('.', ',')
    private fun normalize(value: String): String = GenericDocumentParser.normalized(value).filter(Char::isLetterOrDigit)

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1); current[0] = i + 1
            for (j in b.indices) current[j + 1] = minOf(
                current[j] + 1, previous[j + 1] + 1, previous[j] + if (a[i] == b[j]) 0 else 1,
            )
            previous = current
        }
        return previous[b.length]
    }

    private fun bitmapBounds(file: File): Pair<Float, Float> {
        val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, options)
        return max(1, options.outWidth).toFloat() to max(1, options.outHeight).toFloat()
    }

    private fun toOcrLines(tokens: List<FrameToken>): List<OcrLine> = tokens.sortedWith(
        compareBy<FrameToken> { it.top }.thenBy { it.left },
    ).map { token ->
        OcrLine(token.text, (token.left * 1000).roundToInt(), (token.top * 2000).roundToInt(),
            (token.right * 1000).roundToInt(), (token.bottom * 2000).roundToInt())
    }

    private data class FrameResult(
        val frame: DocumentFrameEntity,
        val rawText: String,
        val tokens: List<FrameToken>,
        val meanConfidence: Float?,
        val durationMs: Long,
    )
    private data class FrameToken(
        val frameId: String,
        val text: String,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val confidence: Float?,
    )
    private data class TokenCluster(val prototype: FrameToken, val members: MutableList<FrameToken>)
    private data class ResolvedToken(
        val text: String,
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val consensus: Float,
        val conflict: Boolean,
    )
    private data class ConsensusResult(
        val rawText: String,
        val lines: List<OcrLine>,
        val elements: List<OcrElementEntity>,
        val consensusConfidence: Float,
        val criticalConsensus: Float,
        val ocrConsistency: Float,
        val conflictingTokens: Int,
    )
    private enum class TargetRegion(val start: Float, val end: Float) {
        HEADER(0f, 0.30f), ITEMS(0.28f, 0.80f), TOTALS(0.72f, 1f),
    }

    companion object {
        private const val MAX_OCR_FRAMES = 8
        private const val MINIMUM_TEXT_COMPATIBILITY = 0.35f
        private const val MINIMUM_CRITICAL_CONSENSUS = 0.75f
        private const val TARGETED_WIDTH = 2_500
        private const val MAX_TARGETED_SCALE = 2.2f
    }
}

internal data class TextVote(val text: String, val frameId: String, val weight: Float)
internal data class VoteOutcome(val text: String, val consensus: Float, val conflict: Boolean)

internal object ConsensusVote {
    fun resolve(votes: List<TextVote>, totalFrames: Int): VoteOutcome {
        require(votes.isNotEmpty())
        val groups = mutableListOf<MutableList<TextVote>>()
        votes.forEach { vote ->
            val group = groups.firstOrNull { equivalent(it.first().text, vote.text) }
            if (group == null) groups += mutableListOf(vote) else group += vote
        }
        val winner = groups.maxBy { group -> group.sumOf { it.weight.toDouble() } }
        val representative = winner.maxBy { it.weight }
        val consensus = winner.map { it.frameId }.distinct().size.toFloat() / max(1, totalFrames)
        val strict = votes.any { strictNumber(it.text) }
        return VoteOutcome(
            text = representative.text,
            consensus = consensus.coerceIn(0f, 1f),
            conflict = groups.size > 1 && (strict || consensus < 0.80f),
        )
    }

    private fun equivalent(a: String, b: String): Boolean {
        if (strictNumber(a) || strictNumber(b)) return number(a) == number(b)
        val first = normalized(a); val second = normalized(b)
        if (first.isEmpty() || second.isEmpty()) return false
        return 1f - levenshtein(first, second).toFloat() / max(first.length, second.length) >= 0.82f
    }

    private fun strictNumber(value: String) = value.contains(Regex("[-+]?\\d+[,.]\\d{2}"))
    private fun number(value: String) = value.replace('O', '0', true).replace('I', '1', true)
        .replace('l', '1').filter { it.isDigit() || it in ",.-" }.replace('.', ',')
    private fun normalized(value: String) = GenericDocumentParser.normalized(value).filter(Char::isLetterOrDigit)
    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1); current[0] = i + 1
            for (j in b.indices) current[j + 1] = minOf(
                current[j] + 1, previous[j + 1] + 1, previous[j] + if (a[i] == b[j]) 0 else 1,
            )
            previous = current
        }
        return previous[b.length]
    }
}
