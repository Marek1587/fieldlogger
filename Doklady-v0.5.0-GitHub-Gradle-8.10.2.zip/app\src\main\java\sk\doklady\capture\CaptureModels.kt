package sk.doklady.capture

import java.io.File

data class NormalizedPoint(val x: Float, val y: Float)

data class FrameQualityMetrics(
    val documentDetected: Boolean,
    val polygon: List<NormalizedPoint>,
    val documentCoverage: Float,
    val coverageScore: Float,
    val perspectiveScore: Float,
    val sharpnessScore: Float,
    val exposureScore: Float,
    val contrastScore: Float,
    val glareScore: Float,
    val clippingScore: Float,
    val stabilityScore: Float,
    val qualityScore: Float,
)

data class SelectedCaptureFrame(
    val sequence: Int,
    val file: File,
    val capturedAt: Long,
    val metrics: FrameQualityMetrics,
)

data class MultiFrameCaptureSnapshot(
    val frameCount: Int,
    val selectedFrames: List<SelectedCaptureFrame>,
    val bestFrameScore: Float?,
    val averageFrameScore: Float?,
)

enum class LiveQuality { WEAK, GOOD, EXCELLENT }

data class LiveScannerState(
    val instruction: String = "Hľadám dokument…",
    val quality: LiveQuality = LiveQuality.WEAK,
    val analyzedFrames: Int = 0,
    val acceptedFrames: Int = 0,
    val stableForMs: Long = 0,
    val autoCaptureReady: Boolean = false,
    val metrics: FrameQualityMetrics? = null,
)
