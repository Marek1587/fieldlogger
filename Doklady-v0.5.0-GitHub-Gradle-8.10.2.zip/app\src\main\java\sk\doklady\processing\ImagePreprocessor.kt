package sk.doklady.processing

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class OcrImageVariant(val name: String, val file: File)

data class PreprocessedBundle(
    val primary: File,
    val variants: List<OcrImageVariant>,
    val cropApplied: Boolean,
    val scaleFactor: Float,
)

class ImagePreprocessor {
    fun process(source: File, primaryDestination: File): PreprocessedBundle {
        require(source.isFile && source.length() > 0L) { "Originálny obrázok chýba alebo je prázdny." }
        primaryDestination.parentFile?.mkdirs()

        val decoded = decode(source)
        val oriented = rotate(decoded, exifRotation(source))
        if (oriented !== decoded) decoded.recycle()

        val detected = detectDocumentBounds(oriented)
        val cropApplied = detected != null
        val cropped = detected?.let { Bitmap.createBitmap(oriented, it.left, it.top, it.width(), it.height()) } ?: oriented
        if (cropped !== oriented) oriented.recycle()

        val requestedScale = min(TARGET_WIDTH.toFloat() / cropped.width, MAX_HEIGHT.toFloat() / cropped.height)
            .coerceAtMost(MAX_UPSCALE)
        val scale = requestedScale.coerceAtMost(1f).takeIf { cropped.width > TARGET_WIDTH || cropped.height > MAX_HEIGHT }
            ?: requestedScale.coerceAtLeast(1f)
        val scaled = if (abs(scale - 1f) > 0.01f) {
            Bitmap.createScaledBitmap(cropped, max(1, (cropped.width * scale).toInt()), max(1, (cropped.height * scale).toInt()), true)
        } else cropped
        if (scaled !== cropped) cropped.recycle()

        val stem = primaryDestination.nameWithoutExtension.removeSuffix("_processed")
        val colorFile = File(primaryDestination.parentFile, "${stem}_ocr_color.jpg")
        saveJpeg(scaled, colorFile, 95)

        val enhanced = normalizeIlluminationAndContrast(scaled)
        scaled.recycle()
        saveJpeg(enhanced, primaryDestination, 96)

        val binaryFile = File(primaryDestination.parentFile, "${stem}_ocr_binary.png")
        val binary = adaptiveBinary(enhanced)
        savePng(binary, binaryFile)
        binary.recycle()
        enhanced.recycle()

        return PreprocessedBundle(
            primary = primaryDestination,
            variants = listOf(
                OcrImageVariant("ENHANCED_GRAY", primaryDestination),
                OcrImageVariant("COLOR_CROP", colorFile),
                OcrImageVariant("ADAPTIVE_BINARY", binaryFile),
            ),
            cropApplied = cropApplied,
            scaleFactor = scale,
        )
    }

    private fun decode(source: File): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Formát obrázka sa nepodarilo dekódovať." }
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > DECODE_LIMIT) sample *= 2
        return requireNotNull(BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })) {
            "Obrázok sa nepodarilo načítať."
        }
    }

    private fun detectDocumentBounds(bitmap: Bitmap): Rect? {
        val scale = (DETECTION_SIZE.toFloat() / max(bitmap.width, bitmap.height)).coerceAtMost(1f)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, max(1, (bitmap.width * scale).toInt()), max(1, (bitmap.height * scale).toInt()), true) else bitmap
        val width = small.width
        val height = small.height
        val pixels = IntArray(width * height)
        small.getPixels(pixels, 0, width, 0, 0, width, height)
        if (small !== bitmap) small.recycle()
        val gray = IntArray(pixels.size) { index -> luminance(pixels[index]) }
        val threshold = otsu(gray)
        val mask = BooleanArray(gray.size) { gray[it] >= threshold }
        val visited = BooleanArray(gray.size)
        val queue = IntArray(gray.size)
        var best: Component? = null

        for (start in mask.indices) {
            if (!mask[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            var minX = width
            var maxX = 0
            var minY = height
            var maxY = 0
            var sum = 0L
            while (head < tail) {
                val index = queue[head++]
                val x = index % width
                val y = index / width
                minX = min(minX, x); maxX = max(maxX, x); minY = min(minY, y); maxY = max(maxY, y)
                sum += gray[index]
                if (x > 0) add(index - 1, mask, visited, queue, tail).also { tail = it }
                if (x + 1 < width) add(index + 1, mask, visited, queue, tail).also { tail = it }
                if (y > 0) add(index - width, mask, visited, queue, tail).also { tail = it }
                if (y + 1 < height) add(index + width, mask, visited, queue, tail).also { tail = it }
            }
            val component = Component(tail, minX, minY, maxX, maxY, sum)
            if (best == null || component.area > best.area) best = component
        }

        val component = best ?: return null
        if (component.area < gray.size * MIN_COMPONENT_AREA) return null
        val insideMean = component.sum.toDouble() / component.area
        val totalMean = gray.average()
        val outsideMean = if (component.area < gray.size) (totalMean * gray.size - component.sum) / (gray.size - component.area) else totalMean
        if (insideMean - outsideMean < MIN_PAPER_CONTRAST) return null
        val boxWidth = component.maxX - component.minX + 1
        val boxHeight = component.maxY - component.minY + 1
        if (boxWidth >= width * 0.96 && boxHeight >= height * 0.96) return null

        val padX = max(2, (boxWidth * 0.025f).toInt())
        val padY = max(2, (boxHeight * 0.015f).toInt())
        val inverse = 1f / scale
        return Rect(
            max(0, ((component.minX - padX) * inverse).toInt()),
            max(0, ((component.minY - padY) * inverse).toInt()),
            min(bitmap.width, ((component.maxX + padX + 1) * inverse).toInt()),
            min(bitmap.height, ((component.maxY + padY + 1) * inverse).toInt()),
        ).takeIf { it.width() >= bitmap.width * 0.2 && it.height() >= bitmap.height * 0.25 }
    }

    private fun add(index: Int, mask: BooleanArray, visited: BooleanArray, queue: IntArray, tail: Int): Int {
        if (!mask[index] || visited[index]) return tail
        visited[index] = true
        queue[tail] = index
        return tail + 1
    }

    private fun normalizeIlluminationAndContrast(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
        val columns = (width + BLOCK - 1) / BLOCK
        val rows = (height + BLOCK - 1) / BLOCK
        val backgrounds = IntArray(columns * rows)
        val histogram = IntArray(256)
        for (blockY in 0 until rows) for (blockX in 0 until columns) {
            histogram.fill(0)
            val left = blockX * BLOCK
            val top = blockY * BLOCK
            val right = min(width, left + BLOCK)
            val bottom = min(height, top + BLOCK)
            var count = 0
            for (y in top until bottom step 2) for (x in left until right step 2) {
                histogram[luminance(pixels[y * width + x])]++
                count++
            }
            var cumulative = 0
            val target = (count * 0.84f).toInt()
            var percentile = 230
            for (value in 0..255) {
                cumulative += histogram[value]
                if (cumulative >= target) { percentile = value; break }
            }
            backgrounds[blockY * columns + blockX] = percentile
        }
        for (y in 0 until height) {
            val gridY = y.toFloat() / BLOCK - 0.5f
            val y0 = gridY.toInt().coerceIn(0, rows - 1)
            val y1 = (y0 + 1).coerceAtMost(rows - 1)
            val fy = (gridY - gridY.toInt()).coerceIn(0f, 1f)
            for (x in 0 until width) {
                val gridX = x.toFloat() / BLOCK - 0.5f
                val x0 = gridX.toInt().coerceIn(0, columns - 1)
                val x1 = (x0 + 1).coerceAtMost(columns - 1)
                val fx = (gridX - gridX.toInt()).coerceIn(0f, 1f)
                val top = backgrounds[y0 * columns + x0] * (1 - fx) + backgrounds[y0 * columns + x1] * fx
                val bottom = backgrounds[y1 * columns + x0] * (1 - fx) + backgrounds[y1 * columns + x1] * fx
                val background = top * (1 - fy) + bottom * fy
                val gray = luminance(pixels[y * width + x])
                val value = (246f - (background - gray) * 1.55f).toInt().coerceIn(0, 255)
                pixels[y * width + x] = Color.rgb(value, value, value)
            }
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun adaptiveBinary(enhanced: Bitmap): Bitmap {
        val width = enhanced.width
        val height = enhanced.height
        val pixels = IntArray(width * height)
        enhanced.getPixels(pixels, 0, width, 0, 0, width, height)
        val gray = IntArray(pixels.size) { luminance(pixels[it]) }
        val threshold = otsu(gray).coerceIn(145, 225)
        for (index in pixels.indices) {
            val value = if (gray[index] < threshold) 0 else 255
            pixels[index] = Color.rgb(value, value, value)
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun otsu(gray: IntArray): Int {
        val histogram = IntArray(256)
        gray.forEach { histogram[it]++ }
        var totalSum = 0L
        histogram.indices.forEach { totalSum += it.toLong() * histogram[it] }
        var backgroundWeight = 0L
        var backgroundSum = 0L
        var bestVariance = -1.0
        var best = 127
        for (threshold in 0..255) {
            backgroundWeight += histogram[threshold]
            if (backgroundWeight == 0L) continue
            val foregroundWeight = gray.size - backgroundWeight
            if (foregroundWeight == 0L) break
            backgroundSum += threshold.toLong() * histogram[threshold]
            val meanBackground = backgroundSum.toDouble() / backgroundWeight
            val meanForeground = (totalSum - backgroundSum).toDouble() / foregroundWeight
            val variance = backgroundWeight.toDouble() * foregroundWeight * (meanBackground - meanForeground) * (meanBackground - meanForeground)
            if (variance > bestVariance) { bestVariance = variance; best = threshold }
        }
        return best
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun rotate(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(degrees.toFloat()) }, true)
    }

    private fun saveJpeg(bitmap: Bitmap, file: File, quality: Int) = FileOutputStream(file).use {
        check(bitmap.compress(Bitmap.CompressFormat.JPEG, quality, it)) { "OCR variant sa nepodarilo uložiť." }
    }

    private fun savePng(bitmap: Bitmap, file: File) = FileOutputStream(file).use {
        check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) { "OCR variant sa nepodarilo uložiť." }
    }

    private fun luminance(color: Int): Int = (Color.red(color) * 0.299f + Color.green(color) * 0.587f + Color.blue(color) * 0.114f).toInt()
    private data class Component(val area: Int, val minX: Int, val minY: Int, val maxX: Int, val maxY: Int, val sum: Long)

    companion object {
        private const val TARGET_WIDTH = 1_800
        private const val MAX_HEIGHT = 5_200
        private const val MAX_UPSCALE = 3.5f
        private const val DECODE_LIMIT = 5_500
        private const val DETECTION_SIZE = 520
        private const val MIN_COMPONENT_AREA = 0.08f
        private const val MIN_PAPER_CONTRAST = 16.0
        private const val BLOCK = 96
    }
}
