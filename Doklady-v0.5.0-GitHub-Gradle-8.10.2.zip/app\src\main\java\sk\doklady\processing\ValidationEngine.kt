package sk.doklady.processing

data class ValidationResult(val confidence: Int, val requiresReview: Boolean)

class ValidationEngine {
    fun validate(parsed: ParsedDocument, rawText: String): ValidationResult {
        var score = 10
        if (rawText.length >= 30) score += 10
        if (!parsed.supplier.isNullOrBlank()) score += 12
        if (parsed.purchaseDate != null) score += 8
        if (parsed.grossTotalCents != null) score += 18
        if (parsed.items.isNotEmpty()) score += 12
        if (parsed.items.size >= 3) score += 5
        val reconciliation = ReceiptReconciler.evaluate(parsed)
        score += when {
            reconciliation.financiallyConsistent -> 25
            reconciliation.differenceCents == null -> -20
            reconciliation.differenceCents <= 5 -> 12
            reconciliation.differenceCents <= 20 -> 0
            else -> -25
        }
        score = score.coerceIn(0, 100)
        val arithmeticRequiresReview = parsed.items.size >= 2 && !reconciliation.financiallyConsistent
        return ValidationResult(
            confidence = score,
            requiresReview = score < 70 || parsed.grossTotalCents == null || arithmeticRequiresReview,
        )
    }
}
