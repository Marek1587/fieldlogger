package sk.doklady.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.io.File
import java.io.FileOutputStream
import java.util.ArrayDeque
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

class MultiFrameAnalyzer(
    context: Context,
    private val onState: (LiveScannerState) -> Unit,
    private val onAutoCaptureReady: () -> Unit,
    private val config: QualityConfiguration = QualityConfiguration(),
) : ImageAnalysis.Analyzer {
    private val sessionDir = File(context.cacheDir, "capture/${UUID.randomUUID()}").apply { mkdirs() }
    private val rolling = ArrayDeque<FrameObservation>()
    private val selected = mutableListOf<SelectedCaptureFrame>()
    private var analyzedFrames = 0
    private var sequence = 0
    private var lastAnalyzedAt = 0L
    private var stableSince: Long? = null
    private var previousPolygon: List<NormalizedPoint>? = null
    @Volatile private var captureRequested = false
    private var autoNotified = false

    override fun analyze(image: ImageProxy) {
        val now = System.currentTimeMillis()
        try {
            if (now - lastAnalyzedAt < config.analysisIntervalMs) return
            lastAnalyzedAt = now
            analyzedFrames++
            sequence++

            val sampled = sampleLuma(image)
            val detection = detectDocument(sampled)
            val stability = calculateStability(detection.polygon, now)
            val metrics = score(sampled, detection, stability)
            val observation = FrameObservation(sequence, now, metrics)
            rolling.addLast(observation)
            while (rolling.size > config.rollingBufferSize) rolling.removeFirst()

            if (metrics.documentDetected && metrics.sharpnessScore >= config.minimumSharpness &&
                metrics.qualityScore >= config.minimumAcceptedQuality
            ) {
                considerForTopFrames(image, observation)
            }

            val stableFor = stableSince?.let { now - it } ?: 0L
            val ready = !captureRequested && !autoNotified && analyzedFrames >= config.minimumAnalyzedFrames &&
                selected.size >= config.minimumOcrFrames && stableFor >= config.autoCaptureStableMs &&
                metrics.qualityScore >= config.autoCaptureQuality && metrics.glareScore <= config.maximumAutoGlare &&
                metrics.clippingScore <= 0.05f
            val state = LiveScannerState(
                instruction = instruction(metrics, stableFor),
                quality = when {
                    metrics.qualityScore >= 0.86f -> LiveQuality.EXCELLENT
                    metrics.qualityScore >= 0.62f -> LiveQuality.GOOD
                    else -> LiveQuality.WEAK
                },
                analyzedFrames = analyzedFrames,
                acceptedFrames = selected.size,
                stableForMs = stableFor,
                autoCaptureReady = ready,
                metrics = metrics,
            )
            onState(state)
            if (ready) {
                autoNotified = true
                onAutoCaptureReady()
            }
        } finally {
            image.close()
        }
    }

    @Synchronized
    fun requestCapture() {
        captureRequested = true
    }

    @Synchronized
    fun snapshot(): MultiFrameCaptureSnapshot {
        captureRequested = true
        val frames = selected.sortedByDescending { it.metrics.qualityScore }.take(config.maximumOcrFrames)
        return MultiFrameCaptureSnapshot(
            frameCount = analyzedFrames,
            selectedFrames = frames,
            bestFrameScore = frames.maxOfOrNull { it.metrics.qualityScore },
            averageFrameScore = frames.map { it.metrics.qualityScore }.takeIf { it.isNotEmpty() }?.average()?.toFloat(),
        )
    }

    @Synchronized
    fun dispose(deleteSelected: Boolean) {
        if (deleteSelected) selected.forEach { it.file.delete() }
        rolling.clear()
        selected.clear()
        if (deleteSelected) sessionDir.delete()
    }

    @Synchronized
    private fun considerForTopFrames(image: ImageProxy, observation: FrameObservation) {
        val metrics = observation.metrics
        val duplicate = selected.indexOfFirst { frame ->
            polygonDistance(frame.metrics.polygon, metrics.polygon) < config.minimumPolygonDiversity &&
                abs(frame.capturedAt - observation.capturedAt) < config.minimumTemporalDiversityMs
        }
        if (duplicate >= 0 && selected[duplicate].metrics.qualityScore >= metrics.qualityScore) return
        if (duplicate < 0 && selected.size >= config.topFrameCapacity &&
            metrics.qualityScore <= selected.minOf { it.metrics.qualityScore }
        ) return

        val file = File(sessionDir, "frame_${observation.sequence}.jpg")
        saveRectifiedFrame(image, metrics.polygon, file)
        val frame = SelectedCaptureFrame(observation.sequence, file, observation.capturedAt, metrics)
        if (duplicate >= 0) {
            selected[duplicate].file.delete()
            selected[duplicate] = frame
        } else selected += frame
        while (selected.size > config.topFrameCapacity) {
            val worst = selected.minBy { it.metrics.qualityScore }
            worst.file.delete()
            selected.remove(worst)
        }
    }

    private fun sampleLuma(image: ImageProxy): SampledLuma {
        val width = image.width
        val height = image.height
        val step = max(1, max(width, height) / config.analysisGridSize)
        val sampledWidth = (width + step - 1) / step
        val sampledHeight = (height + step - 1) / step
        val values = IntArray(sampledWidth * sampledHeight)
        val plane = image.planes[0]
        val buffer = plane.buffer
        var target = 0
        for (y in 0 until height step step) {
            val row = y * plane.rowStride
            for (x in 0 until width step step) {
                values[target++] = buffer.get(row + x * plane.pixelStride).toInt() and 0xFF
            }
        }
        return SampledLuma(sampledWidth, sampledHeight, values, step, width, height)
    }

    private fun detectDocument(sample: SampledLuma): Detection {
        val histogram = IntArray(256)
        sample.values.forEach { histogram[it]++ }
        val threshold = max(135, otsu(histogram, sample.values.size))
        val mask = BooleanArray(sample.values.size) { sample.values[it] >= threshold }
        val visited = BooleanArray(mask.size)
        val queue = IntArray(mask.size)
        var bestIndices = IntArray(0)

        for (start in mask.indices) {
            if (!mask[start] || visited[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            visited[start] = true
            while (head < tail) {
                val index = queue[head++]
                val x = index % sample.width
                val y = index / sample.width
                fun add(candidate: Int) {
                    if (mask[candidate] && !visited[candidate]) {
                        visited[candidate] = true
                        queue[tail++] = candidate
                    }
                }
                if (x > 0) add(index - 1)
                if (x + 1 < sample.width) add(index + 1)
                if (y > 0) add(index - sample.width)
                if (y + 1 < sample.height) add(index + sample.width)
            }
            if (tail > bestIndices.size) bestIndices = queue.copyOf(tail)
        }

        if (bestIndices.size < sample.values.size * 0.08f) return Detection(false, emptyList(), 0f, 0f, 1f)
        var tl = bestIndices.first(); var tr = tl; var br = tl; var bl = tl
        bestIndices.forEach { index ->
            val x = index % sample.width
            val y = index / sample.width
            fun sx(i: Int) = i % sample.width
            fun sy(i: Int) = i / sample.width
            if (x + y < sx(tl) + sy(tl)) tl = index
            if (x - y > sx(tr) - sy(tr)) tr = index
            if (x + y > sx(br) + sy(br)) br = index
            if (x - y < sx(bl) - sy(bl)) bl = index
        }
        val polygon = listOf(tl, tr, br, bl).map { index ->
            NormalizedPoint(
                x = (index % sample.width).toFloat() / max(1, sample.width - 1),
                y = (index / sample.width).toFloat() / max(1, sample.height - 1),
            )
        }
        val area = polygonArea(polygon)
        val rectangularity = (bestIndices.size.toFloat() / max(1f, area * sample.values.size)).coerceIn(0f, 1f)
        val perspective = perspectiveScore(polygon) * rectangularity.pow(0.25f)
        val clipping = if (polygon.any { it.x < 0.015f || it.x > 0.985f || it.y < 0.015f || it.y > 0.985f }) 1f else 0f
        return Detection(area in 0.10f..0.98f, polygon, area, perspective, clipping)
    }

    private fun calculateStability(polygon: List<NormalizedPoint>, now: Long): Float {
        if (polygon.size != 4) {
            previousPolygon = null
            stableSince = null
            return 0f
        }
        val previous = previousPolygon
        previousPolygon = polygon
        if (previous == null) {
            stableSince = null
            return 0.2f
        }
        val translation = polygonDistance(previous, polygon)
        val previousArea = polygonArea(previous)
        val area = polygonArea(polygon)
        val scaleChange = abs(area - previousArea) / max(0.01f, previousArea)
        val previousAngle = edgeAngle(previous[0], previous[1])
        val angle = edgeAngle(polygon[0], polygon[1])
        val rotation = abs(angle - previousAngle).coerceAtMost(PI.toFloat()) / PI.toFloat()
        val score = exp(-(translation * 22f + scaleChange * 6f + rotation * 8f)).coerceIn(0f, 1f)
        if (score >= config.stableScoreThreshold) {
            if (stableSince == null) stableSince = now
        } else stableSince = null
        return score
    }

    private fun score(sample: SampledLuma, detection: Detection, stability: Float): FrameQualityMetrics {
        if (!detection.detected) return FrameQualityMetrics(
            false, detection.polygon, detection.coverage, 0f, detection.perspective,
            sharpness(sample), exposure(sample.values), contrast(sample.values), glare(sample.values),
            detection.clipping, stability, 0f,
        )
        val sharpness = sharpness(sample)
        val exposure = exposure(sample.values)
        val contrast = contrast(sample.values)
        val glare = glare(sample.values)
        val coverage = coverageScore(detection.coverage)
        val base =
            sharpness.coerceAtLeast(0.05f).pow(config.sharpnessWeight) *
                coverage.coerceAtLeast(0.05f).pow(config.coverageWeight) *
                detection.perspective.coerceAtLeast(0.05f).pow(config.perspectiveWeight) *
                exposure.coerceAtLeast(0.05f).pow(config.exposureWeight) *
                contrast.coerceAtLeast(0.05f).pow(config.contrastWeight) *
                stability.coerceAtLeast(0.20f).pow(config.stabilityWeight)
        val quality = (base - glare * config.glarePenalty - detection.clipping * config.clippingPenalty).coerceIn(0f, 1f)
        return FrameQualityMetrics(
            true, detection.polygon, detection.coverage, coverage, detection.perspective,
            sharpness, exposure, contrast, glare, detection.clipping, stability, quality,
        )
    }

    private fun sharpness(sample: SampledLuma): Float {
        var sum = 0.0
        var sumSquares = 0.0
        var count = 0
        for (y in 1 until sample.height - 1) for (x in 1 until sample.width - 1) {
            val center = sample.values[y * sample.width + x]
            val laplacian = 4 * center - sample.values[y * sample.width + x - 1] -
                sample.values[y * sample.width + x + 1] - sample.values[(y - 1) * sample.width + x] -
                sample.values[(y + 1) * sample.width + x]
            sum += laplacian
            sumSquares += laplacian.toDouble() * laplacian
            count++
        }
        if (count == 0) return 0f
        val variance = sumSquares / count - (sum / count) * (sum / count)
        return (1.0 - exp(-variance / 420.0)).toFloat().coerceIn(0f, 1f)
    }

    private fun exposure(values: IntArray): Float {
        val mean = values.average().toFloat()
        val shadows = values.count { it < 25 }.toFloat() / values.size
        val highlights = values.count { it > 250 }.toFloat() / values.size
        return (1f - abs(mean - 170f) / 150f - shadows * 0.7f - highlights * 0.8f).coerceIn(0f, 1f)
    }

    private fun contrast(values: IntArray): Float {
        val mean = values.average()
        val deviation = sqrt(values.sumOf { (it - mean) * (it - mean) } / values.size).toFloat()
        return (deviation / 68f).coerceIn(0f, 1f)
    }

    private fun glare(values: IntArray): Float = (values.count { it >= 250 }.toFloat() / values.size * 5f).coerceIn(0f, 1f)

    private fun coverageScore(coverage: Float): Float = when {
        coverage in 0.60f..0.90f -> 1f
        coverage < 0.60f -> (coverage / 0.60f).coerceIn(0f, 1f)
        else -> ((1f - coverage) / 0.10f).coerceIn(0f, 1f)
    }

    private fun instruction(metrics: FrameQualityMetrics, stableFor: Long): String = when {
        !metrics.documentDetected -> "Hľadám dokument…"
        metrics.documentCoverage < 0.55f -> "Priblížte dokument"
        metrics.documentCoverage > 0.92f || metrics.clippingScore > 0.1f -> "Oddiaľte telefón"
        metrics.perspectiveScore < 0.65f -> "Držte telefón rovno"
        metrics.exposureScore < 0.55f -> "Viac svetla"
        metrics.glareScore > 0.18f -> "Odstráňte odlesk"
        metrics.sharpnessScore < config.minimumSharpness -> "Držte stabilne"
        stableFor < config.autoCaptureStableMs -> "Držte stabilne"
        selected.size < config.minimumOcrFrames -> "Získavam kvalitné zábery ${selected.size}/${config.minimumOcrFrames}"
        else -> "Dokument pripravený"
    }

    private fun saveRectifiedFrame(image: ImageProxy, polygon: List<NormalizedPoint>, file: File) {
        val width = image.width
        val height = image.height
        val plane = image.planes[0]
        val buffer = plane.buffer
        val source = IntArray(width * height)
        for (y in 0 until height) {
            val row = y * plane.rowStride
            for (x in 0 until width) {
                val value = buffer.get(row + x * plane.pixelStride).toInt() and 0xFF
                source[y * width + x] = Color.rgb(value, value, value)
            }
        }
        val points = polygon.takeIf { it.size == 4 } ?: listOf(
            NormalizedPoint(0f, 0f), NormalizedPoint(1f, 0f), NormalizedPoint(1f, 1f), NormalizedPoint(0f, 1f),
        )
        val px = points.map { NormalizedPoint(it.x * (width - 1), it.y * (height - 1)) }
        var outWidth = max(distance(px[0], px[1]), distance(px[3], px[2])).toInt().coerceAtLeast(1)
        var outHeight = max(distance(px[0], px[3]), distance(px[1], px[2])).toInt().coerceAtLeast(1)
        val resize = min(1f, config.maximumSavedDimension.toFloat() / max(outWidth, outHeight))
        outWidth = max(1, (outWidth * resize).toInt())
        outHeight = max(1, (outHeight * resize).toInt())
        val output = IntArray(outWidth * outHeight)
        for (y in 0 until outHeight) {
            val v = if (outHeight == 1) 0f else y.toFloat() / (outHeight - 1)
            val left = lerp(px[0], px[3], v)
            val right = lerp(px[1], px[2], v)
            for (x in 0 until outWidth) {
                val u = if (outWidth == 1) 0f else x.toFloat() / (outWidth - 1)
                val point = lerp(left, right, u)
                val sx = point.x.toInt().coerceIn(0, width - 1)
                val sy = point.y.toInt().coerceIn(0, height - 1)
                output[y * outWidth + x] = source[sy * width + sx]
            }
        }
        var bitmap = Bitmap.createBitmap(output, outWidth, outHeight, Bitmap.Config.ARGB_8888)
        val rotation = image.imageInfo.rotationDegrees
        if (rotation != 0) {
            val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply { postRotate(rotation.toFloat()) }, true)
            bitmap.recycle()
            bitmap = rotated
        }
        FileOutputStream(file).use { outputStream ->
            check(bitmap.compress(Bitmap.CompressFormat.JPEG, 96, outputStream)) { "Frame sa nepodarilo uložiť." }
        }
        bitmap.recycle()
    }

    private fun perspectiveScore(points: List<NormalizedPoint>): Float {
        if (points.size != 4) return 0f
        val top = distance(points[0], points[1]); val bottom = distance(points[3], points[2])
        val left = distance(points[0], points[3]); val right = distance(points[1], points[2])
        val oppositeRatio = min(top, bottom) / max(0.001f, max(top, bottom)) *
            (min(left, right) / max(0.001f, max(left, right)))
        val corner = angleScore(points[3], points[0], points[1])
        return (oppositeRatio * 0.65f + corner * 0.35f).coerceIn(0f, 1f)
    }

    private fun angleScore(a: NormalizedPoint, b: NormalizedPoint, c: NormalizedPoint): Float {
        val abx = a.x - b.x; val aby = a.y - b.y; val cbx = c.x - b.x; val cby = c.y - b.y
        val denominator = max(0.0001f, hypot(abx, aby) * hypot(cbx, cby))
        val angle = acos(((abx * cbx + aby * cby) / denominator).coerceIn(-1f, 1f))
        return (1f - abs(angle - PI.toFloat() / 2f) / (PI.toFloat() / 2f)).coerceIn(0f, 1f)
    }

    private fun polygonArea(points: List<NormalizedPoint>): Float {
        if (points.size < 3) return 0f
        var area = 0f
        points.indices.forEach { index ->
            val next = points[(index + 1) % points.size]
            area += points[index].x * next.y - next.x * points[index].y
        }
        return abs(area) / 2f
    }

    private fun polygonDistance(a: List<NormalizedPoint>, b: List<NormalizedPoint>): Float {
        if (a.size != b.size || a.isEmpty()) return 1f
        return a.indices.sumOf { distance(a[it], b[it]).toDouble() }.toFloat() / a.size
    }

    private fun edgeAngle(a: NormalizedPoint, b: NormalizedPoint): Float = kotlin.math.atan2(b.y - a.y, b.x - a.x)
    private fun distance(a: NormalizedPoint, b: NormalizedPoint): Float = hypot(a.x - b.x, a.y - b.y)
    private fun lerp(a: NormalizedPoint, b: NormalizedPoint, amount: Float) =
        NormalizedPoint(a.x + (b.x - a.x) * amount, a.y + (b.y - a.y) * amount)

    private fun otsu(histogram: IntArray, count: Int): Int {
        var total = 0L
        histogram.indices.forEach { total += it.toLong() * histogram[it] }
        var backgroundWeight = 0L; var backgroundSum = 0L; var bestVariance = -1.0; var best = 150
        for (threshold in histogram.indices) {
            backgroundWeight += histogram[threshold]
            if (backgroundWeight == 0L) continue
            val foregroundWeight = count - backgroundWeight
            if (foregroundWeight == 0L) break
            backgroundSum += threshold.toLong() * histogram[threshold]
            val bg = backgroundSum.toDouble() / backgroundWeight
            val fg = (total - backgroundSum).toDouble() / foregroundWeight
            val variance = backgroundWeight.toDouble() * foregroundWeight * (bg - fg) * (bg - fg)
            if (variance > bestVariance) { bestVariance = variance; best = threshold }
        }
        return best
    }

    private data class SampledLuma(
        val width: Int,
        val height: Int,
        val values: IntArray,
        val step: Int,
        val sourceWidth: Int,
        val sourceHeight: Int,
    )
    private data class Detection(
        val detected: Boolean,
        val polygon: List<NormalizedPoint>,
        val coverage: Float,
        val perspective: Float,
        val clipping: Float,
    )
    private data class FrameObservation(val sequence: Int, val capturedAt: Long, val metrics: FrameQualityMetrics)
}

data class QualityConfiguration(
    val analysisIntervalMs: Long = 130L,
    val analysisGridSize: Int = 180,
    val rollingBufferSize: Int = 24,
    val topFrameCapacity: Int = 8,
    val minimumOcrFrames: Int = 5,
    val maximumOcrFrames: Int = 6,
    val minimumAnalyzedFrames: Int = 15,
    val minimumSharpness: Float = 0.42f,
    val minimumAcceptedQuality: Float = 0.46f,
    val autoCaptureQuality: Float = 0.72f,
    val maximumAutoGlare: Float = 0.18f,
    val autoCaptureStableMs: Long = 750L,
    val stableScoreThreshold: Float = 0.82f,
    val minimumTemporalDiversityMs: Long = 160L,
    val minimumPolygonDiversity: Float = 0.006f,
    val maximumSavedDimension: Int = 1_900,
    val sharpnessWeight: Float = 0.28f,
    val coverageWeight: Float = 0.18f,
    val perspectiveWeight: Float = 0.14f,
    val exposureWeight: Float = 0.11f,
    val contrastWeight: Float = 0.11f,
    val stabilityWeight: Float = 0.18f,
    val glarePenalty: Float = 0.18f,
    val clippingPenalty: Float = 0.15f,
)
