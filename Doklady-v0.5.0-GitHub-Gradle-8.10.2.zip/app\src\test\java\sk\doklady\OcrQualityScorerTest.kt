package sk.doklady

import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.processing.OcrLine
import sk.doklady.processing.OcrQualityScorer

class OcrQualityScorerTest {
    @Test
    fun `receipt fields beat a noisy OCR pass`() {
        val receipt = listOf(
            "LIDL Slovenská republika",
            "Dátum 15.08.2026",
            "Dojčenská voda 1,56 EUR",
            "Smoothie Jahoda 4,58 EUR",
            "Základ 28,13 DPH 3,81",
            "NA ÚHRADU EUR 31,94",
        )
        val noise = listOf("| l 1", "--..", "S8?", "I I I", "qz")

        val receiptScore = OcrQualityScorer.score(receipt.joinToString("\n"), lines(receipt), 82)
        val noiseScore = OcrQualityScorer.score(noise.joinToString("\n"), lines(noise), 35)

        assertTrue(receiptScore >= 60)
        assertTrue(receiptScore > noiseScore + 30)
    }

    @Test
    fun `blank OCR receives zero`() {
        assertTrue(OcrQualityScorer.score("", emptyList(), 100) == 0)
    }

    private fun lines(values: List<String>) = values.mapIndexed { index, value ->
        OcrLine(value, 0, index * 30, 500, index * 30 + 24)
    }
}
