package sk.doklady

import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentItemEntity
import sk.doklady.data.DocumentStatus
import sk.doklady.data.ImageSource
import sk.doklady.export.ExportData
import sk.doklady.export.XlsxExporter
import java.io.File
import java.util.zip.ZipFile

class XlsxExporterTest {
    @Test
    fun `creates valid xlsx package with required sheets and item rows`() {
        val directory = createTempDir(prefix = "doklady-xlsx-")
        val output = File(directory, "test.xlsx")
        val document = DocumentEntity(
            id = "doc-1", status = DocumentStatus.PROCESSED, imageSource = ImageSource.GALLERY,
            originalImagePath = "original.jpg", originalDisplayName = "receipt.jpg", originalMimeType = "image/jpeg",
            createdAt = 1L, updatedAt = 1L, supplierName = "HORNBACH", purchaseDate = "2026-08-26",
            grossTotalCents = 6560, currency = "EUR", confidence = 90, itemCount = 1,
        )
        val item = DocumentItemEntity(documentId = "doc-1", position = 1, originalText = "OSB", name = "OSB doska", quantity = "4", unit = "KS", totalGrossCents = 6560)

        XlsxExporter().createAt(ExportData(listOf(document), listOf(item), emptyList(), emptyList()), output)

        assertTrue(output.length() > 0)
        ZipFile(output).use { zip ->
            val names = zip.entries().asSequence().map { it.name }.toSet()
            assertTrue("xl/workbook.xml" in names)
            assertTrue("xl/worksheets/sheet2.xml" in names)
            val workbook = zip.getInputStream(zip.getEntry("xl/workbook.xml")).bufferedReader().readText()
            val items = zip.getInputStream(zip.getEntry("xl/worksheets/sheet2.xml")).bufferedReader().readText()
            assertTrue(workbook.contains("POLOŽKY"))
            assertTrue(items.contains("OSB doska"))
        }
        directory.deleteRecursively()
    }
}
