package sk.doklady.work

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import sk.doklady.data.DocumentDao
import sk.doklady.data.DocumentStatus
import java.util.concurrent.TimeUnit

class DocumentWorkScheduler(context: Context) {
    private val workManager = WorkManager.getInstance(context.applicationContext)

    suspend fun enqueue(documentId: String, dao: DocumentDao) {
        val request = OneTimeWorkRequestBuilder<DocumentProcessingWorker>()
            .setInputData(Data.Builder().putString(DocumentProcessingWorker.DOCUMENT_ID, documentId).build())
            .addTag("document:$documentId")
            .addTag(PROCESSING_TAG)
            .build()
        dao.markQueued(documentId, request.id.toString(), System.currentTimeMillis())
        workManager.enqueueUniqueWork(
            QUEUE_NAME,
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            request,
        ).result.get()
    }

    suspend fun retry(documentId: String, dao: DocumentDao) = enqueue(documentId, dao)

    fun scheduleRecovery() {
        val periodic = PeriodicWorkRequestBuilder<QueueRecoveryWorker>(15, TimeUnit.MINUTES).build()
        workManager.enqueueUniquePeriodicWork(RECOVERY_NAME, androidx.work.ExistingPeriodicWorkPolicy.KEEP, periodic)
        workManager.enqueueUniqueWork(
            "$RECOVERY_NAME-now",
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<QueueRecoveryWorker>().build(),
        )
    }

    companion object {
        const val QUEUE_NAME = "document-processing-sequential-queue"
        const val PROCESSING_TAG = "document-processing"
        const val RECOVERY_NAME = "document-processing-recovery"
    }
}
