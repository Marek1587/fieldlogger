# StrechoStav Sketch pre Android 3.5.0

Offline-first nástroj pre pracovný tok:

`2D obrys → topologická sieť → typológia → parametrický 3D model → výkaz → rozsah prác → PDF`

## Sedem pracovných kariet

1. **Obrys** – ZBGIS ortofoto alebo jeden PDF/JPG podklad, freehand do 10 bodov, presná korekcia, pridanie bodu podľa `EdgeId`, editácia uzla alebo translácia hrany.
2. **Vnútorné línie** – korekcia bez vytvárania bodov či línií: blízke existujúce konce sa zlúčia, hrebene sa do 10° dorovnajú rovnobežne s obvodom a nárožia/úžľabia na 45° pri zmene dĺžky najviac 10 %.
3. **Typológia** – zamknuté XY; dlhé podržanie hrany mení iba `EdgeSemantic`. Tu sa pridávajú aj technické objekty, sklony a výškové kóty.
4. **3D model** – model z `FaceId` a rovín `z = ax + by + c`, nie z názvu strechy. Kóty nad OpenGL scénou používajú krok 50 mm a live preview.
5. **Výkaz výmer** – skutočné 3D plochy a 3D dĺžky s auditom podľa `FaceId`/`EdgeId`.
6. **Rozsah prác** – lokálny katalóg, automatické množstvá, dohľadateľný ručný override a editovateľné ceny.
7. **PDF** – deterministický lokálny renderer: dva izometrické pohľady, technický pôdorys, výkaz a rozpočet.

## Canonical RoofGraph

Schéma projektu 6 používa jediný zdroj geometrickej pravdy:

- `GraphNode(id, x, y, z, lockX, lockY, lockZ)`
- `GraphEdge(id, startNodeId, endNodeId, boundary, semanticRole, adjacentFaceIds, elevationZ)`
- `GraphFace(id, orderedNodeIds, holeNodeIdLoops, orderedEdgeIds, plane, slopeConstraint, elevationConstraints, componentId, hostFaceId)`
- tvrdé dĺžkové a všeobecné dimension constraints

ID zostávajú stabilné pri parametrickej zmene. Spoločný `NodeId` je jediný spoločný 3D bod všetkých incidentných plôch. Staré projekty sa automaticky migrujú; `RoofShape` sa uchováva iba ako legacy metadata a nový generátor ho nepoužíva.

## Presný univerzálny solver 3.1

- smer sklonu je jednoznačne `downhillDirection`; gradient roviny smeruje opačne,
- staré grafy so smerom interpretovaným ako „uphill“ sa pri načítaní automaticky invertujú,
- incidencie `Node–Face`, pevné výšky, bodové kóty, vpuste a nízke hrany sa riešia ako presné lineárne rovnice,
- presný audit hard constraints zostáva bez aproximácie a nekompatibilný systém označí ako chybu,
- 3D, bitmapový renderer, PDF a výkaz používajú až po neúspešnom presnom audite spoločný deterministický aproximačný režim; incidencie a ID hrán sa nemenia a odchýlka zostáva evidovaná v audite,
- podporované sú `RAKE`, `LOW_EDGE`, `ELEVATED_LOW_EDGE`, `STEP` a `OPENING_BOUNDARY`,
- schéma podporuje otvory plôch, sekundárny `RoofComponent`, hostiteľskú plochu a `DrainPointConstraint`,
- stenový pôdorys je oddelený od fyzickej hranice strechy,
- zánik hrebeňa, hrany, plochy alebo polvalbového rezu je explicitná topologická udalosť,
- kanonický JSON adaptér normalizuje mm/cm/m, stabilné ID a downhill sklony,
- komíny, strešné okná, výlezy a prestupy sú odvodené 3D telesá a nevlastnia topológiu strechy.

## Dve nezávislé 3D vykresľovacie cesty

- interaktívna obrazovka používa `GLSurfaceView`, OpenGL ES 3.0, VBO a GLSL `#version 300 es`, pričom zdrojové texty shaderov sú priamo v `Roof3DView.kt`,
- `RoofBitmapRenderer.kt` je samostatný Kotlin/Canvas renderer, ktorý vytvára deterministický `Bitmap` bez EGL alebo OpenGL kontextu,
- oba renderery čítajú rovnaký validovaný odvodený `RoofMesh`, takže nemenia topológiu ani výpočtový model,
- materiál je explicitnou vlastnosťou vrcholu: strecha zostáva antracitová s rotačnou svetelnou zmenou do 10 % a steny sú svetlobéžové bez zámeny materiálu pri otočení,
- vektorový nápis `STRECHOSTAV` sa vytvára priamo nad dvoma najväčšími strešnými plochami a používa ho OpenGL aj statický PDF renderer,
- obvodové 3D kóty sa premietajú podľa aktuálnej kamery; kliknutie otvorí 50 mm koliesko a priebežne volá parametrický solver bez zmeny incidencie,
- karta Rozsah prác používa statický bitmapový náhľad a PDF vkladá dve bitmapové izometrie bez potreby predchádzajúceho otvorenia 3D obrazovky.

## Mapy a offline režim

- používateľská mapová vrstva je **ZBGIS ortofoto** (WMS 1.3.0, EPSG:3857), bez API kľúča,
- PDF/JPG/PNG/WebP podklad funguje úplne offline,
- viditeľné ZBGIS dlaždice sa ukladajú do persistentnej cache konkrétneho projektu,
- Nominatim a Overpass sú iba voliteľné online vstupy pre adresu/GPS a import obrysu budovy,
- OSM mapa, OSM terén a trvalý nástroj Posun nie sú používateľské voľby,
- podržanie prsta 1 sekundu na voľnom mieste aktivuje dočasný posun; pinch zoomuje podklad aj geometriu.

## Zostavenie

Projekt nepotrebuje Google API secret:

```text
gradle :app:testDebugUnitTest :app:assembleDebug
```

Vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2. GitHub Actions workflow v `.github/workflows/build-apk.yml` zostaví najnovší ZIP zdrojového projektu. APK vznikne v:

`app/build/outputs/apk/debug/app-debug.apk`

## Presnosť

Geometria, 3D, výkaz, rozsah prác a PDF sa počítajú lokálne a deterministicky. Údaje odvodené iba z ortofotomapy sú orientačné; pred výrobou alebo realizáciou ich treba overiť meraním na stavbe.
