package sk.strechasketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.hypot

/** Clickable screen-space dimensions projected from the current OpenGL camera. */
class Roof3DDimensionOverlay(context: Context) : View(context) {
    var source: Roof3DView? = null
    var onDimensionClick: ((String) -> Unit)? = null
    private val hitBoxes = linkedMapOf<String, RectF>()
    private var pressedEdgeId: String? = null
    private val density = resources.displayMetrics.density.coerceAtLeast(1f)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(31, 108, 52)
        strokeWidth = 1.5f * density
        style = Paint.Style.STROKE
    }
    private val witnessPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 84, 91, 87)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 58, 37)
        textSize = 12f * density
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private val labelBackground = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(238, 255, 253, 246)
        style = Paint.Style.FILL
    }
    private val labelBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 122, 53)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }

    init {
        isClickable = true
        contentDescription = "Klikateľné parametrické kóty trojrozmerného modelu"
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hitBoxes.clear()
        source?.projectedDimensions()?.forEach { dimension ->
            val a = dimension.start
            val b = dimension.end
            if ((a.x < -100f && b.x < -100f) || (a.x > width + 100f && b.x > width + 100f) ||
                (a.y < -100f && b.y < -100f) || (a.y > height + 100f && b.y > height + 100f)
            ) return@forEach
            canvas.drawLine(dimension.witnessStart.x, dimension.witnessStart.y, a.x, a.y, witnessPaint)
            canvas.drawLine(dimension.witnessEnd.x, dimension.witnessEnd.y, b.x, b.y, witnessPaint)
            canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1f)
            val nx = -dy / length
            val ny = dx / length
            val tick = 5f * density
            canvas.drawLine(a.x - nx * tick, a.y - ny * tick, a.x + nx * tick, a.y + ny * tick, linePaint)
            canvas.drawLine(b.x - nx * tick, b.y - ny * tick, b.x + nx * tick, b.y + ny * tick, linePaint)

            val text = String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
            val centerX = (a.x + b.x) / 2f
            val centerY = (a.y + b.y) / 2f
            val paddingX = 8f * density
            val halfWidth = labelPaint.measureText(text) / 2f + paddingX
            val halfHeight = 14f * density
            val box = RectF(centerX - halfWidth, centerY - halfHeight, centerX + halfWidth, centerY + halfHeight)
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBackground)
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBorder)
            val baseline = centerY - (labelPaint.ascent() + labelPaint.descent()) / 2f
            canvas.drawText(text, centerX, baseline, labelPaint)
            hitBoxes[dimension.edgeId] = RectF(box).apply { inset(-5f * density, -5f * density) }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedEdgeId = hitBoxes.entries.lastOrNull { it.value.contains(event.x, event.y) }?.key
                return pressedEdgeId != null
            }
            MotionEvent.ACTION_UP -> {
                val edgeId = pressedEdgeId
                pressedEdgeId = null
                if (edgeId != null && hitBoxes[edgeId]?.contains(event.x, event.y) == true) {
                    performClick()
                    onDimensionClick?.invoke(edgeId)
                    return true
                }
            }
            MotionEvent.ACTION_CANCEL -> pressedEdgeId = null
        }
        return pressedEdgeId != null
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
