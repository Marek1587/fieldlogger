package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

data class ParametricEditResult(
    val applied: Boolean,
    val graph: RoofGraph,
    val issues: List<String> = emptyList()
)

object TopologyValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = RoofGraphValidator.validate(graph)

    fun sameIncidence(before: RoofGraph, after: RoofGraph): Boolean =
        before.nodes.keys == after.nodes.keys &&
            before.edges.keys == after.edges.keys &&
            before.faces.keys == after.faces.keys &&
            before.edges.all { (id, edge) ->
                after.edges[id]?.let { it.startNodeId == edge.startNodeId && it.endNodeId == edge.endNodeId } == true
            } &&
            before.faces.all { (id, face) ->
                after.faces[id]?.let {
                    it.orderedNodeIds == face.orderedNodeIds && it.orderedEdgeIds == face.orderedEdgeIds
                } == true
            }
}

object PlanConstraintSolver {
    fun setEdgeLength(graph: RoofGraph, edgeId: String, targetLengthM: Double): ParametricEditResult {
        val candidate = RoofGraphOperations.setEdgeLength(graph, edgeId, targetLengthM)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutým uzlom."))
        if (!TopologyValidator.sameIncidence(graph, candidate)) {
            return ParametricEditResult(false, graph, listOf("Parametrická zmena by zmenila topológiu."))
        }
        val issues = TopologyValidator.validate(candidate)
        if (issues.any { it.code in setOf("NON_FINITE_NODE", "ZERO_EDGE", "BROKEN_FACE_REFERENCE") }) {
            return ParametricEditResult(false, graph, issues.map { it.message })
        }
        val events = RoofTopologyEventDetector.detect(candidate)
        if (events.any { it.requiresExplicitRetopology }) {
            return ParametricEditResult(false, graph, events.map { it.message })
        }
        val hardConflicts = validateHardPlanConstraints(candidate)
        if (hardConflicts.isNotEmpty()) return ParametricEditResult(false, graph, hardConflicts)
        return ParametricEditResult(true, candidate)
    }

    fun setDimension(graph: RoofGraph, dimensionId: String, targetDistanceM: Double): ParametricEditResult {
        if (targetDistanceM !in 0.05..5000.0) return ParametricEditResult(false, graph, listOf("Rozmer je mimo povoleného rozsahu."))
        val constraint = graph.dimensions[dimensionId]
            ?: return ParametricEditResult(false, graph, listOf("Rozmer neexistuje."))
        val edgeA = graph.edges[constraint.supportAEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Prvá podpora rozmeru neexistuje."))
        val edgeB = graph.edges[constraint.supportBEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Druhá podpora rozmeru neexistuje."))
        val length = hypot(constraint.directionX, constraint.directionY)
        if (length < 1e-12) return ParametricEditResult(false, graph, listOf("Rozmer nemá platný smer."))
        val dx = constraint.directionX / length; val dy = constraint.directionY / length
        fun midpoint(edge: GraphEdge): Pair<Double, Double> {
            val a = graph.nodes.getValue(edge.startNodeId); val b = graph.nodes.getValue(edge.endNodeId)
            return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
        }
        val a = midpoint(edgeA); val b = midpoint(edgeB)
        val current = (b.first - a.first) * dx + (b.second - a.second) * dy
        val movingB = constraint.fixedSupportEdgeId != edgeB.id
        val movingEdge = if (movingB) edgeB else edgeA
        val delta = if (movingB) targetDistanceM - current else current - targetDistanceM
        val movingNodes = constraint.movingNodeIds.ifEmpty { setOf(movingEdge.startNodeId, movingEdge.endNodeId) }
        val positions = movingNodes.associateWith { id ->
            val node = graph.nodes[id] ?: return ParametricEditResult(false, graph, listOf("Pohyblivý uzol rozmeru neexistuje."))
            node.x + dx * delta to node.y + dy * delta
        }
        val moved = RoofGraphOperations.moveNodes(graph, positions)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutými uzlami."))
        val updated = moved.copy(dimensions = moved.dimensions + (dimensionId to constraint.copy(valueMm = targetDistanceM * 1000.0)))
        if (!TopologyValidator.sameIncidence(graph, updated)) return ParametricEditResult(false, graph, listOf("Zmena vyžaduje explicitnú zmenu topológie."))
        val conflicts = validateHardPlanConstraints(updated)
        if (conflicts.isNotEmpty()) return ParametricEditResult(false, graph, conflicts)
        return ParametricEditResult(true, updated)
    }

    private fun validateHardPlanConstraints(graph: RoofGraph): List<String> = buildList {
        graph.edgeLengthConstraints.values.filter { it.hard }.forEach { constraint ->
            val edge = graph.edges[constraint.edgeId] ?: return@forEach
            val a = graph.nodes[edge.startNodeId] ?: return@forEach
            val b = graph.nodes[edge.endNodeId] ?: return@forEach
            if (abs(hypot(b.x - a.x, b.y - a.y) - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer hrany ${edge.id} nie je splnený s presnosťou 0,5 mm.")
            }
        }
        graph.dimensions.values.filter { it.hard }.forEach { constraint ->
            val edgeA = graph.edges[constraint.supportAEdgeId] ?: return@forEach
            val edgeB = graph.edges[constraint.supportBEdgeId] ?: return@forEach
            val directionLength = hypot(constraint.directionX, constraint.directionY)
            if (directionLength < 1e-12) return@forEach
            fun midpoint(edge: GraphEdge): Pair<Double, Double> {
                val a = graph.nodes[edge.startNodeId] ?: return 0.0 to 0.0
                val b = graph.nodes[edge.endNodeId] ?: return 0.0 to 0.0
                return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
            }
            val a = midpoint(edgeA); val b = midpoint(edgeB)
            val measured = ((b.first - a.first) * constraint.directionX + (b.second - a.second) * constraint.directionY) / directionLength
            if (abs(measured - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer ${constraint.id} medzi podporami nie je splnený s presnosťou 0,5 mm.")
            }
        }
    }
}

object ParametricEditSolver {
    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double
    ): ParametricEditResult {
        val plan = PlanConstraintSolver.setEdgeLength(graph, edgeId, targetLengthM)
        if (!plan.applied) return plan
        val roof = RoofPlaneSolver.solveForRendering(plan.graph, wallHeightM, defaultSlopeDeg)
        if (roof.hasBlockingIssues) {
            val hardGeometryConflicts = roof.issues.filter { it.blocking && it.code != "AUTO_TOPOLOGY_REQUIRED" }
            if (hardGeometryConflicts.isNotEmpty()) {
                return ParametricEditResult(false, graph, hardGeometryConflicts.map { it.message })
            }
            return ParametricEditResult(true, plan.graph, roof.issues.map { it.message })
        }
        if (!TopologyValidator.sameIncidence(graph, roof.graph)) {
            return ParametricEditResult(false, graph, listOf("RoofPlaneSolver zmenil topologickú incidenciu."))
        }
        return ParametricEditResult(true, roof.graph, roof.issues.map { it.message })
    }
}
