package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Camera for deterministic CPU-rendered previews. No OpenGL context is used. */
data class RoofBitmapCamera(
    val yawDeg: Double = -35.0,
    val pitchDeg: Double = 28.0,
    val distance: Double = 4.8,
    val paddingFraction: Double = 0.09
)

/**
 * Standalone static 3D renderer for lists, exports and PDF documents.
 *
 * It consumes the same validated [RoofMesh] snapshot as the interactive
 * OpenGL view, but projects and shades it entirely through Kotlin + Canvas.
 * Therefore it works without creating, opening or capturing a GLSurfaceView.
 */
object RoofBitmapRenderer {
    private data class Projected(val x: Double, val y: Double, val depth: Double)
    private data class DrawTriangle(
        val a: Projected,
        val b: Projected,
        val c: Projected,
        val depth: Double,
        val color: Int
    )

    fun render(
        project: RoofProject,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera = RoofBitmapCamera(),
        backgroundColor: Int = Color.rgb(246, 247, 247)
    ): Bitmap {
        require(width in 64..4096 && height in 64..4096) { "Neplatná veľkosť statického 3D obrázka." }
        return renderMesh(RoofMeshBuilder.build(project), width, height, camera, backgroundColor)
    }

    internal fun renderMesh(
        mesh: RoofMesh,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera,
        backgroundColor: Int
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(backgroundColor)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(155, 160, 163)
            strokeWidth = max(0.9f, min(width, height) / 520f)
        }
        if (mesh.triangles.isEmpty()) {
            val message = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(78, 91, 82)
                textAlign = Paint.Align.CENTER
                textSize = min(width, height) * 0.045f
            }
            canvas.drawText("3D model nie je dostupný", width / 2f, height / 2f, message)
            canvas.drawRect(0.5f, 0.5f, width - 0.5f, height - 0.5f, frame)
            return bitmap
        }

        val yaw = Math.toRadians(camera.yawDeg)
        val pitch = Math.toRadians(camera.pitchDeg)
        fun rotate(x: Double, y: Double, z: Double): Triple<Double, Double, Double> {
            val yawX = x * cos(yaw) + z * sin(yaw)
            val yawZ = -x * sin(yaw) + z * cos(yaw)
            val pitchY = y * cos(pitch) - yawZ * sin(pitch)
            val pitchZ = y * sin(pitch) + yawZ * cos(pitch)
            return Triple(yawX, pitchY, pitchZ)
        }
        fun project(x: Double, y: Double, z: Double): Projected {
            val rotated = rotate(x, y, z)
            val perspective = camera.distance / (camera.distance - rotated.third).coerceAtLeast(0.35)
            return Projected(rotated.first * perspective, -rotated.second * perspective, rotated.third)
        }

        val projectedVertices = mutableListOf<Projected>()
        var offset = 0
        while (offset + 2 < mesh.triangles.size) {
            projectedVertices += project(
                mesh.triangles[offset].toDouble(),
                mesh.triangles[offset + 1].toDouble(),
                mesh.triangles[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.edges.size) {
            projectedVertices += project(
                mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.logoEdges.size) {
            projectedVertices += project(
                mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        val minX = projectedVertices.minOf { it.x }
        val maxX = projectedVertices.maxOf { it.x }
        val minY = projectedVertices.minOf { it.y }
        val maxY = projectedVertices.maxOf { it.y }
        val padding = min(width, height) * camera.paddingFraction.coerceIn(0.02, 0.25)
        val availableWidth = (width - 2.0 * padding).coerceAtLeast(1.0)
        val availableHeight = (height - 2.0 * padding).coerceAtLeast(1.0)
        val scale = min(availableWidth / max(1e-6, maxX - minX), availableHeight / max(1e-6, maxY - minY))
        fun sx(point: Projected) = (width / 2.0 + (point.x - (minX + maxX) / 2.0) * scale).toFloat()
        fun sy(point: Projected) = (height / 2.0 + (point.y - (minY + maxY) / 2.0) * scale).toFloat()

        val lightLength = sqrt(0.42 * 0.42 + 0.72 * 0.72 + 0.86 * 0.86)
        val light = Triple(-0.42 / lightLength, 0.72 / lightLength, 0.86 / lightLength)
        val triangles = mutableListOf<DrawTriangle>()
        var vertexOffset = 0
        while (vertexOffset + 8 < mesh.triangles.size) {
            val a = project(mesh.triangles[vertexOffset].toDouble(), mesh.triangles[vertexOffset + 1].toDouble(), mesh.triangles[vertexOffset + 2].toDouble())
            val b = project(mesh.triangles[vertexOffset + 3].toDouble(), mesh.triangles[vertexOffset + 4].toDouble(), mesh.triangles[vertexOffset + 5].toDouble())
            val c = project(mesh.triangles[vertexOffset + 6].toDouble(), mesh.triangles[vertexOffset + 7].toDouble(), mesh.triangles[vertexOffset + 8].toDouble())
            val nx = mesh.normals.getOrElse(vertexOffset) { 0f }.toDouble()
            val ny = mesh.normals.getOrElse(vertexOffset + 1) { 1f }.toDouble()
            val nz = mesh.normals.getOrElse(vertexOffset + 2) { 0f }.toDouble()
            val normal = rotate(nx, ny, nz)
            val diffuse = max(0.0, normal.first * light.first + normal.second * light.second + normal.third * light.third)
            val roof = mesh.materials.getOrElse(vertexOffset / 3) { if (abs(ny) >= 0.42) 1f else 0f } >= 0.5f
            val mineral = abs(sin((a.x + b.x * 1.71 + c.x * 0.63) * 18.7 + (a.y + b.y + c.y) * 11.3))
            val base = if (roof) {
                val materialVariation = 0.985 + mineral * 0.030
                intArrayOf(
                    (40 * materialVariation).toInt(),
                    (46 * materialVariation).toInt(),
                    (50 * materialVariation).toInt()
                )
            } else {
                intArrayOf(232, 218, 190)
            }
            val shade = if (roof) {
                (0.97 + 0.06 * diffuse).coerceIn(0.97, 1.03)
            } else {
                (0.82 + 0.18 * diffuse).coerceIn(0.80, 1.0)
            }
            val color = Color.rgb(
                (base[0] * shade).toInt().coerceIn(0, 255),
                (base[1] * shade).toInt().coerceIn(0, 255),
                (base[2] * shade).toInt().coerceIn(0, 255)
            )
            triangles += DrawTriangle(a, b, c, (a.depth + b.depth + c.depth) / 3.0, color)
            vertexOffset += 9
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val surfaceStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(125, 24, 28, 30)
            strokeWidth = max(0.72f, min(width, height) / 760f)
        }
        triangles.sortedBy { it.depth }.forEach { triangle ->
            val path = Path().apply {
                moveTo(sx(triangle.a), sy(triangle.a))
                lineTo(sx(triangle.b), sy(triangle.b))
                lineTo(sx(triangle.c), sy(triangle.c))
                close()
            }
            fill.color = triangle.color
            canvas.drawPath(path, fill)
            canvas.drawPath(path, surfaceStroke)
        }

        val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(19, 23, 25)
            strokeWidth = max(1.0f, min(width, height) / 430f)
            strokeCap = Paint.Cap.BUTT
        }
        offset = 0
        while (offset + 5 < mesh.edges.size) {
            val a = project(mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble())
            val b = project(mesh.edges[offset + 3].toDouble(), mesh.edges[offset + 4].toDouble(), mesh.edges[offset + 5].toDouble())
            canvas.drawLine(sx(a), sy(a), sx(b), sy(b), edgePaint)
            offset += 6
        }
        val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(226, 212, 178)
            strokeWidth = max(1.2f, min(width, height) / 320f)
            strokeCap = Paint.Cap.SQUARE
        }
        offset = 0
        while (offset + 5 < mesh.logoEdges.size) {
            val a = project(mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble())
            val b = project(mesh.logoEdges[offset + 3].toDouble(), mesh.logoEdges[offset + 4].toDouble(), mesh.logoEdges[offset + 5].toDouble())
            canvas.drawLine(sx(a), sy(a), sx(b), sy(b), logoPaint)
            offset += 6
        }
        canvas.drawRect(RectF(0.5f, 0.5f, width - 0.5f, height - 0.5f), frame)
        return bitmap
    }
}
