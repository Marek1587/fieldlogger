package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object DevelopedProfilePdfRenderer {
    private const val PT_PER_MM = 72f / 25.4f
    private const val BREAK_THRESHOLD_MM = 450.0
    private const val VISIBLE_END_MM = 150.0
    private const val BREAK_GAP_MM = 180.0
    private val scaleSteps = intArrayOf(1, 2, 5, 10, 20, 25, 50, 100, 200)
    private val panelPalette = intArrayOf(
        Color.rgb(221, 238, 251),
        Color.rgb(223, 245, 231),
        Color.rgb(255, 242, 214),
        Color.rgb(239, 231, 252),
        Color.rgb(250, 228, 231),
        Color.rgb(228, 243, 244)
    )

    fun draw(
        canvas: Canvas,
        project: ProjectRecord,
        drawing: DrawingRecord,
        pageNumber: Int,
        totalPages: Int
    ) {
        val developed = DevelopedProfileBuilder.build(drawing)
            ?: error("Rozvinutý plášť sa nepodarilo vypočítať.")
        val metrics = calculateMetrics(drawing)
        canvas.drawColor(Color.WHITE)

        val titlePaint = textPaint(15.5f, Color.rgb(25, 42, 55), bold = true)
        val subtitlePaint = textPaint(8.0f, Color.rgb(73, 92, 106), bold = true)
        val smallPaint = textPaint(6.8f, Color.rgb(44, 61, 73), bold = false)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(38, 54, 66)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        canvas.drawRect(RectF(mm(8f), mm(8f), mm(202f), mm(289f)), borderPaint)
        canvas.drawText("ROZVINUTÝ PLÁŠŤ – ŠABLÓNA NA STRIHANIE", mm(14f), mm(17f), titlePaint)
        canvas.drawText(
            "${drawing.identifier}  •  ${drawing.name}  •  ${project.name}",
            mm(14f),
            mm(23f),
            subtitlePaint
        )
        canvas.drawText("LIST $pageNumber/$totalPages", mm(166f), mm(17f), subtitlePaint)

        val drawingArea = RectF(mm(12f), mm(34f), mm(198f), mm(220f))
        val availableWidthMm = drawingArea.width() / PT_PER_MM - 8f
        val availableHeightMm = drawingArea.height() / PT_PER_MM - 10f
        val brokenView = drawing.profileLengthM * 1000.0 > BREAK_THRESHOLD_MM
        val plan = if (brokenView) {
            choosePlanForBrokenView(
                developed = developed,
                blankWidthMm = metrics.blankWidthMm.toDouble(),
                nominalLengthMm = drawing.profileLengthM * 1000.0,
                availableWidthMm = availableWidthMm.toDouble(),
                availableHeightMm = availableHeightMm.toDouble()
            )
        } else {
            choosePlan(
                developed = developed,
                blankWidthMm = metrics.blankWidthMm.toDouble(),
                availableWidthMm = availableWidthMm.toDouble(),
                availableHeightMm = availableHeightMm.toDouble()
            )
        }

        val layoutText = if (brokenView) {
            "SKRÁTENÉ ZOBRAZENIE ZAČIATKU A KONCA PROFILU"
        } else {
            "ÚPLNÝ VÝKRES CELEJ DĹŽKY"
        }
        canvas.drawText(
            "$layoutText  •  MIERKA 1:${plan.denominator}",
            mm(14f),
            mm(29f),
            subtitlePaint
        )

        drawDevelopedGeometry(canvas, developed, metrics, plan, drawingArea, drawing.profileLengthM * 1000.0)
        drawLegendAndProcess(canvas, drawing, developed, metrics, plan, smallPaint, borderPaint)
        drawCalibration(canvas, subtitlePaint)
    }

    private fun drawDevelopedGeometry(
        canvas: Canvas,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        area: RectF,
        nominalLengthMm: Double
    ) {
        if (nominalLengthMm <= BREAK_THRESHOLD_MM) {
            drawFullDevelopedGeometry(canvas, developed, metrics, plan, area)
            return
        }
        drawBrokenDevelopedGeometry(canvas, developed, metrics, plan, area, nominalLengthMm)
    }

    private fun drawFullDevelopedGeometry(
        canvas: Canvas,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        area: RectF
    ) {
        val blankModel = blankEnvelope(developed, metrics.blankWidthMm.toDouble())
        val transformedFront = developed.frontEdge.map(plan::transform)
        val transformedBack = developed.backEdge.map(plan::transform)
        val transformedBlank = blankModel.map(plan::transform)
        val all = transformedFront + transformedBack + transformedBlank
        val minX = all.minOf { it.x }
        val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }
        val maxY = all.maxOf { it.y }
        val geometryWidthPt = ((maxX - minX) / plan.denominator * PT_PER_MM).toFloat()
        val geometryHeightPt = ((maxY - minY) / plan.denominator * PT_PER_MM).toFloat()
        val originX = area.left + (area.width() - geometryWidthPt) / 2f
        val originY = area.top + (area.height() - geometryHeightPt) / 2f

        fun pagePoint(point: FlatPoint): FlatPoint {
            val transformed = plan.transform(point)
            return FlatPoint(
                originX + ((transformed.x - minX) / plan.denominator * PT_PER_MM),
                originY + ((transformed.y - minY) / plan.denominator * PT_PER_MM)
            )
        }

        val front = developed.frontEdge.map(::pagePoint)
        val back = developed.backEdge.map(::pagePoint)
        val blank = blankModel.map(::pagePoint)
        drawGeometryPieces(canvas, developed, metrics, front, back, listOf(blank), emptyList(), emptyList(), emptyList())
        drawEndDimensions(
            canvas = canvas,
            front = front,
            back = back,
            frontValues = developed.panels.map { it.frontWidthMm.roundToInt() },
            backValues = developed.panels.map { it.rearWidthMm.roundToInt() },
            frontOverall = metrics.developedWidthMm,
            backOverall = metrics.rearDevelopedWidthMm ?: metrics.developedWidthMm,
            area = area
        )
    }

    private fun drawBrokenDevelopedGeometry(
        canvas: Canvas,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        area: RectF,
        nominalLengthMm: Double
    ) {
        val model = buildBrokenModel(
            developed,
            metrics.blankWidthMm.toDouble(),
            nominalLengthMm
        )
        val transformed = model.allDisplayedPoints.map(plan::transform)
        val minX=transformed.minOf{it.x}; val maxX=transformed.maxOf{it.x}
        val minY=transformed.minOf{it.y}; val maxY=transformed.maxOf{it.y}
        val widthPt=((maxX-minX)/plan.denominator*PT_PER_MM).toFloat()
        val heightPt=((maxY-minY)/plan.denominator*PT_PER_MM).toFloat()
        val originX=area.left+(area.width()-widthPt)/2f
        val originY=area.top+(area.height()-heightPt)/2f
        fun pagePoint(point:FlatPoint):FlatPoint { val q=plan.transform(point); return FlatPoint(originX+(q.x-minX)/plan.denominator*PT_PER_MM, originY+(q.y-minY)/plan.denominator*PT_PER_MM) }
        val front=model.front.map(::pagePoint)
        val left=model.leftBreak.map(::pagePoint)
        val right=model.rightBreak.map(::pagePoint)
        val back=model.back.map(::pagePoint)
        val leftBlankPage=model.leftBlank.map(::pagePoint)
        val rightBlankPage=model.rightBlank.map(::pagePoint)
        val panelPieces=mutableListOf<List<FlatPoint>>()
        developed.panels.indices.forEach { i ->
            panelPieces += listOf(front[i],front[i+1],left[i+1],left[i])
            panelPieces += listOf(right[i],right[i+1],back[i+1],back[i])
        }
        val breakLines=listOf(
            BreakLine(left.first(), pagePoint(model.leftBlankBottom), 0.38),
            BreakLine(right.first(), pagePoint(model.rightBlankBottom), 0.62)
        )
        val splitFolds=mutableListOf<Pair<FlatPoint,FlatPoint>>()
        front.indices.forEach { i -> splitFolds += front[i] to left[i]; splitFolds += right[i] to back[i] }
        drawOmittedCenter(canvas, left, right)
        drawGeometryPieces(canvas, developed, metrics, front, back, listOf(leftBlankPage,rightBlankPage), panelPieces, breakLines, splitFolds)
        drawBrokenViewCenterAxis(canvas, front, back)
        drawOverallLengthDimension(
            canvas = canvas,
            start = front.first(),
            end = back.first(),
            breakStart = left.first(),
            breakEnd = right.first(),
            label = nominalLengthMm.roundToInt().toString(),
            colorValue = Color.rgb(24, 41, 54),
            normalOffset = -29f
        )
        drawEndDimensions(
            canvas = canvas,
            front = front,
            back = back,
            frontValues = developed.panels.map { it.frontWidthMm.roundToInt() },
            backValues = developed.panels.map { it.rearWidthMm.roundToInt() },
            frontOverall = metrics.developedWidthMm,
            backOverall = metrics.rearDevelopedWidthMm ?: metrics.developedWidthMm,
            area = area
        )
    }

    private fun drawGeometryPieces(
        canvas: Canvas,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        front: List<FlatPoint>,
        back: List<FlatPoint>,
        blankPolygons: List<List<FlatPoint>>,
        explicitPanelPieces: List<List<FlatPoint>>,
        breakLines: List<BreakLine>,
        splitFoldSegments: List<Pair<FlatPoint,FlatPoint>>
    ) {
        val blankFill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(251,214,214);style=Paint.Style.FILL}
        val blankOutline=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(173,42,34);style=Paint.Style.STROKE;strokeWidth=1.35f;strokeJoin=Paint.Join.ROUND}
        val outline=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(24,41,54);style=Paint.Style.STROKE;strokeWidth=1.4f;strokeJoin=Paint.Join.ROUND}
        val fold=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(230,132,38);style=Paint.Style.STROKE;strokeWidth=1.2f;pathEffect=DashPathEffect(floatArrayOf(7f,4f),0f)}
        val cut=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(173,42,34);style=Paint.Style.STROKE;strokeWidth=1.7f}
        val frontPaint=Paint(outline).apply{color=Color.rgb(10,110,196);strokeWidth=2.2f}
        val backPaint=Paint(outline).apply{color=Color.rgb(83,97,108);strokeWidth=2.2f}
        blankPolygons.forEach{canvas.drawPath(polygonPath(it),blankFill);canvas.drawPath(polygonPath(it),blankOutline)}
        val pieces=if(explicitPanelPieces.isEmpty()) developed.panels.indices.map{i->listOf(front[i],front[i+1],back[i+1],back[i])} else explicitPanelPieces
        pieces.forEachIndexed{i,poly-> val fill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=panelPalette[(i/if(explicitPanelPieces.isEmpty())1 else 2)%panelPalette.size];style=Paint.Style.FILL};canvas.drawPath(polygonPath(poly),fill);canvas.drawPath(polygonPath(poly),outline)}
        drawPolyline(canvas,front,frontPaint);drawPolyline(canvas,back,backPaint)
        val foldSegments = if (splitFoldSegments.isEmpty()) front.indices.map { front[it] to back[it] } else splitFoldSegments
        foldSegments.forEachIndexed { segmentIndex, segment ->
            val profileIndex = if (splitFoldSegments.isEmpty()) segmentIndex else segmentIndex / 2
            val p=if(profileIndex==0||profileIndex==front.lastIndex)cut else fold
            canvas.drawLine(segment.first.x.toFloat(),segment.first.y.toFloat(),segment.second.x.toFloat(),segment.second.y.toFloat(),p)
        }
        breakLines.forEach{drawStnLongBreak(canvas,it.start,it.end,it.centerT,outline)}
        if(metrics.offcutPerPieceM2>0.000001 && blankPolygons.isNotEmpty()) {
            val red=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.rgb(233,102,94);style=Paint.Style.FILL}
            if(blankPolygons.size==1) {
                val off=listOf(front.last(),back.last(),blankPolygons[0][2],blankPolygons[0][3]);canvas.drawPath(polygonPath(off),red);canvas.drawPath(polygonPath(off),blankOutline)
            } else if(explicitPanelPieces.size>=2) {
                val lastPanelLeft=explicitPanelPieces[explicitPanelPieces.size-2]
                val leftOff=listOf(front.last(),lastPanelLeft[2],blankPolygons[0][2],blankPolygons[0][3])
                val rightOff=listOf(explicitPanelPieces.last()[1],back.last(),blankPolygons[1][2],blankPolygons[1][3])
                listOf(leftOff,rightOff).forEach{canvas.drawPath(polygonPath(it),red);canvas.drawPath(polygonPath(it),blankOutline)}
                val centerX=rightOff.map{it.x}.average().toFloat();val centerY=rightOff.map{it.y}.average().toFloat();val labelPaint=textPaint(7.2f,Color.rgb(112,19,16),true).apply{textAlign=Paint.Align.CENTER};canvas.drawText("ODREZOK",centerX,centerY,labelPaint)
            }
        }
    }

    private fun drawEndDimensions(
        canvas: Canvas,
        front: List<FlatPoint>,
        back: List<FlatPoint>,
        frontValues: List<Int>,
        backValues: List<Int>,
        frontOverall: Int,
        backOverall: Int,
        area: RectF
    ) {
        val occupied = mutableListOf<RectF>()
        val frontSign = outsideSign(front, back)
        val backSign = outsideSign(back, front)
        drawSolvedEdgeDimensions(
            canvas,
            front,
            frontValues,
            frontOverall,
            Color.rgb(10, 110, 196),
            frontSign,
            area,
            occupied
        )
        drawSolvedEdgeDimensions(
            canvas,
            back,
            backValues,
            backOverall,
            Color.rgb(83, 97, 108),
            backSign,
            area,
            occupied
        )
    }

    private fun drawSolvedEdgeDimensions(
        canvas: Canvas,
        edge: List<FlatPoint>,
        values: List<Int>,
        overallValue: Int,
        colorValue: Int,
        preferredSign: Double,
        area: RectF,
        occupied: MutableList<RectF>
    ) {
        if (edge.size < 2) return
        val labelPaint = textPaint(7.2f, colorValue, true)
        edge.zipWithNext().forEachIndexed { index, (start, end) ->
            val label = values.getOrElse(index) { 0 }.toString()
            val offset = solveDimensionOffset(
                start,
                end,
                label,
                labelPaint,
                preferredSign,
                baseOffset = 15f,
                area = area,
                occupied = occupied
            )
            val bounds = dimensionLabelBounds(start, end, label, labelPaint, offset)
            occupied += expanded(bounds, 4f)
            drawDimensionAtOffset(canvas, start, end, label, colorValue, offset, 1.0f)
        }

        if (values.size > 1) {
            val start = edge.first()
            val end = edge.last()
            val label = overallValue.toString()
            val offset = solveDimensionOffset(
                start,
                end,
                label,
                labelPaint,
                preferredSign,
                baseOffset = 43f + values.size.coerceAtMost(4) * 4f,
                area = area,
                occupied = occupied
            )
            occupied += expanded(dimensionLabelBounds(start, end, label, labelPaint, offset), 5f)
            drawDimensionAtOffset(canvas, start, end, label, colorValue, offset, 1.45f)
        }
    }

    private fun drawLineText(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        paint: Paint,
        normalOffset: Float = 0f
    ) {
        val dx = (end.x - start.x).toFloat()
        val dy = (end.y - start.y).toFloat()
        val length = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(0.001f)
        val midX = ((start.x + end.x) / 2.0).toFloat() - dy / length * normalOffset
        val midY = ((start.y + end.y) / 2.0).toFloat() + dx / length * normalOffset
        var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (angle > 90f || angle < -90f) angle += 180f
        canvas.save()
        canvas.rotate(angle, midX, midY)
        val width = paint.measureText(label)
        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawRect(midX - width / 2f - 2f, midY - 7f, midX + width / 2f + 2f, midY + 3f, background)
        canvas.drawText(label, midX - width / 2f, midY, paint)
        canvas.restore()
    }

    private fun drawStnLongBreak(
        canvas: Canvas,
        a: FlatPoint,
        b: FlatPoint,
        centerT: Double,
        paint: Paint
    ){
        val originalDx=b.x-a.x
        val originalDy=b.y-a.y
        val originalLength=hypot(originalDx,originalDy).coerceAtLeast(0.001)
        val ux=originalDx/originalLength
        val uy=originalDy/originalLength
        val start=FlatPoint(a.x-ux*5.0,a.y-uy*5.0)
        val end=FlatPoint(b.x+ux*5.0,b.y+uy*5.0)
        val dx=end.x-start.x
        val dy=end.y-start.y
        val len=hypot(dx,dy).coerceAtLeast(0.001)
        val nx=-dy/len
        val ny=dx/len
        fun point(t:Double,normal:Double=0.0)=FlatPoint(
            start.x+dx*t+nx*normal,
            start.y+dy*t+ny*normal
        )
        val path=Path().apply {
            val p0=point(0.0)
            moveTo(p0.x.toFloat(),p0.y.toFloat())
            listOf(
                point(centerT-0.08),
                point(centerT-0.03,5.5),
                point(centerT+0.03,-5.5),
                point(centerT+0.08),
                point(1.0)
            ).forEach { lineTo(it.x.toFloat(),it.y.toFloat()) }
        }
        canvas.drawPath(path,Paint(paint).apply{strokeWidth=1.05f;pathEffect=null})
    }

    private fun drawBrokenViewCenterAxis(
        canvas: Canvas,
        front: List<FlatPoint>,
        back: List<FlatPoint>
    ) {
        if (front.size < 2 || back.size < 2) return
        val startCenter = FlatPoint(
            (front.first().x + front.last().x) / 2.0,
            (front.first().y + front.last().y) / 2.0
        )
        val endCenter = FlatPoint(
            (back.first().x + back.last().x) / 2.0,
            (back.first().y + back.last().y) / 2.0
        )
        val dx = endCenter.x - startCenter.x
        val dy = endCenter.y - startCenter.y
        val length = hypot(dx, dy).coerceAtLeast(0.001)
        val ux = dx / length
        val uy = dy / length
        val extendedStart = FlatPoint(startCenter.x - ux * 8.0, startCenter.y - uy * 8.0)
        val extendedEnd = FlatPoint(endCenter.x + ux * 8.0, endCenter.y + uy * 8.0)
        val axis = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(91, 106, 116)
            style = Paint.Style.STROKE
            strokeWidth = 0.85f
            pathEffect = DashPathEffect(floatArrayOf(12f, 4f, 2f, 4f), 0f)
        }
        canvas.drawLine(
            extendedStart.x.toFloat(),
            extendedStart.y.toFloat(),
            extendedEnd.x.toFloat(),
            extendedEnd.y.toFloat(),
            axis
        )
    }

    private fun drawOmittedCenter(
        canvas: Canvas,
        leftBreak: List<FlatPoint>,
        rightBreak: List<FlatPoint>
    ) {
        if (leftBreak.size < 2 || leftBreak.size != rightBreak.size) return
        val omittedArea = leftBreak + rightBreak.asReversed()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(235, 239, 242)
            style = Paint.Style.FILL
        }
        canvas.drawPath(polygonPath(omittedArea), fill)

        val continuation = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(92, 108, 119)
            style = Paint.Style.STROKE
            strokeWidth = 1.15f
            pathEffect = DashPathEffect(floatArrayOf(6f, 4f), 0f)
        }
        leftBreak.indices.forEach { index ->
            canvas.drawLine(
                leftBreak[index].x.toFloat(),
                leftBreak[index].y.toFloat(),
                rightBreak[index].x.toFloat(),
                rightBreak[index].y.toFloat(),
                continuation
            )
        }
    }

    private fun drawOverallLengthDimension(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        breakStart: FlatPoint,
        breakEnd: FlatPoint,
        label: String,
        colorValue: Int,
        normalOffset: Float
    ) {
        val dx=end.x-start.x
        val dy=end.y-start.y
        val len=hypot(dx,dy).coerceAtLeast(0.001)
        val nx=-dy/len
        val ny=dx/len
        fun offset(point:FlatPoint)=FlatPoint(
            point.x+nx*normalOffset,
            point.y+ny*normalOffset
        )
        val dimensionStart=offset(start)
        val dimensionEnd=offset(end)
        val gapStart=offset(breakStart)
        val gapEnd=offset(breakEnd)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
            color=colorValue
            strokeWidth=1.15f
            style=Paint.Style.STROKE
        }
        canvas.drawLine(
            start.x.toFloat(),
            start.y.toFloat(),
            dimensionStart.x.toFloat(),
            dimensionStart.y.toFloat(),
            paint
        )
        canvas.drawLine(
            end.x.toFloat(),
            end.y.toFloat(),
            dimensionEnd.x.toFloat(),
            dimensionEnd.y.toFloat(),
            paint
        )
        canvas.drawLine(
            dimensionStart.x.toFloat(),
            dimensionStart.y.toFloat(),
            gapStart.x.toFloat(),
            gapStart.y.toFloat(),
            paint
        )
        canvas.drawLine(
            gapEnd.x.toFloat(),
            gapEnd.y.toFloat(),
            dimensionEnd.x.toFloat(),
            dimensionEnd.y.toFloat(),
            paint
        )
        drawArrow(
            canvas,
            dimensionStart.x.toFloat(),
            dimensionStart.y.toFloat(),
            dimensionEnd.x.toFloat(),
            dimensionEnd.y.toFloat(),
            paint
        )
        drawArrow(
            canvas,
            dimensionEnd.x.toFloat(),
            dimensionEnd.y.toFloat(),
            dimensionStart.x.toFloat(),
            dimensionStart.y.toFloat(),
            paint
        )
        drawDimensionBreakMark(canvas,gapStart,dx,dy,paint)
        drawDimensionBreakMark(canvas,gapEnd,dx,dy,paint)
        drawLineText(
            canvas,
            gapStart,
            gapEnd,
            label,
            textPaint(7.2f,colorValue,true),
            10f
        )
    }

    private fun drawDimensionBreakMark(
        canvas:Canvas,
        center:FlatPoint,
        directionX:Double,
        directionY:Double,
        paint:Paint
    ){
        val len=hypot(directionX,directionY).coerceAtLeast(0.001)
        val ux=directionX/len
        val uy=directionY/len
        val nx=-uy
        val ny=ux
        val p1=FlatPoint(center.x-ux*4.0-nx*5.0,center.y-uy*4.0-ny*5.0)
        val p2=FlatPoint(center.x+ux*4.0+nx*5.0,center.y+uy*4.0+ny*5.0)
        canvas.drawLine(p1.x.toFloat(),p1.y.toFloat(),p2.x.toFloat(),p2.y.toFloat(),paint)
    }

    private fun outsideSign(edge:List<FlatPoint>,other:List<FlatPoint>):Double{
        if(edge.size<2||other.isEmpty()) return 1.0
        val start=edge.first()
        val end=edge.last()
        val dx=end.x-start.x
        val dy=end.y-start.y
        val len=hypot(dx,dy).coerceAtLeast(0.001)
        val nx=-dy/len
        val ny=dx/len
        val edgeCenter=FlatPoint(edge.map{it.x}.average(),edge.map{it.y}.average())
        val otherCenter=FlatPoint(other.map{it.x}.average(),other.map{it.y}.average())
        val towardOther=(otherCenter.x-edgeCenter.x)*nx+(otherCenter.y-edgeCenter.y)*ny
        return if(towardOther>=0.0)-1.0 else 1.0
    }

    private fun solveDimensionOffset(
        start:FlatPoint,
        end:FlatPoint,
        label:String,
        paint:Paint,
        preferredSign:Double,
        baseOffset:Float,
        area:RectF,
        occupied:List<RectF>
    ):Float{
        val signs=listOf(preferredSign,-preferredSign)
        for(lane in 0..9){
            for(sign in signs){
                val offset=(baseOffset+lane*11f)*sign.toFloat()
                val candidate=dimensionLabelBounds(start,end,label,paint,offset)
                if(inside(candidate,area,2f)&&occupied.none{RectF.intersects(expanded(it,3f),candidate)}){
                    return offset
                }
            }
        }
        return baseOffset*preferredSign.toFloat()
    }

    private fun dimensionLabelBounds(
        start:FlatPoint,
        end:FlatPoint,
        label:String,
        paint:Paint,
        offset:Float
    ):RectF{
        val dx=(end.x-start.x).toFloat()
        val dy=(end.y-start.y).toFloat()
        val len=hypot(dx.toDouble(),dy.toDouble()).toFloat().coerceAtLeast(0.001f)
        val nx=-dy/len
        val ny=dx/len
        val centerX=((start.x+end.x)/2.0).toFloat()+nx*offset
        val centerY=((start.y+end.y)/2.0).toFloat()+ny*offset
        val halfWidth=(paint.measureText(label)+8f)/2f
        val halfHeight=6f
        val angle=atan2(dy.toDouble(),dx.toDouble())
        val cosine=kotlin.math.abs(kotlin.math.cos(angle)).toFloat()
        val sine=kotlin.math.abs(kotlin.math.sin(angle)).toFloat()
        val boundX=cosine*halfWidth+sine*halfHeight
        val boundY=sine*halfWidth+cosine*halfHeight
        return RectF(centerX-boundX,centerY-boundY,centerX+boundX,centerY+boundY)
    }

    private fun drawDimensionAtOffset(
        canvas:Canvas,
        start:FlatPoint,
        end:FlatPoint,
        label:String,
        colorValue:Int,
        offset:Float,
        strokeWidth:Float
    ){
        val dx=end.x-start.x
        val dy=end.y-start.y
        val len=hypot(dx,dy).coerceAtLeast(0.001)
        val nx=-dy/len
        val ny=dx/len
        val dimensionStart=FlatPoint(start.x+nx*offset,start.y+ny*offset)
        val dimensionEnd=FlatPoint(end.x+nx*offset,end.y+ny*offset)
        val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
            color=colorValue
            this.strokeWidth=strokeWidth
            style=Paint.Style.STROKE
        }
        canvas.drawLine(
            start.x.toFloat(),start.y.toFloat(),
            dimensionStart.x.toFloat(),dimensionStart.y.toFloat(),paint
        )
        canvas.drawLine(
            end.x.toFloat(),end.y.toFloat(),
            dimensionEnd.x.toFloat(),dimensionEnd.y.toFloat(),paint
        )
        canvas.drawLine(
            dimensionStart.x.toFloat(),dimensionStart.y.toFloat(),
            dimensionEnd.x.toFloat(),dimensionEnd.y.toFloat(),paint
        )
        drawArrow(
            canvas,
            dimensionStart.x.toFloat(),dimensionStart.y.toFloat(),
            dimensionEnd.x.toFloat(),dimensionEnd.y.toFloat(),paint
        )
        drawArrow(
            canvas,
            dimensionEnd.x.toFloat(),dimensionEnd.y.toFloat(),
            dimensionStart.x.toFloat(),dimensionStart.y.toFloat(),paint
        )
        drawLineText(
            canvas,
            dimensionStart,
            dimensionEnd,
            label,
            textPaint(7.2f,colorValue,true)
        )
    }

    private fun expanded(rect:RectF,amount:Float)=RectF(
        rect.left-amount,
        rect.top-amount,
        rect.right+amount,
        rect.bottom+amount
    )

    private fun inside(rect:RectF,area:RectF,margin:Float):Boolean=
        rect.left>=area.left+margin&&
            rect.top>=area.top+margin&&
            rect.right<=area.right-margin&&
            rect.bottom<=area.bottom-margin

    private fun drawLegendAndProcess(
        canvas: Canvas,
        drawing: DrawingRecord,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        textPaint: Paint,
        borderPaint: Paint
    ) {
        val legendBox = RectF(mm(12f), mm(224f), mm(198f), mm(253f))
        val tableBox = RectF(mm(12f), mm(256f), mm(198f), mm(281f))
        canvas.drawRect(legendBox, borderPaint)
        canvas.drawRect(tableBox, borderPaint)

        val heading = Paint(textPaint).apply {
            typeface = Typeface.DEFAULT_BOLD
            textSize = 7.6f
        }
        canvas.drawText("AKO TO V DIELNI OHÝBAŤ", legendBox.left + 5f, legendBox.top + 10f, heading)
        canvas.drawText(
            "Polotovar: ${metrics.blankWidthMm} × ${(drawing.profileLengthM * 1000.0).roundToInt()} mm  •  otočenie nákresu: ${if (plan.rotated) "90°" else "0°"}",
            legendBox.left + 5f,
            legendBox.top + 20f,
            textPaint
        )

        val steps = listOf(
            LegendItem(Color.rgb(173, 42, 34), "červená čiara", "výrobný rez na oboch koncoch"),
            LegendItem(Color.rgb(230, 132, 38), "oranžová čiara", "miesto ohybu na oboch koncoch"),
            LegendItem(Color.rgb(10, 110, 196), "modrý okraj", "predná hrana profilu"),
            LegendItem(Color.rgb(83, 97, 108), "sivý okraj", "zadná hrana profilu"),
            LegendItem(Color.rgb(233, 102, 94), "červená plocha", "odrezok – nevstupuje do hotového kusu")
        )
        var stepY = legendBox.top + 31f
        steps.forEachIndexed { index, item ->
            if (index == 3) stepY = legendBox.top + 31f
            val columnX = if (index < 3) legendBox.left + 6f else legendBox.left + legendBox.width() / 2f
            val rowY = if (index < 3) legendBox.top + 31f + index * 8.5f else legendBox.top + 31f + (index - 3) * 8.5f
            val swatch = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.color; style = Paint.Style.FILL }
            canvas.drawRect(columnX, rowY - 4f, columnX + 8f, rowY + 1f, swatch)
            canvas.drawText(item.title, columnX + 11f, rowY, heading)
            canvas.drawText(item.description, columnX + 42f, rowY, textPaint)
        }

        canvas.drawText("PREHĽAD PÁSOV A OHYBOV", tableBox.left + 5f, tableBox.top + 10f, heading)
        val columns = listOf("Panel", "Predná", "Zadná", "Po paneli")
        val columnWeights = floatArrayOf(0.18f, 0.24f, 0.24f, 0.34f)
        val totalWidth = tableBox.width()
        val rowTop = tableBox.top + 13f
        val rowHeight = 8.5f
        var runningX = tableBox.left
        columns.forEachIndexed { index, title ->
            val cellWidth = totalWidth * columnWeights[index]
            canvas.drawRect(RectF(runningX, rowTop, runningX + cellWidth, rowTop + rowHeight), borderPaint)
            canvas.drawText(title.uppercase(), runningX + 3f, rowTop + 6f, textPaint)
            runningX += cellWidth
        }

        val rows = developed.panels.size
        val tableText = textPaint(6.7f, Color.rgb(28, 43, 53), bold = false)
        val boldValue = Paint(tableText).apply { typeface = Typeface.DEFAULT_BOLD }
        for (row in 0 until rows) {
            val top = rowTop + rowHeight * (row + 1)
            if (top + rowHeight > tableBox.bottom - 1f) break
            var x = tableBox.left
            val values = listOf(
                "${row + 1}",
                "${developed.panels[row].frontWidthMm.roundToInt()} mm",
                "${developed.panels[row].rearWidthMm.roundToInt()} mm",
                if (row < rows - 1) "ohyb" else "koncový rez"
            )
            values.forEachIndexed { index, value ->
                val cellWidth = totalWidth * columnWeights[index]
                val cell = RectF(x, top, x + cellWidth, top + rowHeight)
                canvas.drawRect(cell, borderPaint)
                val paint = if (index == 0 || index == 3) boldValue else tableText
                canvas.drawText(value, cell.left + 3f, cell.top + 6f, paint)
                x += cellWidth
            }
        }

        canvas.drawText(
            "Spotreba polotovaru / kus ${formatDecimal(metrics.sheetPerPieceM2)} m²  •  hotový plášť ${formatDecimal(metrics.netProfileAreaM2)} m²  •  odrezok ${formatDecimal(metrics.offcutPerPieceM2, 3)} m²",
            mm(12f),
            mm(286f),
            heading
        )
    }

    private fun drawCalibration(canvas: Canvas, paint: Paint) {
        val startX = mm(145f)
        val endX = startX + mm(50f)
        val y = mm(284f)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            strokeWidth = 1.2f
        }
        canvas.drawLine(startX, y, endX, y, line)
        canvas.drawLine(startX, y - 4f, startX, y + 4f, line)
        canvas.drawLine(endX, y - 4f, endX, y + 4f, line)
        canvas.drawText("kontrola tlače 50 mm", startX, y - 6f, paint)
    }

    private fun choosePlanForBrokenView(
        developed: DevelopedProfile,
        blankWidthMm: Double,
        nominalLengthMm: Double,
        availableWidthMm: Double,
        availableHeightMm: Double
    ): Plan {
        val model=buildBrokenModel(developed,blankWidthMm,nominalLengthMm)
        val points=model.allDisplayedPoints
        val normal=planForPoints(points,availableWidthMm,availableHeightMm,false);val rotated=planForPoints(points,availableWidthMm,availableHeightMm,true)
        return listOf(normal,rotated).sortedWith(compareBy<Plan>{it.denominator}.thenByDescending{it.usedAreaRatio}.thenBy{it.penalty}).first()
    }

    private fun buildBrokenModel(
        developed:DevelopedProfile,
        blankWidthMm:Double,
        nominalLengthMm:Double
    ):BrokenModel{
        val front=developed.frontEdge
        val originalBack=developed.backEdge
        val blank=blankEnvelope(developed,blankWidthMm)
        val fraction=(VISIBLE_END_MM/nominalLengthMm.coerceAtLeast(1.0)).coerceIn(0.02,0.49)
        fun lerp(a:FlatPoint,b:FlatPoint,t:Double)=FlatPoint(
            a.x+(b.x-a.x)*t,
            a.y+(b.y-a.y)*t
        )
        val leftBreak=front.indices.map{lerp(front[it],originalBack[it],fraction)}
        val rightRaw=front.indices.map{lerp(front[it],originalBack[it],1.0-fraction)}
        val topStart=front.first()
        val topEnd=originalBack.first()
        val topDx=topEnd.x-topStart.x
        val topDy=topEnd.y-topStart.y
        val topLength=hypot(topDx,topDy).coerceAtLeast(1.0)
        val ux=topDx/topLength
        val uy=topDy/topLength
        val desiredRightTop=FlatPoint(
            leftBreak.first().x+ux*BREAK_GAP_MM,
            leftBreak.first().y+uy*BREAK_GAP_MM
        )
        val shiftX=desiredRightTop.x-rightRaw.first().x
        val shiftY=desiredRightTop.y-rightRaw.first().y
        fun shifted(point:FlatPoint)=FlatPoint(point.x+shiftX,point.y+shiftY)
        val rightBreak=rightRaw.map(::shifted)
        val back=originalBack.map(::shifted)
        val leftBlankBottom=lerp(blank[3],blank[2],fraction)
        val rightBlankBottom=shifted(lerp(blank[3],blank[2],1.0-fraction))
        val leftBlank=listOf(front.first(),leftBreak.first(),leftBlankBottom,blank[3])
        val rightBlank=listOf(rightBreak.first(),back.first(),shifted(blank[2]),rightBlankBottom)
        return BrokenModel(
            front=front,
            leftBreak=leftBreak,
            rightBreak=rightBreak,
            back=back,
            leftBlank=leftBlank,
            rightBlank=rightBlank,
            leftBlankBottom=leftBlankBottom,
            rightBlankBottom=rightBlankBottom
        )
    }

    private fun planForPoints(points:List<FlatPoint>,availableWidthMm:Double,availableHeightMm:Double,rotated:Boolean):Plan{
        val q=points.map{if(rotated)FlatPoint(-it.y,it.x)else it};val w=q.maxOf{it.x}-q.minOf{it.x};val h=q.maxOf{it.y}-q.minOf{it.y};val d=scaleSteps.firstOrNull{w/it<=availableWidthMm&&h/it<=availableHeightMm}?:ceil(max(w/availableWidthMm,h/availableHeightMm)).toInt().coerceAtLeast(1);val uw=w/d;val uh=h/d;return Plan(rotated,d,(uw*uh)/(availableWidthMm*availableHeightMm),kotlin.math.abs(uw/availableWidthMm-uh/availableHeightMm))
    }

    private fun choosePlan(
        developed: DevelopedProfile,
        blankWidthMm: Double,
        availableWidthMm: Double,
        availableHeightMm: Double
    ): Plan {
        val normal = planFor(developed, blankWidthMm, availableWidthMm, availableHeightMm, rotated = false)
        val rotated = planFor(developed, blankWidthMm, availableWidthMm, availableHeightMm, rotated = true)
        return listOf(normal, rotated).sortedWith(
            compareBy<Plan> { it.denominator }
                .thenByDescending { it.usedAreaRatio }
                .thenBy { it.penalty }
        ).first()
    }

    private fun planFor(
        profile: DevelopedProfile,
        blankWidthMm: Double,
        availableWidthMm: Double,
        availableHeightMm: Double,
        rotated: Boolean
    ): Plan {
        val points = (profile.frontEdge + profile.backEdge + blankEnvelope(profile, blankWidthMm)).map { point ->
            if (rotated) FlatPoint(-point.y, point.x) else point
        }
        val width = points.maxOf { it.x } - points.minOf { it.x }
        val height = points.maxOf { it.y } - points.minOf { it.y }
        val denominator = scaleSteps.firstOrNull {
            width / it <= availableWidthMm && height / it <= availableHeightMm
        } ?: ceil(max(width / availableWidthMm, height / availableHeightMm)).toInt().coerceAtLeast(1)
        val usedWidth = width / denominator
        val usedHeight = height / denominator
        val usedArea = usedWidth * usedHeight
        val ratio = usedArea / (availableWidthMm * availableHeightMm)
        val penalty = absRatio(usedWidth / availableWidthMm, usedHeight / availableHeightMm)
        return Plan(rotated, denominator, ratio, penalty)
    }

    private fun blankEnvelope(profile: DevelopedProfile, widthMm: Double): List<FlatPoint> {
        val frontTop = profile.frontEdge.first()
        val backTop = profile.backEdge.first()
        val dx = backTop.x - frontTop.x
        val dy = backTop.y - frontTop.y
        val length = hypot(dx, dy).coerceAtLeast(0.000001)
        var normalX = -dy / length
        var normalY = dx / length
        val actualBottomCenter = FlatPoint(
            (profile.frontEdge.last().x + profile.backEdge.last().x) / 2.0,
            (profile.frontEdge.last().y + profile.backEdge.last().y) / 2.0
        )
        val topCenter = FlatPoint(
            (frontTop.x + backTop.x) / 2.0,
            (frontTop.y + backTop.y) / 2.0
        )
        val towardProfile =
            (actualBottomCenter.x - topCenter.x) * normalX +
                (actualBottomCenter.y - topCenter.y) * normalY
        if (towardProfile < 0.0) {
            normalX = -normalX
            normalY = -normalY
        }
        return listOf(
            frontTop,
            backTop,
            FlatPoint(backTop.x + normalX * widthMm, backTop.y + normalY * widthMm),
            FlatPoint(frontTop.x + normalX * widthMm, frontTop.y + normalY * widthMm)
        )
    }

    private fun drawPanelBadge(
        canvas: Canvas,
        polygon: List<FlatPoint>,
        panelIndex: Int,
        frontWidthMm: Int,
        rearWidthMm: Int
    ) {
        val centerX = polygon.map { it.x }.average().toFloat()
        val centerY = polygon.map { it.y }.average().toFloat()
        val labelLines = listOf(
            "PANEL $panelIndex",
            "predná $frontWidthMm mm",
            "zadná $rearWidthMm mm"
        )
        val width = 54f
        val height = 22f
        val box = RectF(centerX - width / 2f, centerY - height / 2f, centerX + width / 2f, centerY + height / 2f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 255, 255, 255) }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 46, 59)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val text = textPaint(6.5f, Color.rgb(27, 46, 59), bold = true).apply { textAlign = Paint.Align.CENTER }
        canvas.drawRoundRect(box, 4f, 4f, fill)
        canvas.drawRoundRect(box, 4f, 4f, border)
        labelLines.forEachIndexed { index, line ->
            canvas.drawText(line, centerX, box.top + 6.5f + index * 6.2f, text)
        }
    }

    private fun drawLineMarker(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        color: Int,
        textPaint: Paint
    ) {
        val midX = ((start.x + end.x) / 2.0).toFloat()
        val midY = ((start.y + end.y) / 2.0).toFloat()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
        val width = max(18f, textPaint.measureText(label) + 10f)
        val box = RectF(midX - width / 2f, midY - 7f, midX + width / 2f, midY + 7f)
        canvas.drawRoundRect(box, 7f, 7f, fill)
        canvas.drawText(label, midX, midY - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)
    }

    private fun drawDimensionLine(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        color: Int,
        offset: Float
    ) {
        val dx = (end.x - start.x).toFloat()
        val dy = (end.y - start.y).toFloat()
        val length = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(0.001f)
        val nx = -dy / length
        val ny = dx / length
        val sx = start.x.toFloat() + nx * offset
        val sy = start.y.toFloat() + ny * offset
        val ex = end.x.toFloat() + nx * offset
        val ey = end.y.toFloat() + ny * offset
        val extension = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = 0.9f
        }
        canvas.drawLine(start.x.toFloat(), start.y.toFloat(), sx, sy, extension)
        canvas.drawLine(end.x.toFloat(), end.y.toFloat(), ex, ey, extension)
        canvas.drawLine(sx, sy, ex, ey, extension)
        drawArrow(canvas, sx, sy, ex, ey, extension)
        drawArrow(canvas, ex, ey, sx, sy, extension)

        val labelPaint = textPaint(6.4f, color, bold = true)
        val midX = (sx + ex) / 2f
        val midY = (sy + ey) / 2f
        var angle = Math.toDegrees(atan2((ey - sy).toDouble(), (ex - sx).toDouble())).toFloat()
        if (angle > 90f || angle < -90f) angle += 180f
        canvas.save()
        canvas.rotate(angle, midX, midY)
        val w = labelPaint.measureText(label)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE }
        canvas.drawRect(midX - w / 2f - 3f, midY - 7f, midX + w / 2f + 3f, midY + 3f, bg)
        canvas.drawText(label, midX - w / 2f, midY, labelPaint)
        canvas.restore()
    }

    private fun drawArrow(canvas: Canvas, x: Float, y: Float, towardX: Float, towardY: Float, paint: Paint) {
        val angle = atan2((towardY - y).toDouble(), (towardX - x).toDouble())
        val size = 5.5f
        val left = angle + Math.toRadians(24.0)
        val right = angle - Math.toRadians(24.0)
        canvas.drawLine(x, y, x + (kotlin.math.cos(left) * size).toFloat(), y + (kotlin.math.sin(left) * size).toFloat(), paint)
        canvas.drawLine(x, y, x + (kotlin.math.cos(right) * size).toFloat(), y + (kotlin.math.sin(right) * size).toFloat(), paint)
    }

    private fun polygonPath(points: List<FlatPoint>): Path = Path().apply {
        moveTo(points.first().x.toFloat(), points.first().y.toFloat())
        points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
        close()
    }

    private fun drawPolyline(canvas: Canvas, points: List<FlatPoint>, paint: Paint) {
        val path = Path().apply {
            moveTo(points.first().x.toFloat(), points.first().y.toFloat())
            points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
        }
        canvas.drawPath(path, paint)
    }

    private fun mm(value: Float): Float = value * PT_PER_MM

    private fun textPaint(size: Float, color: Int, bold: Boolean) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun absRatio(a: Double, b: Double): Double = kotlin.math.abs(a - b)

    private data class LegendItem(val color: Int, val title: String, val description: String)

    private data class BreakLine(
        val start: FlatPoint,
        val end: FlatPoint,
        val centerT: Double
    )

    private data class BrokenModel(
        val front: List<FlatPoint>,
        val leftBreak: List<FlatPoint>,
        val rightBreak: List<FlatPoint>,
        val back: List<FlatPoint>,
        val leftBlank: List<FlatPoint>,
        val rightBlank: List<FlatPoint>,
        val leftBlankBottom: FlatPoint,
        val rightBlankBottom: FlatPoint
    ) {
        val allDisplayedPoints: List<FlatPoint>
            get() = front + leftBreak + rightBreak + back + leftBlank + rightBlank
    }

    private data class Plan(
        val rotated: Boolean,
        val denominator: Int,
        val usedAreaRatio: Double,
        val penalty: Double
    ) {
        fun transform(point: FlatPoint): FlatPoint =
            if (rotated) FlatPoint(-point.y, point.x) else point
    }
}
