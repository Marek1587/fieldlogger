package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.ceil
import kotlin.math.max

object CoilCutPlanPdfRenderer {
    private const val PAGE_WIDTH = 595f
    private const val PAGE_HEIGHT = 842f
    private const val RUNS_PER_PAGE = 3
    private const val PRODUCTS_PER_SUMMARY_PAGE = 12

    fun pageCount(plan: CoilCutPlan): Int =
        cuttingPages(plan).size + summaryPageCount(plan)

    fun drawPage(
        canvas: Canvas,
        project: ProjectRecord,
        plan: CoilCutPlan,
        planPageIndex: Int,
        globalPageNumber: Int,
        totalPages: Int
    ) {
        val cuttingPages = cuttingPages(plan)
        if (planPageIndex < cuttingPages.size) {
            drawCuttingPage(
                canvas,
                project,
                plan,
                cuttingPages[planPageIndex],
                globalPageNumber,
                totalPages
            )
        } else {
            drawSummaryPage(
                canvas,
                project,
                plan,
                planPageIndex - cuttingPages.size,
                globalPageNumber,
                totalPages
            )
        }
    }

    private fun drawCuttingPage(
        canvas: Canvas,
        project: ProjectRecord,
        plan: CoilCutPlan,
        page: CuttingPage,
        globalPageNumber: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)
        val dark = Color.rgb(25, 42, 55)
        val muted = Color.rgb(81, 98, 110)
        val blue = Color.rgb(8, 119, 201)
        val red = Color.rgb(190, 45, 40)
        val orange = Color.rgb(224, 131, 35)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(48, 64, 75)
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
        }
        val title = textPaint(dark, 18f, bold = true)
        val subtitle = textPaint(muted, 8.5f, bold = true)
        val section = textPaint(blue, 10f, bold = true)
        val small = textPaint(dark, 7.3f, bold = false)
        val tiny = textPaint(dark, 6.2f, bold = true)

        canvas.drawRect(RectF(22f, 22f, PAGE_WIDTH - 22f, PAGE_HEIGHT - 22f), border)
        canvas.drawText("PLÁN DELENIA ZVITKU", 34f, 52f, title)
        canvas.drawText("STAVBA: ${project.name}", 34f, 70f, subtitle)
        canvas.drawText(
            "ZVITOK ${plan.coilWidthMm} mm  |  ${page.materialPlan.key.material}, " +
                "${page.materialPlan.key.ral}, hr. " +
                "${formatDecimal(page.materialPlan.key.thicknessMm, 2)} mm",
            34f,
            85f,
            subtitle
        )
        canvas.drawText("LIST $globalPageNumber/$totalPages", 510f, 52f, subtitle)
        canvas.drawText(
            "Červená: pozdĺžny rez  |  oranžová: priečny rez  |  sivá: nevyužitý plech",
            34f,
            101f,
            small
        )

        val blockTop = 116f
        val blockHeight = 214f
        page.runs.forEachIndexed { localIndex, run ->
            drawRun(
                canvas = canvas,
                run = run,
                runNumber = page.firstRunNumber + localIndex,
                coilWidthMm = plan.coilWidthMm,
                top = blockTop + localIndex * blockHeight,
                border = border,
                sectionPaint = section,
                smallPaint = small,
                tinyPaint = tiny,
                longitudinalColor = red,
                transverseColor = orange
            )
        }

        canvas.drawText(
            "Poznámka: dĺžka je znázornená pomerne v každej zostave; záväzné sú uvedené kóty v mm.",
            34f,
            781f,
            small
        )
        canvas.drawText(
            "Najviac ${MAX_LONGITUDINAL_KNIVES} pozdĺžne nože / ${MAX_LANES_PER_RUN} pásy v jednej zostave.",
            34f,
            796f,
            small
        )
    }

    private fun drawRun(
        canvas: Canvas,
        run: CoilCutRun,
        runNumber: Int,
        coilWidthMm: Int,
        top: Float,
        border: Paint,
        sectionPaint: Paint,
        smallPaint: Paint,
        tinyPaint: Paint,
        longitudinalColor: Int,
        transverseColor: Int
    ) {
        val x = 40f
        val y = top + 34f
        val width = 515f
        val height = 132f
        val used = run.usedWidthMm
        val waste = (coilWidthMm - used).coerceAtLeast(0)
        canvas.drawText(
            "ZOSTAVA $runNumber  -  odvinúť ${run.lengthMm} mm",
            x,
            top + 12f,
            sectionPaint
        )
        canvas.drawText(
            "pásy ${run.lanes.size}  |  kusy ${run.units.size}  |  použité $used mm  |  " +
                "zvyšok $waste mm  |  " +
                "pozdĺžne nože ${run.longitudinalKnifeCount(coilWidthMm)}",
            x,
            top + 26f,
            smallPaint
        )

        canvas.drawRect(RectF(x, y, x + width, y + height), border)
        val colors = intArrayOf(
            Color.rgb(221, 237, 255),
            Color.rgb(220, 245, 232),
            Color.rgb(255, 230, 213),
            Color.rgb(240, 230, 255)
        )
        var laneX = x
        run.lanes.forEachIndexed { index, lane ->
            val laneWidth = width * lane.widthMm / coilWidthMm.toFloat()
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colors[index % colors.size]
                style = Paint.Style.FILL
            }
            val transverse = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = transverseColor
                strokeWidth = 1.7f
            }
            var partY = y
            lane.units.forEach { unit ->
                val partHeight = height * unit.lengthMm / max(1, run.lengthMm).toFloat()
                val part = RectF(laneX, partY, laneX + laneWidth, partY + partHeight)
                canvas.drawRect(part, fill)
                if (partHeight >= 17f) {
                    drawCenteredFittedText(
                        canvas,
                        unit.identifier,
                        RectF(part.left + 2f, part.top + 2f, part.right - 2f, part.top + 17f),
                        tinyPaint
                    )
                }
                if (partHeight >= 31f) {
                    drawCenteredFittedText(
                        canvas,
                        "${unit.widthMm} x ${unit.lengthMm}",
                        RectF(part.left + 2f, part.top + 16f, part.right - 2f, part.top + 31f),
                        tinyPaint
                    )
                }
                if (partHeight >= 45f) {
                    drawCenteredFittedText(
                        canvas,
                        "kus ${unit.pieceNumber}",
                        RectF(part.left + 2f, part.top + 30f, part.right - 2f, part.top + 45f),
                        tinyPaint
                    )
                }
                partY += partHeight
                canvas.drawLine(laneX, partY, laneX + laneWidth, partY, transverse)
            }
            if (partY < y + height - 0.5f) {
                val tailWaste = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.rgb(230, 234, 236)
                    style = Paint.Style.FILL
                }
                canvas.drawRect(RectF(laneX, partY, laneX + laneWidth, y + height), tailWaste)
            }
            canvas.drawRect(RectF(laneX, y, laneX + laneWidth, y + height), border)
            laneX += laneWidth
            if (index < run.lanes.lastIndex || used < coilWidthMm) {
                val longitudinal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = longitudinalColor
                    strokeWidth = 1.7f
                }
                canvas.drawLine(laneX, y, laneX, y + height, longitudinal)
            }
        }

        if (waste > 0) {
            val wastePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(230, 234, 236)
                style = Paint.Style.FILL
            }
            canvas.drawRect(RectF(laneX, y, x + width, y + height), wastePaint)
            canvas.drawRect(RectF(laneX, y, x + width, y + height), border)
            drawCenteredFittedText(
                canvas,
                "ZVYŠOK $waste mm",
                RectF(laneX + 2f, y + 48f, x + width - 2f, y + 74f),
                tinyPaint
            )
        }
        canvas.drawText("šírka zvitku $coilWidthMm mm", x, y + height + 15f, smallPaint)
        canvas.drawText("SMER ODVÍJANIA ↓", x + width - 94f, y + height + 15f, smallPaint)
    }

    private fun drawSummaryPage(
        canvas: Canvas,
        project: ProjectRecord,
        plan: CoilCutPlan,
        summaryIndex: Int,
        globalPageNumber: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)
        val dark = Color.rgb(25, 42, 55)
        val muted = Color.rgb(81, 98, 110)
        val blue = Color.rgb(8, 119, 201)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(55, 70, 80)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val title = textPaint(dark, 17f, bold = true)
        val subtitle = textPaint(muted, 8f, bold = true)
        val label = textPaint(muted, 6.5f, bold = true)
        val value = textPaint(dark, 9.5f, bold = true)
        val tableHeader = textPaint(Color.WHITE, 6.1f, bold = true)
        val tableText = textPaint(dark, 6.2f, bold = false)
        val tableBold = textPaint(dark, 6.2f, bold = true)

        canvas.drawRect(RectF(22f, 22f, PAGE_WIDTH - 22f, PAGE_HEIGHT - 22f), border)
        canvas.drawText("KONTROLNÁ SPRÁVA A CENOVÝ SÚHRN", 34f, 51f, title)
        canvas.drawText("STAVBA: ${project.name}", 34f, 69f, subtitle)
        canvas.drawText("LIST $globalPageNumber/$totalPages", 510f, 51f, subtitle)

        val boxes = listOf(
            Triple("POTREBNÝ ZVITOK", "${formatDecimal(plan.totalCoilLengthM)} bm", 34f),
            Triple("PLOCHA ZVITKU", "${formatDecimal(plan.totalCoilAreaM2)} m²", 174f),
            Triple("VYUŽITIE", "${formatDecimal(plan.utilizationPercent, 1)} %", 314f),
            Triple("ODPAD", "${formatDecimal(plan.totalWasteAreaM2)} m²", 454f),
            Triple("CENA PLECHU", "${formatDecimal(plan.totalMaterialPriceEur)} €", 34f),
            Triple("METRE OHYBOV", "${formatDecimal(plan.totalBendingMeters)} m", 174f),
            Triple("METRE REZANIA", "${formatDecimal(plan.totalCuttingMeters)} m", 314f),
            Triple("VÝROBA SPOLU", "${formatDecimal(plan.totalProductionCostEur)} €", 454f)
        )
        boxes.forEachIndexed { index, (boxLabel, boxValue, _) ->
            val left = 34f + (index % 4) * 134f
            val top = if (index < 4) 88f else 142f
            val rect = RectF(left, top, left + 125f, top + 44f)
            canvas.drawRect(rect, border)
            canvas.drawText(boxLabel, rect.left + 7f, rect.top + 13f, label)
            canvas.drawText(boxValue, rect.left + 7f, rect.top + 34f, value)
        }

        canvas.drawText(
            "Sadzby: ohýbanie ${formatDecimal(BENDING_PRICE_EUR_PER_M)} €/m, " +
                "rezanie ${formatDecimal(CUTTING_PRICE_EUR_PER_M)} €/m, " +
                "plech ${formatDecimal(DEFAULT_SHEET_PRICE_EUR_PER_KG)} €/kg bez DPH.",
            34f,
            205f,
            subtitle
        )

        val columns = floatArrayOf(34f, 91f, 214f, 239f, 277f, 311f, 359f, 403f, 447f, 491f, 561f)
        val headers = arrayOf("ID", "VÝROBOK", "KS", "R.Š.", "OHYB", "m OHYB", "m REZ", "OHYB €", "REZ €", "VÝROBA €")
        val headerTop = 220f
        val headerBottom = 242f
        val headerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = blue
            style = Paint.Style.FILL
        }
        for (index in headers.indices) {
            val cell = RectF(columns[index], headerTop, columns[index + 1], headerBottom)
            canvas.drawRect(cell, headerFill)
            canvas.drawRect(cell, border)
            drawCenteredFittedText(canvas, headers[index], cell, tableHeader)
        }

        val pageProducts = plan.productCosts.drop(summaryIndex * PRODUCTS_PER_SUMMARY_PAGE)
            .take(PRODUCTS_PER_SUMMARY_PAGE)
        val rowHeight = 26f
        pageProducts.forEachIndexed { row, product ->
            val values = arrayOf(
                product.identifier,
                product.name,
                product.quantity.toString(),
                product.blankWidthMm.toString(),
                product.bends.toString(),
                formatDecimal(product.bendingMeters),
                formatDecimal(product.cuttingMeters),
                formatDecimal(product.bendingCostEur),
                formatDecimal(product.cuttingCostEur),
                formatDecimal(product.productionCostEur)
            )
            val top = headerBottom + row * rowHeight
            values.forEachIndexed { column, text ->
                val cell = RectF(columns[column], top, columns[column + 1], top + rowHeight)
                canvas.drawRect(cell, border)
                drawCenteredFittedText(
                    canvas,
                    text,
                    RectF(cell.left + 2f, cell.top, cell.right - 2f, cell.bottom),
                    if (column == 0 || column == 9) tableBold else tableText
                )
            }
        }

        val materialTop = 574f
        canvas.drawText("SPOTREBA PODĽA ZVITKOV", 34f, materialTop, subtitle)
        var y = materialTop + 12f
        plan.materialPlans.take(6).forEachIndexed { index, material ->
            val line = "${index + 1}. ${material.key.material}, ${material.key.ral}, " +
                "hr. ${formatDecimal(material.key.thicknessMm, 2)} mm  |  " +
                "${formatDecimal(material.requiredLengthM)} bm  |  " +
                "${formatDecimal(material.grossAreaM2)} m²  |  " +
                "${formatDecimal(material.grossWeightKg)} kg  |  " +
                "${formatDecimal(material.materialPriceEur)} €"
            canvas.drawText(line, 34f, y, tableText)
            y += 15f
        }

        canvas.drawText(
            "Pozdĺžne rezanie: ${formatDecimal(plan.totalLongitudinalCutMeters)} m  |  " +
                "priečne rezanie: ${formatDecimal(plan.totalTransverseCutMeters)} m",
            34f,
            700f,
            value
        )
        canvas.drawText(
            "Ohýbanie: ${formatDecimal(plan.totalBendingCostEur)} €  |  " +
                "rezanie: ${formatDecimal(plan.totalCuttingCostEur)} €  |  " +
                "plech: ${formatDecimal(plan.totalMaterialPriceEur)} €",
            34f,
            720f,
            value
        )
        canvas.drawText(
            "CELKOM PLECH + VÝROBA: ${formatDecimal(plan.totalCostEur)} € bez DPH",
            34f,
            747f,
            textPaint(dark, 12f, bold = true)
        )
        canvas.drawText(
            "Výpočet je výrobný plán a orientačná kalkulácia; obsluha pred delením overí materiál, RAL, hrúbku a smer laku.",
            34f,
            782f,
            tableText
        )
    }

    private fun cuttingPages(plan: CoilCutPlan): List<CuttingPage> =
        plan.materialPlans.flatMap { materialPlan ->
            materialPlan.runs.chunked(RUNS_PER_PAGE).mapIndexed { pageIndex, runs ->
                CuttingPage(
                    materialPlan = materialPlan,
                    runs = runs,
                    firstRunNumber = pageIndex * RUNS_PER_PAGE + 1
                )
            }
        }

    private fun summaryPageCount(plan: CoilCutPlan): Int {
        if (!plan.includeSummary) return 0
        return ceil(plan.productCosts.size / PRODUCTS_PER_SUMMARY_PAGE.toDouble())
            .toInt()
            .coerceAtLeast(1)
    }

    private fun textPaint(color: Int, size: Float, bold: Boolean) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun drawCenteredFittedText(
        canvas: Canvas,
        text: String,
        area: RectF,
        sourcePaint: Paint
    ) {
        val paint = Paint(sourcePaint).apply { textAlign = Paint.Align.CENTER }
        var value = text
        while (value.length > 2 && paint.measureText(value) > area.width()) {
            value = value.dropLast(2) + "…"
        }
        val baseline = area.centerY() - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(value, area.centerX(), baseline, paint)
    }

    private data class CuttingPage(
        val materialPlan: CoilMaterialPlan,
        val runs: List<CoilCutRun>,
        val firstRunNumber: Int
    )
}
