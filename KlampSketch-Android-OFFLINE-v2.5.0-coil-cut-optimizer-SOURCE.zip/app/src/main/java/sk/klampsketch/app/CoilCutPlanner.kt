package sk.klampsketch.app

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

const val BENDING_PRICE_EUR_PER_M = 0.50
const val CUTTING_PRICE_EUR_PER_M = 0.50
const val MAX_LONGITUDINAL_KNIVES = 3
const val MAX_LANES_PER_RUN = MAX_LONGITUDINAL_KNIVES + 1

data class CoilMaterialKey(
    val material: String,
    val ral: String,
    val thicknessMicrons: Int
) {
    val thicknessMm: Double get() = thicknessMicrons / 1000.0
}

data class CoilCutUnit(
    val drawingId: Long,
    val identifier: String,
    val name: String,
    val pieceNumber: Int,
    val widthMm: Int,
    val lengthMm: Int,
    val bends: Int
) {
    val areaM2: Double get() = widthMm * lengthMm / 1_000_000.0
}

data class CoilCutLane(
    val units: List<CoilCutUnit>
) {
    init {
        require(units.isNotEmpty()) { "Pás delenia nesmie byť prázdny." }
        require(units.all { it.widthMm == units.first().widthMm }) {
            "V jednom pozdĺžnom páse musia mať všetky kusy rovnakú šírku."
        }
    }

    val widthMm: Int get() = units.first().widthMm
    val lengthMm: Int get() = units.sumOf { it.lengthMm }
    val netAreaM2: Double get() = units.sumOf { it.areaM2 }
}

data class CoilCutRun(
    val lanes: List<CoilCutLane>
) {
    val units: List<CoilCutUnit> get() = lanes.flatMap { it.units }
    val usedWidthMm: Int get() = lanes.sumOf { it.widthMm }
    val lengthMm: Int get() = lanes.maxOfOrNull { it.lengthMm } ?: 0
    val netAreaM2: Double get() = lanes.sumOf { it.netAreaM2 }

    fun longitudinalKnifeCount(coilWidthMm: Int): Int {
        if (lanes.isEmpty()) return 0
        val internalCuts = (lanes.size - 1).coerceAtLeast(0)
        val wasteEdgeCut = if (usedWidthMm < coilWidthMm) 1 else 0
        return internalCuts + wasteEdgeCut
    }

    fun longitudinalCutMeters(coilWidthMm: Int): Double =
        longitudinalKnifeCount(coilWidthMm) * lengthMm / 1000.0

    val transverseCutMeters: Double get() =
        lanes.sumOf { lane -> lane.widthMm * lane.units.size } / 1000.0
}

data class CoilMaterialPlan(
    val key: CoilMaterialKey,
    val runs: List<CoilCutRun>,
    val coilWidthMm: Int,
    val arealWeightKgM2: Double
) {
    val requiredLengthM: Double get() = runs.sumOf { it.lengthMm } / 1000.0
    val grossAreaM2: Double get() = requiredLengthM * coilWidthMm / 1000.0
    val netAreaM2: Double get() = runs.sumOf { it.netAreaM2 }
    val wasteAreaM2: Double get() = (grossAreaM2 - netAreaM2).coerceAtLeast(0.0)
    val utilizationPercent: Double get() =
        if (grossAreaM2 <= 0.0) 0.0 else netAreaM2 / grossAreaM2 * 100.0
    val grossWeightKg: Double get() = grossAreaM2 * arealWeightKgM2
    val materialPriceEur: Double get() =
        grossWeightKg * DEFAULT_SHEET_PRICE_EUR_PER_KG
    val longitudinalCutMeters: Double get() =
        runs.sumOf { it.longitudinalCutMeters(coilWidthMm) }
    val transverseCutMeters: Double get() = runs.sumOf { it.transverseCutMeters }
}

data class CoilProductCost(
    val drawingId: Long,
    val identifier: String,
    val name: String,
    val quantity: Int,
    val blankWidthMm: Int,
    val profileLengthM: Double,
    val bends: Int,
    val bendingMeters: Double,
    val longitudinalCutMeters: Double,
    val transverseCutMeters: Double
) {
    val cuttingMeters: Double get() = longitudinalCutMeters + transverseCutMeters
    val bendingCostEur: Double get() = bendingMeters * BENDING_PRICE_EUR_PER_M
    val cuttingCostEur: Double get() = cuttingMeters * CUTTING_PRICE_EUR_PER_M
    val productionCostEur: Double get() = bendingCostEur + cuttingCostEur
    val productionCostPerPieceEur: Double get() =
        if (quantity <= 0) 0.0 else productionCostEur / quantity
}

data class CoilCutPlan(
    val coilWidthMm: Int,
    val includeSummary: Boolean,
    val materialPlans: List<CoilMaterialPlan>,
    val productCosts: List<CoilProductCost>
) {
    val totalCoilLengthM: Double get() = materialPlans.sumOf { it.requiredLengthM }
    val totalCoilAreaM2: Double get() = materialPlans.sumOf { it.grossAreaM2 }
    val totalNetAreaM2: Double get() = materialPlans.sumOf { it.netAreaM2 }
    val totalWasteAreaM2: Double get() = materialPlans.sumOf { it.wasteAreaM2 }
    val totalMaterialPriceEur: Double get() = materialPlans.sumOf { it.materialPriceEur }
    val totalBendingMeters: Double get() = productCosts.sumOf { it.bendingMeters }
    val totalLongitudinalCutMeters: Double get() =
        productCosts.sumOf { it.longitudinalCutMeters }
    val totalTransverseCutMeters: Double get() =
        productCosts.sumOf { it.transverseCutMeters }
    val totalCuttingMeters: Double get() = productCosts.sumOf { it.cuttingMeters }
    val totalBendingCostEur: Double get() = productCosts.sumOf { it.bendingCostEur }
    val totalCuttingCostEur: Double get() = productCosts.sumOf { it.cuttingCostEur }
    val totalProductionCostEur: Double get() = productCosts.sumOf { it.productionCostEur }
    val totalCostEur: Double get() = totalMaterialPriceEur + totalProductionCostEur
    val utilizationPercent: Double get() =
        if (totalCoilAreaM2 <= 0.0) 0.0 else totalNetAreaM2 / totalCoilAreaM2 * 100.0
}

object CoilCutPlanner {
    fun createPlan(
        drawings: List<DrawingRecord>,
        coilWidthMm: Int,
        includeSummary: Boolean
    ): CoilCutPlan {
        require(coilWidthMm == 1000 || coilWidthMm == 1250) {
            "Podporovaná šírka zvitku je 1000 alebo 1250 mm."
        }
        require(drawings.isNotEmpty()) { "Nie sú vybrané žiadne výrobky." }

        val unitsByDrawing = drawings.associate { drawing ->
            val metrics = calculateMetrics(drawing)
            require(metrics.blankWidthMm <= coilWidthMm) {
                "${drawing.identifier} potrebuje pás ${metrics.blankWidthMm} mm, " +
                    "ktorý sa nezmestí do zvitku $coilWidthMm mm."
            }
            val lengthMm = (drawing.profileLengthM * 1000.0).roundToInt().coerceAtLeast(1)
            drawing.id to List(drawing.quantity.coerceAtLeast(1)) { pieceIndex ->
                CoilCutUnit(
                    drawingId = drawing.id,
                    identifier = drawing.identifier,
                    name = drawing.name,
                    pieceNumber = pieceIndex + 1,
                    widthMm = metrics.blankWidthMm,
                    lengthMm = lengthMm,
                    bends = metrics.bends
                )
            }
        }

        val groupedDrawings = drawings.groupBy { drawing ->
            CoilMaterialKey(
                material = drawing.material,
                ral = drawing.ral,
                thicknessMicrons = (drawing.thicknessMm * 1000.0).roundToInt()
            )
        }
        val materialPlans = groupedDrawings.map { (key, groupDrawings) ->
            val units = groupDrawings.flatMap { unitsByDrawing.getValue(it.id) }
            CoilMaterialPlan(
                key = key,
                runs = optimizeRuns(units, coilWidthMm),
                coilWidthMm = coilWidthMm,
                arealWeightKgM2 = materialArealWeightKgM2(groupDrawings.first())
            )
        }.sortedWith(
            compareBy<CoilMaterialPlan> { it.key.material }
                .thenBy { it.key.ral }
                .thenBy { it.key.thicknessMicrons }
        )

        val longitudinalByDrawing = mutableMapOf<Long, Double>()
        val transverseByDrawing = mutableMapOf<Long, Double>()
        materialPlans.forEach { materialPlan ->
            materialPlan.runs.forEach { run ->
                val runLengthM = run.lengthMm / 1000.0
                run.lanes.forEachIndexed { laneIndex, lane ->
                    var laneBoundaryFactor = 0.0
                    if (laneIndex > 0) laneBoundaryFactor += 0.5
                    if (laneIndex < run.lanes.lastIndex) laneBoundaryFactor += 0.5
                    if (laneIndex == run.lanes.lastIndex && run.usedWidthMm < coilWidthMm) {
                        laneBoundaryFactor += 1.0
                    }
                    val allocatedLaneLongitudinal = runLengthM * laneBoundaryFactor
                    lane.units.forEach { unit ->
                        val unitShare = unit.lengthMm / lane.lengthMm.toDouble()
                        longitudinalByDrawing[unit.drawingId] =
                            longitudinalByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                allocatedLaneLongitudinal * unitShare
                        transverseByDrawing[unit.drawingId] =
                            transverseByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                unit.widthMm / 1000.0
                    }
                }
            }
        }

        val costs = drawings.map { drawing ->
            val metrics = calculateMetrics(drawing)
            val quantity = drawing.quantity.coerceAtLeast(1)
            CoilProductCost(
                drawingId = drawing.id,
                identifier = drawing.identifier,
                name = drawing.name,
                quantity = quantity,
                blankWidthMm = metrics.blankWidthMm,
                profileLengthM = drawing.profileLengthM,
                bends = metrics.bends,
                bendingMeters = drawing.profileLengthM * metrics.bends * quantity,
                longitudinalCutMeters = longitudinalByDrawing.getOrDefault(drawing.id, 0.0),
                transverseCutMeters = transverseByDrawing.getOrDefault(drawing.id, 0.0)
            )
        }

        val expectedUnitCount = unitsByDrawing.values.sumOf { it.size }
        val plannedUnitCount = materialPlans.sumOf { material ->
            material.runs.sumOf { run -> run.units.size }
        }
        check(plannedUnitCount == expectedUnitCount) {
            "Kontrola delenia zlyhala: počet naplánovaných kusov nesúhlasí."
        }
        materialPlans.forEach { material ->
            material.runs.forEach { run ->
                check(run.usedWidthMm <= coilWidthMm) {
                    "Kontrola delenia zlyhala: prekročená šírka zvitku."
                }
                check(run.longitudinalKnifeCount(coilWidthMm) <= MAX_LONGITUDINAL_KNIVES) {
                    "Kontrola delenia zlyhala: prekročený počet pozdĺžnych nožov."
                }
            }
        }

        return CoilCutPlan(
            coilWidthMm = coilWidthMm,
            includeSummary = includeSummary,
            materialPlans = materialPlans,
            productCosts = costs
        )
    }

    private fun optimizeRuns(
        units: List<CoilCutUnit>,
        coilWidthMm: Int
    ): List<CoilCutRun> {
        if (units.isEmpty()) return emptyList()
        val orders = listOf(
            units.sortedWith(
                compareByDescending<CoilCutUnit> { it.lengthMm }
                    .thenByDescending { it.widthMm }
            ),
            units.sortedWith(
                compareByDescending<CoilCutUnit> { it.widthMm }
                    .thenByDescending { it.lengthMm }
            ),
            units.sortedWith(
                compareByDescending<CoilCutUnit> { it.widthMm.toLong() * it.lengthMm }
                    .thenByDescending { it.lengthMm }
            ),
            units.sortedWith(
                compareByDescending<CoilCutUnit> { max(it.widthMm, it.lengthMm) }
                    .thenByDescending { it.widthMm }
            )
        )
        return orders.map { pack(it, coilWidthMm) }
            .minWithOrNull(
                compareBy<List<CoilCutRun>> { candidate -> candidate.sumOf { it.lengthMm } }
                    .thenBy { candidate ->
                        candidate.sumOf {
                            coilWidthMm.toLong() * it.lengthMm -
                                it.units.sumOf { unit -> unit.widthMm.toLong() * unit.lengthMm }
                        }
                    }
                    .thenBy { it.size }
            )
            .orEmpty()
    }

    private fun pack(
        orderedUnits: List<CoilCutUnit>,
        coilWidthMm: Int
    ): List<CoilCutRun> {
        val runs = mutableListOf<CoilCutRun>()
        orderedUnits.forEach { unit ->
            val placements = mutableListOf<Placement>()
            val standaloneRun = CoilCutRun(listOf(CoilCutLane(listOf(unit))))
            placements += Placement(
                runIndex = -1,
                updatedRun = standaloneRun,
                score = placementScore(CoilCutRun(emptyList()), standaloneRun, coilWidthMm)
            )
            runs.forEachIndexed { runIndex, run ->
                run.lanes.forEachIndexed { laneIndex, lane ->
                    if (lane.widthMm == unit.widthMm) {
                        val updatedLanes = run.lanes.toMutableList().apply {
                            this[laneIndex] = lane.copy(units = lane.units + unit)
                        }
                        val updatedRun = run.copy(lanes = updatedLanes)
                        placements += Placement(
                            runIndex,
                            updatedRun,
                            placementScore(run, updatedRun, coilWidthMm)
                        )
                    }
                }

                val newLaneRun = run.copy(
                    lanes = run.lanes + CoilCutLane(listOf(unit))
                )
                if (
                    newLaneRun.lanes.size <= MAX_LANES_PER_RUN &&
                    newLaneRun.usedWidthMm <= coilWidthMm &&
                    newLaneRun.longitudinalKnifeCount(coilWidthMm) <=
                    MAX_LONGITUDINAL_KNIVES
                ) {
                    placements += Placement(
                        runIndex,
                        newLaneRun,
                        placementScore(run, newLaneRun, coilWidthMm)
                    )
                }
            }

            val best = placements.minByOrNull { it.score }
            if (best == null || best.runIndex < 0) {
                runs += standaloneRun
            } else {
                runs[best.runIndex] = best.updatedRun
            }
        }
        return runs.map { run ->
            run.copy(
                lanes = run.lanes.sortedWith(
                    compareByDescending<CoilCutLane> { it.widthMm }
                        .thenByDescending { it.lengthMm }
                )
            )
        }
    }

    private fun placementScore(
        oldRun: CoilCutRun,
        newRun: CoilCutRun,
        coilWidthMm: Int
    ): Double {
        val remainingWidth = coilWidthMm - newRun.usedWidthMm
        val laneImbalance = newRun.lanes.sumOf { newRun.lengthMm - it.lengthMm }
        return (newRun.lengthMm - oldRun.lengthMm).toDouble() * coilWidthMm +
            remainingWidth * 0.05 +
            laneImbalance * 0.20
    }

    private data class Placement(
        val runIndex: Int,
        val updatedRun: CoilCutRun,
        val score: Double
    )
}
