package sk.strechasketch.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.util.LruCache
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.hypot
import kotlin.math.roundToInt

@SuppressLint("SetTextI18n")
class MainActivity : Activity() {
    private lateinit var store: ProjectStore
    private var currentProject: RoofProject? = null
    private var editorView: RoofMapEditorView? = null
    private var editorStatus: TextView? = null
    private var editorMetrics: TextView? = null
    private var active3DView: Roof3DView? = null
    private var active3DDimensionOverlay: Roof3DDimensionOverlay? = null
    private var activeMapHost: FreeRoofMapHost? = null
    private data class ModelUndoState(
        val graph: RoofGraph?,
        val topology: RoofTopology?,
        val wallHeightM: Double,
        val atticHeightM: Double,
        val slopeDeg: Double,
        val wallFootprint: List<GeoPoint>,
        val objects: List<RoofObject>? = null,
        val polygon: List<GeoPoint>? = null
    )
    private var last3DUndo: ModelUndoState? = null
    private var next3DDimensionWheelHighlightId: String? = null
    private var lastChanged3DDimensionId: String? = null
    private var lastChanged3DDimensionUntilMs = 0L
    private var screen = Screen.HOME
    private var workspaceNavigationScrollX = 0
    private var pendingExport: ByteArray? = null
    private var pendingExportName = ""
    private val projectPreviewExecutor: ExecutorService = Executors.newFixedThreadPool(2)
    private val projectPreviewCache = LruCache<String, Bitmap>(12)
    private var homePreviewGeneration = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BRAND_DARK
        window.navigationBarColor = BRAND_DARK
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        workspaceNavigationScrollX = savedInstanceState?.getInt(STATE_WORKSPACE_NAV_SCROLL_X) ?: 0
        store = ProjectStore(this)
        showHome()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(STATE_WORKSPACE_NAV_SCROLL_X, workspaceNavigationScrollX)
        super.onSaveInstanceState(outState)
    }

    override fun onPause() {
        active3DView?.onPause()
        activeMapHost?.onPause()
        currentProject?.let(store::save)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        active3DView?.onResume()
        activeMapHost?.onResume()
    }

    override fun onLowMemory() {
        activeMapHost?.onLowMemory()
        super.onLowMemory()
    }

    override fun onDestroy() {
        activeMapHost?.onDestroy()
        projectPreviewExecutor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.HOME -> super.onBackPressed()
            Screen.EDITOR -> showHome()
            Screen.THREE_D, Screen.SUMMARY, Screen.WORK_SCOPE, Screen.PDF -> currentProject?.let(::showEditor) ?: showHome()
        }
    }

    private fun showHome() {
        screen = Screen.HOME
        val previewGeneration = ++homePreviewGeneration
        last3DUndo = null
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        editorView = null
        val root = verticalRoot()
        root.addView(appBar("StrechoStav Sketch", null))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = rounded(Color.rgb(237, 248, 237), 0f, stroke = Color.rgb(200, 223, 202))
        }
        hero.addView(label("Strecha od mapy po 3D model", 23f, true, INK))
        hero.addView(label(
            "Vyhľadajte stavbu, importujte alebo obkreslite obrys, doplňte klampiarske prvky a exportujte technický nákres.",
            14f, false, MUTED
        ).apply { setPadding(0, dp(7), 0, dp(12)) })
        val heroActions = row()
        heroActions.addView(actionButton("Nový projekt", BRAND) { showNewProjectDialog() })
        heroActions.addView(actionButton("Import JSON", Color.rgb(56, 76, 88)) { openJsonImport() })
        hero.addView(heroActions)
        root.addView(hero)

        val title = label("Uložené projekty", 18f, true, INK).apply {
            setPadding(dp(18), dp(18), dp(18), dp(8))
        }
        root.addView(title)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(28))
        }
        val projects = store.list()
        if (projects.isEmpty()) {
            list.addView(label(
                "Zatiaľ nemáte žiadny projekt. Začnite tlačidlom „Nový projekt“.",
                16f, false, MUTED
            ).apply {
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(70), dp(24), dp(70))
            })
        } else {
            projects.forEach { list.addView(projectCard(it, previewGeneration)) }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun projectCard(project: RoofProject, previewGeneration: Int): View {
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(Color.WHITE, 14f, stroke = Color.rgb(209, 220, 211))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(11)) }
            addView(row().apply {
                gravity = Gravity.TOP
                if (quantityAudit.faces.isNotEmpty()) {
                    addView(project3DPreview(project, previewGeneration))
                }
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(label(project.name, 19f, true, INK))
                    addView(label(
                        buildString {
                            if (project.customer.isNotBlank()) append(project.customer).append(" • ")
                            append(project.address.ifBlank { "Bez adresy" })
                            append("\n")
                            append("${format1(totals.footprintAreaM2)} m² • ${quantityAudit.faces.size} plôch • predvolený sklon ${format1(project.slopeDeg)}°")
                            append(" • ")
                            append(SimpleDateFormat("d. M. yyyy HH:mm", Locale("sk", "SK")).format(Date(project.updatedAt)))
                        },
                        13f, false, MUTED
                    ).apply { setPadding(0, dp(5), 0, dp(10)) })
                }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            })
            addView(row().apply {
                addView(actionButton("Otvoriť", BRAND) {
                    currentProject = project
                    showEditor(project)
                })
                addView(actionButton("Kópia", Color.rgb(62, 83, 96)) {
                    store.duplicate(project)
                    showHome()
                })
                addView(actionButton("Odstrániť", Color.rgb(150, 50, 45)) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Odstrániť projekt?")
                        .setMessage(project.name)
                        .setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Odstrániť") { _, _ ->
                            store.delete(project.id)
                            showHome()
                        }.show()
                })
            })
        }
    }

    private fun project3DPreview(project: RoofProject, previewGeneration: Int): ImageView {
        val cacheKey = "${project.id}:${project.updatedAt}"
        return ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            clipToOutline = true
            background = rounded(Color.rgb(241, 245, 243), 10f, stroke = Color.rgb(205, 216, 207))
            contentDescription = "Otvoriť 3D model projektu ${project.name}"
            layoutParams = LinearLayout.LayoutParams(dp(132), dp(104)).apply {
                setMargins(0, 0, dp(12), dp(8))
            }
            setOnClickListener {
                currentProject = project
                show3D(project)
            }
            projectPreviewCache.get(cacheKey)?.let(::setImageBitmap) ?: run {
                projectPreviewExecutor.execute {
                    val rendered = runCatching {
                        RoofBitmapRenderer.render(
                            project = project,
                            width = 528,
                            height = 416,
                            camera = RoofBitmapCamera(
                                yawDeg = -35.0,
                                pitchDeg = 28.0,
                                distance = 4.8,
                                paddingFraction = 0.025,
                                fitStructureOnly = true
                            ),
                            backgroundColor = Color.rgb(241, 245, 243),
                            showDimensions = false
                        )
                    }.getOrNull() ?: return@execute
                    projectPreviewCache.put(cacheKey, rendered)
                    runOnUiThread {
                        if (screen == Screen.HOME &&
                            homePreviewGeneration == previewGeneration &&
                            isAttachedToWindow
                        ) setImageBitmap(rendered)
                    }
                }
            }
        }
    }

    private fun showNewProjectDialog() {
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = edit("Názov projektu", "Strecha ${SimpleDateFormat("d.M.yyyy", Locale("sk", "SK")).format(Date())}")
        val customer = edit("Zákazník", "")
        val address = edit("Adresa alebo GPS", "")
        fields.addView(name)
        fields.addView(customer)
        fields.addView(address)
        AlertDialog.Builder(this)
            .setTitle("Nový projekt")
            .setView(fields)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Vytvoriť") { _, _ ->
                val project = RoofProject(
                    name = name.text.toString().trim().ifBlank { "Nová strecha" },
                    customer = customer.text.toString().trim(),
                    address = address.text.toString().trim()
                )
                store.save(project)
                currentProject = project
                showEditor(project)
            }.show()
    }

    private fun showEditor(project: RoofProject, workspaceTab: WorkspaceTab = WorkspaceTab.OUTLINE) {
        screen = Screen.EDITOR
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar(project.name) { showHome() })
        root.addView(workspaceNavigation(project, workspaceTab))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        val search = edit("Adresa alebo 49.123, 18.456", project.address).apply {
            setSingleLine()
            setPadding(dp(12), 0, dp(8), 0)
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f))
        searchRow.addView(compactButton("Nájsť") { resolveLocation(search.text.toString(), project) })
        searchRow.addView(compactButton("Budova") { importNearestBuilding(project) })
        searchRow.addView(compactButton("GPS") { useDeviceLocation() })
        if (workspaceTab == WorkspaceTab.OUTLINE) root.addView(searchRow)

        val settings = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(246, 248, 246))
        }
        val settingsRow = row().apply { setPadding(dp(8), dp(6), dp(8), dp(6)) }
        settingsRow.addView(label("Sklon °", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val slope = EditText(this).apply {
            inputType = InputType.TYPE_NULL
            isFocusable = false
            isClickable = true
            setText(format1(project.slopeDeg))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(slope, LinearLayout.LayoutParams(dp(72), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        val shapeSpinner = Spinner(this)
        shapeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            RoofShape.entries.map { it.label }
        )
        shapeSpinner.setSelection(RoofShape.entries.indexOf(project.shape))
        settingsRow.addView(label("3D podľa plôch", 13f, true, BRAND).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(14), 0)
        }, LinearLayout.LayoutParams(dp(150), dp(44)))
        settingsRow.addView(label("Steny m", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val wallHeight = EditText(this).apply {
            inputType = InputType.TYPE_NULL
            isFocusable = false
            isClickable = true
            setText(format1(project.wallHeightM))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(wallHeight, LinearLayout.LayoutParams(dp(76), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        settings.addView(settingsRow)
        if (workspaceTab == WorkspaceTab.OUTLINE) root.addView(settings)

        val tools = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(30, 62, 40))
        }
        val toolRow = row().apply { setPadding(dp(7), dp(5), dp(7), dp(5)) }
        tools.addView(toolRow)
        root.addView(tools)

        val mapFrame = FrameLayout(this)
        val mapHost = FreeRoofMapHost(this, project)
        activeMapHost = mapHost
        val map = mapHost.editor
        editorView = map
        map.setWorkspace(when (workspaceTab) {
            WorkspaceTab.OUTLINE -> EditorWorkspace.OUTLINE
            WorkspaceTab.INTERNAL -> EditorWorkspace.INTERNAL_LINES
            WorkspaceTab.SUPERSTRUCTURES -> EditorWorkspace.SUPERSTRUCTURES
            else -> EditorWorkspace.TYPOLOGY
        })
        mapFrame.addView(mapHost, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val zoomControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), dp(6), 0)
            addView(mapControlButton("+") { mapHost.zoomBy(1f) })
            addView(mapControlButton("−") { mapHost.zoomBy(-1f) })
            addView(mapControlButton("Celok") { mapHost.fitCurrent() })
            if (workspaceTab == WorkspaceTab.OUTLINE) addView(mapControlButton("Sever") { map.resetMapRotation() })
        }
        mapFrame.addView(
            zoomControls,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        )
        root.addView(mapFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val toolButtons = mutableListOf<Pair<Button, () -> Boolean>>()
        fun refreshToolButtons() {
            toolButtons.forEach { (button, isActive) ->
                applyActiveButtonStyle(button, isActive())
            }
        }
        fun tool(text: String, isActive: () -> Boolean = { false }, click: () -> Unit) {
            val button = actionButton(text, TOOL_INACTIVE) {
                click()
                refreshToolButtons()
            }
            toolButtons += button to isActive
            toolRow.addView(button)
        }
        when (workspaceTab) {
            WorkspaceTab.OUTLINE -> {
                tool("ZBGIS ortofoto", { !mapHost.isDocumentMode() }) {
                    mapHost.setMapType("ZBGIS_ORTHO")
                    store.save(project)
                }
                tool("Podklad z PDF/JPG", { mapHost.isDocumentMode() }) {
                    if (project.underlayUri.isBlank()) openUnderlayImport()
                    else AlertDialog.Builder(this)
                        .setTitle("Podklad z PDF/JPG")
                        .setItems(arrayOf("Zobraziť ${project.underlayName}", "Vybrať iný podklad")) { _, which ->
                            if (which == 0) {
                                mapHost.showDocument(Uri.parse(project.underlayUri), project.underlayMime, project.underlayName, false)
                                store.save(project)
                            } else openUnderlayImport()
                        }.show()
                }
                tool("Obrys prstom", { map.mode == EditorMode.DRAW_POLYGON }) { map.setMode(EditorMode.DRAW_POLYGON) }
                tool("Pridať bod") { map.addMidpointToSelectedEdge() }
                tool("Editovať", { map.mode == EditorMode.EDIT }) { map.setMode(EditorMode.EDIT) }
            }
            WorkspaceTab.INTERNAL -> {
                tool("Pridať líniu", { map.mode == EditorMode.ADD_LINE }) {
                    map.setMode(EditorMode.ADD_LINE, lineType = LineType.UNKNOWN)
                }
                tool("Editovať líniu", { map.mode == EditorMode.EDIT_LINES }) { map.setMode(EditorMode.EDIT_LINES) }
            }
            WorkspaceTab.TYPOLOGY -> {
                fun objectTool(text: String, type: ObjectType) = tool(
                    text,
                    { map.mode == EditorMode.ADD_OBJECT && map.activeObjectType == type }
                ) { map.setMode(EditorMode.ADD_OBJECT, objectType = type) }
                objectTool("Komín", ObjectType.CHIMNEY)
                objectTool("Strešné okno", ObjectType.ROOF_WINDOW)
                objectTool("Výlez", ObjectType.HATCH)
                objectTool("Prestup", ObjectType.VENT)
                objectTool("Vpusť", ObjectType.DRAIN)
                objectTool("Výšková kóta", ObjectType.HEIGHT_MARK)
                objectTool("Značka sklonu", ObjectType.SLOPE_MARK)
            }
            WorkspaceTab.SUPERSTRUCTURES -> {
                fun tile(text: String, active: () -> Boolean, click: () -> Unit) {
                    val button = actionButton(text, TOOL_INACTIVE) {
                        click()
                        refreshToolButtons()
                    }.apply {
                        textSize = 11f
                        minWidth = dp(126)
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(dp(126), dp(58)).apply {
                            setMargins(0, 0, dp(6), 0)
                        }
                    }
                    toolButtons += button to active
                    toolRow.addView(button)
                }
                fun dormerTile(type: DormerType) = tile(
                    type.label,
                    { map.mode == EditorMode.ADD_OBJECT && map.activeObjectType == ObjectType.DORMER && map.activeDormerType == type }
                ) { map.setDormerPlacement(type) }
                DormerType.entries.forEach(::dormerTile)
                fun objectTile(text: String, type: ObjectType) = tile(
                    text,
                    { map.mode == EditorMode.ADD_OBJECT && map.activeObjectType == type }
                ) { map.setMode(EditorMode.ADD_OBJECT, objectType = type) }
                objectTile("Strojovňa výťahu", ObjectType.MACHINE_ROOM)
                objectTile("Šachta", ObjectType.SHAFT)
                objectTile("Strešná terasa", ObjectType.TERRACE)
            }
            else -> Unit
        }
        mapHost.onEditorModeChanged = { refreshToolButtons() }
        mapHost.onBackgroundModeChanged = { refreshToolButtons() }
        refreshToolButtons()

        editorStatus = label("Posúvajte mapu alebo vyhľadajte adresu.", 12f, false, MUTED).apply {
            setPadding(dp(10), dp(5), dp(10), dp(4))
            setBackgroundColor(Color.WHITE)
        }
        editorMetrics = label("", 12f, true, INK).apply {
            setPadding(dp(10), dp(3), dp(10), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(editorStatus)
        root.addView(editorMetrics)

        val actionRow = row().apply {
            setPadding(dp(4), dp(3), dp(4), dp(4))
            setBackgroundColor(Color.rgb(238, 243, 238))
        }
        when (workspaceTab) {
            WorkspaceTab.OUTLINE -> {
                actionRow.addView(editorToolButton("Uzavrieť", R.drawable.ic_action_close, BRAND) { map.finishPolygon() })
                actionRow.addView(editorToolButton("Skorigovať obrys", R.drawable.ic_action_solve, BRAND) {
                    showSolverPreviewDialog(map)
                })
                actionRow.addView(editorToolButton("Odstrániť bod", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelectedPoint()
                })
            }
            WorkspaceTab.INTERNAL -> {
                actionRow.addView(editorToolButton("Skorigovať línie", R.drawable.ic_action_solve, BRAND) {
                    showSolverPreviewDialog(map)
                })
                actionRow.addView(editorToolButton("Odstrániť", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelection()
                })
            }
            WorkspaceTab.TYPOLOGY, WorkspaceTab.SUPERSTRUCTURES -> {
                actionRow.addView(editorToolButton("Späť", R.drawable.ic_action_close, Color.rgb(67, 91, 105)) { map.undo() })
                actionRow.addView(editorToolButton("Odstrániť prvok", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelection()
                })
            }
            else -> Unit
        }
        actionRow.addView(editorToolButton("Viac", R.drawable.ic_action_more, Color.rgb(67, 91, 105)) {
            val items = when (workspaceTab) {
                WorkspaceTab.OUTLINE -> arrayOf("Späť", "Znova", "Rozmer vybratej hrany", "Vyčistiť obrys", "Uložiť")
                WorkspaceTab.INTERNAL -> arrayOf(
                    "Späť", "Znova", "Pripojiť koniec k uzlu", "Odpojiť koniec",
                    "Rozdeliť líniu", "Odstrániť líniu", "Uložiť"
                )
                WorkspaceTab.TYPOLOGY -> arrayOf("Späť", "Znova", "Odstrániť technický prvok", "Uložiť")
                WorkspaceTab.SUPERSTRUCTURES -> arrayOf("Späť", "Znova", "Odstrániť vikier/strojovňu", "Uložiť")
                else -> emptyArray()
            }
            AlertDialog.Builder(this).setTitle("Nástroje").setItems(items) { _, which ->
                if (which == 0) map.undo()
                else if (which == 1) map.redo()
                else when (workspaceTab) {
                    WorkspaceTab.OUTLINE -> when (which) {
                        2 -> showEdgeLengthDialog(map, mapHost)
                        3 -> AlertDialog.Builder(this)
                            .setTitle("Vyčistiť celý nákres?")
                            .setNegativeButton("Zrušiť", null)
                            .setPositiveButton("Vyčistiť") { _, _ -> map.clearDrawing() }
                            .show()
                        4 -> {
                            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    WorkspaceTab.INTERNAL -> when (which) {
                        2 -> map.joinSelectedEndpointToNearest()
                        3 -> map.disconnectSelectedEndpoint()
                        4 -> map.splitSelectedLine()
                        5 -> map.deleteSelection()
                        6 -> {
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    WorkspaceTab.TYPOLOGY, WorkspaceTab.SUPERSTRUCTURES -> when (which) {
                        2 -> map.deleteSelection()
                        3 -> {
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    else -> Unit
                }
            }.show()
        })
        root.addView(actionRow)

        map.onProjectChanged = {
            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
            store.save(project)
            refreshEditorMetrics(project)
        }
        map.onBoundaryEdgeLongPressed = { edgeIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showEdgeSemanticDialog(map, project, boundaryIndex = edgeIndex)
        }
        map.onBoundaryDimensionLongPressed = {
            if (workspaceTab == WorkspaceTab.OUTLINE) showEdgeLengthDialog(map, mapHost)
        }
        map.onLineLongPressed = { lineIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showEdgeSemanticDialog(map, project, lineIndex = lineIndex)
        }
        map.onObjectLongPressed = { objectIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showObjectDimensionMenu(project, map, objectIndex)
        }
        map.onObjectAdded = { objectIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showObjectDimensionMenu(project, map, objectIndex)
        }
        map.onStatusChanged = { editorStatus?.text = it }
        mapHost.onStatusChanged = { editorStatus?.text = it }
        slope.setOnClickListener {
            showDimensionWheel(
                title = "Sklon strechy", description = "Nastavenie sklonu po 0,5°.",
                initial = project.slopeDeg, minimum = 0.0, maximum = 89.0,
                step = 0.5, unit = "°", decimals = 1,
                onCommit = { selected ->
                    project.slopeDeg = selected
                    slope.setText(format1(selected))
                    store.save(project)
                    refreshEditorMetrics(project)
                }
            )
        }
        wallHeight.setOnClickListener {
            showDimensionWheel(
                title = "Výška stien", description = "Spoločná výška obvodových stien.",
                initial = project.wallHeightM * 1000.0, minimum = 500.0, maximum = 100_000.0,
                step = 50.0, unit = " mm", decimals = 0,
                onCommit = { selected ->
                    project.wallHeightM = selected / 1000.0
                    wallHeight.setText(format1(project.wallHeightM))
                    store.save(project)
                    refreshEditorMetrics(project)
                }
            )
        }
        mapHost.onResume()
        shapeSpinner.onItemSelectedListener = simpleSelection {
            project.shape = RoofShape.entries[shapeSpinner.selectedItemPosition]
            store.save(project)
        }
        refreshEditorMetrics(project)
        setContentView(root)
    }

    private fun updateEditorSettings(project: RoofProject, slope: EditText, wallHeight: EditText, shape: Spinner) {
        project.slopeDeg = slope.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 75.0) ?: project.slopeDeg
        project.wallHeightM = wallHeight.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.5, 100.0) ?: project.wallHeightM
        project.shape = RoofShape.entries[shape.selectedItemPosition]
    }

    private fun refreshEditorMetrics(project: RoofProject) {
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        editorMetrics?.text = "Pôdorys ${format1(totals.footprintAreaM2)} m²  •  strecha ${format1(totals.roofAreaM2)} m²  •  obvod ${format1(totals.perimeterM)} m  •  ${project.polygon.size} bodov"
    }

    private fun resolveLocation(input: String, project: RoofProject) {
        val text = input.trim()
        if (text.isBlank()) {
            toast("Zadajte adresu alebo GPS súradnice.")
            return
        }
        parseCoordinates(text)?.let { point ->
            project.address = "${point.lat}, ${point.lon}"
            editorView?.setCenter(point)
            store.save(project)
            return
        }
        val loading = loadingDialog("Hľadám adresu…")
        GeoServices.geocode(text) { result ->
            loading.dismiss()
            result.onSuccess { place ->
                project.address = place.displayName
                editorView?.setCenter(place.point)
                store.save(project)
                editorStatus?.text = "Adresa nájdená: ${place.displayName}"
            }.onFailure { toast(it.message ?: "Adresu sa nepodarilo nájsť.") }
        }
    }

    private fun importNearestBuilding(project: RoofProject) {
        val center = GeoPoint(project.centerLat, project.centerLon)
        val loading = loadingDialog("Hľadám obrys budovy v OpenStreetMap…")
        GeoServices.nearestBuilding(center) { result ->
            loading.dismiss()
            result.onSuccess { building ->
                val details = buildString {
                    append("Plocha: ${format1(building.areaM2)} m²\n")
                    append("Vzdialenosť od stredu: ${format1(building.distanceM)} m\n")
                    append("OSM: ${building.buildingType} #${building.osmId}")
                    if (building.name.isNotBlank()) append("\n${building.name}")
                    if (project.polygon.isNotEmpty()) append("\n\nExistujúci nákres bude nahradený.")
                }
                AlertDialog.Builder(this)
                    .setTitle("Importovať najbližšiu budovu?")
                    .setMessage(details)
                    .setNegativeButton("Zrušiť", null)
                    .setPositiveButton("Importovať") { _, _ ->
                        editorView?.importPolygon(building.points)
                        store.save(project)
                    }.show()
            }.onFailure { toast(it.message ?: "Budova sa nenašla.") }
        }
    }

    private fun useDeviceLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }
        moveToLastLocation()
    }

    private fun moveToLastLocation() {
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { provider ->
                    runCatching {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        ) manager.getLastKnownLocation(provider) else null
                    }.getOrNull()
                }.maxByOrNull { it.time }
            if (location != null) {
                val point = GeoPoint(location.latitude, location.longitude)
                currentProject?.let {
                    it.address = "${point.lat}, ${point.lon}"
                    editorView?.setCenter(point, 20)
                    store.save(it)
                }
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Poloha nie je dostupná")
                    .setMessage("Zapnite polohu v telefóne alebo zadajte GPS súradnice ručne.")
                    .setNegativeButton("Zavrieť", null)
                    .setPositiveButton("Nastavenia") { _, _ ->
                        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }.show()
            }
        } catch (error: Exception) {
            toast(error.message ?: "Polohu sa nepodarilo načítať.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            moveToLastLocation()
        }
    }

    private fun pointInsideRoofFace(graph: RoofGraph, face: GraphFace, point: LocalPoint): Boolean {
        val outer = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        if (outer.size < 3 || !Geometry.pointInPolygon(point, outer)) return false
        return face.holeNodeIdLoops.none { loop ->
            val hole = loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
            hole.size >= 3 && Geometry.pointInPolygon(point, hole)
        }
    }

    private fun roofFaceAt(
        graph: RoofGraph,
        point: LocalPoint,
        preferredFaceId: String? = null
    ): GraphFace? {
        preferredFaceId?.let(graph.faces::get)?.takeIf { pointInsideRoofFace(graph, it, point) }
            ?.let { return it }
        return graph.faces.values.firstOrNull { pointInsideRoofFace(graph, it, point) }
    }

    private fun applyAutomaticChimneyHeight(
        project: RoofProject,
        item: RoofObject,
        preparedGraph: RoofGraph? = null
    ): Boolean {
        if (item.type != ObjectType.CHIMNEY) return false
        val graph = preparedGraph ?: Roof3DPreparation.prepare(project).graph
        val axis = Geometry.toLocal(item.center, graph.origin)
        val face = roofFaceAt(graph, axis, item.attachedFaceId) ?: return false
        val solved = ChimneyHeightSolver.applyAutomatic(
            graph = graph,
            face = face,
            chimneyAxis = axis,
            atticHeightM = project.atticHeightM,
            fallbackSlopeDeg = project.slopeDeg,
            chimney = item
        ) ?: return false
        item.attachedFaceId = face.id
        return solved.heightAboveRoofM.isFinite()
    }

    private fun snapRoofOpeningToHeadHeight(
        project: RoofProject,
        graph: RoofGraph,
        item: RoofObject,
        lateralReference: LocalPoint = Geometry.toLocal(item.center, graph.origin)
    ): Boolean {
        if (item.type !in setOf(ObjectType.ROOF_WINDOW, ObjectType.HATCH)) return false
        val face = roofFaceAt(graph, lateralReference, item.attachedFaceId) ?: return false
        val plane = face.plane ?: return false
        val solved = RoofOpeningPlacementSolver.solve(
            plane = plane,
            lateralReference = lateralReference,
            surfaceLengthM = item.heightMm.coerceAtLeast(100.0) / 1000.0,
            floorElevationM = project.wallHeightM
        ) ?: return false
        // The complete uphill span must remain on its host roof face. Lateral width is
        // constrained separately during dragging and never changes the 2.10 m head level.
        if (!pointInsideRoofFace(graph, face, solved.center) ||
            !pointInsideRoofFace(graph, face, solved.upperEdgeCenter) ||
            !pointInsideRoofFace(graph, face, solved.lowerEdgeCenter)
        ) return false
        item.center = Geometry.toGeo(solved.center, graph.origin)
        item.attachedFaceId = face.id
        return true
    }

    private fun show3D(
        project: RoofProject,
        objectMode: Boolean = false,
        rainwaterMode: Boolean = false
    ) {
        val preservedCameraState = if (screen == Screen.THREE_D) active3DView?.cameraState() else null
        if (project.polygon.size < 3) {
            toast("Najprv vytvorte uzavretý obrys strechy.")
            return
        }
        val prepared3D = Roof3DPreparation.prepare(project)
        val solvedTopology = prepared3D.topology
        val graph = prepared3D.graph
        if (graph.faces.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Chýbajú uzavreté strešné plochy")
                .setMessage("V karte Vnútorné línie spojte hrany do uzavretých plôch. Typ strechy sa nevyberá – 3D vzniká priamo z FaceId.")
                .setNegativeButton("Zavrieť", null)
                .setPositiveButton("Zobraziť v nákrese") { _, _ ->
                    showEditor(project, WorkspaceTab.INTERNAL)
                }
                .show()
            return
        }
        val planeSolution = prepared3D.planeSolution
        if (planeSolution.hasBlockingIssues) {
            AlertDialog.Builder(this)
                .setTitle("3D model nemožno bezpečne vytvoriť")
                .setMessage(planeSolution.issues.filter { it.blocking }.joinToString("\n\n") { "• ${it.message}" })
                .setNegativeButton("Zavrieť", null)
                .setPositiveButton("Otvoriť typológiu") { _, _ -> showEditor(project, WorkspaceTab.TYPOLOGY) }
                .show()
            return
        }
        project.roofTopology = solvedTopology
        project.roofGraph = planeSolution.graph
        project.objects.forEach { item ->
            snapRoofOpeningToHeadHeight(project, planeSolution.graph, item)
        }
        store.save(project)
        screen = Screen.THREE_D
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar(
            when {
                rainwaterMode -> "Žľaby a zvody • ${project.name}"
                objectMode -> "3D prvky • ${project.name}"
                else -> "3D geometria • ${project.name}"
            }
        ) { showEditor(project) }.apply {
            addView(compactButton("Reset") { active3DView?.resetView() })
            if (last3DUndo != null) addView(compactButton("Undo rozmer") {
                val undo = last3DUndo ?: return@compactButton
                undo.graph?.let { graph ->
                    RoofTopologyMigration.applyToProject(project, graph.toTopology(), requireFullyValid = false)
                    project.roofGraph = graph
                    project.roofTopology = undo.topology ?: graph.toTopology()
                }
                undo.polygon?.let { saved ->
                    project.polygon = saved.map(GeoPoint::copy).toMutableList()
                }
                project.wallHeightM = undo.wallHeightM
                project.atticHeightM = undo.atticHeightM
                project.slopeDeg = undo.slopeDeg
                project.wallFootprint = undo.wallFootprint.map(GeoPoint::copy).toMutableList()
                undo.objects?.let { saved ->
                    project.objects = saved.map { it.copy(center = it.center.copy()) }.toMutableList()
                }
                last3DUndo = null
                store.save(project)
                show3D(project, objectMode, rainwaterMode)
            })
        })
        root.addView(workspaceNavigation(
            project,
            when {
                rainwaterMode -> WorkspaceTab.RAINWATER
                objectMode -> WorkspaceTab.MODEL_OBJECTS
                else -> WorkspaceTab.MODEL_3D
            }
        ))
        val settings = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.WHITE)
        }
        settings.addView(label(
            if (rainwaterMode) {
                val rainwater = RainwaterDrainageSolver.solve(
                    planeSolution.graph,
                    project.wallFootprint.map { Geometry.toLocal(it, planeSolution.graph.origin) },
                    project.objects
                )
                "Odvodnenie: ${rainwater.gutters.size} žľabov • ${rainwater.downspouts.size} zvodov • " +
                    "${rainwater.gutterHooks.size} hákov • ${rainwater.downspoutClamps.size} objímok • " +
                    "spád 4 mm/m • max. rozstup zvodov 12 m"
            } else if (objectMode) {
                "3D prvky: ${project.objects.count { it.type in EDITABLE_3D_OBJECTS }}  •  okno/výlez: horná hrana 2,10 m nad podlahou, posun iba pozdĺž odkvapu"
            } else {
                "${planeSolution.graph.faces.size} plôch z RoofGraph  •  predvolený sklon ${format1(project.slopeDeg)}°  •  steny ${format1(project.wallHeightM)} m" +
                    if (planeSolution.issues.isNotEmpty()) "  •  doplniť constraints: ${planeSolution.issues.size}" else "  •  model určený"
            },
            13f, true, INK
        ))
        root.addView(settings)
        val view = Roof3DView(this)
        active3DView = view
        view.setProject(project)
        preservedCameraState?.let(view::restoreCameraState)
        val modelFrame = FrameLayout(this).apply {
            addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            if (!rainwaterMode) {
                val dimensionOverlay = Roof3DDimensionOverlay(this@MainActivity).apply {
                source = view
                objectEditingEnabled = objectMode
                dimensionFilter = { kind -> is3DObjectDimension(kind) == objectMode }
                onDimensionClick = { dimension ->
                    next3DDimensionWheelHighlightId = dimension.dimensionId
                    when (dimension.kind) {
                        RoofDimensionKind.PLAN_LENGTH -> show3DEdgeLengthDialog(project, dimension, view)
                        RoofDimensionKind.WALL_HEIGHT -> show3DWallHeightDialog(project, view)
                        RoofDimensionKind.ATTIC_HEIGHT -> show3DAtticHeightDialog(project, view)
                        RoofDimensionKind.ATTIC_WIDTH -> show3DAtticWidthDialog(project, view)
                        RoofDimensionKind.OVERHANG -> show3DOverhangDialog(project, dimension, view)
                        RoofDimensionKind.SLOPE -> show3DSlopeDialog(project, view)
                        RoofDimensionKind.CHIMNEY_WIDTH,
                        RoofDimensionKind.CHIMNEY_LENGTH,
                        RoofDimensionKind.CHIMNEY_HEIGHT,
                        RoofDimensionKind.ROOF_WINDOW_WIDTH,
                        RoofDimensionKind.ROOF_WINDOW_LENGTH,
                        RoofDimensionKind.HATCH_WIDTH,
                        RoofDimensionKind.HATCH_LENGTH,
                        RoofDimensionKind.VENT_DIAMETER,
                        RoofDimensionKind.SUPERSTRUCTURE_WIDTH,
                        RoofDimensionKind.SUPERSTRUCTURE_LENGTH,
                        RoofDimensionKind.SUPERSTRUCTURE_HEIGHT,
                        RoofDimensionKind.SUPERSTRUCTURE_SLOPE,
                        RoofDimensionKind.SUPERSTRUCTURE_OVERHANG ->
                            show3DObjectDimensionDialog(project, dimension, view)
                    }
                }
                fun offsetFor(item: RoofObject, lockedCornerIndex: Int? = null): RoofObjectOffset? {
                    val point = Geometry.toLocal(item.center, planeSolution.graph.origin)
                    val corners = project.polygon.map { Geometry.toLocal(it, planeSolution.graph.origin) }
                    return if (lockedCornerIndex != null) {
                        RoofObjectPlacement.offsetFromCorner(point, corners, lockedCornerIndex)
                    } else {
                        RoofObjectPlacement.offsetFromNearestCorner(point, corners)
                    }
                }
                onObjectOffsetRequested = { objectId ->
                    project.objects.firstOrNull { it.id == objectId }?.let(::offsetFor)
                }
                onObjectDragStateChanged = { objectId -> view.setHighlightedObject(objectId) }
                onObjectMove = move@ { objectId, delta, lockedCornerIndex ->
                    val item = project.objects.firstOrNull { it.id == objectId } ?: return@move null
                    val graph = planeSolution.graph
                    val current = Geometry.toLocal(item.center, graph.origin)
                    if (item.type in setOf(ObjectType.ROOF_WINDOW, ObjectType.HATCH)) {
                        val face = roofFaceAt(graph, current, item.attachedFaceId)
                            ?: return@move offsetFor(item, lockedCornerIndex)
                        val plane = face.plane ?: return@move offsetFor(item, lockedCornerIndex)
                        val constrained = RoofOpeningPlacementSolver.constrainMoveAlongEave(plane, delta)
                        val lateralReference = LocalPoint(
                            current.x + constrained.x,
                            current.y + constrained.y
                        )
                        if (snapRoofOpeningToHeadHeight(project, graph, item, lateralReference)) {
                            view.setProject(project)
                            store.save(project)
                        }
                        return@move offsetFor(item, lockedCornerIndex)
                    }
                    val candidate = LocalPoint(current.x + delta.x, current.y + delta.y)
                    val face = roofFaceAt(graph, candidate, item.attachedFaceId)
                        ?: return@move offsetFor(item, lockedCornerIndex)
                    item.center = Geometry.toGeo(candidate, graph.origin)
                    item.attachedFaceId = face.id
                    if (item.type == ObjectType.CHIMNEY && !item.chimneyHeightManual) {
                        ChimneyHeightSolver.applyAutomatic(
                            graph = graph,
                            face = face,
                            chimneyAxis = candidate,
                            atticHeightM = project.atticHeightM,
                            fallbackSlopeDeg = project.slopeDeg,
                            chimney = item
                        )
                    }
                    view.setProject(project)
                    store.save(project)
                    offsetFor(item, lockedCornerIndex)
                }
            }
                active3DDimensionOverlay = dimensionOverlay
                val highlightRemaining = lastChanged3DDimensionUntilMs - SystemClock.uptimeMillis()
                val highlightId = lastChanged3DDimensionId
                if (highlightId != null && highlightRemaining > 0L) {
                    dimensionOverlay.flashDimension(highlightId, highlightRemaining)
                }
                view.onCameraChanged = { dimensionOverlay.postInvalidateOnAnimation() }
                addView(dimensionOverlay, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                ))
            }
        }
        val rainwaterActions = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            setBackgroundColor(Color.WHITE)
            visibility = View.GONE
        }
        var selectedRainwater: RainwaterSelection? = null
        fun rainwaterSolution(): RainwaterDrainageSolver.Solution = RainwaterDrainageSolver.solve(
            planeSolution.graph,
            project.wallFootprint.map { Geometry.toLocal(it, planeSolution.graph.origin) },
            project.objects
        )
        fun ensureDownspoutConfig(id: String): RoofObject? {
            project.objects.firstOrNull { it.type == ObjectType.DOWNSPOUT && it.id == id }?.let { return it }
            val solved = rainwaterSolution().downspouts.firstOrNull { it.id == id } ?: return null
            return RoofObject(
                id = solved.id,
                type = ObjectType.DOWNSPOUT,
                center = Geometry.toGeo(solved.eavePoint, planeSolution.graph.origin),
                diameterMm = RainwaterDrainageSolver.DOWNSPOUT_DIAMETER_M * 1000.0,
                attachedEdgeId = solved.primaryEdgeId,
                downspoutTermination = solved.termination,
                downspoutAutomatic = solved.automatic
            ).also(project.objects::add)
        }
        fun edgeT(edge: GraphEdge, point: LocalPoint): Double {
            val a = planeSolution.graph.nodes[edge.startNodeId] ?: return 0.0
            val b = planeSolution.graph.nodes[edge.endNodeId] ?: return 0.0
            val dx = b.x - a.x
            val dy = b.y - a.y
            val denominator = dx * dx + dy * dy
            return if (denominator <= 1e-12) 0.0 else
                (((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator).coerceIn(0.0, 1.0)
        }
        fun persistRainwater() {
            project.updatedAt = System.currentTimeMillis()
            store.save(project)
            view.setProject(project)
        }
        fun refreshRainwaterActions() {
            rainwaterActions.removeAllViews()
            val selection = selectedRainwater
            if (!rainwaterMode || selection == null) {
                rainwaterActions.visibility = View.GONE
                return
            }
            rainwaterActions.visibility = View.VISIBLE
            if (selection.kind == RoofRainwaterKind.GUTTER) {
                rainwaterActions.addView(compactButton("+ Pridať zvod") {
                    val edge = planeSolution.graph.edges[selection.edgeId] ?: return@compactButton
                    val a = planeSolution.graph.nodes[edge.startNodeId] ?: return@compactButton
                    val b = planeSolution.graph.nodes[edge.endNodeId] ?: return@compactButton
                    val edgeLengthM = hypot(b.x - a.x, b.y - a.y)
                    val t = RainwaterDrainageSolver.constrainOutletT(edgeLengthM, selection.edgeT)
                    if (t == null) {
                        Toast.makeText(
                            this@MainActivity,
                            "Zvod vyžaduje najmenej 0,8 m od oboch rohov žľabu.",
                            Toast.LENGTH_LONG
                        ).show()
                        return@compactButton
                    }
                    val item = RoofObject(
                        id = "rain-downspout-manual-${UUID.randomUUID()}",
                        type = ObjectType.DOWNSPOUT,
                        center = Geometry.toGeo(
                            LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t),
                            planeSolution.graph.origin
                        ),
                        diameterMm = RainwaterDrainageSolver.DOWNSPOUT_DIAMETER_M * 1000.0,
                        attachedEdgeId = edge.id,
                        downspoutTermination = DownspoutTermination.ELBOW_72
                    )
                    project.objects += item
                    selectedRainwater = RainwaterSelection(item.id, RoofRainwaterKind.DOWNSPOUT, edge.id, t)
                    persistRainwater()
                    view.setHighlightedObject(item.id)
                    refreshRainwaterActions()
                })
            } else {
                val solved = rainwaterSolution().downspouts.firstOrNull { it.id == selection.id }
                val currentTermination = solved?.termination ?: DownspoutTermination.ELBOW_72
                rainwaterActions.addView(compactButton(currentTermination.label) {
                    val options = DownspoutTermination.entries.map { it.label }.toTypedArray()
                    val initial = DownspoutTermination.entries.indexOf(currentTermination)
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Ukončenie zvodovej rúry")
                        .setSingleChoiceItems(options, initial) { dialog, which ->
                            val item = ensureDownspoutConfig(selection.id) ?: return@setSingleChoiceItems
                            item.downspoutTermination = DownspoutTermination.entries[which]
                            item.downspoutSuppressed = false
                            persistRainwater()
                            dialog.dismiss()
                            refreshRainwaterActions()
                        }
                        .setNegativeButton("Zrušiť", null)
                        .show()
                })
                rainwaterActions.addView(compactButton("Odstrániť zvod") {
                    val item = project.objects.firstOrNull {
                        it.type == ObjectType.DOWNSPOUT && it.id == selection.id
                    }
                    if (solved?.automatic == true || item?.downspoutAutomatic == true) {
                        ensureDownspoutConfig(selection.id)?.apply {
                            downspoutAutomatic = true
                            downspoutSuppressed = true
                        }
                    } else {
                        project.objects.removeAll { it.type == ObjectType.DOWNSPOUT && it.id == selection.id }
                    }
                    selectedRainwater = null
                    persistRainwater()
                    view.clearRainwaterSelection()
                    refreshRainwaterActions()
                })
            }
        }
        if (rainwaterMode) {
            view.rainwaterEditingEnabled = true
            view.onRainwaterSelectionChanged = { selection ->
                selectedRainwater = selection
                refreshRainwaterActions()
            }
            view.onRainwaterMove = move@ { id, deltaT ->
                val item = ensureDownspoutConfig(id) ?: return@move
                val attachedEdgeId = item.attachedEdgeId ?: return@move
                val edge = planeSolution.graph.edges[attachedEdgeId] ?: return@move
                val a = planeSolution.graph.nodes[edge.startNodeId] ?: return@move
                val b = planeSolution.graph.nodes[edge.endNodeId] ?: return@move
                val current = Geometry.toLocal(item.center, planeSolution.graph.origin)
                val edgeLengthM = hypot(b.x - a.x, b.y - a.y)
                val t = RainwaterDrainageSolver.constrainOutletT(
                    edgeLengthM,
                    edgeT(edge, current) + deltaT
                ) ?: return@move
                item.center = Geometry.toGeo(
                    LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t),
                    planeSolution.graph.origin
                )
                item.downspoutSuppressed = false
                selectedRainwater = RainwaterSelection(id, RoofRainwaterKind.DOWNSPOUT, edge.id, t)
                persistRainwater()
            }
        }
        root.addView(modelFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        if (rainwaterMode) root.addView(rainwaterActions)
        root.addView(label(
            if (rainwaterMode) {
                "Podržte žľab: pridať zvod • podržte zvod: vybrať a posúvať pozdĺž odkvapu"
            } else if (objectMode) {
                "Prvok: potiahnite po ploche  •  okno/výlez drží výšku 2,10 m a pohybuje sa iba rovnobežne s odkvapom  •  rozmer: kliknite na kótu"
            } else {
                "Orbit: jeden prst  •  zoom/pan: dva prsty  •  upravujú sa iba kóty geometrie strechy"
            },
            13f, false, MUTED
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(16))
            setBackgroundColor(Color.WHITE)
        })
        setContentView(root)
        view.onResume()
    }

    private fun is3DObjectDimension(kind: RoofDimensionKind): Boolean = kind in setOf(
        RoofDimensionKind.CHIMNEY_WIDTH,
        RoofDimensionKind.CHIMNEY_LENGTH,
        RoofDimensionKind.CHIMNEY_HEIGHT,
        RoofDimensionKind.ROOF_WINDOW_WIDTH,
        RoofDimensionKind.ROOF_WINDOW_LENGTH,
        RoofDimensionKind.HATCH_WIDTH,
        RoofDimensionKind.HATCH_LENGTH,
        RoofDimensionKind.VENT_DIAMETER,
        RoofDimensionKind.SUPERSTRUCTURE_WIDTH,
        RoofDimensionKind.SUPERSTRUCTURE_LENGTH,
        RoofDimensionKind.SUPERSTRUCTURE_HEIGHT,
        RoofDimensionKind.SUPERSTRUCTURE_SLOPE,
        RoofDimensionKind.SUPERSTRUCTURE_OVERHANG
    )

    private fun showSummary(project: RoofProject) {
        screen = Screen.SUMMARY
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("Výkaz výmer") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.QUANTITIES))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(30))
        }
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        content.addView(sectionTitle(project.name))
        content.addView(infoCard(listOf(
            "Adresa" to project.address.ifBlank { "—" },
            "3D model" to "NODE → EDGE → FACE → roviny",
            "Predvolený sklon" to "${format1(project.slopeDeg)}°",
            "Výška stien" to "${format1(project.wallHeightM)} m",
            "Body obrysu" to project.polygon.size.toString()
        )))
        content.addView(sectionTitle("Výkaz výmer"))
        content.addView(infoCard(listOf(
            "Pôdorysná plocha" to "${format1(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${format1(totals.roofAreaM2)} m²",
            "Obvod" to "${format1(totals.perimeterM)} m",
            "Hrebeň" to "${format1(totals.ridgeM)} m",
            "Úžľabie" to "${format1(totals.valleyM)} m",
            "Nárožie" to "${format1(totals.hipM)} m",
            "Atika / pult / pri murive" to "${format1(totals.atticM)} / ${format1(totals.pultM)} / ${format1(totals.wallEndM)} m",
            "Odkvap / štít" to "${format1(totals.eaveM)} / ${format1(totals.gableM)} m",
            "Komíny / okná / výlezy" to "${totals.chimneys} / ${totals.roofWindows} / ${totals.hatches}",
            "Prestupy / vpuste / zvody" to "${totals.vents} / ${totals.drains} / ${totals.downspouts}",
            "Vikiere / strojovne / šachty / terasy" to
                "${totals.dormers} / ${totals.machineRooms} / ${totals.shafts} / ${totals.terraces}",
            "Výrez hostiteľskej strechy" to "${format1(totals.superstructureOpeningAreaM2)} m²",
            "Nové strešné plochy" to "${format1(totals.superstructureRoofAreaM2)} m²",
            "Žľabové háky / objímky zvodov" to "${totals.gutterHooks} / ${totals.downspoutClamps}",
            "Systémový roh vnút. / vonk. 90°" to "${totals.innerGutterCorners90} / ${totals.outerGutterCorners90}",
            "Výšky / sklony" to "${totals.heightMarks} / ${totals.slopeMarks}"
        )))
        content.addView(sectionTitle("Audit plôch podľa FaceId"))
        content.addView(infoCard(quantityAudit.faces.map { face ->
            face.faceId to "${format1(face.area3DM2)} m²${if (face.underconstrained) " • doplniť sklon/výšku" else ""}"
        }.ifEmpty { listOf("—" to "Žiadna uzavretá plocha") }))
        content.addView(sectionTitle("Audit hrán podľa EdgeId"))
        content.addView(infoCard(quantityAudit.edges.map { edge ->
            "${edge.edgeId} • ${edge.semanticRole.toLegacy().label}" to "${format1(edge.length3DM)} m"
        }.ifEmpty { listOf("—" to "Žiadna hrana") }))
        content.addView(label(
            "Geometria a výmery z ortofotomapy sú orientačné. Pred výrobou alebo realizáciou ich overte meraním na stavbe.",
            12f, false, Color.rgb(81, 90, 85)
        ).apply {
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(Color.rgb(241, 245, 241), 10f, stroke = Color.rgb(194, 205, 195))
        })
        content.addView(sectionTitle("Export projektu"))
        content.addView(row().apply {
            addView(actionButton("PDF nákres", BRAND) {
                exportFile(
                    "Situacia-osadenia-stavby-${safeName(project.name)}.pdf",
                    "application/pdf",
                    Exporters.pdf(this@MainActivity, project)
                )
            })
            addView(actionButton("SVG nákres", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.svg", "image/svg+xml", Exporters.svg(project))
            })
            addView(actionButton("JSON projekt", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.json", "application/json", Exporters.json(project))
            })
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showWorkScope(project: RoofProject) {
        screen = Screen.WORK_SCOPE
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("Rozsah prác") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.WORK_SCOPE))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
            addView(sectionTitle("Rozsah realizácie"))
            addView(label(
                "Položky sa počítajú lokálne z auditovaného výkazu. Jednotkové ceny zostávajú editovateľné a bez internetovej závislosti.",
                13f, false, MUTED
            ))
            addView(ImageView(this@MainActivity).apply {
                setImageBitmap(RoofBitmapRenderer.render(
                    project, 720, 420, RoofBitmapCamera(-35.0, 28.0)
                ))
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = "Statický 3D náhľad projektu vytvorený bez otvorenia 3D obrazovky"
                background = rounded(Color.rgb(241, 247, 242), 10f, stroke = Color.rgb(205, 216, 207))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(210)
                ).apply { setMargins(0, dp(10), 0, dp(4)) }
            })
            addView(label(
                "Statický 3D náhľad je vykreslený samostatným Kotlin rendererom do bitmapy.",
                11f, false, MUTED
            ))
            WorkScopeEngine.resolve(project).forEach { resolved ->
                val selection = project.selectedWorkItems.getOrPut(resolved.item.code) {
                    SelectedWorkItem(resolved.item.code)
                }
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(9), dp(12), dp(9))
                    background = rounded(Color.WHITE, 10f, stroke = Color.rgb(205, 216, 207))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, dp(8), 0, 0) }
                    val selected = CheckBox(this@MainActivity).apply {
                        text = "${resolved.item.code} • ${resolved.item.label}"
                        isChecked = selection.selected
                        setTypeface(typeface, Typeface.BOLD)
                        setOnCheckedChangeListener { _, checked ->
                            selection.selected = checked
                            store.save(project)
                        }
                    }
                    addView(selected)
                    addView(label(
                        "Automatický zdroj ${resolved.item.quantitySource}: ${format1(resolved.automaticQuantity)} ${resolved.item.unit}" +
                            if (resolved.manualOverride) "  •  ručne: ${format1(resolved.quantity)}" else "",
                        12f, false, MUTED
                    ))
                    val fields = row().apply { gravity = Gravity.CENTER_VERTICAL }
                    val quantity = edit("Množstvo", format1(resolved.quantity)).apply {
                        inputType = InputType.TYPE_NULL
                        isFocusable = false
                        isClickable = true
                        layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, dp(6), dp(5), 0) }
                    }
                    val price = edit("Cena / ${resolved.item.unit}", resolved.unitPrice?.let(::format1).orEmpty()).apply {
                        inputType = InputType.TYPE_NULL
                        isFocusable = false
                        isClickable = true
                        layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(5), dp(6), 0, 0) }
                    }
                    fields.addView(quantity)
                    fields.addView(price)
                    addView(fields)
                    addView(label("Množstvo môžete prepísať; automatická hodnota zostáva vyššie auditovateľná.", 11f, false, MUTED))
                    quantity.setOnClickListener {
                        val integerUnit = resolved.item.unit == "ks"
                        showDimensionWheel(
                            title = "Množstvo • ${resolved.item.label}",
                            description = "Ručná hodnota zostáva oddelená od auditovateľného automatického výpočtu.",
                            initial = selection.manualQuantityOverride ?: resolved.quantity,
                            minimum = 0.0, maximum = 1_000_000.0,
                            step = if (integerUnit) 1.0 else 0.1,
                            unit = " ${resolved.item.unit}", decimals = if (integerUnit) 0 else 1,
                            onCommit = { entered ->
                                selection.manualQuantityOverride = entered.takeUnless {
                                    kotlin.math.abs(it - resolved.automaticQuantity) < 0.0001
                                }
                                quantity.setText(format1(entered))
                                store.save(project)
                            }
                        )
                    }
                    price.setOnClickListener {
                        showDimensionWheel(
                            title = "Jednotková cena",
                            description = "Cena za ${resolved.item.unit}.",
                            initial = selection.unitPrice ?: 0.0,
                            minimum = 0.0, maximum = 1_000_000.0,
                            step = 0.1, unit = " €", decimals = 1,
                            onCommit = { entered ->
                                selection.unitPrice = entered
                                price.setText(format1(entered))
                                store.save(project)
                            }
                        )
                    }
                })
            }
            val selectedTotals = WorkScopeEngine.resolve(project).filter { project.selectedWorkItems[it.item.code]?.selected == true }
            val knownTotal = selectedTotals.mapNotNull { it.totalPrice }.sum()
            addView(sectionTitle("Súčet"))
            addView(actionButton("DPH ${format1(project.budgetVatPercent)} %", Color.rgb(40, 91, 112)) {
                showDimensionWheel(
                    title = "Sadzba DPH",
                    description = "Použije sa v ponukovom rozpočte PDF. Množstvá a jednotkové ceny sa nemenia.",
                    initial = project.budgetVatPercent,
                    minimum = 0.0,
                    maximum = 100.0,
                    step = 1.0,
                    unit = " %",
                    decimals = 0,
                    onCommit = { entered ->
                        project.budgetVatPercent = entered
                        store.save(project)
                        showWorkScope(project)
                    }
                )
            })
            addView(infoCard(listOf(
                "Vybrané položky" to selectedTotals.size.toString(),
                "Celková cena bez DPH" to "${format1(knownTotal)} €",
                "DPH ${format1(project.budgetVatPercent)} %" to "${format1(knownTotal * project.budgetVatPercent / 100.0)} €",
                "Celková cena s DPH" to "${format1(knownTotal * (1.0 + project.budgetVatPercent / 100.0))} €",
                "Položky bez ceny" to selectedTotals.count { it.unitPrice == null }.toString()
            )))
        }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showPdfTab(project: RoofProject) {
        screen = Screen.PDF
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        active3DDimensionOverlay = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("PDF dokumentácia") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.PDF))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
            addView(sectionTitle("Offline technický výstup"))
            addView(infoCard(listOf(
                "Projekt" to project.name,
                "Pôdorys" to "z aktuálneho RoofGraph",
                "Výkaz výmer" to "z lokálneho 3D modelu",
                "Sieť" to "nie je potrebná"
            )))
            addView(actionButton("Vytvoriť a uložiť PDF", BRAND) {
                exportFile(
                    "Situacia-osadenia-stavby-${safeName(project.name)}.pdf",
                    "application/pdf",
                    Exporters.pdf(this@MainActivity, project)
                )
            })
            addView(actionButton("Generovať IFC BIM model", Color.rgb(40, 91, 112)) {
                runCatching { Exporters.ifc(project) }
                    .onSuccess { bytes ->
                        exportFile("${safeName(project.name)}.ifc", "application/x-step", bytes)
                    }
                    .onFailure { error ->
                        toast(error.message ?: "IFC model sa nepodarilo vytvoriť.")
                    }
            })
        }
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun exportFile(name: String, mime: String, bytes: ByteArray) {
        pendingExport = bytes
        pendingExportName = name
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun openJsonImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, REQUEST_IMPORT_JSON)
    }

    private fun openUnderlayImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_IMPORT_UNDERLAY)
    }

    private fun showSolverPreviewDialog(map: RoofMapEditorView) {
        val preview = map.prepareSolverPreview() ?: return
        val stats = preview.statistics
        val blockingIssues = preview.issues.count { it.severity == TopologyIssueSeverity.ERROR }
        val warnings = preview.issues.size - blockingIssues
        val message = buildString {
            append("Návrh sa najprv zobrazuje nad pôvodným nákresom. Projekt sa zmení až po potvrdení.\n\n")
            append("Zlúčené uzly: ${stats.mergedNodes}\n")
            if (map.workspace == EditorWorkspace.INTERNAL_LINES) {
                append("Nové body a línie: 0 – topológia nákresu zostala zachovaná\n")
                append("Magneticky spojené existujúce konce: ${stats.snappedFreeEnds}\n")
                append("Maximálna zmena uhla: 10°; maximálna zmena dĺžky: 10 %\n")
            } else {
                append("Nové priesečníky: ${stats.createdIntersections}\n")
                append("Rozdelené hrany: ${stats.splitEdges}\n")
                append("Prichytené konce: ${stats.snappedFreeEnds}\n")
                append("Odstránené krátke/duplicitné hrany: ${stats.removedShortEdges + stats.removedDuplicateEdges}\n")
                append("Vyrovnané body obrysu: ${stats.regularizedBoundaryNodes}\n")
            }
            append("Zarovnané nárožia/úžľabia na 45°: ${stats.alignedHipValleyNodes}\n")
            append("Zarovnané hrebene k obvodu: ${stats.alignedRidgeNodes}\n")
            if (preview.isValid) {
                append("Stav: geometria je pripravená na použitie")
                if (warnings > 0) append(" ($warnings upozornení)")
            } else {
                append("Potrebné ručné doplnenie: $blockingIssues")
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Náhľad korekcie geometrie")
            .setMessage(message)
            .setNegativeButton("Zrušiť") { _, _ -> map.cancelSolverPreview() }
            .setNeutralButton("Ďalší problém", null)
            .setPositiveButton("Použiť opravy", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                map.focusNextSolverIssue() ?: toast("Solver nenašiel ďalší problém.")
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled = preview.issues.isNotEmpty()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).apply {
                isEnabled = true
                setOnClickListener {
                    if (map.applySolverPreview()) {
                        currentProject?.let(store::save)
                        refreshEditorMetrics(map.project)
                        dialog.dismiss()
                    }
                }
            }
        }
        dialog.setOnCancelListener { map.cancelSolverPreview() }
        dialog.show()
    }

    private fun showAtticHeightDialog(map: RoofMapEditorView, project: RoofProject) {
        showDimensionWheel(
            title = "Výška atiky nad strechou",
            description = "Atika sa v 3D vytvorí ako zvislý pás s vodorovným vrchom.",
            initial = project.atticHeightM * 1000.0,
            minimum = 100.0, maximum = 3_000.0, step = 10.0,
            unit = " mm", decimals = 0,
            onCommit = { millimetres ->
                project.atticHeightM = millimetres / 1000.0
                store.save(project)
                map.setMode(EditorMode.ADD_LINE, lineType = LineType.ATTIC)
            }
        )
    }

    private fun showObjectDimensionMenu(project: RoofProject, map: RoofMapEditorView, objectIndex: Int) {
        val item = project.objects.getOrNull(objectIndex) ?: return
        val options = when (item.type) {
            ObjectType.CHIMNEY -> listOf("Šírka", "Dĺžka", "Výška nad strechou")
            ObjectType.ROOF_WINDOW -> listOf("Šírka okna", "Dĺžka okna")
            ObjectType.HATCH -> listOf("Šírka výlezu", "Dĺžka výlezu")
            ObjectType.VENT -> listOf("Priemer prestupu")
            ObjectType.DORMER -> listOf("Typ vikiera", "Šírka", "Hĺbka", "Výška čela", "Sklon vikiera", "Presah od muriva")
            ObjectType.MACHINE_ROOM -> listOf("Šírka", "Hĺbka", "Prevýšenie strechy")
            ObjectType.SHAFT -> listOf("Šírka", "Hĺbka", "Prevýšenie šachty")
            ObjectType.TERRACE -> listOf("Šírka", "Hĺbka", "Zapustenie podlahy")
            else -> listOf("Šírka", "Dĺžka")
        }
        AlertDialog.Builder(this)
            .setTitle(item.type.label)
            .setMessage("Všetky rozmery sa nastavujú rovnakým otočným kolieskom.")
            .setItems(options.toTypedArray()) { _, which ->
                if (item.type == ObjectType.DORMER && which == 0) {
                    AlertDialog.Builder(this)
                        .setTitle("Typ vikiera")
                        .setSingleChoiceItems(
                            DormerType.entries.map { it.label }.toTypedArray(),
                            DormerType.entries.indexOf(item.dormerType)
                        ) { dialog, selected ->
                            item.dormerType = DormerType.entries[selected]
                            store.save(project)
                            map.invalidate()
                            dialog.dismiss()
                        }
                        .setNegativeButton("Zrušiť", null)
                        .show()
                    return@setItems
                }
                val isHeight = item.type == ObjectType.CHIMNEY && which == 2
                val isDiameter = item.type == ObjectType.VENT
                val isSuperstructure = item.type in setOf(
                    ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT, ObjectType.TERRACE
                )
                val dimensionIndex = if (item.type == ObjectType.DORMER) which - 1 else which
                val isSuperHeight = isSuperstructure && dimensionIndex == 2
                val isSuperSlope = item.type == ObjectType.DORMER && dimensionIndex == 3
                val isDormerOverhang = item.type == ObjectType.DORMER && dimensionIndex == 4
                val isWidth = if (isSuperstructure) dimensionIndex == 0 else which == 0
                val initial = when {
                    isHeight -> (item.value.takeIf { it > 0.0 } ?: 0.8) * 1000.0
                    isDiameter -> item.diameterMm.coerceAtLeast(100.0)
                    isSuperHeight -> item.superstructureHeightM * 1000.0
                    isSuperSlope -> item.superstructureSlopeDeg
                    isDormerOverhang -> item.dormerOverhangMm
                    isWidth -> item.widthMm.coerceAtLeast(100.0)
                    else -> item.heightMm.coerceAtLeast(100.0)
                }
                val title = options[which]
                val autoAction: (() -> Unit)? = if (isHeight) ({
                    if (applyAutomaticChimneyHeight(project, item)) {
                        store.save(project)
                        map.invalidate()
                        refreshEditorMetrics(project)
                        toast("Výška komína je znovu riadená solverom.")
                    } else {
                        toast("Automatickú výšku komína sa nepodarilo určiť.")
                    }
                }) else null
                showDimensionWheel(
                    title = "${item.type.label} • $title",
                    description = "Otočenie o 15° zmení rozmer o 10 mm.",
                    initial = initial,
                    minimum = when { isSuperSlope -> 2.0; isDormerOverhang -> 0.0; isHeight || isSuperHeight -> 200.0; else -> 100.0 },
                    maximum = when { isSuperSlope -> 70.0; isDormerOverhang -> 2_000.0; isHeight || isSuperHeight -> 20_000.0; else -> 30_000.0 },
                    step = if (isSuperSlope) 0.5 else 10.0,
                    unit = if (isSuperSlope) "°" else " mm",
                    decimals = if (isSuperSlope) 1 else 0,
                    autoLabel = if (isHeight) "AUTO – výška podľa solvera" else null,
                    onAuto = autoAction,
                    onCommit = { value ->
                        when {
                            isHeight -> {
                                item.value = value / 1000.0
                                item.chimneyHeightManual = true
                            }
                            isDiameter -> item.diameterMm = value
                            isSuperHeight -> item.superstructureHeightM = value / 1000.0
                            isSuperSlope -> item.superstructureSlopeDeg = value
                            isDormerOverhang -> item.dormerOverhangMm = value
                            isWidth -> item.widthMm = value
                            else -> item.heightMm = value
                        }
                        store.save(project)
                        map.invalidate()
                        refreshEditorMetrics(project)
                    }
                )
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showBoundaryEdgeTypeDialog(map: RoofMapEditorView, project: RoofProject, edgeIndex: Int) {
        val types = listOf(
            LineType.EAVE, LineType.GABLE, LineType.RAKE, LineType.LOW_EDGE,
            LineType.ELEVATED_LOW_EDGE, LineType.PULT, LineType.ATTIC,
            LineType.WALL_END, LineType.STEP, LineType.OPENING_BOUNDARY
        )
        val addPointLabel = "Pridať bod"
        val items = types.map { it.label } + addPointLabel
        AlertDialog.Builder(this)
            .setTitle("Obvodová hrana")
            .setItems(items.toTypedArray()) { _, position ->
                if (position == types.size) {
                    if (map.addBoundaryMidpoint(edgeIndex)) store.save(project)
                    return@setItems
                }
                val type = types[position]
                if (type == LineType.ATTIC) {
                    showDimensionWheel(
                        title = "Výška atiky nad strechou", description = "Zvislá výška atiky.",
                        initial = project.atticHeightM * 1000.0,
                        minimum = 100.0, maximum = 3_000.0, step = 10.0,
                        unit = " mm", decimals = 0,
                        onCommit = { value ->
                            project.atticHeightM = value / 1000.0
                            map.setBoundaryEdgeType(edgeIndex, type)
                            store.save(project)
                        }
                    )
                } else if (type == LineType.ELEVATED_LOW_EDGE) {
                    showDimensionWheel(
                        title = "Absolútna výška zvýšenej hrany",
                        description = "Tvrdé výškové obmedzenie pre oba koncové uzly.",
                        initial = (project.wallHeightM + 1.0) * 1000.0,
                        minimum = 0.0, maximum = 100_000.0, step = 10.0,
                        unit = " mm", decimals = 0,
                        onCommit = { value ->
                            map.setBoundaryEdgeType(edgeIndex, type, value / 1000.0)
                            store.save(project)
                        }
                    )
                } else {
                    map.setBoundaryEdgeType(edgeIndex, type)
                    store.save(project)
                }
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showEdgeSemanticDialog(
        map: RoofMapEditorView,
        project: RoofProject,
        boundaryIndex: Int? = null,
        lineIndex: Int? = null
    ) {
        if ((boundaryIndex == null) == (lineIndex == null)) {
            toast("Najprv podržte jednu obvodovú alebo vnútornú hranu.")
            return
        }
        val types = listOf(
            LineType.EAVE, LineType.GABLE, LineType.RAKE, LineType.LOW_EDGE, LineType.ELEVATED_LOW_EDGE,
            LineType.PULT, LineType.ATTIC, LineType.WALL_END, LineType.RIDGE, LineType.HIP,
            LineType.VALLEY, LineType.STEP, LineType.OPENING_BOUNDARY, LineType.UNKNOWN
        )
        val currentType = when {
            boundaryIndex != null -> map.boundaryEdgeType(boundaryIndex)
            lineIndex != null -> map.lineType(lineIndex)
            else -> null
        }
        val checkedItem = types.indexOf(currentType)

        fun applyType(type: LineType, elevationZ: Double? = null) {
            val changed = when {
                boundaryIndex != null -> map.setBoundaryEdgeType(boundaryIndex, type, elevationZ)
                lineIndex != null -> map.setLineType(lineIndex, type, elevationZ)
                else -> false
            }
            if (changed) {
                store.save(project)
                refreshEditorMetrics(project)
            } else {
                toast("Typ hrany sa nepodarilo zmeniť. Skontrolujte napojenie hrany na RoofGraph.")
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Typ hrany • ${currentType?.label ?: "neurčená"}")
            // AlertDialog nezobrazuje Message a List súčasne. Vysvetlenie preto nie je setMessage().
            .setSingleChoiceItems(types.map { it.label }.toTypedArray(), checkedItem) { selectionDialog, position ->
                val type = types[position]
                selectionDialog.dismiss()
                if (type == LineType.ATTIC) {
                    showDimensionWheel(
                        title = "Výška atiky nad strechou",
                        description = "Poloha koncových uzlov sa nemení.",
                        initial = project.atticHeightM * 1000.0,
                        minimum = 100.0, maximum = 3_000.0, step = 10.0,
                        unit = " mm", decimals = 0,
                        onCommit = { value ->
                            project.atticHeightM = value / 1000.0
                            applyType(type)
                        }
                    )
                } else if (type == LineType.ELEVATED_LOW_EDGE) {
                    showDimensionWheel(
                        title = "Absolútna výška zvýšenej hrany",
                        description = "Tvrdé výškové obmedzenie pre oba koncové uzly.",
                        initial = (project.wallHeightM + 1.0) * 1000.0,
                        minimum = 0.0, maximum = 100_000.0, step = 10.0,
                        unit = " mm", decimals = 0,
                        onCommit = { value -> applyType(type, value / 1000.0) }
                    )
                } else {
                    applyType(type)
                }
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    /** One numeric interaction everywhere: the native circular dial from the STN PHP tool. */
    private fun showDimensionWheel(
        title: String,
        description: String,
        initial: Double,
        minimum: Double,
        maximum: Double,
        step: Double,
        unit: String,
        decimals: Int,
        extraView: View? = null,
        autoLabel: String? = null,
        onAuto: (() -> Unit)? = null,
        onPreview: (Double) -> Unit = {},
        onCancel: () -> Unit = {},
        onCommit: (Double) -> Unit
    ) {
        val changedDimensionId = next3DDimensionWheelHighlightId
        next3DDimensionWheelHighlightId = null
        val dial = DimensionDialView(this).apply {
            this.title = title
            this.minimum = minimum
            this.maximum = maximum
            this.step = step
            this.unit = unit
            this.decimals = decimals
            value = initial
        }
        val autoButton = onAuto?.let {
            actionButton(autoLabel ?: "AUTO", BRAND) { }.apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(46)
                ).apply { setMargins(0, dp(4), 0, dp(8)) }
            }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
            if (description.isNotBlank()) addView(label(description, 13f, false, MUTED))
            autoButton?.let(::addView)
            addView(dial, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(390)))
            extraView?.let(::addView)
        }
        var finished = false
        val dialog = AlertDialog.Builder(this)
            .setTitle(title)
            .setView(content)
            .setNegativeButton("Zrušiť") { _, _ ->
                if (!finished) {
                    finished = true
                    onCancel()
                }
            }
            .create()
        autoButton?.setOnClickListener {
            if (!finished) {
                finished = true
                onAuto?.invoke()
                changedDimensionId?.let(::flashChanged3DDimension)
                dialog.dismiss()
            }
        }
        dial.onValueChanged = onPreview
        dial.onConfirm = { selected ->
            if (!finished) {
                finished = true
                onCommit(selected)
                changedDimensionId?.let(::flashChanged3DDimension)
                dialog.dismiss()
            }
        }
        dialog.setOnCancelListener {
            if (!finished) {
                finished = true
                onCancel()
            }
        }
        dialog.setOnShowListener { dial.armConfirmation() }
        dialog.show()
    }

    private fun flashChanged3DDimension(dimensionId: String) {
        lastChanged3DDimensionId = dimensionId
        lastChanged3DDimensionUntilMs = SystemClock.uptimeMillis() + 2_000L
        active3DDimensionOverlay?.flashDimension(dimensionId, 2_000L)
    }

    private fun showEdgeLengthDialog(map: RoofMapEditorView, mapHost: FreeRoofMapHost) {
        val current = map.selectedEdgeLengthM()
        if (current == null) {
            toast("Najprv zvoľte Editovať a klepnite na obvodovú hranu.")
            return
        }
        val calibration = CheckBox(this).apply {
            text = "Kalibrovať celý PDF/JPG podklad podľa tejto hrany"
            isChecked = mapHost.isDocumentMode()
            visibility = if (mapHost.isDocumentMode()) View.VISIBLE else View.GONE
        }
        showDimensionWheel(
            title = "Rozmer vybranej hrany",
            description = "Otočenie o 15° mení rozmer o 50 mm. Hodnota je tvrdé obmedzenie solvera.",
            initial = current * 1000.0, minimum = 50.0, maximum = 5_000_000.0,
            step = 50.0, unit = " mm", decimals = 0, extraView = calibration,
            onCommit = { millimetres ->
                val target = millimetres / 1000.0
                if (map.setSelectedEdgeLength(target, mapHost.isDocumentMode() && calibration.isChecked)) {
                    currentProject?.let(store::save)
                    refreshEditorMetrics(map.project)
                } else toast(map.selectedEdgeLengthFailure() ?: "Rozmer hrany sa nepodarilo použiť.")
            }
        )
    }

    private fun show3DEdgeLengthDialog(
        project: RoofProject,
        dimension: ProjectedRoofDimension,
        view: Roof3DView
    ) {
        val before = project.roofGraph ?: return
        val edgeId = dimension.edgeId
        val edge = before.edges[edgeId] ?: return
        val a = before.nodes[edge.startNodeId] ?: return
        val b = before.nodes[edge.endNodeId] ?: return
        val currentM = dimension.lengthM.takeIf { it > 0.0 }
            ?: kotlin.math.hypot(b.x - a.x, b.y - a.y)
        val currentRoofEdgeM = kotlin.math.hypot(b.x - a.x, b.y - a.y)
        val sourcePolygon = project.polygon.map(GeoPoint::copy)
        val sourceWallFootprint = project.wallFootprint.map(GeoPoint::copy)
        val sourceObjects = project.objects.map { it.copy(center = it.center.copy()) }
        var preview = before
        var previewIssue: String? = null
        fun restoreBefore() {
            RoofTopologyMigration.applyToProject(project, before.toTopology(), requireFullyValid = false)
            project.roofGraph = before
            project.roofTopology = before.toTopology()
            project.polygon = sourcePolygon.map(GeoPoint::copy).toMutableList()
            project.wallFootprint = sourceWallFootprint.map(GeoPoint::copy).toMutableList()
            project.objects = sourceObjects.map { it.copy(center = it.center.copy()) }.toMutableList()
            view.setProject(project)
        }
        fun previewValue(millimetres: Double): Boolean {
            // The visible plan dimension lies on the wall footprint. Preserve an existing eave
            // overhang by applying the requested delta, rather than replacing the roof-edge
            // length with the (usually shorter) wall dimension.
            val targetWallM = millimetres / 1000.0
            val targetRoofEdgeM = currentRoofEdgeM + (targetWallM - currentM)
            val result = ParametricEditSolver.setBoundaryDimension(
                before, dimension.linkedEdgeIds, targetRoofEdgeM, project.wallHeightM, project.slopeDeg
            )
            if (!result.applied) {
                previewIssue = result.issues.firstOrNull()
                return false
            }
            preview = result.graph
            if (!ProjectPlanSynchronizer.apply(
                    project, before, preview, sourceWallFootprint, sourceObjects
                )) {
                previewIssue = "Zmenu sa nepodarilo zosúladiť s pôdorysom stien."
                return false
            }
            previewIssue = null
            view.setProject(project)
            return true
        }
        showDimensionWheel(
            title = if (dimension.linkedEdgeIds.size == 2) "Spoločná kóta protiľahlých strán" else "3D kóta • $edgeId",
            description = "Rovnobežné protiľahlé strany sa upravia spoločne. Jeden krok kolieska je 50 mm.",
            initial = currentM * 1000.0, minimum = 50.0, maximum = 5_000_000.0,
            step = 50.0, unit = " mm", decimals = 0,
            onPreview = { previewValue(it) },
            onCancel = ::restoreBefore,
            onCommit = { millimetres ->
                if (!previewValue(millimetres)) {
                    toast(previewIssue ?: "Rozmer by vytvoril neplatný pôdorys.")
                    restoreBefore()
                } else {
                    last3DUndo = ModelUndoState(
                        before,
                        before.toTopology(),
                        project.wallHeightM,
                        project.atticHeightM,
                        project.slopeDeg,
                        sourceWallFootprint,
                        sourceObjects,
                        sourcePolygon
                    )
                    project.roofGraph = preview
                    project.roofTopology = preview.toTopology()
                    store.save(project)
                    show3D(project)
                }
            }
        )
    }

    private fun show3DWallHeightDialog(project: RoofProject, view: Roof3DView) {
        val before = ModelUndoState(
            project.roofGraph, project.roofTopology, project.wallHeightM, project.atticHeightM, project.slopeDeg,
            project.wallFootprint.map(GeoPoint::copy)
        )
        showDimensionWheel(
            title = "Výška stien domu",
            description = "Kóta H mení výšku všetkých obvodových stien po 50 mm.",
            initial = project.wallHeightM * 1000.0, minimum = 500.0, maximum = 100_000.0,
            step = 50.0, unit = " mm", decimals = 0,
            onPreview = { value -> project.wallHeightM = value / 1000.0; view.setProject(project) },
            onCancel = {
                project.wallHeightM = before.wallHeightM
                view.setProject(project)
            },
            onCommit = { value ->
                project.wallHeightM = value / 1000.0
                last3DUndo = before
                store.save(project)
                show3D(project)
            }
        )
    }

    private fun show3DAtticHeightDialog(project: RoofProject, view: Roof3DView) {
        val before = ModelUndoState(
            project.roofGraph, project.roofTopology, project.wallHeightM, project.atticHeightM, project.slopeDeg,
            project.wallFootprint.map(GeoPoint::copy)
        )
        showDimensionWheel(
            title = "Výška atiky",
            description = "Vrch atiky zostáva vodorovný aj nad spádovanou vnútornou plochou.",
            initial = project.atticHeightM * 1000.0, minimum = 100.0, maximum = 3_000.0,
            step = 10.0, unit = " mm", decimals = 0,
            onPreview = { value -> project.atticHeightM = value / 1000.0; view.setProject(project) },
            onCancel = {
                project.atticHeightM = before.atticHeightM
                view.setProject(project)
            },
            onCommit = { value ->
                project.atticHeightM = value / 1000.0
                last3DUndo = before
                store.save(project)
                show3D(project)
            }
        )
    }

    private fun show3DAtticWidthDialog(project: RoofProject, view: Roof3DView) {
        val before = project.atticWidthM
        showDimensionWheel(
            title = "Šírka atiky",
            description = "Šírka sa meria kolmo dovnútra strechy. Spojené rohy sa prepočítajú ako súvislý miterový pás.",
            initial = project.atticWidthM * 1000.0,
            minimum = 60.0,
            maximum = 1_500.0,
            step = 10.0,
            unit = " mm",
            decimals = 0,
            onPreview = { value ->
                project.atticWidthM = value / 1000.0
                view.setProject(project)
            },
            onCancel = {
                project.atticWidthM = before
                view.setProject(project)
            },
            onCommit = { value ->
                project.atticWidthM = value / 1000.0
                store.save(project)
                show3D(project)
            }
        )
    }

    private fun show3DSlopeDialog(project: RoofProject, view: Roof3DView) {
        val before = ModelUndoState(
            project.roofGraph, project.roofTopology, project.wallHeightM, project.atticHeightM, project.slopeDeg,
            project.wallFootprint.map(GeoPoint::copy)
        )
        fun applySlope(degrees: Double) {
            project.slopeDeg = degrees
            project.roofGraph = before.graph?.let { graph ->
                graph.copy(faces = graph.faces.mapValues { (_, face) ->
                    face.copy(
                        plane = null,
                        slopeConstraint = face.slopeConstraint?.copy(angleDeg = degrees)
                    )
                })
            }
            project.roofTopology = project.roofGraph?.toTopology() ?: before.topology
            view.setProject(project)
        }
        showDimensionWheel(
            title = "Sklon strešných plôch",
            description = "Značka sklonu mení predvolený aj existujúce plošné obmedzenia po 0,5°.",
            initial = project.slopeDeg, minimum = 0.0, maximum = 89.0,
            step = 0.5, unit = "°", decimals = 1,
            onPreview = ::applySlope,
            onCancel = {
                project.slopeDeg = before.slopeDeg
                project.roofGraph = before.graph
                project.roofTopology = before.topology
                view.setProject(project)
            },
            onCommit = { value ->
                applySlope(value)
                last3DUndo = before
                store.save(project)
                show3D(project)
            }
        )
    }

    private fun show3DOverhangDialog(
        project: RoofProject,
        dimension: ProjectedRoofDimension,
        view: Roof3DView
    ) {
        val graph = project.roofGraph ?: return
        val before = ModelUndoState(
            graph, project.roofTopology, project.wallHeightM, project.atticHeightM, project.slopeDeg,
            project.wallFootprint.map(GeoPoint::copy)
        )
        var previewValid = true
        fun previewValue(millimetres: Double) {
            val footprint = semanticEaveFootprint(graph, millimetres / 1000.0)
            previewValid = footprint != null
            if (footprint != null) {
                project.wallFootprint = footprint.toMutableList()
                view.setProject(project)
            }
        }
        showDimensionWheel(
            title = "Odsadenie stien od strechy",
            description = "Jedna hodnota sa aplikuje na odkvapy aj štíty. Atiky zostanú bez presahu; valby a L/T/H rohy spája solver spoločnými uzlami.",
            initial = dimension.lengthM * 1000.0, minimum = 0.0, maximum = 5_000.0,
            step = 10.0, unit = " mm", decimals = 0,
            onPreview = ::previewValue,
            onCancel = {
                project.wallFootprint = before.wallFootprint.map(GeoPoint::copy).toMutableList()
                view.setProject(project)
            },
            onCommit = { millimetres ->
                previewValue(millimetres)
                if (!previewValid) {
                    toast("Takéto odsadenie by vytvorilo neplatný pôdorys stien.")
                    project.wallFootprint = before.wallFootprint.map(GeoPoint::copy).toMutableList()
                    view.setProject(project)
                } else {
                    last3DUndo = before
                    store.save(project)
                    show3D(project)
                }
            }
        )
    }

    private fun show3DObjectDimensionDialog(
        project: RoofProject,
        dimension: ProjectedRoofDimension,
        view: Roof3DView
    ) {
        val item = project.objects.firstOrNull { it.id == dimension.edgeId } ?: return
        val savedObjects = project.objects.map { it.copy(center = it.center.copy()) }
        val before = ModelUndoState(
            project.roofGraph, project.roofTopology, project.wallHeightM, project.atticHeightM,
            project.slopeDeg, project.wallFootprint.map(GeoPoint::copy), savedObjects
        )
        val title = when (dimension.kind) {
            RoofDimensionKind.CHIMNEY_WIDTH -> "Šírka komína"
            RoofDimensionKind.CHIMNEY_LENGTH -> "Dĺžka komína"
            RoofDimensionKind.CHIMNEY_HEIGHT -> "Výška komína nad strechou"
            RoofDimensionKind.ROOF_WINDOW_WIDTH -> "Šírka strešného okna"
            RoofDimensionKind.ROOF_WINDOW_LENGTH -> "Dĺžka strešného okna"
            RoofDimensionKind.HATCH_WIDTH -> "Šírka strešného výlezu"
            RoofDimensionKind.HATCH_LENGTH -> "Dĺžka strešného výlezu"
            RoofDimensionKind.VENT_DIAMETER -> "Priemer prestupu"
            RoofDimensionKind.SUPERSTRUCTURE_WIDTH -> when (item.type) {
                ObjectType.DORMER -> "Šírka vikiera"
                ObjectType.MACHINE_ROOM -> "Šírka strojovne výťahu"
                ObjectType.SHAFT -> "Šírka šachty"
                ObjectType.TERRACE -> "Šírka strešnej terasy"
                else -> "Šírka nadstavby"
            }
            RoofDimensionKind.SUPERSTRUCTURE_LENGTH -> when (item.type) {
                ObjectType.DORMER -> "Hĺbka vikiera"
                ObjectType.MACHINE_ROOM -> "Dĺžka strojovne výťahu"
                ObjectType.SHAFT -> "Dĺžka šachty"
                ObjectType.TERRACE -> "Hĺbka strešnej terasy"
                else -> "Dĺžka nadstavby"
            }
            RoofDimensionKind.SUPERSTRUCTURE_HEIGHT -> when (item.type) {
                ObjectType.DORMER -> "Výška čela vikiera"
                ObjectType.MACHINE_ROOM -> "Prevýšenie strechy strojovne"
                ObjectType.SHAFT -> "Prevýšenie šachty"
                ObjectType.TERRACE -> "Zapustenie podlahy terasy"
                else -> "Výška nadstavby"
            }
            RoofDimensionKind.SUPERSTRUCTURE_SLOPE -> "Sklon strechy vikiera"
            RoofDimensionKind.SUPERSTRUCTURE_OVERHANG -> "Presah strechy od muriva vikiera"
            else -> return
        }
        val isAngle = dimension.kind == RoofDimensionKind.SUPERSTRUCTURE_SLOPE
        fun apply(value: Double) {
            when (dimension.kind) {
                RoofDimensionKind.CHIMNEY_WIDTH, RoofDimensionKind.ROOF_WINDOW_WIDTH,
                RoofDimensionKind.HATCH_WIDTH, RoofDimensionKind.SUPERSTRUCTURE_WIDTH -> item.widthMm = value
                RoofDimensionKind.CHIMNEY_LENGTH, RoofDimensionKind.ROOF_WINDOW_LENGTH,
                RoofDimensionKind.HATCH_LENGTH, RoofDimensionKind.SUPERSTRUCTURE_LENGTH -> item.heightMm = value
                RoofDimensionKind.CHIMNEY_HEIGHT -> item.value = value / 1000.0
                RoofDimensionKind.VENT_DIAMETER -> item.diameterMm = value
                RoofDimensionKind.SUPERSTRUCTURE_HEIGHT -> item.superstructureHeightM = value / 1000.0
                RoofDimensionKind.SUPERSTRUCTURE_SLOPE -> item.superstructureSlopeDeg = value
                RoofDimensionKind.SUPERSTRUCTURE_OVERHANG -> item.dormerOverhangMm = value
                else -> Unit
            }
            if (dimension.kind in setOf(
                    RoofDimensionKind.ROOF_WINDOW_LENGTH,
                    RoofDimensionKind.HATCH_LENGTH
                )
            ) {
                project.roofGraph?.let { graph -> snapRoofOpeningToHeadHeight(project, graph, item) }
            }
            view.setProject(project)
        }
        val autoAction: (() -> Unit)? = if (dimension.kind == RoofDimensionKind.CHIMNEY_HEIGHT) ({
            if (applyAutomaticChimneyHeight(project, item)) {
                last3DUndo = before
                store.save(project)
                toast("Výška komína je znovu riadená solverom.")
                show3D(project, objectMode = true)
            } else {
                project.objects = savedObjects.map { it.copy(center = it.center.copy()) }.toMutableList()
                view.setProject(project)
                toast("Automatickú výšku komína sa nepodarilo určiť.")
            }
        }) else null
        showDimensionWheel(
            title = title,
            description = if (isAngle) "Sklon strechy vikiera; jeden krok kolieska je 0,5°."
                else "Technický rozmer prvku; jeden krok kolieska je 10 mm.",
            initial = if (isAngle) dimension.lengthM else dimension.lengthM * 1000.0,
            minimum = when {
                isAngle -> 2.0
                dimension.kind == RoofDimensionKind.SUPERSTRUCTURE_OVERHANG -> 0.0
                dimension.kind == RoofDimensionKind.CHIMNEY_HEIGHT -> 200.0
                dimension.kind == RoofDimensionKind.SUPERSTRUCTURE_HEIGHT && item.type == ObjectType.TERRACE -> 50.0
                else -> 100.0
            },
            maximum = when {
                isAngle -> 70.0
                dimension.kind == RoofDimensionKind.SUPERSTRUCTURE_OVERHANG -> 2_000.0
                dimension.kind == RoofDimensionKind.CHIMNEY_HEIGHT -> 20_000.0
                dimension.kind == RoofDimensionKind.SUPERSTRUCTURE_HEIGHT -> 20_000.0
                else -> 20_000.0
            },
            step = if (isAngle) 0.5 else 10.0,
            unit = if (isAngle) "°" else " mm",
            decimals = if (isAngle) 1 else 0,
            autoLabel = if (dimension.kind == RoofDimensionKind.CHIMNEY_HEIGHT) {
                "AUTO – výška podľa solvera"
            } else null,
            onAuto = autoAction,
            onPreview = ::apply,
            onCancel = {
                project.objects = savedObjects.map { it.copy(center = it.center.copy()) }.toMutableList()
                view.setProject(project)
            },
            onCommit = { value ->
                apply(value)
                if (dimension.kind == RoofDimensionKind.CHIMNEY_HEIGHT) {
                    item.chimneyHeightManual = true
                }
                last3DUndo = before
                store.save(project)
                show3D(project, objectMode = true)
            }
        )
    }

    /** Shared perimeter parameter for EAVE and GABLE supports; ATTIC stays fixed. */
    private fun semanticEaveFootprint(graph: RoofGraph, insetM: Double): List<GeoPoint>? =
        RoofOverhangSolver.selectiveWallFootprint(graph, insetM)
            ?.map { Geometry.toGeo(it, graph.origin) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQUEST_EXPORT -> {
                val bytes = pendingExport ?: return
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: error("Súbor sa nedá otvoriť na zápis.")
                }.onSuccess {
                    toast("Uložené: $pendingExportName")
                }.onFailure { toast(it.message ?: "Export zlyhal.") }
                pendingExport = null
            }
            REQUEST_IMPORT_JSON -> {
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Súbor sa nedá prečítať.")
                    val imported = ProjectJson.decode(text)
                    imported.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        name = "${imported.name} – import",
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                }.onSuccess { project ->
                    store.save(project)
                    currentProject = project
                    showEditor(project)
                }.onFailure { toast("Neplatný projekt: ${it.message}") }
            }
            REQUEST_IMPORT_UNDERLAY -> {
                val project = currentProject ?: return
                runCatching {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val mime = contentResolver.getType(uri).orEmpty()
                val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: uri.lastPathSegment.orEmpty().ifBlank { "Podklad" }
                project.underlayUri = uri.toString()
                project.underlayMime = mime
                project.underlayName = name
                activeMapHost?.showDocument(uri, mime, name, true)
                store.save(project)
                editorStatus?.text = "Načítavam podklad $name…"
            }
        }
    }

    private fun appBar(title: String, back: (() -> Unit)?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(8), dp(8), dp(8))
        setBackgroundColor(BRAND_DARK)
        if (back != null) addView(compactButton("‹ Späť", back))
        addView(label(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun verticalRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(PAPER)
        if (Build.VERSION.SDK_INT >= 30) {
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            requestApplyInsets()
        } else {
            fitsSystemWindows = true
        }
    }

    private fun disposeActiveMap() {
        activeMapHost?.onPause()
        activeMapHost?.onDestroy()
        activeMapHost = null
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(color, 9f)
        setPadding(dp(12), 0, dp(12), 0)
        minHeight = dp(42)
        minWidth = 0
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply {
            setMargins(0, 0, dp(7), 0)
        }
    }

    private fun editorToolButton(text: String, iconRes: Int, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 11f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setCompoundDrawablesWithIntrinsicBounds(0, iconRes, 0, 0)
        compoundDrawablePadding = dp(2)
        background = rounded(color, 8f, stroke = Color.rgb(104, 143, 113))
        setPadding(dp(3), dp(4), dp(3), dp(3))
        minWidth = dp(44)
        minHeight = dp(60)
        maxLines = 2
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
    }

    private fun compactButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 12f
        background = rounded(Color.rgb(51, 103, 65), 8f, stroke = Color.rgb(117, 156, 126))
        setPadding(dp(9), 0, dp(9), 0)
        minWidth = 0
        minHeight = dp(38)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(0, 0, dp(6), 0)
        }
    }

    private fun workspaceNavigation(project: RoofProject, selected: WorkspaceTab): View {
        val rememberedScrollX = workspaceNavigationScrollX
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(236, 242, 237))
            val navigationRow = row().apply {
                setPadding(dp(6), dp(5), dp(6), dp(5))
                WorkspaceTab.entries.forEach { tab ->
                    val button = actionButton(tab.label, TOOL_INACTIVE) {
                        when (tab) {
                            WorkspaceTab.OUTLINE, WorkspaceTab.INTERNAL, WorkspaceTab.TYPOLOGY,
                            WorkspaceTab.SUPERSTRUCTURES -> showEditor(project, tab)
                            WorkspaceTab.MODEL_3D -> show3D(project)
                            WorkspaceTab.MODEL_OBJECTS -> show3D(project, objectMode = true)
                            WorkspaceTab.RAINWATER -> show3D(project, rainwaterMode = true)
                            WorkspaceTab.QUANTITIES -> showSummary(project)
                            WorkspaceTab.WORK_SCOPE -> showWorkScope(project)
                            WorkspaceTab.PDF -> showPdfTab(project)
                        }
                    }
                    applyActiveButtonStyle(button, tab == selected)
                    button.tag = tab
                    addView(button)
                }
            }
            addView(navigationRow)
            setOnScrollChangeListener { _, scrollX, _, _, _ ->
                workspaceNavigationScrollX = scrollX
            }
            post {
                val maxScrollX = (navigationRow.width - width).coerceAtLeast(0)
                scrollTo(rememberedScrollX.coerceIn(0, maxScrollX), 0)
                post ensureSelectedVisible@{
                    val selectedButton = (0 until navigationRow.childCount)
                        .map { navigationRow.getChildAt(it) }
                        .firstOrNull { it.tag == selected }
                        ?: return@ensureSelectedVisible
                    val margin = dp(8)
                    val target = when {
                        selectedButton.left - margin < scrollX -> selectedButton.left - margin
                        selectedButton.right + margin > scrollX + width -> selectedButton.right + margin - width
                        else -> scrollX
                    }.coerceIn(0, maxScrollX)
                    if (target != scrollX) smoothScrollTo(target, 0)
                }
            }
        }
    }

    private fun applyActiveButtonStyle(button: Button, active: Boolean) {
        button.isSelected = active
        button.alpha = if (active) 1f else 0.88f
        button.elevation = if (active) dp(3).toFloat() else 0f
        button.background = if (active) {
            rounded(TOOL_ACTIVE, 9f, stroke = ACTIVE_ACCENT, strokeWidthDp = 2)
        } else {
            rounded(TOOL_INACTIVE, 9f, stroke = Color.rgb(99, 121, 108))
        }
        button.contentDescription = if (active) "Aktívne: ${button.text}" else button.text
    }

    private fun mapControlButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = if (text.length == 1) 20f else 10f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(Color.rgb(31, 89, 48), 8f, stroke = Color.WHITE)
        minWidth = 0
        minHeight = 0
        setPadding(dp(7), 0, dp(7), 0)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(54), dp(42)).apply {
            setMargins(0, 0, 0, dp(5))
        }
    }

    private fun label(text: String, size: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.12f)
    }

    private fun edit(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        textSize = 15f
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = rounded(Color.WHITE, 8f, stroke = Color.rgb(194, 205, 195))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            setMargins(0, 0, 0, dp(9))
        }
    }

    private fun sectionTitle(text: String) = label(text, 18f, true, INK).apply {
        setPadding(0, dp(12), 0, dp(8))
    }

    private fun infoCard(rows: List<Pair<String, String>>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(Color.WHITE, 12f, stroke = Color.rgb(211, 220, 212))
        rows.forEach { (key, value) ->
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
                setPadding(0, dp(7), 0, dp(7))
                addView(label(key, 13f, false, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.46f))
                addView(label(value, 13f, true, INK).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.54f))
            })
        }
    }

    private fun rounded(
        fill: Int,
        radiusDp: Float,
        stroke: Int? = null,
        strokeWidthDp: Int = 1
    ) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp.roundToInt()).toFloat()
        stroke?.let { setStroke(dp(strokeWidthDp), it) }
    }

    private fun loadingDialog(message: String): AlertDialog = AlertDialog.Builder(this)
        .setView(label(message, 16f, true, INK).apply { setPadding(dp(28), dp(26), dp(28), dp(26)) })
        .setCancelable(false)
        .create()
        .also { it.show() }

    private fun simpleSelection(block: () -> Unit) =
        object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = block()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }

    private fun parseCoordinates(value: String): GeoPoint? {
        val match = Regex("""^\s*(-?\d{1,2}(?:[.,]\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:[.,]\d+)?)\s*$""").find(value)
            ?: return null
        val lat = match.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val lon = match.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return null
        return if (lat in -90.0..90.0 && lon in -180.0..180.0) GeoPoint(lat, lon) else null
    }

    private fun safeName(value: String) = value.trim()
        .replace(Regex("""[^\p{L}\p{N}._-]+"""), "_")
        .trim('_')
        .ifBlank { "strecha" }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun format1(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)

    private enum class Screen { HOME, EDITOR, THREE_D, SUMMARY, WORK_SCOPE, PDF }

    private enum class WorkspaceTab(val label: String) {
        OUTLINE("1 Obrys"),
        INTERNAL("2 Vnútorné línie"),
        TYPOLOGY("3 Typológia"),
        SUPERSTRUCTURES("4 Vikiere a strojovne"),
        MODEL_3D("5 3D geometria"),
        MODEL_OBJECTS("6 3D prvky"),
        RAINWATER("7 Žľaby a zvody"),
        QUANTITIES("8 Výkaz výmer"),
        WORK_SCOPE("9 Rozsah prác"),
        PDF("10 PDF")
    }

    companion object {
        private const val REQUEST_EXPORT = 4001
        private const val REQUEST_IMPORT_JSON = 4002
        private const val REQUEST_LOCATION = 4003
        private const val REQUEST_IMPORT_UNDERLAY = 4004
        private const val STATE_WORKSPACE_NAV_SCROLL_X = "workspace_navigation_scroll_x"
        private val BRAND = Color.rgb(35, 122, 53)
        private val BRAND_DARK = Color.rgb(22, 84, 38)
        private val TOOL_ACTIVE = Color.rgb(24, 151, 67)
        private val TOOL_INACTIVE = Color.rgb(65, 84, 74)
        private val ACTIVE_ACCENT = Color.rgb(255, 207, 63)
        private val INK = Color.rgb(23, 33, 43)
        private val MUTED = Color.rgb(91, 107, 99)
        private val PAPER = Color.rgb(244, 247, 244)
        private val EDITABLE_3D_OBJECTS = setOf(
            ObjectType.CHIMNEY,
            ObjectType.ROOF_WINDOW,
            ObjectType.HATCH,
            ObjectType.VENT,
            ObjectType.DORMER,
            ObjectType.MACHINE_ROOM,
            ObjectType.SHAFT,
            ObjectType.TERRACE
        )
    }
}
