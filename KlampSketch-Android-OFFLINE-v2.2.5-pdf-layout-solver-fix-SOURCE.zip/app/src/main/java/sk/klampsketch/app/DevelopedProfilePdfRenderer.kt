package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object DevelopedProfilePdfRenderer {
    private const val PT_PER_MM = 72f / 25.4f
    private val scaleSteps = intArrayOf(1, 2, 5, 10, 20, 25, 50, 100, 200)
    private val panelPalette = intArrayOf(
        Color.rgb(221, 238, 251),
        Color.rgb(223, 245, 231),
        Color.rgb(255, 242, 214),
        Color.rgb(239, 231, 252),
        Color.rgb(250, 228, 231),
        Color.rgb(228, 243, 244)
    )

    fun draw(
        canvas: Canvas,
        project: ProjectRecord,
        drawing: DrawingRecord,
        pageNumber: Int,
        totalPages: Int
    ) {
        val developed = DevelopedProfileBuilder.build(drawing)
            ?: error("Rozvinutý plášť sa nepodarilo vypočítať.")
        val metrics = calculateMetrics(drawing)
        canvas.drawColor(Color.WHITE)

        val titlePaint = textPaint(15.5f, Color.rgb(25, 42, 55), bold = true)
        val subtitlePaint = textPaint(8.0f, Color.rgb(73, 92, 106), bold = true)
        val smallPaint = textPaint(6.8f, Color.rgb(44, 61, 73), bold = false)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(38, 54, 66)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        canvas.drawRect(RectF(mm(8f), mm(8f), mm(202f), mm(289f)), borderPaint)
        canvas.drawText("ROZVINUTÝ PLÁŠŤ – ŠABLÓNA NA STRIHANIE", mm(14f), mm(17f), titlePaint)
        canvas.drawText(
            "${drawing.identifier}  •  ${drawing.name}  •  ${project.name}",
            mm(14f),
            mm(23f),
            subtitlePaint
        )
        canvas.drawText("LIST $pageNumber/$totalPages", mm(166f), mm(17f), subtitlePaint)

        val drawingArea = RectF(mm(12f), mm(34f), mm(198f), mm(220f))
        val availableWidthMm = drawingArea.width() / PT_PER_MM - 8f
        val availableHeightMm = drawingArea.height() / PT_PER_MM - 10f
        val plan = choosePlan(
            developed = developed,
            blankWidthMm = metrics.blankWidthMm.toDouble(),
            availableWidthMm = availableWidthMm.toDouble(),
            availableHeightMm = availableHeightMm.toDouble()
        )

        canvas.drawText(
            "Solver rozloženia: auto-fit + otočenie 0°/90°  •  MIERKA 1:${plan.denominator}",
            mm(14f),
            mm(29f),
            subtitlePaint
        )

        drawDevelopedGeometry(canvas, developed, metrics, plan, drawingArea)
        drawLegendAndProcess(canvas, drawing, developed, metrics, plan, smallPaint, borderPaint)
        drawCalibration(canvas, subtitlePaint)
    }

    private fun drawDevelopedGeometry(
        canvas: Canvas,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        area: RectF
    ) {
        val blankModel = blankEnvelope(developed, metrics.blankWidthMm.toDouble())
        val transformedFront = developed.frontEdge.map(plan::transform)
        val transformedBack = developed.backEdge.map(plan::transform)
        val transformedBlank = blankModel.map(plan::transform)
        val all = transformedFront + transformedBack + transformedBlank
        val minX = all.minOf { it.x }
        val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }
        val maxY = all.maxOf { it.y }
        val geometryWidthPt = ((maxX - minX) / plan.denominator * PT_PER_MM).toFloat()
        val geometryHeightPt = ((maxY - minY) / plan.denominator * PT_PER_MM).toFloat()
        val originX = area.left + (area.width() - geometryWidthPt) / 2f
        val originY = area.top + (area.height() - geometryHeightPt) / 2f

        fun pagePoint(point: FlatPoint): FlatPoint {
            val transformed = plan.transform(point)
            return FlatPoint(
                originX + ((transformed.x - minX) / plan.denominator * PT_PER_MM),
                originY + ((transformed.y - minY) / plan.denominator * PT_PER_MM)
            )
        }

        val front = developed.frontEdge.map(::pagePoint)
        val back = developed.backEdge.map(::pagePoint)
        val blank = blankModel.map(::pagePoint)

        val blankFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(251, 214, 214)
            style = Paint.Style.FILL
        }
        val blankOutlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(173, 42, 34)
            style = Paint.Style.STROKE
            strokeWidth = 1.35f
            strokeJoin = Paint.Join.ROUND
        }
        val offcutFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(233, 102, 94)
            style = Paint.Style.FILL
        }
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(24, 41, 54)
            style = Paint.Style.STROKE
            strokeWidth = 1.4f
            strokeJoin = Paint.Join.ROUND
        }
        val frontPaint = Paint(outlinePaint).apply {
            color = Color.rgb(10, 110, 196)
            strokeWidth = 2.2f
        }
        val rearPaint = Paint(outlinePaint).apply {
            color = Color.rgb(83, 97, 108)
            strokeWidth = 2.2f
        }
        val foldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(230, 132, 38)
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            pathEffect = DashPathEffect(floatArrayOf(7f, 4f), 0f)
        }
        val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(173, 42, 34)
            style = Paint.Style.STROKE
            strokeWidth = 1.7f
        }
        val markerTextPaint = textPaint(7.2f, Color.rgb(20, 37, 49), bold = true)
        val numberPaint = textPaint(8.4f, Color.WHITE, bold = true).apply {
            textAlign = Paint.Align.CENTER
        }

        val blankPath = polygonPath(blank)
        canvas.drawPath(blankPath, blankFillPaint)
        canvas.drawPath(blankPath, blankOutlinePaint)

        developed.panels.forEachIndexed { index, _ ->
            val panel = listOf(front[index], front[index + 1], back[index + 1], back[index])
            val panelFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = panelPalette[index % panelPalette.size]
                style = Paint.Style.FILL
            }
            canvas.drawPath(polygonPath(panel), panelFill)
            canvas.drawPath(polygonPath(panel), outlinePaint)
            drawPanelBadge(
                canvas = canvas,
                polygon = panel,
                panelIndex = index + 1,
                frontWidthMm = developed.panels[index].frontWidthMm.roundToInt(),
                rearWidthMm = developed.panels[index].rearWidthMm.roundToInt()
            )
        }

        if (metrics.offcutPerPieceM2 > 0.000001) {
            val offcut = listOf(front.last(), back.last(), blank[2], blank[3])
            canvas.drawPath(polygonPath(offcut), offcutFillPaint)
            canvas.drawPath(polygonPath(offcut), blankOutlinePaint)
            val centerX = offcut.map { it.x }.average().toFloat()
            val centerY = offcut.map { it.y }.average().toFloat()
            val offcutLabel = textPaint(7.2f, Color.rgb(112, 19, 16), bold = true).apply {
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("ODREZOK", centerX, centerY, offcutLabel)
        }

        drawPolyline(canvas, front, frontPaint)
        drawPolyline(canvas, back, rearPaint)

        front.indices.forEach { index ->
            val a = front[index]
            val b = back[index]
            when (index) {
                0, front.lastIndex -> canvas.drawLine(a.x.toFloat(), a.y.toFloat(), b.x.toFloat(), b.y.toFloat(), cutPaint)
                else -> canvas.drawLine(a.x.toFloat(), a.y.toFloat(), b.x.toFloat(), b.y.toFloat(), foldPaint)
            }
        }

        drawLineMarker(canvas, front.first(), back.first(), "K0", Color.rgb(173, 42, 34), numberPaint)
        drawLineMarker(canvas, front.last(), back.last(), "K${front.lastIndex}", Color.rgb(173, 42, 34), numberPaint)
        for (index in 1 until front.lastIndex) {
            drawLineMarker(canvas, front[index], back[index], "O$index", Color.rgb(230, 132, 38), numberPaint)
        }

        val widthLabel = "VYUŽITEĽNÁ ŠÍRKA PÁSU ${metrics.blankWidthMm} mm"
        drawDimensionLine(canvas, blank[0], blank[3], widthLabel, Color.rgb(173, 42, 34), -16f)
        drawDimensionLine(canvas, blank[1], blank[2], widthLabel, Color.rgb(173, 42, 34), 16f)

        val topLabel = textPaint(6.8f, Color.rgb(10, 110, 196), bold = true)
        canvas.drawText("PREDNÁ REZNÁ HRANA", front.first().x.toFloat(), front.first().y.toFloat() - 9f, topLabel)
        canvas.drawText("ZADNÁ REZNÁ HRANA", back.first().x.toFloat(), back.first().y.toFloat() + 14f, textPaint(6.8f, Color.rgb(83, 97, 108), bold = true))
    }

    private fun drawLegendAndProcess(
        canvas: Canvas,
        drawing: DrawingRecord,
        developed: DevelopedProfile,
        metrics: ProfileMetrics,
        plan: Plan,
        textPaint: Paint,
        borderPaint: Paint
    ) {
        val legendBox = RectF(mm(12f), mm(224f), mm(198f), mm(253f))
        val tableBox = RectF(mm(12f), mm(256f), mm(198f), mm(281f))
        canvas.drawRect(legendBox, borderPaint)
        canvas.drawRect(tableBox, borderPaint)

        val heading = Paint(textPaint).apply {
            typeface = Typeface.DEFAULT_BOLD
            textSize = 7.6f
        }
        canvas.drawText("AKO TO V DIELNI OHÝBAŤ", legendBox.left + 5f, legendBox.top + 10f, heading)
        canvas.drawText(
            "Polotovar: ${metrics.blankWidthMm} × ${(drawing.profileLengthM * 1000.0).roundToInt()} mm  •  otočenie nákresu: ${if (plan.rotated) "90°" else "0°"}",
            legendBox.left + 5f,
            legendBox.top + 20f,
            textPaint
        )

        val steps = listOf(
            LegendItem(Color.rgb(173, 42, 34), "K0 / K${developed.frontEdge.lastIndex}", "rezať po červených koncových čiarach"),
            LegendItem(Color.rgb(230, 132, 38), "O1 až O${max(1, developed.frontEdge.lastIndex - 1)}", "ohýbať v poradí oranžových čiar"),
            LegendItem(Color.rgb(10, 110, 196), "modrý okraj", "predná hrana profilu"),
            LegendItem(Color.rgb(83, 97, 108), "sivý okraj", "zadná hrana profilu"),
            LegendItem(Color.rgb(233, 102, 94), "červená plocha", "odrezok – nevstupuje do hotového kusu")
        )
        var stepY = legendBox.top + 31f
        steps.forEachIndexed { index, item ->
            if (index == 3) stepY = legendBox.top + 31f
            val columnX = if (index < 3) legendBox.left + 6f else legendBox.left + legendBox.width() / 2f
            val rowY = if (index < 3) legendBox.top + 31f + index * 8.5f else legendBox.top + 31f + (index - 3) * 8.5f
            val swatch = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = item.color; style = Paint.Style.FILL }
            canvas.drawRect(columnX, rowY - 4f, columnX + 8f, rowY + 1f, swatch)
            canvas.drawText(item.title, columnX + 11f, rowY, heading)
            canvas.drawText(item.description, columnX + 42f, rowY, textPaint)
        }

        canvas.drawText("PREHĽAD PÁSOV A OHYBOV", tableBox.left + 5f, tableBox.top + 10f, heading)
        val columns = listOf("Panel", "Predná", "Zadná", "Po paneli")
        val columnWeights = floatArrayOf(0.18f, 0.24f, 0.24f, 0.34f)
        val totalWidth = tableBox.width()
        val rowTop = tableBox.top + 13f
        val rowHeight = 8.5f
        var runningX = tableBox.left
        columns.forEachIndexed { index, title ->
            val cellWidth = totalWidth * columnWeights[index]
            canvas.drawRect(RectF(runningX, rowTop, runningX + cellWidth, rowTop + rowHeight), borderPaint)
            canvas.drawText(title.uppercase(), runningX + 3f, rowTop + 6f, textPaint)
            runningX += cellWidth
        }

        val rows = developed.panels.size
        val tableText = textPaint(6.7f, Color.rgb(28, 43, 53), bold = false)
        val boldValue = Paint(tableText).apply { typeface = Typeface.DEFAULT_BOLD }
        for (row in 0 until rows) {
            val top = rowTop + rowHeight * (row + 1)
            if (top + rowHeight > tableBox.bottom - 1f) break
            var x = tableBox.left
            val values = listOf(
                "P${row + 1}",
                "${developed.panels[row].frontWidthMm.roundToInt()} mm",
                "${developed.panels[row].rearWidthMm.roundToInt()} mm",
                if (row < rows - 1) "ohyb O${row + 1}" else "rez K${developed.frontEdge.lastIndex}"
            )
            values.forEachIndexed { index, value ->
                val cellWidth = totalWidth * columnWeights[index]
                val cell = RectF(x, top, x + cellWidth, top + rowHeight)
                canvas.drawRect(cell, borderPaint)
                val paint = if (index == 0 || index == 3) boldValue else tableText
                canvas.drawText(value, cell.left + 3f, cell.top + 6f, paint)
                x += cellWidth
            }
        }

        canvas.drawText(
            "Spotreba polotovaru / kus ${formatDecimal(metrics.sheetPerPieceM2)} m²  •  hotový plášť ${formatDecimal(metrics.netProfileAreaM2)} m²  •  odrezok ${formatDecimal(metrics.offcutPerPieceM2, 3)} m²",
            mm(12f),
            mm(286f),
            heading
        )
    }

    private fun drawCalibration(canvas: Canvas, paint: Paint) {
        val startX = mm(145f)
        val endX = startX + mm(50f)
        val y = mm(284f)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            strokeWidth = 1.2f
        }
        canvas.drawLine(startX, y, endX, y, line)
        canvas.drawLine(startX, y - 4f, startX, y + 4f, line)
        canvas.drawLine(endX, y - 4f, endX, y + 4f, line)
        canvas.drawText("kontrola tlače 50 mm", startX, y - 6f, paint)
    }

    private fun choosePlan(
        developed: DevelopedProfile,
        blankWidthMm: Double,
        availableWidthMm: Double,
        availableHeightMm: Double
    ): Plan {
        val normal = planFor(developed, blankWidthMm, availableWidthMm, availableHeightMm, rotated = false)
        val rotated = planFor(developed, blankWidthMm, availableWidthMm, availableHeightMm, rotated = true)
        return listOf(normal, rotated).sortedWith(
            compareBy<Plan> { it.denominator }
                .thenByDescending { it.usedAreaRatio }
                .thenBy { it.penalty }
        ).first()
    }

    private fun planFor(
        profile: DevelopedProfile,
        blankWidthMm: Double,
        availableWidthMm: Double,
        availableHeightMm: Double,
        rotated: Boolean
    ): Plan {
        val points = (profile.frontEdge + profile.backEdge + blankEnvelope(profile, blankWidthMm)).map { point ->
            if (rotated) FlatPoint(-point.y, point.x) else point
        }
        val width = points.maxOf { it.x } - points.minOf { it.x }
        val height = points.maxOf { it.y } - points.minOf { it.y }
        val denominator = scaleSteps.firstOrNull {
            width / it <= availableWidthMm && height / it <= availableHeightMm
        } ?: ceil(max(width / availableWidthMm, height / availableHeightMm)).toInt().coerceAtLeast(1)
        val usedWidth = width / denominator
        val usedHeight = height / denominator
        val usedArea = usedWidth * usedHeight
        val ratio = usedArea / (availableWidthMm * availableHeightMm)
        val penalty = absRatio(usedWidth / availableWidthMm, usedHeight / availableHeightMm)
        return Plan(rotated, denominator, ratio, penalty)
    }

    private fun blankEnvelope(profile: DevelopedProfile, widthMm: Double): List<FlatPoint> {
        val frontTop = profile.frontEdge.first()
        val backTop = profile.backEdge.first()
        val dx = backTop.x - frontTop.x
        val dy = backTop.y - frontTop.y
        val length = hypot(dx, dy).coerceAtLeast(0.000001)
        var normalX = -dy / length
        var normalY = dx / length
        val actualBottomCenter = FlatPoint(
            (profile.frontEdge.last().x + profile.backEdge.last().x) / 2.0,
            (profile.frontEdge.last().y + profile.backEdge.last().y) / 2.0
        )
        val topCenter = FlatPoint(
            (frontTop.x + backTop.x) / 2.0,
            (frontTop.y + backTop.y) / 2.0
        )
        val towardProfile =
            (actualBottomCenter.x - topCenter.x) * normalX +
                (actualBottomCenter.y - topCenter.y) * normalY
        if (towardProfile < 0.0) {
            normalX = -normalX
            normalY = -normalY
        }
        return listOf(
            frontTop,
            backTop,
            FlatPoint(backTop.x + normalX * widthMm, backTop.y + normalY * widthMm),
            FlatPoint(frontTop.x + normalX * widthMm, frontTop.y + normalY * widthMm)
        )
    }

    private fun drawPanelBadge(
        canvas: Canvas,
        polygon: List<FlatPoint>,
        panelIndex: Int,
        frontWidthMm: Int,
        rearWidthMm: Int
    ) {
        val centerX = polygon.map { it.x }.average().toFloat()
        val centerY = polygon.map { it.y }.average().toFloat()
        val labelLines = listOf(
            "PANEL $panelIndex",
            "predná $frontWidthMm mm",
            "zadná $rearWidthMm mm"
        )
        val width = 54f
        val height = 22f
        val box = RectF(centerX - width / 2f, centerY - height / 2f, centerX + width / 2f, centerY + height / 2f)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 255, 255, 255) }
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 46, 59)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }
        val text = textPaint(6.5f, Color.rgb(27, 46, 59), bold = true).apply { textAlign = Paint.Align.CENTER }
        canvas.drawRoundRect(box, 4f, 4f, fill)
        canvas.drawRoundRect(box, 4f, 4f, border)
        labelLines.forEachIndexed { index, line ->
            canvas.drawText(line, centerX, box.top + 6.5f + index * 6.2f, text)
        }
    }

    private fun drawLineMarker(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        color: Int,
        textPaint: Paint
    ) {
        val midX = ((start.x + end.x) / 2.0).toFloat()
        val midY = ((start.y + end.y) / 2.0).toFloat()
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
        val width = max(18f, textPaint.measureText(label) + 10f)
        val box = RectF(midX - width / 2f, midY - 7f, midX + width / 2f, midY + 7f)
        canvas.drawRoundRect(box, 7f, 7f, fill)
        canvas.drawText(label, midX, midY - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)
    }

    private fun drawDimensionLine(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        color: Int,
        offset: Float
    ) {
        val dx = (end.x - start.x).toFloat()
        val dy = (end.y - start.y).toFloat()
        val length = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(0.001f)
        val nx = -dy / length
        val ny = dx / length
        val sx = start.x.toFloat() + nx * offset
        val sy = start.y.toFloat() + ny * offset
        val ex = end.x.toFloat() + nx * offset
        val ey = end.y.toFloat() + ny * offset
        val extension = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = 0.9f
        }
        canvas.drawLine(start.x.toFloat(), start.y.toFloat(), sx, sy, extension)
        canvas.drawLine(end.x.toFloat(), end.y.toFloat(), ex, ey, extension)
        canvas.drawLine(sx, sy, ex, ey, extension)
        drawArrow(canvas, sx, sy, ex, ey, extension)
        drawArrow(canvas, ex, ey, sx, sy, extension)

        val labelPaint = textPaint(6.4f, color, bold = true)
        val midX = (sx + ex) / 2f
        val midY = (sy + ey) / 2f
        var angle = Math.toDegrees(atan2((ey - sy).toDouble(), (ex - sx).toDouble())).toFloat()
        if (angle > 90f || angle < -90f) angle += 180f
        canvas.save()
        canvas.rotate(angle, midX, midY)
        val w = labelPaint.measureText(label)
        val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE }
        canvas.drawRect(midX - w / 2f - 3f, midY - 7f, midX + w / 2f + 3f, midY + 3f, bg)
        canvas.drawText(label, midX - w / 2f, midY, labelPaint)
        canvas.restore()
    }

    private fun drawArrow(canvas: Canvas, x: Float, y: Float, towardX: Float, towardY: Float, paint: Paint) {
        val angle = atan2((towardY - y).toDouble(), (towardX - x).toDouble())
        val size = 5.5f
        val left = angle + Math.toRadians(24.0)
        val right = angle - Math.toRadians(24.0)
        canvas.drawLine(x, y, x + (kotlin.math.cos(left) * size).toFloat(), y + (kotlin.math.sin(left) * size).toFloat(), paint)
        canvas.drawLine(x, y, x + (kotlin.math.cos(right) * size).toFloat(), y + (kotlin.math.sin(right) * size).toFloat(), paint)
    }

    private fun polygonPath(points: List<FlatPoint>): Path = Path().apply {
        moveTo(points.first().x.toFloat(), points.first().y.toFloat())
        points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
        close()
    }

    private fun drawPolyline(canvas: Canvas, points: List<FlatPoint>, paint: Paint) {
        val path = Path().apply {
            moveTo(points.first().x.toFloat(), points.first().y.toFloat())
            points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
        }
        canvas.drawPath(path, paint)
    }

    private fun mm(value: Float): Float = value * PT_PER_MM

    private fun textPaint(size: Float, color: Int, bold: Boolean) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private fun absRatio(a: Double, b: Double): Double = kotlin.math.abs(a - b)

    private data class LegendItem(val color: Int, val title: String, val description: String)

    private data class Plan(
        val rotated: Boolean,
        val denominator: Int,
        val usedAreaRatio: Double,
        val penalty: Double
    ) {
        fun transform(point: FlatPoint): FlatPoint =
            if (rotated) FlatPoint(-point.y, point.x) else point
    }
}
