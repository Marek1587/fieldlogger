# Latovanie 1.1.0

Kompletná offline Android aplikácia na náčrt strešných plôch, výpočet latovania,
optimalizáciu rezov zo 4 m lát a tvorbu dielenských výkresov.

## Hlavné funkcie

- obdĺžnik, lichobežník, trojuholník alebo voľne kreslený tvar,
- presné zadanie hrán ovládacím kolieskom,
- nastaviteľný prierez, prvá lata, modul latovania a rozstup kontralát,
- samostatný prvý rozostup a postupnosť ďalších rozostupov s opakovaním poslednej hodnoty,
- optimalizácia nových lát a opätovné použitie odrezkov,
- montážne tagy radov, kusovník a rezný plán,
- tlač alebo uloženie všetkých výkresov do PDF,
- automatické lokálne uloženie rozpracovanej zákazky,
- bez internetu, účtu a servera.

## Zostavenie

Projekt vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2. Spustite:

```text
gradle :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

## Aktualizácie

Balík aplikácie je trvalo `sk.latovanie.app`. Všetky ďalšie verzie musia zvýšiť
`versionCode` a zostať podpísané súborom `app/latovanie-update-key.jks`.
Podrobnosti sú v `TRVALY-PODPIS-APK.txt`.
