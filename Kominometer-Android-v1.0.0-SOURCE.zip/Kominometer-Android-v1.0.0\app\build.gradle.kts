plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.kominometer.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.kominometer.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    val updateKey = file("kominometer-release-key.jks")
    signingConfigs {
        if (updateKey.exists()) create("stableUpdate") {
            storeFile = file("kominometer-release-key.jks")
            storePassword = "android"
            keyAlias = "kominometer-update"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfigs.findByName("stableUpdate")?.let { signingConfig = it }
            applicationIdSuffix = ""
        }
        release {
            signingConfigs.findByName("stableUpdate")?.let { signingConfig = it }
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { checkReleaseBuilds = false }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
