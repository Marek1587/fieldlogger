(function (root) {
  "use strict";
  const FACES = ["front", "left", "rear", "right"];
  const FACE_LABELS = { front: "Predná", left: "Ľavá", rear: "Zadná", right: "Pravá" };
  const FACE_VERTICES = {
    front: ["FLB", "FRB", "FLT", "FRT"],
    left: ["RLB", "FLB", "RLT", "FLT"],
    rear: ["RRB", "RLB", "RRT", "RLT"],
    right: ["FRB", "RRB", "FRT", "RRT"]
  };

  function defaultProject() {
    return {
      version: 1,
      chimneyGeometry: {
        roofHeightDifference: 200, roofLinked: true, locks: [],
        vertices: {
          FLB:{x:-250,y:-250,z:0}, FRB:{x:250,y:-250,z:0}, RLB:{x:-250,y:250,z:200}, RRB:{x:250,y:250,z:200},
          FLT:{x:-240,y:-240,z:1200}, FRT:{x:240,y:-240,z:1200}, RLT:{x:-240,y:240,z:1200}, RRT:{x:240,y:240,z:1200}
        }
      },
      claddingGeometry: {
        offsetX:0, offsetY:0, offsetZ:0, folds:25, overlaps:30,
        vertices: {
          FLB:{x:-300,y:-300,z:0}, FRB:{x:300,y:-300,z:0}, RLB:{x:-300,y:300,z:200}, RRB:{x:300,y:300,z:200},
          FLT:{x:-300,y:-300,z:1200}, FRT:{x:300,y:-300,z:1200}, RLT:{x:-300,y:300,z:1200}, RRT:{x:300,y:300,z:1200}
        }
      },
      insulationMaterial: {
        manufacturer:"Vlastný materiál", product:"Kamenná vata", thicknessOptions:[20,30,40,50,60],
        compressionMin:5, compressionTarget:10, compressionMax:20, reservePercent:12,
        frictionCoefficient:.35, pressureCurve:"0:0, 10:2, 20:8"
      }
    };
  }
  const clone = x => JSON.parse(JSON.stringify(x));
  const sub = (a,b) => ({x:a.x-b.x,y:a.y-b.y,z:a.z-b.z});
  const cross = (a,b) => ({x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x});
  const dot = (a,b) => a.x*b.x+a.y*b.y+a.z*b.z;
  const norm = a => Math.hypot(a.x,a.y,a.z);
  const normalize = a => { const n=norm(a)||1; return {x:a.x/n,y:a.y/n,z:a.z/n}; };
  const avg = p => ({x:p.reduce((s,v)=>s+v.x,0)/p.length,y:p.reduce((s,v)=>s+v.y,0)/p.length,z:p.reduce((s,v)=>s+v.z,0)/p.length});

  function translatedCladding(project) {
    const c=project.claddingGeometry;
    return Object.fromEntries(Object.entries(c.vertices).map(([k,v])=>[k,{x:v.x+c.offsetX,y:v.y+c.offsetY,z:v.z+c.offsetZ}]));
  }
  function faceDimension(g,face,edge) {
    const [bl,br,tl,tr]=FACE_VERTICES[face];
    if(edge==="bottom") return face==="front"||face==="rear"?Math.abs(g[br].x-g[bl].x):Math.abs(g[br].y-g[bl].y);
    if(edge==="top") return face==="front"||face==="rear"?Math.abs(g[tr].x-g[tl].x):Math.abs(g[tr].y-g[tl].y);
    return edge==="left"?Math.abs(g[tl].z-g[bl].z):Math.abs(g[tr].z-g[br].z);
  }
  function setFaceDimension(g,face,edge,value) {
    const next=clone(g), [bl,br,tl,tr]=FACE_VERTICES[face];
    if(!Number.isFinite(value)||value<=0) return next;
    if(edge==="left"||edge==="right") { const b=edge==="left"?bl:br,t=edge==="left"?tl:tr; next[t].z=next[b].z+value; return next; }
    const a=edge==="bottom"?bl:tl,b=edge==="bottom"?br:tr,axis=face==="front"||face==="rear"?"x":"y";
    const mid=(next[a][axis]+next[b][axis])/2,sign=next[b][axis]>=next[a][axis]?1:-1;
    next[a][axis]=mid-sign*value/2; next[b][axis]=mid+sign*value/2; return next;
  }
  function applyRoofLink(g,difference) {
    const n=clone(g); n.FLB.z=0;n.FRB.z=0;n.RLB.z=difference;n.RRB.z=difference;
    const top=(n.FLT.z+n.FRT.z)/2;n.RLT.z=top;n.RRT.z=top;return n;
  }
  function gapsForFace(chimney,cladding,face) {
    const keys=FACE_VERTICES[face],cp=keys.map(k=>cladding[k]);let normal=normalize(cross(sub(cp[1],cp[0]),sub(cp[2],cp[0])));
    if(dot(normal,sub(avg(cp),avg(Object.values(cladding))))<0) normal={x:-normal.x,y:-normal.y,z:-normal.z};
    const v=keys.map(k=>-dot(normal,sub(chimney[k],cp[0])));return {LD:v[0],PD:v[1],LH:v[2],PH:v[3]};
  }
  function solveAllGaps(project) { const c=project.chimneyGeometry.vertices,o=translatedCladding(project);return Object.fromEntries(FACES.map(f=>[f,gapsForFace(c,o,f)])); }
  function gapStats(g) { const v=Object.values(g),min=Math.min(...v),max=Math.max(...v);return {min,max,average:v.reduce((s,x)=>s+x,0)/v.length,spread:max-min}; }
  function autoFit(project) {
    let best=clone(project),bestScore=Infinity,cx=project.claddingGeometry.offsetX,cy=project.claddingGeometry.offsetY,step=100;
    const score=p=>{const v=Object.values(solveAllGaps(p)).flatMap(Object.values),collision=v.filter(x=>x<0).reduce((s,x)=>s+x*x*1000,0);return collision+(Math.max(...v)-Math.min(...v))**2+Math.max(...v)*.01;};
    for(let round=0;round<14;round++){for(const dx of[-step,0,step])for(const dy of[-step,0,step]){const p=clone(project);p.claddingGeometry.offsetX=cx+dx;p.claddingGeometry.offsetY=cy+dy;const s=score(p);if(s<bestScore){bestScore=s;best=p;}}cx=best.claddingGeometry.offsetX;cy=best.claddingGeometry.offsetY;step/=2;}return best;
  }
  function combinations(options,maxLayers=3){const r=[];function walk(start,a){if(a.length)r.push(a);if(a.length===maxLayers)return;for(let i=start;i<options.length;i++)walk(i,a.concat(options[i]));}walk(0,[]);return r;}
  function insulationPlan(gaps,material){
    const stats=gapStats(gaps),target=stats.average/(1-material.compressionTarget/100);
    if(stats.min<0)return{layers:[],total:0,targetNominal:0,compressionMin:0,compressionMax:0,status:"KOLÍZIA",baseLayer:0,supplements:{LD:0,PD:0,LH:0,PH:0}};
    const opts=[...new Set(material.thicknessOptions.filter(n=>n>0))].sort((a,b)=>a-b);
    const c=combinations(opts).map(layers=>{const total=layers.reduce((s,n)=>s+n,0),comps=Object.values(gaps).map(g=>(total-g)/total*100),valid=Math.min(...comps)>=material.compressionMin&&Math.max(...comps)<=material.compressionMax;return{layers,total,comps,valid,score:(valid?0:10000)+Math.abs(total-target)+layers.length*.1};}).sort((a,b)=>a.score-b.score)[0]||{layers:[],total:0,comps:[0],valid:false};
    const desired=stats.min/(1-material.compressionTarget/100),base=opts.filter(v=>v<=desired+.01).at(-1)||opts[0]||0;
    const supplements=Object.fromEntries(Object.entries(gaps).map(([k,g])=>[k,Math.max(0,Math.round((g/(1-material.compressionTarget/100)-base)*10)/10)]));
    return{layers:c.layers,total:c.total,targetNominal:target,compressionMin:Math.min(...c.comps),compressionMax:Math.max(...c.comps),status:c.valid&&stats.spread<=12?"OK":"POZOR",baseLayer:base,supplements};
  }
  function faceArea(g,face){const [bl,br,tl,tr]=FACE_VERTICES[face].map(k=>g[k]);const tri=(a,b,c)=>norm(cross(sub(b,a),sub(c,a)))/2;return(tri(bl,br,tl)+tri(br,tr,tl))/1e6;}
  const api={FACES,FACE_LABELS,FACE_VERTICES,defaultProject,clone,translatedCladding,faceDimension,setFaceDimension,applyRoofLink,gapsForFace,solveAllGaps,gapStats,autoFit,insulationPlan,faceArea};
  root.KominSolver=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(typeof globalThis!=="undefined"?globalThis:this);
