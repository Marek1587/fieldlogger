const test = require("node:test");
const assert = require("node:assert/strict");
const S = require("../app/src/main/assets/solver.js");

function boxProject(bottom, top, clad) {
  const p=S.defaultProject();
  for(const k of ["FLB","RLB","FLT","RLT"]) p.chimneyGeometry.vertices[k].x=-(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FRB","RRB","FRT","RRT"]) p.chimneyGeometry.vertices[k].x=(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FLB","FRB","FLT","FRT"]) p.chimneyGeometry.vertices[k].y=-(k.endsWith("B")?bottom:top)/2;
  for(const k of ["RLB","RRB","RLT","RRT"]) p.chimneyGeometry.vertices[k].y=(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FLB","RLB","FLT","RLT"]) p.claddingGeometry.vertices[k].x=-clad/2;
  for(const k of ["FRB","RRB","FRT","RRT"]) p.claddingGeometry.vertices[k].x=clad/2;
  for(const k of ["FLB","FRB","FLT","FRT"]) p.claddingGeometry.vertices[k].y=-clad/2;
  for(const k of ["RLB","RRB","RLT","RRT"]) p.claddingGeometry.vertices[k].y=clad/2;
  return p;
}
test("ideálny komín 500 v opláštení 600 má 50 mm",()=>{for(const g of Object.values(S.solveAllGaps(boxProject(500,500,600))))for(const v of Object.values(g))assert.ok(Math.abs(v-50)<1e-8)});
test("zbiehavý komín zachová dolnú a hornú medzeru",()=>{const g=S.solveAllGaps(boxProject(500,480,600));assert.equal(Math.round(g.front.LD),50);assert.equal(Math.round(g.front.LH),60)});
test("strešná väzba vytvorí rozdiel 200 mm",()=>{const p=S.defaultProject(),g=S.applyRoofLink(p.chimneyGeometry.vertices,200);assert.equal(g.RLB.z-g.FLB.z,200);assert.equal(S.faceDimension(g,"left","left"),1000);assert.equal(S.faceDimension(g,"left","right"),1200)});
test("optimal fit vyváži excentrický komín",()=>{const p=boxProject(500,500,600);Object.values(p.chimneyGeometry.vertices).forEach(v=>{v.x+=28;v.y-=17});const b=Object.values(S.solveAllGaps(p)).flatMap(Object.values),q=S.autoFit(p),a=Object.values(S.solveAllGaps(q)).flatMap(Object.values);assert.ok(Math.max(...a)-Math.min(...a)<Math.max(...b)-Math.min(...b));assert.ok(Math.abs(q.claddingGeometry.offsetX-28)<1)});
test("kolízia zostane zápornou medzerou a izolácia je KOLÍZIA",()=>{const p=boxProject(500,500,480),g=S.solveAllGaps(p);assert.ok(Object.values(g).flatMap(Object.values).some(v=>v<0));assert.equal(S.insulationPlan(g.front,p.insulationMaterial).status,"KOLÍZIA")});
test("spoločný uzol zmení prednú aj ľavú výšku",()=>{const p=S.defaultProject(),g=S.setFaceDimension(p.chimneyGeometry.vertices,"front","left",1100);assert.equal(S.faceDimension(g,"front","left"),1100);assert.equal(S.faceDimension(g,"left","right"),1100)});
