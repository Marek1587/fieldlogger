const test=require("node:test"),assert=require("node:assert/strict"),fs=require("node:fs"),path=require("node:path");
const html=fs.readFileSync(path.join(__dirname,"../app/src/main/assets/index.html"),"utf8");
test("offline pracovný priestor obsahuje päť kariet a natívny 3D most",()=>{for(const x of["1 Komín","2 Opláštenie","3 Izolácia","4 Výsledok","5 Diely","Kominometer.open3D"])assert.match(html,new RegExp(x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")))});
test("technické kóty sú editovateľné priamo v SVG",()=>{assert.match(html,/data-edit=/);assert.match(html,/class=\"dim-value\"/);assert.match(html,/showModal\(\)/)});
