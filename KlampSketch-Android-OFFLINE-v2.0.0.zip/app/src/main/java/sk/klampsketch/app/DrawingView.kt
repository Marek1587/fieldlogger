package sk.klampsketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var onProfileChanged: ((MutableList<ProfilePoint>) -> Unit)? = null
    var onSegmentSelected: ((segmentIndex: Int, currentLengthMm: Int) -> Unit)? = null
    var onAngleSelected: ((vertexIndex: Int, currentAngle: Int) -> Unit)? = null

    private var profile = mutableListOf<ProfilePoint>()
    private val rawStroke = mutableListOf<ProfilePoint>()
    private var sketchMode = true
    private var renderResult = ProfileRenderResult(emptyList(), emptyList(), emptyList())
    private var draggedPointIndex: Int? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var movedDuringTouch = false

    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(8, 119, 201)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 4f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(234, 239, 242)
        strokeWidth = resources.displayMetrics.density
    }

    init {
        setBackgroundColor(Color.WHITE)
        isFocusable = true
        contentDescription = "Plocha na kreslenie klampiarskeho profilu"
    }

    fun setProfile(points: List<ProfilePoint>) {
        profile = points.map { it.copy() }.toMutableList()
        sketchMode = profile.size < 2
        rawStroke.clear()
        invalidate()
    }

    fun getProfile(): MutableList<ProfilePoint> =
        profile.map { it.copy() }.toMutableList()

    fun startNewSketch() {
        profile.clear()
        rawStroke.clear()
        sketchMode = true
        draggedPointIndex = null
        invalidate()
    }

    fun updateSegmentLength(segmentIndex: Int, lengthMm: Int) {
        profile = ProfileGeometry.updateSegmentLength(profile, segmentIndex, lengthMm)
        onProfileChanged?.invoke(getProfile())
        invalidate()
    }

    fun updateAngle(vertexIndex: Int, angle: Int) {
        profile = ProfileGeometry.updateAngle(profile, vertexIndex, angle)
        onProfileChanged?.invoke(getProfile())
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawGrid(canvas)
        val area = RectF(
            paddingLeft.toFloat(),
            paddingTop.toFloat(),
            (width - paddingRight).toFloat(),
            (height - paddingBottom).toFloat()
        )
        renderResult = ProfileRenderer.renderTechnical(
            canvas,
            area,
            profile,
            labelSize = resources.displayMetrics.scaledDensity * 16f,
            showHandles = true
        )

        if (rawStroke.size >= 2) {
            val path = Path()
            path.moveTo(rawStroke.first().x, rawStroke.first().y)
            rawStroke.drop(1).forEach { point -> path.lineTo(point.x, point.y) }
            canvas.drawPath(path, rawPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                movedDuringTouch = false
                lastTouchX = event.x
                lastTouchY = event.y
                if (sketchMode) {
                    rawStroke.clear()
                    rawStroke += ProfilePoint(event.x, event.y)
                } else {
                    draggedPointIndex = nearestHandle(event.x, event.y)
                }
                invalidate()
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val distance = hypot(
                    (event.x - lastTouchX).toDouble(),
                    (event.y - lastTouchY).toDouble()
                ).toFloat()
                if (distance > resources.displayMetrics.density * 2f) {
                    movedDuringTouch = true
                }

                if (sketchMode) {
                    if (rawStroke.isEmpty() || distance > resources.displayMetrics.density * 2f) {
                        rawStroke += ProfilePoint(event.x, event.y)
                    }
                } else {
                    draggedPointIndex?.let { index ->
                        val modelScale = modelUnitsPerScreenPixel()
                        profile[index].x += (event.x - lastTouchX) * modelScale
                        profile[index].y += (event.y - lastTouchY) * modelScale
                        onProfileChanged?.invoke(getProfile())
                    }
                }
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (sketchMode && rawStroke.size >= 2) {
                    profile = ProfileGeometry.magicClean(rawStroke)
                    rawStroke.clear()
                    sketchMode = false
                    onProfileChanged?.invoke(getProfile())
                    performClick()
                } else if (draggedPointIndex != null) {
                    profile = ProfileGeometry.snapProfile(profile)
                    draggedPointIndex = null
                    onProfileChanged?.invoke(getProfile())
                    performClick()
                } else if (!movedDuringTouch && event.actionMasked == MotionEvent.ACTION_UP) {
                    handleTap(event.x, event.y)
                }
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        renderResult.angleHitBoxes.firstOrNull { (_, box) -> box.contains(x, y) }
            ?.let { (index, _) ->
                onAngleSelected?.invoke(
                    index,
                    ProfileGeometry.internalAngle(profile, index)
                )
                return
            }
        renderResult.segmentHitBoxes.firstOrNull { (_, box) -> box.contains(x, y) }
            ?.let { (index, _) ->
                onSegmentSelected?.invoke(
                    index,
                    ProfileGeometry.segmentLength(profile, index)
                )
            }
    }

    private fun nearestHandle(x: Float, y: Float): Int? {
        val radius = resources.displayMetrics.density * 30f
        return renderResult.screenPoints
            .mapIndexed { index, point ->
                index to hypot(
                    (x - point.x).toDouble(),
                    (y - point.y).toDouble()
                ).toFloat()
            }
            .filter { it.second <= radius }
            .minByOrNull { it.second }
            ?.first
    }

    private fun modelUnitsPerScreenPixel(): Float {
        if (profile.size < 2 || renderResult.screenPoints.size < 2) return 1f
        val model = hypot(
            (profile[1].x - profile[0].x).toDouble(),
            (profile[1].y - profile[0].y).toDouble()
        ).toFloat()
        val screen = hypot(
            (renderResult.screenPoints[1].x - renderResult.screenPoints[0].x).toDouble(),
            (renderResult.screenPoints[1].y - renderResult.screenPoints[0].y).toDouble()
        ).toFloat()
        return if (screen > 0.01f) model / screen else 1f
    }

    private fun drawGrid(canvas: Canvas) {
        val step = resources.displayMetrics.density * 24f
        var x = 0f
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += step
        }
        var y = 0f
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += step
        }
    }
}
