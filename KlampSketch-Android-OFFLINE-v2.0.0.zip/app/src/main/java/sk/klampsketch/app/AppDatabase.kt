package sk.klampsketch.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class AppDatabase(context: Context) :
    SQLiteOpenHelper(context, "klampsketch-offline.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                customer TEXT NOT NULL DEFAULT '',
                address TEXT NOT NULL DEFAULT ''
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE drawings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                name TEXT NOT NULL,
                identifier TEXT NOT NULL,
                points_json TEXT NOT NULL,
                material TEXT NOT NULL,
                ral TEXT NOT NULL,
                thickness_mm REAL NOT NULL,
                profile_length_m REAL NOT NULL,
                quantity INTEGER NOT NULL,
                photo_path TEXT,
                updated_at INTEGER NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX drawings_project_idx ON drawings(project_id)")
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun ensureDefaultProject(): ProjectRecord {
        val projects = listProjects()
        if (projects.isNotEmpty()) return projects.first()
        val id = insertProject(ProjectRecord(name = "Moja stavba"))
        return ProjectRecord(id = id, name = "Moja stavba")
    }

    fun insertProject(project: ProjectRecord): Long {
        val values = ContentValues().apply {
            put("name", project.name)
            put("customer", project.customer)
            put("address", project.address)
        }
        return writableDatabase.insertOrThrow("projects", null, values)
    }

    fun listProjects(): List<ProjectRecord> {
        val result = mutableListOf<ProjectRecord>()
        readableDatabase.query(
            "projects",
            arrayOf("id", "name", "customer", "address"),
            null,
            null,
            null,
            null,
            "name COLLATE NOCASE"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += ProjectRecord(
                    id = cursor.getLong(0),
                    name = cursor.getString(1),
                    customer = cursor.getString(2),
                    address = cursor.getString(3)
                )
            }
        }
        return result
    }

    fun saveDrawing(drawing: DrawingRecord): Long {
        val values = drawingValues(drawing)
        if (drawing.id == 0L) {
            return writableDatabase.insertOrThrow("drawings", null, values)
        }
        writableDatabase.update(
            "drawings",
            values,
            "id = ?",
            arrayOf(drawing.id.toString())
        )
        return drawing.id
    }

    fun copyDrawing(drawing: DrawingRecord, targetProjectId: Long): Long {
        return saveDrawing(
            drawing.copy(
                id = 0,
                projectId = targetProjectId,
                name = drawing.name,
                identifier = nextIdentifier(),
                points = drawing.points.map { it.copy() }.toMutableList(),
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    fun nextIdentifier(): String {
        val number = readableDatabase.rawQuery(
            "SELECT COALESCE(MAX(id), 0) + 1 FROM drawings",
            null
        ).use { cursor ->
            cursor.moveToFirst()
            cursor.getLong(0)
        }
        return "KL-${number.toString().padStart(5, '0')}"
    }

    fun listDrawings(projectId: Long): List<DrawingRecord> {
        val result = mutableListOf<DrawingRecord>()
        readableDatabase.query(
            "drawings",
            DRAWING_COLUMNS,
            "project_id = ?",
            arrayOf(projectId.toString()),
            null,
            null,
            "updated_at DESC"
        ).use { cursor ->
            while (cursor.moveToNext()) {
                result += cursorToDrawing(cursor)
            }
        }
        return result
    }

    fun getDrawing(id: Long): DrawingRecord? {
        readableDatabase.query(
            "drawings",
            DRAWING_COLUMNS,
            "id = ?",
            arrayOf(id.toString()),
            null,
            null,
            null,
            "1"
        ).use { cursor ->
            return if (cursor.moveToFirst()) cursorToDrawing(cursor) else null
        }
    }

    fun deleteDrawing(id: Long) {
        writableDatabase.delete("drawings", "id = ?", arrayOf(id.toString()))
    }

    private fun drawingValues(drawing: DrawingRecord) = ContentValues().apply {
        put("project_id", drawing.projectId)
        put("name", drawing.name)
        put("identifier", drawing.identifier)
        put("points_json", encodePoints(drawing.points))
        put("material", drawing.material)
        put("ral", drawing.ral)
        put("thickness_mm", drawing.thicknessMm)
        put("profile_length_m", drawing.profileLengthM)
        put("quantity", drawing.quantity)
        put("photo_path", drawing.photoPath)
        put("updated_at", drawing.updatedAt)
    }

    private fun cursorToDrawing(cursor: android.database.Cursor) = DrawingRecord(
        id = cursor.getLong(0),
        projectId = cursor.getLong(1),
        name = cursor.getString(2),
        identifier = cursor.getString(3),
        points = decodePoints(cursor.getString(4)),
        material = cursor.getString(5),
        ral = cursor.getString(6),
        thicknessMm = cursor.getDouble(7),
        profileLengthM = cursor.getDouble(8),
        quantity = cursor.getInt(9),
        photoPath = if (cursor.isNull(10)) null else cursor.getString(10),
        updatedAt = cursor.getLong(11)
    )

    companion object {
        private val DRAWING_COLUMNS = arrayOf(
            "id",
            "project_id",
            "name",
            "identifier",
            "points_json",
            "material",
            "ral",
            "thickness_mm",
            "profile_length_m",
            "quantity",
            "photo_path",
            "updated_at"
        )
    }
}
