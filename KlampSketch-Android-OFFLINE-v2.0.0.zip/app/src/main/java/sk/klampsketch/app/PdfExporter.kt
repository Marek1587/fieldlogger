package sk.klampsketch.app

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfExporter {
    private const val PAGE_WIDTH = 1240
    private const val PAGE_HEIGHT = 1754

    fun export(
        context: Context,
        project: ProjectRecord,
        drawings: List<DrawingRecord>
    ): String {
        require(drawings.isNotEmpty()) { "Nie sú vybrané žiadne výkresy." }
        val document = PdfDocument()
        try {
            drawings.forEachIndexed { index, drawing ->
                val pageInfo = PdfDocument.PageInfo.Builder(
                    PAGE_WIDTH,
                    PAGE_HEIGHT,
                    index + 1
                ).create()
                val page = document.startPage(pageInfo)
                drawPage(
                    page.canvas,
                    project,
                    drawing,
                    index + 1,
                    drawings.size
                )
                document.finishPage(page)
            }

            val date = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            val fileName = "KlampSketch-${safeFileName(project.name)}-$date.pdf"
            openOutput(context, fileName).use { output -> document.writeTo(output) }
            return "Downloads/KlampSketch/$fileName"
        } finally {
            document.close()
        }
    }

    private fun drawPage(
        canvas: Canvas,
        project: ProjectRecord,
        drawing: DrawingRecord,
        pageNumber: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 50, 62)
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            textSize = 30f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(79, 96, 108)
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(8, 119, 201)
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val pageBorder = RectF(42f, 42f, PAGE_WIDTH - 42f, PAGE_HEIGHT - 42f)
        canvas.drawRect(pageBorder, borderPaint)
        canvas.drawText("KLAMPIARSKY VÝROBNÝ NÁKRES", 72f, 88f, headerPaint)
        canvas.drawText(drawing.identifier, 72f, 116f, smallPaint)
        canvas.drawText(
            "LIST $pageNumber/$totalPages",
            1050f,
            88f,
            smallPaint
        )

        val technicalArea = RectF(65f, 135f, 820f, 1140f)
        val threeDArea = RectF(845f, 135f, 1175f, 470f)
        val photoArea = RectF(845f, 500f, 1175f, 835f)
        canvas.drawRect(technicalArea, borderPaint)
        canvas.drawRect(threeDArea, borderPaint)
        canvas.drawRect(photoArea, borderPaint)
        canvas.drawText("TECHNICKÝ PROFIL", 82f, 165f, sectionPaint)

        ProfileRenderer.renderTechnical(
            canvas,
            RectF(
                technicalArea.left + 12f,
                technicalArea.top + 38f,
                technicalArea.right - 12f,
                technicalArea.bottom - 12f
            ),
            drawing.points,
            labelSize = 22f,
            showHandles = false
        )
        ProfileRenderer.renderProportional3D(
            canvas,
            RectF(
                threeDArea.left + 8f,
                threeDArea.top + 8f,
                threeDArea.right - 8f,
                threeDArea.bottom - 8f
            ),
            drawing.points,
            profileLengthMm = (drawing.profileLengthM * 1000.0).toFloat(),
            labelSize = 15f
        )
        drawPhoto(canvas, drawing.photoPath, photoArea, smallPaint)

        val metrics = calculateMetrics(drawing)
        val table = RectF(65f, 1190f, 1175f, 1685f)
        canvas.drawRect(table, borderPaint)
        val rows = listOf(
            "STAVBA" to project.name,
            "ZÁKAZNÍK" to project.customer,
            "ADRESA" to project.address,
            "NÁZOV VÝROBKU" to drawing.name,
            "IDENTIFIKAČNÉ ČÍSLO" to drawing.identifier,
            "ROZVINUTÁ ŠÍRKA" to "${metrics.developedWidthMm} mm",
            "POČET OHYBOV" to "${metrics.bends} ×",
            "DĹŽKA PROFILU" to "${formatDecimal(drawing.profileLengthM, 2)} m",
            "SPOTREBA PLECHU / KUS" to "${formatDecimal(metrics.sheetPerPieceM2)} m²",
            "POČET KUSOV" to "${drawing.quantity} ks",
            "SPOTREBA PLECHU CELKOM" to "${formatDecimal(metrics.sheetTotalM2)} m²",
            "DRUH PLECHU" to "${drawing.material}, ${formatDecimal(drawing.thicknessMm, 1)} mm",
            "FARBA" to drawing.ral,
            "HMOTNOSŤ PROFILU" to "${formatDecimal(metrics.weightPerPieceKg)} kg",
            "HMOTNOSŤ CELKOM" to "${formatDecimal(metrics.weightTotalKg)} kg",
            "DÁTUM" to SimpleDateFormat("d. M. yyyy", Locale("sk", "SK")).format(Date())
        )
        val columnWidth = table.width() / 2f
        val rowHeight = table.height() / 8f
        rows.chunked(8).forEachIndexed { column, columnRows ->
            columnRows.forEachIndexed { row, value ->
                val cell = RectF(
                    table.left + column * columnWidth,
                    table.top + row * rowHeight,
                    table.left + (column + 1) * columnWidth,
                    table.top + (row + 1) * rowHeight
                )
                drawCell(canvas, cell, value.first, value.second, borderPaint)
            }
        }
    }

    private fun drawPhoto(
        canvas: Canvas,
        photoPath: String?,
        area: RectF,
        labelPaint: Paint
    ) {
        val bitmap = photoPath
            ?.takeIf { File(it).isFile }
            ?.let { BitmapFactory.decodeFile(it) }
        if (bitmap == null) {
            val centered = Paint(labelPaint).apply { textAlign = Paint.Align.CENTER }
            canvas.drawText(
                "FOTOGRAFIA ZO STAVBY",
                area.centerX(),
                area.centerY(),
                centered
            )
            return
        }

        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val targetRatio = area.width() / area.height()
        val source = if (sourceRatio > targetRatio) {
            val wantedWidth = (bitmap.height * targetRatio).toInt()
            val left = (bitmap.width - wantedWidth) / 2
            Rect(left, 0, left + wantedWidth, bitmap.height)
        } else {
            val wantedHeight = (bitmap.width / targetRatio).toInt()
            val top = (bitmap.height - wantedHeight) / 2
            Rect(0, top, bitmap.width, top + wantedHeight)
        }
        canvas.drawBitmap(bitmap, source, area, Paint(Paint.ANTI_ALIAS_FLAG))
        bitmap.recycle()
    }

    private fun drawCell(
        canvas: Canvas,
        cell: RectF,
        label: String,
        value: String,
        borderPaint: Paint
    ) {
        canvas.drawRect(cell, borderPaint)
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(91, 106, 118)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 44, 57)
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        canvas.drawText(label, cell.left + 12f, cell.top + 18f, labelPaint)
        canvas.drawText(
            value.ifBlank { "—" }.take(56),
            cell.left + 12f,
            cell.top + 43f,
            valuePaint
        )
    }

    private fun openOutput(context: Context, fileName: String): OutputStream {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/KlampSketch"
                )
            }
            val uri = context.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
            ) ?: error("Súbor sa nepodarilo vytvoriť.")
            return context.contentResolver.openOutputStream(uri)
                ?: error("Súbor sa nepodarilo otvoriť.")
        }

        @Suppress("DEPRECATION")
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "KlampSketch"
        )
        if (!directory.exists() && !directory.mkdirs()) {
            error("Priečinok Downloads/KlampSketch sa nepodarilo vytvoriť.")
        }
        return FileOutputStream(File(directory, fileName))
    }

    private fun safeFileName(value: String): String =
        value.replace(Regex("""[\\/:*?"<>|\r\n]"""), "_")
            .trim()
            .ifBlank { "Stavba" }
}
