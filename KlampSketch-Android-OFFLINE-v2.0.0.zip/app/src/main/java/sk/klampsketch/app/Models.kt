package sk.klampsketch.app

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.roundToInt

data class ProfilePoint(var x: Float, var y: Float)

data class ProjectRecord(
    val id: Long = 0,
    val name: String,
    val customer: String = "",
    val address: String = ""
)

data class DrawingRecord(
    val id: Long = 0,
    val projectId: Long,
    var name: String,
    var identifier: String,
    var points: MutableList<ProfilePoint>,
    var material: String = "Pozinkovaná oceľ",
    var ral: String = "RAL 7016",
    var thicknessMm: Double = 0.7,
    var profileLengthM: Double = 2.0,
    var quantity: Int = 1,
    var photoPath: String? = null,
    var updatedAt: Long = System.currentTimeMillis()
)

data class ProfileMetrics(
    val developedWidthMm: Int,
    val bends: Int,
    val sheetPerPieceM2: Double,
    val sheetTotalM2: Double,
    val weightPerPieceKg: Double,
    val weightTotalKg: Double
)

fun encodePoints(points: List<ProfilePoint>): String {
    val result = JSONArray()
    points.forEach { point ->
        result.put(
            JSONObject()
                .put("x", point.x.toDouble())
                .put("y", point.y.toDouble())
        )
    }
    return result.toString()
}

fun decodePoints(json: String): MutableList<ProfilePoint> {
    return try {
        val array = JSONArray(json)
        MutableList(array.length()) { index ->
            val point = array.getJSONObject(index)
            ProfilePoint(
                point.optDouble("x", 0.0).toFloat(),
                point.optDouble("y", 0.0).toFloat()
            )
        }
    } catch (_: Exception) {
        mutableListOf()
    }
}

fun calculateMetrics(drawing: DrawingRecord): ProfileMetrics {
    val widthMm = drawing.points.zipWithNext().sumOf { (start, end) ->
        snapFive(hypot(
            (end.x - start.x).toDouble(),
            (end.y - start.y).toDouble()
        ))
    }
    val bends = (drawing.points.size - 2).coerceAtLeast(0)
    val sheetPerPiece = widthMm / 1000.0 * drawing.profileLengthM
    val density = when {
        drawing.material.contains("hlin", ignoreCase = true) -> 2700.0
        drawing.material.contains("meď", ignoreCase = true) ||
            drawing.material.contains("med", ignoreCase = true) -> 8960.0
        drawing.material.contains("titán", ignoreCase = true) ||
            drawing.material.contains("zinok", ignoreCase = true) -> 7140.0
        else -> 7850.0
    }
    val weightPerPiece = sheetPerPiece * (drawing.thicknessMm / 1000.0) * density
    return ProfileMetrics(
        developedWidthMm = widthMm,
        bends = bends,
        sheetPerPieceM2 = sheetPerPiece,
        sheetTotalM2 = sheetPerPiece * drawing.quantity,
        weightPerPieceKg = weightPerPiece,
        weightTotalKg = weightPerPiece * drawing.quantity
    )
}

fun snapFive(value: Double): Int =
    ((value / 5.0).roundToInt() * 5).coerceAtLeast(5)

fun formatDecimal(value: Double, digits: Int = 2): String =
    "%.${digits}f".format(java.util.Locale("sk", "SK"), value)
