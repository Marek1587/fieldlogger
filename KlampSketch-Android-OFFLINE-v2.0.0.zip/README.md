# KlampSketch Offline pre Android

Natívna Android aplikácia v Kotline. Nepoužíva WebView, JavaScript, hosting,
OpenAI účet ani internetové pripojenie. Stavby, výkresy a fotografie ukladá
iba do telefónu a PDF vytvára priamo v zariadení.

## Zostavenie cez pripravený GitHub Actions workflow

1. Nahrajte ZIP s týmto projektom do koreňa GitHub repozitára.
2. Súbor workflow musí byť v `.github/workflows/`.
3. Spustite workflow alebo odošlite zmenu do vetvy `main`/`master`.
4. Hotové `app-debug.apk` bude dostupné medzi Artifacts daného workflow.

Projekt podporuje kreslenie prstom, automatické vyrovnanie profilu, úpravu
dĺžok po 5 mm, celé uhly, stavby, kopírovanie profilov, fotoaparát, galériu
a natívne PDF s technickým aj proporčným 3D náhľadom.
