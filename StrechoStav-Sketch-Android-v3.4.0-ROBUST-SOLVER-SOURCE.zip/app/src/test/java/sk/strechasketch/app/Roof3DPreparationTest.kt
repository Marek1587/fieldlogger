package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class Roof3DPreparationTest {
    private val origin = GeoPoint(49.0, 18.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    @Test
    fun imperfectHipAndRidgeDrawingStillProduces3DMeshAndQuantities() {
        val lowerJunction = geo(6.18, 5.55)
        val upperJunction = geo(5.84, 12.62)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 18.0), geo(0.0, 18.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.RIDGE, start = lowerJunction.copy(), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(0.0, 18.0), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 18.0), end = upperJunction.copy())
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val quantities = RoofQuantityEngine.calculate(project)
        val mesh = RoofMeshBuilder.build(project)

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.code }, !prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.graph.nodes.values.all { it.z.isFinite() })
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
        assertTrue(quantities.totals.perimeterM > 0.0)
        assertTrue(mesh.triangles.isNotEmpty())
        assertTrue(mesh.edges.isNotEmpty())
    }
}
