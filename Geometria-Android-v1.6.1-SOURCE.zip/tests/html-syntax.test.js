const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");

test("Android projekt je priamo v koreňovom priečinku", function () {
  const root = path.resolve(__dirname, "..");
  assert.equal(fs.existsSync(path.join(root, "settings.gradle.kts")), true);
  assert.equal(fs.existsSync(path.join(root, "app", "build.gradle.kts")), true);
  assert.equal(fs.existsSync(path.join(root, "app", "src", "main", "AndroidManifest.xml")), true);
});

test("offline HTML obsahuje platný JavaScript a všetky režimy", function () {
  const html = fs.readFileSync(path.resolve(__dirname, "../app/src/main/assets/index.html"), "utf8");
  const scripts = Array.from(html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi), function (match) { return match[1]; });
  assert.equal(scripts.length, 1);
  assert.doesNotThrow(function () { new Function(scripts[0]); });
  assert.match(html, /ROZDELENIE/);
  assert.match(html, /data-basic-wheel/);
  assert.match(html, /VSTUP · KLIKNITE NA KÓTU/);
  assert.match(html, /VÝSLEDNÝ NÁKRES/);
  assert.match(html, /M300 100 V126 l-18 12 l36 14 l-36 14 l18 12 V190/);
  assert.match(html, /M500 105 V131 l18 12 l-36 14 l36 14 l-18 12 V195/);
  assert.doesNotMatch(html, /M225 98 l10 -14/);
  assert.match(html, /KOREKCIA/);
  assert.match(html, /TROJUHOLNÍK/);
  assert.match(html, /data-triangle-side/);
  assert.match(html, /UHLOVANIE/);
  assert.match(html, /data-squaring-key/);
  assert.match(html, /Pevný krok kolieska: 5 mm/);
  assert.match(html, /KOLMICA/);
  assert.match(html, /data-slope-key/);
  assert.match(html, /Pevný krok kolieska: 1°/);
  assert.match(html, /PRÍPONKY/);
  assert.match(html, /data-clips-key="angleDegrees"/);
  assert.match(html, /data-clips-key="length"/);
  assert.match(html, /S · \$\{fmtWholeMm\(r\.spacing\)\} mm/);
  assert.match(html, /ZDIEĽAŤ OBRÁZOK/);
  assert.match(html, /shareSvgImage/);
  assert.match(html, /wheelStep=500/);
  assert.match(html, /bindDimensionInputSteppers/);
  assert.doesNotMatch(html, /Pevný krok kolieska: 1 mm/);
  assert.doesNotMatch(html, /Pevný krok kolieska: 0,5°/);
  assert.doesNotMatch(html, /<button[^>]+data-wheel-step/);
  assert.match(html, /class="rotary"/);
  assert.doesNotMatch(html, /Rozmer sedí/);
  assert.doesNotMatch(html, /Zadajte cieľ a šírku/);
});
