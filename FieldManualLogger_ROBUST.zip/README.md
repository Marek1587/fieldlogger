# Field Manual Logger ROBUST

Fixes XlsxWriter Kotlin compilation issues.

Features:
- Lokalita / Miesto persist after save
- Note is required
- Tile UI with emoji
- Drag/drop tile order
- Speech-to-text to note field
- Local XLSX
- Optional Google Sheets sync
