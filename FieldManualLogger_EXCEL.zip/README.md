# Field Manual Logger EXCEL

Ručná Android aplikácia pre terénny denník.

## Výstup

Preferovaný verejný priečinok:

- /storage/emulated/0/Documents/FieldLogger/field_manual_log.xlsx
- /storage/emulated/0/Documents/FieldLogger/photos/

Ak Android zablokuje verejný zápis, aplikácia použije fallback:

- Android/data/sk.strechostav.fieldmanual/files/Documents/FieldLogger/

## Funkcie

- ručné udalosti
- poznámky
- GPS
- fotodokumentácia
- kompresia fotiek
- Excel XLSX export po každom zázname
- zdieľanie Excelu
