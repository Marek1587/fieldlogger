package sk.strechostav.fieldmanual

import android.content.Context
import android.location.Location
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ManualLogStore {
    private val header = listOf(
        "timestamp",
        "event_type",
        "lat",
        "lon",
        "accuracy_m",
        "provider",
        "title",
        "note",
        "photo_path"
    )

    fun publicBaseDir(): File {
        val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val d = File(docs, "FieldLogger")
        d.mkdirs()
        return d
    }

    fun fallbackBaseDir(context: Context): File {
        val d = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "FieldLogger")
        d.mkdirs()
        return d
    }

    fun baseDir(context: Context): File {
        return try {
            val d = publicBaseDir()
            val test = File(d, ".write_test")
            test.writeText("ok", Charsets.UTF_8)
            test.delete()
            d
        } catch (_: Exception) {
            fallbackBaseDir(context)
        }
    }

    fun photoDir(context: Context): File {
        val d = File(baseDir(context), "photos")
        d.mkdirs()
        return d
    }

    fun dataFile(context: Context): File {
        val f = File(baseDir(context), "field_manual_log_data.tsv")
        if (!f.exists()) {
            f.writeText(header.joinToString("\t") + "\n", Charsets.UTF_8)
        }
        return f
    }

    fun xlsxFile(context: Context): File {
        return File(baseDir(context), "field_manual_log.xlsx")
    }

    fun now(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    }

    fun stamp(): String {
        return SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    }

    fun append(
        context: Context,
        eventType: String,
        title: String,
        note: String = "",
        location: Location? = null,
        photoPath: String = ""
    ): Boolean {
        return try {
            val values = listOf(
                now(),
                eventType,
                location?.latitude?.toString() ?: "",
                location?.longitude?.toString() ?: "",
                location?.accuracy?.toString() ?: "",
                location?.provider ?: "",
                title,
                note,
                photoPath
            )
            dataFile(context).appendText(values.joinToString("\t") { clean(it) } + "\n", Charsets.UTF_8)
            rebuildXlsx(context)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun rebuildXlsx(context: Context): Boolean {
        return try {
            val rows = dataFile(context).readLines(Charsets.UTF_8).map { line ->
                line.split("\t")
            }
            XlsxWriter.writeWorkbook(xlsxFile(context), rows)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun clean(value: String): String {
        return value.replace("\n", " ").replace("\r", " ").replace("\t", " ").trim()
    }
}
