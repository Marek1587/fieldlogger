package sk.strechostav.fieldmanual

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val reqPerm = 1001
    private val reqPhoto = 2001

    private lateinit var noteEdit: EditText
    private lateinit var statusText: TextView

    private var pendingPhotoNote: String = ""
    private var pendingPhotoFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        buildUi()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(28, 28, 28, 28)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Field Manual Logger"
        title.textSize = 27f
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "Ručný terénny denník do Excelu v Dokumentoch"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Poznámka k záznamu..."
        noteEdit.minLines = 3
        noteEdit.gravity = Gravity.TOP
        root.addView(noteEdit, full())

        addButton(root, "Príchod na stavbu / miesto") {
            writeEvent("SITE_ARRIVAL", "Príchod na stavbu / miesto", takeNote())
        }

        addButton(root, "Obhliadka / kontrola") {
            writeEvent("INSPECTION", "Obhliadka / kontrola", takeNote())
        }

        addButton(root, "Meranie / zameranie") {
            writeEvent("MEASUREMENT", "Meranie / zameranie", takeNote())
        }

        addButton(root, "Telefonát / komunikácia") {
            writeEvent("PHONE_CALL", "Telefonát / komunikácia", takeNote())
        }

        addButton(root, "Odchod zo stavby / miesta") {
            writeEvent("SITE_DEPARTURE", "Odchod zo stavby / miesta", takeNote())
        }

        addButton(root, "Vlastná poznámka") {
            writeEvent("MANUAL_NOTE", "Vlastná poznámka", takeNote())
        }

        addButton(root, "Rýchly GPS zápis") {
            writeEvent("GPS_CHECK", "Rýchly GPS zápis", "")
        }

        addButton(root, "Odfotiť + zapísať fotku") {
            pendingPhotoNote = takeNote()
            openCamera()
        }

        addButton(root, "Prebuildovať Excel") {
            val ok = ManualLogStore.rebuildXlsx(this)
            Toast.makeText(this, if (ok) "Excel obnovený." else "Excel sa nepodarilo obnoviť.", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        addButton(root, "Zdieľať Excel") {
            shareExcel()
        }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, 18, 0, 0)
        root.addView(statusText, full())

        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, text: String, fn: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 15f
        b.setOnClickListener { fn() }
        root.addView(b, full())
    }

    private fun full(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(0, 8, 0, 8)
        }
    }

    private fun takeNote(): String {
        val note = noteEdit.text.toString().trim()
        noteEdit.setText("")
        return note
    }

    private fun requestPermissionsIfNeeded() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )

        val missing = perms.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), reqPerm)
        }
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager

        if (
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        return try {
            lm.getProviders(true)
                .mapNotNull { provider ->
                    try {
                        lm.getLastKnownLocation(provider)
                    } catch (_: Exception) {
                        null
                    }
                }
                .maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeEvent(eventType: String, title: String, note: String, photoPath: String = "") {
        val ok = ManualLogStore.append(
            context = this,
            eventType = eventType,
            title = title,
            note = note,
            location = bestLocation(),
            photoPath = photoPath
        )

        Toast.makeText(this, if (ok) "Zapísané do Excelu: $title" else "Zápis zlyhal.", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun refreshStatus() {
        val xlsx = ManualLogStore.xlsxFile(this)
        val data = ManualLogStore.dataFile(this)
        statusText.text =
            "Excel: ${xlsx.absolutePath}\nVeľkosť Excelu: ${if (xlsx.exists()) xlsx.length() else 0} B\nDáta: ${data.absolutePath}\nFotky: ${ManualLogStore.photoDir(this).absolutePath}"
    }

    private fun openCamera() {
        val f = File(cacheDir, "camera_${ManualLogStore.stamp()}.jpg")
        pendingPhotoFile = f

        val uri: Uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            f
        )

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

        try {
            startActivityForResult(intent, reqPhoto)
        } catch (e: Exception) {
            Toast.makeText(this, "Nepodarilo sa otvoriť fotoaparát.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android framework")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == reqPhoto) {
            val f = pendingPhotoFile

            if (resultCode == RESULT_OK && f != null && f.exists()) {
                val small = compressImage(f)
                writeEvent(
                    "PHOTO_NOTE",
                    "Fotodokumentácia",
                    pendingPhotoNote,
                    small.absolutePath
                )
                pendingPhotoNote = ""
            } else {
                Toast.makeText(this, "Fotka nebola uložená.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun compressImage(src: File): File {
        val out = File(ManualLogStore.photoDir(this), "photo_${ManualLogStore.stamp()}_compressed.jpg")
        val bmp = BitmapFactory.decodeFile(src.absolutePath) ?: return src

        val maxSide = 1600
        val scale = minOf(
            1.0f,
            maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat()
        )

        val resized = if (scale < 1.0f) {
            Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt(),
                (bmp.height * scale).toInt(),
                true
            )
        } else {
            bmp
        }

        FileOutputStream(out).use { stream ->
            resized.compress(Bitmap.CompressFormat.JPEG, 82, stream)
        }

        if (resized != bmp) {
            resized.recycle()
        }
        bmp.recycle()

        return out
    }

    private fun shareExcel() {
        val f = ManualLogStore.xlsxFile(this)
        if (!f.exists()) {
            ManualLogStore.rebuildXlsx(this)
        }

        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            f
        )

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivity(Intent.createChooser(intent, "Zdieľať Excel"))
    }
}
