plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.strechostav.fieldmanual"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.fieldmanual"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "1.0-manual-excel"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
