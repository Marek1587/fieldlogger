# Mobile Activity Logger SCREEN CONTEXT

Separate Android app for automatic background logging.

## Features

- UsageStats foreground app segments.
- Accessibility screen context:
  - screen_title
  - screen_text
  - page_title_guess
  - url_guess, if visible
  - chatgpt_topic_guess, if visible
- Ignores own apps and launchers.
- Local queue when Google sync fails.
- Auto start after phone reboot when enabled.

## Required phone settings

1. Paste Apps Script Web App URL.
2. Allow Usage Access.
3. Allow Accessibility service:
   Mobile Activity Logger screen context.
4. Start background logger.
5. Set battery mode to Unrestricted / Neobmedzené.

## Privacy

Does not capture screenshots.
Does not record keystrokes.
Skips password fields and editable text fields.
Logs a short visible screen text snippet only for personal activity reporting.

## Apps Script

Use `docs/google_apps_script_unified_screen.gs`.
