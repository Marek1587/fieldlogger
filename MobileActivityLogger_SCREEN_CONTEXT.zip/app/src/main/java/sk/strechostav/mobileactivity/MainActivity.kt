package sk.strechostav.mobileactivity

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var urlEdit: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBasicPermissions()
        buildUi()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(28, 28, 28, 28)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Mobile Activity Logger"
        title.textSize = 26f
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "Logovanie aplikácií + názvov obrazoviek do Google Sheets"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        urlEdit = EditText(this)
        urlEdit.hint = "Apps Script Web App URL"
        urlEdit.setText(SettingsStore.url(this))
        urlEdit.minLines = 2
        root.addView(urlEdit, full())

        addButton(root, "Uložiť Google URL") {
            SettingsStore.setUrl(this, urlEdit.text.toString())
            Toast.makeText(this, "URL uložená.", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        addButton(root, "Povoliť Usage Access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        addButton(root, "Povoliť Accessibility záznamy obrazoviek") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        addButton(root, "Spustiť logger na pozadí") {
            startLogger()
        }

        addButton(root, "Zastaviť logger") {
            SettingsStore.setEnabled(this, false)
            stopService(Intent(this, MobileActivityLoggerService::class.java))
            Toast.makeText(this, "Logger zastavený.", Toast.LENGTH_SHORT).show()
            refreshStatus()
        }

        addButton(root, "Test zápis do Google Sheets") {
            testSync()
        }

        addButton(root, "Otvoriť nastavenia batérie") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Nastavenia batérie sa nepodarilo otvoriť.", Toast.LENGTH_SHORT).show()
            }
        }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, 18, 0, 0)
        root.addView(statusText, full())

        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, text: String, fn: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 15f
        b.setOnClickListener { fn() }
        root.addView(b, full())
    }

    private fun full(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(0, 8, 0, 8)
        }
    }

    private fun requestBasicPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 1001)
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    private fun hasAccessibilityEnabled(): Boolean {
        return try {
            val expected = "$packageName/${ScreenContextAccessibilityService::class.java.name}"
            val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            TextUtils.SimpleStringSplitter(':').also { splitter ->
                splitter.setString(enabled)
                while (splitter.hasNext()) {
                    val service = splitter.next()
                    if (service.equals(expected, ignoreCase = true) || service.contains(packageName)) return true
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    private fun startLogger() {
        SettingsStore.setUrl(this, urlEdit.text.toString())

        if (SettingsStore.url(this).isBlank()) {
            Toast.makeText(this, "Najprv vlož Google Web App URL.", Toast.LENGTH_LONG).show()
            return
        }

        if (!hasUsageAccess()) {
            Toast.makeText(this, "Najprv povoľ Usage Access.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }

        SettingsStore.setEnabled(this, true)

        try {
            val i = Intent(this, MobileActivityLoggerService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
            Toast.makeText(this, "Logger spustený.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Spustenie zlyhalo: ${e.message}", Toast.LENGTH_LONG).show()
        }

        refreshStatus()
    }

    private fun testSync() {
        SettingsStore.setUrl(this, urlEdit.text.toString())

        val event = linkedMapOf(
            "timestamp" to LocalLogStore.now(),
            "source" to "mobile_activity",
            "event_type" to "MOBILE_ACTIVITY_TEST",
            "title" to "Test zápis z Mobile Activity Logger",
            "note" to "Test pripojenia na Google Sheets",
            "package_name" to packageName,
            "app_name" to "Mobile Activity Logger",
            "start_time" to "",
            "end_time" to "",
            "duration_sec" to "",
            "screen_title" to "Test screen context",
            "capture_method" to "manual_test",
            "confidence" to "1.0"
        )

        LocalLogStore.appendLocal(this, event)
        GoogleSync.sendOrQueue(this, event) { ok, msg ->
            runOnUiThread {
                Toast.makeText(this, if (ok) "Google sync OK" else "Sync zlyhal/queue: $msg", Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }
    }

    private fun refreshStatus() {
        val pendingCount = LocalLogStore.loadPending(this).size
        statusText.text =
            "URL: ${if (SettingsStore.url(this).isBlank()) "nenastavená" else "nastavená"}\n" +
            "Usage Access: ${if (hasUsageAccess()) "povolený" else "nepovolený"}\n" +
            "Accessibility screen context: ${if (hasAccessibilityEnabled()) "povolený" else "nepovolený"}\n" +
            "Autostart po reštarte: ${if (SettingsStore.enabled(this)) "zapnutý" else "vypnutý"}\n" +
            "Pending queue: $pendingCount\n" +
            "Lokálny log: ${LocalLogStore.logFile(this).absolutePath}"
    }
}
