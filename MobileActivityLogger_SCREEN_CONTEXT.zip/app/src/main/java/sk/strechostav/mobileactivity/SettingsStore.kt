package sk.strechostav.mobileactivity

import android.content.Context

object SettingsStore {
    private const val PREF = "mobile_activity_logger"
    private const val KEY_URL = "web_app_url"
    private const val KEY_ENABLED = "logger_enabled"

    fun url(context: Context): String {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY_URL, "") ?: ""
    }

    fun setUrl(context: Context, url: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_URL, url.trim())
            .apply()
    }

    fun enabled(context: Context): Boolean {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(KEY_ENABLED, false)
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }
}
