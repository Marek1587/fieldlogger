package sk.strechostav.mobileactivity

import android.content.Context
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GoogleSync {
    fun sendOrQueue(context: Context, event: Map<String, String>, callback: ((Boolean, String) -> Unit)? = null) {
        val json = toJson(event)

        Thread {
            val ok = sendJson(context, json)
            if (!ok) LocalLogStore.queue(context, json)
            callback?.invoke(ok, if (ok) "OK" else "queued")
        }.start()
    }

    fun flushPending(context: Context) {
        Thread {
            val pending = LocalLogStore.loadPending(context)
            if (pending.isEmpty()) return@Thread

            val remain = mutableListOf<String>()
            for (line in pending) {
                val ok = sendJson(context, line)
                if (!ok) remain.add(line)
            }
            LocalLogStore.replacePending(context, remain)
        }.start()
    }

    private fun sendJson(context: Context, json: String): Boolean {
        val target = SettingsStore.url(context)
        if (target.isBlank()) return false

        return try {
            val conn = URL(target).openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(json) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (_: Exception) {
            false
        }
    }

    fun toJson(event: Map<String, String>): String {
        return event.entries.joinToString(prefix = "{", postfix = "}") { item ->
            "\"" + esc(item.key) + "\":\"" + esc(item.value) + "\""
        }
    }

    private fun esc(v: String): String {
        return v
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", " ")
            .replace("\r", " ")
    }
}
