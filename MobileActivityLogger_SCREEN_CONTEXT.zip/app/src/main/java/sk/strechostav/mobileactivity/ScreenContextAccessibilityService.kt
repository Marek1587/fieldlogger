package sk.strechostav.mobileactivity

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenContextAccessibilityService : AccessibilityService() {
    private var lastKey: String = ""
    private var lastWriteMillis: Long = 0L

    private val ignoredPackages = setOf(
        "sk.strechostav.mobileactivity",
        "sk.strechostav.fieldmanual",
        "sk.strechostav.fieldlogger",
        "com.sec.android.app.launcher",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.android.systemui",
        "com.google.android.inputmethod.latin",
        "com.samsung.android.honeyboard"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        if (ignoredPackages.contains(pkg)) return

        val now = System.currentTimeMillis()

        val appName = appLabel(pkg)
        val cls = event.className?.toString() ?: ""

        val visibleText = collectVisibleText(rootInActiveWindow)
        val eventText = event.text?.joinToString(" ")?.trim() ?: ""

        val title = guessTitle(appName, eventText, visibleText)
        val screenText = visibleText.take(700)

        val key = "$pkg|$title|${screenText.take(120)}"
        if (key == lastKey && now - lastWriteMillis < 45_000L) return
        if (now - lastWriteMillis < 4_000L) return

        val eventMap = baseEvent(
            eventType = "SCREEN_CONTEXT",
            title = title,
            note = screenText
        ).toMutableMap()

        eventMap["package_name"] = pkg
        eventMap["app_name"] = appName
        eventMap["screen_class"] = cls
        eventMap["screen_title"] = title
        eventMap["screen_text"] = screenText
        eventMap["page_title_guess"] = pageTitleGuess(pkg, appName, title, screenText)
        eventMap["url_guess"] = urlGuess(screenText)
        eventMap["chatgpt_topic_guess"] = chatgptTopicGuess(pkg, appName, title, screenText)
        eventMap["capture_method"] = "accessibility_visible_text"
        eventMap["confidence"] = if (screenText.isNotBlank()) "0.70" else "0.35"

        LocalLogStore.appendLocal(this, eventMap)
        GoogleSync.sendOrQueue(this, eventMap)

        lastKey = key
        lastWriteMillis = now
    }

    override fun onInterrupt() {}

    private fun collectVisibleText(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val out = ArrayList<String>()
        collectNode(root, out, 0)
        return out
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" | ")
            .take(900)
    }

    private fun collectNode(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 8 || out.size > 50) return

        if (node.isPassword) return

        val cls = node.className?.toString()?.lowercase() ?: ""
        // Neberieme editovateľné textové polia, aby sa nelogovali heslá / zadávané texty.
        if (cls.contains("edittext")) return

        val txt = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        if (!txt.isNullOrBlank() && txt.length <= 160) out.add(txt)
        if (!desc.isNullOrBlank() && desc.length <= 160) out.add(desc)

        for (i in 0 until node.childCount) {
            collectNode(node.getChild(i), out, depth + 1)
        }
    }

    private fun guessTitle(appName: String, eventText: String, visibleText: String): String {
        val candidates = listOf(eventText, visibleText.split("|").firstOrNull() ?: "", appName)
        return candidates.firstOrNull { it.trim().isNotBlank() }?.trim()?.take(180) ?: appName
    }

    private fun pageTitleGuess(pkg: String, appName: String, title: String, text: String): String {
        val p = pkg.lowercase()
        val a = appName.lowercase()
        return if (p.contains("chrome") || p.contains("browser") || a.contains("browser") || a.contains("chrome")) title else ""
    }

    private fun chatgptTopicGuess(pkg: String, appName: String, title: String, text: String): String {
        val p = pkg.lowercase()
        val a = appName.lowercase()
        val t = (title + " " + text).lowercase()
        return if (p.contains("openai") || a.contains("chatgpt") || t.contains("chatgpt")) title else ""
    }

    private fun urlGuess(text: String): String {
        val regex = Regex("""https?://[^\s|]+""")
        return regex.find(text)?.value ?: ""
    }

    private fun appLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    private fun baseEvent(eventType: String, title: String, note: String): Map<String, String> {
        val loc = LocationHelper.bestLocation(this)
        return linkedMapOf(
            "timestamp" to LocalLogStore.now(),
            "source" to "mobile_screen",
            "event_type" to eventType,
            "title" to title,
            "note" to note,
            "lat" to (loc?.latitude?.toString() ?: ""),
            "lon" to (loc?.longitude?.toString() ?: ""),
            "accuracy_m" to (loc?.accuracy?.toString() ?: ""),
            "provider" to (loc?.provider ?: ""),
            "package_name" to "",
            "app_name" to "",
            "start_time" to "",
            "end_time" to "",
            "duration_sec" to ""
        )
    }
}
