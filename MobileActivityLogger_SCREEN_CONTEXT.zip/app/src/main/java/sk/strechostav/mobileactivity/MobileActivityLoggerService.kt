package sk.strechostav.mobileactivity

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class MobileActivityLoggerService : Service() {
    private val channelId = "mobile_activity_logger"
    private val notificationId = 6201
    private val handler = Handler(Looper.getMainLooper())

    private var activePackage: String = ""
    private var activeAppName: String = ""
    private var activeStartMillis: Long = 0L
    private var lastPollMillis: Long = 0L
    private var lastHeartbeatMillis: Long = 0L

    private val ignoredPackages = setOf(
        "sk.strechostav.mobileactivity",
        "sk.strechostav.fieldmanual",
        "sk.strechostav.fieldlogger",
        "com.sec.android.app.launcher",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.android.systemui"
    )

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            LocationHelper.cachedLocation = location
        }

        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}

        @Deprecated("Deprecated in Android framework")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            try { poll() } catch (_: Exception) {}
            handler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForeground(notificationId, buildNotification())
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        SettingsStore.setEnabled(this, true)
        startLocationUpdates()
        writeSystemEvent("MOBILE_ACTIVITY_LOGGER_START", "Mobile Activity Logger spustený")

        lastPollMillis = System.currentTimeMillis() - 60_000L
        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)

        return START_STICKY
    }

    override fun onDestroy() {
        finalizeActiveSegment("service_stop")
        handler.removeCallbacks(pollRunnable)
        stopLocationUpdates()
        writeSystemEvent("MOBILE_ACTIVITY_LOGGER_STOP", "Mobile Activity Logger zastavený")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startLocationUpdates() {
        if (!LocationHelper.hasPermission(this)) return

        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        LocationHelper.cachedLocation = LocationHelper.bestLocation(this)

        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)

        for (provider in providers) {
            try {
                if (lm.isProviderEnabled(provider)) {
                    lm.requestLocationUpdates(provider, 60_000L, 20f, locationListener, Looper.getMainLooper())
                }
            } catch (_: Exception) {}
        }
    }

    private fun stopLocationUpdates() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.removeUpdates(locationListener)
        } catch (_: Exception) {}
    }

    private fun poll() {
        val pkg = currentForegroundPackage()
        val now = System.currentTimeMillis()

        if (pkg.isBlank()) return

        if (ignoredPackages.contains(pkg)) {
            if (activePackage.isNotBlank()) {
                finalizeActiveSegment("ignored_or_own_app_opened")
                clearActive()
            }
            GoogleSync.flushPending(this)
            return
        }

        val appName = appLabel(pkg)

        if (activePackage.isBlank()) {
            activePackage = pkg
            activeAppName = appName
            activeStartMillis = now
            lastHeartbeatMillis = now
            GoogleSync.flushPending(this)
            return
        }

        if (pkg != activePackage) {
            finalizeActiveSegment("app_changed")
            activePackage = pkg
            activeAppName = appName
            activeStartMillis = now
            lastHeartbeatMillis = now
            GoogleSync.flushPending(this)
            return
        }

        if (now - lastHeartbeatMillis >= 5 * 60 * 1000L) {
            finalizeActiveSegment("heartbeat_5min")
            activePackage = pkg
            activeAppName = appName
            activeStartMillis = now
            lastHeartbeatMillis = now
        }

        GoogleSync.flushPending(this)
    }

    private fun currentForegroundPackage(): String {
        val now = System.currentTimeMillis()
        val begin = maxOf(lastPollMillis, now - 2 * 60_000L)
        lastPollMillis = now

        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

            var latestPkg = ""
            var latestTime = 0L

            val events = usm.queryEvents(begin, now)
            val event = UsageEvents.Event()

            while (events.hasNextEvent()) {
                events.getNextEvent(event)
                val type = event.eventType
                val foreground =
                    type == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    (Build.VERSION.SDK_INT >= 29 && type == UsageEvents.Event.ACTIVITY_RESUMED)

                if (foreground && event.timeStamp >= latestTime) {
                    latestTime = event.timeStamp
                    latestPkg = event.packageName ?: ""
                }
            }

            if (latestPkg.isNotBlank()) return latestPkg

            val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 60_000L, now)
            stats?.filter { it.lastTimeUsed > 0 }?.maxByOrNull { it.lastTimeUsed }?.packageName ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun finalizeActiveSegment(reason: String) {
        if (activePackage.isBlank() || activeStartMillis <= 0L) return

        val end = System.currentTimeMillis()
        val duration = ((end - activeStartMillis) / 1000L).coerceAtLeast(0L)
        if (duration < 2L) return

        val event = baseEvent(
            eventType = "APP_SEGMENT",
            title = activeAppName,
            note = "Používanie aplikácie: $activeAppName; dôvod: $reason; trvanie: $duration s"
        ).toMutableMap()

        event["package_name"] = activePackage
        event["app_name"] = activeAppName
        event["start_time"] = formatTime(activeStartMillis)
        event["end_time"] = formatTime(end)
        event["duration_sec"] = duration.toString()

        LocalLogStore.appendLocal(this, event)
        GoogleSync.sendOrQueue(this, event)
    }

    private fun clearActive() {
        activePackage = ""
        activeAppName = ""
        activeStartMillis = 0L
        lastHeartbeatMillis = 0L
    }

    private fun writeSystemEvent(eventType: String, title: String) {
        val event = baseEvent(eventType, title, "")
        LocalLogStore.appendLocal(this, event)
        GoogleSync.sendOrQueue(this, event)
    }

    private fun baseEvent(eventType: String, title: String, note: String): Map<String, String> {
        val loc = LocationHelper.bestLocation(this)
        return linkedMapOf(
            "timestamp" to LocalLogStore.now(),
            "source" to "mobile_activity",
            "event_type" to eventType,
            "title" to title,
            "note" to note,
            "lat" to (loc?.latitude?.toString() ?: ""),
            "lon" to (loc?.longitude?.toString() ?: ""),
            "accuracy_m" to (loc?.accuracy?.toString() ?: ""),
            "provider" to (loc?.provider ?: ""),
            "package_name" to "",
            "app_name" to "",
            "start_time" to "",
            "end_time" to "",
            "duration_sec" to ""
        )
    }

    private fun formatTime(millis: Long): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        return sdf.format(java.util.Date(millis))
    }

    private fun appLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, channelId) else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder
            .setContentTitle("Mobile Activity Logger beží")
            .setContentText("Logujem aplikácie a názvy obrazoviek.")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(channelId, "Mobile Activity Logger", NotificationManager.IMPORTANCE_LOW)
        channel.description = "Logovanie aktívnych aplikácií a názvov obrazoviek."
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }
}
