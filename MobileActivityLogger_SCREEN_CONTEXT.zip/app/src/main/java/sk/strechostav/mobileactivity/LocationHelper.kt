package sk.strechostav.mobileactivity

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager

object LocationHelper {
    @Volatile
    var cachedLocation: Location? = null

    fun hasPermission(context: Context): Boolean {
        return context.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            context.checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    fun bestLocation(context: Context): Location? {
        cachedLocation?.let { return it }

        if (!hasPermission(context)) return null

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

        return try {
            val loc = lm.getProviders(true).mapNotNull { provider ->
                try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null }
            }.maxByOrNull { it.time }
            if (loc != null) cachedLocation = loc
            loc
        } catch (_: Exception) {
            null
        }
    }
}
