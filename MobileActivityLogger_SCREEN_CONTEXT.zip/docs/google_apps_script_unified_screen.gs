// Unified Field Logger endpoint
// Manual Field Logger + Mobile Activity Logger + Screen Context -> one Google Sheet.
//
// Deploy:
// Execute as: Me
// Who has access: Anyone

const SPREADSHEET_ID = '1FC3tOKFC2hyid--rvhoISmF_1CNYiRhN'; // uprav podľa svojej natívnej Google tabuľky
const SHEET_NAME = 'Manual Log';
const PHOTO_FOLDER_NAME = 'FieldLoggerPhotos';

const HEADER = [
  'timestamp',
  'source',
  'event_type',
  'lokalita',
  'miesto',
  'lat',
  'lon',
  'accuracy_m',
  'provider',
  'title',
  'note',
  'package_name',
  'app_name',
  'start_time',
  'end_time',
  'duration_sec',
  'screen_class',
  'screen_title',
  'screen_text',
  'page_title_guess',
  'url_guess',
  'chatgpt_topic_guess',
  'capture_method',
  'confidence',
  'local_photo_path',
  'photo_file_id',
  'photo_url',
  'photo_filename'
];

function doPost(e) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME);
    if (!sh) sh = ss.insertSheet(SHEET_NAME);

    ensureHeaders_(sh);

    const d = JSON.parse((e && e.postData && e.postData.contents) ? e.postData.contents : '{}');

    let photoFileId = '';
    let photoUrl = '';
    let photoFilename = d.photo_filename || '';

    if (d.photo_base64 && d.photo_filename) {
      const folder = getOrCreateFolder_(PHOTO_FOLDER_NAME);
      const bytes = Utilities.base64Decode(d.photo_base64);
      const mimeType = d.photo_mime_type || 'image/jpeg';
      const filename = makeSafeFilename_(d.photo_filename, d.timestamp, d.lokalita, d.miesto);

      const blob = Utilities.newBlob(bytes, mimeType, filename);
      const file = folder.createFile(blob);

      photoFileId = file.getId();
      photoUrl = file.getUrl();
      photoFilename = filename;

      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    }

    const rowObj = {
      timestamp: d.timestamp || '',
      source: d.source || (d.package_name || d.app_name ? 'mobile_activity' : 'manual'),
      event_type: d.event_type || '',
      lokalita: d.lokalita || '',
      miesto: d.miesto || '',
      lat: d.lat || '',
      lon: d.lon || '',
      accuracy_m: d.accuracy_m || '',
      provider: d.provider || '',
      title: d.title || '',
      note: d.note || '',
      package_name: d.package_name || '',
      app_name: d.app_name || '',
      start_time: d.start_time || '',
      end_time: d.end_time || '',
      duration_sec: d.duration_sec || '',
      screen_class: d.screen_class || '',
      screen_title: d.screen_title || '',
      screen_text: d.screen_text || '',
      page_title_guess: d.page_title_guess || '',
      url_guess: d.url_guess || '',
      chatgpt_topic_guess: d.chatgpt_topic_guess || '',
      capture_method: d.capture_method || '',
      confidence: d.confidence || '',
      local_photo_path: d.local_photo_path || d.photo_path || '',
      photo_file_id: photoFileId || d.photo_file_id || '',
      photo_url: photoUrl || d.photo_url || '',
      photo_filename: photoFilename || d.photo_filename || ''
    };

    const headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
    sh.appendRow(headers.map(h => rowObj[h] || ''));

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, photo_url: photoUrl, photo_file_id: photoFileId }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput('Unified Field Logger screen endpoint OK')
    .setMimeType(ContentService.MimeType.TEXT);
}

function ensureHeaders_(sh) {
  if (sh.getLastRow() === 0 || sh.getLastColumn() === 0) {
    sh.getRange(1, 1, 1, HEADER.length).setValues([HEADER]);
    sh.setFrozenRows(1);
    return;
  }

  const existing = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
  const missing = HEADER.filter(h => existing.indexOf(h) === -1);

  if (missing.length > 0) {
    sh.getRange(1, existing.length + 1, 1, missing.length).setValues([missing]);
  }

  sh.setFrozenRows(1);
}

function getOrCreateFolder_(name) {
  const it = DriveApp.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(name);
}

function makeSafeFilename_(original, timestamp, lokalita, miesto) {
  const ts = String(timestamp || new Date().toISOString()).replace(/[^0-9A-Za-z_-]/g, '_');
  const loc = String(lokalita || '').substring(0, 40).replace(/[^0-9A-Za-zÁÄČĎÉÍĹĽŇÓÔŔŠŤÚÝŽáäčďéíĺľňóôŕšťúýž_-]/g, '_');
  const place = String(miesto || '').substring(0, 40).replace(/[^0-9A-Za-zÁÄČĎÉÍĹĽŇÓÔŔŠŤÚÝŽáäčďéíĺľňóôŕšťúýž_-]/g, '_');
  const ext = String(original).toLowerCase().endsWith('.png') ? '.png' : '.jpg';
  const parts = [ts, loc, place].filter(x => x && x.length > 0);
  return (parts.join('__') || 'field_photo') + ext;
}
