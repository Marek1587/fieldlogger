package sk.doklady.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sk.doklady.HomeUiState
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentStatus
import sk.doklady.slovakLabel
import java.text.NumberFormat
import java.util.Currency
import java.util.Locale

@Composable
fun HomeScreen(
    state: HomeUiState,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
    onSystemPicker: () -> Unit,
    onDocument: (String) -> Unit,
    onExport: () -> Unit,
    onDiagnostics: () -> Unit,
    onRetry: (String) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Spacer(Modifier.height(14.dp)) }
        item { Text("DOKLADY", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold) }
        item {
            Button(onClick = onCamera, Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(16.dp)) {
                Text("ODFOTIŤ DOKLAD", fontWeight = FontWeight.Bold)
            }
        }
        item {
            Button(
                onClick = onGallery,
                enabled = !state.importing,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2E9E5), contentColor = Color(0xFF153E30)),
                shape = RoundedCornerShape(16.dp),
            ) { Text(if (state.importing) "IMPORTUJEM…" else "VYBRAŤ Z GALÉRIE", fontWeight = FontWeight.SemiBold) }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                androidx.compose.material3.TextButton(onClick = onSystemPicker) { Text("Vybrať cez systém") }
            }
        }
        if (state.activeBatch.isNotEmpty()) item { BatchProgress(state) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Stat("Čaká", state.queuedCount, Modifier.weight(1f))
                Stat("Spracované", state.processedCount, Modifier.weight(1f))
                Stat("Na kontrolu", state.reviewCount, Modifier.weight(1f))
                Stat("Chyba", state.errorCount, Modifier.weight(1f))
            }
        }
        item {
            Button(onClick = onExport, Modifier.fillMaxWidth().height(52.dp)) { Text("EXPORT EXCEL") }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("POSLEDNÉ DOKLADY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                androidx.compose.material3.TextButton(onClick = onDiagnostics) { Text("Diagnostika") }
            }
        }
        items(state.documents, key = { it.id }) { document ->
            DocumentCard(document, { onDocument(document.id) }, { onRetry(document.id) })
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun BatchProgress(state: HomeUiState) {
    val current = state.currentDocument
    Surface(shape = RoundedCornerShape(18.dp), color = Color(0xFFEAF3EF)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("SPRACOVANIE DOKLADOV", fontWeight = FontWeight.Bold)
            Text("${state.batchDone} / ${state.activeBatch.size}", style = MaterialTheme.typography.headlineSmall)
            LinearProgressIndicator(
                progress = { state.batchPercent / 100f },
                modifier = Modifier.fillMaxWidth().height(9.dp),
            )
            Text("${state.batchPercent} %", style = MaterialTheme.typography.labelMedium)
            current?.let {
                Text("Aktuálne: ${it.originalDisplayName ?: it.id.take(8)}")
                Text(it.status.slovakLabel(), color = Color(0xFF1E5B45), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun DocumentCard(document: DocumentEntity, onClick: () -> Unit, onRetry: () -> Unit) {
    Surface(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(16.dp), tonalElevation = 1.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(document.supplierName ?: document.originalDisplayName ?: "Fotografia ${document.id.take(8)}", fontWeight = FontWeight.SemiBold)
            if (document.purchaseDate != null || document.grossTotalCents != null) {
                Row {
                    document.purchaseDate?.let { Text(it); Spacer(Modifier.width(12.dp)) }
                    document.grossTotalCents?.let { Text(formatMoney(it, document.currency ?: "EUR"), fontWeight = FontWeight.Bold) }
                }
            }
            Text(document.status.slovakLabel(), color = statusColor(document.status))
            LinearProgressIndicator(progress = { document.stageProgress / 100f }, Modifier.fillMaxWidth())
            Text("${document.stageProgress} %", style = MaterialTheme.typography.labelSmall)
            if (document.status == DocumentStatus.PROCESSED || document.status == DocumentStatus.REVIEW_REQUIRED) {
                Text("Položiek: ${document.itemCount} · Confidence: ${document.confidence} %", style = MaterialTheme.typography.bodySmall)
            }
            if (document.status == DocumentStatus.ERROR) {
                Text(document.errorMessage ?: "Chyba spracovania", color = Color(0xFF9E2A2B), style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onRetry) { Text("SKÚSIŤ ZNOVA") }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier, shape = RoundedCornerShape(13.dp), color = Color.White) {
        Column(Modifier.padding(9.dp)) {
            Text(value.toString(), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun statusColor(status: DocumentStatus) = when (status) {
    DocumentStatus.ERROR -> Color(0xFF9E2A2B)
    DocumentStatus.PROCESSED -> Color(0xFF1E6B4B)
    DocumentStatus.REVIEW_REQUIRED -> Color(0xFF9A6500)
    else -> Color(0xFF355D50)
}

fun formatMoney(cents: Long, currencyCode: String): String = runCatching {
    NumberFormat.getCurrencyInstance(Locale("sk", "SK")).apply { currency = Currency.getInstance(currencyCode) }.format(cents / 100.0)
}.getOrElse { "%.2f %s".format(cents / 100.0, currencyCode) }
