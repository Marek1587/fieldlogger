package sk.doklady.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sk.doklady.DetailUiState
import sk.doklady.data.DocumentStatus
import sk.doklady.slovakLabel

@Composable
fun DetailScreen(
    state: DetailUiState,
    onBack: () -> Unit,
    onRetry: (String) -> Unit,
    onSave: (String, String, String, String, String) -> Unit,
) {
    val document = state.document
    if (document == null) { Text("Načítavam…", Modifier.padding(24.dp)); return }
    var editing by remember(document.id) { mutableStateOf(false) }
    var supplier by remember(document.id, document.supplierName) { mutableStateOf(document.supplierName.orEmpty()) }
    var date by remember(document.id, document.purchaseDate) { mutableStateOf(document.purchaseDate.orEmpty()) }
    var number by remember(document.id, document.documentNumber) { mutableStateOf(document.documentNumber.orEmpty()) }
    var total by remember(document.id, document.grossTotalCents) { mutableStateOf(document.grossTotalCents?.let { "%.2f".format(it / 100.0) }.orEmpty()) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TextButton(onClick = onBack) { Text("← Späť") } }
        item { Text("DOKLAD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { LocalFileImage(document.processedImagePath ?: document.originalImagePath, Modifier.fillMaxWidth().height(320.dp)) }
        item { Field("Stav", document.status.slovakLabel()) }
        if (editing) {
            item { OutlinedTextField(supplier, { supplier = it }, label = { Text("Dodávateľ") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(date, { date = it }, label = { Text("Dátum YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(number, { number = it }, label = { Text("Číslo dokladu") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(total, { total = it }, label = { Text("Celkom") }, modifier = Modifier.fillMaxWidth()) }
            item { Button(onClick = { onSave(document.id, supplier, date, number, total); editing = false }, Modifier.fillMaxWidth()) { Text("ULOŽIŤ") } }
        } else {
            item { Field("Dodávateľ", document.supplierName) }
            item { Field("Dátum", document.purchaseDate) }
            item { Field("Číslo dokladu", document.documentNumber) }
            item { Field("Celkom", document.grossTotalCents?.let { formatMoney(it, document.currency ?: "EUR") }) }
        }
        item { Field("DPH", document.vatTotalCents?.let { formatMoney(it, document.currency ?: "EUR") }) }
        item { Field("Confidence", "${document.confidence} %") }
        if (document.status == DocumentStatus.ERROR || document.status == DocumentStatus.REVIEW_REQUIRED) {
            item { OutlinedButton(onClick = { onRetry(document.id) }, Modifier.fillMaxWidth()) { Text("SPRACOVAŤ ZNOVA") } }
        }
        item { Button(onClick = { editing = !editing }, modifier = Modifier.fillMaxWidth()) { Text(if (editing) "ZRUŠIŤ ÚPRAVU" else "UPRAVIŤ") } }
        item { Text("POLOŽKY", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(state.items, key = { it.id }) { item ->
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("${item.position}. ${item.name}", fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(listOfNotNull(item.quantity, item.unit).joinToString(" "))
                    item.totalGrossCents?.let { Text(formatMoney(it, document.currency ?: "EUR")) }
                }
                item.unitPriceGrossCents?.let { Text("Cena/MJ: ${formatMoney(it, document.currency ?: "EUR")}") }
            }
        }
        if (state.items.isEmpty()) item { Text("Položky neboli spoľahlivo rozpoznané.") }
        item { Text("RAW OCR", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        item { Text(document.rawOcrText ?: "OCR ešte nie je dostupné.", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable private fun Field(label: String, value: String?) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value ?: "—", fontWeight = FontWeight.SemiBold)
    }
}
