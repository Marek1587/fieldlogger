package sk.doklady.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import sk.doklady.DiagnosticsUiState
import sk.doklady.slovakLabel

@Composable
fun DiagnosticsScreen(state: DiagnosticsUiState, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { TextButton(onClick = onBack) { Text("← Späť") } }
        item { Text("DIAGNOSTIKA SPRACOVANIA", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(state.documents, key = { it.id }) { document ->
            Surface(Modifier.fillMaxWidth(), tonalElevation = 1.dp) {
                Column(Modifier.padding(12.dp)) {
                    Text(document.originalDisplayName ?: "Document ${document.id.take(8)}", fontWeight = FontWeight.Bold)
                    Text("${document.status.name} — ${document.status.slovakLabel()}")
                    Text("Work UUID: ${document.workId ?: "—"}")
                    Text("Attempts: ${document.attemptCount}")
                    document.errorStage?.let { Text("Error stage: $it") }
                    document.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    document.errorStackTrace?.let { Text(it.take(500), style = MaterialTheme.typography.labelSmall) }
                    Text("Import ${document.importDurationMs} ms · Pre ${document.preprocessingDurationMs} ms · OCR ${document.ocrDurationMs} ms")
                    Text("Parser ${document.parsingDurationMs} ms · Validácia ${document.validationDurationMs} ms · Celkom ${document.totalDurationMs} ms")
                }
            }
        }
        item { Text("POSLEDNÉ LOGY", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        items(state.logs, key = { it.id }) { log ->
            Text("${log.documentId.take(8)} · ${log.workerName} · ${log.stage} · ${log.status} · ${log.durationMs ?: 0} ms${log.errorMessage?.let { " · $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
        }
    }
}
