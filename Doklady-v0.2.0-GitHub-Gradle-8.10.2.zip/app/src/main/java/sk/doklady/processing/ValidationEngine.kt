package sk.doklady.processing

import kotlin.math.abs

data class ValidationResult(val confidence: Int, val requiresReview: Boolean)

class ValidationEngine {
    fun validate(parsed: ParsedDocument, rawText: String): ValidationResult {
        var score = 15
        if (rawText.length >= 30) score += 15
        if (!parsed.supplier.isNullOrBlank()) score += 15
        if (parsed.purchaseDate != null) score += 10
        if (parsed.grossTotalCents != null) score += 20
        if (parsed.items.isNotEmpty()) score += 15
        val itemSum = parsed.items.mapNotNull { it.totalGrossCents }.sum()
        if (parsed.grossTotalCents != null && itemSum > 0) {
            score += if (abs(itemSum - parsed.grossTotalCents) <= 2) 10 else -8
        }
        score = score.coerceIn(0, 100)
        return ValidationResult(score, score < 70 || parsed.grossTotalCents == null)
    }
}
