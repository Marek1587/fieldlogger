package sk.doklady.processing

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

class ImagePreprocessor {
    fun process(source: File, destination: File): File {
        require(source.isFile && source.length() > 0L) { "Originálny obrázok chýba alebo je prázdny." }
        destination.parentFile?.mkdirs()

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Formát obrázka sa nepodarilo dekódovať." }
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > MAX_DIMENSION * 2) sample *= 2
        val decoded = requireNotNull(
            BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample }),
        ) { "Obrázok sa nepodarilo načítať." }

        val oriented = rotate(decoded, exifRotation(source))
        if (oriented !== decoded) decoded.recycle()
        val scale = (MAX_DIMENSION.toFloat() / max(oriented.width, oriented.height)).coerceAtMost(1f)
        val scaled = if (scale < 1f) {
            Bitmap.createScaledBitmap(oriented, (oriented.width * scale).toInt(), (oriented.height * scale).toInt(), true)
        } else oriented
        if (scaled !== oriented) oriented.recycle()

        val output = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        val contrast = 1.12f
        val translate = (-0.5f * contrast + 0.5f) * 255f
        val matrix = ColorMatrix().apply {
            setSaturation(0f)
            postConcat(ColorMatrix(floatArrayOf(
                contrast, 0f, 0f, 0f, translate,
                0f, contrast, 0f, 0f, translate,
                0f, 0f, contrast, 0f, translate,
                0f, 0f, 0f, 1f, 0f,
            )))
        }
        Canvas(output).drawBitmap(scaled, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrix)
        })
        scaled.recycle()
        FileOutputStream(destination).use { stream ->
            check(output.compress(Bitmap.CompressFormat.JPEG, 92, stream)) { "Upravený scan sa nepodarilo uložiť." }
        }
        output.recycle()
        require(destination.length() > 0L) { "Upravený scan je prázdny." }
        return destination
    }

    private fun exifRotation(file: File): Int = runCatching {
        when (ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90
            ExifInterface.ORIENTATION_ROTATE_180 -> 180
            ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
    }.getOrDefault(0)

    private fun rotate(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return bitmap
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, Matrix().apply {
            postRotate(degrees.toFloat())
        }, true)
    }

    companion object { private const val MAX_DIMENSION = 2_500 }
}
