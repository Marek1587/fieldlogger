package sk.doklady.processing

import sk.doklady.data.DocumentItemEntity
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer

data class OcrLine(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

data class ParsedDocument(
    val supplier: String?,
    val registrationId: String?,
    val documentNumber: String?,
    val purchaseDate: String?,
    val currency: String,
    val netTotalCents: Long?,
    val vatTotalCents: Long?,
    val grossTotalCents: Long?,
    val items: List<ParsedItem>,
)

data class ParsedItem(
    val originalText: String,
    val name: String,
    val productCode: String? = null,
    val ean: String? = null,
    val quantity: String? = null,
    val unit: String? = null,
    val unitPriceGrossCents: Long? = null,
    val totalGrossCents: Long? = null,
    val vatRate: String? = null,
    val confidence: Int,
)

interface DocumentParser { fun parse(lines: List<OcrLine>): ParsedDocument }

class GenericDocumentParser : DocumentParser {
    override fun parse(lines: List<OcrLine>): ParsedDocument {
        val clean = lines.map { it.text.trim() }.filter { it.isNotBlank() }
        val supplier = detectSupplier(clean)
        val registrationId = findFirst(clean, REGISTRATION_REGEX)?.groupValues?.get(1)?.filter(Char::isDigit)
        val documentNumber = clean.asSequence().mapNotNull { findFirst(listOf(it), DOCUMENT_NUMBER_REGEX)?.groupValues?.get(1) }.firstOrNull()
        val date = clean.asSequence().mapNotNull { DATE_REGEX.find(it)?.value }.firstOrNull()?.let(::normalizeDate)
        val currency = when {
            clean.any { it.contains("CZK", true) || it.contains("Kč", true) } -> "CZK"
            clean.any { it.contains("USD", true) || it.contains('$') } -> "USD"
            else -> "EUR"
        }
        val total = findLabelledAmount(clean, listOf("celkom", "spolu", "total", "k úhrade", "suma"))
            ?: clean.takeLast(12).flatMap(::amounts).lastOrNull()
        val vat = findLabelledAmount(clean, listOf("dph", "vat"))
        val net = findLabelledAmount(clean, listOf("základ", "bez dph", "netto", "net"))
            ?: if (total != null && vat != null) total - vat else null
        val items = detectItems(clean)
        return ParsedDocument(supplier, registrationId, documentNumber, date, currency, net, vat, total, items)
    }

    private fun detectSupplier(lines: List<String>): String? {
        val known = listOf("HORNBACH", "OBI", "BAUHAUS", "DEK", "STAVMAT", "LIDL", "KAUFLAND", "TESCO", "BILLA")
        known.firstOrNull { name -> lines.take(10).any { normalized(it).contains(name) } }?.let { return it }
        return lines.take(6).firstOrNull { line ->
            line.length in 3..80 && line.any(Char::isLetter) && !line.contains(Regex("(?i)doklad|fakt[úu]ra|blo[cč]ek|receipt"))
        }
    }

    private fun detectItems(lines: List<String>): List<ParsedItem> {
        val result = mutableListOf<ParsedItem>()
        lines.forEachIndexed { index, line ->
            if (line.contains(Regex("(?i)celkom|spolu|total|dph|základ|úhrade|hotovosť|karta|dátum|datum|IČO|ICO")) || DATE_REGEX.containsMatchIn(line)) return@forEachIndexed
            val values = amounts(line)
            val quantityMatch = QUANTITY_REGEX.find(line)
            val hasName = line.replace(AMOUNT_REGEX, "").count(Char::isLetter) >= 3
            if (quantityMatch != null && index > 0 && amounts(lines[index - 1]).isEmpty() && lines[index - 1].count(Char::isLetter) >= 3) {
                return@forEachIndexed
            }
            if (hasName && values.isEmpty()) {
                val next = lines.getOrNull(index + 1).orEmpty()
                val nextQuantity = QUANTITY_REGEX.find(next)
                val nextValues = amounts(next)
                if (nextQuantity != null && nextValues.isNotEmpty()) {
                    val followingTotal = lines.getOrNull(index + 2)?.let(::amounts)?.singleOrNull()
                    result += ParsedItem(
                        originalText = listOfNotNull(line, next, lines.getOrNull(index + 2)?.takeIf { followingTotal != null }).joinToString("\n"),
                        name = line.trim(),
                        ean = EAN_REGEX.find(line)?.value,
                        quantity = nextQuantity.groupValues[1].replace(',', '.'),
                        unit = nextQuantity.groupValues[2].uppercase(),
                        unitPriceGrossCents = nextValues.firstOrNull(),
                        totalGrossCents = followingTotal ?: nextValues.lastOrNull(),
                        confidence = 88,
                    )
                }
                return@forEachIndexed
            }
            if (!hasName || values.isEmpty()) return@forEachIndexed
            val total = values.last()
            val quantity = quantityMatch?.groupValues?.get(1)?.replace(',', '.')
            val unit = quantityMatch?.groupValues?.get(2)?.uppercase()
            val unitPrice = if (values.size >= 2) values[values.lastIndex - 1] else null
            val name = line
                .replace(QUANTITY_REGEX, " ")
                .replace(AMOUNT_REGEX, " ")
                .replace(Regex("\\s+"), " ")
                .trim(' ', '-', '|', ':')
                .ifBlank { lines.getOrNull(index - 1)?.takeIf { it.any(Char::isLetter) } ?: return@forEachIndexed }
            val ean = EAN_REGEX.find(line)?.value
            result += ParsedItem(line, name, ean = ean, quantity = quantity, unit = unit,
                unitPriceGrossCents = unitPrice, totalGrossCents = total,
                confidence = if (quantity != null && unitPrice != null) 82 else 64)
        }
        return result.distinctBy { it.originalText }
    }

    private fun findLabelledAmount(lines: List<String>, labels: List<String>): Long? = lines.asReversed().firstNotNullOfOrNull { line ->
        if (labels.any { normalized(line).contains(normalized(it)) }) amounts(line).lastOrNull() else null
    }

    private fun amounts(line: String): List<Long> = AMOUNT_REGEX.findAll(line).mapNotNull { parseCents(it.value) }.toList()
    private fun findFirst(lines: List<String>, regex: Regex): MatchResult? = lines.firstNotNullOfOrNull(regex::find)
    private fun normalizeDate(value: String): String {
        val parts = value.split('.', '/', '-').mapNotNull(String::toIntOrNull)
        return if (parts.size == 3) "%04d-%02d-%02d".format(if (parts[2] < 100) 2000 + parts[2] else parts[2], parts[1], parts[0]) else value
    }

    companion object {
        private val AMOUNT_REGEX = Regex("(?<!\\d)[-+]?\\d{1,6}(?:[ .]\\d{3})*[,.]\\d{2}(?!\\d)")
        private val QUANTITY_REGEX = Regex("(?i)(\\d+(?:[,.]\\d+)?)\\s*(ks|kg|g|l|m|m2|m²|bal|bal\\.|pc)\\b(?:\\s*[x×])?")
        private val DATE_REGEX = Regex("\\b(?:0?[1-9]|[12]\\d|3[01])[./-](?:0?[1-9]|1[0-2])[./-](?:20)?\\d{2}\\b")
        private val REGISTRATION_REGEX = Regex("(?i)(?:IČO|ICO)\\s*[: ]\\s*(\\d{6,10})")
        private val DOCUMENT_NUMBER_REGEX = Regex("(?i)(?:č\\.?\\s*dokladu|doklad|fakt[úu]ra|invoice)\\s*(?:č\\.?|no\\.?)?\\s*[:# ]\\s*([A-Z0-9][A-Z0-9/-]{3,})")
        private val EAN_REGEX = Regex("(?<!\\d)\\d{8,13}(?!\\d)")

        fun parseCents(raw: String): Long? = runCatching {
            val compact = raw.replace(" ", "").filter { it.isDigit() || it in ".,-+" }
            val separator = maxOf(compact.lastIndexOf(','), compact.lastIndexOf('.'))
            val normalized = if (separator >= 0 && compact.length - separator - 1 == 2) {
                compact.substring(0, separator).replace(",", "").replace(".", "") + "." + compact.substring(separator + 1)
            } else compact.replace(",", "").replace(".", "")
            BigDecimal(normalized).setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact()
        }.getOrNull()

        private fun normalized(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "").uppercase()
    }
}

fun ParsedItem.toEntity(documentId: String, position: Int) = DocumentItemEntity(
    documentId = documentId,
    position = position,
    originalText = originalText,
    productCode = productCode,
    ean = ean,
    name = name,
    quantity = quantity,
    unit = unit,
    unitPriceGrossCents = unitPriceGrossCents,
    totalGrossCents = totalGrossCents,
    vatRate = vatRate,
    confidence = confidence,
)
