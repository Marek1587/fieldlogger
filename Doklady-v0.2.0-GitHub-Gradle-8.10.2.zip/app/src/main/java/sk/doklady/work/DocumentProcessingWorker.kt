package sk.doklady.work

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import sk.doklady.DokladyApplication
import sk.doklady.data.DocumentStatus
import sk.doklady.data.OcrElementEntity
import sk.doklady.data.ProcessingLogEntity
import sk.doklady.data.SupplierEntity
import sk.doklady.data.VatSummaryEntity
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.processing.ImagePreprocessor
import sk.doklady.processing.OcrLine
import sk.doklady.processing.ValidationEngine
import sk.doklady.processing.toEntity
import java.io.File

class DocumentProcessingWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    private val app = applicationContext as DokladyApplication
    private val dao = app.database.documents()
    private var currentStage = DocumentStatus.QUEUED.name
    private var totalStartedAt = 0L

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val documentId = inputData.getString(DOCUMENT_ID) ?: return@withContext Result.failure()
        totalStartedAt = System.currentTimeMillis()
        try {
            val document = dao.get(documentId) ?: return@withContext Result.success()
            dao.incrementAttempt(documentId, totalStartedAt)
            Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME START_TIME=$totalStartedAt STATUS=STARTED")

            val processedFile = measuredStage(documentId, DocumentStatus.PREPROCESSING, 15) {
                val target = app.storage.processedTarget(documentId)
                val started = System.currentTimeMillis()
                val file = ImagePreprocessor().process(File(document.originalImagePath), target)
                dao.savePreprocessing(documentId, file.absolutePath, System.currentTimeMillis() - started, System.currentTimeMillis())
                file
            }

            val ocrResult = measuredStage(documentId, DocumentStatus.OCR, 40) {
                val started = System.currentTimeMillis()
                val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                try {
                    val result = Tasks.await(recognizer.process(InputImage.fromFilePath(applicationContext, Uri.fromFile(processedFile))))
                    val rawText = result.text.orEmpty()
                    require(rawText.isNotBlank()) { "OCR nerozpoznalo žiadny text." }
                    val elements = mutableListOf<OcrElementEntity>()
                    val lines = mutableListOf<OcrLine>()
                    result.textBlocks.forEachIndexed { blockIndex, block ->
                        block.lines.forEachIndexed { lineIndex, line ->
                            line.boundingBox?.let { box -> lines += OcrLine(line.text, box.left, box.top, box.right, box.bottom) }
                            line.elements.forEachIndexed { elementIndex, element ->
                                val box = element.boundingBox ?: return@forEachIndexed
                                elements += OcrElementEntity(
                                    documentId = documentId,
                                    blockIndex = blockIndex,
                                    lineIndex = lineIndex,
                                    elementIndex = elementIndex,
                                    text = element.text,
                                    left = box.left,
                                    top = box.top,
                                    right = box.right,
                                    bottom = box.bottom,
                                    confidence = element.confidence,
                                )
                            }
                        }
                    }
                    dao.replaceOcr(documentId, elements)
                    dao.saveOcr(documentId, rawText, System.currentTimeMillis() - started, System.currentTimeMillis())
                    OcrPayload(rawText, lines)
                } finally {
                    recognizer.close()
                }
            }

            val parsed = measuredStage(documentId, DocumentStatus.PARSING, 70) {
                val started = System.currentTimeMillis()
                val value = GenericDocumentParser().parse(ocrResult.lines)
                val items = value.items.mapIndexed { index, item -> item.toEntity(documentId, index + 1) }
                dao.replaceItems(documentId, items)
                dao.saveParsed(
                    id = documentId,
                    supplier = value.supplier,
                    registrationId = value.registrationId,
                    documentNumber = value.documentNumber,
                    purchaseDate = value.purchaseDate,
                    currency = value.currency,
                    netTotal = value.netTotalCents,
                    vatTotal = value.vatTotalCents,
                    grossTotal = value.grossTotalCents,
                    itemCount = items.size,
                    duration = System.currentTimeMillis() - started,
                    now = System.currentTimeMillis(),
                )
                value.supplier?.let { supplier ->
                    dao.insertSupplier(SupplierEntity(name = supplier, normalizedName = supplier.trim().uppercase(), registrationId = value.registrationId))
                }
                dao.deleteVatSummaries(documentId)
                if (value.vatTotalCents != null || value.netTotalCents != null) {
                    dao.insertVatSummaries(listOf(VatSummaryEntity(
                        documentId = documentId,
                        rate = "nezistená",
                        baseCents = value.netTotalCents,
                        vatCents = value.vatTotalCents,
                        totalCents = value.grossTotalCents,
                    )))
                }
                value
            }

            measuredStage(documentId, DocumentStatus.VALIDATING, 90) {
                val started = System.currentTimeMillis()
                val validation = ValidationEngine().validate(parsed, ocrResult.rawText)
                val now = System.currentTimeMillis()
                dao.finish(
                    id = documentId,
                    status = if (validation.requiresReview) DocumentStatus.REVIEW_REQUIRED else DocumentStatus.PROCESSED,
                    confidence = validation.confidence,
                    validationDuration = now - started,
                    totalDuration = now - totalStartedAt,
                    now = now,
                )
            }
            val ended = System.currentTimeMillis()
            Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME END_TIME=$ended STATUS=SUCCESS")
            Result.success()
        } catch (error: Throwable) {
            val ended = System.currentTimeMillis()
            val message = error.message ?: error.javaClass.simpleName
            runCatching {
                dao.markError(
                    id = documentId,
                    stage = currentStage,
                    message = message,
                    stackTrace = error.stackTraceToString().take(16_000),
                    totalDuration = (ended - totalStartedAt).coerceAtLeast(0),
                    now = ended,
                )
            }
            Log.e(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME END_TIME=$ended STATUS=ERROR ERROR_MESSAGE=$message", error)
            // The document owns the error state. Success keeps the global sequential queue moving.
            Result.success()
        }
    }

    private suspend fun <T> measuredStage(
        documentId: String,
        status: DocumentStatus,
        progress: Int,
        block: suspend () -> T,
    ): T {
        currentCoroutineContext().ensureActive()
        currentStage = status.name
        val started = System.currentTimeMillis()
        dao.transition(documentId, status, progress, started)
        val logId = dao.insertLog(ProcessingLogEntity(
            documentId = documentId,
            workId = id.toString(),
            workerName = WORKER_NAME,
            stage = status.name,
            status = "STARTED",
            startTime = started,
        ))
        Log.i(TAG, "DOCUMENT_ID=$documentId WORKER_NAME=$WORKER_NAME START_TIME=$started STATUS=${status.name}")
        return try {
            block().also {
                val ended = System.currentTimeMillis()
                dao.finishLog(logId, "SUCCESS", ended, ended - started)
            }
        } catch (error: Throwable) {
            val ended = System.currentTimeMillis()
            dao.finishLog(logId, "ERROR", ended, ended - started, error.message)
            throw error
        }
    }

    private data class OcrPayload(val rawText: String, val lines: List<OcrLine>)

    companion object {
        const val DOCUMENT_ID = "document_id"
        const val WORKER_NAME = "DocumentProcessingWorker"
        private const val TAG = "DokladyPipeline"
    }
}
