package sk.doklady.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

enum class DocumentStatus {
    CAPTURED,
    QUEUED,
    PREPROCESSING,
    OCR,
    PARSING,
    VALIDATING,
    PROCESSED,
    REVIEW_REQUIRED,
    ERROR,
}

enum class ImageSource { CAMERA, GALLERY }

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String,
    val status: DocumentStatus,
    val imageSource: ImageSource,
    val originalImagePath: String,
    val originalDisplayName: String?,
    val originalMimeType: String,
    val createdAt: Long,
    val updatedAt: Long,
    val errorMessage: String? = null,
    @ColumnInfo(defaultValue = "NULL") val batchId: String? = null,
    @ColumnInfo(defaultValue = "NULL") val workId: String? = null,
    @ColumnInfo(defaultValue = "0") val attemptCount: Int = 0,
    @ColumnInfo(defaultValue = "0") val stageProgress: Int = 0,
    @ColumnInfo(defaultValue = "NULL") val phaseStartedAt: Long? = null,
    @ColumnInfo(defaultValue = "NULL") val finishedAt: Long? = null,
    @ColumnInfo(defaultValue = "NULL") val errorStage: String? = null,
    @ColumnInfo(defaultValue = "NULL") val errorStackTrace: String? = null,
    @ColumnInfo(defaultValue = "NULL") val processedImagePath: String? = null,
    @ColumnInfo(defaultValue = "NULL") val rawOcrText: String? = null,
    @ColumnInfo(defaultValue = "NULL") val supplierName: String? = null,
    @ColumnInfo(defaultValue = "NULL") val supplierRegistrationId: String? = null,
    @ColumnInfo(defaultValue = "NULL") val documentNumber: String? = null,
    @ColumnInfo(defaultValue = "NULL") val purchaseDate: String? = null,
    @ColumnInfo(defaultValue = "NULL") val currency: String? = null,
    @ColumnInfo(defaultValue = "NULL") val netTotalCents: Long? = null,
    @ColumnInfo(defaultValue = "NULL") val vatTotalCents: Long? = null,
    @ColumnInfo(defaultValue = "NULL") val grossTotalCents: Long? = null,
    @ColumnInfo(defaultValue = "0") val confidence: Int = 0,
    @ColumnInfo(defaultValue = "0") val itemCount: Int = 0,
    @ColumnInfo(defaultValue = "0") val importDurationMs: Long = 0,
    @ColumnInfo(defaultValue = "0") val preprocessingDurationMs: Long = 0,
    @ColumnInfo(defaultValue = "0") val ocrDurationMs: Long = 0,
    @ColumnInfo(defaultValue = "0") val parsingDurationMs: Long = 0,
    @ColumnInfo(defaultValue = "0") val validationDurationMs: Long = 0,
    @ColumnInfo(defaultValue = "0") val totalDurationMs: Long = 0,
)

@Entity(tableName = "document_items", indices = [Index("documentId")])
data class DocumentItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: String,
    val position: Int,
    val originalText: String,
    val productCode: String? = null,
    val ean: String? = null,
    val name: String,
    val quantity: String? = null,
    val unit: String? = null,
    val unitPriceNetCents: Long? = null,
    val unitPriceGrossCents: Long? = null,
    val vatRate: String? = null,
    val totalNetCents: Long? = null,
    val totalGrossCents: Long? = null,
    val confidence: Int = 0,
    val manualEdited: Boolean = false,
)

@Entity(tableName = "ocr_elements", indices = [Index("documentId")])
data class OcrElementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: String,
    val pageNumber: Int = 1,
    val blockIndex: Int,
    val lineIndex: Int,
    val elementIndex: Int,
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val confidence: Float? = null,
)

@Entity(tableName = "vat_summaries", indices = [Index("documentId")])
data class VatSummaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: String,
    val rate: String,
    val baseCents: Long?,
    val vatCents: Long?,
    val totalCents: Long?,
)

@Entity(tableName = "suppliers", indices = [Index(value = ["normalizedName"], unique = true)])
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val normalizedName: String,
    val registrationId: String? = null,
)

@Entity(tableName = "processing_logs", indices = [Index("documentId")])
data class ProcessingLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val documentId: String,
    val workId: String?,
    val workerName: String,
    val stage: String,
    val status: String,
    val startTime: Long,
    val endTime: Long? = null,
    val durationMs: Long? = null,
    val errorMessage: String? = null,
)
