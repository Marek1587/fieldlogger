package sk.doklady.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter fun statusToString(value: DocumentStatus): String = value.name
    @TypeConverter fun stringToStatus(value: String): DocumentStatus = DocumentStatus.valueOf(value)
    @TypeConverter fun sourceToString(value: ImageSource): String = value.name
    @TypeConverter fun stringToSource(value: String): ImageSource = ImageSource.valueOf(value)
}
