package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.processing.OcrLine
import sk.doklady.processing.ValidationEngine

class DocumentParserTest {
    @Test
    fun `parses multiline receipt item and real totals`() {
        val lines = listOf(
            "HORNBACH", "IČO: 12345678", "Dátum 26.08.2026",
            "OSB 3 P+D 18MM 2500X625", "4 KS x 16,40", "65,60",
            "Základ 54,67", "DPH 10,93", "CELKOM 65,60 EUR",
        ).mapIndexed { index, text -> OcrLine(text, 0, index * 20, 500, index * 20 + 18) }

        val parsed = GenericDocumentParser().parse(lines)

        assertEquals("HORNBACH", parsed.supplier)
        assertEquals("2026-08-26", parsed.purchaseDate)
        assertEquals(6560L, parsed.grossTotalCents)
        assertEquals(6560L, GenericDocumentParser.parseCents("65.60"))
        assertEquals(123456L, GenericDocumentParser.parseCents("1.234,56"))
        assertEquals(1, parsed.items.size)
        assertEquals("4", parsed.items.single().quantity)
        assertEquals(1640L, parsed.items.single().unitPriceGrossCents)
        assertEquals(6560L, parsed.items.single().totalGrossCents)
        assertFalse(ValidationEngine().validate(parsed, lines.joinToString(" ") { it.text }).requiresReview)
    }

    @Test
    fun `blank unstructured OCR requires review`() {
        val parsed = GenericDocumentParser().parse(listOf(OcrLine("nečitateľné", 0, 0, 10, 10)))
        val validation = ValidationEngine().validate(parsed, "nečitateľné")
        assertTrue(validation.requiresReview)
        assertTrue(validation.confidence < 70)
    }
}
