(function (root) {
  "use strict";
  const TICKS_PER_MM = 100;
  const DEFAULT_INSERTION_DEPTH_TICKS = 50 * TICKS_PER_MM;

  function parseDimension(value, unit) {
    const normalized = String(value).trim().replace(/\s/g, "").replace(",", ".");
    const number = Number(normalized);
    if (!Number.isFinite(number)) return null;
    return Math.round(number * (unit === "cm" ? 1000 : TICKS_PER_MM));
  }

  function formatDimension(ticks, unit, withUnit) {
    const divider = unit === "cm" ? 1000 : TICKS_PER_MM;
    const value = ticks / divider;
    const text = new Intl.NumberFormat("sk-SK", { maximumFractionDigits: unit === "cm" ? 3 : 2 }).format(value);
    return withUnit === false ? text : text + " " + unit;
  }

  function validate(input) {
    const errors = [];
    if (!Number.isInteger(input.targetLength) || input.targetLength <= 0) errors.push("Cieľová dĺžka musí byť väčšia ako nula.");
    if (!Number.isInteger(input.nominalWidth) || input.nominalWidth <= 0) errors.push("Šírka dielu musí byť väčšia ako nula.");
    if ((input.fixedLeft || 0) < 0 || (input.fixedRight || 0) < 0) errors.push("Pevné kraje nemôžu byť záporné.");
    if ((input.fixedLeft || 0) + (input.fixedRight || 0) >= input.targetLength) errors.push("Pevné kraje musia byť spolu menšie než cieľová dĺžka.");
    if ((input.minCorrection || 0) < 0 || (input.maxCorrection || 0) < 0) errors.push("Tolerancia nemôže byť záporná.");
    return errors;
  }

  function calculateBasicLayout(input) {
    const errors = validate(input);
    if (!errors.length && input.nominalWidth > input.targetLength) errors.push("Šírka dielu nemôže byť väčšia než cieľová dĺžka.");
    if (errors.length) return { ok: false, errors: errors };
    const fullPieceCount = Math.floor(input.targetLength / input.nominalWidth);
    const remainder = input.targetLength - fullPieceCount * input.nominalWidth;
    const leftEdge = remainder / 2;
    const rightEdge = remainder - leftEdge;
    return { ok: true, targetLength: input.targetLength, nominalWidth: input.nominalWidth, fullPieceCount: fullPieceCount, remainder: remainder, leftEdge: leftEdge, rightEdge: rightEdge, achievedLength: leftEdge + fullPieceCount * input.nominalWidth + rightEdge };
  }

  function distributeCorrection(input) {
    const minSteps = Math.ceil(-input.minCorrection / input.step);
    const maxSteps = Math.floor(input.maxCorrection / input.step);
    const wantedSteps = Math.round(input.totalCorrection / input.step);
    const totalSteps = Math.max(input.pieceCount * minSteps, Math.min(input.pieceCount * maxSteps, wantedSteps));
    const base = Math.floor(totalSteps / input.pieceCount);
    const raised = totalSteps - base * input.pieceCount;
    return {
      corrections: Array.from({ length: input.pieceCount }, function (_, index) { return (index < raised ? base + 1 : base) * input.step; }),
      appliedCorrection: totalSteps * input.step
    };
  }

  function makeCandidate(input, pieceCount) {
    const nominalTotal = input.fixedLeft + input.fixedRight + pieceCount * input.nominalWidth;
    const requiredCorrection = input.targetLength - nominalTotal;
    const distribution = distributeCorrection({ pieceCount: pieceCount, totalCorrection: requiredCorrection, step: input.step, minCorrection: input.minCorrection, maxCorrection: input.maxCorrection });
    const pieces = distribution.corrections.map(function (correction, index) { return { index: index + 1, nominalWidth: input.nominalWidth, correction: correction, finalWidth: input.nominalWidth + correction }; });
    const achievedLength = nominalTotal + distribution.appliedCorrection;
    return { targetLength: input.targetLength, nominalWidth: input.nominalWidth, pieceCount: pieceCount, fixedLeft: input.fixedLeft, fixedRight: input.fixedRight, nominalTotal: nominalTotal, requiredCorrection: requiredCorrection, correctionPerPiece: requiredCorrection / pieceCount, pieces: pieces, achievedLength: achievedLength, residualError: achievedLength - input.targetLength, exact: achievedLength === input.targetLength, appliedCorrection: distribution.appliedCorrection, averageCorrection: Math.abs(distribution.appliedCorrection / pieceCount) };
  }

  function solveCorrection(input) {
    const errors = validate(input);
    if (!Number.isInteger(input.step) || input.step <= 0) errors.push("Krok korekcie musí byť väčší ako nula.");
    if (errors.length) return { ok: false, errors: errors };
    const available = input.targetLength - input.fixedLeft - input.fixedRight;
    const minimumWidth = Math.max(1, input.nominalWidth - input.minCorrection);
    const maxCount = Math.min(500, Math.max(1, Math.ceil(available / minimumWidth) + 2));
    const counts = input.pieceCount ? [input.pieceCount] : Array.from({ length: maxCount }, function (_, index) { return index + 1; });
    const candidates = counts.map(function (count) { return makeCandidate(input, count); });
    candidates.sort(function (a, b) { return Math.abs(a.residualError) - Math.abs(b.residualError) || a.averageCorrection - b.averageCorrection || Math.abs(a.pieceCount - available / input.nominalWidth) - Math.abs(b.pieceCount - available / input.nominalWidth); });
    const best = candidates[0];
    best.ok = true;
    best.minimumTolerance = Math.abs(best.requiredCorrection / best.pieceCount);
    return best;
  }

  function groupPieces(pieces) {
    const map = new Map();
    pieces.forEach(function (piece) {
      const key = piece.finalWidth + ":" + piece.correction;
      const group = map.get(key) || { count: 0, finalWidth: piece.finalWidth, correction: piece.correction };
      group.count += 1;
      map.set(key, group);
    });
    return Array.from(map.values()).sort(function (a, b) { return b.correction - a.correction; });
  }

  function solveRightTriangle(values, manualSides) {
    const manual = manualSides.slice(-2);
    const computedSide = ["a", "b", "c"].find(function (side) { return !manual.includes(side); });
    if (!computedSide || manual.some(function (side) { return !Number.isFinite(values[side]) || values[side] <= 0; })) {
      return { ok: false, computedSide: computedSide || null, values: Object.assign({}, values) };
    }
    let squared;
    if (computedSide === "c") squared = values.a * values.a + values.b * values.b;
    if (computedSide === "a") squared = values.c * values.c - values.b * values.b;
    if (computedSide === "b") squared = values.c * values.c - values.a * values.a;
    if (!(squared > 0)) return { ok: false, computedSide: computedSide, values: Object.assign({}, values) };
    const result = Object.assign({}, values);
    result[computedSide] = Math.round(Math.sqrt(squared) / TICKS_PER_MM) * TICKS_PER_MM;
    return { ok: true, computedSide: computedSide, values: result };
  }

  const DIMENSION_SOURCE_WEIGHT = { default: 0.45, derived: 0.8, autoAdjusted: 1.2, user: Infinity };

  class ProportionalGeometryAdjuster {
    static adjust(states, editedKey, factor) {
      const adjusted = [];
      Object.keys(states).forEach(function (name) {
        const state = states[name];
        if (name !== editedKey && !state.isUserLocked && Number.isFinite(state.value) && state.value > 0) {
          state.value = Math.max(TICKS_PER_MM, Math.round(state.value * factor / TICKS_PER_MM) * TICKS_PER_MM);
          state.source = "autoAdjusted";
          adjusted.push(name);
        }
      });
      return adjusted;
    }
  }

  class ConstraintOptimization {
    static solve(states) { return solveRectangleSquaringConstrained(states); }
  }

  class GeometryConstraintSolver {
    solve(states) { return ConstraintOptimization.solve(states); }
    validate(values) { return solveRectangleSquaring(values); }
  }

  class UserDimensionLockManager {
    constructor(values) {
      this.states = {};
      Object.keys(values || {}).forEach(function (key) {
        this.states[key] = { value: values[key], source: "default", isUserLocked: false, lastUserEditTimestamp: 0 };
      }, this);
    }
    values() { const result = {}; Object.keys(this.states).forEach(function (key) { result[key] = this.states[key].value; }, this); return result; }
    edit(key, value, timestamp) {
      if (!this.states[key]) this.states[key] = { value: value, source: "default", isUserLocked: false, lastUserEditTimestamp: 0 };
      const oldValue = this.states[key].value, factor = oldValue > 0 ? value / oldValue : 1;
      this.states[key] = { value: value, source: "user", isUserLocked: true, lastUserEditTimestamp: timestamp || Date.now() };
      const proportionallyAdjusted=ProportionalGeometryAdjuster.adjust(this.states,key,factor);
      const result=this.solve();result.autoAdjusted=Array.from(new Set(proportionallyAdjusted.concat(result.autoAdjusted||[])));return result;
    }
    unlockLeastImportant() {
      const locked = Object.keys(this.states).filter(function (key) { return this.states[key].isUserLocked; }, this).sort(function (a,b) { return this.states[a].lastUserEditTimestamp-this.states[b].lastUserEditTimestamp; }.bind(this));
      if (!locked.length) return this.solve();
      const key = locked[0], state = this.states[key];state.isUserLocked=false;state.source="autoAdjusted";return this.solve(key);
    }
    solve() {
      const result = ConstraintOptimization.solve(this.states);
      if (result.ok) {
        Object.keys(result.values).forEach(function (key) {
          const state=this.states[key];
          if (!state.isUserLocked && state.value !== result.values[key]) { state.value=result.values[key];state.source="autoAdjusted"; }
        }, this);
      }
      result.states = JSON.parse(JSON.stringify(this.states));
      return result;
    }
  }

  function solveRectangleSquaringConstrained(states) {
    const keys=["l1","l2","d1","d2"],values={};keys.forEach(function(key){values[key]=states[key]&&states[key].value;});
    let solution=solveRectangleSquaring(values);
    if(solution.ok)return {ok:true,values:values,solution:solution,autoAdjusted:[],conflicts:[]};
    const unlocked=keys.filter(function(key){return states[key]&&!states[key].isUserLocked;});
    if(!unlocked.length)return {ok:false,values:values,solution:solution,autoAdjusted:[],conflicts:keys.filter(function(key){return states[key]&&states[key].isUserLocked;}),errors:["Zadané rozmery si geometricky odporujú."]};
    const originals=Object.assign({},values),weights={};unlocked.forEach(function(key){weights[key]=DIMENSION_SOURCE_WEIGHT[states[key].source]||1;});
    let best=null,bestScore=Infinity;
    function consider(candidate){const solved=solveRectangleSquaring(candidate);if(!solved.ok)return;let score=0;unlocked.forEach(function(key){const base=Math.max(TICKS_PER_MM,originals[key]),relative=(candidate[key]-originals[key])/base;score+=weights[key]*relative*relative;});if(score<bestScore){bestScore=score;best={values:Object.assign({},candidate),solution:solved};}}
    consider(values);
    const factorCount=unlocked.length===1?801:unlocked.length===2?81:25,factors=[];for(let i=0;i<factorCount;i+=1)factors.push(Math.exp(Math.log(.02)+(Math.log(50)-Math.log(.02))*i/(factorCount-1)));
    function search(index,candidate){if(index===unlocked.length){consider(candidate);return;}const key=unlocked[index];factors.forEach(function(factor){candidate[key]=Math.max(TICKS_PER_MM,Math.round(originals[key]*factor/TICKS_PER_MM)*TICKS_PER_MM);search(index+1,candidate);});candidate[key]=originals[key];}
    search(0,Object.assign({},values));
    if(!best)return {ok:false,values:values,solution:solution,autoAdjusted:[],conflicts:keys.filter(function(key){return states[key]&&states[key].isUserLocked;}),errors:["Zadané rozmery si geometricky odporujú."]};
    let step=.08;for(let pass=0;pass<16;pass+=1){unlocked.forEach(function(key){[-step,step].forEach(function(delta){const candidate=Object.assign({},best.values);candidate[key]=Math.max(TICKS_PER_MM,Math.round(candidate[key]*(1+delta)/TICKS_PER_MM)*TICKS_PER_MM);consider(candidate);});});step*=.55;}
    const adjusted=unlocked.filter(function(key){return best.values[key]!==originals[key];});
    return {ok:true,values:best.values,solution:best.solution,autoAdjusted:adjusted,conflicts:[]};
  }

  function solveRectangleSquaring(values) {
    const l1 = values && (values.l1 || values.length);
    const l2 = values && (values.l2 || values.length);
    const d1 = values && values.d1;
    const d2 = values && values.d2;
    if (![l1, l2, d1, d2].every(function (value) { return Number.isFinite(value) && value > 0; })) {
      return { ok: false, errors: ["Rozmery musia byť kladné čísla."] };
    }
    // Rovnobežné hrany: spodná od 0 po L2, horná od posunu s po s + L1.
    // Rovnice diagonál jednoznačne určia posun ľavej strany aj výšku.
    const rawLeftShift = (d2 * d2 - d1 * d1 - l1 * l1 + l2 * l2) / (2 * (l1 + l2));
    const rawRightShift = rawLeftShift + l1 - l2;
    const heightSquared = d2 * d2 - Math.pow(rawLeftShift + l1, 2);
    if (!(heightSquared > 0)) return { ok: false, errors: ["Z rozmerov nevznikne platný lichobežník."] };
    const height = Math.sqrt(heightSquared);
    const signedLeftShift = Math.round(rawLeftShift / TICKS_PER_MM) * TICKS_PER_MM;
    const signedRightShift = Math.round(rawRightShift / TICKS_PER_MM) * TICKS_PER_MM;
    const bottomLeft = Math.atan2(height, rawLeftShift) * 180 / Math.PI;
    const bottomRight = Math.atan2(height, -rawRightShift) * 180 / Math.PI;
    const angles = {
      topLeft: 180 - bottomLeft,
      topRight: 180 - bottomRight,
      bottomRight: bottomRight,
      bottomLeft: bottomLeft
    };
    const rightAngleCorners = Object.keys(angles).filter(function (corner) { return Math.abs(angles[corner] - 90) <= 0.1; });
    const signedSkewAngleDegrees = 90 - bottomLeft;
    const skewAngleDegrees = Math.abs(signedSkewAngleDegrees);
    return {
      ok: true,
      l1: l1,
      l2: l2,
      x: Math.abs(signedLeftShift),
      signedX: signedLeftShift,
      xLeft: Math.abs(signedLeftShift),
      signedXLeft: signedLeftShift,
      xRight: Math.abs(signedRightShift),
      signedXRight: signedRightShift,
      wholeSideShift: Math.abs(signedLeftShift),
      longerDiagonal: d2 >= d1 ? "d2" : "d1",
      derivedHeight: Math.round(height),
      skewAngleDegrees: skewAngleDegrees,
      signedSkewAngleDegrees: signedSkewAngleDegrees,
      angles: angles,
      rightAngleCorners: rightAngleCorners
    };
  }

  function solveSheetPerpendicular(values) {
    const width = values && values.width;
    const angleDegrees = values && values.angleDegrees;
    if (!Number.isFinite(width) || width <= 0) return { ok: false, errors: ["Šírka pásu musí byť kladná."] };
    if (!Number.isFinite(angleDegrees) || angleDegrees <= 0 || angleDegrees >= 90) {
      return { ok: false, errors: ["Uhol musí byť väčší ako 0° a menší ako 90°."] };
    }
    const angleRadians = angleDegrees * Math.PI / 180;
    return { ok: true, x: Math.round(width * Math.tan(angleRadians) / TICKS_PER_MM) * TICKS_PER_MM, width: width, angleDegrees: angleDegrees };
  }

  function solveClipLayout(values) {
    const length = values && values.length;
    const angleDegrees = values && values.angleDegrees;
    const spacing = values && values.spacing;
    if (!Number.isFinite(length) || length <= 0) return { ok: false, errors: ["Dĺžka pásu musí byť kladná."] };
    if (!Number.isFinite(angleDegrees) || angleDegrees < 3 || angleDegrees >= 90) {
      return { ok: false, errors: ["Sklon musí byť od 3° do 89°."] };
    }
    if (!Number.isFinite(spacing) || spacing <= 0) return { ok: false, errors: ["Rozstup príponiek musí byť kladný."] };
    const fixedZoneLength = Math.min(length, length > 1000000 ? 300000 : 100000);
    let factor;
    if (angleDegrees === 3) factor = 0.5;
    else if (angleDegrees <= 10) factor = 2 / 3;
    else if (angleDegrees <= 30) factor = 3 / 4;
    else factor = null;
    const requestedCenter = factor === null ? length - fixedZoneLength / 2 : length * factor;
    const fixedStart = Math.max(0, Math.min(length - fixedZoneLength, Math.round(requestedCenter - fixedZoneLength / 2)));
    const fixedEnd = fixedStart + fixedZoneLength;
    const clips = [];
    for (let position = spacing, index = 1; position < length; position += spacing, index += 1) {
      clips.push({ index: index, position: position, type: position >= fixedStart && position <= fixedEnd ? "fixed" : "sliding" });
    }
    return {
      ok: true,
      length: length,
      angleDegrees: angleDegrees,
      spacing: spacing,
      fixedZoneLength: fixedZoneLength,
      fixedCenter: fixedStart + fixedZoneLength / 2,
      fixedStart: fixedStart,
      fixedEnd: fixedEnd,
      clips: clips,
      zones: [
        { number: 1, start: fixedEnd, end: length, type: "sliding" },
        { number: 2, start: fixedStart, end: fixedEnd, type: "fixed" },
        { number: 3, start: 0, end: fixedStart, type: "sliding" }
      ]
    };
  }

  function solveUpperSlidingDilatation(values) {
    const panelLength = values && values.panelLength;
    const fixedZoneEnd = values && values.fixedZoneEnd;
    const screwDiameter = values && values.screwDiameter;
    const alphaSteel = Number.isFinite(values && values.alphaSteel) ? values.alphaSteel : 0.012;
    const temperatureRange = Number.isFinite(values && values.temperatureRange) ? values.temperatureRange : 100;
    const installationReserve = Number.isFinite(values && values.installationReserve) ? values.installationReserve : 200;
    if (![panelLength, fixedZoneEnd, screwDiameter].every(function (value) { return Number.isFinite(value) && value >= 0; }) || panelLength <= 0 || screwDiameter <= 0) {
      return { ok: false, errors: ["Dĺžka pásu, pevná zóna a priemer skrutky musia byť platné."] };
    }
    if (fixedZoneEnd > panelLength) return { ok: false, errors: ["Horný okraj pevnej zóny nemôže byť za hrebeňom."] };
    const upperSlidingLength = panelLength - fixedZoneEnd;
    const upperLengthMeters = upperSlidingLength / TICKS_PER_MM / 1000;
    const thermalMovementMm = upperLengthMeters * alphaSteel * temperatureRange;
    const thermalMovement = Math.round(thermalMovementMm * TICKS_PER_MM);
    const theoreticalSlotLength = screwDiameter + thermalMovement;
    const minimumSlotLength = Math.ceil(theoreticalSlotLength / TICKS_PER_MM) * TICKS_PER_MM;
    const requiredWithReserve = theoreticalSlotLength + installationReserve;
    const requiredMm = requiredWithReserve / TICKS_PER_MM;
    const recommendedSlotLength = Math.max(800, Math.ceil(requiredMm / 2) * 200);
    const clearanceWidthMm = screwDiameter / TICKS_PER_MM + 1;
    const recommendedSlotWidth = Math.ceil(clearanceWidthMm / 2) * 200;
    return {
      ok: true,
      panelLength: panelLength,
      fixedZoneEnd: fixedZoneEnd,
      upperSlidingLength: upperSlidingLength,
      alphaSteel: alphaSteel,
      temperatureRange: temperatureRange,
      screwDiameter: screwDiameter,
      installationReserve: installationReserve,
      thermalMovement: thermalMovement,
      theoreticalSlotLength: theoreticalSlotLength,
      minimumSlotLength: minimumSlotLength,
      requiredWithReserve: requiredWithReserve,
      recommendedSlotWidth: recommendedSlotWidth,
      recommendedSlotLength: recommendedSlotLength,
      movementDirection: "k hrebeňu",
      slotOrientation: "pozdĺž smeru spádu / dilatácie"
    };
  }

  function solveDownpipeOffset(values) {
    const x = values && values.x;
    const y = values && values.y;
    const diameter = values && values.diameter;
    const insertion = values && values.insertion;
    const angleDegrees = values && values.angleDegrees;
    if (![x, diameter, insertion, angleDegrees].every(function (value) { return Number.isFinite(value); }) || x <= 0 || insertion < 0) {
      return { ok: false, errors: ["X a priemer musia byť kladné a zasunutie nesmie byť záporné."] };
    }
    if (diameter < 8000 || diameter > 15000 || diameter % 1000 !== 0) return { ok: false, errors: ["Priemer rúry musí byť 80 až 150 mm po 10 mm."] };
    if (angleDegrees <= 0 || angleDegrees >= 90) {
      return { ok: false, errors: ["Uhol kolena musí byť väčší ako 0° a menší ako 90°."] };
    }
    const radians = angleDegrees * Math.PI / 180;
    const radius = diameter;
    const arcHorizontal = 2 * radius * (1 - Math.cos(radians));
    const arcVertical = 2 * radius * Math.sin(radians);
    if (x < arcHorizontal) return { ok: false, errors: ["Rozmer X je menší ako minimálne odsadenie dvoch kolien pri tomto priemere a uhle."] };
    const clearLengthRaw = (x - arcHorizontal) / Math.sin(radians);
    const requiredYRaw = arcVertical + clearLengthRaw * Math.cos(radians);
    const requiredY = Math.round(requiredYRaw / TICKS_PER_MM) * TICKS_PER_MM;
    const clearLength = Math.ceil(clearLengthRaw / TICKS_PER_MM) * TICKS_PER_MM;
    const cutLength = Math.ceil((clearLengthRaw + 2 * insertion) / TICKS_PER_MM) * TICKS_PER_MM;
    const yCorrection = Number.isFinite(y) ? requiredY - y : 0;
    return {
      ok: true,
      x: x,
      enteredY: Number.isFinite(y) ? y : requiredY,
      requiredY: requiredY,
      yCorrection: yCorrection,
      diameter: diameter,
      insertion: insertion,
      angleDegrees: angleDegrees,
      bendRadius: radius,
      arcHorizontal: Math.round(arcHorizontal / TICKS_PER_MM) * TICKS_PER_MM,
      arcVertical: Math.round(arcVertical / TICKS_PER_MM) * TICKS_PER_MM,
      clearLength: clearLength,
      cutLength: cutLength
    };
  }

  function solveThreeElbowOffset(values) {
    const x = values && values.x;
    const diameter = values && values.diameter;
    const alphaDegrees = values && values.alphaDegrees;
    const insertion = values && Number.isFinite(values.insertion) ? values.insertion : DEFAULT_INSERTION_DEPTH_TICKS;
    const angleOptions = values && Array.isArray(values.angleOptions) ? values.angleOptions : [40, 72, 87];
    if (![x, diameter, alphaDegrees, insertion].every(function (value) { return Number.isFinite(value); }) || x <= 0 || insertion <= 0 || alphaDegrees < 0 || alphaDegrees >= 90) {
      return { ok: false, errors: ["X, priemer P a zasunutie musia byť kladné; uhol α musí byť od 0° do 89°."] };
    }
    if (diameter < 8000 || diameter > 15000 || diameter % 1000 !== 0) return { ok: false, errors: ["Priemer rúry musí byť 80 až 150 mm po 10 mm."] };
    if (!angleOptions.length || angleOptions.some(function (angle) { return !Number.isFinite(angle) || angle <= 0 || angle >= 90; })) {
      return { ok: false, errors: ["Zoznam uhlov kolien nie je platný."] };
    }
    const radius = diameter;
    const candidates = [];
    function arcPoint(px, py, heading, signedAngle) {
      const turn = signedAngle * Math.PI / 180;
      const direction = Math.sign(turn);
      const nextHeading = heading + turn;
      return {
        x: px + radius / direction * (Math.sin(nextHeading) - Math.sin(heading)),
        y: py + radius / direction * (-Math.cos(nextHeading) + Math.cos(heading)),
        heading: nextHeading
      };
    }
    angleOptions.forEach(function (angle1) {
      angleOptions.forEach(function (angle2) {
        angleOptions.forEach(function (angle3) {
          let point = { x: 0, y: 0, heading: Math.PI / 2 };
          point = arcPoint(point.x, point.y, point.heading, -angle1);
          const afterFirst = { x: point.x, y: point.y, heading: point.heading };
          point = arcPoint(point.x, point.y, point.heading, angle2);
          const afterSecond = { x: point.x, y: point.y, heading: point.heading };
          point = arcPoint(point.x, point.y, point.heading, angle3);
          const arcEnd = { x: point.x, y: point.y, heading: point.heading };
          const cosA = Math.cos(afterFirst.heading);
          const sinA = Math.sin(afterFirst.heading);
          const cosB = Math.cos(afterSecond.heading);
          const sinB = Math.sin(afterSecond.heading);
          const lengths = [];
          const directJoint = -insertion;
          const directX = arcEnd.x + directJoint * cosA + directJoint * cosB;
          if (Math.abs(directX - x) <= TICKS_PER_MM / 2) lengths.push({ a: 0, b: 0 });
          if (Math.abs(cosA) > 1e-8) {
            const clearA = (x - arcEnd.x - directJoint * cosB) / cosA;
            if (clearA >= 0) lengths.push({ a: clearA + 2 * insertion, b: 0 });
          }
          if (Math.abs(cosB) > 1e-8) {
            const clearB = (x - arcEnd.x - directJoint * cosA) / cosB;
            if (clearB >= 0) lengths.push({ a: 0, b: clearB + 2 * insertion });
          }
          lengths.forEach(function (lengthsCandidate) {
            const a = Math.max(0, Math.round(lengthsCandidate.a / TICKS_PER_MM) * TICKS_PER_MM);
            const b = Math.max(0, Math.round(lengthsCandidate.b / TICKS_PER_MM) * TICKS_PER_MM);
            const jointA = a > 0 ? a - 2 * insertion : directJoint;
            const jointB = b > 0 ? b - 2 * insertion : directJoint;
            const achievedX = arcEnd.x + jointA * cosA + jointB * cosB;
            const achievedY = arcEnd.y + jointA * sinA + jointB * sinB;
            if (!(achievedY > 0)) return;
            const xError = achievedX - x;
            const extensionTotal = a + b;
            const extraPieceCount = (a > 0 ? 1 : 0) + (b > 0 ? 1 : 0);
            const anglePreference = Math.abs(angle1 - 72) + Math.abs(angle2 - 72) + Math.abs(angle3 - 72);
            const finalHeadingDegrees = ((arcEnd.heading * 180 / Math.PI) % 360 + 360) % 360;
            const targetHeadingDegrees = 180 - alphaDegrees;
            const headingDifference = Math.abs(finalHeadingDegrees - targetHeadingDegrees);
            const outletSlopeErrorDegrees = Math.min(headingDifference, 360 - headingDifference);
            const outletSlopeDegrees = Math.abs(180 - finalHeadingDegrees);
            const score = outletSlopeErrorDegrees * 1000000000 + Math.abs(xError) * 1000000 + extensionTotal * 10 + extraPieceCount * 2000 + anglePreference * 10;
            candidates.push({
              angles: [angle1, angle2, angle3],
              a: a,
              b: b,
              jointA: jointA,
              jointB: jointB,
              exposedA: Math.max(0, jointA),
              exposedB: Math.max(0, jointB),
              extensionTotal: extensionTotal,
              extraPieceCount: extraPieceCount,
              achievedX: Math.round(achievedX / TICKS_PER_MM) * TICKS_PER_MM,
              achievedY: Math.round(achievedY / TICKS_PER_MM) * TICKS_PER_MM,
              xError: Math.round(xError / TICKS_PER_MM) * TICKS_PER_MM || 0,
              finalHeadingDegrees: finalHeadingDegrees,
              outletSlopeDegrees: outletSlopeDegrees,
              outletSlopeErrorDegrees: outletSlopeErrorDegrees,
              score: score
            });
          });
        });
      });
    });
    if (!candidates.length) return { ok: false, errors: ["Pre zadané rozmery sa nenašla zostava troch kolien."] };
    candidates.sort(function (left, right) { return left.score - right.score || left.extensionTotal - right.extensionTotal || left.outletSlopeErrorDegrees - right.outletSlopeErrorDegrees; });
    const best = candidates[0];
    best.insertion = insertion;
    return Object.assign({ ok: true, x: x, y: best.achievedY, alphaDegrees: alphaDegrees, diameter: diameter, bendRadius: radius, topology: "pravé–ľavé–ľavé", evaluatedCombinations: Math.pow(angleOptions.length, 3) }, best);
  }

  // Layout of a tangent circular corner for field marking with a square.
  // Lengths use the application's fixed-point unit (100 ticks = 1 mm).
  function solveSeamRadiusLayout(values) {
    const input = values || {}, angleDegrees = Number(input.angleDegrees), flangeWidth = Number(input.flangeWidth), radius = Number(input.radius), jointType = input.jointType === "pocket-pocket" ? "pocket-pocket" : "arc-pocket", elongationPercent = Number(input.elongationPercent || 22), errors = [];
    if (!(angleDegrees > 0 && angleDegrees < 150)) errors.push("Uhol musí byť väčší ako 0° a menší ako 150°.");
    if (!(flangeWidth > 0)) errors.push("Šírka zahnutia musí byť väčšia ako 0 mm.");
    if (!(radius > 0)) errors.push("Polomer musí byť väčší ako 0 mm.");
    if (!(elongationPercent > 0)) errors.push("Ťažnosť materiálu musí byť väčšia ako 0 %.");
    if (errors.length) return { ok: false, errors: errors };

    const theta = angleDegrees * Math.PI / 180, tangentSetback = radius * Math.tan(theta / 2), endpointX = radius * Math.sin(theta), endpointY = radius * (1 - Math.cos(theta)), pointCount = 8, points = [];
    for (let index = 0; index <= pointCount; index += 1) {
      const phi = theta * index / pointCount;
      points.push({ index: index, fraction: index / pointCount, angleDegrees: angleDegrees * index / pointCount, x: radius * Math.sin(phi), y: radius * (1 - Math.cos(phi)) });
    }

    const formingStrainPercent = flangeWidth / radius * 100;
    // DX51D commonly has A80 min. 22 %. The limits below deliberately retain
    // reserve for coating, edge condition, work hardening and hand forming.
    const recommendedStrainPercent = elongationPercent * 0.60;
    const trialStrainPercent = elongationPercent * 0.75;
    const roundUpTicks = (value, step) => Math.ceil(value / step) * step;
    const recommendedRadius = roundUpTicks(flangeWidth / (recommendedStrainPercent / 100), 500);
    const trialRadius = roundUpTicks(flangeWidth / (trialStrainPercent / 100), 500);
    let riskCode = "recommended", riskLabel = "PRACOVNÝ ODPORÚČANÝ RÁDIUS";
    if (jointType === "pocket-pocket") { riskCode = "pocket"; riskLabel = "KAPSA + KAPSA – POSUDZUJE SA SKÚŠKOU"; }
    else if (formingStrainPercent > elongationPercent) { riskCode = "high"; riskLabel = "VYSOKÉ RIZIKO PRETRHNUTIA"; }
    else if (formingStrainPercent > trialStrainPercent) { riskCode = "borderline"; riskLabel = "HRANIČNÉ – UROBIŤ SKÚŠOBNÝ KUS"; }
    else if (formingStrainPercent > recommendedStrainPercent) { riskCode = "trial"; riskLabel = "SKÚŠOBNÝ RÁDIUS"; }

    return {
      ok: true,
      angleDegrees: angleDegrees,
      flangeWidth: flangeWidth,
      radius: radius,
      jointType: jointType,
      elongationPercent: elongationPercent,
      formingStrainPercent: formingStrainPercent,
      recommendedStrainPercent: recommendedStrainPercent,
      trialStrainPercent: trialStrainPercent,
      recommendedRadius: recommendedRadius,
      trialRadius: trialRadius,
      tangentSetback: tangentSetback,
      endpointX: endpointX,
      endpointY: endpointY,
      chordLength: 2 * radius * Math.sin(theta / 2),
      arcLength: radius * theta,
      points: points,
      riskCode: riskCode,
      riskLabel: riskLabel,
      materialLabel: "KJG farebný pozink 0,50 mm – základ DX51D (kým atest neurčí inak)"
    };
  }

  const api = { TICKS_PER_MM: TICKS_PER_MM, DEFAULT_INSERTION_DEPTH_TICKS: DEFAULT_INSERTION_DEPTH_TICKS, parseDimension: parseDimension, formatDimension: formatDimension, calculateBasicLayout: calculateBasicLayout, distributeCorrection: distributeCorrection, solveCorrection: solveCorrection, groupPieces: groupPieces, solveRightTriangle: solveRightTriangle, solveRectangleSquaring: solveRectangleSquaring, solveSheetPerpendicular: solveSheetPerpendicular, solveClipLayout: solveClipLayout, solveUpperSlidingDilatation: solveUpperSlidingDilatation, solveDownpipeOffset: solveDownpipeOffset, solveThreeElbowOffset: solveThreeElbowOffset, solveSeamRadiusLayout: solveSeamRadiusLayout };
  api.UserDimensionLockManager = UserDimensionLockManager;
  api.GeometryConstraintSolver = GeometryConstraintSolver;
  api.ProportionalGeometryAdjuster = ProportionalGeometryAdjuster;
  api.ConstraintOptimization = ConstraintOptimization;
  api.solveRectangleSquaringConstrained = solveRectangleSquaringConstrained;
  root.GeometrySolver = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
