# Mobile Activity Logger V4 - Call Sessions

## Changes

- Phone calls are no longer logged every few seconds.
- In-call screen creates:
  - CALL_START
  - CALL_END
- After the call ends, the app opens a note dialog:
  - save CALL_NOTE
  - or cancel without note
- Google Maps navigation remains start/end only:
  - NAVIGATION_START
  - NAVIGATION_END
- Generic screen context remains throttled/deduplicated.

## Required settings

- Usage Access enabled
- Accessibility enabled
- Battery unrestricted
- Same Apps Script unified_screen endpoint as before
