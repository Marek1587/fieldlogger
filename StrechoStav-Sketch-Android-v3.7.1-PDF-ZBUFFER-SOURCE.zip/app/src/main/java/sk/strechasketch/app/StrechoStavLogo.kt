package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface

/** Runtime rendering of the supplied StrechoStav roof/chimney SVG identity. */
object StrechoStavLogo {
    fun bitmap(width: Int = 1024, height: Int = 470): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val scaleX = width / 1000f
        val scaleY = height / 470f
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(205, 214, 218)
            style = Paint.Style.STROKE
            strokeWidth = 14f * minOf(scaleX, scaleY)
            strokeJoin = Paint.Join.MITER
            strokeCap = Paint.Cap.SQUARE
        }
        val roof = Path().apply {
            // Proportions traced from the supplied SVG identity: asymmetric ridge, chimney
            // standing on the right roof plane and short folded eaves at both ends.
            moveTo(190f * scaleX, 225f * scaleY)
            lineTo(558f * scaleX, 88f * scaleY)
            lineTo(670f * scaleX, 132f * scaleY)
            lineTo(670f * scaleX, 58f * scaleY)
            lineTo(735f * scaleX, 58f * scaleY)
            lineTo(735f * scaleX, 157f * scaleY)
            lineTo(925f * scaleX, 225f * scaleY)
            lineTo(895f * scaleX, 319f * scaleY)
            lineTo(869f * scaleX, 310f * scaleY)
            moveTo(190f * scaleX, 225f * scaleY)
            lineTo(220f * scaleX, 319f * scaleY)
            lineTo(246f * scaleX, 310f * scaleY)
        }
        canvas.drawPath(roof, line)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(205, 214, 218)
            textAlign = Paint.Align.CENTER
            textSize = 128f * scaleY
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        canvas.drawText("StrechoStav", 560f * scaleX, 370f * scaleY, text)
        return bitmap
    }
}
