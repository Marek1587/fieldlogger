package sk.klampsketch.app

import org.junit.Assert.assertEquals
import org.junit.Test

class CoilCutPlannerTest {
    @Test
    fun `length tiers preserve all four exact boundaries`() {
        assertEquals(ProfileLengthTier.UP_TO_ONE_METER, profileLengthTier(1.00))
        assertEquals(ProfileLengthTier.ONE_TO_TWO_METERS, profileLengthTier(1.001))
        assertEquals(ProfileLengthTier.ONE_TO_TWO_METERS, profileLengthTier(1.999))
        assertEquals(ProfileLengthTier.TWO_TO_FOUR_METERS, profileLengthTier(2.00))
        assertEquals(ProfileLengthTier.TWO_TO_FOUR_METERS, profileLengthTier(4.00))
        assertEquals(ProfileLengthTier.OVER_FOUR_METERS, profileLengthTier(4.001))
    }

    @Test
    fun `KL-00011 bending uses bending meters not profile meters`() {
        val drawing = DrawingRecord(
            id = 11,
            projectId = 1,
            name = "Referenčný profil",
            identifier = "KL-00011",
            points = MutableList(9) { index -> ProfilePoint(index * 10f, 0f) },
            profileLengthM = 3.35,
            quantity = 2
        )

        val plan = CoilCutPlanner.createPlan(
            drawings = listOf(drawing),
            coilWidthMm = 1250,
            includeSummary = true
        )
        val item = plan.productCosts.single()

        assertEquals(ProfileLengthTier.TWO_TO_FOUR_METERS, item.lengthTier)
        assertEquals(6.70, item.profileMeters, 1e-9)
        assertEquals(46.90, item.bendingMeters, 1e-9)
        assertEquals(0.72, item.bendingRateEurPerM, 1e-9)
        assertEquals(33.768, item.bendingCostEur, 1e-9)
        assertEquals("33,77", formatDecimal(item.bendingCostEur))
    }

    @Test
    fun `real cutting and material allocations reconcile exactly with optimized runs`() {
        val drawings = listOf(
            DrawingRecord(
                id = 21,
                projectId = 1,
                name = "A",
                identifier = "KL-A",
                points = mutableListOf(
                    ProfilePoint(0f, 0f),
                    ProfilePoint(300f, 0f),
                    ProfilePoint(300f, 50f)
                ),
                profileLengthM = 2.4,
                quantity = 2
            ),
            DrawingRecord(
                id = 22,
                projectId = 1,
                name = "B",
                identifier = "KL-B",
                points = mutableListOf(
                    ProfilePoint(0f, 0f),
                    ProfilePoint(180f, 0f),
                    ProfilePoint(180f, 40f),
                    ProfilePoint(220f, 40f)
                ),
                profileLengthM = 1.6,
                quantity = 3
            )
        )

        val plan = CoilCutPlanner.createPlan(drawings, 1000, includeSummary = true)
        val plannedLongitudinal = plan.materialPlans.sumOf { it.longitudinalCutMeters }
        val plannedTransverse = plan.materialPlans.sumOf { it.transverseCutMeters }

        assertEquals(plannedLongitudinal, plan.productCosts.sumOf { it.longitudinalCutMeters }, 1e-9)
        assertEquals(plannedTransverse, plan.productCosts.sumOf { it.transverseCutMeters }, 1e-9)
        assertEquals(
            plannedLongitudinal + plannedTransverse,
            plan.productCosts.sumOf { it.cuttingMeters },
            1e-9
        )
        assertEquals(
            plan.totalMaterialPriceEur,
            plan.productCosts.sumOf { it.allocatedMaterialCostEur },
            1e-9
        )
        assertEquals(
            plan.totalCostEur,
            plan.productCosts.sumOf { it.totalCostEur },
            1e-9
        )
    }

    @Test
    fun `tier summary prices bending meters and always keeps four categories`() {
        val drawings = listOf(0.8, 1.5, 2.0, 4.5).mapIndexed { index, length ->
            DrawingRecord(
                id = 100L + index,
                projectId = 1,
                name = "Profil $index",
                identifier = "KL-$index",
                points = mutableListOf(
                    ProfilePoint(0f, 0f),
                    ProfilePoint(100f, 0f),
                    ProfilePoint(100f, 100f),
                    ProfilePoint(200f, 100f)
                ),
                profileLengthM = length,
                quantity = 1
            )
        }

        val plan = CoilCutPlanner.createPlan(drawings, 1250, includeSummary = true)

        assertEquals(4, plan.tierSummaries.size)
        plan.tierSummaries.forEach { summary ->
            assertEquals(
                summary.bendingMeters * summary.tier.priceEurPerM,
                summary.priceEur,
                1e-9
            )
        }
        assertEquals(
            plan.totalBendingCostEur,
            plan.tierSummaries.sumOf { it.priceEur },
            1e-9
        )
    }
}
