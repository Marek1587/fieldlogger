package sk.klampsketch.app

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sqrt

const val DEFAULT_SHEET_PRICE_EUR_PER_KG = 2.69
const val SHORT_PROFILE_PRICE_EUR_PER_M = 0.77
const val LONG_PROFILE_PRICE_EUR_PER_M = 0.72

data class ProfilePoint(var x: Float, var y: Float)

data class ProjectRecord(
    val id: Long = 0,
    val name: String,
    val customer: String = "",
    val address: String = ""
)

data class StockSheetRecord(
    val id: Long = 0,
    val projectId: Long,
    val lengthMm: Int,
    val widthMm: Int,
    val quantity: Int = 1,
    val material: String = "Farebný pozink",
    val ral: String = "RAL 8028",
    val thicknessMm: Double = 0.5,
    val createdAt: Long = System.currentTimeMillis()
)

data class DrawingRecord(
    val id: Long = 0,
    val projectId: Long,
    var name: String,
    var identifier: String,
    var points: MutableList<ProfilePoint>,
    var backPoints: MutableList<ProfilePoint>? = null,
    var material: String = "Farebný pozink",
    var ral: String = "RAL 8028",
    var thicknessMm: Double = 0.5,
    var profileLengthM: Double = 2.0,
    var quantity: Int = 1,
    var photoPath: String? = null,
    var paintedTopSide: Boolean = true,
    var updatedAt: Long = System.currentTimeMillis()
)

data class ProfileMetrics(
    val developedWidthMm: Int,
    val rearDevelopedWidthMm: Int?,
    val blankWidthMm: Int,
    val bends: Int,
    val netProfileAreaM2: Double,
    val sheetPerPieceM2: Double,
    val sheetTotalM2: Double,
    val offcutPerPieceM2: Double,
    val offcutTotalM2: Double,
    val weightPerPieceKg: Double,
    val weightTotalKg: Double,
    val materialPricePerPieceEur: Double,
    val materialPriceTotalEur: Double,
    val bendingMetersPerPiece: Double,
    val bendingMetersTotal: Double,
    val bendingRateEurPerM: Double,
    val bendingCostPerPieceEur: Double,
    val bendingCostTotalEur: Double,
    val estimatedPricePerPieceEur: Double,
    val estimatedPriceTotalEur: Double
)

enum class ProfileLengthTier(
    val label: String,
    val priceEurPerM: Double
) {
    UP_TO_ONE_METER("0 až 1 m", SHORT_PROFILE_PRICE_EUR_PER_M),
    ONE_TO_TWO_METERS("nad 1 až menej ako 2 m", SHORT_PROFILE_PRICE_EUR_PER_M),
    TWO_TO_FOUR_METERS("2 až 4 m", LONG_PROFILE_PRICE_EUR_PER_M),
    OVER_FOUR_METERS("nad 4 m", LONG_PROFILE_PRICE_EUR_PER_M)
}

fun profileLengthTier(lengthM: Double): ProfileLengthTier = when {
    lengthM <= 1.0 -> ProfileLengthTier.UP_TO_ONE_METER
    lengthM < 2.0 -> ProfileLengthTier.ONE_TO_TWO_METERS
    lengthM <= 4.0 -> ProfileLengthTier.TWO_TO_FOUR_METERS
    else -> ProfileLengthTier.OVER_FOUR_METERS
}

fun bendingRateEurPerM(lengthM: Double): Double =
    profileLengthTier(lengthM).priceEurPerM

fun encodePoints(points: List<ProfilePoint>): String {
    val result = JSONArray()
    points.forEach { point ->
        result.put(
            JSONObject()
                .put("x", point.x.toDouble())
                .put("y", point.y.toDouble())
        )
    }
    return result.toString()
}

fun decodePoints(json: String): MutableList<ProfilePoint> {
    return try {
        val array = JSONArray(json)
        MutableList(array.length()) { index ->
            val point = array.getJSONObject(index)
            ProfilePoint(
                point.optDouble("x", 0.0).toFloat(),
                point.optDouble("y", 0.0).toFloat()
            )
        }
    } catch (_: Exception) {
        mutableListOf()
    }
}

fun DrawingRecord.validBackPoints(): MutableList<ProfilePoint>? =
    backPoints?.takeIf { it.size == points.size && it.size >= 2 }

fun calculateMetrics(drawing: DrawingRecord): ProfileMetrics {
    val frontWidthMm = developedWidth(drawing.points)
    val back = drawing.validBackPoints()
    val rearWidthMm = back?.let(::developedWidth)
    val blankWidthMm = maxOf(frontWidthMm, rearWidthMm ?: frontWidthMm)

    // Spotreba plechu sa v klampiarskej výrobe počíta z celého obdĺžnikového
    // polotovaru: najväčšia rozvinutá šírka × výrobná dĺžka. Tým sa do
    // spotreby započíta aj klinovitý odrezok pri skosenom profile.
    val sheetPerPiece = blankWidthMm / 1000.0 * drawing.profileLengthM

    // Hmotnosť hotového profilu sa počíta z čistej plochy rozvinutého plášťa,
    // nie z odrezku, ktorý po vystrihnutí nezostáva súčasťou výrobku.
    val netProfileArea = if (back == null) {
        sheetPerPiece
    } else {
        taperedSurfaceAreaM2(
            drawing.points,
            back,
            drawing.profileLengthM * 1000.0
        )
    }
    val offcutPerPiece = (sheetPerPiece - netProfileArea).coerceAtLeast(0.0)

    val arealWeightKgM2 = materialArealWeightKgM2(drawing)
    val quantity = drawing.quantity.coerceAtLeast(1)
    val weightPerPiece = netProfileArea * arealWeightKgM2
    val materialPricePerPiece =
        sheetPerPiece * arealWeightKgM2 * DEFAULT_SHEET_PRICE_EUR_PER_KG
    val bends = (drawing.points.size - 2).coerceAtLeast(0)
    val bendingMetersPerPiece = drawing.profileLengthM * bends
    val bendingMetersTotal = bendingMetersPerPiece * quantity
    val productionRate = bendingRateEurPerM(drawing.profileLengthM)
    val productionPerPiece = bendingMetersPerPiece * productionRate
    val estimatedPricePerPiece = materialPricePerPiece + productionPerPiece
    return ProfileMetrics(
        developedWidthMm = frontWidthMm,
        rearDevelopedWidthMm = rearWidthMm,
        blankWidthMm = blankWidthMm,
        bends = bends,
        netProfileAreaM2 = netProfileArea,
        sheetPerPieceM2 = sheetPerPiece,
        sheetTotalM2 = sheetPerPiece * quantity,
        offcutPerPieceM2 = offcutPerPiece,
        offcutTotalM2 = offcutPerPiece * quantity,
        weightPerPieceKg = weightPerPiece,
        weightTotalKg = weightPerPiece * quantity,
        materialPricePerPieceEur = materialPricePerPiece,
        materialPriceTotalEur = materialPricePerPiece * quantity,
        bendingMetersPerPiece = bendingMetersPerPiece,
        bendingMetersTotal = bendingMetersTotal,
        bendingRateEurPerM = productionRate,
        bendingCostPerPieceEur = productionPerPiece,
        bendingCostTotalEur = productionPerPiece * quantity,
        estimatedPricePerPieceEur = estimatedPricePerPiece,
        estimatedPriceTotalEur = estimatedPricePerPiece * quantity
    )
}

fun materialArealWeightKgM2(drawing: DrawingRecord): Double {
    val density = when {
        drawing.material.contains("hlin", ignoreCase = true) -> 2700.0
        drawing.material.contains("meď", ignoreCase = true) ||
            drawing.material.contains("med", ignoreCase = true) -> 8960.0
        drawing.material.contains("titán", ignoreCase = true) ||
            drawing.material.contains("zinok", ignoreCase = true) -> 7140.0
        else -> 7850.0
    }
    return if (
        drawing.material.contains("pozink", ignoreCase = true) &&
        kotlin.math.abs(drawing.thicknessMm - 0.5) < 0.001
    ) {
        3.928
    } else {
        drawing.thicknessMm / 1000.0 * density
    }
}

private fun developedWidth(points: List<ProfilePoint>): Int =
    points.zipWithNext().sumOf { (start, end) ->
        snapFive(hypot(
            (end.x - start.x).toDouble(),
            (end.y - start.y).toDouble()
        ))
    }

private fun taperedSurfaceAreaM2(
    front: List<ProfilePoint>,
    back: List<ProfilePoint>,
    lengthMm: Double
): Double {
    var areaMm2 = 0.0
    for (index in 0 until front.lastIndex) {
        val a = Point3(front[index].x.toDouble(), front[index].y.toDouble(), 0.0)
        val b = Point3(front[index + 1].x.toDouble(), front[index + 1].y.toDouble(), 0.0)
        val c = Point3(back[index + 1].x.toDouble(), back[index + 1].y.toDouble(), lengthMm)
        val d = Point3(back[index].x.toDouble(), back[index].y.toDouble(), lengthMm)
        areaMm2 += triangleArea(a, b, c) + triangleArea(a, c, d)
    }
    return areaMm2 / 1_000_000.0
}

private data class Point3(val x: Double, val y: Double, val z: Double)

private fun triangleArea(a: Point3, b: Point3, c: Point3): Double {
    val abX = b.x - a.x
    val abY = b.y - a.y
    val abZ = b.z - a.z
    val acX = c.x - a.x
    val acY = c.y - a.y
    val acZ = c.z - a.z
    val crossX = abY * acZ - abZ * acY
    val crossY = abZ * acX - abX * acZ
    val crossZ = abX * acY - abY * acX
    return 0.5 * sqrt(crossX * crossX + crossY * crossY + crossZ * crossZ)
}

fun snapFive(value: Double): Int =
    ((value / 5.0).roundToInt() * 5).coerceAtLeast(5)

fun formatDecimal(value: Double, digits: Int = 2): String =
    "%.${digits}f".format(java.util.Locale("sk", "SK"), value)
