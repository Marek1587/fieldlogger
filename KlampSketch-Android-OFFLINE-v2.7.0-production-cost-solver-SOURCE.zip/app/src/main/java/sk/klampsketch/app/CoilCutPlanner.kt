package sk.klampsketch.app

import kotlin.math.max
import kotlin.math.abs
import kotlin.math.roundToInt

const val CUTTING_PRICE_EUR_PER_M = 0.50
const val MAX_LONGITUDINAL_KNIVES = 3
const val MAX_LANES_PER_RUN = MAX_LONGITUDINAL_KNIVES + 1

enum class CutMaterialSource { STOCK_SHEET, NEW_COIL }

data class CoilMaterialKey(
    val material: String,
    val ral: String,
    val thicknessMicrons: Int
) {
    val thicknessMm: Double get() = thicknessMicrons / 1000.0

    fun matches(stockSheet: StockSheetRecord): Boolean =
        material.equals(stockSheet.material, ignoreCase = true) &&
            ral.equals(stockSheet.ral, ignoreCase = true) &&
            thicknessMicrons == (stockSheet.thicknessMm * 1000.0).roundToInt()
}

data class CoilCutUnit(
    val drawingId: Long,
    val identifier: String,
    val name: String,
    val pieceNumber: Int,
    val widthMm: Int,
    val lengthMm: Int,
    val bends: Int
) {
    val areaM2: Double get() = widthMm * lengthMm / 1_000_000.0
}

data class CoilCutLane(val units: List<CoilCutUnit>) {
    init {
        require(units.isNotEmpty()) { "Pás delenia nesmie byť prázdny." }
        require(units.all { it.widthMm == units.first().widthMm }) {
            "V jednom pozdĺžnom páse musia mať všetky kusy rovnakú šírku."
        }
    }

    val widthMm: Int get() = units.first().widthMm
    val lengthMm: Int get() = units.sumOf { it.lengthMm }
    val netAreaM2: Double get() = units.sumOf { it.areaM2 }
}

data class CoilCutRun(
    val lanes: List<CoilCutLane>,
    val source: CutMaterialSource,
    val sourceWidthMm: Int,
    val fixedSourceLengthMm: Int? = null,
    val stockSheetId: Long? = null
) {
    val units: List<CoilCutUnit> get() = lanes.flatMap { it.units }
    val usedWidthMm: Int get() = lanes.sumOf { it.widthMm }
    val occupiedLengthMm: Int get() = lanes.maxOfOrNull { it.lengthMm } ?: 0
    val lengthMm: Int get() = fixedSourceLengthMm ?: occupiedLengthMm
    val netAreaM2: Double get() = lanes.sumOf { it.netAreaM2 }
    val grossAreaM2: Double get() = sourceWidthMm * lengthMm / 1_000_000.0

    val longitudinalKnifeCount: Int get() {
        if (lanes.isEmpty()) return 0
        val internalCuts = (lanes.size - 1).coerceAtLeast(0)
        val wasteEdgeCut = if (usedWidthMm < sourceWidthMm) 1 else 0
        return internalCuts + wasteEdgeCut
    }

    val longitudinalCutMeters: Double get() =
        longitudinalKnifeCount * lengthMm / 1000.0

    val transverseCutMeters: Double get() =
        lanes.sumOf { lane -> lane.widthMm * lane.units.size } / 1000.0
}

data class CoilMaterialPlan(
    val key: CoilMaterialKey,
    val runs: List<CoilCutRun>,
    val coilWidthMm: Int,
    val arealWeightKgM2: Double
) {
    val coilRuns: List<CoilCutRun> get() = runs.filter { it.source == CutMaterialSource.NEW_COIL }
    val stockRuns: List<CoilCutRun> get() = runs.filter { it.source == CutMaterialSource.STOCK_SHEET }
    val requiredLengthM: Double get() = coilRuns.sumOf { it.lengthMm } / 1000.0
    val coilAreaM2: Double get() = coilRuns.sumOf { it.grossAreaM2 }
    val stockAreaM2: Double get() = stockRuns.sumOf { it.grossAreaM2 }
    val grossAreaM2: Double get() = runs.sumOf { it.grossAreaM2 }
    val netAreaM2: Double get() = runs.sumOf { it.netAreaM2 }
    val wasteAreaM2: Double get() = (grossAreaM2 - netAreaM2).coerceAtLeast(0.0)
    val utilizationPercent: Double get() =
        if (grossAreaM2 <= 0.0) 0.0 else netAreaM2 / grossAreaM2 * 100.0
    val grossWeightKg: Double get() = grossAreaM2 * arealWeightKgM2
    val materialPriceEur: Double get() = grossWeightKg * DEFAULT_SHEET_PRICE_EUR_PER_KG
    val longitudinalCutMeters: Double get() = runs.sumOf { it.longitudinalCutMeters }
    val transverseCutMeters: Double get() = runs.sumOf { it.transverseCutMeters }
}

data class CoilProductCost(
    val drawingId: Long,
    val identifier: String,
    val name: String,
    val quantity: Int,
    val blankWidthMm: Int,
    val profileLengthM: Double,
    val lengthTier: ProfileLengthTier,
    val bends: Int,
    val bendingMeters: Double,
    val profileMeters: Double,
    val bendingRateEurPerM: Double,
    val allocatedMaterialAreaM2: Double,
    val allocatedMaterialCostEur: Double,
    val longitudinalCutMeters: Double,
    val transverseCutMeters: Double,
    val stockPieceCount: Int,
    val newCoilPieceCount: Int
) {
    val cuttingMeters: Double get() = longitudinalCutMeters + transverseCutMeters
    val bendingCostEur: Double get() = bendingMeters * bendingRateEurPerM
    val cuttingCostEur: Double get() = cuttingMeters * CUTTING_PRICE_EUR_PER_M
    val productionCostEur: Double get() = bendingCostEur + cuttingCostEur
    val totalCostEur: Double get() = allocatedMaterialCostEur + productionCostEur
    val materialCostPerPieceEur: Double get() = perPiece(allocatedMaterialCostEur)
    val bendingCostPerPieceEur: Double get() = perPiece(bendingCostEur)
    val cuttingCostPerPieceEur: Double get() = perPiece(cuttingCostEur)
    val productionCostPerPieceEur: Double get() =
        perPiece(productionCostEur)
    val totalCostPerPieceEur: Double get() = perPiece(totalCostEur)

    private fun perPiece(value: Double): Double =
        if (quantity <= 0) 0.0 else value / quantity
}

data class ProfileTierSummary(
    val tier: ProfileLengthTier,
    val pieceCount: Int,
    val profileMeters: Double,
    val bendingMeters: Double,
    val priceEur: Double
)

data class CoilCutPlan(
    val coilWidthMm: Int,
    val includeSummary: Boolean,
    val materialPlans: List<CoilMaterialPlan>,
    val productCosts: List<CoilProductCost>
) {
    val totalCoilLengthM: Double get() = materialPlans.sumOf { it.requiredLengthM }
    val totalCoilAreaM2: Double get() = materialPlans.sumOf { it.coilAreaM2 }
    val totalStockAreaM2: Double get() = materialPlans.sumOf { it.stockAreaM2 }
    val totalGrossAreaM2: Double get() = materialPlans.sumOf { it.grossAreaM2 }
    val totalNetAreaM2: Double get() = materialPlans.sumOf { it.netAreaM2 }
    val totalWasteAreaM2: Double get() = materialPlans.sumOf { it.wasteAreaM2 }
    val totalMaterialPriceEur: Double get() = materialPlans.sumOf { it.materialPriceEur }
    val totalBendingMeters: Double get() = productCosts.sumOf { it.bendingMeters }
    val totalProfileMeters: Double get() = productCosts.sumOf { it.profileMeters }
    val totalLongitudinalCutMeters: Double get() = productCosts.sumOf { it.longitudinalCutMeters }
    val totalTransverseCutMeters: Double get() = productCosts.sumOf { it.transverseCutMeters }
    val totalCuttingMeters: Double get() = productCosts.sumOf { it.cuttingMeters }
    val totalBendingCostEur: Double get() = productCosts.sumOf { it.bendingCostEur }
    val totalCuttingCostEur: Double get() = productCosts.sumOf { it.cuttingCostEur }
    val totalProductionCostEur: Double get() = productCosts.sumOf { it.productionCostEur }
    val totalCostEur: Double get() = totalMaterialPriceEur + totalProductionCostEur
    val totalAllocatedMaterialPriceEur: Double get() =
        productCosts.sumOf { it.allocatedMaterialCostEur }
    val totalProductPricesEur: Double get() = productCosts.sumOf { it.totalCostEur }
    val totalStockPieces: Int get() = productCosts.sumOf { it.stockPieceCount }
    val totalNewCoilPieces: Int get() = productCosts.sumOf { it.newCoilPieceCount }
    val utilizationPercent: Double get() =
        if (totalGrossAreaM2 <= 0.0) 0.0 else totalNetAreaM2 / totalGrossAreaM2 * 100.0
    val tierSummaries: List<ProfileTierSummary> get() = ProfileLengthTier.entries.map { tier ->
        val products = productCosts.filter { it.lengthTier == tier }
        val pieces = products.sumOf { it.quantity }
        val meters = products.sumOf { it.profileMeters }
        val bendingMeters = products.sumOf { it.bendingMeters }
        ProfileTierSummary(
            tier = tier,
            pieceCount = pieces,
            profileMeters = meters,
            bendingMeters = bendingMeters,
            priceEur = bendingMeters * tier.priceEurPerM
        )
    }
}

object CoilCutPlanner {
    fun createPlan(
        drawings: List<DrawingRecord>,
        coilWidthMm: Int,
        includeSummary: Boolean,
        stockSheets: List<StockSheetRecord> = emptyList()
    ): CoilCutPlan {
        require(coilWidthMm == 1000 || coilWidthMm == 1250) {
            "Podporovaná šírka zvitku je 1000 alebo 1250 mm."
        }
        require(drawings.isNotEmpty()) { "Nie sú vybrané žiadne výrobky." }

        val unitsByDrawing = drawings.associate { drawing ->
            val metrics = calculateMetrics(drawing)
            val lengthMm = (drawing.profileLengthM * 1000.0).roundToInt().coerceAtLeast(1)
            drawing.id to List(drawing.quantity.coerceAtLeast(1)) { pieceIndex ->
                CoilCutUnit(
                    drawingId = drawing.id,
                    identifier = drawing.identifier,
                    name = drawing.name,
                    pieceNumber = pieceIndex + 1,
                    widthMm = metrics.blankWidthMm,
                    lengthMm = lengthMm,
                    bends = metrics.bends
                )
            }
        }

        val groupedDrawings = drawings.groupBy { drawing ->
            CoilMaterialKey(
                material = drawing.material,
                ral = drawing.ral,
                thicknessMicrons = (drawing.thicknessMm * 1000.0).roundToInt()
            )
        }
        val materialPlans = groupedDrawings.map { (key, groupDrawings) ->
            val remaining = groupDrawings.flatMap { unitsByDrawing.getValue(it.id) }.toMutableList()
            val stockRuns = mutableListOf<CoilCutRun>()
            stockSheets.filter(key::matches).forEach { stockSheet ->
                repeat(stockSheet.quantity.coerceAtLeast(1)) {
                    val stockRun = packOneStockSheet(
                        units = remaining,
                        stockSheet = stockSheet
                    )
                    if (stockRun != null) {
                        stockRuns += stockRun
                        val used = stockRun.units.toSet()
                        remaining.removeAll { it in used }
                    }
                }
            }
            remaining.firstOrNull { it.widthMm > coilWidthMm }?.let { oversized ->
                error(
                    "${oversized.identifier} potrebuje pás ${oversized.widthMm} mm, " +
                        "ktorý sa nezmestí do zvitku $coilWidthMm mm ani do zadaného skladového plechu."
                )
            }
            CoilMaterialPlan(
                key = key,
                runs = stockRuns + optimizeRuns(remaining, coilWidthMm),
                coilWidthMm = coilWidthMm,
                arealWeightKgM2 = materialArealWeightKgM2(groupDrawings.first())
            )
        }.sortedWith(
            compareBy<CoilMaterialPlan> { it.key.material }
                .thenBy { it.key.ral }
                .thenBy { it.key.thicknessMicrons }
        )

        val longitudinalByDrawing = mutableMapOf<Long, Double>()
        val transverseByDrawing = mutableMapOf<Long, Double>()
        val materialAreaByDrawing = mutableMapOf<Long, Double>()
        val materialCostByDrawing = mutableMapOf<Long, Double>()
        val stockPiecesByDrawing = mutableMapOf<Long, Int>()
        val coilPiecesByDrawing = mutableMapOf<Long, Int>()
        materialPlans.forEach { materialPlan ->
            materialPlan.runs.forEach { run ->
                val runLengthM = run.lengthMm / 1000.0
                val runMaterialCost =
                    run.grossAreaM2 * materialPlan.arealWeightKgM2 * DEFAULT_SHEET_PRICE_EUR_PER_KG
                val runNetArea = run.netAreaM2
                run.lanes.forEachIndexed { laneIndex, lane ->
                    var laneBoundaryFactor = 0.0
                    if (laneIndex > 0) laneBoundaryFactor += 0.5
                    if (laneIndex < run.lanes.lastIndex) laneBoundaryFactor += 0.5
                    if (laneIndex == run.lanes.lastIndex && run.usedWidthMm < run.sourceWidthMm) {
                        laneBoundaryFactor += 1.0
                    }
                    val allocatedLaneLongitudinal = runLengthM * laneBoundaryFactor
                    lane.units.forEach { unit ->
                        val materialShare = if (runNetArea <= 0.0) {
                            0.0
                        } else {
                            unit.areaM2 / runNetArea
                        }
                        materialAreaByDrawing[unit.drawingId] =
                            materialAreaByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                run.grossAreaM2 * materialShare
                        materialCostByDrawing[unit.drawingId] =
                            materialCostByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                runMaterialCost * materialShare
                        val unitShare = unit.lengthMm / lane.lengthMm.toDouble()
                        longitudinalByDrawing[unit.drawingId] =
                            longitudinalByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                allocatedLaneLongitudinal * unitShare
                        transverseByDrawing[unit.drawingId] =
                            transverseByDrawing.getOrDefault(unit.drawingId, 0.0) +
                                unit.widthMm / 1000.0
                        val target = if (run.source == CutMaterialSource.STOCK_SHEET) {
                            stockPiecesByDrawing
                        } else {
                            coilPiecesByDrawing
                        }
                        target[unit.drawingId] = target.getOrDefault(unit.drawingId, 0) + 1
                    }
                }
            }
        }

        val costs = drawings.map { drawing ->
            val metrics = calculateMetrics(drawing)
            val quantity = drawing.quantity.coerceAtLeast(1)
            CoilProductCost(
                drawingId = drawing.id,
                identifier = drawing.identifier,
                name = drawing.name,
                quantity = quantity,
                blankWidthMm = metrics.blankWidthMm,
                profileLengthM = drawing.profileLengthM,
                lengthTier = profileLengthTier(drawing.profileLengthM),
                bends = metrics.bends,
                bendingMeters = drawing.profileLengthM * metrics.bends * quantity,
                profileMeters = drawing.profileLengthM * quantity,
                bendingRateEurPerM =
                    bendingRateEurPerM(drawing.profileLengthM),
                allocatedMaterialAreaM2 = materialAreaByDrawing.getOrDefault(drawing.id, 0.0),
                allocatedMaterialCostEur = materialCostByDrawing.getOrDefault(drawing.id, 0.0),
                longitudinalCutMeters = longitudinalByDrawing.getOrDefault(drawing.id, 0.0),
                transverseCutMeters = transverseByDrawing.getOrDefault(drawing.id, 0.0),
                stockPieceCount = stockPiecesByDrawing.getOrDefault(drawing.id, 0),
                newCoilPieceCount = coilPiecesByDrawing.getOrDefault(drawing.id, 0)
            )
        }

        validatePlan(materialPlans, unitsByDrawing.values.sumOf { it.size })
        validateCosts(materialPlans, costs, drawings)
        return CoilCutPlan(coilWidthMm, includeSummary, materialPlans, costs)
    }

    private fun packOneStockSheet(
        units: List<CoilCutUnit>,
        stockSheet: StockSheetRecord
    ): CoilCutRun? {
        val eligible = units.filter {
            it.widthMm <= stockSheet.widthMm && it.lengthMm <= stockSheet.lengthMm
        }
        if (eligible.isEmpty()) return null
        val orders = candidateOrders(eligible)
        val bestLanes = orders.map { order ->
            val lanes = mutableListOf<CoilCutLane>()
            order.forEach { unit ->
                val existingIndex = lanes.withIndex()
                    .filter { (_, lane) ->
                        lane.widthMm == unit.widthMm &&
                            lane.lengthMm + unit.lengthMm <= stockSheet.lengthMm
                    }
                    .minByOrNull { (_, lane) -> stockSheet.lengthMm - lane.lengthMm - unit.lengthMm }
                    ?.index
                if (existingIndex != null) {
                    val lane = lanes[existingIndex]
                    lanes[existingIndex] = lane.copy(units = lane.units + unit)
                } else {
                    val candidate = CoilCutRun(
                        lanes = lanes + CoilCutLane(listOf(unit)),
                        source = CutMaterialSource.STOCK_SHEET,
                        sourceWidthMm = stockSheet.widthMm,
                        fixedSourceLengthMm = stockSheet.lengthMm,
                        stockSheetId = stockSheet.id
                    )
                    if (
                        candidate.usedWidthMm <= stockSheet.widthMm &&
                        candidate.lanes.size <= MAX_LANES_PER_RUN &&
                        candidate.longitudinalKnifeCount <= MAX_LONGITUDINAL_KNIVES
                    ) {
                        lanes += CoilCutLane(listOf(unit))
                    }
                }
            }
            lanes
        }.maxWithOrNull(
            compareBy<List<CoilCutLane>> { lanes -> lanes.sumOf { it.netAreaM2 } }
                .thenBy { lanes -> lanes.sumOf { lane -> lane.units.size } }
                .thenBy { lanes -> lanes.sumOf { it.widthMm } }
        ).orEmpty()
        if (bestLanes.isEmpty()) return null
        return CoilCutRun(
            lanes = sortedLanes(bestLanes),
            source = CutMaterialSource.STOCK_SHEET,
            sourceWidthMm = stockSheet.widthMm,
            fixedSourceLengthMm = stockSheet.lengthMm,
            stockSheetId = stockSheet.id
        )
    }

    private fun optimizeRuns(units: List<CoilCutUnit>, coilWidthMm: Int): List<CoilCutRun> {
        if (units.isEmpty()) return emptyList()
        return candidateOrders(units).map { pack(it, coilWidthMm) }
            .minWithOrNull(
                compareBy<List<CoilCutRun>> { candidate -> candidate.sumOf { it.lengthMm } }
                    .thenBy { candidate -> candidate.sumOf { it.grossAreaM2 - it.netAreaM2 } }
                    .thenBy { it.size }
            ).orEmpty()
    }

    private fun candidateOrders(units: List<CoilCutUnit>): List<List<CoilCutUnit>> = listOf(
        units.sortedWith(compareByDescending<CoilCutUnit> { it.lengthMm }.thenByDescending { it.widthMm }),
        units.sortedWith(compareByDescending<CoilCutUnit> { it.widthMm }.thenByDescending { it.lengthMm }),
        units.sortedWith(
            compareByDescending<CoilCutUnit> { it.widthMm.toLong() * it.lengthMm }
                .thenByDescending { it.lengthMm }
        ),
        units.sortedWith(
            compareByDescending<CoilCutUnit> { max(it.widthMm, it.lengthMm) }
                .thenByDescending { it.widthMm }
        )
    )

    private fun pack(orderedUnits: List<CoilCutUnit>, coilWidthMm: Int): List<CoilCutRun> {
        val runs = mutableListOf<CoilCutRun>()
        orderedUnits.forEach { unit ->
            val standaloneRun = CoilCutRun(
                lanes = listOf(CoilCutLane(listOf(unit))),
                source = CutMaterialSource.NEW_COIL,
                sourceWidthMm = coilWidthMm
            )
            val placements = mutableListOf(
                Placement(-1, standaloneRun, placementScore(emptyCoilRun(coilWidthMm), standaloneRun))
            )
            runs.forEachIndexed { runIndex, run ->
                run.lanes.forEachIndexed { laneIndex, lane ->
                    if (lane.widthMm == unit.widthMm) {
                        val updatedLanes = run.lanes.toMutableList().apply {
                            this[laneIndex] = lane.copy(units = lane.units + unit)
                        }
                        val updatedRun = run.copy(lanes = updatedLanes)
                        placements += Placement(runIndex, updatedRun, placementScore(run, updatedRun))
                    }
                }
                val newLaneRun = run.copy(lanes = run.lanes + CoilCutLane(listOf(unit)))
                if (
                    newLaneRun.lanes.size <= MAX_LANES_PER_RUN &&
                    newLaneRun.usedWidthMm <= coilWidthMm &&
                    newLaneRun.longitudinalKnifeCount <= MAX_LONGITUDINAL_KNIVES
                ) {
                    placements += Placement(runIndex, newLaneRun, placementScore(run, newLaneRun))
                }
            }
            val best = placements.minBy { it.score }
            if (best.runIndex < 0) runs += standaloneRun else runs[best.runIndex] = best.updatedRun
        }
        return runs.map { it.copy(lanes = sortedLanes(it.lanes)) }
    }

    private fun emptyCoilRun(widthMm: Int) = CoilCutRun(
        lanes = emptyList(),
        source = CutMaterialSource.NEW_COIL,
        sourceWidthMm = widthMm
    )

    private fun sortedLanes(lanes: List<CoilCutLane>) = lanes.sortedWith(
        compareByDescending<CoilCutLane> { it.widthMm }.thenByDescending { it.lengthMm }
    )

    private fun placementScore(oldRun: CoilCutRun, newRun: CoilCutRun): Double {
        val remainingWidth = newRun.sourceWidthMm - newRun.usedWidthMm
        val laneImbalance = newRun.lanes.sumOf { newRun.lengthMm - it.lengthMm }
        return (newRun.lengthMm - oldRun.lengthMm).toDouble() * newRun.sourceWidthMm +
            remainingWidth * 0.05 + laneImbalance * 0.20
    }

    private fun validatePlan(materialPlans: List<CoilMaterialPlan>, expectedUnits: Int) {
        val plannedUnits = materialPlans.sumOf { material ->
            material.runs.sumOf { run -> run.units.size }
        }
        check(plannedUnits == expectedUnits) {
            "Kontrola delenia zlyhala: počet naplánovaných kusov nesúhlasí."
        }
        materialPlans.flatMap { it.runs }.forEach { run ->
            check(run.usedWidthMm <= run.sourceWidthMm) {
                "Kontrola delenia zlyhala: prekročená šírka zdrojového plechu."
            }
            check(run.occupiedLengthMm <= run.lengthMm) {
                "Kontrola delenia zlyhala: prekročená dĺžka skladového plechu."
            }
            check(run.longitudinalKnifeCount <= MAX_LONGITUDINAL_KNIVES) {
                "Kontrola delenia zlyhala: prekročený počet pozdĺžnych nožov."
            }
        }
    }

    private fun validateCosts(
        materialPlans: List<CoilMaterialPlan>,
        costs: List<CoilProductCost>,
        drawings: List<DrawingRecord>
    ) {
        val expectedBendingMeters = drawings.sumOf { drawing ->
            val bends = calculateMetrics(drawing).bends
            drawing.profileLengthM * drawing.quantity.coerceAtLeast(1) * bends
        }
        val itemBendingMeters = costs.sumOf { it.bendingMeters }
        assertClose("SUM(mOHYB položiek) = celkové metre ohybov", itemBendingMeters, expectedBendingMeters)

        val itemBendingCost = costs.sumOf { it.bendingCostEur }
        val expectedBendingCost = costs.sumOf {
            it.bendingMeters * it.lengthTier.priceEurPerM
        }
        assertClose("SUM(cena ohýbania položiek) = ohýbanie spolu", itemBendingCost, expectedBendingCost)

        val planLongitudinal = materialPlans.sumOf { it.longitudinalCutMeters }
        val planTransverse = materialPlans.sumOf { it.transverseCutMeters }
        val itemLongitudinal = costs.sumOf { it.longitudinalCutMeters }
        val itemTransverse = costs.sumOf { it.transverseCutMeters }
        assertClose("Pozdĺžne rezanie položiek = plán", itemLongitudinal, planLongitudinal)
        assertClose("Priečne rezanie položiek = plán", itemTransverse, planTransverse)
        assertClose(
            "SUM(mREZ položiek) = pozdĺžne + priečne rezanie",
            costs.sumOf { it.cuttingMeters },
            planLongitudinal + planTransverse
        )

        val itemCuttingCost = costs.sumOf { it.cuttingCostEur }
        assertClose(
            "SUM(cena rezania položiek) = rezanie spolu",
            itemCuttingCost,
            (planLongitudinal + planTransverse) * CUTTING_PRICE_EUR_PER_M
        )
        assertClose(
            "SUM(výroba spolu položiek) = ohýbanie spolu + rezanie spolu",
            costs.sumOf { it.productionCostEur },
            itemBendingCost + itemCuttingCost
        )

        val planMaterialCost = materialPlans.sumOf { it.materialPriceEur }
        val itemMaterialCost = costs.sumOf { it.allocatedMaterialCostEur }
        assertClose("SUM(cena plechu položiek) = cena plechu plánu", itemMaterialCost, planMaterialCost)
        assertClose(
            "SUM(celkových cien výrobkov) = plech + ohýbanie + rezanie",
            costs.sumOf { it.totalCostEur },
            planMaterialCost + itemBendingCost + itemCuttingCost
        )
    }

    private fun assertClose(label: String, actual: Double, expected: Double) {
        val tolerance = 1e-7 * max(1.0, abs(expected))
        check(abs(actual - expected) <= tolerance) {
            "Kontrola kalkulácie zlyhala: $label (výsledok $actual, očakávané $expected)."
        }
    }

    private data class Placement(
        val runIndex: Int,
        val updatedRun: CoilCutRun,
        val score: Double
    )
}
