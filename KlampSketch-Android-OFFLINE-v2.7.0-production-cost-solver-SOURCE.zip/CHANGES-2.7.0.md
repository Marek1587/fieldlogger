# KlampSketch 2.7.0

- Opravená cena ohýbania: `mOHYB = dĺžka profilu × počet kusov × počet ohybov`.
- Cena ohýbania sa počíta z mOHYB, nikdy iba z mPROF.
- Zachované sú štyri samostatné kategórie: 0-1,00 m; nad 1,00 až menej ako 2,00 m; 2,00-4,00 m; nad 4,00 m.
- Sadzba je 0,77 €/m ohybu pre profily kratšie ako 2,00 m a 0,72 €/m ohybu od 2,00 m vrátane.
- Pozdĺžne a priečne rezanie sa každému výrobku prideľuje z jeho skutočného umiestnenia v optimalizovanom pláne.
- Položkové metre rezania sa kontrolujú proti fyzickým rezom všetkých zostáv.
- Cena plechu vrátane odpadu zostavy sa alokuje výrobkom pomerne podľa ich plochy v danej zostave.
- Kontrolná správa uvádza pri každom výrobku ks, dĺžku, kategóriu, ohyby, mPROF, mOHYB, sadzbu, ohýbanie, mREZ, rezanie a výrobu.
- Pri každom výrobku je cena za kus aj cena všetkých kusov vrátane plechu, ohýbania a rezania.
- Súhrn vždy obsahuje všetky štyri dĺžkové kategórie a samostatné pozdĺžne/priečne rezanie.
- Runtime validácie kontrolujú všetky požadované položkové a celkové súčty.
- Automatický referenčný test KL-00011 overuje 6,70 mPROF, 46,90 mOHYB a 33,77 € za ohýbanie.
- Optimalizačný algoritmus rozmiestnenia výrobkov na plech nebol zmenený.
- APK je podpísané rovnakým trvalým aktualizačným kľúčom ako verzia 2.6.0.
