package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SolvedRoofSurfaceGeometryTest {
    @Test
    fun canonicalSurfaceUsesSolvedGraphBoundaryAndExcludesInternalLines() {
        val graph = RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = linkedMapOf(
                // Deliberately stale Z values: the solved face plane is normative.
                "n0" to GraphNode("n0", 0.0, 0.0, -4.0),
                "n1" to GraphNode("n1", 8.0, 0.0, -4.0),
                "n2" to GraphNode("n2", 8.0, 5.0, -4.0),
                "n3" to GraphNode("n3", 0.0, 5.0, -4.0),
                "r0" to GraphNode("r0", 4.0, 1.0, 6.0),
                "r1" to GraphNode("r1", 4.0, 4.0, 6.0)
            ),
            edges = linkedMapOf(
                "e0" to GraphEdge("e0", "n0", "n1", true, EdgeSemantic.EAVE),
                "e1" to GraphEdge("e1", "n1", "n2", true, EdgeSemantic.GABLE),
                "e2" to GraphEdge("e2", "n2", "n3", true, EdgeSemantic.EAVE),
                "e3" to GraphEdge("e3", "n3", "n0", true, EdgeSemantic.GABLE),
                "ridge" to GraphEdge("ridge", "r0", "r1", false, EdgeSemantic.RIDGE)
            ),
            faces = linkedMapOf(
                "face" to GraphFace(
                    id = "face",
                    orderedNodeIds = listOf("n0", "n1", "n2", "n3"),
                    orderedEdgeIds = listOf("e0", "e1", "e2", "e3"),
                    signedAreaM2 = 40.0,
                    plane = RoofPlane(0.1, 0.2, 5.0)
                )
            )
        )

        val surface = SolvedRoofSurfaceGeometry.from(graph)

        assertNotNull(surface)
        surface!!
        assertEquals(setOf("n0", "n1", "n2", "n3"), surface.nodeIds.toSet())
        assertEquals(setOf("e0", "e1", "e2", "e3"), surface.edges.map { it.id }.toSet())
        assertTrue(surface.edges.all { it.boundary })
        assertEquals(4, surface.boundary.size)
        assertEquals(listOf(5.0, 5.8, 6.8, 6.0), surface.topBoundary.map { it.z })
    }

    @Test
    fun visiblePerimeterUsesThePlaneOwningEachExactBoundaryEdge() {
        val graph = RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = linkedMapOf(
                "n0" to GraphNode("n0", 0.0, 0.0, -10.0),
                "n1" to GraphNode("n1", 6.0, 0.0, -10.0),
                "n2" to GraphNode("n2", 6.0, 4.0, -10.0),
                "n3" to GraphNode("n3", 0.0, 4.0, -10.0)
            ),
            edges = linkedMapOf(
                "e0" to GraphEdge(
                    "e0", "n0", "n1", true, EdgeSemantic.EAVE,
                    adjacentFaceIds = setOf("low-face")
                ),
                "e1" to GraphEdge(
                    "e1", "n1", "n2", true, EdgeSemantic.GABLE,
                    adjacentFaceIds = setOf("high-face")
                ),
                "e2" to GraphEdge(
                    "e2", "n2", "n3", true, EdgeSemantic.EAVE,
                    adjacentFaceIds = setOf("high-face")
                ),
                "e3" to GraphEdge(
                    "e3", "n3", "n0", true, EdgeSemantic.GABLE,
                    adjacentFaceIds = setOf("low-face")
                )
            ),
            faces = linkedMapOf(
                "low-face" to GraphFace(
                    id = "low-face",
                    orderedNodeIds = listOf("n0", "n1", "n3"),
                    orderedEdgeIds = listOf("e0", "e3"),
                    signedAreaM2 = 12.0,
                    plane = RoofPlane(0.0, 0.0, 5.0)
                ),
                "high-face" to GraphFace(
                    id = "high-face",
                    orderedNodeIds = listOf("n1", "n2", "n3"),
                    orderedEdgeIds = listOf("e1", "e2"),
                    signedAreaM2 = 12.0,
                    plane = RoofPlane(0.0, 0.0, 8.0)
                )
            )
        )

        val surface = SolvedRoofSurfaceGeometry.from(graph)

        assertNotNull(surface)
        val segmentsByEdge = surface!!.edges.mapIndexed { index, edge ->
            edge.id to surface.topEdgeSegments[index]
        }.toMap()
        assertEquals(listOf(5.0, 5.0), segmentsByEdge.getValue("e0").toList().map { it.z })
        assertEquals(listOf(8.0, 8.0), segmentsByEdge.getValue("e1").toList().map { it.z })
        assertEquals(listOf(8.0, 8.0), segmentsByEdge.getValue("e2").toList().map { it.z })
        assertEquals(listOf(5.0, 5.0), segmentsByEdge.getValue("e3").toList().map { it.z })
    }

    @Test
    fun structuralComponentPriorityOwnsBoundaryInsteadOfAlphabeticalFaceId() {
        val nodes = linkedMapOf(
            "n0" to GraphNode("n0", 0.0, 0.0, -20.0),
            "n1" to GraphNode("n1", 5.0, 0.0, -20.0),
            "n2" to GraphNode("n2", 5.0, 3.0, -20.0),
            "n3" to GraphNode("n3", 0.0, 3.0, -20.0)
        )
        val edges = linkedMapOf(
            "e0" to GraphEdge("e0", "n0", "n1", true, EdgeSemantic.EAVE),
            "e1" to GraphEdge("e1", "n1", "n2", true, EdgeSemantic.GABLE),
            "e2" to GraphEdge("e2", "n2", "n3", true, EdgeSemantic.EAVE),
            "e3" to GraphEdge("e3", "n3", "n0", true, EdgeSemantic.GABLE)
        )
        fun face(id: String, componentId: String, elevation: Double, area: Double) = GraphFace(
            id = id,
            orderedNodeIds = nodes.keys.toList(),
            orderedEdgeIds = edges.keys.toList(),
            signedAreaM2 = area,
            plane = RoofPlane(0.0, 0.0, elevation),
            componentId = componentId
        )
        val graph = RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = nodes,
            edges = edges,
            // The projection is deliberately first, alphabetically smaller and larger.
            // None of those incidental properties may override the structural hierarchy.
            faces = linkedMapOf(
                "aaa-projection" to face("aaa-projection", "projection", 9.0, 90.0),
                "zzz-main" to face("zzz-main", "main", 5.0, 15.0)
            ),
            components = linkedMapOf(
                "main" to RoofComponent("main", "Hlavný strešný trakt"),
                "projection" to RoofComponent("projection", "Výstupok / rizalit", hostFaceId = "zzz-main")
            )
        )

        val surface = requireNotNull(SolvedRoofSurfaceGeometry.from(graph))

        assertTrue(surface.sections.all { it.faceId == "zzz-main" })
        assertEquals(listOf(5.0, 5.0, 5.0, 5.0), surface.topBoundary.map { it.z })
        assertTrue(
            surface.topEdgeSegments
                .flatMap { (start, end) -> listOf(start, end) }
                .all { it.z == 5.0 }
        )
    }

    @Test
    fun internalRoofLineIsLiftedFromIncidentPlanesInsteadOfStoredNodeZ() {
        val graph = RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = linkedMapOf(
                "s0" to GraphNode("s0", 2.0, 0.0, -50.0),
                "s1" to GraphNode("s1", 2.0, 4.0, 80.0),
                "l" to GraphNode("l", 0.0, 2.0, 0.0),
                "r" to GraphNode("r", 4.0, 2.0, 0.0)
            ),
            edges = linkedMapOf(
                "ridge" to GraphEdge(
                    "ridge", "s0", "s1", false, EdgeSemantic.RIDGE,
                    adjacentFaceIds = setOf("left", "right")
                )
            ),
            faces = linkedMapOf(
                "left" to GraphFace(
                    "left", listOf("s0", "s1", "l"), listOf("ridge"), 4.0,
                    plane = RoofPlane(0.0, 0.25, 6.0)
                ),
                "right" to GraphFace(
                    "right", listOf("s1", "s0", "r"), listOf("ridge"), 4.0,
                    plane = RoofPlane(0.0, 0.25, 6.0)
                )
            )
        )

        val segment = requireNotNull(
            SolvedRoofSurfaceGeometry.solvedEdgeSegment(graph, graph.edges.getValue("ridge"))
        )

        assertEquals(6.0, segment.first.z, 1e-9)
        assertEquals(7.0, segment.second.z, 1e-9)
    }

    @Test
    fun atticCrownUsesSolvedAnthraciteSectionsInsteadOfStaleBoundaryNodes() {
        val nodes = linkedMapOf(
            "a" to GraphNode("a", 0.0, 0.0, 91.0),
            "b" to GraphNode("b", 6.0, 0.0, 92.0),
            "c" to GraphNode("c", 6.0, 4.0, 93.0),
            "d" to GraphNode("d", 0.0, 4.0, 94.0)
        )
        val edges = linkedMapOf(
            "attic" to GraphEdge("attic", "a", "b", true, EdgeSemantic.ATTIC, setOf("face")),
            "right" to GraphEdge("right", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
            "high" to GraphEdge("high", "c", "d", true, EdgeSemantic.GABLE, setOf("face")),
            "left" to GraphEdge("left", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
        )
        val face = GraphFace(
            "face", nodes.keys.toList(), edges.keys.toList(), 24.0,
            plane = RoofPlane(0.0, 0.25, 4.0)
        )
        val surface = requireNotNull(SolvedRoofSurfaceGeometry.from(
            RoofGraph(GeoPoint(48.0, 18.0), nodes, edges, mapOf(face.id to face))
        ))

        val section = requireNotNull(surface.section("attic"))
        assertEquals(4.0, section.topA.z, 1e-9)
        assertEquals(4.0, section.topB.z, 1e-9)
        assertEquals(4.3, surface.atticCrownZ(0.3)!!, 1e-9)
    }
}
