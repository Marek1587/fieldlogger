package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.roundToLong

/**
 * One authoritative correction pass for the authored internal roof network.
 *
 * The persisted project grid is the only angle reference:
 *  - RIDGE uses one grid axis and the centreline of its structural part,
 *  - HIP and VALLEY use one of the two exact grid diagonals,
 *  - the physical outline keeps its existing edge directions.
 *
 * Several authored endpoint IDs may represent one physical junction. They stay in the
 * inventory (no line/node is deleted or reconnected), but a complete-linkage alias group is
 * solved as one coordinate. Existing outline nodes may participate in the same solve, on a
 * 50 mm lattice and within [MAX_BOUNDARY_SHIFT_M]. Internal coordinates use a 25 mm lattice.
 */
object HierarchicalInternalLineSolver {
    const val MAX_BOUNDARY_SHIFT_M = 0.30
    private const val STEP_M = 0.025
    private const val BOUNDARY_CELL_MULTIPLE = 2L
    private const val JUNCTION_TOLERANCE_M = 0.35
    private const val EPS = 1e-8

    private enum class Direction { HORIZONTAL, VERTICAL, DIAGONAL_UP, DIAGONAL_DOWN }

    private data class Cell(val u: Long, val v: Long)
    private data class GridLine(val a: Long, val b: Long, val c: Long)
    private data class Relation(
        val first: String,
        val second: String,
        val direction: Direction,
        val sourceEdgeId: String?
    )
    private data class FixedLine(val clusterId: String, val line: GridLine, val reason: String)
    private data class RidgeFrame(
        val direction: Direction,
        val centreCell: Long,
        val partId: String
    )

    fun solve(
        input: RoofTopology,
        footprintContext: WallFootprintSolver.Context? = null,
        junctionToleranceM: Double = JUNCTION_TOLERANCE_M,
        maximumBoundaryShiftM: Double = MAX_BOUNDARY_SHIFT_M
    ): RoofSolverPreview {
        val original = input.deepCopyForInternalSolver()
        val internalEdges = input.edges.filterNot { it.boundary }
        if (internalEdges.isEmpty()) {
            return RoofSolverPreview(
                original = original,
                proposed = original.deepCopyForInternalSolver(),
                statistics = RoofSolverStatistics(),
                movements = emptyList(),
                issues = emptyList(),
                faces = RoofTopologySolver.extractFaces(original)
            )
        }

        val rotation = MetricPlanGrid.axisDeg(input) ?: 0.0
        val radians = Math.toRadians(rotation)
        val cosine = kotlin.math.cos(radians)
        val sine = kotlin.math.sin(radians)
        val nodesById = input.nodes.associateBy { it.id }
        val boundaryIds = input.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val structuralTypes = setOf(LineType.RIDGE, LineType.HIP, LineType.VALLEY)
        val internalAt = mutableMapOf<String, MutableList<TopologyEdge>>()
        input.edges.filterNot { it.boundary }.forEach { edge ->
            internalAt.getOrPut(edge.startNodeId) { mutableListOf() } += edge
            internalAt.getOrPut(edge.endNodeId) { mutableListOf() } += edge
        }

        fun toContinuousCell(x: Double, y: Double): Pair<Double, Double> =
            ((x * cosine + y * sine) / STEP_M) to ((-x * sine + y * cosine) / STEP_M)

        fun toCell(node: TopologyNode): Cell {
            val (u, v) = toContinuousCell(node.x, node.y)
            return if (node.id in boundaryIds) {
                Cell(roundToMultiple(u, BOUNDARY_CELL_MULTIPLE), roundToMultiple(v, BOUNDARY_CELL_MULTIPLE))
            } else Cell(u.roundToLong(), v.roundToLong())
        }

        fun fromCell(cell: Cell): LocalPoint = LocalPoint(
            x = clean(cell.u * STEP_M * cosine - cell.v * STEP_M * sine),
            y = clean(cell.u * STEP_M * sine + cell.v * STEP_M * cosine)
        )

        fun contextPoint(x: Double, y: Double): LocalPoint? {
            val context = footprintContext ?: return null
            val geo = Geometry.toGeo(LocalPoint(x, y), input.origin)
            return Geometry.toLocal(geo, context.origin)
        }

        /*
         * Complete-linkage alias groups. This deliberately keeps every authored ID. Exact
         * coordinate aliases are interpreted as one physical junction by the disposable
         * incidence graph used for validation/3D.
         */
        val parent = input.nodes.associate { it.id to it.id }.toMutableMap()
        val members = input.nodes.associate { it.id to mutableSetOf(it.id) }.toMutableMap()
        fun root(id: String): String {
            var current = id
            while (parent.getValue(current) != current) current = parent.getValue(current)
            var cursor = id
            while (parent.getValue(cursor) != cursor) {
                val next = parent.getValue(cursor)
                parent[cursor] = current
                cursor = next
            }
            return current
        }
        fun membersOf(id: String): Set<String> = members.getValue(root(id))
        fun canJoin(firstId: String, secondId: String): Boolean {
            val first = membersOf(firstId)
            val second = membersOf(secondId)
            if (first == second) return false
            if (first.any { it in boundaryIds } && second.any { it in boundaryIds }) return false
            val merged = first + second
            val mergedNodes = merged.mapNotNull(nodesById::get)
            for (i in mergedNodes.indices) for (j in i + 1 until mergedNodes.size) {
                if (hypot(
                        mergedNodes[i].x - mergedNodes[j].x,
                        mergedNodes[i].y - mergedNodes[j].y
                    ) > junctionToleranceM + EPS
                ) return false
            }
            val locked = mergedNodes.filter { it.locked }
            if (locked.size > 1 && locked.drop(1).any {
                    hypot(it.x - locked.first().x, it.y - locked.first().y) > EPS
                }
            ) return false
            val directlyConnected = input.edges.any { edge ->
                (edge.startNodeId in first && edge.endNodeId in second) ||
                    (edge.startNodeId in second && edge.endNodeId in first)
            }
            if (directlyConnected) return false
            if (footprintContext != null) {
                val a = mergedNodes.firstOrNull()?.let { contextPoint(it.x, it.y) }
                val b = mergedNodes.lastOrNull()?.let { contextPoint(it.x, it.y) }
                if (a != null && b != null &&
                    !footprintContext.sameStructuralPart(a.x, a.y, b.x, b.y)
                ) return false
            }
            return true
        }
        fun join(firstId: String, secondId: String) {
            val firstRoot = root(firstId)
            val secondRoot = root(secondId)
            if (firstRoot == secondRoot) return
            val keep = minOf(firstRoot, secondRoot)
            val drop = maxOf(firstRoot, secondRoot)
            parent[drop] = keep
            members.getValue(keep) += members.getValue(drop)
            members.remove(drop)
        }

        val eligible = input.nodes.filter { node ->
            internalAt[node.id].orEmpty().any { it.type in structuralTypes }
        }.sortedBy { it.id }
        buildList {
            for (i in eligible.indices) for (j in i + 1 until eligible.size) {
                val distance = hypot(eligible[i].x - eligible[j].x, eligible[i].y - eligible[j].y)
                if (distance <= junctionToleranceM + EPS) add(Triple(distance, eligible[i].id, eligible[j].id))
            }
        }.sortedWith(compareBy<Triple<Double, String, String>> { it.first }
            .thenBy { it.second }.thenBy { it.third })
            .forEach { (_, first, second) -> if (canJoin(first, second)) join(first, second) }

        val clusterByNode = input.nodes.associate { it.id to root(it.id) }
        val clusterMembers = input.nodes.groupBy { clusterByNode.getValue(it.id) }
        val originalCellByNode = input.nodes.associate { it.id to toCell(it) }
        val points = clusterMembers.mapValues { (_, grouped) ->
            val locked = grouped.firstOrNull { it.locked }
            if (locked != null) originalCellByNode.getValue(locked.id)
            else {
                val averageU = grouped.map { originalCellByNode.getValue(it.id).u }.average()
                val averageV = grouped.map { originalCellByNode.getValue(it.id).v }.average()
                if (grouped.any { it.id in boundaryIds }) Cell(
                    roundToMultiple(averageU, BOUNDARY_CELL_MULTIPLE),
                    roundToMultiple(averageV, BOUNDARY_CELL_MULTIPLE)
                ) else Cell(averageU.roundToLong(), averageV.roundToLong())
            }
        }.toMutableMap()

        fun rawDirection(edge: TopologyEdge): Pair<Double, Double> {
            val a = nodesById.getValue(edge.startNodeId)
            val b = nodesById.getValue(edge.endNodeId)
            val first = toContinuousCell(a.x, a.y)
            val second = toContinuousCell(b.x, b.y)
            return (second.first - first.first) to (second.second - first.second)
        }

        fun nearestDirection(edge: TopologyEdge, permitted: List<Direction>): Direction {
            val (du, dv) = rawDirection(edge)
            return permitted.minWith(compareBy<Direction> { directionResidual(du, dv, it) }.thenBy { it.ordinal })
        }

        fun ridgeOwner(edge: TopologyEdge): WallFootprintSolver.Context.LocalPart? {
            val context = footprintContext ?: return null
            val a = nodesById[edge.startNodeId] ?: return null
            val b = nodesById[edge.endNodeId] ?: return null
            val scores = mutableMapOf<String, Int>()
            for (index in 0..10) {
                val t = index / 10.0
                val sample = contextPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t) ?: continue
                context.partsAt(sample.x, sample.y)
                    .filter { it.type != WallFootprintPartType.SUPERSTRUCTURE }
                    .forEach { part -> scores[part.id] = (scores[part.id] ?: 0) + 1 }
            }
            return context.parts.asSequence()
                .filter { it.type != WallFootprintPartType.SUPERSTRUCTURE && (scores[it.id] ?: 0) > 0 }
                .sortedWith(compareByDescending<WallFootprintSolver.Context.LocalPart> { scores[it.id] ?: 0 }
                    .thenBy { context.priorityOf(it.type) }
                    .thenByDescending { it.areaM2 }
                    .thenBy { it.id })
                .firstOrNull()
        }

        fun ridgeFrame(edge: TopologyEdge): RidgeFrame? {
            val context = footprintContext ?: return null
            val part = ridgeOwner(edge) ?: return null
            val cells = part.polygon.map { point ->
                val geo = Geometry.toGeo(point, context.origin)
                val local = Geometry.toLocal(geo, input.origin)
                toContinuousCell(local.x, local.y)
            }
            if (cells.size < 3) return null
            val minU = cells.minOf { it.first }
            val maxU = cells.maxOf { it.first }
            val minV = cells.minOf { it.second }
            val maxV = cells.maxOf { it.second }
            val spanU = maxU - minU
            val spanV = maxV - minV
            val nearest = nearestDirection(edge, listOf(Direction.HORIZONTAL, Direction.VERTICAL))
            val direction = when {
                spanU > spanV + 1.0 -> Direction.HORIZONTAL
                spanV > spanU + 1.0 -> Direction.VERTICAL
                else -> nearest
            }
            val centre = if (direction == Direction.HORIZONTAL) {
                ((minV + maxV) / 2.0).roundToLong()
            } else ((minU + maxU) / 2.0).roundToLong()
            return RidgeFrame(direction, centre, part.id)
        }

        val edgeDirections = mutableMapOf<String, Direction>()
        val fixed = mutableListOf<FixedLine>()
        input.edges.forEach { edge ->
            val direction = when {
                edge.boundary -> nearestDirection(edge, Direction.entries)
                edge.type == LineType.RIDGE -> ridgeFrame(edge)?.direction
                    ?: nearestDirection(edge, listOf(Direction.HORIZONTAL, Direction.VERTICAL))
                edge.type == LineType.HIP || edge.type == LineType.VALLEY ->
                    nearestDirection(edge, listOf(Direction.DIAGONAL_UP, Direction.DIAGONAL_DOWN))
                else -> nearestDirection(edge, Direction.entries)
            }
            edgeDirections[edge.id] = direction
            if (!edge.boundary && edge.type == LineType.RIDGE) {
                ridgeFrame(edge)?.let { frame ->
                    val line = if (frame.direction == Direction.HORIZONTAL) {
                        GridLine(0L, 1L, frame.centreCell)
                    } else GridLine(1L, 0L, frame.centreCell)
                    fixed += FixedLine(clusterByNode.getValue(edge.startNodeId), line, "RIDGE_CENTRE_${frame.partId}")
                    fixed += FixedLine(clusterByNode.getValue(edge.endNodeId), line, "RIDGE_CENTRE_${frame.partId}")
                }
            }
        }

        val relations = input.edges.mapNotNull { edge ->
            val first = clusterByNode.getValue(edge.startNodeId)
            val second = clusterByNode.getValue(edge.endNodeId)
            if (first == second) null else Relation(first, second, edgeDirections.getValue(edge.id), edge.id)
        }.toMutableList()

        // A free structural end may intentionally terminate on the interior of another
        // structural line. Add a point-on-support relation; the disposable incidence graph will
        // create the virtual split only for face walking, never in the authored inventory.
        internalAt.filterValues { it.size == 1 }.keys.sorted().forEach { nodeId ->
            if (nodeId in boundaryIds) return@forEach
            val node = nodesById[nodeId] ?: return@forEach
            val own = internalAt.getValue(nodeId).single()
            if (own.type !in structuralTypes) return@forEach
            val candidate = input.edges.asSequence()
                .filter { it.id != own.id && !it.boundary && it.type in structuralTypes }
                .filter { nodeId != it.startNodeId && nodeId != it.endNodeId }
                .mapNotNull { target ->
                    val a = nodesById[target.startNodeId] ?: return@mapNotNull null
                    val b = nodesById[target.endNodeId] ?: return@mapNotNull null
                    val projection = projectToSegment(node.x, node.y, a.x, a.y, b.x, b.y)
                    if (projection.third !in 0.02..0.98) return@mapNotNull null
                    val distance = hypot(node.x - projection.first, node.y - projection.second)
                    if (distance > junctionToleranceM + EPS) return@mapNotNull null
                    Triple(target, distance, projection.third)
                }.sortedWith(compareBy<Triple<TopologyEdge, Double, Double>> { it.second }
                    .thenBy { it.first.id })
                .firstOrNull() ?: return@forEach
            val target = candidate.first
            val freeCluster = clusterByNode.getValue(nodeId)
            val targetCluster = clusterByNode.getValue(target.startNodeId)
            if (freeCluster != targetCluster) {
                relations += Relation(freeCluster, targetCluster, edgeDirections.getValue(target.id), null)
            }
        }

        val fixedByCluster = fixed.groupBy { it.clusterId }
        val relationsByCluster = mutableMapOf<String, MutableList<Relation>>()
        relations.forEach { relation ->
            relationsByCluster.getOrPut(relation.first) { mutableListOf() } += relation
            relationsByCluster.getOrPut(relation.second) { mutableListOf() } += relation
        }

        fun lineAt(relation: Relation, forCluster: String): GridLine {
            val otherId = if (relation.first == forCluster) relation.second else relation.first
            val other = points.getValue(otherId)
            return when (relation.direction) {
                Direction.HORIZONTAL -> GridLine(0L, 1L, other.v)
                Direction.VERTICAL -> GridLine(1L, 0L, other.u)
                Direction.DIAGONAL_UP -> GridLine(-1L, 1L, other.v - other.u)
                Direction.DIAGONAL_DOWN -> GridLine(1L, 1L, other.v + other.u)
            }
        }

        fun pointAllowed(clusterId: String, cell: Cell): Boolean {
            val grouped = clusterMembers.getValue(clusterId)
            val local = fromCell(cell)
            if (grouped.any { it.id in boundaryIds } &&
                (cell.u % BOUNDARY_CELL_MULTIPLE != 0L || cell.v % BOUNDARY_CELL_MULTIPLE != 0L)
            ) return false
            grouped.filter { it.locked }.forEach { locked ->
                if (hypot(local.x - locked.x, local.y - locked.y) > EPS) return false
            }
            grouped.filter { it.id in boundaryIds }.forEach { boundary ->
                if (hypot(local.x - boundary.x, local.y - boundary.y) > maximumBoundaryShiftM + EPS) return false
            }
            return true
        }

        fun displacementCost(clusterId: String, cell: Cell): Double {
            val local = fromCell(cell)
            return clusterMembers.getValue(clusterId).sumOf { source ->
                val dx = local.x - source.x
                val dy = local.y - source.y
                val weight = if (source.id in boundaryIds) 10_000.0 else 1.0
                (dx * dx + dy * dy) * weight
            }
        }

        fun candidates(clusterId: String, lines: List<GridLine>): Set<Cell> {
            val result = linkedSetOf<Cell>()
            val current = points.getValue(clusterId)
            val originals = clusterMembers.getValue(clusterId).map { originalCellByNode.getValue(it.id) }
            val boundary = clusterMembers.getValue(clusterId).any { it.id in boundaryIds }
            fun addAround(u: Double, v: Double, radius: Int = 2) {
                if (!u.isFinite() || !v.isFinite()) return
                val baseUs = setOf(floor(u).toLong(), ceil(u).toLong(), u.roundToLong())
                val baseVs = setOf(floor(v).toLong(), ceil(v).toLong(), v.roundToLong())
                baseUs.forEach { baseU -> baseVs.forEach { baseV ->
                    for (du in -radius..radius) for (dv in -radius..radius) {
                        var nextU = baseU + du
                        var nextV = baseV + dv
                        if (boundary) {
                            nextU = roundToMultiple(nextU.toDouble(), BOUNDARY_CELL_MULTIPLE)
                            nextV = roundToMultiple(nextV.toDouble(), BOUNDARY_CELL_MULTIPLE)
                        }
                        result += Cell(nextU, nextV)
                    }
                } }
            }
            addAround(current.u.toDouble(), current.v.toDouble(), 1)
            originals.forEach { addAround(it.u.toDouble(), it.v.toDouble(), 1) }
            lines.forEach { line ->
                val denominator = (line.a * line.a + line.b * line.b).toDouble()
                val residual = line.a * current.u + line.b * current.v - line.c
                addAround(
                    current.u - line.a * residual / denominator,
                    current.v - line.b * residual / denominator
                )
            }
            for (i in lines.indices) for (j in i + 1 until lines.size) {
                val determinant = lines[i].a * lines[j].b - lines[j].a * lines[i].b
                if (determinant == 0L) continue
                addAround(
                    (lines[i].c * lines[j].b - lines[j].c * lines[i].b).toDouble() / determinant,
                    (lines[i].a * lines[j].c - lines[j].a * lines[i].c).toDouble() / determinant
                )
            }
            return result.filterTo(linkedSetOf()) { pointAllowed(clusterId, it) }
        }

        val order = points.keys.sortedWith(compareByDescending<String> {
            relationsByCluster[it].orEmpty().size + fixedByCluster[it].orEmpty().size * 2
        }.thenBy { clusterMembers.getValue(it).any { node -> node.id in boundaryIds } }.thenBy { it })

        repeat(160) { iteration ->
            var changed = false
            val pass = if (iteration % 2 == 0) order else order.asReversed()
            pass.forEach { clusterId ->
                val lines = buildList {
                    addAll(fixedByCluster[clusterId].orEmpty().map { it.line })
                    addAll(relationsByCluster[clusterId].orEmpty().map { lineAt(it, clusterId) })
                }
                if (lines.isEmpty()) return@forEach
                val best = candidates(clusterId, lines).minWithOrNull(
                    compareBy<Cell> { candidate ->
                        lines.sumOf { line ->
                            val residual = line.a * candidate.u + line.b * candidate.v - line.c
                            residual.toDouble() * residual.toDouble()
                        }
                    }.thenBy { displacementCost(clusterId, it) }
                        .thenBy { it.u }.thenBy { it.v }
                ) ?: return@forEach
                if (best != points.getValue(clusterId)) {
                    points[clusterId] = best
                    changed = true
                }
            }
            if (!changed) return@repeat
        }

        val constraintFailures = mutableListOf<String>()
        relations.forEach { relation ->
            val first = points.getValue(relation.first)
            val second = points.getValue(relation.second)
            if (relationResidual(first, second, relation.direction) != 0L) {
                constraintFailures += relation.sourceEdgeId ?: "virtual-junction"
            }
        }
        fixed.forEach { item ->
            val point = points.getValue(item.clusterId)
            if (item.line.a * point.u + item.line.b * point.v != item.line.c) {
                constraintFailures += item.reason
            }
        }

        val candidateNodes = input.nodes.map { source ->
            val cell = points.getValue(clusterByNode.getValue(source.id))
            val local = fromCell(cell)
            source.copy(x = local.x, y = local.y)
        }
        val candidate = input.copy(
            origin = input.origin.copy(),
            nodes = candidateNodes,
            edges = input.edges.map { it.copy() },
            gridRotationDeg = rotation
        )
        val boundaryValid = validBoundary(input, candidate, maximumBoundaryShiftM)
        val identityValid = input.nodes.map { it.id } == candidate.nodes.map { it.id } &&
            input.edges == candidate.edges
        val allCellsAllowed = points.all { (clusterId, cell) -> pointAllowed(clusterId, cell) }
        val infeasible = constraintFailures.isNotEmpty() || !boundaryValid || !identityValid || !allCellsAllowed
        if (infeasible) {
            val detail = constraintFailures.distinct().take(5).joinToString()
            val issue = TopologyIssue(
                code = "INTERNAL_CONSTRAINTS_INFEASIBLE",
                message = if (detail.isBlank()) {
                    "Vnútorné línie nemožno presne spojiť bez prekročenia 300 mm limitu obrysu. Návrh sa nezmenil."
                } else {
                    "Presné 45° línie a spoločné uzly sú v konflikte ($detail). Návrh sa nezmenil."
                },
                severity = TopologyIssueSeverity.ERROR,
                edgeIds = constraintFailures.filter { failure -> input.edges.any { it.id == failure } }.distinct()
            )
            return RoofSolverPreview(
                original = original,
                proposed = original.deepCopyForInternalSolver(),
                statistics = RoofSolverStatistics(),
                movements = emptyList(),
                issues = listOf(issue),
                faces = RoofTopologySolver.extractFaces(original)
            )
        }

        val movements = input.nodes.mapNotNull { source ->
            val corrected = candidateNodes.first { it.id == source.id }
            if (hypot(corrected.x - source.x, corrected.y - source.y) <= EPS) null
            else NodeMovement(
                sourceNodeId = source.id,
                targetNodeId = source.id,
                fromX = source.x,
                fromY = source.y,
                toX = corrected.x,
                toY = corrected.y,
                reason = when {
                    source.id in boundaryIds -> "INTERNAL_NETWORK_BOUNDARY_50MM"
                    clusterMembers.getValue(clusterByNode.getValue(source.id)).size > 1 -> "COMMON_ROOF_JUNCTION_25MM"
                    internalAt[source.id].orEmpty().any { it.type == LineType.RIDGE } -> "RIDGE_CENTRE_25MM"
                    else -> "INTERNAL_DIRECTION_25MM"
                }
            )
        }
        val alignedHipValley = input.edges.count { edge ->
            !edge.boundary && edge.type in setOf(LineType.HIP, LineType.VALLEY)
        }
        val alignedRidges = input.edges.count { edge -> !edge.boundary && edge.type == LineType.RIDGE }
        return RoofSolverPreview(
            original = original,
            proposed = candidate,
            statistics = RoofSolverStatistics(
                snappedFreeEnds = clusterMembers.values.sumOf { (it.size - 1).coerceAtLeast(0) },
                regularizedBoundaryNodes = movements.count { it.sourceNodeId in boundaryIds },
                alignedHipValleyNodes = alignedHipValley,
                alignedRidgeNodes = alignedRidges
            ),
            movements = movements,
            issues = emptyList(),
            faces = RoofTopologySolver.extractFaces(candidate)
        )
    }

    private fun relationResidual(first: Cell, second: Cell, direction: Direction): Long = when (direction) {
        Direction.HORIZONTAL -> first.v - second.v
        Direction.VERTICAL -> first.u - second.u
        Direction.DIAGONAL_UP -> (first.v - first.u) - (second.v - second.u)
        Direction.DIAGONAL_DOWN -> (first.v + first.u) - (second.v + second.u)
    }

    private fun directionResidual(du: Double, dv: Double, direction: Direction): Double = when (direction) {
        Direction.HORIZONTAL -> abs(dv)
        Direction.VERTICAL -> abs(du)
        Direction.DIAGONAL_UP -> abs(dv - du) / kotlin.math.sqrt(2.0)
        Direction.DIAGONAL_DOWN -> abs(dv + du) / kotlin.math.sqrt(2.0)
    }

    private fun projectToSegment(
        px: Double,
        py: Double,
        ax: Double,
        ay: Double,
        bx: Double,
        by: Double
    ): Triple<Double, Double, Double> {
        val dx = bx - ax
        val dy = by - ay
        val length2 = dx * dx + dy * dy
        if (length2 <= EPS) return Triple(ax, ay, 0.0)
        val t = (((px - ax) * dx + (py - ay) * dy) / length2).coerceIn(0.0, 1.0)
        return Triple(ax + dx * t, ay + dy * t, t)
    }

    private fun validBoundary(
        original: RoofTopology,
        candidate: RoofTopology,
        maximumBoundaryShiftM: Double
    ): Boolean {
        val originalCycle = RoofTopologyMigration.orderedBoundary(original) ?: return false
        val candidateCycle = RoofTopologyMigration.orderedBoundary(candidate) ?: return false
        if (originalCycle.first != candidateCycle.first || originalCycle.second != candidateCycle.second) return false
        val originalNodes = original.nodes.associateBy { it.id }
        val candidateNodes = candidate.nodes.associateBy { it.id }
        if (originalCycle.first.any { id ->
                val before = originalNodes[id] ?: return@any true
                val after = candidateNodes[id] ?: return@any true
                before.locked && (before.x != after.x || before.y != after.y) ||
                    hypot(after.x - before.x, after.y - before.y) > maximumBoundaryShiftM + EPS
            }
        ) return false
        val before = originalCycle.first.map { originalNodes.getValue(it) }
        val after = candidateCycle.first.map { candidateNodes.getValue(it) }
        val beforeArea = signedArea(before)
        val afterArea = signedArea(after)
        if (abs(beforeArea) <= EPS || abs(afterArea) <= EPS || beforeArea * afterArea <= 0.0) return false
        if (after.indices.any { index ->
                val next = after[(index + 1) % after.size]
                hypot(next.x - after[index].x, next.y - after[index].y) < 0.05 - EPS
            }
        ) return false
        for (i in after.indices) for (j in i + 1 until after.size) {
            if (j == i || j == (i + 1) % after.size || i == (j + 1) % after.size) continue
            val a = after[i]
            val b = after[(i + 1) % after.size]
            val c = after[j]
            val d = after[(j + 1) % after.size]
            if (segmentsProperlyIntersect(a.x, a.y, b.x, b.y, c.x, c.y, d.x, d.y)) return false
        }
        return true
    }

    private fun signedArea(nodes: List<TopologyNode>): Double = nodes.indices.sumOf { index ->
        val next = nodes[(index + 1) % nodes.size]
        nodes[index].x * next.y - next.x * nodes[index].y
    } / 2.0

    private fun segmentsProperlyIntersect(
        ax: Double, ay: Double, bx: Double, by: Double,
        cx: Double, cy: Double, dx: Double, dy: Double
    ): Boolean {
        fun orientation(px: Double, py: Double, qx: Double, qy: Double, rx: Double, ry: Double): Double =
            (qx - px) * (ry - py) - (qy - py) * (rx - px)
        val o1 = orientation(ax, ay, bx, by, cx, cy)
        val o2 = orientation(ax, ay, bx, by, dx, dy)
        val o3 = orientation(cx, cy, dx, dy, ax, ay)
        val o4 = orientation(cx, cy, dx, dy, bx, by)
        return o1 * o2 < -EPS && o3 * o4 < -EPS
    }

    private fun roundToMultiple(value: Double, multiple: Long): Long =
        (value / multiple).roundToLong() * multiple

    private fun clean(value: Double): Double = if (abs(value) < 1e-12) 0.0 else value

    private fun RoofTopology.deepCopyForInternalSolver() = copy(
        origin = origin.copy(),
        nodes = nodes.map { it.copy() },
        edges = edges.map { it.copy() }
    )
}
