package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Canonical plan envelope of the solved anthracite roof surface.
 *
 * Rendering consumers must derive walls, build-up/soffit, outlines and drainage
 * from this object. A saved polygon or wall footprint may describe user input or
 * a measurement reference, but it is never a second physical roof envelope.
 */
internal data class SolvedRoofSurfaceGeometry(
    val nodeIds: List<String>,
    val boundary: List<LocalPoint>,
    val edges: List<GraphEdge>,
    /**
     * The same boundary lifted onto the solved roof planes. GraphNode.z is an
     * input/constraint value and may lag behind a face plane after a solve; it
     * must therefore never be used for the visible roof perimeter.
     */
    val topBoundary: List<GraphNode>,
    /** Exact edge-local sections of the rendered anthracite surface. */
    val sections: List<BoundarySection>
) {
    val roles: List<EdgeSemantic> get() = edges.map { it.semanticRole }
    val topEdgeSegments: List<Pair<GraphNode, GraphNode>>
        get() = sections.map { it.topA to it.topB }

    data class BoundarySection(
        val edge: GraphEdge,
        val faceId: String?,
        val plane: RoofPlane?,
        val topA: GraphNode,
        val topB: GraphNode
    ) {
        fun bottomA(thicknessM: Double) = topA.copy(
            id = "roof-shell-bottom-${edge.id}-a",
            z = topA.z - thicknessM
        )

        fun bottomB(thicknessM: Double) = topB.copy(
            id = "roof-shell-bottom-${edge.id}-b",
            z = topB.z - thicknessM
        )

        fun undersideZAt(point: LocalPoint, thicknessM: Double): Double {
            val top = plane?.zAt(point.x, point.y) ?: run {
                val dx = topB.x - topA.x
                val dy = topB.y - topA.y
                val denominator = dx * dx + dy * dy
                val t = if (denominator <= 1e-12) 0.0 else
                    (((point.x - topA.x) * dx + (point.y - topA.y) * dy) / denominator).coerceIn(0.0, 1.0)
                topA.z + (topB.z - topA.z) * t
            }
            return top - thicknessM
        }
    }

    fun section(edgeId: String): BoundarySection? = sections.firstOrNull { it.edge.id == edgeId }

    /**
     * Finished horizontal parapet crown measured from the actually rendered roof
     * surface. Stored boundary-node Z values are solver inputs and can legitimately
     * lag behind the owning face plane, so they must not create a second parapet
     * datum for 3D, annotations or technical objects.
     */
    fun atticCrownZ(atticHeightM: Double): Double? = sections.asSequence()
        .filter { it.edge.semanticRole == EdgeSemantic.ATTIC }
        .flatMap { sequenceOf(it.topA.z, it.topB.z) }
        .filter(Double::isFinite)
        .maxOrNull()
        ?.plus(atticHeightM.coerceIn(0.1, 3.0))

    companion object {
        /**
         * Selects the physical owner of a solved surface fragment. This is the single
         * ownership policy used for both boundary sections and rendered internal seams.
         *
         * Persisted component metadata wins when it is available. The ordering mirrors
         * the structural edit hierarchy: main tract, separate wing, projection, recess.
         * Host depth and plan area provide a deterministic geometric fallback for legacy
         * graphs whose faces all still belong to the default `main` component. Face IDs
         * deliberately never participate in the decision.
         */
        private fun selectOwningFace(
            graph: RoofGraph,
            candidates: Collection<GraphFace>,
            sample: LocalPoint
        ): GraphFace? {
            fun componentRank(face: GraphFace): Int {
                val component = graph.components[face.componentId]
                val text = "${face.componentId} ${component?.label.orEmpty()}".lowercase()
                return when {
                    listOf("main", "hlavn").any(text::contains) -> 0
                    listOf("wing", "separate", "kridl", "krídl").any(text::contains) -> 1
                    listOf("projection", "vystup", "výstup", "rizalit").any(text::contains) -> 2
                    listOf("recess", "vyklen", "výklen").any(text::contains) -> 3
                    face.hostFaceId != null || component?.hostFaceId != null -> 4
                    else -> 5
                }
            }

            fun hostDepth(face: GraphFace): Int {
                var depth = 0
                var current: GraphFace? = face
                val visited = mutableSetOf<String>()
                while (current?.hostFaceId != null && visited.add(current.id)) {
                    depth++
                    current = graph.faces[current.hostFaceId]
                }
                return depth
            }

            fun centroid(face: GraphFace): LocalPoint {
                val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
                return if (nodes.isEmpty()) sample else LocalPoint(
                    nodes.sumOf { it.x } / nodes.size,
                    nodes.sumOf { it.y } / nodes.size
                )
            }

            return candidates.asSequence()
                .filter { it.plane != null }
                .distinctBy { it.id }
                .minWithOrNull(
                    compareBy<GraphFace> { componentRank(it) }
                        .thenBy { hostDepth(it) }
                        .thenByDescending { abs(it.signedAreaM2) }
                        // In an otherwise indistinguishable legacy overlap, match the
                        // actually visible anthracite envelope rather than an arbitrary ID.
                        .thenByDescending { it.plane?.zAt(sample.x, sample.y) ?: Double.NEGATIVE_INFINITY }
                        .thenBy { centroid(it).x }
                        .thenBy { centroid(it).y }
                        .thenBy { it.plane?.a ?: 0.0 }
                        .thenBy { it.plane?.b ?: 0.0 }
                        .thenBy { it.plane?.c ?: 0.0 }
                )
        }

        private fun facesOwningEdge(graph: RoofGraph, edge: GraphEdge): List<GraphFace> {
            val actual = graph.faces.values.filter { edge.id in it.orderedEdgeIds }
            if (actual.isNotEmpty()) return actual
            return edge.adjacentFaceIds.mapNotNull(graph.faces::get)
        }

        /**
         * Lifts a roof line onto its incident solved face planes. Stored node Z is only
         * an input constraint and is never a rendering height. Consistent incident planes
         * share one height; an inconsistent legacy overlap follows the same canonical
         * owner policy as the visible roof boundary.
         */
        internal fun solvedEdgeSegment(
            graph: RoofGraph,
            edge: GraphEdge
        ): Pair<GraphNode, GraphNode>? {
            val sourceA = graph.nodes[edge.startNodeId] ?: return null
            val sourceB = graph.nodes[edge.endNodeId] ?: return null
            val faces = facesOwningEdge(graph, edge).filter { it.plane != null }
            if (faces.isEmpty()) return null
            val middle = LocalPoint((sourceA.x + sourceB.x) / 2.0, (sourceA.y + sourceB.y) / 2.0)
            val owner = selectOwningFace(graph, faces, middle) ?: return null
            val ownerPlane = owner.plane ?: return null

            fun solvedZ(source: GraphNode): Double {
                val values = faces.mapNotNull { face ->
                    face.plane?.zAt(source.x, source.y)?.takeIf(Double::isFinite)
                }
                if (values.isEmpty()) return ownerPlane.zAt(source.x, source.y)
                val minimum = values.min()
                val maximum = values.max()
                return if (maximum - minimum <= 1e-6) values.average()
                else ownerPlane.zAt(source.x, source.y)
            }

            val zA = solvedZ(sourceA)
            val zB = solvedZ(sourceB)
            if (!zA.isFinite() || !zB.isFinite() || hypot(sourceB.x - sourceA.x, sourceB.y - sourceA.y) <= 1e-12) {
                return null
            }
            return sourceA.copy(z = zA) to sourceB.copy(z = zB)
        }

        fun from(graph: RoofGraph): SolvedRoofSurfaceGeometry? {
            val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology()) ?: return null
            val nodeIds = ordered.first
            val boundary = nodeIds.map { id ->
                val node = graph.nodes[id] ?: return null
                if (!node.x.isFinite() || !node.y.isFinite()) return null
                LocalPoint(node.x, node.y)
            }
            val edges = ordered.second.map { edge -> graph.edges[edge.id] ?: return null }
            if (boundary.size < 3 || edges.size != boundary.size) return null
            val twiceArea = boundary.indices.sumOf { index ->
                val a = boundary[index]
                val b = boundary[(index + 1) % boundary.size]
                a.x * b.y - b.x * a.y
            }
            if (abs(twiceArea) <= 1e-9) return null
            val ownerByEdgeId = edges.associate { edge ->
                val sourceA = graph.nodes[edge.startNodeId] ?: return null
                val sourceB = graph.nodes[edge.endNodeId] ?: return null
                val middle = LocalPoint((sourceA.x + sourceB.x) / 2.0, (sourceA.y + sourceB.y) / 2.0)
                edge.id to selectOwningFace(graph, facesOwningEdge(graph, edge), middle)
            }
            val topBoundary = nodeIds.mapIndexed { index, nodeId ->
                val source = graph.nodes[nodeId] ?: return null
                val point = boundary[index]
                val candidateFaces = listOfNotNull(
                    ownerByEdgeId[edges[index].id],
                    ownerByEdgeId[edges[(index - 1 + edges.size) % edges.size].id]
                ).ifEmpty {
                    graph.faces.values.filter { face -> nodeId in face.orderedNodeIds }
                }
                val owner = selectOwningFace(graph, candidateFaces, point)
                val solvedZ = owner?.plane?.zAt(point.x, point.y)
                    ?.takeIf(Double::isFinite) ?: source.z
                if (!solvedZ.isFinite()) return null
                source.copy(x = point.x, y = point.y, z = solvedZ)
            }
            val sections = edges.mapIndexed { index, edge ->
                val next = (index + 1) % nodeIds.size
                val sourceA = graph.nodes[nodeIds[index]] ?: return null
                val sourceB = graph.nodes[nodeIds[next]] ?: return null
                val owningFace = ownerByEdgeId[edge.id]
                val plane = owningFace?.plane
                val zA = plane?.zAt(sourceA.x, sourceA.y)?.takeIf(Double::isFinite)
                    ?: topBoundary[index].z
                val zB = plane?.zAt(sourceB.x, sourceB.y)?.takeIf(Double::isFinite)
                    ?: topBoundary[next].z
                BoundarySection(
                    edge = edge,
                    faceId = owningFace?.id,
                    plane = plane,
                    topA = sourceA.copy(z = zA),
                    topB = sourceB.copy(z = zB)
                )
            }
            return SolvedRoofSurfaceGeometry(
                nodeIds, boundary, edges, topBoundary, sections
            )
        }
    }
}
