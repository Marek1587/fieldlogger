package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.tan

/**
 * Makes an off-centre gable tract vertically solvable without moving its ridge.
 *
 * With equal eave elevations, unequal plan runs cannot use equal pitch angles and
 * still meet at one ridge height. For a ridge joining two opposite gables this pass
 * preserves one common rise and derives a separate pitch for every face. The project default
 * belongs to the face with the longer perpendicular run; it is not a global equality constraint.
 */
internal object GableTractSlopeSolver {
    private data class FaceRun(
        val faceId: String,
        val runM: Double,
        val downhillX: Double,
        val downhillY: Double
    )

    private const val PARALLEL_TOLERANCE_DEG = 3.0
    private const val EPSILON = 1e-7

    fun apply(
        input: RoofGraph,
        defaultSlopeDeg: Double,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofGraph {
        val faces = input.faces.toMutableMap()
        input.edges.values.asSequence()
            .filter { it.semanticRole == EdgeSemantic.RIDGE && it.adjacentFaceIds.size == 2 }
            .sortedBy { it.id }
            .forEach { ridge ->
                val ridgeStart = input.nodes[ridge.startNodeId] ?: return@forEach
                val ridgeEnd = input.nodes[ridge.endNodeId] ?: return@forEach
                val ridgeDx = ridgeEnd.x - ridgeStart.x
                val ridgeDy = ridgeEnd.y - ridgeStart.y
                val ridgeLength = hypot(ridgeDx, ridgeDy)
                if (ridgeLength <= EPSILON) return@forEach
                val ridgeMidX = (ridgeStart.x + ridgeEnd.x) / 2.0
                val ridgeMidY = (ridgeStart.y + ridgeEnd.y) / 2.0

                val runs = ridge.adjacentFaceIds.sorted().mapNotNull { faceId ->
                    val face = faces[faceId] ?: return@mapNotNull null
                    val candidates = face.orderedEdgeIds.mapNotNull(input.edges::get)
                        .filter { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
                        .filter { edge ->
                            val a = input.nodes[edge.startNodeId] ?: return@filter false
                            val b = input.nodes[edge.endNodeId] ?: return@filter false
                            val dx = b.x - a.x
                            val dy = b.y - a.y
                            val length = hypot(dx, dy)
                            length > EPSILON && abs(dx * ridgeDy - dy * ridgeDx) /
                                (length * ridgeLength) <= kotlin.math.sin(Math.toRadians(PARALLEL_TOLERANCE_DEG))
                        }
                    val sameTractCandidates = candidates.filter { edge ->
                        val a = input.nodes[edge.startNodeId] ?: return@filter false
                        val b = input.nodes[edge.endNodeId] ?: return@filter false
                        footprintContext?.sameStructuralPart(
                            ridgeMidX, ridgeMidY, (a.x + b.x) / 2.0, (a.y + b.y) / 2.0
                        ) != false
                    }
                    val eave = sameTractCandidates.ifEmpty { candidates }
                        .maxByOrNull { edgeLength(input, it) }
                        ?: return@mapNotNull null
                    val eaveStart = input.nodes.getValue(eave.startNodeId)
                    val eaveEnd = input.nodes.getValue(eave.endNodeId)
                    val eaveMidX = (eaveStart.x + eaveEnd.x) / 2.0
                    val eaveMidY = (eaveStart.y + eaveEnd.y) / 2.0
                    val normalX = -ridgeDy / ridgeLength
                    val normalY = ridgeDx / ridgeLength
                    val signedRun = (eaveMidX - ridgeMidX) * normalX + (eaveMidY - ridgeMidY) * normalY
                    val run = abs(signedRun)
                    if (run <= EPSILON) return@mapNotNull null
                    val sign = if (signedRun < 0.0) -1.0 else 1.0
                    FaceRun(faceId, run, normalX * sign, normalY * sign)
                }
                if (runs.size != 2) return@forEach

                val pairs = runs.map { it to faces.getValue(it.faceId) }
                val userConstraints = pairs.filter {
                    it.second.slopeConstraint?.source == SlopeConstraintSource.USER
                }
                val consistentUserPair = userConstraints.takeIf { it.size == 2 }?.let { pair ->
                    val firstRise = riseFor(pair[0].first, pair[0].second.slopeConstraint!!)
                    val secondRise = riseFor(pair[1].first, pair[1].second.slopeConstraint!!)
                    pair.takeIf { abs(firstRise - secondRise) <= 0.001 }
                }
                if (consistentUserPair != null) return@forEach

                // A face-specific user value is the vertical driver. Otherwise the larger roof
                // run receives the project default and the opposite face is derived from it.
                // Old projects had no source marker and therefore safely return to this rule.
                val anchor = userConstraints.singleOrNull()
                    ?: pairs.maxWith(compareBy<Pair<FaceRun, GraphFace>> { it.first.runM }
                        .thenByDescending { it.first.faceId })
                val anchorAngle = anchor.second.slopeConstraint
                    ?.takeIf { it.source == SlopeConstraintSource.USER }
                    ?.angleDeg
                    ?: defaultSlopeDeg
                val rise = tan(Math.toRadians(anchorAngle.coerceIn(0.0, 75.0))) * anchor.first.runM
                if (!rise.isFinite() || rise < 0.0) return@forEach

                runs.forEach { run ->
                    val face = faces.getValue(run.faceId)
                    val isAnchorUser = run.faceId == anchor.first.faceId &&
                        anchor.second.slopeConstraint?.source == SlopeConstraintSource.USER
                    val angle = if (isAnchorUser) anchorAngle.coerceIn(0.0, 75.0)
                        else Math.toDegrees(atan(rise / run.runM)).coerceIn(0.0, 75.0)
                    faces[run.faceId] = face.copy(
                        plane = null,
                        slopeConstraint = FaceSlopeConstraint(
                            angleDeg = angle,
                            directionX = run.downhillX,
                            directionY = run.downhillY,
                            hard = true,
                            source = if (isAnchorUser) SlopeConstraintSource.USER
                                else SlopeConstraintSource.AUTOMATIC_GABLE
                        )
                    )
                }
            }
        return input.copy(faces = faces)
    }

    private fun edgeLength(graph: RoofGraph, edge: GraphEdge): Double {
        val a = graph.nodes[edge.startNodeId] ?: return 0.0
        val b = graph.nodes[edge.endNodeId] ?: return 0.0
        return hypot(b.x - a.x, b.y - a.y)
    }

    private fun riseFor(run: FaceRun, constraint: FaceSlopeConstraint): Double =
        tan(Math.toRadians(constraint.angleDeg.coerceIn(0.0, 75.0))) * run.runM
}
