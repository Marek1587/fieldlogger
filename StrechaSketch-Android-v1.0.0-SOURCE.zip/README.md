# StrechaSketch pre Android

Natívna Android aplikácia v Kotline na zameranie strechy z mapy, vytvorenie
technického 2D nákresu, výkazu výmer, orientačnej cenovej kalkulácie a 3D
modelu. Projekt nevyžaduje Google Maps API kľúč ani platené mapové SDK.

## Hlavné funkcie

- vyhľadanie adresy cez OpenStreetMap Nominatim,
- zobrazenie OpenStreetMap dlaždíc a ich lokálna cache,
- načítanie najbližšieho obrysu budovy cez Overpass API,
- zadanie GPS súradníc alebo použitie poslednej polohy telefónu,
- obkreslenie strechy jedným ťahom alebo pridávanie bodov,
- presúvanie vrcholov a automatická korekcia smerov 0° / 45° / 90°,
- typy vnútorných čiar: hrebeň, úžľabie, nárožie, atika, pultová hrana,
  napojenie pri murive,
- typy obvodových hrán: odkvap, štít, atika, pult a napojenie pri murive,
- komín, strešné okno, výlez, prestup, vpusť, zvod, výšková kóta a značka sklonu,
- výpočet pôdorysnej plochy, plochy v sklone, obvodu a dĺžok jednotlivých hrán,
- typ 3D modelu: plochá, sedlová, valbová/stanová a pultová strecha,
- 3D ovládanie podľa princípu KlampSketch: otočenie jedným prstom, zoom dvoma
  prstami a reset dvojitým ťuknutím,
- lokálne projekty, duplikovanie a JSON import/export,
- technický SVG a PDF export,
- orientačný výpočet hydroizolácie podľa konštánt a systémov z dodaného PHP
  kalkulátora.

## Zostavenie APK cez GitHub

1. Rozbaľte obsah ZIP-u do koreňa nového GitHub repozitára. Súbor
   `settings.gradle.kts` musí byť priamo v koreňovom priečinku repozitára.
2. Commitnite a odošlite súbory do vetvy `main` alebo `master`.
3. Otvorte kartu **Actions** a workflow **Build StrechaSketch APK**.
4. Spustite ho tlačidlom **Run workflow** alebo obyčajným pushom.
5. Po dokončení stiahnite artifact `StrechaSketch-v1.0.0-debug-apk`.
   V ňom je `app-debug.apk`.

Workflow používa Java 17, Android SDK a Gradle 8.10.2. Gradle Wrapper nie je
potrebný.

## Lokálne zostavenie

Po nainštalovaní JDK 17 a Android SDK:

```text
gradle :app:assembleDebug
```

Výsledok bude v `app/build/outputs/apk/debug/app-debug.apk`.

## Online a offline režim

Editor, uložené projekty, výpočty, 3D model a export fungujú lokálne.
Vyhľadanie novej adresy, prvé načítanie mapových dlaždíc a nový import OSM
obrysu vyžadujú internet. Už načítané dlaždice sa ukladajú do cache aplikácie.

Verejné služby Nominatim, Overpass a `tile.openstreetmap.org` môžu mať limity.
Pri väčšom komerčnom nasadení nastavte vlastný alebo zmluvný mapový endpoint
v `GeoServices.kt`.

## Dôležité technické upozornenie

Výmera z mapy, automaticky vytvorený 3D tvar aj cena sú orientačné. Pred
objednávkou materiálu alebo realizáciou treba rozmery, sklon, detaily a stav
podkladu overiť priamo na stavbe. Verejné OSM dáta nemusia obsahovať každú
budovu ani presný presah strechy.

## Licencie a zdroje

- mapové dáta a dlaždice: © OpenStreetMap contributors,
- geokódovanie: Nominatim,
- geometria budov: OpenStreetMap cez Overpass API,
- aplikácia obsahuje iba vlastný Kotlin kód a Android platformové API.
