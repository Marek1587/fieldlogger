package sk.strechasketch.app

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class CoatingSystem(
    val key: String,
    val label: String,
    val primer: String,
    val consumptionKgM2: Double,
    val coats: Int,
    val primerMaterial: Double,
    val reinforcementMaterial: Double,
    val reinforcementLabor: Double,
    val preparation: Double,
    val detailAllowance: Double,
    val reinforcement: String,
    val eta25: Boolean
)

data class RoofQuote(
    val roofAreaM2: Double,
    val unitExVat: Double,
    val unitWithVat: Double,
    val totalExVat: Double,
    val totalWithVat: Double,
    val distanceKm: Double,
    val laborMultiplier: Double,
    val slopeCategory: String,
    val system: CoatingSystem
)

object QuoteCalculator {
    const val VAT_RATE = 0.23
    private const val BASE_LAT = 49.0963860
    private const val BASE_LON = 18.9272000
    private const val ROAD_DISTANCE_FACTOR = 1.35
    private const val NEOPROOF_BUCKET_KG = 13.0
    private const val NEOPROOF_BUCKET_PRICE_EX_VAT = 100.60
    private const val LABOUR_PER_COAT_EX_VAT = 5.0
    private const val LABOUR_PRIMER_EX_VAT = 5.0
    private const val COMMERCIAL_FACTOR = 1.25
    private val revinexPrimer = (31.92 / 5.0) * 0.065

    val systems = listOf(
        CoatingSystem(
            "concrete", "Betónový podklad", "Revinex® zriedený vodou 1 : 4",
            1.20, 2, revinexPrimer, 1.20, 2.00, 4.00, 1.80,
            "Lokálna výstuž v kútoch, škárach, vpustoch a trhlinách", true
        ),
        CoatingSystem(
            "steel", "Oceľový plech", "Vinyfix® Primer",
            1.20, 2, 1.50, 1.80, 3.00, 5.50, 2.20,
            "Lokálne vystuženie spojov, skrutiek, prestupov a prechodov", true
        ),
        CoatingSystem(
            "standing_seam", "Falcovaný plech", "Vinyfix® / Neotex® Inox Primer",
            1.20, 2, 1.70, 3.20, 5.00, 6.50, 3.00,
            "Lokálne vystuženie všetkých falcov, priečnych spojov a detailov", true
        ),
        CoatingSystem(
            "inox", "Pozink / nerez / hliník", "Neotex® Inox Primer",
            1.20, 2, 1.90, 1.80, 3.00, 6.00, 2.40,
            "Lokálne vystuženie spojov, prestupov a kritických detailov", true
        ),
        CoatingSystem(
            "existing_coating", "Existujúci náter", "Podľa skúšky prídržnosti a kompatibility",
            1.20, 2, 1.10, 1.40, 2.50, 5.00, 2.00,
            "Lokálne vystuženie trhlín, škár, vpustov a napojení", false
        ),
        CoatingSystem(
            "bitumen", "Asfaltový pás", "Revinex® zriedený vodou 1 : 4",
            2.50, 3, revinexPrimer, 3.20, 5.00, 6.00, 2.80,
            "Celoplošná polyesterová výstuž Neotextile® 1,05 m²/m²", true
        )
    )

    fun calculate(project: RoofProject): RoofQuote {
        val totals = ProjectSummary.calculate(project)
        val system = systems.firstOrNull { it.key == project.substrate } ?: systems[1]
        val angle = project.slopeDeg.coerceIn(0.0, 75.0)
        val areaFactor = if (angle > 0.0) 1.0 / cos(Math.toRadians(angle)) else 1.0
        val roofArea = totals.footprintAreaM2 * areaFactor
        val point = Geometry.centroid(project.polygon).takeIf { project.polygon.isNotEmpty() }
            ?: GeoPoint(project.centerLat, project.centerLon)
        val distance = haversineKm(point.lat, point.lon, BASE_LAT, BASE_LON) * ROAD_DISTANCE_FACTOR
        val laborMultiplier = laborDistanceAreaMultiplier(roofArea, distance)
        val laborFactor = when {
            angle <= 3.0 -> 1.0
            angle <= 10.0 -> interpolate(angle, 3.0, 10.0, 1.0, 1.05)
            angle <= 35.0 -> interpolate(angle, 10.0, 35.0, 1.05, 1.18)
            angle <= 45.0 -> interpolate(angle, 35.0, 45.0, 1.18, 1.30)
            else -> min(1.55, 1.30 + (angle - 45.0) * 0.008)
        }
        val pricePerKg = NEOPROOF_BUCKET_PRICE_EX_VAT / NEOPROOF_BUCKET_KG
        val coatingMaterial = system.consumptionKgM2 * pricePerKg
        val laborBase = LABOUR_PRIMER_EX_VAT +
            system.coats * LABOUR_PER_COAT_EX_VAT +
            system.reinforcementLabor
        val laborWithDistance = (laborBase * laborFactor + system.preparation * laborFactor) * laborMultiplier
        val directPerM2 = coatingMaterial + system.primerMaterial +
            system.reinforcementMaterial + laborWithDistance + system.detailAllowance
        val unitEx = directPerM2 * COMMERCIAL_FACTOR
        val unitVat = unitEx * (1 + VAT_RATE)
        return RoofQuote(
            roofAreaM2 = roofArea,
            unitExVat = unitEx,
            unitWithVat = unitVat,
            totalExVat = unitEx * roofArea,
            totalWithVat = unitVat * roofArea,
            distanceKm = distance,
            laborMultiplier = laborMultiplier,
            slopeCategory = when {
                angle <= 3.0 -> "S1–S2"
                angle <= 10.0 -> "S3"
                else -> "S4"
            },
            system = system
        )
    }

    private fun laborDistanceAreaMultiplier(areaValue: Double, distanceValue: Double): Double {
        val area = max(areaValue, 0.01)
        val baseArea = 100.0
        val baseDistance = 5.0
        val calculationArea = min(area, baseArea)
        val calculationKm = max(distanceValue, baseDistance)
        val a = 192.4375
        val b = 44.4209
        val c = 2.4067
        val d = 4.431
        val e = 0.8606
        val f = 0.0648
        val baseLinear = a + b * baseArea + c * baseDistance
        val basePower = exp(d) * baseArea.pow(e) * baseDistance.pow(f)
        val basePerM2 = max(baseLinear, basePower) / baseArea
        val currentLinear = a + b * calculationArea + c * calculationKm
        val currentPower = exp(d) * calculationArea.pow(e) * calculationKm.pow(f)
        val currentPerM2 = max(currentLinear, currentPower) / calculationArea
        return max(1.0, currentPerM2 / basePerM2)
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        return 6371.0088 * 2 * atan2(sqrt(a), sqrt(max(0.0, 1 - a)))
    }

    private fun interpolate(x: Double, x1: Double, x2: Double, y1: Double, y2: Double): Double =
        y1 + ((x - x1) / (x2 - x1)) * (y2 - y1)
}
