package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

data class GeocodedPlace(val displayName: String, val point: GeoPoint)
data class BuildingFootprint(
    val osmId: Long,
    val buildingType: String,
    val name: String,
    val points: MutableList<GeoPoint>,
    val areaM2: Double,
    val distanceM: Double
)

object GeoServices {
    private const val USER_AGENT = "StrechaSketch-Android/1.0 (roof drawing field application)"
    private val executor = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun geocode(query: String, callback: (Result<GeocodedPlace>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
                val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=sk,cz&addressdetails=1&q=$encoded"
                val array = JSONArray(get(url))
                require(array.length() > 0) { "Adresa sa nenašla." }
                val item = array.getJSONObject(0)
                GeocodedPlace(
                    item.optString("display_name", query),
                    GeoPoint(item.getString("lat").toDouble(), item.getString("lon").toDouble())
                )
            }
            main.post { callback(result) }
        }
    }

    fun nearestBuilding(center: GeoPoint, callback: (Result<BuildingFootprint>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val query = """
                    [out:json][timeout:25];
                    (
                      way["building"](around:120,${center.lat},${center.lon});
                      relation["building"](around:120,${center.lat},${center.lon});
                    );
                    out geom tags;
                """.trimIndent()
                val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
                val root = JSONObject(get("https://overpass-api.de/api/interpreter?data=$encoded"))
                val elements = root.optJSONArray("elements") ?: JSONArray()
                val candidates = mutableListOf<BuildingFootprint>()
                repeat(elements.length()) { index ->
                    val element = elements.getJSONObject(index)
                    val tags = element.optJSONObject("tags") ?: JSONObject()
                    val polygons = mutableListOf<JSONArray>()
                    element.optJSONArray("geometry")?.let(polygons::add)
                    val members = element.optJSONArray("members")
                    if (members != null) {
                        repeat(members.length()) { memberIndex ->
                            val member = members.getJSONObject(memberIndex)
                            val role = member.optString("role")
                            if (role.isBlank() || role == "outer") {
                                member.optJSONArray("geometry")?.let(polygons::add)
                            }
                        }
                    }
                    polygons.forEach { geometry ->
                        val points = mutableListOf<GeoPoint>()
                        repeat(geometry.length()) { pointIndex ->
                            val point = geometry.getJSONObject(pointIndex)
                            points += GeoPoint(point.optDouble("lat"), point.optDouble("lon"))
                        }
                        if (points.size > 3 && Geometry.distanceM(points.first(), points.last()) < 0.25) {
                            points.removeAt(points.lastIndex)
                        }
                        val area = Geometry.areaM2(points)
                        if (points.size >= 3 && area in 5.0..50_000.0) {
                            candidates += BuildingFootprint(
                                osmId = element.optLong("id"),
                                buildingType = tags.optString("building", "building"),
                                name = tags.optString("name"),
                                points = points,
                                areaM2 = area,
                                distanceM = Geometry.nearestDistanceToPolygon(center, points)
                            )
                        }
                    }
                }
                require(candidates.isNotEmpty()) { "V okruhu 120 m nie je v OpenStreetMap zakreslená budova." }
                candidates.minWith(compareBy<BuildingFootprint> { it.distanceM }.thenBy { it.areaM2 })
            }
            main.post { callback(result) }
        }
    }

    private fun get(url: String): String {
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 28_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val code = connection.responseCode
            require(code in 200..299) { "Mapová služba odpovedala kódom $code." }
            connection.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}

class MapTileCache(
    cacheDirectory: File,
    private val onTileReady: () -> Unit
) {
    private val memory = object : LruCache<String, Bitmap>(32 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val directory = File(cacheDirectory, "osm_tiles").apply { mkdirs() }
    private val executor = Executors.newFixedThreadPool(3)
    private val pending = ConcurrentHashMap.newKeySet<String>()
    private val main = Handler(Looper.getMainLooper())

    fun get(z: Int, x: Int, y: Int): Bitmap? {
        val count = 1 shl z
        if (y !in 0 until count) return null
        val normalizedX = ((x % count) + count) % count
        val key = "$z-$normalizedX-$y"
        memory.get(key)?.let { return it }
        val disk = File(directory, "$key.png")
        if (disk.exists()) {
            BitmapFactory.decodeFile(disk.absolutePath)?.let {
                memory.put(key, it)
                return it
            }
        }
        if (pending.add(key)) {
            executor.execute {
                try {
                    val connection = URI("https://tile.openstreetmap.org/$z/$normalizedX/$y.png")
                        .toURL().openConnection() as HttpURLConnection
                    connection.connectTimeout = 8_000
                    connection.readTimeout = 12_000
                    connection.setRequestProperty("User-Agent", "StrechaSketch-Android/1.0")
                    connection.setRequestProperty("Referer", "https://www.openstreetmap.org/")
                    if (connection.responseCode in 200..299) {
                        val bytes = connection.inputStream.use { it.readBytes() }
                        if (bytes.isNotEmpty()) {
                            disk.writeBytes(bytes)
                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { memory.put(key, it) }
                        }
                    }
                    connection.disconnect()
                } catch (_: Exception) {
                    // Pri práci bez internetu zostane viditeľná neutrálna mriežka.
                } finally {
                    pending.remove(key)
                    main.post(onTileReady)
                }
            }
        }
        return null
    }
}
