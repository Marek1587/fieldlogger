package sk.strechasketch.app

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class Roof3DView(context: Context) : GLSurfaceView(context) {
    private val roofRenderer = Roof3DRenderer()
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                roofRenderer.zoom = (roofRenderer.zoom * detector.scaleFactor).coerceIn(0.45f, 3.2f)
                requestRender()
                return true
            }
        }
    )
    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        setPreserveEGLContextOnPause(true)
        setRenderer(roofRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        contentDescription = "Interaktívny trojrozmerný model strechy"
    }

    fun setProject(project: RoofProject) {
        roofRenderer.setProject(project)
        requestRender()
    }

    fun resetView() {
        roofRenderer.resetView()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.yawDegrees += (event.x - lastX) / density * 0.62f
                    roofRenderer.pitchDegrees = (
                        roofRenderer.pitchDegrees + (event.y - lastY) / density * 0.62f
                    ).coerceIn(-82f, 82f)
                    requestRender()
                }
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

private data class RoofVec3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(other: RoofVec3) = RoofVec3(x - other.x, y - other.y, z - other.z)
}

private data class RoofMesh(
    val triangles: FloatArray,
    val normals: FloatArray,
    val edges: FloatArray
)

private object RoofMeshBuilder {
    fun build(project: RoofProject): RoofMesh {
        if (project.polygon.size < 3) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val origin = Geometry.centroid(project.polygon)
        val local = project.polygon.map { Geometry.toLocal(it, origin) }
        val maxSpan = max(
            (local.maxOf { it.x } - local.minOf { it.x }),
            (local.maxOf { it.y } - local.minOf { it.y })
        ).coerceAtLeast(1.0)
        val normalization = (2.2 / maxSpan).toFloat()
        val centerLocal = LocalPoint(local.sumOf { it.x } / local.size, local.sumOf { it.y } / local.size)
        val longestIndex = local.indices.maxByOrNull { index ->
            val b = local[(index + 1) % local.size]
            hypot(b.x - local[index].x, b.y - local[index].y)
        } ?: 0
        val longestNext = local[(longestIndex + 1) % local.size]
        val baseAngle = atan2(longestNext.y - local[longestIndex].y, longestNext.x - local[longestIndex].x)
        val ux = cos(baseAngle)
        val uy = sin(baseAngle)
        val vx = -uy
        val vy = ux
        fun u(p: LocalPoint) = p.x * ux + p.y * uy
        fun v(p: LocalPoint) = p.x * vx + p.y * vy
        val uMin = local.minOf(::u)
        val uMax = local.maxOf(::u)
        val vMin = local.minOf(::v)
        val vMax = local.maxOf(::v)
        val vMid = (vMin + vMax) / 2.0
        val halfWidth = ((vMax - vMin) / 2.0).coerceAtLeast(0.25)
        val slopeHeight = (tan(Math.toRadians(project.slopeDeg.coerceIn(0.0, 75.0))) * halfWidth)
            .coerceIn(maxSpan * 0.015, maxSpan * 0.75)
        fun point(p: LocalPoint, height: Double) = RoofVec3(
            ((p.x - centerLocal.x) * normalization).toFloat(),
            (height * normalization).toFloat(),
            ((p.y - centerLocal.y) * normalization).toFloat()
        )
        fun fromUv(up: Double, vp: Double) = LocalPoint(up * ux + vp * vx, up * uy + vp * vy)

        val positions = arrayListOf<Float>()
        val normals = arrayListOf<Float>()
        val edges = arrayListOf<Float>()

        when (project.shape) {
            RoofShape.FLAT -> {
                val height = maxSpan * 0.035
                val center = point(centerLocal, height)
                local.indices.forEach { index ->
                    val a = point(local[index], height)
                    val b = point(local[(index + 1) % local.size], height)
                    addTriangle(positions, normals, a, b, center)
                    addLine(edges, a, b)
                }
            }
            RoofShape.HIP -> {
                val apex = point(centerLocal, slopeHeight)
                local.indices.forEach { index ->
                    val a = point(local[index], 0.0)
                    val b = point(local[(index + 1) % local.size], 0.0)
                    addTriangle(positions, normals, a, b, apex)
                    addLine(edges, a, b)
                    addLine(edges, a, apex)
                }
            }
            RoofShape.SHED -> {
                fun height(p: LocalPoint): Double {
                    val fraction = ((v(p) - vMin) / (vMax - vMin).coerceAtLeast(0.1)).coerceIn(0.0, 1.0)
                    return maxSpan * 0.025 + fraction * slopeHeight * 1.6
                }
                val center = point(centerLocal, height(centerLocal))
                local.indices.forEach { index ->
                    val a = point(local[index], height(local[index]))
                    val bPoint = local[(index + 1) % local.size]
                    val b = point(bPoint, height(bPoint))
                    addTriangle(positions, normals, a, b, center)
                    addLine(edges, a, b)
                }
            }
            RoofShape.GABLE -> {
                fun ridgeAt(up: Double) = point(fromUv(up.coerceIn(uMin, uMax), vMid), slopeHeight)
                val ridgeA = ridgeAt(uMin)
                val ridgeB = ridgeAt(uMax)
                addLine(edges, ridgeA, ridgeB)
                local.indices.forEach { index ->
                    val aLocal = local[index]
                    val bLocal = local[(index + 1) % local.size]
                    val a = point(aLocal, 0.0)
                    val b = point(bLocal, 0.0)
                    val du = abs(u(bLocal) - u(aLocal))
                    val dv = abs(v(bLocal) - v(aLocal))
                    if (du >= dv * 0.65) {
                        val ra = ridgeAt(u(aLocal))
                        val rb = ridgeAt(u(bLocal))
                        addTriangle(positions, normals, a, b, rb)
                        addTriangle(positions, normals, a, rb, ra)
                        addLine(edges, a, ra)
                        addLine(edges, b, rb)
                    } else {
                        val ridge = if (abs((u(aLocal) + u(bLocal)) / 2 - uMin) <
                            abs((u(aLocal) + u(bLocal)) / 2 - uMax)
                        ) ridgeA else ridgeB
                        addTriangle(positions, normals, a, b, ridge)
                        addLine(edges, a, ridge)
                        addLine(edges, b, ridge)
                    }
                    addLine(edges, a, b)
                }
            }
        }

        val fasciaDepth = (maxSpan * 0.045).coerceAtLeast(0.08)
        local.indices.forEach { index ->
            val aTopHeight = when (project.shape) {
                RoofShape.FLAT -> maxSpan * 0.035
                RoofShape.SHED -> {
                    val fraction = ((v(local[index]) - vMin) / (vMax - vMin).coerceAtLeast(0.1)).coerceIn(0.0, 1.0)
                    maxSpan * 0.025 + fraction * slopeHeight * 1.6
                }
                else -> 0.0
            }
            val bIndex = (index + 1) % local.size
            val bTopHeight = when (project.shape) {
                RoofShape.FLAT -> maxSpan * 0.035
                RoofShape.SHED -> {
                    val fraction = ((v(local[bIndex]) - vMin) / (vMax - vMin).coerceAtLeast(0.1)).coerceIn(0.0, 1.0)
                    maxSpan * 0.025 + fraction * slopeHeight * 1.6
                }
                else -> 0.0
            }
            val a = point(local[index], aTopHeight)
            val b = point(local[bIndex], bTopHeight)
            val c = point(local[bIndex], bTopHeight - fasciaDepth)
            val d = point(local[index], aTopHeight - fasciaDepth)
            addTriangle(positions, normals, a, c, b)
            addTriangle(positions, normals, a, d, c)
            addLine(edges, d, c)
        }
        project.lines.forEach { line ->
            val aLocal = Geometry.toLocal(line.start, origin)
            val bLocal = Geometry.toLocal(line.end, origin)
            val height = if (line.type == LineType.RIDGE) slopeHeight else slopeHeight * 0.3
            addLine(edges, point(aLocal, height + maxSpan * 0.006), point(bLocal, height + maxSpan * 0.006))
        }
        return RoofMesh(positions.toFloatArray(), normals.toFloatArray(), edges.toFloatArray())
    }

    private fun addTriangle(
        positions: MutableList<Float>,
        normals: MutableList<Float>,
        a: RoofVec3,
        b: RoofVec3,
        c: RoofVec3
    ) {
        var normal = normalized(cross(b - a, c - a))
        if (normal.y < 0f) {
            normal = RoofVec3(-normal.x, -normal.y, -normal.z)
            addVertex(positions, a)
            addVertex(positions, c)
            addVertex(positions, b)
        } else {
            addVertex(positions, a)
            addVertex(positions, b)
            addVertex(positions, c)
        }
        repeat(3) { addVertex(normals, normal) }
    }

    private fun addLine(values: MutableList<Float>, a: RoofVec3, b: RoofVec3) {
        addVertex(values, a)
        addVertex(values, b)
    }

    private fun addVertex(values: MutableList<Float>, value: RoofVec3) {
        values += value.x
        values += value.y
        values += value.z
    }

    private fun cross(a: RoofVec3, b: RoofVec3) = RoofVec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )

    private fun normalized(value: RoofVec3): RoofVec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) RoofVec3(0f, 1f, 0f)
        else RoofVec3(value.x / length, value.y / length, value.z / length)
    }
}

private class Roof3DRenderer : GLSurfaceView.Renderer {
    @Volatile private var pendingMesh = RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
    @Volatile var yawDegrees = -34f
    @Volatile var pitchDegrees = 28f
    @Volatile var zoom = 1f

    private var width = 1
    private var height = 1
    private var surfaceProgram = 0
    private var edgeProgram = 0
    private var triangleVbo = 0
    private var edgeVbo = 0
    private var triangleCount = 0
    private var edgeCount = 0
    private var uploaded: RoofMesh? = null

    fun setProject(project: RoofProject) {
        pendingMesh = RoofMeshBuilder.build(project)
    }

    fun resetView() {
        yawDegrees = -34f
        pitchDegrees = 28f
        zoom = 1f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.945f, 0.965f, 0.950f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        surfaceProgram = createProgram(SURFACE_VERTEX, SURFACE_FRAGMENT)
        edgeProgram = createProgram(EDGE_VERTEX, EDGE_FRAGMENT)
        val buffers = IntArray(2)
        GLES30.glGenBuffers(2, buffers, 0)
        triangleVbo = buffers[0]
        edgeVbo = buffers[1]
        uploaded = null
    }

    override fun onSurfaceChanged(gl: GL10?, widthValue: Int, heightValue: Int) {
        width = max(1, widthValue)
        height = max(1, heightValue)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (triangleCount == 0) return
        val model = FloatArray(16)
        val view = FloatArray(16)
        val projection = FloatArray(16)
        val viewProjection = FloatArray(16)
        val mvp = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, zoom, zoom, zoom)
        Matrix.setLookAtM(view, 0, 0f, 0.35f, 5.2f, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projection, 0, 34f, width.toFloat() / height, 0.1f, 20f)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)
        drawSurfaces(model, mvp)
        drawEdges(mvp)
    }

    private fun uploadIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploaded) return
        val interleaved = FloatArray(mesh.triangles.size * 2)
        var source = 0
        var target = 0
        while (source < mesh.triangles.size) {
            interleaved[target++] = mesh.triangles[source]
            interleaved[target++] = mesh.triangles[source + 1]
            interleaved[target++] = mesh.triangles[source + 2]
            interleaved[target++] = mesh.normals[source]
            interleaved[target++] = mesh.normals[source + 1]
            interleaved[target++] = mesh.normals[source + 2]
            source += 3
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, interleaved.size * 4, interleaved.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        triangleCount = mesh.triangles.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, mesh.edges.size * 4, mesh.edges.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        edgeCount = mesh.edges.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        uploaded = mesh
    }

    private fun drawSurfaces(model: FloatArray, mvp: FloatArray) {
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uModel"), 1, false, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uColor"), 0.68f, 0.16f, 0.12f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uLight"), -0.3f, 0.8f, 0.55f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(normal)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glVertexAttribPointer(normal, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, triangleCount)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(normal)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(edgeProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(edgeProgram, "uColor"), 0.08f, 0.10f, 0.11f, 0.95f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glLineWidth(1.5f)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeCount)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragment)
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL program: ${GLES30.glGetProgramInfoLog(program)}" }
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return program
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL shader: ${GLES30.glGetShaderInfoLog(shader)}" }
        return shader
    }

    private fun FloatArray.nativeBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(this@nativeBuffer)
            position(0)
        }

    companion object {
        private const val SURFACE_VERTEX = """
            #version 300 es
            uniform mat4 uModel;
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec3 aNormal;
            out vec3 vNormal;
            void main() {
                vNormal = mat3(uModel) * aNormal;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val SURFACE_FRAGMENT = """
            #version 300 es
            precision highp float;
            uniform vec3 uColor;
            uniform vec3 uLight;
            in vec3 vNormal;
            out vec4 outColor;
            void main() {
                vec3 normal = normalize(vNormal);
                if (!gl_FrontFacing) normal = -normal;
                float diffuse = max(dot(normal, normalize(uLight)), 0.0);
                vec3 color = uColor * (0.40 + 0.60 * diffuse);
                outColor = vec4(color, 1.0);
            }
        """
        private const val EDGE_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            void main() { gl_Position = uMvp * vec4(aPosition, 1.0); }
        """
        private const val EDGE_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform vec4 uColor;
            out vec4 outColor;
            void main() { outColor = uColor; }
        """
    }
}
