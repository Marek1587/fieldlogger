# Zmeny

## 1.0.0

- prvá natívna Android verzia,
- OSM mapový podklad, Nominatim a Overpass,
- dotykový 2D editor strechy,
- technické línie a prvky z PHP editora,
- živý výkaz výmer a cenový výpočet,
- OpenGL 3D model so štyrmi tvarmi strechy,
- lokálne projekty a JSON import/export,
- SVG a PDF export,
- GitHub Actions workflow na zostavenie debug APK.
