# Prenos funkcií z dodaných PHP súborov

| PHP funkcia / pracovný postup | Android implementácia |
|---|---|
| adresa alebo GPS | vyhľadávací riadok + priame súradnice + poloha telefónu |
| Overpass obrys budovy | tlačidlo `Budova`, výber najbližšieho validného polygonu |
| ručné obkreslenie polygonu | `Obrys prstom` |
| pridanie a presun vrcholov | `+ bod` a `Editovať` |
| regularizácia geometrie | `Skorigovať`, smery 0° / 45° / 90° |
| hrebeň / úžľabie / nárožie | samostatné farebné nástroje |
| atika / pult / pri murive | vnútorné línie aj cyklický typ obvodovej hrany |
| komín / okno / výlez | obdĺžnikové prvky |
| prestup / vpusť | kruhové prvky |
| zvod / výška / sklon | bodové technické značky |
| výkaz výmer | živý súhrn v editore a samostatná obrazovka |
| GPS a JSON model | lokálny projekt + JSON import/export |
| technický SVG | natívny SVG export s rozmermi a súhrnom |
| ponukový PDF | natívny PDF technický výstup |
| cenový kalkulátor | 6 systémov podkladu, DPH 23 %, materiál, práca, vzdialenosť a malá zákazka |
| 3D klampiarsky náhľad | OpenGL ES 3, otočenie, zoom, reset |

Serverové funkcie PHP ako archivácia ponúk do serverovej SQLite/MySQL,
odosielanie formulárov a serverová štatistika nie sú prenesené. Android
aplikácia ukladá projekty iba lokálne a nevytvára bez vedomia používateľa
žiadne záznamy na serveri.
