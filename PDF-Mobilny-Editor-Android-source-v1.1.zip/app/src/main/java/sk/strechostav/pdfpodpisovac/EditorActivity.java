package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class EditorActivity extends Activity {
    public static final String EXTRA_URIS = "document_uris";

    private static final int REQUEST_ADD_FILES = 2001;
    private static final int REQUEST_CREATE_PDF = 2002;

    private final ArrayList<Uri> initialUris = new ArrayList<>();
    private final ArrayList<EditAnnotation> annotations = new ArrayList<>();
    private final ArrayList<Button> allDrawerButtons = new ArrayList<>();
    private final ArrayList<Button> modeButtons = new ArrayList<>();

    private File workingPdf;
    private PdfRenderer renderer;
    private PdfPageAdapter pageAdapter;
    private int[] pageWidths = new int[]{595};
    private int[] pageHeights = new int[]{842};
    private int pageCount = 1;
    private int currentPage;
    private boolean loaded;
    private boolean busy;
    private EditAnnotation.Type activeMode;
    private boolean selectionMode;

    private ListView pdfList;
    private LinearLayout drawer;
    private TextView statusText;
    private TextView pageIndicator;
    private ProgressBar progressBar;
    private Button menuButton;
    private Button readButton;
    private Button selectButton;
    private Button addFilesButton;
    private Button deletePagesButton;
    private Button undoButton;
    private Button clearButton;
    private Button exportButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ArrayList<String> values = getIntent().getStringArrayListExtra(EXTRA_URIS);
        if (values != null) {
            for (String value : values) {
                if (value != null && !value.trim().isEmpty()) {
                    initialUris.add(Uri.parse(value));
                }
            }
        }
        if (initialUris.isEmpty()) {
            Toast.makeText(this, "Nebol vybraný žiadny dokument.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildUi();
        loadInitialDocuments();
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(237, 239, 243));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, Ui.dp(this, 18), 0, 0);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        LinearLayout topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(
                Ui.dp(this, 8),
                Ui.dp(this, 5),
                Ui.dp(this, 10),
                Ui.dp(this, 5)
        );
        topBar.setBackgroundColor(Color.WHITE);

        menuButton = Ui.squareToolButton(this, "Menu", R.drawable.ic_menu);
        topBar.addView(menuButton, new LinearLayout.LayoutParams(
                Ui.dp(this, 56),
                Ui.dp(this, 56)
        ));
        menuButton.setOnClickListener(view -> toggleDrawer());

        TextView title = Ui.text(this, "PDF Editor", 18, Color.rgb(35, 38, 47));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        );
        titleParams.leftMargin = Ui.dp(this, 10);
        topBar.addView(title, titleParams);

        pageIndicator = Ui.text(this, "1 / 1", 13, Color.rgb(70, 73, 82));
        pageIndicator.setGravity(Gravity.CENTER);
        pageIndicator.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 6),
                Ui.dp(this, 10),
                Ui.dp(this, 6)
        );
        GradientDrawable pageChip = new GradientDrawable();
        pageChip.setColor(Color.rgb(244, 245, 248));
        pageChip.setCornerRadius(Ui.dp(this, 13));
        pageChip.setStroke(Ui.dp(this, 1), Color.rgb(224, 226, 232));
        pageIndicator.setBackground(pageChip);
        pageIndicator.setOnClickListener(view -> showGoToPageDialog());
        topBar.addView(pageIndicator);
        content.addView(topBar);

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(
                Ui.dp(this, 12),
                Ui.dp(this, 3),
                Ui.dp(this, 12),
                Ui.dp(this, 3)
        );
        statusText = Ui.text(this, "Načítavam dokumenty…", 12, Color.rgb(91, 96, 108));
        statusText.setSingleLine(true);
        statusText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        statusRow.addView(statusText, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        statusRow.addView(progressBar, new LinearLayout.LayoutParams(
                Ui.dp(this, 24),
                Ui.dp(this, 24)
        ));
        content.addView(statusRow);

        pdfList = new ListView(this);
        pdfList.setBackgroundColor(Color.rgb(226, 230, 236));
        pdfList.setDividerHeight(Ui.dp(this, 10));
        pdfList.setDivider(null);
        pdfList.setClipToPadding(false);
        pdfList.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 24));
        pdfList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                // The compact page number is updated by onScroll.
            }

            @Override
            public void onScroll(
                    AbsListView view,
                    int firstVisibleItem,
                    int visibleItemCount,
                    int totalItemCount
            ) {
                if (totalItemCount <= 0) {
                    return;
                }
                int visiblePage = firstVisibleItem;
                View firstChild = view.getChildAt(0);
                if (firstChild != null
                        && -firstChild.getTop() > firstChild.getHeight() / 2
                        && visiblePage + 1 < totalItemCount) {
                    visiblePage++;
                }
                currentPage = Math.max(0, Math.min(visiblePage, pageCount - 1));
                updatePageIndicator();
                updateControls();
            }
        });
        content.addView(pdfList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        drawer = buildDrawer();
        drawer.setVisibility(View.GONE);
        int drawerWidth = Math.min(
                Ui.dp(this, 292),
                getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 28)
        );
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(
                drawerWidth,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.START
        );
        drawerParams.topMargin = Ui.dp(this, 18);
        root.addView(drawer, drawerParams);

        setContentView(root);
        updateControls();
    }

    private LinearLayout buildDrawer() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 10),
                Ui.dp(this, 10),
                Ui.dp(this, 14)
        );
        panel.setBackgroundColor(Color.rgb(250, 250, 252));
        panel.setElevation(Ui.dp(this, 12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "PDF nástroje", 18, Color.rgb(35, 38, 47));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        Button hideButton = Ui.squareToolButton(this, "Skryť", R.drawable.ic_close);
        header.addView(hideButton, new LinearLayout.LayoutParams(
                Ui.dp(this, 56),
                Ui.dp(this, 56)
        ));
        hideButton.setOnClickListener(view -> hideDrawer());
        panel.addView(header);

        TextView hint = Ui.text(
                this,
                "Vyberte nástroj a potom pracujte priamo na strane.",
                12,
                Color.rgb(91, 96, 108)
        );
        LinearLayout.LayoutParams hintParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        hintParams.bottomMargin = Ui.dp(this, 7);
        panel.addView(hint, hintParams);

        ScrollView scroll = new ScrollView(this);
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        scroll.addView(grid, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        panel.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        readButton = addSquareButton(grid, "Čítať", R.drawable.ic_read);
        selectButton = addSquareButton(grid, "Upraviť", R.drawable.ic_select_edit);
        Button replaceButton = addSquareButton(grid, "Text", R.drawable.ic_text_edit);
        Button highlightButton = addSquareButton(
                grid,
                "Zvýrazniť",
                R.drawable.ic_highlight
        );
        Button underlineButton = addSquareButton(
                grid,
                "Podčiarknuť",
                R.drawable.ic_underline
        );
        Button strikeButton = addSquareButton(
                grid,
                "Prečiarknuť",
                R.drawable.ic_strike
        );
        addFilesButton = addSquareButton(grid, "Pridať", R.drawable.ic_add_file);
        deletePagesButton = addSquareButton(
                grid,
                "Strany od–do",
                R.drawable.ic_delete_pages
        );
        undoButton = addSquareButton(grid, "Späť", R.drawable.ic_undo);
        clearButton = addSquareButton(grid, "Vyčistiť", R.drawable.ic_clear);
        exportButton = addSquareButton(grid, "Exportovať", R.drawable.ic_export);
        Button closeButton = addSquareButton(grid, "Zavrieť", R.drawable.ic_close);

        modeButtons.add(readButton);
        modeButtons.add(selectButton);
        modeButtons.add(replaceButton);
        modeButtons.add(highlightButton);
        modeButtons.add(underlineButton);
        modeButtons.add(strikeButton);

        readButton.setOnClickListener(view -> selectTool(null, false, readButton));
        selectButton.setOnClickListener(view -> selectTool(null, true, selectButton));
        replaceButton.setOnClickListener(view -> selectTool(
                EditAnnotation.Type.REPLACE_TEXT,
                false,
                replaceButton
        ));
        highlightButton.setOnClickListener(view -> selectTool(
                EditAnnotation.Type.HIGHLIGHT,
                false,
                highlightButton
        ));
        underlineButton.setOnClickListener(view -> selectTool(
                EditAnnotation.Type.UNDERLINE,
                false,
                underlineButton
        ));
        strikeButton.setOnClickListener(view -> selectTool(
                EditAnnotation.Type.STRIKEOUT,
                false,
                strikeButton
        ));
        addFilesButton.setOnClickListener(view -> chooseAdditionalFiles());
        deletePagesButton.setOnClickListener(view -> showDeletePagesDialog());
        undoButton.setOnClickListener(view -> undoLastEdit());
        clearButton.setOnClickListener(view -> confirmClearPage());
        exportButton.setOnClickListener(view -> chooseOutputFile());
        closeButton.setOnClickListener(view -> finish());

        selectTool(null, false, readButton);
        return panel;
    }

    private Button addSquareButton(GridLayout grid, String label, int icon) {
        Button button = Ui.squareToolButton(this, label, icon);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = Ui.dp(this, 82);
        params.height = Ui.dp(this, 82);
        params.setMargins(
                Ui.dp(this, 3),
                Ui.dp(this, 3),
                Ui.dp(this, 3),
                Ui.dp(this, 3)
        );
        grid.addView(button, params);
        allDrawerButtons.add(button);
        return button;
    }

    private void selectTool(
            EditAnnotation.Type mode,
            boolean selectExisting,
            Button selectedButton
    ) {
        activeMode = mode;
        selectionMode = selectExisting;
        for (Button button : modeButtons) {
            button.setAlpha(button == selectedButton ? 1f : 0.56f);
        }
        if (pageAdapter != null) {
            pageAdapter.setTool(activeMode, selectionMode);
        }
        if (!busy && statusText != null) {
            statusText.setText(toolInstruction());
        }
        hideDrawer();
    }

    private String toolInstruction() {
        if (selectionMode) {
            return "Upraviť: ťuknite na úpravu; potiahnutím ju presuňte alebo zmeňte roh.";
        }
        if (activeMode == null) {
            return "Čítanie: dokument posúvajte zvislo prstom.";
        }
        switch (activeMode) {
            case REPLACE_TEXT:
                return "Text: potiahnutím označte miesto pôvodného textu.";
            case HIGHLIGHT:
                return "Zvýraznenie: potiahnutím označte text.";
            case UNDERLINE:
                return "Podčiarknutie: potiahnutím označte text.";
            case STRIKEOUT:
                return "Prečiarknutie: potiahnutím označte text.";
            default:
                return "";
        }
    }

    private void toggleDrawer() {
        drawer.setVisibility(
                drawer.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE
        );
    }

    private void hideDrawer() {
        if (drawer != null) {
            drawer.setVisibility(View.GONE);
        }
    }

    private void onRegionSelected(
            EditAnnotation.Type type,
            int pageIndex,
            RectF rect
    ) {
        currentPage = pageIndex;
        updatePageIndicator();
        if (type == EditAnnotation.Type.REPLACE_TEXT) {
            showReplacementDialog(pageIndex, rect);
            return;
        }
        EditAnnotation annotation = new EditAnnotation(type, pageIndex, rect);
        annotations.add(annotation);
        refreshAnnotations();
        if (type == EditAnnotation.Type.HIGHLIGHT) {
            showAnnotationDialog(annotation);
        } else {
            statusText.setText("Úprava bola pridaná. Cez Upraviť ju môžete zmeniť.");
        }
    }

    private final PdfEditView.AnnotationListener annotationListener =
            new PdfEditView.AnnotationListener() {
                @Override
                public void onAnnotationTapped(EditAnnotation annotation) {
                    showAnnotationDialog(annotation);
                }

                @Override
                public void onAnnotationChanged(EditAnnotation annotation) {
                    statusText.setText(
                            "Úprava sa presúva. Modrým rohom zmeníte veľkosť oblasti."
                    );
                }
            };

    private void showReplacementDialog(int pageIndex, RectF rect) {
        EditText input = new EditText(this);
        input.setHint("Nový text; prázdne pole pôvodný text iba prekryje");
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMinLines(2);
        new AlertDialog.Builder(this)
                .setTitle("Zmeniť text")
                .setMessage("Označené miesto sa prekryje a vloží sa nový text.")
                .setView(input)
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Vložiť", (dialog, which) -> {
                    EditAnnotation annotation = new EditAnnotation(
                            EditAnnotation.Type.REPLACE_TEXT,
                            pageIndex,
                            rect
                    );
                    annotation.text = input.getText().toString();
                    annotations.add(annotation);
                    refreshAnnotations();
                    statusText.setText("Nový text bol vložený.");
                })
                .show();
    }

    private void showAnnotationDialog(EditAnnotation annotation) {
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(
                Ui.dp(this, 18),
                Ui.dp(this, 4),
                Ui.dp(this, 18),
                0
        );

        EditText textInput = null;
        if (annotation.type == EditAnnotation.Type.REPLACE_TEXT) {
            textInput = new EditText(this);
            textInput.setHint("Vložený text");
            textInput.setText(annotation.text);
            textInput.setMinLines(2);
            textInput.setInputType(InputType.TYPE_CLASS_TEXT
                    | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            content.addView(textInput);
        }

        EditText commentInput = new EditText(this);
        commentInput.setHint("Komentár k označeniu");
        commentInput.setText(annotation.comment);
        commentInput.setMinLines(2);
        commentInput.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        content.addView(commentInput);

        TextView colorLabel = Ui.text(this, "Farba", 13, Color.rgb(91, 96, 108));
        LinearLayout.LayoutParams colorLabelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        colorLabelParams.topMargin = Ui.dp(this, 8);
        content.addView(colorLabel, colorLabelParams);

        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(colors);
        int[] selectedColor = new int[]{annotation.color};
        int[] palette = annotation.type == EditAnnotation.Type.HIGHLIGHT
                ? new int[]{
                Color.argb(105, 255, 221, 45),
                Color.argb(100, 102, 187, 106),
                Color.argb(95, 244, 143, 177),
                Color.argb(90, 66, 165, 245)
        }
                : new int[]{
                Color.rgb(198, 40, 40),
                Color.rgb(25, 118, 210),
                Color.rgb(20, 20, 20),
                Color.rgb(46, 125, 50)
        };
        for (int color : palette) {
            Button colorButton = new Button(this);
            colorButton.setMinWidth(0);
            colorButton.setMinHeight(0);
            GradientDrawable colorBackground = new GradientDrawable();
            colorBackground.setShape(GradientDrawable.OVAL);
            colorBackground.setColor(color);
            colorBackground.setStroke(
                    Ui.dp(this, 1),
                    Color.rgb(130, 133, 142)
            );
            colorButton.setBackground(colorBackground);
            LinearLayout.LayoutParams colorParams = new LinearLayout.LayoutParams(
                    Ui.dp(this, 42),
                    Ui.dp(this, 42)
            );
            colorParams.rightMargin = Ui.dp(this, 10);
            colors.addView(colorButton, colorParams);
            colorButton.setOnClickListener(view -> {
                selectedColor[0] = color;
                Toast.makeText(this, "Farba zvolená.", Toast.LENGTH_SHORT).show();
            });
        }

        EditText finalTextInput = textInput;
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(annotationTitle(annotation))
                .setMessage(
                        "V režime Upraviť môžete označenie presúvať a modrým rohom "
                                + "meniť jeho veľkosť."
                )
                .setView(content)
                .setNegativeButton("Zavrieť", null)
                .setNeutralButton("Odstrániť", null)
                .setPositiveButton("Uložiť", null)
                .create();
        dialog.setOnShowListener(ignored -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                if (finalTextInput != null) {
                    annotation.text = finalTextInput.getText().toString();
                }
                annotation.comment = commentInput.getText().toString();
                annotation.color = selectedColor[0];
                refreshAnnotations();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(view -> {
                annotations.remove(annotation);
                refreshAnnotations();
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private String annotationTitle(EditAnnotation annotation) {
        switch (annotation.type) {
            case REPLACE_TEXT:
                return "Upraviť vložený text";
            case HIGHLIGHT:
                return "Zvýraznenie a komentár";
            case UNDERLINE:
                return "Upraviť podčiarknutie";
            case STRIKEOUT:
                return "Upraviť prečiarknutie";
            default:
                return "Upraviť označenie";
        }
    }

    private void refreshAnnotations() {
        if (pageAdapter != null) {
            pageAdapter.refreshAnnotations();
        }
        updateControls();
    }

    private void loadInitialDocuments() {
        setBusy(true, "Pripravujem dokumenty…");
        new Thread(() -> {
            try {
                File combined = DocumentCombiner.combineToPdf(
                        this,
                        initialUris,
                        false,
                        (current, total, fileName) -> runOnUiThread(() ->
                                statusText.setText(
                                        "Importujem " + current + " z " + total
                                                + ": " + fileName
                                )
                        )
                );
                RendererData data = prepareRenderer(combined);
                runOnUiThread(() -> installDocument(combined, data, 0, null));
            } catch (Exception exception) {
                runOnUiThread(() -> showLoadError(exception));
            }
        }, "pdf-initial-loader").start();
    }

    private RendererData prepareRenderer(File file) throws IOException {
        ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_READ_ONLY
        );
        PdfRenderer newRenderer = null;
        try {
            newRenderer = new PdfRenderer(descriptor);
            int count = newRenderer.getPageCount();
            if (count <= 0) {
                throw new IOException("PDF neobsahuje žiadnu stranu.");
            }
            int[] widths = new int[count];
            int[] heights = new int[count];
            synchronized (newRenderer) {
                for (int index = 0; index < count; index++) {
                    try (PdfRenderer.Page page = newRenderer.openPage(index)) {
                        widths[index] = Math.max(1, page.getWidth());
                        heights[index] = Math.max(1, page.getHeight());
                    }
                }
            }
            return new RendererData(newRenderer, widths, heights);
        } catch (Exception exception) {
            if (newRenderer != null) {
                newRenderer.close();
            } else {
                descriptor.close();
            }
            if (exception instanceof IOException) {
                throw (IOException) exception;
            }
            throw new IOException("PDF sa nepodarilo pripraviť.", exception);
        }
    }

    private void installDocument(
            File newFile,
            RendererData data,
            int targetPage,
            File oldFile
    ) {
        closeRenderer();
        workingPdf = newFile;
        renderer = data.renderer;
        pageWidths = data.widths;
        pageHeights = data.heights;
        pageCount = pageWidths.length;
        currentPage = Math.max(0, Math.min(targetPage, pageCount - 1));
        pageAdapter = new PdfPageAdapter(
                this,
                renderer,
                pageWidths,
                pageHeights,
                annotations,
                this::onRegionSelected,
                annotationListener
        );
        pageAdapter.setTool(activeMode, selectionMode);
        pdfList.setAdapter(pageAdapter);
        loaded = true;
        setBusy(false, toolInstruction());
        pdfList.setSelection(currentPage);
        updatePageIndicator();
        if (oldFile != null && oldFile.isFile() && !oldFile.equals(newFile)) {
            //noinspection ResultOfMethodCallIgnored
            oldFile.delete();
        }
    }

    private void chooseAdditionalFiles() {
        if (!loaded || busy) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{
                        "application/pdf",
                        "image/jpeg",
                        "image/png",
                        "image/webp",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                }
        );
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_ADD_FILES);
        } catch (Exception exception) {
            Toast.makeText(this, "Výber súborov nie je dostupný.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) {
            return;
        }
        if (requestCode == REQUEST_ADD_FILES) {
            ArrayList<Uri> additions = collectUris(data);
            if (!additions.isEmpty()) {
                appendFiles(additions);
            }
        } else if (requestCode == REQUEST_CREATE_PDF && data.getData() != null) {
            exportTo(data.getData());
        }
    }

    private ArrayList<Uri> collectUris(Intent data) {
        LinkedHashSet<Uri> selected = new LinkedHashSet<>();
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int index = 0; index < clipData.getItemCount(); index++) {
                Uri uri = clipData.getItemAt(index).getUri();
                if (uri != null) {
                    selected.add(uri);
                }
            }
        } else if (data.getData() != null) {
            selected.add(data.getData());
        }
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        for (Uri uri : selected) {
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) {
                // Temporary access is enough for immediate import.
            }
        }
        return new ArrayList<>(selected);
    }

    private void appendFiles(ArrayList<Uri> additions) {
        File previousFile = workingPdf;
        int returnToPage = currentPage;
        ArrayList<Uri> combinedInputs = new ArrayList<>();
        combinedInputs.add(Uri.fromFile(previousFile));
        combinedInputs.addAll(additions);
        setBusy(true, "Pridávam ďalšie súbory…");
        hideDrawer();
        new Thread(() -> {
            try {
                File combined = DocumentCombiner.combineToPdf(
                        this,
                        combinedInputs,
                        false,
                        (current, total, fileName) -> runOnUiThread(() ->
                                statusText.setText(
                                        "Spájam " + current + " z " + total
                                                + ": " + fileName
                                )
                        )
                );
                RendererData data = prepareRenderer(combined);
                runOnUiThread(() -> installDocument(
                        combined,
                        data,
                        returnToPage,
                        previousFile
                ));
            } catch (Exception exception) {
                runOnUiThread(() -> setBusy(
                        false,
                        "Súbory sa nepodarilo pridať: " + safeMessage(exception)
                ));
            }
        }, "pdf-file-appender").start();
    }

    private void showDeletePagesDialog() {
        if (!loaded || busy) {
            return;
        }
        hideDrawer();
        LinearLayout fields = new LinearLayout(this);
        fields.setPadding(
                Ui.dp(this, 18),
                Ui.dp(this, 4),
                Ui.dp(this, 18),
                0
        );
        EditText fromInput = new EditText(this);
        fromInput.setHint("Od");
        fromInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        fromInput.setText(String.valueOf(currentPage + 1));
        EditText toInput = new EditText(this);
        toInput.setHint("Do");
        toInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        toInput.setText(String.valueOf(currentPage + 1));
        fields.addView(fromInput, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        fields.addView(toInput, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        new AlertDialog.Builder(this)
                .setTitle("Odstrániť strany")
                .setMessage("Zadajte rozsah od–do. Dokument má " + pageCount + " strán.")
                .setView(fields)
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Odstrániť", (dialog, which) -> {
                    try {
                        int from = Integer.parseInt(fromInput.getText().toString()) - 1;
                        int to = Integer.parseInt(toInput.getText().toString()) - 1;
                        if (from < 0 || to < from || to >= pageCount) {
                            throw new IllegalArgumentException();
                        }
                        if (to - from + 1 >= pageCount) {
                            Toast.makeText(
                                    this,
                                    "Nie je možné odstrániť všetky strany.",
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }
                        deletePageRange(from, to);
                    } catch (Exception exception) {
                        Toast.makeText(
                                this,
                                "Zadajte platný rozsah od 1 do " + pageCount + ".",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                })
                .show();
    }

    private void deletePageRange(int from, int to) {
        File previousFile = workingPdf;
        setBusy(true, "Odstraňujem strany…");
        new Thread(() -> {
            try {
                File updated = PdfPageOperations.deleteRange(this, previousFile, from, to);
                RendererData data = prepareRenderer(updated);
                runOnUiThread(() -> {
                    remapAnnotationsAfterDelete(from, to);
                    installDocument(updated, data, Math.min(from, data.widths.length - 1), previousFile);
                });
            } catch (Exception exception) {
                runOnUiThread(() -> setBusy(
                        false,
                        "Strany sa nepodarilo odstrániť: " + safeMessage(exception)
                ));
            }
        }, "pdf-page-remover").start();
    }

    private void remapAnnotationsAfterDelete(int from, int to) {
        int removedCount = to - from + 1;
        Iterator<EditAnnotation> iterator = annotations.iterator();
        while (iterator.hasNext()) {
            EditAnnotation annotation = iterator.next();
            if (annotation.pageIndex >= from && annotation.pageIndex <= to) {
                iterator.remove();
            } else if (annotation.pageIndex > to) {
                annotation.pageIndex -= removedCount;
            }
        }
    }

    private void undoLastEdit() {
        hideDrawer();
        for (int index = annotations.size() - 1; index >= 0; index--) {
            if (annotations.get(index).pageIndex == currentPage) {
                annotations.remove(index);
                refreshAnnotations();
                statusText.setText("Posledná úprava na strane bola odstránená.");
                return;
            }
        }
        Toast.makeText(this, "Na tejto strane nie je žiadna úprava.", Toast.LENGTH_SHORT).show();
    }

    private void confirmClearPage() {
        hideDrawer();
        if (!hasEditOnCurrentPage()) {
            Toast.makeText(this, "Na tejto strane nie sú úpravy.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Vyčistiť úpravy strany?")
                .setMessage("Odstránia sa zvýraznenia, komentáre aj zmeny textu.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Vyčistiť", (dialog, which) -> {
                    annotations.removeIf(item -> item.pageIndex == currentPage);
                    refreshAnnotations();
                })
                .show();
    }

    private void showGoToPageDialog() {
        if (!loaded || busy) {
            return;
        }
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(currentPage + 1));
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("Prejsť na stranu")
                .setMessage("Zadajte číslo od 1 do " + pageCount + ".")
                .setView(input)
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Prejsť", (dialog, which) -> {
                    try {
                        int page = Integer.parseInt(input.getText().toString()) - 1;
                        if (page < 0 || page >= pageCount) {
                            throw new IllegalArgumentException();
                        }
                        currentPage = page;
                        pdfList.setSelection(page);
                        updatePageIndicator();
                    } catch (Exception exception) {
                        Toast.makeText(
                                this,
                                "Neplatné číslo strany.",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                })
                .show();
    }

    private void chooseOutputFile() {
        if (!loaded || busy) {
            return;
        }
        hideDrawer();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, "upravene_pdf.pdf");
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_CREATE_PDF);
        } catch (Exception exception) {
            Toast.makeText(this, "Uloženie súboru nie je dostupné.", Toast.LENGTH_LONG).show();
        }
    }

    private void exportTo(Uri outputUri) {
        ArrayList<EditAnnotation> snapshot = new ArrayList<>(annotations.size());
        for (EditAnnotation annotation : annotations) {
            snapshot.add(annotation.copy());
        }
        setBusy(true, "Vytváram upravené PDF…");
        new Thread(() -> {
            try {
                PdfEditExporter.export(
                        this,
                        workingPdf,
                        snapshot,
                        outputUri,
                        (page, total) -> runOnUiThread(() ->
                                statusText.setText(String.format(
                                        Locale.getDefault(),
                                        "Exportujem stranu %d z %d…",
                                        page,
                                        total
                                ))
                        )
                );
                runOnUiThread(() -> {
                    setBusy(false, "Upravené PDF bolo vytvorené.");
                    showExportSuccess(outputUri);
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, "PDF sa nepodarilo vytvoriť.");
                    new AlertDialog.Builder(this)
                            .setTitle("Export zlyhal")
                            .setMessage(safeMessage(exception))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        }, "pdf-editor-exporter").start();
    }

    private void showExportSuccess(Uri uri) {
        new AlertDialog.Builder(this)
                .setTitle("PDF je uložené")
                .setMessage("Upravené PDF bolo vytvorené. Originály zostali nezmenené.")
                .setPositiveButton("Zdieľať", (dialog, which) -> sharePdf(uri))
                .setNeutralButton("Otvoriť", (dialog, which) -> openPdf(uri))
                .setNegativeButton("Hotovo", null)
                .show();
    }

    private void sharePdf(Uri uri) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(share, "Zdieľať upravené PDF"));
        } catch (Exception exception) {
            Toast.makeText(this, "PDF sa nepodarilo zdieľať.", Toast.LENGTH_LONG).show();
        }
    }

    private void openPdf(Uri uri) {
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "application/pdf");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(view);
        } catch (Exception exception) {
            Toast.makeText(this, "Nie je dostupná čítačka PDF.", Toast.LENGTH_LONG).show();
        }
    }

    private void setBusy(boolean value, String message) {
        busy = value;
        if (progressBar != null) {
            progressBar.setVisibility(value ? View.VISIBLE : View.GONE);
        }
        if (statusText != null && message != null) {
            statusText.setText(message);
        }
        if (pdfList != null) {
            pdfList.setEnabled(!value);
        }
        updateControls();
    }

    private void updateControls() {
        updatePageIndicator();
        if (menuButton == null) {
            return;
        }
        menuButton.setEnabled(!busy);
        if (allDrawerButtons.isEmpty()) {
            return;
        }
        for (Button button : allDrawerButtons) {
            button.setEnabled(loaded && !busy);
        }
        deletePagesButton.setEnabled(loaded && !busy && pageCount > 1);
        undoButton.setEnabled(loaded && !busy && hasEditOnCurrentPage());
        clearButton.setEnabled(loaded && !busy && hasEditOnCurrentPage());
        exportButton.setEnabled(loaded && !busy);
    }

    private void updatePageIndicator() {
        if (pageIndicator != null) {
            pageIndicator.setText(String.format(
                    Locale.getDefault(),
                    "%d / %d",
                    currentPage + 1,
                    pageCount
            ));
        }
    }

    private boolean hasEditOnCurrentPage() {
        for (EditAnnotation annotation : annotations) {
            if (annotation.pageIndex == currentPage) {
                return true;
            }
        }
        return false;
    }

    private void closeRenderer() {
        loaded = false;
        if (pageAdapter != null) {
            pageAdapter.shutdown();
            pageAdapter = null;
        }
        if (pdfList != null) {
            pdfList.setAdapter(null);
        }
        if (renderer != null) {
            try {
                synchronized (renderer) {
                    renderer.close();
                }
            } catch (Exception ignored) {
                // Already closed.
            }
            renderer = null;
        }
    }

    private void showLoadError(Exception exception) {
        setBusy(false, "Dokument sa nepodarilo načítať.");
        new AlertDialog.Builder(this)
                .setTitle("Dokument nemožno otvoriť")
                .setMessage(safeMessage(exception))
                .setPositiveButton("Zavrieť", (dialog, which) -> finish())
                .show();
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty()
                ? "Neznáma chyba."
                : message;
    }

    @Override
    protected void onDestroy() {
        closeRenderer();
        if (workingPdf != null && workingPdf.isFile()) {
            //noinspection ResultOfMethodCallIgnored
            workingPdf.delete();
        }
        super.onDestroy();
    }

    private static final class RendererData {
        final PdfRenderer renderer;
        final int[] widths;
        final int[] heights;

        RendererData(PdfRenderer renderer, int[] widths, int[] heights) {
            this.renderer = renderer;
            this.widths = widths;
            this.heights = heights;
        }
    }
}
