package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.util.LruCache;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class PdfPageAdapter extends BaseAdapter {
    private final Activity activity;
    private final PdfRenderer renderer;
    private final int[] pageWidths;
    private final int[] pageHeights;
    private final List<EditAnnotation> annotations;
    private final PdfEditView.RegionListener regionListener;
    private final PdfEditView.AnnotationListener annotationListener;
    private final LruCache<Integer, Bitmap> bitmapCache;
    private final Set<Integer> loadingPages = new HashSet<>();

    private EditAnnotation.Type mode;
    private boolean selectionMode;
    private boolean closed;

    PdfPageAdapter(
            Activity activity,
            PdfRenderer renderer,
            int[] pageWidths,
            int[] pageHeights,
            List<EditAnnotation> annotations,
            PdfEditView.RegionListener regionListener,
            PdfEditView.AnnotationListener annotationListener
    ) {
        this.activity = activity;
        this.renderer = renderer;
        this.pageWidths = pageWidths;
        this.pageHeights = pageHeights;
        this.annotations = annotations;
        this.regionListener = regionListener;
        this.annotationListener = annotationListener;

        int cacheKilobytes = 24 * 1024;
        bitmapCache = new LruCache<Integer, Bitmap>(cacheKilobytes) {
            @Override
            protected int sizeOf(Integer key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
    }

    void setTool(EditAnnotation.Type selectedMode, boolean selectExisting) {
        mode = selectedMode;
        selectionMode = selectExisting;
        notifyDataSetChanged();
    }

    void refreshAnnotations() {
        notifyDataSetChanged();
    }

    void shutdown() {
        closed = true;
        synchronized (loadingPages) {
            loadingPages.clear();
        }
        bitmapCache.evictAll();
    }

    @Override
    public int getCount() {
        return pageWidths.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        PdfEditView pageView;
        if (convertView instanceof PdfEditView) {
            pageView = (PdfEditView) convertView;
        } else {
            pageView = new PdfEditView(activity);
            pageView.setRegionListener(regionListener);
            pageView.setAnnotationListener(annotationListener);
        }
        pageView.setTag(position);
        pageView.preparePage(position);
        pageView.setAnnotations(annotations);
        pageView.setTool(mode, selectionMode);

        int availableWidth = Math.max(
                320,
                activity.getResources().getDisplayMetrics().widthPixels
                        - Ui.dp(activity, 12)
        );
        float aspect = (float) pageHeights[position]
                / Math.max(1, pageWidths[position]);
        int rowHeight = Math.max(
                Ui.dp(activity, 220),
                Math.round(availableWidth * aspect) + Ui.dp(activity, 14)
        );
        pageView.setLayoutParams(new AbsListView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                rowHeight
        ));

        Bitmap cached = bitmapCache.get(position);
        if (cached != null && !cached.isRecycled()) {
            pageView.setPage(cached, position);
        } else {
            loadPage(position);
        }
        return pageView;
    }

    private void loadPage(int position) {
        synchronized (loadingPages) {
            if (closed || loadingPages.contains(position)) {
                return;
            }
            loadingPages.add(position);
        }
        new Thread(() -> {
            Bitmap bitmap = null;
            try {
                bitmap = DocumentFiles.renderPdfPage(renderer, position, 1800);
            } catch (Exception ignored) {
                // The row remains as a white page if rendering fails.
            }
            final Bitmap rendered = bitmap;
            activity.runOnUiThread(() -> {
                synchronized (loadingPages) {
                    loadingPages.remove(position);
                }
                if (closed) {
                    if (rendered != null) {
                        rendered.recycle();
                    }
                    return;
                }
                if (rendered != null) {
                    bitmapCache.put(position, rendered);
                    notifyDataSetChanged();
                }
            });
        }, "pdf-scroll-page-" + position).start();
    }
}
