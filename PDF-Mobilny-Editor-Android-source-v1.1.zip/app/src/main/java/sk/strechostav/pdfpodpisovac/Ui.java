package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

final class Ui {
    private Ui() {
    }

    static int dp(Context context, float value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                context.getResources().getDisplayMetrics()
        ));
    }

    static TextView text(Context context, String value, float sp, int color) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setTextColor(color);
        return view;
    }

    static Button button(Context context, String label, boolean primary) {
        Button button = new Button(context);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        button.setTextColor(primary ? Color.WHITE : Color.rgb(164, 28, 28));
        button.setMinHeight(dp(context, 48));

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(context, 10));
        background.setColor(primary ? Color.rgb(198, 40, 40) : Color.WHITE);
        background.setStroke(dp(context, 1), Color.rgb(198, 40, 40));
        button.setBackground(background);
        button.setPadding(dp(context, 16), dp(context, 8), dp(context, 16), dp(context, 8));
        return button;
    }

    static Button iconToolButton(
            Context context,
            String label,
            int iconResource
    ) {
        Button button = new Button(context);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        button.setTextColor(Color.rgb(23, 78, 166));
        button.setGravity(Gravity.CENTER);
        button.setMinWidth(dp(context, 84));
        button.setMinHeight(dp(context, 76));
        button.setPadding(
                dp(context, 10),
                dp(context, 8),
                dp(context, 10),
                dp(context, 7)
        );
        button.setCompoundDrawablePadding(dp(context, 4));

        Drawable icon = context.getDrawable(iconResource);
        if (icon != null) {
            int iconSize = dp(context, 27);
            icon.setBounds(0, 0, iconSize, iconSize);
            button.setCompoundDrawables(null, icon, null, null);
        }

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(context, 13));
        background.setColor(Color.rgb(248, 250, 255));
        background.setStroke(dp(context, 1), Color.rgb(196, 210, 236));
        button.setBackground(background);
        button.setElevation(dp(context, 1));
        return button;
    }

    static Button squareToolButton(
            Context context,
            String label,
            int iconResource
    ) {
        Button button = new Button(context);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        button.setTextColor(Color.rgb(65, 68, 77));
        button.setGravity(Gravity.CENTER);
        button.setMinWidth(0);
        button.setMinHeight(0);
        button.setPadding(
                dp(context, 6),
                dp(context, 6),
                dp(context, 6),
                dp(context, 5)
        );
        button.setCompoundDrawablePadding(dp(context, 3));

        Drawable icon = context.getDrawable(iconResource);
        if (icon != null) {
            int iconSize = dp(context, 25);
            icon.setBounds(0, 0, iconSize, iconSize);
            button.setCompoundDrawables(null, icon, null, null);
        }
        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(context, 10));
        background.setColor(Color.WHITE);
        background.setStroke(dp(context, 1), Color.rgb(224, 226, 232));
        button.setBackground(background);
        button.setElevation(dp(context, 1));
        return button;
    }

    static GradientDrawable cardBackground(Context context) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(context, 16));
        background.setStroke(dp(context, 1), Color.rgb(220, 226, 235));
        return background;
    }

    static void setMargins(View view, int leftDp, int topDp, int rightDp, int bottomDp) {
        if (!(view.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams)) {
            return;
        }
        Context context = view.getContext();
        android.view.ViewGroup.MarginLayoutParams params =
                (android.view.ViewGroup.MarginLayoutParams) view.getLayoutParams();
        params.setMargins(
                dp(context, leftDp),
                dp(context, topDp),
                dp(context, rightDp),
                dp(context, bottomDp)
        );
        view.setLayoutParams(params);
    }
}
