package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public final class PdfEditView extends View {
    interface RegionListener {
        void onRegionSelected(EditAnnotation.Type type, int pageIndex, RectF normalizedRect);
    }

    interface AnnotationListener {
        void onAnnotationTapped(EditAnnotation annotation);

        void onAnnotationChanged(EditAnnotation annotation);
    }

    private final Paint bitmapPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint activePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF pageRect = new RectF();
    private final ArrayList<EditAnnotation> annotations = new ArrayList<>();

    private Bitmap pageBitmap;
    private int pageIndex;
    private EditAnnotation.Type mode;
    private boolean selectionMode;
    private RegionListener regionListener;
    private AnnotationListener annotationListener;

    private float startX;
    private float startY;
    private float currentX;
    private float currentY;
    private boolean selecting;

    private EditAnnotation activeAnnotation;
    private float lastNormalizedX;
    private float lastNormalizedY;
    private boolean resizingAnnotation;
    private boolean annotationMoved;

    public PdfEditView(Context context) {
        this(context, null);
    }

    public PdfEditView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(226, 230, 236));
        setFocusable(true);
        setClickable(true);

        shadowPaint.setColor(Color.argb(45, 0, 0, 0));
        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(Ui.dp(context, 2));
        selectionPaint.setColor(Color.rgb(198, 40, 40));
        selectionPaint.setPathEffect(new DashPathEffect(
                new float[]{Ui.dp(context, 7), Ui.dp(context, 5)},
                0f
        ));

        activePaint.setStyle(Paint.Style.STROKE);
        activePaint.setStrokeWidth(Ui.dp(context, 2));
        activePaint.setColor(Color.rgb(25, 118, 210));
    }

    void setRegionListener(RegionListener listener) {
        regionListener = listener;
    }

    void setAnnotationListener(AnnotationListener listener) {
        annotationListener = listener;
    }

    void setTool(EditAnnotation.Type selectedMode, boolean selectExisting) {
        mode = selectedMode;
        selectionMode = selectExisting;
        selecting = false;
        if (!selectExisting) {
            activeAnnotation = null;
        }
        invalidate();
    }

    void preparePage(int newPageIndex) {
        pageIndex = newPageIndex;
        pageBitmap = null;
        selecting = false;
        activeAnnotation = null;
        invalidate();
    }

    void setPage(Bitmap bitmap, int newPageIndex) {
        pageBitmap = bitmap;
        pageIndex = newPageIndex;
        selecting = false;
        invalidate();
    }

    void clearPage() {
        pageBitmap = null;
        selecting = false;
        activeAnnotation = null;
        invalidate();
    }

    void setAnnotations(List<EditAnnotation> source) {
        annotations.clear();
        annotations.addAll(source);
        if (activeAnnotation != null && !annotations.contains(activeAnnotation)) {
            activeAnnotation = null;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        calculatePageRect();
        if (pageRect.isEmpty()) {
            return;
        }

        RectF shadow = new RectF(pageRect);
        shadow.offset(Ui.dp(getContext(), 3), Ui.dp(getContext(), 4));
        canvas.drawRect(shadow, shadowPaint);
        Paint white = new Paint();
        white.setColor(Color.WHITE);
        canvas.drawRect(pageRect, white);

        if (pageBitmap == null) {
            Paint message = new Paint(Paint.ANTI_ALIAS_FLAG);
            message.setColor(Color.GRAY);
            message.setTextAlign(Paint.Align.CENTER);
            message.setTextSize(Ui.dp(getContext(), 14));
            canvas.drawText(
                    "Načítavam stranu " + (pageIndex + 1) + "…",
                    pageRect.centerX(),
                    pageRect.centerY(),
                    message
            );
            return;
        }

        canvas.drawBitmap(pageBitmap, null, pageRect, bitmapPaint);
        for (EditAnnotation annotation : annotations) {
            if (annotation.pageIndex == pageIndex) {
                AnnotationPainter.draw(canvas, annotation, pageRect);
            }
        }
        if (activeAnnotation != null && activeAnnotation.pageIndex == pageIndex) {
            drawActiveAnnotation(canvas, activeAnnotation);
        }
        if (selecting) {
            canvas.drawRect(sortedSelectionRect(), selectionPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled() || pageBitmap == null) {
            return false;
        }
        calculatePageRect();
        if (selectionMode) {
            return handleAnnotationEditing(event);
        }
        if (mode != null) {
            return handleNewRegion(event);
        }
        return false;
    }

    private boolean handleNewRegion(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!pageRect.contains(event.getX(), event.getY())) {
                    return false;
                }
                getParent().requestDisallowInterceptTouchEvent(true);
                startX = clamp(event.getX(), pageRect.left, pageRect.right);
                startY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                currentX = startX;
                currentY = startY;
                selecting = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (selecting) {
                    currentX = clamp(event.getX(), pageRect.left, pageRect.right);
                    currentY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (selecting) {
                    currentX = clamp(event.getX(), pageRect.left, pageRect.right);
                    currentY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                    RectF normalized = normalizedSelection();
                    selecting = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    invalidate();
                    if (regionListener != null) {
                        regionListener.onRegionSelected(mode, pageIndex, normalized);
                    }
                    performClick();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                selecting = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private boolean handleAnnotationEditing(MotionEvent event) {
        float normalizedX = (event.getX() - pageRect.left) / pageRect.width();
        float normalizedY = (event.getY() - pageRect.top) / pageRect.height();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!pageRect.contains(event.getX(), event.getY())) {
                    return false;
                }
                activeAnnotation = findAnnotationAt(normalizedX, normalizedY);
                if (activeAnnotation == null) {
                    invalidate();
                    return false;
                }
                getParent().requestDisallowInterceptTouchEvent(true);
                lastNormalizedX = normalizedX;
                lastNormalizedY = normalizedY;
                annotationMoved = false;
                float handleSize = Math.max(
                        0.025f,
                        Ui.dp(getContext(), 24) / pageRect.width()
                );
                resizingAnnotation =
                        Math.abs(normalizedX - activeAnnotation.rect.right) <= handleSize
                                && Math.abs(normalizedY - activeAnnotation.rect.bottom)
                                <= handleSize;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeAnnotation == null) {
                    return false;
                }
                float dx = normalizedX - lastNormalizedX;
                float dy = normalizedY - lastNormalizedY;
                if (Math.abs(dx) + Math.abs(dy) > 0.002f) {
                    annotationMoved = true;
                }
                if (resizingAnnotation) {
                    activeAnnotation.rect.right = clamp(
                            normalizedX,
                            activeAnnotation.rect.left + 0.025f,
                            1f
                    );
                    activeAnnotation.rect.bottom = clamp(
                            normalizedY,
                            activeAnnotation.rect.top + 0.018f,
                            1f
                    );
                } else {
                    moveAnnotation(activeAnnotation, dx, dy);
                }
                lastNormalizedX = normalizedX;
                lastNormalizedY = normalizedY;
                if (annotationListener != null) {
                    annotationListener.onAnnotationChanged(activeAnnotation);
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                getParent().requestDisallowInterceptTouchEvent(false);
                if (activeAnnotation != null && !annotationMoved
                        && annotationListener != null) {
                    annotationListener.onAnnotationTapped(activeAnnotation);
                }
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            default:
                return true;
        }
    }

    private void drawActiveAnnotation(Canvas canvas, EditAnnotation annotation) {
        RectF rect = annotationRectOnScreen(annotation);
        canvas.drawRect(rect, activePaint);
        Paint handle = new Paint(Paint.ANTI_ALIAS_FLAG);
        handle.setColor(Color.WHITE);
        canvas.drawCircle(
                rect.right,
                rect.bottom,
                Ui.dp(getContext(), 7),
                handle
        );
        handle.setStyle(Paint.Style.STROKE);
        handle.setStrokeWidth(Ui.dp(getContext(), 2));
        handle.setColor(Color.rgb(25, 118, 210));
        canvas.drawCircle(
                rect.right,
                rect.bottom,
                Ui.dp(getContext(), 7),
                handle
        );
    }

    private EditAnnotation findAnnotationAt(float x, float y) {
        for (int index = annotations.size() - 1; index >= 0; index--) {
            EditAnnotation annotation = annotations.get(index);
            if (annotation.pageIndex == pageIndex && annotation.rect.contains(x, y)) {
                return annotation;
            }
        }
        return null;
    }

    private void moveAnnotation(EditAnnotation annotation, float dx, float dy) {
        float width = annotation.rect.width();
        float height = annotation.rect.height();
        float left = clamp(annotation.rect.left + dx, 0f, 1f - width);
        float top = clamp(annotation.rect.top + dy, 0f, 1f - height);
        annotation.rect.set(left, top, left + width, top + height);
    }

    private RectF annotationRectOnScreen(EditAnnotation annotation) {
        return new RectF(
                pageRect.left + annotation.rect.left * pageRect.width(),
                pageRect.top + annotation.rect.top * pageRect.height(),
                pageRect.left + annotation.rect.right * pageRect.width(),
                pageRect.top + annotation.rect.bottom * pageRect.height()
        );
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private RectF normalizedSelection() {
        RectF selected = sortedSelectionRect();
        float left = (selected.left - pageRect.left) / pageRect.width();
        float top = (selected.top - pageRect.top) / pageRect.height();
        float right = (selected.right - pageRect.left) / pageRect.width();
        float bottom = (selected.bottom - pageRect.top) / pageRect.height();
        if (right - left < 0.025f) {
            right = Math.min(1f, left + 0.025f);
        }
        if (bottom - top < 0.018f) {
            bottom = Math.min(1f, top + 0.018f);
        }
        return new RectF(left, top, right, bottom);
    }

    private RectF sortedSelectionRect() {
        return new RectF(
                Math.min(startX, currentX),
                Math.min(startY, currentY),
                Math.max(startX, currentX),
                Math.max(startY, currentY)
        );
    }

    private void calculatePageRect() {
        if (getWidth() <= 0 || getHeight() <= 0) {
            pageRect.setEmpty();
            return;
        }
        float horizontalPadding = Ui.dp(getContext(), 8);
        float verticalPadding = Ui.dp(getContext(), 7);
        pageRect.set(
                horizontalPadding,
                verticalPadding,
                getWidth() - horizontalPadding,
                getHeight() - verticalPadding
        );
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
