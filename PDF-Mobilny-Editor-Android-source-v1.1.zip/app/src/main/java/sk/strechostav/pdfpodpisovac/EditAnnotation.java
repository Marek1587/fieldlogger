package sk.strechostav.pdfpodpisovac;

import android.graphics.Color;
import android.graphics.RectF;

final class EditAnnotation {
    enum Type {
        REPLACE_TEXT,
        HIGHLIGHT,
        UNDERLINE,
        STRIKEOUT
    }

    Type type;
    int pageIndex;
    final RectF rect;
    String text;
    String comment;
    int color;

    EditAnnotation(Type type, int pageIndex, RectF rect) {
        this.type = type;
        this.pageIndex = pageIndex;
        this.rect = new RectF(rect);
        this.text = "";
        this.comment = "";
        this.color = type == Type.HIGHLIGHT
                ? Color.argb(105, 255, 221, 45)
                : Color.rgb(198, 40, 40);
    }

    EditAnnotation copy() {
        EditAnnotation copy = new EditAnnotation(type, pageIndex, rect);
        copy.text = text;
        copy.comment = comment;
        copy.color = color;
        return copy;
    }
}
