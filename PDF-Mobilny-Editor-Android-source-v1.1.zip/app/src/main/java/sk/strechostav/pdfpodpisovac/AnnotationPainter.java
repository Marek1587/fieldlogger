package sk.strechostav.pdfpodpisovac;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

import java.util.ArrayList;

final class AnnotationPainter {
    private AnnotationPainter() {
    }

    static void draw(
            Canvas canvas,
            EditAnnotation annotation,
            RectF pageRect
    ) {
        RectF rect = new RectF(
                pageRect.left + annotation.rect.left * pageRect.width(),
                pageRect.top + annotation.rect.top * pageRect.height(),
                pageRect.left + annotation.rect.right * pageRect.width(),
                pageRect.top + annotation.rect.bottom * pageRect.height()
        );
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        switch (annotation.type) {
            case HIGHLIGHT:
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(annotation.color);
                canvas.drawRect(rect, paint);
                break;
            case UNDERLINE:
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeWidth(Math.max(1.5f, pageRect.height() * 0.0028f));
                paint.setColor(annotation.color);
                canvas.drawLine(
                        rect.left,
                        rect.bottom - rect.height() * 0.08f,
                        rect.right,
                        rect.bottom - rect.height() * 0.08f,
                        paint
                );
                break;
            case STRIKEOUT:
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeWidth(Math.max(1.5f, pageRect.height() * 0.0028f));
                paint.setColor(annotation.color);
                canvas.drawLine(
                        rect.left,
                        rect.centerY(),
                        rect.right,
                        rect.centerY(),
                        paint
                );
                break;
            case REPLACE_TEXT:
                drawReplacement(canvas, rect, annotation.text);
                break;
        }
        if (annotation.comment != null && !annotation.comment.trim().isEmpty()) {
            drawCommentNote(canvas, rect, pageRect, annotation.comment.trim());
        }
    }

    private static void drawCommentNote(
            Canvas canvas,
            RectF rect,
            RectF pageRect,
            String comment
    ) {
        float radius = Math.max(5f, pageRect.width() * 0.013f);
        float centerX = Math.min(pageRect.right - radius, rect.right);
        float centerY = Math.max(pageRect.top + radius, rect.top);
        Paint marker = new Paint(Paint.ANTI_ALIAS_FLAG);
        marker.setColor(Color.rgb(198, 40, 40));
        canvas.drawCircle(centerX, centerY, radius, marker);
        marker.setColor(Color.WHITE);
        marker.setTextAlign(Paint.Align.CENTER);
        marker.setFakeBoldText(true);
        marker.setTextSize(radius * 1.35f);
        Paint.FontMetrics metrics = marker.getFontMetrics();
        float baseline = centerY - (metrics.ascent + metrics.descent) / 2f;
        canvas.drawText("i", centerX, baseline, marker);

        float textSize = Math.max(5f, pageRect.height() * 0.013f);
        float padding = textSize * 0.55f;
        float noteWidth = Math.min(
                pageRect.width() * 0.46f,
                Math.max(pageRect.width() * 0.24f, textSize * 22f)
        );
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.rgb(55, 48, 30));
        textPaint.setTextSize(textSize);
        ArrayList<String> lines = wrapComment(
                comment,
                textPaint,
                noteWidth - padding * 2f,
                3
        );
        Paint.FontMetrics textMetrics = textPaint.getFontMetrics();
        float lineHeight = (textMetrics.descent - textMetrics.ascent) * 1.1f;
        float noteHeight = padding * 2f + lineHeight * lines.size();
        float noteLeft = clamp(
                rect.left,
                pageRect.left,
                pageRect.right - noteWidth
        );
        float noteTop = rect.bottom + padding * 0.5f;
        if (noteTop + noteHeight > pageRect.bottom) {
            noteTop = Math.max(pageRect.top, rect.top - noteHeight - padding * 0.5f);
        }
        RectF note = new RectF(
                noteLeft,
                noteTop,
                noteLeft + noteWidth,
                noteTop + noteHeight
        );
        Paint notePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        notePaint.setColor(Color.rgb(255, 249, 196));
        notePaint.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(note, padding, padding, notePaint);
        notePaint.setStyle(Paint.Style.STROKE);
        notePaint.setStrokeWidth(Math.max(1f, pageRect.width() * 0.0015f));
        notePaint.setColor(Color.rgb(198, 40, 40));
        canvas.drawRoundRect(note, padding, padding, notePaint);

        float textBaseline = note.top + padding - textMetrics.ascent;
        for (String line : lines) {
            canvas.drawText(line, note.left + padding, textBaseline, textPaint);
            textBaseline += lineHeight;
        }
    }

    private static ArrayList<String> wrapComment(
            String comment,
            Paint paint,
            float maxWidth,
            int maxLines
    ) {
        ArrayList<String> lines = new ArrayList<>();
        String[] words = comment.replace('\n', ' ').trim().split("\\s+");
        StringBuilder current = new StringBuilder();
        for (String word : words) {
            String candidate = current.length() == 0
                    ? word
                    : current + " " + word;
            if (paint.measureText(candidate) <= maxWidth || current.length() == 0) {
                current.setLength(0);
                current.append(candidate);
            } else {
                lines.add(current.toString());
                current.setLength(0);
                current.append(word);
                if (lines.size() == maxLines) {
                    break;
                }
            }
        }
        if (lines.size() < maxLines && current.length() > 0) {
            lines.add(current.toString());
        }
        if (lines.isEmpty()) {
            lines.add(comment);
        }
        if (lines.size() == maxLines && words.length > 0) {
            int lastIndex = lines.size() - 1;
            String last = lines.get(lastIndex);
            if (!last.endsWith("…")) {
                lines.set(lastIndex, last + "…");
            }
        }
        return lines;
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static void drawReplacement(Canvas canvas, RectF rect, String value) {
        Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        background.setColor(Color.WHITE);
        background.setStyle(Paint.Style.FILL);
        canvas.drawRect(rect, background);

        String text = value == null ? "" : value;
        if (text.isEmpty()) {
            return;
        }
        String[] lines = text.split("\\n", -1);
        float padding = Math.max(1f, rect.height() * 0.08f);
        float availableWidth = Math.max(1f, rect.width() - padding * 2f);
        float availableHeight = Math.max(1f, rect.height() - padding * 2f);
        float textSize = Math.max(
                3f,
                Math.min(rect.height() * 0.68f, availableHeight / Math.max(1, lines.length))
        );

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        textPaint.setColor(Color.rgb(25, 25, 25));
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextSize(textSize);

        float widest = 0f;
        for (String line : lines) {
            widest = Math.max(widest, textPaint.measureText(line));
        }
        if (widest > availableWidth) {
            textSize *= availableWidth / widest;
            textPaint.setTextSize(Math.max(3f, textSize));
        }

        Paint.FontMetrics metrics = textPaint.getFontMetrics();
        float lineHeight = metrics.descent - metrics.ascent;
        float totalHeight = lineHeight * lines.length;
        if (totalHeight > availableHeight) {
            textPaint.setTextSize(
                    Math.max(3f, textPaint.getTextSize() * availableHeight / totalHeight)
            );
            metrics = textPaint.getFontMetrics();
            lineHeight = metrics.descent - metrics.ascent;
            totalHeight = lineHeight * lines.length;
        }
        float baseline = rect.top + padding
                + Math.max(0f, (availableHeight - totalHeight) / 2f)
                - metrics.ascent;
        canvas.save();
        canvas.clipRect(rect);
        for (String line : lines) {
            canvas.drawText(line, rect.left + padding, baseline, textPaint);
            baseline += lineHeight;
        }
        canvas.restore();
    }
}
