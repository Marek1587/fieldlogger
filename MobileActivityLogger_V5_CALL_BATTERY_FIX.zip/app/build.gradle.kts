plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.strechostav.mobileactivity"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.mobileactivity"
        minSdk = 26
        targetSdk = 28
        versionCode = 6
        versionName = "2.3-call-battery-fix"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
