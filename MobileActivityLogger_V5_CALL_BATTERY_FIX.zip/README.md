# Mobile Activity Logger V5 - Call + Battery Fix

## Changes

- Battery notification / charging percentage screen is ignored.
- Notification shade battery spam is filtered:
  - "Nabíja sa batéria, 75%" no longer writes SCREEN_CONTEXT.
- Call handling improved:
  - package incallui alone is not treated as a call
  - real call controls must be visible
  - own "O čom bol hovor?" dialog is ignored by call detector
  - screen off/on does not immediately end the call
  - call ends only after call screen has not been seen for about 75 seconds
  - CALL_NOTE opens only once
- Google Maps navigation remains start/end only.
