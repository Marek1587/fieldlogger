package sk.strechasketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.tan

/**
 * Deterministic rainwater-system solver derived from the solved RoofGraph.
 *
 * Gutters exist only below EAVE boundaries. Downspouts are distributed so the plan
 * distance from the beginning of a run and between consecutive outlets never exceeds
 * [MAX_DOWNSPOUT_SPACING_M]. The default system is rebuilt after every parametric roof edit.
 * Only user overrides (position, termination, manually added or suppressed outlets) are
 * persisted, so derived geometry never becomes a second copy of the roof topology.
 */
internal object RainwaterDrainageSolver {
    const val GUTTER_WIDTH_M = 0.120
    const val GUTTER_EDGE_OFFSET_M = 0.030
    const val GUTTER_SLOPE_DEG = 1.5
    const val MAX_DOWNSPOUT_SPACING_M = 12.0
    const val DOWNSPOUT_DIAMETER_M = 0.100
    const val ELBOW_ANGLE_DEG = 72.0
    const val CONNECTOR_FALL_DEG = 90.0 - ELBOW_ANGLE_DEG

    internal data class ProfilePoint(
        val t: Double,
        val center: LocalPoint,
        val elevationZ: Double,
        val outlet: Boolean
    )

    internal data class GutterRun(
        val edgeId: String,
        val start: GraphNode,
        val end: GraphNode,
        val outwardX: Double,
        val outwardY: Double,
        val outletTs: List<Double>,
        val profile: List<ProfilePoint>
    ) {
        val lengthM: Double get() = hypot(end.x - start.x, end.y - start.y)

        fun planPoint(t: Double, offsetM: Double): LocalPoint = LocalPoint(
            start.x + (end.x - start.x) * t + outwardX * offsetM,
            start.y + (end.y - start.y) * t + outwardY * offsetM
        )

        fun bandCorners(): List<LocalPoint> = listOf(
            planPoint(0.0, GUTTER_EDGE_OFFSET_M),
            planPoint(1.0, GUTTER_EDGE_OFFSET_M),
            planPoint(1.0, GUTTER_EDGE_OFFSET_M + GUTTER_WIDTH_M),
            planPoint(0.0, GUTTER_EDGE_OFFSET_M + GUTTER_WIDTH_M)
        )
    }

    internal data class Downspout(
        val id: String,
        val edgeIds: Set<String>,
        val primaryEdgeId: String,
        val edgeT: Double,
        val eavePoint: LocalPoint,
        val gutterPoint: LocalPoint,
        val gutterElevationZ: Double,
        val wallPoint: LocalPoint,
        val automatic: Boolean,
        val termination: DownspoutTermination
    )

    internal data class Solution(
        val gutters: List<GutterRun>,
        val downspouts: List<Downspout>
    ) {
        val gutterLengthM: Double get() = gutters.sumOf { it.lengthM }
    }

    private data class Candidate(
        val id: String,
        val edgeId: String,
        val t: Double,
        val eavePoint: LocalPoint,
        val gutterPoint: LocalPoint,
        val gutterElevationZ: Double,
        val automatic: Boolean,
        val termination: DownspoutTermination
    )

    private data class EaveSeed(
        val edge: GraphEdge,
        val start: GraphNode,
        val end: GraphNode,
        val outwardX: Double,
        val outwardY: Double
    )

    fun solve(
        graph: RoofGraph,
        wallLoop: List<LocalPoint> = emptyList(),
        explicitObjects: List<RoofObject> = emptyList()
    ): Solution {
        val eaves = graph.edges.values.asSequence()
            .filter { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
            .sortedBy { it.id }
            .mapNotNull { edge ->
                val a = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                val b = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                val length = hypot(b.x - a.x, b.y - a.y)
                if (length <= 1e-6) return@mapNotNull null
                val face = edge.adjacentFaceIds.asSequence().mapNotNull(graph.faces::get).firstOrNull()
                val faceNodes = face?.orderedNodeIds?.mapNotNull(graph.nodes::get).orEmpty()
                val faceCenter = faceNodes.takeIf { it.isNotEmpty() }?.let { nodes ->
                    LocalPoint(nodes.map { it.x }.average(), nodes.map { it.y }.average())
                }
                val mid = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
                var normalX = -(b.y - a.y) / length
                var normalY = (b.x - a.x) / length
                if (faceCenter != null &&
                    (faceCenter.x - mid.x) * normalX + (faceCenter.y - mid.y) * normalY > 0.0
                ) {
                    normalX = -normalX
                    normalY = -normalY
                }
                EaveSeed(edge, a, b, normalX, normalY)
            }.toList()
        if (eaves.isEmpty()) return Solution(emptyList(), emptyList())

        val downspoutConfigs = explicitObjects.asSequence()
            .filter { it.type == ObjectType.DOWNSPOUT }
            .map { item -> item to Geometry.toLocal(item.center, graph.origin) }
            .toList()
        val configById = downspoutConfigs.associate { it.first.id to it }
        val suppressedIds = downspoutConfigs.asSequence()
            .filter { it.first.downspoutSuppressed }
            .map { it.first.id }
            .toSet()

        val runs = arrayListOf<GutterRun>()
        val candidates = arrayListOf<Candidate>()
        eaves.forEach { seed ->
            val edge = seed.edge
            val a = seed.start
            val b = seed.end
            val outwardX = seed.outwardX
            val outwardY = seed.outwardY
            val length = hypot(b.x - a.x, b.y - a.y)
            val automaticCount = max(1, ceil(length / MAX_DOWNSPOUT_SPACING_M).toInt())
            val automaticCandidates = (1..automaticCount).mapNotNull { index ->
                val id = automaticId(edge.id, index)
                if (id in suppressedIds) return@mapNotNull null
                val configured = configById[id]
                val t = configured?.second?.let { point ->
                    projectionT(point, LocalPoint(a.x, a.y), LocalPoint(b.x, b.y))
                } ?: (index.toDouble() / automaticCount)
                Triple(id, t, configured?.first?.downspoutTermination ?: DownspoutTermination.ELBOW_72)
            }
            val manualCandidates = downspoutConfigs.mapNotNull { (item, point) ->
                if (item.downspoutAutomatic || item.downspoutSuppressed) return@mapNotNull null
                val belongs = item.attachedEdgeId == edge.id || (
                    item.attachedEdgeId == null && nearestEaveId(point, eaves) == edge.id
                )
                if (!belongs) return@mapNotNull null
                val t = projectionT(point, LocalPoint(a.x, a.y), LocalPoint(b.x, b.y))
                val projected = LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
                if (item.attachedEdgeId == edge.id || hypot(projected.x - point.x, projected.y - point.y) <= 0.75) {
                    Triple(item.id, t, item.downspoutTermination)
                } else null
            }
            // Manual positions win inside the 150 mm de-duplication tolerance.
            val configuredCandidates = (manualCandidates.map { (id, t, termination) ->
                Triple(id, t.coerceIn(0.0, 1.0), termination)
            } + automaticCandidates.map { (id, t, termination) ->
                Triple(id, t.coerceIn(0.0, 1.0), termination)
            }).sortedBy { it.second }
                .fold(mutableListOf<Triple<String, Double, DownspoutTermination>>()) { output, value ->
                    if (output.none { abs(it.second - value.second) * length < 0.15 }) output += value
                    output
                }
            val outletTs = configuredCandidates.map { it.second }
            val profile = profile(a, b, outwardX, outwardY, outletTs)
            val run = GutterRun(edge.id, a, b, outwardX, outwardY, outletTs, profile)
            runs += run
            configuredCandidates.forEach { (id, t, termination) ->
                val automatic = id.startsWith("rain-downspout-auto-")
                val eavePoint = run.planPoint(t, 0.0)
                val gutterPoint = run.planPoint(t, GUTTER_EDGE_OFFSET_M + GUTTER_WIDTH_M / 2.0)
                val elevation = profile.firstOrNull { it.outlet && abs(it.t - t) < 1e-7 }?.elevationZ
                    ?: interpolateZ(a, b, t) - 0.03
                candidates += Candidate(id, edge.id, t, eavePoint, gutterPoint, elevation, automatic, termination)
            }
        }

        val downspouts = arrayListOf<Downspout>()
        candidates.sortedWith(compareBy<Candidate>({ it.gutterPoint.x }, { it.gutterPoint.y }, { it.edgeId }))
            .forEach { candidate ->
                val existingIndex = downspouts.indexOfFirst {
                    hypot(it.gutterPoint.x - candidate.gutterPoint.x, it.gutterPoint.y - candidate.gutterPoint.y) < 0.12
                }
                if (existingIndex >= 0) {
                    val existing = downspouts[existingIndex]
                    downspouts[existingIndex] = existing.copy(
                        edgeIds = existing.edgeIds + candidate.edgeId,
                        gutterElevationZ = minOf(existing.gutterElevationZ, candidate.gutterElevationZ),
                        automatic = existing.automatic && candidate.automatic,
                        termination = if (existing.automatic) candidate.termination else existing.termination
                    )
                } else {
                    val wallPoint = closestPointOnLoop(candidate.gutterPoint, wallLoop) ?: candidate.eavePoint
                    downspouts += Downspout(
                        id = candidate.id,
                        edgeIds = setOf(candidate.edgeId),
                        primaryEdgeId = candidate.edgeId,
                        edgeT = candidate.t,
                        eavePoint = candidate.eavePoint,
                        gutterPoint = candidate.gutterPoint,
                        gutterElevationZ = candidate.gutterElevationZ,
                        wallPoint = wallPoint,
                        automatic = candidate.automatic,
                        termination = candidate.termination
                    )
                }
            }
        return Solution(runs, downspouts)
    }

    fun automaticId(edgeId: String, oneBasedIndex: Int): String =
        "rain-downspout-auto-$edgeId-$oneBasedIndex"

    private fun nearestEaveId(point: LocalPoint, eaves: List<EaveSeed>): String? =
        eaves.minByOrNull { seed ->
            val a = LocalPoint(seed.start.x, seed.start.y)
            val b = LocalPoint(seed.end.x, seed.end.y)
            val t = projectionT(point, a, b)
            hypot(point.x - (a.x + (b.x - a.x) * t), point.y - (a.y + (b.y - a.y) * t))
        }?.edge?.id

    private fun profile(
        a: GraphNode,
        b: GraphNode,
        outwardX: Double,
        outwardY: Double,
        outletTs: List<Double>
    ): List<ProfilePoint> {
        val length = hypot(b.x - a.x, b.y - a.y).coerceAtLeast(1e-9)
        val breaks = mutableListOf(0.0)
        breaks += outletTs
        outletTs.zipWithNext().forEach { (from, to) -> breaks += (from + to) / 2.0 }
        val ordered = breaks.sorted().fold(mutableListOf<Double>()) { output, value ->
            if (output.none { abs(it - value) < 1e-8 }) output += value
            output
        }
        val slope = tan(GUTTER_SLOPE_DEG * PI / 180.0)
        return ordered.map { t ->
            val outletIndex = outletTs.indexOfFirst { abs(it - t) < 1e-8 }
            val drop = if (outletIndex >= 0) {
                val previousHigh = if (outletIndex == 0) 0.0 else (outletTs[outletIndex - 1] + t) / 2.0
                val nextHigh = if (outletIndex == outletTs.lastIndex) t
                    else (t + outletTs[outletIndex + 1]) / 2.0
                max(t - previousHigh, nextHigh - t) * length * slope
            } else 0.0
            val centerOffset = GUTTER_EDGE_OFFSET_M + GUTTER_WIDTH_M / 2.0
            ProfilePoint(
                t = t,
                center = LocalPoint(
                    a.x + (b.x - a.x) * t + outwardX * centerOffset,
                    a.y + (b.y - a.y) * t + outwardY * centerOffset
                ),
                elevationZ = interpolateZ(a, b, t) - 0.03 - drop,
                outlet = outletIndex >= 0
            )
        }
    }

    private fun interpolateZ(a: GraphNode, b: GraphNode, t: Double) = a.z + (b.z - a.z) * t

    private fun projectionT(point: LocalPoint, a: LocalPoint, b: LocalPoint): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val denominator = dx * dx + dy * dy
        if (denominator <= 1e-12) return 0.0
        return (((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator).coerceIn(0.0, 1.0)
    }

    private fun closestPointOnLoop(point: LocalPoint, loop: List<LocalPoint>): LocalPoint? {
        if (loop.size < 2) return null
        return loop.indices.map { index ->
            val a = loop[index]
            val b = loop[(index + 1) % loop.size]
            val t = projectionT(point, a, b)
            LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)
        }.minByOrNull { candidate -> hypot(candidate.x - point.x, candidate.y - point.y) }
    }
}
