package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.tan

/**
 * Makes an off-centre gable tract vertically solvable without moving its ridge.
 *
 * With equal eave elevations, unequal plan runs cannot use equal pitch angles and
 * still meet at one ridge height. For a ridge joining two opposite gables this pass
 * preserves one common rise and derives the missing per-face pitch constraints.
 */
internal object GableTractSlopeSolver {
    private data class FaceRun(
        val faceId: String,
        val runM: Double,
        val downhillX: Double,
        val downhillY: Double
    )

    private const val PARALLEL_TOLERANCE_DEG = 3.0
    private const val EPSILON = 1e-7

    fun apply(input: RoofGraph, defaultSlopeDeg: Double): RoofGraph {
        val faces = input.faces.toMutableMap()
        input.edges.values.asSequence()
            .filter { it.semanticRole == EdgeSemantic.RIDGE && it.adjacentFaceIds.size == 2 }
            .sortedBy { it.id }
            .forEach { ridge ->
                val ridgeStart = input.nodes[ridge.startNodeId] ?: return@forEach
                val ridgeEnd = input.nodes[ridge.endNodeId] ?: return@forEach
                if (!isGableContact(input, ridge.startNodeId) || !isGableContact(input, ridge.endNodeId)) {
                    return@forEach
                }
                val ridgeDx = ridgeEnd.x - ridgeStart.x
                val ridgeDy = ridgeEnd.y - ridgeStart.y
                val ridgeLength = hypot(ridgeDx, ridgeDy)
                if (ridgeLength <= EPSILON) return@forEach
                val ridgeMidX = (ridgeStart.x + ridgeEnd.x) / 2.0
                val ridgeMidY = (ridgeStart.y + ridgeEnd.y) / 2.0

                val runs = ridge.adjacentFaceIds.sorted().mapNotNull { faceId ->
                    val face = faces[faceId] ?: return@mapNotNull null
                    val eave = face.orderedEdgeIds.mapNotNull(input.edges::get)
                        .filter { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
                        .filter { edge ->
                            val a = input.nodes[edge.startNodeId] ?: return@filter false
                            val b = input.nodes[edge.endNodeId] ?: return@filter false
                            val dx = b.x - a.x
                            val dy = b.y - a.y
                            val length = hypot(dx, dy)
                            length > EPSILON && abs(dx * ridgeDy - dy * ridgeDx) /
                                (length * ridgeLength) <= kotlin.math.sin(Math.toRadians(PARALLEL_TOLERANCE_DEG))
                        }
                        .maxByOrNull { edgeLength(input, it) }
                        ?: return@mapNotNull null
                    val eaveStart = input.nodes.getValue(eave.startNodeId)
                    val eaveEnd = input.nodes.getValue(eave.endNodeId)
                    val eaveMidX = (eaveStart.x + eaveEnd.x) / 2.0
                    val eaveMidY = (eaveStart.y + eaveEnd.y) / 2.0
                    val normalX = -ridgeDy / ridgeLength
                    val normalY = ridgeDx / ridgeLength
                    val signedRun = (eaveMidX - ridgeMidX) * normalX + (eaveMidY - ridgeMidY) * normalY
                    val run = abs(signedRun)
                    if (run <= EPSILON) return@mapNotNull null
                    val sign = if (signedRun < 0.0) -1.0 else 1.0
                    FaceRun(faceId, run, normalX * sign, normalY * sign)
                }
                if (runs.size != 2) return@forEach

                val firstFace = faces.getValue(runs[0].faceId)
                val secondFace = faces.getValue(runs[1].faceId)
                if (firstFace.slopeConstraint != null && secondFace.slopeConstraint != null) return@forEach

                val explicit = listOf(runs[0] to firstFace, runs[1] to secondFace)
                    .firstOrNull { it.second.slopeConstraint != null }
                val rise = explicit?.let { (run, face) ->
                    tan(Math.toRadians(face.slopeConstraint!!.angleDeg.coerceIn(0.0, 75.0))) * run.runM
                } ?: tan(Math.toRadians(defaultSlopeDeg.coerceIn(0.0, 75.0))) *
                    ((runs[0].runM + runs[1].runM) / 2.0)
                if (!rise.isFinite() || rise < 0.0) return@forEach

                runs.forEach { run ->
                    val face = faces.getValue(run.faceId)
                    if (face.slopeConstraint == null) {
                        val angle = Math.toDegrees(atan(rise / run.runM)).coerceIn(0.0, 75.0)
                        faces[run.faceId] = face.copy(
                            slopeConstraint = FaceSlopeConstraint(
                                angleDeg = angle,
                                directionX = run.downhillX,
                                directionY = run.downhillY,
                                hard = true
                            )
                        )
                    }
                }
            }
        return input.copy(faces = faces)
    }

    private fun isGableContact(graph: RoofGraph, nodeId: String): Boolean {
        val incident = graph.edges.values.filter {
            it.boundary && (it.startNodeId == nodeId || it.endNodeId == nodeId)
        }
        return incident.size == 2 && incident.all { it.semanticRole == EdgeSemantic.GABLE }
    }

    private fun edgeLength(graph: RoofGraph, edge: GraphEdge): Double {
        val a = graph.nodes[edge.startNodeId] ?: return 0.0
        val b = graph.nodes[edge.endNodeId] ?: return 0.0
        return hypot(b.x - a.x, b.y - a.y)
    }
}
