package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.tan

class Roof3DPreparationTest {
    private val origin = GeoPoint(49.0, 18.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    @Test
    fun lFootprintWithTwoGablesRidgesHipAndValleyBuildsFourRoofFaces() {
        val junction = geo(4.0, 4.0)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(16.0, 0.0), geo(16.0, 8.0),
                geo(8.0, 8.0), geo(8.0, 16.0), geo(0.0, 16.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.GABLE, 2 to LineType.EAVE,
                3 to LineType.EAVE, 4 to LineType.GABLE, 5 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(4.0, 16.0), end = junction.copy()),
                RoofLine(type = LineType.VALLEY, start = junction.copy(), end = geo(8.0, 8.0)),
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = junction.copy()),
                RoofLine(type = LineType.RIDGE, start = junction.copy(), end = geo(16.0, 4.0))
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val internalDividerEdges = prepared.graph.edges.values.filter {
            !it.boundary && it.semanticRole in setOf(
                EdgeSemantic.RIDGE, EdgeSemantic.HIP, EdgeSemantic.VALLEY
            )
        }

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message },
            !prepared.planeSolution.hasBlockingIssues)
        assertTrue(internalDividerEdges.isNotEmpty())
        assertTrue(internalDividerEdges.all { it.adjacentFaceIds.size == 2 })
        assertTrue(RoofMeshBuilder.build(project).triangles.isNotEmpty())
        assertTrue(RoofQuantityEngine.calculate(project).totals.roofAreaM2 > 0.0)
    }

    @Test
    fun roofLogoUsesUnmirroredSourceMappingForBothRenderers() {
        assertEquals(0f, StrechoStavLogo.roofSurfaceU(left = true), 0f)
        assertEquals(1f, StrechoStavLogo.roofSurfaceU(left = false), 0f)
        assertTrue(StrechoStavLogo.roofSurfaceSourceCorners(100, 40).contentEquals(
            floatArrayOf(0f, 0f, 100f, 0f, 100f, 40f, 0f, 40f)
        ))
    }

    @Test
    fun imperfectHipAndRidgeDrawingStillProduces3DMeshAndQuantities() {
        val lowerJunction = geo(6.18, 5.55)
        val upperJunction = geo(5.84, 12.62)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 18.0), geo(0.0, 18.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.RIDGE, start = lowerJunction.copy(), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(0.0, 18.0), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 18.0), end = upperJunction.copy())
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val quantities = RoofQuantityEngine.calculate(project)
        val mesh = RoofMeshBuilder.build(project)

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.code }, !prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.graph.nodes.values.all { it.z.isFinite() })
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
        assertTrue(quantities.totals.perimeterM > 0.0)
        assertTrue(mesh.triangles.isNotEmpty())
        assertTrue(mesh.edges.isNotEmpty())
        assertTrue(mesh.internalEdges.isNotEmpty())
        assertEquals(mesh.triangles.size / 3, mesh.materials.size)
        assertTrue(mesh.materials.any { it == 1f })
        assertTrue(mesh.materials.any { it == 0f })
        assertEquals(2, mesh.logoFaceCount)
        assertEquals(2, mesh.logoQuads.size)
        assertTrue(mesh.logoQuads.all { it.faceId in prepared.graph.faces })
        assertTrue(mesh.logoQuads.all { quad ->
            val abX = quad.topRight.x - quad.topLeft.x
            val abZ = quad.topRight.z - quad.topLeft.z
            val acX = quad.bottomRight.x - quad.topLeft.x
            val acZ = quad.bottomRight.z - quad.topLeft.z
            // Model Z is -north; this winding keeps the source SVG readable, not mirrored.
            abZ * acX - abX * acZ < 0f
        })
        assertTrue(mesh.logoQuads.all { quad ->
            val plane = prepared.graph.faces.getValue(quad.faceId).plane!!
            val topX = (quad.topLeft.x + quad.topRight.x) / 2f
            val topZ = (quad.topLeft.z + quad.topRight.z) / 2f
            val bottomX = (quad.bottomLeft.x + quad.bottomRight.x) / 2f
            val bottomZ = (quad.bottomLeft.z + quad.bottomRight.z) / 2f
            // Plane gradient is uphill; the bottom of the logo must point downhill.
            (bottomX - topX) * plane.a - (bottomZ - topZ) * plane.b < -1e-7
        })
        assertEquals(12, StrechoStavLogo.originalSvgPathCount)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        assertEquals(4, planDimensions.size)
        assertEquals(2, planDimensions.map { it.dimensionId }.toSet().size)
        assertTrue(planDimensions.all { it.linkedEdgeIds.size == 2 })
        val modelBaseY = mesh.materials.indices
            .filter { mesh.materials[it] < 0.5f }
            .minOf { mesh.triangles[it * 3 + 1] }
        assertTrue(planDimensions.all { abs(it.witnessStart.y - modelBaseY) < 1e-5f })
        assertTrue(planDimensions.all { abs(it.witnessEnd.y - modelBaseY) < 1e-5f })
        assertTrue(planDimensions.all { it.start.y < it.witnessStart.y })
        assertTrue(planDimensions.all { it.end.y < it.witnessEnd.y })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.WALL_HEIGHT })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.OVERHANG })
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.SLOPE })
    }

    @Test
    fun staleRectangularWallFootprintCannotReplaceSixCornerBuildingPlan() {
        val lPolygon = mutableListOf(
            geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 4.0),
            geo(14.0, 4.0), geo(14.0, 10.0), geo(0.0, 10.0)
        )
        val project = RoofProject(
            polygon = lPolygon,
            wallFootprint = mutableListOf(
                geo(0.0, 0.0), geo(14.0, 0.0), geo(14.0, 10.0), geo(0.0, 10.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }

        assertTrue(mesh.triangles.isNotEmpty())
        assertEquals(6, planDimensions.size)
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
    }

    @Test
    fun planDimensionsMeasureWallFootprintAndOverhangIsOneSharedParameter() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            wallFootprint = mutableListOf(
                geo(0.5, 0.5), geo(11.5, 0.5), geo(11.5, 7.5), geo(0.5, 7.5)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planValues = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
            .map { it.lengthM }.toSet()
        val overhangs = mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }

        assertTrue(planValues.any { abs(it - 11.0) < 1e-3 })
        assertTrue(planValues.any { abs(it - 7.0) < 1e-3 })
        assertEquals(1, overhangs.map { it.dimensionId }.toSet().size)
        assertTrue(overhangs.all { abs(it.lengthM - 0.5) < 1e-3 })
    }

    @Test
    fun flatRoofWithThreeParapetsAndOneEaveBuildsSlopedDeckAndLevelParapet() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(13.0, 0.0), geo(13.0, 10.0), geo(0.0, 10.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.ATTIC,
                1 to LineType.ATTIC,
                2 to LineType.EAVE,
                3 to LineType.ATTIC
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0,
            atticHeightM = 0.3,
            atticWidthM = 0.28
        )

        val prepared = Roof3DPreparation.prepare(project)
        val mesh = RoofMeshBuilder.build(project)
        val quantities = RoofQuantityEngine.calculate(project)

        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(2.0)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        val eave = prepared.graph.edges.values.single { it.semanticRole == EdgeSemantic.EAVE }
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.startNodeId).z, 1e-6)
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.endNodeId).z, 1e-6)
        assertTrue(prepared.graph.nodes.values.map { it.z }.distinct().size > 1)
        assertTrue(mesh.triangles.isNotEmpty())
        val padVertices = mesh.materials.indices.filter { mesh.materials[it] >= 1.5f }
        assertEquals(30, padVertices.size)
        val padX = padVertices.map { mesh.triangles[it * 3] }
        val padZ = padVertices.map { mesh.triangles[it * 3 + 2] }
        assertTrue(padX.max() - padX.min() > 2.8f)
        assertTrue(padZ.max() - padZ.min() > 2.3f)
        assertTrue("Doska musí mať vonkajší a dva jemné vnútorné rámy", mesh.padEdges.size >= 72)
        val atticDimension = mesh.dimensions.first { it.kind == RoofDimensionKind.ATTIC_HEIGHT }
        assertEquals(0.3, atticDimension.lengthM, 1e-9)
        val atticWidthDimension = mesh.dimensions.first { it.kind == RoofDimensionKind.ATTIC_WIDTH }
        assertEquals(0.28, atticWidthDimension.lengthM, 1e-9)
        val vertexHeights = mesh.triangles.indices.filter { it % 3 == 1 }.map { mesh.triangles[it] }
        val maximum = vertexHeights.max()
        assertTrue(vertexHeights.count { abs(it - maximum) < 1e-5f } >= 6)
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
    }

    @Test
    fun explicitFlatShapeNeedsNoRidgeOrInternalLine() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(9.0, 0.0), geo(9.0, 7.0), geo(0.0, 7.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE, 2 to LineType.EAVE, 3 to LineType.EAVE
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 1.5,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(1.5)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        assertTrue(RoofMeshBuilder.build(project).triangles.isNotEmpty())
    }

    @Test
    fun planDimensionExtensionsArePerpendicularToFoundationWalls() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 1.0), geo(11.0, 9.0), geo(-1.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        RoofMeshBuilder.build(project).dimensions
            .filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
            .forEach { dimension ->
                val wallX = dimension.witnessEnd.x - dimension.witnessStart.x
                val wallZ = dimension.witnessEnd.z - dimension.witnessStart.z
                val extensionX = dimension.start.x - dimension.witnessStart.x
                val extensionZ = dimension.start.z - dimension.witnessStart.z
                assertEquals(0.0, (wallX * extensionX + wallZ * extensionZ).toDouble(), 1e-5)
            }
    }

    @Test
    fun pairedPlanDimensionsKeepOneDeterministicPhysicalSide() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        val allPlanDimensions = RoofMeshBuilder.build(project).dimensions
            .filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        val fixedPlanDimensions = RoofDimensionPlacement.stablePlanCandidates(allPlanDimensions)

        assertEquals(4, allPlanDimensions.size)
        assertEquals(2, fixedPlanDimensions.size)
        assertEquals(2, fixedPlanDimensions.map { it.dimensionId }.toSet().size)
        allPlanDimensions.groupBy { it.dimensionId }.forEach { (dimensionId, candidates) ->
            val expected = candidates.minWith(compareBy<RoofDimension3D> { it.edgeId }
                .thenBy { it.start.x }.thenBy { it.start.z })
            assertEquals(expected.edgeId, fixedPlanDimensions.single { it.dimensionId == dimensionId }.edgeId)
        }
    }

    @Test
    fun roofObjectsExposeAllRequiredParametricDimensions() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            objects = mutableListOf(
                RoofObject(
                    type = ObjectType.CHIMNEY, center = geo(3.0, 3.0),
                    widthMm = 700.0, heightMm = 900.0, value = 1.2
                ),
                RoofObject(
                    type = ObjectType.ROOF_WINDOW, center = geo(8.0, 4.0),
                    widthMm = 780.0, heightMm = 1180.0
                ),
                RoofObject(
                    type = ObjectType.HATCH, center = geo(7.0, 6.0),
                    widthMm = 650.0, heightMm = 900.0
                ),
                RoofObject(
                    type = ObjectType.VENT, center = geo(5.0, 5.0), diameterMm = 180.0
                )
            )
        )
        val dimensions = RoofMeshBuilder.build(project).dimensions
        assertEquals(0.7, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_WIDTH }.lengthM, 1e-9)
        assertEquals(0.9, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_LENGTH }.lengthM, 1e-9)
        assertEquals(1.2, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_HEIGHT }.lengthM, 1e-9)
        assertEquals(0.78, dimensions.single { it.kind == RoofDimensionKind.ROOF_WINDOW_WIDTH }.lengthM, 1e-9)
        assertEquals(1.18, dimensions.single { it.kind == RoofDimensionKind.ROOF_WINDOW_LENGTH }.lengthM, 1e-9)
        assertEquals(0.65, dimensions.single { it.kind == RoofDimensionKind.HATCH_WIDTH }.lengthM, 1e-9)
        assertEquals(0.9, dimensions.single { it.kind == RoofDimensionKind.HATCH_LENGTH }.lengthM, 1e-9)
        assertEquals(0.18, dimensions.single { it.kind == RoofDimensionKind.VENT_DIAMETER }.lengthM, 1e-9)
        val chimneyWidth = dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_WIDTH }
        val prepared = Roof3DPreparation.prepare(project)
        val chimneyLocal = Geometry.toLocal(project.objects.first().center, prepared.graph.origin)
        val chimneyFace = prepared.graph.faces.values.first { face ->
            val polygon = face.orderedNodeIds.map { id -> prepared.graph.nodes.getValue(id) }
                .map { LocalPoint(it.x, it.y) }
            Geometry.pointInPolygon(chimneyLocal, polygon)
        }
        val plane = chimneyFace.plane!!
        val widthX = chimneyWidth.end.x - chimneyWidth.start.x
        val widthZ = chimneyWidth.end.z - chimneyWidth.start.z
        // Model Z is deliberately -north so its top view agrees with the non-mirrored 2D map.
        assertEquals(0.0, widthX * plane.a - widthZ * plane.b, 1e-5)

        val anchors = RoofMeshBuilder.build(project).objectAnchors
        assertTrue(anchors.all { it.outerNormal.y > 0f })
        val south = anchors.single { it.type == ObjectType.ROOF_WINDOW }
        val north = anchors.single { it.type == ObjectType.HATCH }
        assertTrue(north.localY > south.localY)
        assertTrue("Sever nesmie byť v 3D zrkadlovo obrátený", north.center.z < south.center.z)
    }

    @Test
    fun modelTransformPreservesRightAnglesAndPadFollowsLongestWall() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 3.0), geo(10.75, 8.0), geo(-1.25, 5.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        val mesh = RoofMeshBuilder.build(project)
        val plan = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        val vectors = plan.map { dimension ->
            (dimension.witnessEnd.x - dimension.witnessStart.x) to
                (dimension.witnessEnd.z - dimension.witnessStart.z)
        }
        vectors.forEachIndexed { index, vector ->
            assertTrue(vectors.withIndex().any { (otherIndex, other) ->
                otherIndex != index && abs(vector.first * other.first + vector.second * other.second) < 1e-5
            })
        }

        fun padSegmentLength(offset: Int): Double {
            val dx = mesh.padEdges[offset + 3] - mesh.padEdges[offset]
            val dz = mesh.padEdges[offset + 5] - mesh.padEdges[offset + 2]
            return hypot(dx.toDouble(), dz.toDouble())
        }
        assertTrue("Prvá os dosky má sledovať najdlhšiu stenu", padSegmentLength(0) > padSegmentLength(6))
    }
}
