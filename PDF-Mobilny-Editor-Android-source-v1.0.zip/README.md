# PDF Mobilný Editor pre Android

Samostatná offline aplikácia na čítanie, vizuálne upravovanie, spájanie,
rozdeľovanie a exportovanie PDF.

## Funkcie

- otvorenie jedného alebo viacerých PDF, obrázkov, DOCX a XLSX,
- čítanie, listovanie medzi stranami a priblíženie dvoma prstami,
- vizuálna zmena textu prekrytím pôvodného textu a vložením nového,
- zvýraznenie, podčiarknutie a prečiarknutie označenej oblasti,
- vrátenie poslednej úpravy a vyčistenie úprav na strane,
- pridanie ďalších súborov počas práce,
- spojenie všetkých vstupov do jedného PDF,
- odstránenie jednej strany alebo rozsahu strán od–do,
- export do nového PDF bez prepísania originálu,
- vlastná červená ikona PDF,
- lokálne spracovanie bez internetového povolenia.

## Dôležité správanie

Zmena textu je vizuálna: používateľ označí obdĺžnik pôvodného textu, aplikácia
ho prekryje bielou plochou a vloží nový text. Funguje preto aj pri skenovaných
PDF, ale nemení vnútornú textovú vrstvu PDF. Výsledok sa exportuje ako obrazové
PDF.

DOCX a XLSX sa importujú základným offline prevodom. Zložité rozloženie,
špeciálne fonty, grafy a presné štýly sa nemusia zachovať. Pre úplne verný
vzhľad kancelárskeho dokumentu ho najprv uložte ako PDF.

## Zostavenie

Požiadavky: JDK 17, Android SDK 35 a Gradle 8.10.2.

```text
gradle :app:assembleDebug --stacktrace
```

Workflow `build-apk.yml` možno použiť bez zmeny. Ak je v repozitári iba
zdrojový ZIP, použite priložený
`github-actions/build-from-newest-zip.yml`.
