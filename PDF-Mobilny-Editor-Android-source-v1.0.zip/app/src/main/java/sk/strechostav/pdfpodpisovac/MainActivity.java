package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        Intent launchIntent = getIntent();
        if (launchIntent != null
                && Intent.ACTION_VIEW.equals(launchIntent.getAction())
                && launchIntent.getData() != null) {
            ArrayList<Uri> uris = new ArrayList<>();
            uris.add(launchIntent.getData());
            openEditor(uris, launchIntent.getFlags());
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(246, 247, 250));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(
                Ui.dp(this, 24),
                Ui.dp(this, 42),
                Ui.dp(this, 24),
                Ui.dp(this, 44)
        );
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView badge = Ui.text(this, "PDF", 27, Color.WHITE);
        badge.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        GradientDrawable badgeBackground = new GradientDrawable();
        badgeBackground.setColor(Color.rgb(198, 40, 40));
        badgeBackground.setCornerRadius(Ui.dp(this, 20));
        badge.setBackground(badgeBackground);
        root.addView(badge, new LinearLayout.LayoutParams(
                Ui.dp(this, 92),
                Ui.dp(this, 92)
        ));

        TextView title = Ui.text(this, "PDF Mobilný Editor", 29, Color.rgb(28, 33, 43));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        titleParams.topMargin = Ui.dp(this, 22);
        root.addView(title, titleParams);

        TextView description = Ui.text(
                this,
                "Čítajte a upravujte PDF, zvýrazňujte text, spájajte dokumenty "
                        + "a odstraňujte nepotrebné strany.",
                16,
                Color.rgb(78, 85, 99)
        );
        description.setGravity(Gravity.CENTER);
        description.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams descriptionParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        descriptionParams.topMargin = Ui.dp(this, 10);
        root.addView(description, descriptionParams);

        Button openButton = Ui.button(this, "Otvoriť dokumenty", true);
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        openParams.topMargin = Ui.dp(this, 30);
        root.addView(openButton, openParams);
        openButton.setOnClickListener(view -> chooseFiles());

        TextView formats = Ui.text(
                this,
                "Podporované: PDF, JPG, PNG, WebP, DOCX a XLSX. "
                        + "Môžete vybrať viac súborov naraz.",
                14,
                Color.rgb(104, 110, 123)
        );
        formats.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams formatsParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        formatsParams.topMargin = Ui.dp(this, 18);
        root.addView(formats, formatsParams);

        TextView privacy = Ui.text(
                this,
                "Spracovanie prebieha lokálne v telefóne. Originály zostanú nezmenené.",
                13,
                Color.rgb(104, 110, 123)
        );
        privacy.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams privacyParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        privacyParams.topMargin = Ui.dp(this, 34);
        root.addView(privacy, privacyParams);

        setContentView(scroll);
    }

    private void chooseFiles() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{
                        "application/pdf",
                        "image/jpeg",
                        "image/png",
                        "image/webp",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                }
        );
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN);
        } catch (Exception exception) {
            Toast.makeText(this, "Výber súborov nie je dostupný.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_OPEN || resultCode != RESULT_OK || data == null) {
            return;
        }
        ArrayList<Uri> uris = collectUris(data);
        if (!uris.isEmpty()) {
            openEditor(uris, data.getFlags());
        }
    }

    private ArrayList<Uri> collectUris(Intent data) {
        LinkedHashSet<Uri> selected = new LinkedHashSet<>();
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int index = 0; index < clipData.getItemCount(); index++) {
                Uri uri = clipData.getItemAt(index).getUri();
                if (uri != null) {
                    selected.add(uri);
                }
            }
        } else if (data.getData() != null) {
            selected.add(data.getData());
        }
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        for (Uri uri : selected) {
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) {
                // Some providers only grant temporary access.
            }
        }
        return new ArrayList<>(selected);
    }

    private void openEditor(ArrayList<Uri> uris, int flags) {
        ArrayList<String> values = new ArrayList<>(uris.size());
        for (Uri uri : uris) {
            values.add(uri.toString());
        }
        Intent editor = new Intent(this, EditorActivity.class);
        editor.putStringArrayListExtra(EditorActivity.EXTRA_URIS, values);
        editor.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if ((flags & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0) {
            editor.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        }
        startActivity(editor);
    }
}
