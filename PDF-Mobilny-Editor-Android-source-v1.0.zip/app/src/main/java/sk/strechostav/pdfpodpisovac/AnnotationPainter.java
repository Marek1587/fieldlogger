package sk.strechostav.pdfpodpisovac;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

final class AnnotationPainter {
    private AnnotationPainter() {
    }

    static void draw(
            Canvas canvas,
            EditAnnotation annotation,
            RectF pageRect
    ) {
        RectF rect = new RectF(
                pageRect.left + annotation.rect.left * pageRect.width(),
                pageRect.top + annotation.rect.top * pageRect.height(),
                pageRect.left + annotation.rect.right * pageRect.width(),
                pageRect.top + annotation.rect.bottom * pageRect.height()
        );
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        switch (annotation.type) {
            case HIGHLIGHT:
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(annotation.color);
                canvas.drawRect(rect, paint);
                break;
            case UNDERLINE:
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeWidth(Math.max(1.5f, pageRect.height() * 0.0028f));
                paint.setColor(annotation.color);
                canvas.drawLine(
                        rect.left,
                        rect.bottom - rect.height() * 0.08f,
                        rect.right,
                        rect.bottom - rect.height() * 0.08f,
                        paint
                );
                break;
            case STRIKEOUT:
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeWidth(Math.max(1.5f, pageRect.height() * 0.0028f));
                paint.setColor(annotation.color);
                canvas.drawLine(
                        rect.left,
                        rect.centerY(),
                        rect.right,
                        rect.centerY(),
                        paint
                );
                break;
            case REPLACE_TEXT:
                drawReplacement(canvas, rect, annotation.text);
                break;
        }
    }

    private static void drawReplacement(Canvas canvas, RectF rect, String value) {
        Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
        background.setColor(Color.WHITE);
        background.setStyle(Paint.Style.FILL);
        canvas.drawRect(rect, background);

        String text = value == null ? "" : value;
        if (text.isEmpty()) {
            return;
        }
        String[] lines = text.split("\\n", -1);
        float padding = Math.max(1f, rect.height() * 0.08f);
        float availableWidth = Math.max(1f, rect.width() - padding * 2f);
        float availableHeight = Math.max(1f, rect.height() - padding * 2f);
        float textSize = Math.max(
                3f,
                Math.min(rect.height() * 0.68f, availableHeight / Math.max(1, lines.length))
        );

        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        textPaint.setColor(Color.rgb(25, 25, 25));
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextSize(textSize);

        float widest = 0f;
        for (String line : lines) {
            widest = Math.max(widest, textPaint.measureText(line));
        }
        if (widest > availableWidth) {
            textSize *= availableWidth / widest;
            textPaint.setTextSize(Math.max(3f, textSize));
        }

        Paint.FontMetrics metrics = textPaint.getFontMetrics();
        float lineHeight = metrics.descent - metrics.ascent;
        float totalHeight = lineHeight * lines.length;
        if (totalHeight > availableHeight) {
            textPaint.setTextSize(
                    Math.max(3f, textPaint.getTextSize() * availableHeight / totalHeight)
            );
            metrics = textPaint.getFontMetrics();
            lineHeight = metrics.descent - metrics.ascent;
            totalHeight = lineHeight * lines.length;
        }
        float baseline = rect.top + padding
                + Math.max(0f, (availableHeight - totalHeight) / 2f)
                - metrics.ascent;
        canvas.save();
        canvas.clipRect(rect);
        for (String line : lines) {
            canvas.drawText(line, rect.left + padding, baseline, textPaint);
            baseline += lineHeight;
        }
        canvas.restore();
    }
}
