package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public final class PdfEditView extends View {
    interface RegionListener {
        void onRegionSelected(EditAnnotation.Type type, int pageIndex, RectF normalizedRect);
    }

    private final Paint bitmapPaint =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF pageRect = new RectF();
    private final ArrayList<EditAnnotation> annotations = new ArrayList<>();

    private Bitmap pageBitmap;
    private int pageIndex;
    private EditAnnotation.Type mode;
    private RegionListener regionListener;
    private float startX;
    private float startY;
    private float currentX;
    private float currentY;
    private boolean selecting;
    private float zoom = 1f;
    private float panX;
    private float panY;
    private float readLastX;
    private float readLastY;
    private boolean pinching;
    private float pinchStartDistance;
    private float pinchStartZoom;

    public PdfEditView(Context context) {
        this(context, null);
    }

    public PdfEditView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setBackgroundColor(Color.rgb(226, 230, 236));
        setFocusable(true);
        setClickable(true);
        shadowPaint.setColor(Color.argb(45, 0, 0, 0));
        selectionPaint.setStyle(Paint.Style.STROKE);
        selectionPaint.setStrokeWidth(Ui.dp(context, 2));
        selectionPaint.setColor(Color.rgb(198, 40, 40));
        selectionPaint.setPathEffect(
                new DashPathEffect(
                        new float[]{Ui.dp(context, 7), Ui.dp(context, 5)},
                        0f
                )
        );
    }

    void setRegionListener(RegionListener listener) {
        regionListener = listener;
    }

    void setMode(EditAnnotation.Type selectedMode) {
        mode = selectedMode;
        selecting = false;
        invalidate();
    }

    EditAnnotation.Type getMode() {
        return mode;
    }

    void setPage(Bitmap bitmap, int newPageIndex) {
        pageBitmap = bitmap;
        pageIndex = newPageIndex;
        selecting = false;
        zoom = 1f;
        panX = 0f;
        panY = 0f;
        invalidate();
    }

    void clearPage() {
        pageBitmap = null;
        selecting = false;
        invalidate();
    }

    void setAnnotations(List<EditAnnotation> source) {
        annotations.clear();
        annotations.addAll(source);
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        calculatePageRect();
        if (pageBitmap == null || pageRect.isEmpty()) {
            Paint message = new Paint(Paint.ANTI_ALIAS_FLAG);
            message.setColor(Color.DKGRAY);
            message.setTextAlign(Paint.Align.CENTER);
            message.setTextSize(Ui.dp(getContext(), 16));
            canvas.drawText(
                    "Načítavam stranu…",
                    getWidth() / 2f,
                    getHeight() / 2f,
                    message
            );
            return;
        }

        RectF shadow = new RectF(pageRect);
        shadow.offset(Ui.dp(getContext(), 3), Ui.dp(getContext(), 4));
        canvas.drawRect(shadow, shadowPaint);
        canvas.drawBitmap(pageBitmap, null, pageRect, bitmapPaint);
        for (EditAnnotation annotation : annotations) {
            if (annotation.pageIndex == pageIndex) {
                AnnotationPainter.draw(canvas, annotation, pageRect);
            }
        }
        if (selecting) {
            canvas.drawRect(sortedSelectionRect(), selectionPaint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled() || pageBitmap == null) {
            return true;
        }
        if (mode == null) {
            return handleReadTouch(event);
        }
        calculatePageRect();
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!pageRect.contains(event.getX(), event.getY())) {
                    return true;
                }
                getParent().requestDisallowInterceptTouchEvent(true);
                startX = clamp(event.getX(), pageRect.left, pageRect.right);
                startY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                currentX = startX;
                currentY = startY;
                selecting = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                if (selecting) {
                    currentX = clamp(event.getX(), pageRect.left, pageRect.right);
                    currentY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (selecting) {
                    currentX = clamp(event.getX(), pageRect.left, pageRect.right);
                    currentY = clamp(event.getY(), pageRect.top, pageRect.bottom);
                    RectF normalized = normalizedSelection();
                    selecting = false;
                    getParent().requestDisallowInterceptTouchEvent(false);
                    invalidate();
                    if (regionListener != null) {
                        regionListener.onRegionSelected(mode, pageIndex, normalized);
                    }
                    performClick();
                }
                return true;
            case MotionEvent.ACTION_CANCEL:
                selecting = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                invalidate();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private RectF normalizedSelection() {
        RectF selected = sortedSelectionRect();
        float left = (selected.left - pageRect.left) / pageRect.width();
        float top = (selected.top - pageRect.top) / pageRect.height();
        float right = (selected.right - pageRect.left) / pageRect.width();
        float bottom = (selected.bottom - pageRect.top) / pageRect.height();
        if (right - left < 0.025f) {
            right = Math.min(1f, left + 0.025f);
        }
        if (bottom - top < 0.018f) {
            bottom = Math.min(1f, top + 0.018f);
        }
        return new RectF(left, top, right, bottom);
    }

    private RectF sortedSelectionRect() {
        return new RectF(
                Math.min(startX, currentX),
                Math.min(startY, currentY),
                Math.max(startX, currentX),
                Math.max(startY, currentY)
        );
    }

    private void calculatePageRect() {
        if (pageBitmap == null || getWidth() <= 0 || getHeight() <= 0) {
            pageRect.setEmpty();
            return;
        }
        float padding = Ui.dp(getContext(), 12);
        float availableWidth = Math.max(1f, getWidth() - padding * 2f);
        float availableHeight = Math.max(1f, getHeight() - padding * 2f);
        float bitmapAspect = (float) pageBitmap.getWidth() / pageBitmap.getHeight();
        float availableAspect = availableWidth / availableHeight;
        float width;
        float height;
        if (bitmapAspect > availableAspect) {
            width = availableWidth;
            height = width / bitmapAspect;
        } else {
            height = availableHeight;
            width = height * bitmapAspect;
        }
        width *= zoom;
        height *= zoom;
        float left = (getWidth() - width) / 2f + panX;
        float top = (getHeight() - height) / 2f + panY;
        pageRect.set(left, top, left + width, top + height);
    }

    private boolean handleReadTouch(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                readLastX = event.getX();
                readLastY = event.getY();
                pinching = false;
                getParent().requestDisallowInterceptTouchEvent(true);
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getPointerCount() >= 2) {
                    pinching = true;
                    pinchStartDistance = pointerDistance(event);
                    pinchStartZoom = zoom;
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (pinching && event.getPointerCount() >= 2) {
                    float distance = pointerDistance(event);
                    if (pinchStartDistance > 1f) {
                        zoom = clamp(
                                pinchStartZoom * distance / pinchStartDistance,
                                1f,
                                4f
                        );
                        clampPan();
                        invalidate();
                    }
                } else if (zoom > 1f) {
                    float x = event.getX();
                    float y = event.getY();
                    panX += x - readLastX;
                    panY += y - readLastY;
                    readLastX = x;
                    readLastY = y;
                    clampPan();
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                pinching = false;
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                pinching = false;
                getParent().requestDisallowInterceptTouchEvent(false);
                performClick();
                return true;
            default:
                return true;
        }
    }

    private void clampPan() {
        calculatePageRect();
        float maxPanX = Math.max(0f, (pageRect.width() - getWidth()) / 2f);
        float maxPanY = Math.max(0f, (pageRect.height() - getHeight()) / 2f);
        panX = clamp(panX, -maxPanX, maxPanX);
        panY = clamp(panY, -maxPanY, maxPanY);
    }

    private static float pointerDistance(MotionEvent event) {
        float dx = event.getX(0) - event.getX(1);
        float dy = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
