package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class EditorActivity extends Activity {
    public static final String EXTRA_URIS = "document_uris";

    private static final int REQUEST_ADD_FILES = 2001;
    private static final int REQUEST_CREATE_PDF = 2002;

    private final ArrayList<Uri> initialUris = new ArrayList<>();
    private final ArrayList<EditAnnotation> annotations = new ArrayList<>();
    private final ArrayList<Button> modeButtons = new ArrayList<>();

    private File workingPdf;
    private PdfRenderer renderer;
    private Bitmap displayedBitmap;
    private int pageCount = 1;
    private int currentPage;
    private boolean loaded;
    private boolean busy;

    private PdfEditView editView;
    private TextView statusText;
    private TextView pageText;
    private ProgressBar progressBar;
    private Button previousButton;
    private Button nextButton;
    private Button addFilesButton;
    private Button deletePagesButton;
    private Button undoButton;
    private Button clearButton;
    private Button exportButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ArrayList<String> values = getIntent().getStringArrayListExtra(EXTRA_URIS);
        if (values != null) {
            for (String value : values) {
                if (value != null && !value.trim().isEmpty()) {
                    initialUris.add(Uri.parse(value));
                }
            }
        }
        if (initialUris.isEmpty()) {
            Toast.makeText(this, "Nebol vybraný žiadny dokument.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildUi();
        loadInitialDocuments();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(246, 247, 250));
        root.setPadding(0, Ui.dp(this, 18), 0, 0);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(
                Ui.dp(this, 14),
                Ui.dp(this, 10),
                Ui.dp(this, 14),
                Ui.dp(this, 10)
        );
        header.setBackgroundColor(Color.WHITE);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        header.addView(titles, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        TextView title = Ui.text(this, "PDF Mobilný Editor", 19, Color.rgb(31, 36, 47));
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(title);
        statusText = Ui.text(this, "Načítavam dokumenty…", 13, Color.rgb(92, 98, 111));
        titles.addView(statusText);

        Button closeButton = Ui.button(this, "Zavrieť", false);
        closeButton.setOnClickListener(view -> finish());
        header.addView(closeButton);
        root.addView(header);

        LinearLayout navigation = new LinearLayout(this);
        navigation.setGravity(Gravity.CENTER);
        navigation.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 6),
                Ui.dp(this, 10),
                Ui.dp(this, 6)
        );
        previousButton = Ui.button(this, "‹", false);
        nextButton = Ui.button(this, "›", false);
        pageText = Ui.text(this, "Strana 1 / 1", 15, Color.rgb(36, 40, 50));
        pageText.setGravity(Gravity.CENTER);
        navigation.addView(previousButton, new LinearLayout.LayoutParams(
                Ui.dp(this, 56),
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        navigation.addView(pageText, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        navigation.addView(nextButton, new LinearLayout.LayoutParams(
                Ui.dp(this, 56),
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        root.addView(navigation);
        previousButton.setOnClickListener(view -> renderPage(currentPage - 1));
        nextButton.setOnClickListener(view -> renderPage(currentPage + 1));

        editView = new PdfEditView(this);
        LinearLayout.LayoutParams editorParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        editorParams.setMargins(
                Ui.dp(this, 10),
                0,
                Ui.dp(this, 10),
                Ui.dp(this, 5)
        );
        root.addView(editView, editorParams);
        editView.setRegionListener(this::onRegionSelected);

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Ui.dp(this, 28)
        );
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(progressBar, progressParams);

        TextView toolsLabel = Ui.text(this, "Nástroj úpravy", 13, Color.rgb(92, 98, 111));
        LinearLayout.LayoutParams labelParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        labelParams.setMargins(Ui.dp(this, 14), 0, Ui.dp(this, 14), Ui.dp(this, 3));
        root.addView(toolsLabel, labelParams);

        HorizontalScrollView editToolsScroll = new HorizontalScrollView(this);
        editToolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout editTools = new LinearLayout(this);
        editTools.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 3),
                Ui.dp(this, 10),
                Ui.dp(this, 5)
        );
        editToolsScroll.addView(editTools);
        root.addView(editToolsScroll);

        Button readButton = createModeButton(editTools, "Čítať");
        Button replaceButton = createModeButton(editTools, "Zmeniť text");
        Button highlightButton = createModeButton(editTools, "Zvýrazniť");
        Button underlineButton = createModeButton(editTools, "Podčiarknuť");
        Button strikeButton = createModeButton(editTools, "Prečiarknuť");
        readButton.setOnClickListener(view -> selectMode(null, readButton));
        replaceButton.setOnClickListener(view ->
                selectMode(EditAnnotation.Type.REPLACE_TEXT, replaceButton));
        highlightButton.setOnClickListener(view ->
                selectMode(EditAnnotation.Type.HIGHLIGHT, highlightButton));
        underlineButton.setOnClickListener(view ->
                selectMode(EditAnnotation.Type.UNDERLINE, underlineButton));
        strikeButton.setOnClickListener(view ->
                selectMode(EditAnnotation.Type.STRIKEOUT, strikeButton));
        selectMode(null, readButton);

        HorizontalScrollView documentToolsScroll = new HorizontalScrollView(this);
        documentToolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout documentTools = new LinearLayout(this);
        documentTools.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 3),
                Ui.dp(this, 10),
                Ui.dp(this, 6)
        );
        documentToolsScroll.addView(documentTools);
        addFilesButton = Ui.button(this, "+ Pridať súbory", false);
        deletePagesButton = Ui.button(this, "Odstrániť strany", false);
        undoButton = Ui.button(this, "Späť", false);
        clearButton = Ui.button(this, "Vyčistiť stranu", false);
        addToolButton(documentTools, addFilesButton);
        addToolButton(documentTools, deletePagesButton);
        addToolButton(documentTools, undoButton);
        addToolButton(documentTools, clearButton);
        root.addView(documentToolsScroll);

        addFilesButton.setOnClickListener(view -> chooseAdditionalFiles());
        deletePagesButton.setOnClickListener(view -> showDeletePagesDialog());
        undoButton.setOnClickListener(view -> undoLastEdit());
        clearButton.setOnClickListener(view -> confirmClearPage());

        exportButton = Ui.button(this, "Vytvoriť upravené PDF", true);
        LinearLayout.LayoutParams exportParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        exportParams.setMargins(
                Ui.dp(this, 10),
                Ui.dp(this, 2),
                Ui.dp(this, 10),
                Ui.dp(this, 26)
        );
        root.addView(exportButton, exportParams);
        exportButton.setOnClickListener(view -> chooseOutputFile());

        setContentView(root);
        updateControls();
    }

    private Button createModeButton(LinearLayout parent, String label) {
        Button button = Ui.button(this, label, false);
        button.setTextSize(13);
        modeButtons.add(button);
        addToolButton(parent, button);
        return button;
    }

    private void addToolButton(LinearLayout parent, Button button) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.rightMargin = Ui.dp(this, 7);
        parent.addView(button, params);
    }

    private void selectMode(EditAnnotation.Type mode, Button selectedButton) {
        editView.setMode(mode);
        for (Button button : modeButtons) {
            button.setAlpha(button == selectedButton ? 1f : 0.62f);
        }
        if (!busy) {
            statusText.setText(modeInstruction(mode));
        }
    }

    private String modeInstruction(EditAnnotation.Type mode) {
        if (mode == null) {
            return "Čítanie: dvoma prstami priblížte, jedným posúvajte.";
        }
        switch (mode) {
            case REPLACE_TEXT:
                return "Potiahnutím označte pôvodný text, ktorý chcete nahradiť.";
            case HIGHLIGHT:
                return "Potiahnutím označte oblasť na zvýraznenie.";
            case UNDERLINE:
                return "Potiahnutím označte text na podčiarknutie.";
            case STRIKEOUT:
                return "Potiahnutím označte text na prečiarknutie.";
            default:
                return "";
        }
    }

    private void onRegionSelected(
            EditAnnotation.Type type,
            int pageIndex,
            RectF rect
    ) {
        if (type == EditAnnotation.Type.REPLACE_TEXT) {
            showReplacementDialog(pageIndex, rect);
            return;
        }
        annotations.add(new EditAnnotation(type, pageIndex, rect));
        editView.setAnnotations(annotations);
        updateControls();
        statusText.setText("Úprava bola pridaná. Môžete označiť ďalšiu oblasť.");
    }

    private void showReplacementDialog(int pageIndex, RectF rect) {
        EditText input = new EditText(this);
        input.setHint("Nový text; prázdne pole pôvodný text iba prekryje");
        input.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setMinLines(2);
        input.setPadding(
                Ui.dp(this, 18),
                Ui.dp(this, 12),
                Ui.dp(this, 18),
                Ui.dp(this, 12)
        );
        new AlertDialog.Builder(this)
                .setTitle("Zmeniť text")
                .setMessage("Označené miesto sa prekryje a vloží sa nový text.")
                .setView(input)
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Vložiť", (dialog, which) -> {
                    EditAnnotation annotation = new EditAnnotation(
                            EditAnnotation.Type.REPLACE_TEXT,
                            pageIndex,
                            rect
                    );
                    annotation.text = input.getText().toString();
                    annotations.add(annotation);
                    editView.setAnnotations(annotations);
                    updateControls();
                    statusText.setText("Nový text bol vložený.");
                })
                .show();
    }

    private void loadInitialDocuments() {
        setBusy(true, "Pripravujem dokumenty…");
        new Thread(() -> {
            try {
                File combined = DocumentCombiner.combineToPdf(
                        this,
                        initialUris,
                        false,
                        (current, total, fileName) -> runOnUiThread(() ->
                                statusText.setText(
                                        "Importujem " + current + " z " + total
                                                + ": " + fileName
                                )
                        )
                );
                runOnUiThread(() -> {
                    workingPdf = combined;
                    try {
                        openRenderer();
                        busy = false;
                        renderPage(0);
                    } catch (Exception exception) {
                        showLoadError(exception);
                    }
                });
            } catch (Exception exception) {
                runOnUiThread(() -> showLoadError(exception));
            }
        }, "pdf-initial-loader").start();
    }

    private void openRenderer() throws IOException {
        closeRenderer();
        ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                workingPdf,
                ParcelFileDescriptor.MODE_READ_ONLY
        );
        renderer = new PdfRenderer(descriptor);
        pageCount = renderer.getPageCount();
        if (pageCount <= 0) {
            throw new IOException("PDF neobsahuje žiadnu stranu.");
        }
        loaded = true;
    }

    private void renderPage(int requestedPage) {
        if (!loaded || renderer == null || busy
                || requestedPage < 0 || requestedPage >= pageCount) {
            return;
        }
        currentPage = requestedPage;
        setBusy(true, "Načítavam stranu…");
        new Thread(() -> {
            try {
                Bitmap bitmap = DocumentFiles.renderPdfPage(renderer, requestedPage, 2400);
                runOnUiThread(() -> {
                    if (displayedBitmap != null && displayedBitmap != bitmap) {
                        displayedBitmap.recycle();
                    }
                    displayedBitmap = bitmap;
                    editView.setPage(bitmap, requestedPage);
                    editView.setAnnotations(annotations);
                    setBusy(false, modeInstruction(editView.getMode()));
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, "Stranu sa nepodarilo načítať.");
                    Toast.makeText(this, safeMessage(exception), Toast.LENGTH_LONG).show();
                });
            }
        }, "pdf-page-renderer").start();
    }

    private void chooseAdditionalFiles() {
        if (!loaded || busy) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{
                        "application/pdf",
                        "image/jpeg",
                        "image/png",
                        "image/webp",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                }
        );
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_ADD_FILES);
        } catch (Exception exception) {
            Toast.makeText(this, "Výber súborov nie je dostupný.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) {
            return;
        }
        if (requestCode == REQUEST_ADD_FILES) {
            ArrayList<Uri> additions = collectUris(data);
            if (!additions.isEmpty()) {
                appendFiles(additions);
            }
        } else if (requestCode == REQUEST_CREATE_PDF && data.getData() != null) {
            exportTo(data.getData());
        }
    }

    private ArrayList<Uri> collectUris(Intent data) {
        LinkedHashSet<Uri> selected = new LinkedHashSet<>();
        ClipData clipData = data.getClipData();
        if (clipData != null) {
            for (int index = 0; index < clipData.getItemCount(); index++) {
                Uri uri = clipData.getItemAt(index).getUri();
                if (uri != null) {
                    selected.add(uri);
                }
            }
        } else if (data.getData() != null) {
            selected.add(data.getData());
        }
        int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        for (Uri uri : selected) {
            try {
                getContentResolver().takePersistableUriPermission(uri, flags);
            } catch (Exception ignored) {
                // Temporary access is enough for immediate import.
            }
        }
        return new ArrayList<>(selected);
    }

    private void appendFiles(ArrayList<Uri> additions) {
        File previousFile = workingPdf;
        int returnToPage = currentPage;
        ArrayList<Uri> combinedInputs = new ArrayList<>();
        combinedInputs.add(Uri.fromFile(previousFile));
        combinedInputs.addAll(additions);
        setBusy(true, "Pridávam ďalšie súbory…");
        new Thread(() -> {
            try {
                File combined = DocumentCombiner.combineToPdf(
                        this,
                        combinedInputs,
                        false,
                        (current, total, fileName) -> runOnUiThread(() ->
                                statusText.setText(
                                        "Spájam " + current + " z " + total
                                                + ": " + fileName
                                )
                        )
                );
                runOnUiThread(() -> {
                    closeRenderer();
                    workingPdf = combined;
                    //noinspection ResultOfMethodCallIgnored
                    previousFile.delete();
                    try {
                        openRenderer();
                        busy = false;
                        renderPage(Math.min(returnToPage, pageCount - 1));
                    } catch (Exception exception) {
                        showLoadError(exception);
                    }
                });
            } catch (Exception exception) {
                runOnUiThread(() -> setBusy(
                        false,
                        "Súbory sa nepodarilo pridať: " + safeMessage(exception)
                ));
            }
        }, "pdf-file-appender").start();
    }

    private void showDeletePagesDialog() {
        if (!loaded || busy) {
            return;
        }
        LinearLayout fields = new LinearLayout(this);
        fields.setPadding(
                Ui.dp(this, 18),
                Ui.dp(this, 4),
                Ui.dp(this, 18),
                0
        );
        EditText fromInput = new EditText(this);
        fromInput.setHint("Od");
        fromInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        fromInput.setText(String.valueOf(currentPage + 1));
        EditText toInput = new EditText(this);
        toInput.setHint("Do");
        toInput.setInputType(InputType.TYPE_CLASS_NUMBER);
        toInput.setText(String.valueOf(currentPage + 1));
        fields.addView(fromInput, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));
        fields.addView(toInput, new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        ));

        new AlertDialog.Builder(this)
                .setTitle("Odstrániť strany")
                .setMessage("Zadajte rozsah strán od–do. Dokument má "
                        + pageCount + " strán.")
                .setView(fields)
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Odstrániť", (dialog, which) -> {
                    try {
                        int from = Integer.parseInt(fromInput.getText().toString()) - 1;
                        int to = Integer.parseInt(toInput.getText().toString()) - 1;
                        if (from < 0 || to < from || to >= pageCount) {
                            throw new IllegalArgumentException();
                        }
                        if (to - from + 1 >= pageCount) {
                            Toast.makeText(
                                    this,
                                    "Nie je možné odstrániť všetky strany.",
                                    Toast.LENGTH_LONG
                            ).show();
                            return;
                        }
                        deletePageRange(from, to);
                    } catch (Exception exception) {
                        Toast.makeText(
                                this,
                                "Zadajte platný rozsah od 1 do " + pageCount + ".",
                                Toast.LENGTH_LONG
                        ).show();
                    }
                })
                .show();
    }

    private void deletePageRange(int from, int to) {
        File previousFile = workingPdf;
        setBusy(true, "Odstraňujem strany…");
        new Thread(() -> {
            try {
                File updated = PdfPageOperations.deleteRange(this, previousFile, from, to);
                runOnUiThread(() -> {
                    closeRenderer();
                    workingPdf = updated;
                    //noinspection ResultOfMethodCallIgnored
                    previousFile.delete();
                    remapAnnotationsAfterDelete(from, to);
                    try {
                        openRenderer();
                        busy = false;
                        renderPage(Math.min(from, pageCount - 1));
                    } catch (Exception exception) {
                        showLoadError(exception);
                    }
                });
            } catch (Exception exception) {
                runOnUiThread(() -> setBusy(
                        false,
                        "Strany sa nepodarilo odstrániť: " + safeMessage(exception)
                ));
            }
        }, "pdf-page-remover").start();
    }

    private void remapAnnotationsAfterDelete(int from, int to) {
        int removedCount = to - from + 1;
        Iterator<EditAnnotation> iterator = annotations.iterator();
        while (iterator.hasNext()) {
            EditAnnotation annotation = iterator.next();
            if (annotation.pageIndex >= from && annotation.pageIndex <= to) {
                iterator.remove();
            } else if (annotation.pageIndex > to) {
                annotation.pageIndex -= removedCount;
            }
        }
    }

    private void undoLastEdit() {
        for (int index = annotations.size() - 1; index >= 0; index--) {
            if (annotations.get(index).pageIndex == currentPage) {
                annotations.remove(index);
                editView.setAnnotations(annotations);
                updateControls();
                statusText.setText("Posledná úprava na strane bola odstránená.");
                return;
            }
        }
        Toast.makeText(this, "Na tejto strane nie je žiadna úprava.", Toast.LENGTH_SHORT).show();
    }

    private void confirmClearPage() {
        boolean hasEdits = false;
        for (EditAnnotation annotation : annotations) {
            if (annotation.pageIndex == currentPage) {
                hasEdits = true;
                break;
            }
        }
        if (!hasEdits) {
            Toast.makeText(this, "Na tejto strane nie sú úpravy.", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Vyčistiť úpravy strany?")
                .setMessage("Odstránia sa zvýraznenia aj zmeny textu na tejto strane.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Vyčistiť", (dialog, which) -> {
                    annotations.removeIf(item -> item.pageIndex == currentPage);
                    editView.setAnnotations(annotations);
                    updateControls();
                })
                .show();
    }

    private void chooseOutputFile() {
        if (!loaded || busy) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, "upravene_pdf.pdf");
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_CREATE_PDF);
        } catch (Exception exception) {
            Toast.makeText(this, "Uloženie súboru nie je dostupné.", Toast.LENGTH_LONG).show();
        }
    }

    private void exportTo(Uri outputUri) {
        ArrayList<EditAnnotation> snapshot = new ArrayList<>(annotations.size());
        for (EditAnnotation annotation : annotations) {
            snapshot.add(annotation.copy());
        }
        setBusy(true, "Vytváram upravené PDF…");
        new Thread(() -> {
            try {
                PdfEditExporter.export(
                        this,
                        workingPdf,
                        snapshot,
                        outputUri,
                        (page, total) -> runOnUiThread(() ->
                                statusText.setText(
                                        String.format(
                                                Locale.getDefault(),
                                                "Exportujem stranu %d z %d…",
                                                page,
                                                total
                                        )
                                )
                        )
                );
                runOnUiThread(() -> {
                    setBusy(false, "Upravené PDF bolo vytvorené.");
                    showExportSuccess(outputUri);
                });
            } catch (Exception exception) {
                runOnUiThread(() -> new AlertDialog.Builder(this)
                        .setTitle("Export zlyhal")
                        .setMessage(safeMessage(exception))
                        .setPositiveButton("OK", null)
                        .show());
                runOnUiThread(() -> setBusy(false, "PDF sa nepodarilo vytvoriť."));
            }
        }, "pdf-editor-exporter").start();
    }

    private void showExportSuccess(Uri uri) {
        new AlertDialog.Builder(this)
                .setTitle("PDF je uložené")
                .setMessage("Upravené PDF bolo vytvorené. Pôvodné súbory zostali nezmenené.")
                .setPositiveButton("Zdieľať", (dialog, which) -> sharePdf(uri))
                .setNeutralButton("Otvoriť", (dialog, which) -> openPdf(uri))
                .setNegativeButton("Hotovo", null)
                .show();
    }

    private void sharePdf(Uri uri) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(share, "Zdieľať upravené PDF"));
        } catch (Exception exception) {
            Toast.makeText(this, "PDF sa nepodarilo zdieľať.", Toast.LENGTH_LONG).show();
        }
    }

    private void openPdf(Uri uri) {
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "application/pdf");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(view);
        } catch (Exception exception) {
            Toast.makeText(this, "Nie je dostupná čítačka PDF.", Toast.LENGTH_LONG).show();
        }
    }

    private void setBusy(boolean value, String message) {
        busy = value;
        if (progressBar != null) {
            progressBar.setVisibility(value ? View.VISIBLE : View.GONE);
        }
        if (statusText != null && message != null) {
            statusText.setText(message);
        }
        if (editView != null) {
            editView.setEnabled(!value);
        }
        updateControls();
    }

    private void updateControls() {
        if (previousButton == null) {
            return;
        }
        pageText.setText(String.format(
                Locale.getDefault(),
                "Strana %d / %d",
                currentPage + 1,
                pageCount
        ));
        previousButton.setEnabled(loaded && !busy && currentPage > 0);
        nextButton.setEnabled(loaded && !busy && currentPage < pageCount - 1);
        addFilesButton.setEnabled(loaded && !busy);
        deletePagesButton.setEnabled(loaded && !busy && pageCount > 1);
        undoButton.setEnabled(loaded && !busy && hasEditOnCurrentPage());
        clearButton.setEnabled(loaded && !busy && hasEditOnCurrentPage());
        exportButton.setEnabled(loaded && !busy);
    }

    private boolean hasEditOnCurrentPage() {
        for (EditAnnotation annotation : annotations) {
            if (annotation.pageIndex == currentPage) {
                return true;
            }
        }
        return false;
    }

    private void closeRenderer() {
        loaded = false;
        if (editView != null) {
            editView.clearPage();
        }
        if (renderer != null) {
            try {
                renderer.close();
            } catch (Exception ignored) {
                // Already closed.
            }
            renderer = null;
        }
        if (displayedBitmap != null) {
            displayedBitmap.recycle();
            displayedBitmap = null;
        }
    }

    private void showLoadError(Exception exception) {
        setBusy(false, "Dokument sa nepodarilo načítať.");
        new AlertDialog.Builder(this)
                .setTitle("Dokument nemožno otvoriť")
                .setMessage(safeMessage(exception))
                .setPositiveButton("Zavrieť", (dialog, which) -> finish())
                .show();
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.trim().isEmpty()
                ? "Neznáma chyba."
                : message;
    }

    @Override
    protected void onDestroy() {
        closeRenderer();
        if (workingPdf != null && workingPdf.isFile()) {
            //noinspection ResultOfMethodCallIgnored
            workingPdf.delete();
        }
        super.onDestroy();
    }
}
