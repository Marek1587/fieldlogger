package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

final class PdfEditExporter {
    interface ProgressListener {
        void onProgress(int currentPage, int totalPages);
    }

    private static final Paint BITMAP_PAINT =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private PdfEditExporter() {
    }

    static void export(
            Context context,
            File source,
            List<EditAnnotation> annotations,
            Uri destination,
            ProgressListener listener
    ) throws IOException {
        if (source == null || !source.isFile()) {
            throw new IOException("Pracovné PDF sa nenašlo.");
        }
        ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                source,
                ParcelFileDescriptor.MODE_READ_ONLY
        );
        PdfDocument output = new PdfDocument();
        try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
            int total = renderer.getPageCount();
            for (int pageIndex = 0; pageIndex < total; pageIndex++) {
                if (listener != null) {
                    listener.onProgress(pageIndex + 1, total);
                }
                renderPage(renderer, output, annotations, pageIndex);
            }
            try (OutputStream stream =
                         context.getContentResolver().openOutputStream(destination, "w")) {
                if (stream == null) {
                    throw new IOException("Výstupné PDF sa nepodarilo vytvoriť.");
                }
                output.writeTo(stream);
                stream.flush();
            }
        } finally {
            output.close();
        }
    }

    private static void renderPage(
            PdfRenderer renderer,
            PdfDocument output,
            List<EditAnnotation> annotations,
            int pageIndex
    ) {
        try (PdfRenderer.Page sourcePage = renderer.openPage(pageIndex)) {
            int pageWidth = Math.max(1, sourcePage.getWidth());
            int pageHeight = Math.max(1, sourcePage.getHeight());
            float scale = Math.min(2.4f, 2700f / Math.max(pageWidth, pageHeight));
            scale = Math.max(0.5f, scale);
            Bitmap rendered = Bitmap.createBitmap(
                    Math.max(1, Math.round(pageWidth * scale)),
                    Math.max(1, Math.round(pageHeight * scale)),
                    Bitmap.Config.ARGB_8888
            );
            rendered.eraseColor(Color.WHITE);
            Matrix matrix = new Matrix();
            matrix.setScale(scale, scale);
            sourcePage.render(
                    rendered,
                    null,
                    matrix,
                    PdfRenderer.Page.RENDER_MODE_FOR_PRINT
            );

            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(
                    pageWidth,
                    pageHeight,
                    pageIndex + 1
            ).create();
            PdfDocument.Page page = output.startPage(info);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            RectF fullPage = new RectF(0f, 0f, pageWidth, pageHeight);
            canvas.drawBitmap(rendered, null, fullPage, BITMAP_PAINT);
            for (EditAnnotation annotation : annotations) {
                if (annotation.pageIndex == pageIndex) {
                    AnnotationPainter.draw(canvas, annotation, fullPage);
                }
            }
            output.finishPage(page);
            rendered.recycle();
        }
    }
}
