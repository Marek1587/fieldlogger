package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

final class PdfPageOperations {
    private static final Paint BITMAP_PAINT =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private PdfPageOperations() {
    }

    static File deleteRange(
            Context context,
            File source,
            int fromPage,
            int toPage
    ) throws IOException {
        File destination = File.createTempFile(
                "pdf_editor_pages_",
                ".pdf",
                context.getCacheDir()
        );
        boolean success = false;
        ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(
                source,
                ParcelFileDescriptor.MODE_READ_ONLY
        );
        PdfDocument output = new PdfDocument();
        try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
            int outputPageNumber = 0;
            for (int pageIndex = 0; pageIndex < renderer.getPageCount(); pageIndex++) {
                if (pageIndex >= fromPage && pageIndex <= toPage) {
                    continue;
                }
                outputPageNumber++;
                copyPage(renderer, pageIndex, output, outputPageNumber);
            }
            if (outputPageNumber == 0) {
                throw new IOException("Nie je možné odstrániť všetky strany dokumentu.");
            }
            try (FileOutputStream stream = new FileOutputStream(destination)) {
                output.writeTo(stream);
                stream.flush();
            }
            success = true;
            return destination;
        } finally {
            output.close();
            if (!success) {
                //noinspection ResultOfMethodCallIgnored
                destination.delete();
            }
        }
    }

    private static void copyPage(
            PdfRenderer renderer,
            int pageIndex,
            PdfDocument output,
            int outputPageNumber
    ) {
        try (PdfRenderer.Page sourcePage = renderer.openPage(pageIndex)) {
            int width = Math.max(1, sourcePage.getWidth());
            int height = Math.max(1, sourcePage.getHeight());
            float scale = Math.min(2.2f, 2500f / Math.max(width, height));
            scale = Math.max(0.5f, scale);
            Bitmap bitmap = Bitmap.createBitmap(
                    Math.max(1, Math.round(width * scale)),
                    Math.max(1, Math.round(height * scale)),
                    Bitmap.Config.ARGB_8888
            );
            bitmap.eraseColor(Color.WHITE);
            Matrix matrix = new Matrix();
            matrix.setScale(scale, scale);
            sourcePage.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);

            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(
                    width,
                    height,
                    outputPageNumber
            ).create();
            PdfDocument.Page page = output.startPage(info);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(bitmap, null, new RectF(0, 0, width, height), BITMAP_PAINT);
            output.finishPage(page);
            bitmap.recycle();
        }
    }
}
