plugins {
    id("com.android.application")
}

android {
    namespace = "sk.strechostav.pdfpodpisovac"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.pdfeditor"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
