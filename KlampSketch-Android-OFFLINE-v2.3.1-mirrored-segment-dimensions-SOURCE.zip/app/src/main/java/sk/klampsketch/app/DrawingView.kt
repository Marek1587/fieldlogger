package sk.klampsketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

class DrawingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    var onProfileChanged: ((MutableList<ProfilePoint>) -> Unit)? = null
    var onSegmentSelected: ((segmentIndex: Int, currentLengthMm: Int) -> Unit)? = null
    var onAngleSelected: ((vertexIndex: Int, currentAngle: Int) -> Unit)? = null
    var onPointSelectionChanged: ((selectedIndex: Int?) -> Unit)? = null
    var allowPointDrag: Boolean = true
    var allowAngleEditing: Boolean = true

    private var profile = mutableListOf<ProfilePoint>()
    private val rawStroke = mutableListOf<ProfilePoint>()
    private var sketchMode = true
    private var renderResult = ProfileRenderResult(emptyList(), emptyList(), emptyList())
    private var draggedPointIndex: Int? = null
    private var pressedHandleIndex: Int? = null
    private var selectedPointIndex: Int? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var movedDuringTouch = false
    private var pinchActive = false
    private var initialPinchDistance = 0f
    private var initialZoom = 1f
    private var initialPanX = 0f
    private var initialPanY = 0f
    private var pinchMidX = 0f
    private var pinchMidY = 0f
    private var userZoom = 1f
    private var userPanX = 0f
    private var userPanY = 0f

    private val rawPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(8, 119, 201)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 4f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(234, 239, 242)
        strokeWidth = resources.displayMetrics.density
    }

    init {
        setBackgroundColor(Color.WHITE)
        isFocusable = true
        contentDescription = "Plocha na kreslenie klampiarskeho profilu"
    }

    fun setProfile(points: List<ProfilePoint>) {
        profile = points.map { it.copy() }.toMutableList()
        sketchMode = profile.size < 2
        rawStroke.clear()
        draggedPointIndex = null
        pressedHandleIndex = null
        selectedPointIndex = null
        onPointSelectionChanged?.invoke(null)
        invalidate()
    }

    fun getProfile(): MutableList<ProfilePoint> =
        profile.map { it.copy() }.toMutableList()

    fun getSelectedPointIndex(): Int? = selectedPointIndex

    fun addPoint(): AddPointResult? {
        if (profile.size < 2) return null
        val eligibleSegments = (0 until profile.lastIndex).filter { index ->
            ProfileGeometry.segmentLength(profile, index) >= 10
        }
        val preferredSegment = selectedPointIndex
            ?.let { selected -> selected.coerceAtMost(profile.lastIndex - 1) }
            ?.coerceAtLeast(0)
        val segmentIndex = preferredSegment
            ?.takeIf { it in eligibleSegments }
            ?: eligibleSegments.maxByOrNull { index ->
                ProfileGeometry.segmentLength(profile, index)
            }
            ?: return null
        val start = profile[segmentIndex]
        val end = profile[segmentIndex + 1]
        val originalLength = ProfileGeometry.segmentLength(profile, segmentIndex)
        val firstLength = (originalLength / 10 * 5).coerceIn(5, originalLength - 5)
        val angle = atan2(
            (end.y - start.y).toDouble(),
            (end.x - start.x).toDouble()
        )
        val insertIndex = segmentIndex + 1
        profile.add(
            insertIndex,
            ProfilePoint(
                start.x + (cos(angle) * firstLength).toFloat(),
                start.y + (sin(angle) * firstLength).toFloat()
            )
        )
        selectedPointIndex = insertIndex
        onPointSelectionChanged?.invoke(insertIndex)
        onProfileChanged?.invoke(getProfile())
        invalidate()
        return AddPointResult(insertIndex, segmentIndex, getProfile())
    }

    fun zoomIn() = zoomBy(1.25f)

    fun zoomOut() = zoomBy(0.8f)

    fun startNewSketch() {
        profile.clear()
        rawStroke.clear()
        sketchMode = true
        draggedPointIndex = null
        pressedHandleIndex = null
        selectedPointIndex = null
        userZoom = 1f
        userPanX = 0f
        userPanY = 0f
        onPointSelectionChanged?.invoke(null)
        invalidate()
    }

    fun updateSegmentLength(segmentIndex: Int, lengthMm: Int) {
        profile = ProfileGeometry.updateSegmentLength(profile, segmentIndex, lengthMm)
        onProfileChanged?.invoke(getProfile())
        invalidate()
    }

    fun updateAngle(vertexIndex: Int, angle: Int) {
        profile = ProfileGeometry.updateAngle(profile, vertexIndex, angle)
        onProfileChanged?.invoke(getProfile())
        invalidate()
    }

    fun removeSelectedPoint(): DeletePointResult? {
        val index = selectedPointIndex ?: return null
        if (profile.size <= 2 || index !in profile.indices) return null
        val updated = profile.map { it.copy() }.toMutableList().apply { removeAt(index) }
        profile = ProfileGeometry.snapProfile(updated)
        selectedPointIndex = null
        onPointSelectionChanged?.invoke(null)
        onProfileChanged?.invoke(getProfile())
        invalidate()
        return DeletePointResult(index, getProfile())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawGrid(canvas)
        val area = RectF(
            paddingLeft.toFloat(),
            paddingTop.toFloat(),
            (width - paddingRight).toFloat(),
            (height - paddingBottom).toFloat()
        )
        renderResult = ProfileRenderer.renderTechnical(
            canvas = canvas,
            area = area,
            points = profile,
            labelSize = resources.displayMetrics.scaledDensity * 16f,
            showHandles = true,
            zoom = userZoom,
            panX = userPanX,
            panY = userPanY,
            selectedHandleIndex = selectedPointIndex
        )

        if (rawStroke.size >= 2) {
            val path = Path()
            path.moveTo(rawStroke.first().x, rawStroke.first().y)
            rawStroke.drop(1).forEach { point -> path.lineTo(point.x, point.y) }
            canvas.drawPath(path, rawPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                movedDuringTouch = false
                pinchActive = false
                lastTouchX = event.x
                lastTouchY = event.y
                if (sketchMode) {
                    rawStroke.clear()
                    rawStroke += ProfilePoint(event.x, event.y)
                } else {
                    pressedHandleIndex = nearestHandle(event.x, event.y)
                    if (pressedHandleIndex != null) {
                        selectedPointIndex = pressedHandleIndex
                        onPointSelectionChanged?.invoke(selectedPointIndex)
                    }
                    draggedPointIndex = if (allowPointDrag) pressedHandleIndex else null
                }
                invalidate()
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (!sketchMode && draggedPointIndex == null && event.pointerCount >= 2) {
                    pinchActive = true
                    movedDuringTouch = true
                    initialPinchDistance = pointerDistance(event).coerceAtLeast(1f)
                    initialZoom = userZoom
                    initialPanX = userPanX
                    initialPanY = userPanY
                    pinchMidX = midpointX(event)
                    pinchMidY = midpointY(event)
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2 && pinchActive && !sketchMode && draggedPointIndex == null) {
                    val distance = pointerDistance(event).coerceAtLeast(1f)
                    userZoom = (initialZoom * (distance / initialPinchDistance)).coerceIn(0.5f, 8f)
                    userPanX = initialPanX + (midpointX(event) - pinchMidX)
                    userPanY = initialPanY + (midpointY(event) - pinchMidY)
                    invalidate()
                    return true
                }

                val distance = hypot(
                    (event.x - lastTouchX).toDouble(),
                    (event.y - lastTouchY).toDouble()
                ).toFloat()
                if (distance > resources.displayMetrics.density * 2f) {
                    movedDuringTouch = true
                }

                if (sketchMode) {
                    if (rawStroke.isEmpty() || distance > resources.displayMetrics.density * 2f) {
                        rawStroke += ProfilePoint(event.x, event.y)
                    }
                } else if (draggedPointIndex != null) {
                    draggedPointIndex?.let { index ->
                        val modelScale = modelUnitsPerScreenPixel()
                        profile[index].x += (event.x - lastTouchX) * modelScale
                        profile[index].y += (event.y - lastTouchY) * modelScale
                        onProfileChanged?.invoke(getProfile())
                    }
                } else if (pressedHandleIndex == null) {
                    userPanX += event.x - lastTouchX
                    userPanY += event.y - lastTouchY
                }
                lastTouchX = event.x
                lastTouchY = event.y
                invalidate()
                return true
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (event.pointerCount - 1 < 2) {
                    pinchActive = false
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (sketchMode && rawStroke.size >= 2) {
                    profile = ProfileGeometry.magicClean(rawStroke)
                    rawStroke.clear()
                    sketchMode = false
                    onProfileChanged?.invoke(getProfile())
                    performClick()
                } else if (draggedPointIndex != null) {
                    profile = ProfileGeometry.snapProfile(profile)
                    draggedPointIndex = null
                    onProfileChanged?.invoke(getProfile())
                    performClick()
                } else if (!movedDuringTouch && event.actionMasked == MotionEvent.ACTION_UP) {
                    handleTap(event.x, event.y)
                }
                pinchActive = false
                pressedHandleIndex = null
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        nearestHandle(x, y)?.let { handleIndex ->
            selectedPointIndex = handleIndex
            onPointSelectionChanged?.invoke(handleIndex)
            invalidate()
            return
        }

        if (allowAngleEditing) {
            renderResult.angleHitBoxes.firstOrNull { (_, box) -> box.contains(x, y) }
                ?.let { (index, _) ->
                    onAngleSelected?.invoke(
                        index,
                        ProfileGeometry.internalAngle(profile, index)
                    )
                    return
                }
        }
        renderResult.segmentHitBoxes.firstOrNull { (_, box) -> box.contains(x, y) }
            ?.let { (index, _) ->
                onSegmentSelected?.invoke(
                    index,
                    ProfileGeometry.segmentLength(profile, index)
                )
                return
            }

        if (selectedPointIndex != null) {
            selectedPointIndex = null
            onPointSelectionChanged?.invoke(null)
        }
    }

    private fun nearestHandle(x: Float, y: Float): Int? {
        val radius = resources.displayMetrics.density * 34f
        return renderResult.screenPoints
            .mapIndexed { index, point ->
                index to hypot(
                    (x - point.x).toDouble(),
                    (y - point.y).toDouble()
                ).toFloat()
            }
            .filter { it.second <= radius }
            .minByOrNull { it.second }
            ?.first
    }

    private fun modelUnitsPerScreenPixel(): Float {
        if (profile.size < 2 || renderResult.screenPoints.size < 2) return 1f
        val model = hypot(
            (profile[1].x - profile[0].x).toDouble(),
            (profile[1].y - profile[0].y).toDouble()
        ).toFloat()
        val screen = hypot(
            (renderResult.screenPoints[1].x - renderResult.screenPoints[0].x).toDouble(),
            (renderResult.screenPoints[1].y - renderResult.screenPoints[0].y).toDouble()
        ).toFloat()
        return if (screen > 0.01f) model / screen else 1f
    }

    private fun zoomBy(factor: Float) {
        val oldZoom = userZoom
        val newZoom = (oldZoom * factor).coerceIn(0.5f, 8f)
        if (kotlin.math.abs(newZoom - oldZoom) < 0.001f) return
        val ratio = newZoom / oldZoom
        val centerX = width / 2f
        val centerY = height / 2f
        userPanX = centerX - (centerX - userPanX) * ratio
        userPanY = centerY - (centerY - userPanY) * ratio
        userZoom = newZoom
        invalidate()
    }

    private fun pointerDistance(event: MotionEvent): Float {
        if (event.pointerCount < 2) return 0f
        return hypot(
            (event.getX(1) - event.getX(0)).toDouble(),
            (event.getY(1) - event.getY(0)).toDouble()
        ).toFloat()
    }

    private fun midpointX(event: MotionEvent): Float =
        if (event.pointerCount >= 2) (event.getX(0) + event.getX(1)) / 2f else event.x

    private fun midpointY(event: MotionEvent): Float =
        if (event.pointerCount >= 2) (event.getY(0) + event.getY(1)) / 2f else event.y

    private fun drawGrid(canvas: Canvas) {
        val step = resources.displayMetrics.density * 24f
        var x = userPanX % step
        while (x <= width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += step
        }
        var y = userPanY % step
        while (y <= height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += step
        }
    }
}

data class DeletePointResult(
    val deletedIndex: Int,
    val updatedPoints: MutableList<ProfilePoint>
)

data class AddPointResult(
    val insertedIndex: Int,
    val segmentIndex: Int,
    val updatedPoints: MutableList<ProfilePoint>
)
