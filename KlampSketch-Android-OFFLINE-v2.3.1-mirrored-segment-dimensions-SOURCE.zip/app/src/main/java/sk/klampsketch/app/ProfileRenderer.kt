package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class ProfileRenderResult(
    val segmentHitBoxes: List<Pair<Int, RectF>>,
    val angleHitBoxes: List<Pair<Int, RectF>>,
    val screenPoints: List<ProfilePoint>
)

object ProfileRenderer {
    fun renderTechnical(
        canvas: Canvas,
        area: RectF,
        points: List<ProfilePoint>,
        labelSize: Float,
        showHandles: Boolean,
        zoom: Float = 1f,
        panX: Float = 0f,
        panY: Float = 0f,
        selectedHandleIndex: Int? = null
    ): ProfileRenderResult {
        if (points.size < 2) {
            val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(94, 112, 128)
                textSize = labelSize
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(
                "Nakreslite profil prstom",
                area.centerX(),
                area.centerY(),
                hintPaint
            )
            return ProfileRenderResult(emptyList(), emptyList(), emptyList())
        }

        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val spanX = max(80f, maxX - minX)
        val spanY = max(80f, maxY - minY)
        val reserve = max(90f, labelSize * 5f)
        val fitScale = min(
            (area.width() - reserve * 2f) / spanX,
            (area.height() - reserve * 2f) / spanY
        ).coerceAtLeast(0.05f)
        val scale = (fitScale * zoom).coerceAtLeast(0.02f)
        val contentWidth = spanX * scale
        val contentHeight = spanY * scale
        val left = area.centerX() - contentWidth / 2f + panX
        val top = area.centerY() - contentHeight / 2f + panY

        val screenPoints = points.map {
            ProfilePoint(
                left + (it.x - minX) * scale,
                top + (it.y - minY) * scale
            )
        }

        val profilePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(17, 38, 58)
            style = Paint.Style.STROKE
            strokeWidth = max(3f, labelSize * 0.2f)
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        }
        val dimensionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(91, 109, 124)
            style = Paint.Style.STROKE
            strokeWidth = max(1.3f, labelSize * 0.09f)
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 48, 65)
            textSize = labelSize
            textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val labelBackground = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val anglePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(210, 92, 32)
            style = Paint.Style.STROKE
            strokeWidth = max(1.5f, labelSize * 0.1f)
        }
        val angleTextPaint = Paint(textPaint).apply {
            color = Color.rgb(202, 76, 24)
        }

        drawPolyline(canvas, screenPoints, profilePaint)

        val occupied = mutableListOf<RectF>()
        val segmentHits = mutableListOf<Pair<Int, RectF>>()
        screenPoints.zipWithNext().forEachIndexed { index, (start, end) ->
            val dx = end.x - start.x
            val dy = end.y - start.y
            val length = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
            val nx = -dy / length
            val ny = dx / length
            val text = "${ProfileGeometry.segmentLength(points, index)}"
            val textWidth = textPaint.measureText(text)
            val boxWidth = textWidth + labelSize * 1.2f
            val boxHeight = labelSize * 1.75f
            var selectedBox: RectF? = null
            var selectedOffsetX = 0f
            var selectedOffsetY = 0f

            val baseOffset = max(32f, labelSize * 2.2f)
            search@ for (lane in 0..7) {
                // Dĺžkové kóty sa umiestňujú zrkadlovo oproti pôvodnej strane:
                // vodorovné úseky prednostne hore a zvislé úseky prednostne vľavo.
                for (sign in listOf(-1f, 1f)) {
                    val offset = (baseOffset + lane * (boxHeight + 8f)) * sign
                    val centerX = (start.x + end.x) / 2f + nx * offset
                    val centerY = (start.y + end.y) / 2f + ny * offset
                    val candidate = RectF(
                        centerX - boxWidth / 2f,
                        centerY - boxHeight / 2f,
                        centerX + boxWidth / 2f,
                        centerY + boxHeight / 2f
                    )
                    if (inside(candidate, area, 4f) && occupied.none { expanded(it, 7f).intersected(candidate) }) {
                        selectedBox = candidate
                        selectedOffsetX = nx * offset
                        selectedOffsetY = ny * offset
                        break@search
                    }
                }
            }

            val labelBox = selectedBox ?: RectF(
                (start.x + end.x) / 2f - boxWidth / 2f,
                (start.y + end.y) / 2f - boxHeight / 2f,
                (start.x + end.x) / 2f + boxWidth / 2f,
                (start.y + end.y) / 2f + boxHeight / 2f
            )
            occupied += RectF(labelBox)
            segmentHits += index to expanded(labelBox, 12f)

            val dimStartX = start.x + selectedOffsetX
            val dimStartY = start.y + selectedOffsetY
            val dimEndX = end.x + selectedOffsetX
            val dimEndY = end.y + selectedOffsetY
            canvas.drawLine(start.x, start.y, dimStartX, dimStartY, dimensionPaint)
            canvas.drawLine(end.x, end.y, dimEndX, dimEndY, dimensionPaint)
            canvas.drawLine(dimStartX, dimStartY, dimEndX, dimEndY, dimensionPaint)
            drawArrow(canvas, dimStartX, dimStartY, dimEndX, dimEndY, dimensionPaint, labelSize)
            drawArrow(canvas, dimEndX, dimEndY, dimStartX, dimStartY, dimensionPaint, labelSize)
            canvas.drawRoundRect(labelBox, 5f, 5f, labelBackground)
            canvas.drawText(
                text,
                labelBox.centerX(),
                labelBox.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f,
                textPaint
            )
        }

        val angleHits = mutableListOf<Pair<Int, RectF>>()
        for (index in 1 until screenPoints.lastIndex) {
            val before = screenPoints[index - 1]
            val vertex = screenPoints[index]
            val after = screenPoints[index + 1]
            val beforeAngle = atan2((before.y - vertex.y).toDouble(), (before.x - vertex.x).toDouble())
            val afterAngle = atan2((after.y - vertex.y).toDouble(), (after.x - vertex.x).toDouble())
            val bisector = averageDirection(beforeAngle, afterAngle)
            val text = "${ProfileGeometry.internalAngle(points, index)}°"
            val width = angleTextPaint.measureText(text) + labelSize
            val height = labelSize * 1.7f
            var selected: RectF? = null
            var centerX = vertex.x
            var centerY = vertex.y
            search@ for (radius in listOf(labelSize * 2.6f, labelSize * 4.2f, labelSize * 5.8f, labelSize * 7.4f)) {
                for (direction in listOf(bisector, bisector + Math.PI)) {
                    val x = vertex.x + (cos(direction) * radius).toFloat()
                    val y = vertex.y + (sin(direction) * radius).toFloat()
                    val candidate = RectF(
                        x - width / 2f,
                        y - height / 2f,
                        x + width / 2f,
                        y + height / 2f
                    )
                    if (inside(candidate, area, 3f) && occupied.none { expanded(it, 6f).intersected(candidate) }) {
                        selected = candidate
                        centerX = x
                        centerY = y
                        break@search
                    }
                }
            }
            val box = selected ?: RectF(
                centerX - width / 2f,
                centerY - height / 2f,
                centerX + width / 2f,
                centerY + height / 2f
            )
            occupied += RectF(box)
            angleHits += index to expanded(box, 12f)

            val arcRadius = max(18f, labelSize * 1.45f)
            val startDegrees = Math.toDegrees(beforeAngle).toFloat()
            var sweep = Math.toDegrees(afterAngle - beforeAngle).toFloat()
            while (sweep > 180f) sweep -= 360f
            while (sweep < -180f) sweep += 360f
            canvas.drawArc(
                RectF(vertex.x - arcRadius, vertex.y - arcRadius, vertex.x + arcRadius, vertex.y + arcRadius),
                startDegrees,
                sweep,
                false,
                anglePaint
            )
            canvas.drawRoundRect(box, 5f, 5f, labelBackground)
            canvas.drawText(
                text,
                box.centerX(),
                box.centerY() - (angleTextPaint.ascent() + angleTextPaint.descent()) / 2f,
                angleTextPaint
            )
        }

        if (showHandles) {
            val outer = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.FILL
            }
            val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(8, 119, 201)
                style = Paint.Style.STROKE
                strokeWidth = max(3f, labelSize * 0.16f)
            }
            val selectedRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(236, 129, 46)
                style = Paint.Style.STROKE
                strokeWidth = max(4f, labelSize * 0.2f)
            }
            screenPoints.forEachIndexed { index, point ->
                val radius = max(9f, labelSize * 0.7f)
                if (selectedHandleIndex == index) {
                    canvas.drawCircle(point.x, point.y, radius + max(5f, labelSize * 0.22f), selectedRing)
                }
                canvas.drawCircle(point.x, point.y, radius, outer)
                canvas.drawCircle(point.x, point.y, radius, inner)
            }
        }

        return ProfileRenderResult(segmentHits, angleHits, screenPoints)
    }

    fun renderProportional3D(
        canvas: Canvas,
        area: RectF,
        points: List<ProfilePoint>,
        profileLengthMm: Float,
        labelSize: Float,
        ral: String = "",
        material: String = ""
    ) {
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 50, 66)
            textSize = labelSize
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        val infoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(91, 109, 124)
            textSize = labelSize * 0.72f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("3D NÁHĽAD SO Z-BUFFEROM", area.centerX(), area.top + labelSize, titlePaint)
        if (points.size < 2) return

        val drawArea = RectF(
            area.left + 7f,
            area.top + labelSize * 1.65f,
            area.right - 7f,
            area.bottom - labelSize * 2.15f
        )
        val bitmap = Profile3DBitmapRenderer.render(
            drawArea.width().toInt().coerceAtLeast(2),
            drawArea.height().toInt().coerceAtLeast(2),
            points,
            profileLengthMm,
            ral,
            material
        )
        canvas.drawBitmap(
            bitmap,
            null,
            drawArea,
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        )
        bitmap.recycle()

        canvas.drawText(
            "L = ${profileLengthMm.toInt()} mm  •  skryté plochy odfiltrované",
            area.centerX(),
            area.bottom - labelSize * 0.38f,
            infoPaint
        )
    }

    private fun drawPolyline(canvas: Canvas, points: List<ProfilePoint>, paint: Paint) {
        if (points.isEmpty()) return
        val path = Path()
        path.moveTo(points.first().x, points.first().y)
        points.drop(1).forEach { point -> path.lineTo(point.x, point.y) }
        canvas.drawPath(path, paint)
    }

    private fun drawArrow(
        canvas: Canvas,
        x: Float,
        y: Float,
        towardX: Float,
        towardY: Float,
        paint: Paint,
        labelSize: Float
    ) {
        val angle = atan2((towardY - y).toDouble(), (towardX - x).toDouble())
        val size = max(7f, labelSize * 0.55f)
        val left = angle + Math.toRadians(24.0)
        val right = angle - Math.toRadians(24.0)
        canvas.drawLine(x, y, x + (cos(left) * size).toFloat(), y + (sin(left) * size).toFloat(), paint)
        canvas.drawLine(x, y, x + (cos(right) * size).toFloat(), y + (sin(right) * size).toFloat(), paint)
    }

    private fun averageDirection(first: Double, second: Double): Double {
        val x = cos(first) + cos(second)
        val y = sin(first) + sin(second)
        if (hypot(x, y) < 0.001) return first + Math.PI / 2.0
        return atan2(y, x)
    }

    private fun inside(rect: RectF, area: RectF, margin: Float): Boolean =
        rect.left >= area.left + margin &&
            rect.top >= area.top + margin &&
            rect.right <= area.right - margin &&
            rect.bottom <= area.bottom - margin

    private fun expanded(rect: RectF, amount: Float) = RectF(
        rect.left - amount,
        rect.top - amount,
        rect.right + amount,
        rect.bottom + amount
    )

    private fun RectF.intersected(other: RectF): Boolean = RectF.intersects(this, other)
}
