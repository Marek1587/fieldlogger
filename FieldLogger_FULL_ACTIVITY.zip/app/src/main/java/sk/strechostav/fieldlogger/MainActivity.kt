package sk.strechostav.fieldlogger

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {

    private val reqPerm = 1001
    private val reqPhoto = 2001

    private lateinit var noteEdit: EditText
    private lateinit var statusText: TextView

    private var pendingPhotoNote: String = ""
    private var pendingPhotoFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        buildUi()
        refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(28, 28, 28, 28)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Field Logger"
        title.textSize = 28f
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "GPS + poznámky + fotky + mobilný activity logger"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Poznámka k záznamu..."
        noteEdit.minLines = 3
        noteEdit.gravity = Gravity.TOP
        root.addView(noteEdit, full())

        addButton(root, "Spustiť activity logger na pozadí") {
            startActivityLogger()
        }

        addButton(root, "Zastaviť activity logger") {
            stopService(Intent(this, AppUsageLoggerService::class.java))
            Toast.makeText(this, "Activity logger zastavený.", Toast.LENGTH_SHORT).show()
        }

        addButton(root, "Povoliť Usage Access") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }

        addButton(root, "Príchod na stavbu / miesto") {
            writeEvent("SITE_ARRIVAL", "Príchod na stavbu / miesto", takeNote())
        }

        addButton(root, "Obhliadka / kontrola") {
            writeEvent("INSPECTION", "Obhliadka / kontrola", takeNote())
        }

        addButton(root, "Meranie / zameranie") {
            writeEvent("MEASUREMENT", "Meranie / zameranie", takeNote())
        }

        addButton(root, "Telefonát / komunikácia") {
            writeEvent("PHONE_CALL", "Telefonát / komunikácia", takeNote())
        }

        addButton(root, "Odchod zo stavby / miesta") {
            writeEvent("SITE_DEPARTURE", "Odchod zo stavby / miesta", takeNote())
        }

        addButton(root, "Vlastná poznámka") {
            writeEvent("MANUAL_NOTE", "Vlastná poznámka", takeNote())
        }

        addButton(root, "Rýchly GPS zápis") {
            writeEvent("GPS_CHECK", "Rýchly GPS zápis", "")
        }

        addButton(root, "Odfotiť + zapísať fotku") {
            pendingPhotoNote = takeNote()
            openCamera()
        }

        addButton(root, "Zdieľať CSV") {
            shareCsv()
        }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, 18, 0, 0)
        root.addView(statusText, full())

        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, text: String, fn: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 15f
        b.setOnClickListener { fn() }
        root.addView(b, full())
    }

    private fun full(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(0, 8, 0, 8)
        }
    }

    private fun takeNote(): String {
        val note = noteEdit.text.toString().trim()
        noteEdit.setText("")
        return note
    }

    private fun requestPermissionsIfNeeded() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )

        val missing = perms.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), reqPerm)
        }
    }

    private fun hasUsageAccess(): Boolean {
        return try {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                android.os.Process.myUid(),
                packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        } catch (_: Exception) {
            false
        }
    }

    private fun startActivityLogger() {
        if (!hasUsageAccess()) {
            Toast.makeText(this, "Najprv povoľ Usage Access pre Field Logger.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            return
        }

        val i = Intent(this, AppUsageLoggerService::class.java)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            startForegroundService(i)
        } else {
            startService(i)
        }

        Toast.makeText(this, "Activity logger spustený.", Toast.LENGTH_SHORT).show()
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager

        if (
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        return try {
            lm.getProviders(true)
                .mapNotNull { provider ->
                    try {
                        lm.getLastKnownLocation(provider)
                    } catch (_: Exception) {
                        null
                    }
                }
                .maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun writeEvent(eventType: String, title: String, note: String, photoPath: String = "") {
        try {
            CsvStore.append(
                eventType = eventType,
                title = title,
                note = note,
                location = bestLocation(),
                photoPath = photoPath
            )
            Toast.makeText(this, "Zapísané: $title", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Chyba zápisu: ${e.message}", Toast.LENGTH_LONG).show()
        }

        refreshStatus()
    }

    private fun refreshStatus() {
        val f = CsvStore.csvFile()
        statusText.text =
            "CSV: ${f.absolutePath}\\nVeľkosť: ${f.length()} B\\nFotky: ${CsvStore.photoDir().absolutePath}\\nUsage Access: ${if (hasUsageAccess()) "povolený" else "nepovolený"}"
    }

    private fun openCamera() {
        val f = File(cacheDir, "camera_${CsvStore.stamp()}.jpg")
        pendingPhotoFile = f

        val uri: Uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            f
        )

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)

        try {
            startActivityForResult(intent, reqPhoto)
        } catch (e: Exception) {
            Toast.makeText(this, "Nepodarilo sa otvoriť fotoaparát.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Android framework")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == reqPhoto) {
            val f = pendingPhotoFile

            if (resultCode == RESULT_OK && f != null && f.exists()) {
                val small = compressImage(f)
                writeEvent(
                    "PHOTO_NOTE",
                    "Fotodokumentácia",
                    pendingPhotoNote,
                    small.absolutePath
                )
                pendingPhotoNote = ""
            } else {
                Toast.makeText(this, "Fotka nebola uložená.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun compressImage(src: File): File {
        val out = File(CsvStore.photoDir(), "photo_${CsvStore.stamp()}_compressed.jpg")
        val bmp = BitmapFactory.decodeFile(src.absolutePath) ?: return src

        val maxSide = 1600
        val scale = minOf(
            1.0f,
            maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat()
        )

        val resized = if (scale < 1.0f) {
            Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt(),
                (bmp.height * scale).toInt(),
                true
            )
        } else {
            bmp
        }

        FileOutputStream(out).use { stream ->
            resized.compress(Bitmap.CompressFormat.JPEG, 82, stream)
        }

        if (resized != bmp) {
            resized.recycle()
        }
        bmp.recycle()

        return out
    }

    private fun shareCsv() {
        val f = CsvStore.csvFile()
        val uri = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            f
        )

        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/csv"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        startActivity(Intent.createChooser(intent, "Zdieľať CSV"))
    }
}
