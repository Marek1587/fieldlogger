package sk.strechostav.fieldlogger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class AppUsageLoggerService : Service() {

    private val channelId = "field_logger_activity"
    private val notificationId = 5101
    private val handler = Handler(Looper.getMainLooper())

    private var lastPackage: String = ""
    private var lastWriteMillis: Long = 0L

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                pollForegroundApp()
            } catch (_: Exception) {
            }
            handler.postDelayed(this, 10_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(notificationId, buildNotification())

        CsvStore.append(
            eventType = "MOBILE_LOGGER_START",
            title = "Spustený mobilný activity logger",
            note = "Služba sleduje aktívnu aplikáciu cez Usage Access.",
            location = bestLocation()
        )

        handler.removeCallbacks(pollRunnable)
        handler.post(pollRunnable)

        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)

        CsvStore.append(
            eventType = "MOBILE_LOGGER_STOP",
            title = "Zastavený mobilný activity logger",
            note = "Služba bola ukončená.",
            location = bestLocation()
        )

        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun pollForegroundApp() {
        val pkg = currentForegroundPackage()
        if (pkg.isBlank()) return

        val now = System.currentTimeMillis()

        // Zapíš zmenu aplikácie hneď.
        // Ak sa aplikácia nemení, zapíš heartbeat max raz za 5 minút.
        val shouldWrite = pkg != lastPackage || (now - lastWriteMillis) > 5 * 60 * 1000L
        if (!shouldWrite) return

        val appName = appLabel(pkg)

        CsvStore.append(
            eventType = "APP_FOREGROUND",
            title = "Aktívna aplikácia",
            note = "",
            location = bestLocation(),
            packageName = pkg,
            appName = appName
        )

        lastPackage = pkg
        lastWriteMillis = now
    }

    private fun currentForegroundPackage(): String {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val begin = now - 60_000L

        val stats = usm.queryUsageStats(
            UsageStatsManager.INTERVAL_DAILY,
            begin,
            now
        )

        if (stats.isNullOrEmpty()) return ""

        return stats
            .filter { it.lastTimeUsed > 0 }
            .maxByOrNull { it.lastTimeUsed }
            ?.packageName ?: ""
    }

    private fun appLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        if (
            checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }

        return try {
            lm.getProviders(true)
                .mapNotNull { provider ->
                    try {
                        lm.getLastKnownLocation(provider)
                    } catch (_: Exception) {
                        null
                    }
                }
                .maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Field Logger beží")
            .setContentText("Logujem aktívnu aplikáciu do CSV.")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val channel = NotificationChannel(
            channelId,
            "Field Logger Activity",
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = "Mobilný activity logger na pozadí."

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }
}
