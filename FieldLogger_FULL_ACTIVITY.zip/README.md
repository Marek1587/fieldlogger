# FieldLogger FULL ACTIVITY

Stores CSV and compressed photos into public Downloads/field_logger folder.

## Output folder

/storage/emulated/0/Download/field_logger/

## Features

- GPS event log to CSV
- manual notes
- camera capture
- compressed photo
- share CSV
- background mobile activity logger
- Usage Access logging of foreground app
