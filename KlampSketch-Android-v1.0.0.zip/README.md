# KlampSketch pre Android

Tento projekt vytvorí Android APK, ktoré otvára súkromnú aplikáciu:

https://klampsketch-profilova-dielna.marek87.chatgpt.site

## Zostavenie cez pripravený GitHub Actions workflow

1. Nahrajte ZIP s týmto projektom do koreňa GitHub repozitára.
2. Súbor workflow musí byť v `.github/workflows/`.
3. Spustite workflow alebo odošlite zmenu do vetvy `main`/`master`.
4. Hotové `app-debug.apk` bude dostupné medzi Artifacts daného workflow.

Projekt podporuje fotoaparát, výber obrázkov, sťahovanie PDF, cookies
súkromného prihlásenia a návratové tlačidlo Androidu.
