package sk.klampsketch.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import android.net.http.SslError;
import android.util.Base64;

public class MainActivity extends Activity {
    private static final String APP_URL =
            "https://klampsketch-profilova-dielna.marek87.chatgpt.site";
    private static final String APP_HOST = "klampsketch-profilova-dielna.marek87.chatgpt.site";
    private static final int FILE_CHOOSER_REQUEST = 701;
    private static final int PERMISSION_REQUEST = 702;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraOutputUri;
    private volatile String currentPageUrl = "";
    private final ExecutorService fileExecutor = Executors.newSingleThreadExecutor();

    @Override
    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((view, windowInsets) -> {
                android.graphics.Insets bars = windowInsets.getInsets(
                        WindowInsets.Type.systemBars()
                );
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return windowInsets;
            });
        } else {
            root.setFitsSystemWindows(true);
        }
        webView = new WebView(this);
        progressBar = new ProgressBar(
                this,
                null,
                android.R.attr.progressBarStyleHorizontal
        );

        root.addView(
                webView,
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                )
        );

        FrameLayout.LayoutParams progressParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(3)
        );
        root.addView(progressBar, progressParams);
        setContentView(root);

        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptCookie(true);
        cookieManager.setAcceptThirdPartyCookies(webView, true);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(
                settings.getUserAgentString() + " KlampSketchAndroid/1.0"
        );

        webView.setBackgroundColor(Color.WHITE);
        webView.addJavascriptInterface(new AndroidDownloads(), "KlampSketchAndroid");
        webView.setWebViewClient(createWebViewClient());
        webView.setWebChromeClient(createWebChromeClient());
        webView.setDownloadListener(createDownloadListener());

        requestOptionalPermissions();

        if (savedInstanceState == null) {
            webView.loadUrl(APP_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private WebViewClient createWebViewClient() {
        return new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openUrl(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openUrl(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                currentPageUrl = url == null ? "" : url;
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(
                    WebView view,
                    WebResourceRequest request,
                    WebResourceError error
            ) {
                if (request.isForMainFrame()) {
                    showOfflinePage();
                }
            }

            @Override
            public void onReceivedSslError(
                    WebView view,
                    SslErrorHandler handler,
                    SslError error
            ) {
                handler.cancel();
                Toast.makeText(
                        MainActivity.this,
                        R.string.ssl_error,
                        Toast.LENGTH_LONG
                ).show();
            }
        };
    }

    private WebChromeClient createWebChromeClient() {
        return new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params
            ) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                launchImageChooser(params != null && params.getMode()
                        == FileChooserParams.MODE_OPEN_MULTIPLE);
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                            && checkSelfPermission(Manifest.permission.CAMERA)
                            == PackageManager.PERMISSION_GRANTED) {
                        for (String resource : request.getResources()) {
                            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                                request.grant(new String[]{resource});
                                return;
                            }
                        }
                    }
                    request.deny();
                });
            }
        };
    }

    private DownloadListener createDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            String fileName = safeFileName(
                    URLUtil.guessFileName(url, contentDisposition, mimeType)
            );
            if (url != null && (url.startsWith("blob:") || url.startsWith("data:"))) {
                downloadBlob(url, fileName, mimeType);
            } else {
                enqueueDownload(url, userAgent, fileName, mimeType);
            }
        };
    }

    private boolean openUrl(Uri uri) {
        String scheme = uri.getScheme();
        if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
            return false;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException ignored) {
            Toast.makeText(this, R.string.no_app_for_link, Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private void launchImageChooser(boolean allowMultiple) {
        Intent galleryIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        galleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
        galleryIntent.setType("image/*");
        galleryIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, allowMultiple);

        Intent chooser = Intent.createChooser(
                galleryIntent,
                getString(R.string.choose_photo)
        );

        Intent cameraIntent = createCameraIntent();
        if (cameraIntent != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{cameraIntent});
        }

        try {
            startActivityForResult(chooser, FILE_CHOOSER_REQUEST);
        } catch (ActivityNotFoundException error) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(null);
                fileCallback = null;
            }
            Toast.makeText(this, R.string.no_image_app, Toast.LENGTH_LONG).show();
        }
    }

    private Intent createCameraIntent() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            return null;
        }

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (cameraIntent.resolveActivity(getPackageManager()) == null) {
            return null;
        }

        try {
            File imageFile = File.createTempFile(
                    "klampsketch_",
                    ".jpg",
                    getExternalCacheDir()
            );
            cameraOutputUri = FileProvider.getUriForFile(
                    this,
                    getPackageName() + ".fileprovider",
                    imageFile
            );
            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, cameraOutputUri);
            cameraIntent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            );
            cameraIntent.setClipData(
                    ClipData.newRawUri("KlampSketch photo", cameraOutputUri)
            );
            return cameraIntent;
        } catch (Exception error) {
            cameraOutputUri = null;
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != FILE_CHOOSER_REQUEST || fileCallback == null) {
            return;
        }

        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data == null && cameraOutputUri != null) {
                result = new Uri[]{cameraOutputUri};
            } else if (data != null && data.getClipData() != null) {
                ClipData clipData = data.getClipData();
                result = new Uri[clipData.getItemCount()];
                for (int index = 0; index < clipData.getItemCount(); index++) {
                    result[index] = clipData.getItemAt(index).getUri();
                }
            } else if (data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
        }

        fileCallback.onReceiveValue(result);
        fileCallback = null;
        cameraOutputUri = null;
    }

    private void downloadBlob(String url, String fileName, String mimeType) {
        String script =
                "(async()=>{" +
                "try{" +
                "const r=await fetch(" + JSONObject.quote(url) + ");" +
                "const b=await r.blob();" +
                "const q=new FileReader();" +
                "q.onloadend=()=>KlampSketchAndroid.saveBase64File(" +
                "q.result," + JSONObject.quote(fileName) + "," +
                JSONObject.quote(mimeType == null ? "" : mimeType) + ");" +
                "q.readAsDataURL(b);" +
                "}catch(e){KlampSketchAndroid.downloadFailed();}" +
                "})()";
        webView.evaluateJavascript(script, null);
    }

    private void enqueueDownload(
            String url,
            String userAgent,
            String fileName,
            String mimeType
    ) {
        if (url == null || !url.startsWith("https://")) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_LONG).show();
            return;
        }

        try {
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(fileName);
            request.setDescription(getString(R.string.downloading));
            request.setNotificationVisibility(
                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            );
            request.setDestinationInExternalPublicDir(
                    Environment.DIRECTORY_DOWNLOADS,
                    "KlampSketch/" + fileName
            );

            if (mimeType != null && !mimeType.isEmpty()) {
                request.setMimeType(mimeType);
            }
            if (userAgent != null) {
                request.addRequestHeader("User-Agent", userAgent);
            }

            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) {
                request.addRequestHeader("Cookie", cookies);
            }

            DownloadManager manager =
                    (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, R.string.download_started, Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void saveDecodedFile(String dataUrl, String requestedName, String requestedMime) {
        if (!isTrustedAppPage()) {
            showToast(R.string.download_failed);
            return;
        }

        int comma = dataUrl == null ? -1 : dataUrl.indexOf(',');
        if (comma < 0) {
            showToast(R.string.download_failed);
            return;
        }

        try {
            String header = dataUrl.substring(0, comma);
            String mimeType = normalizeMimeType(header, requestedMime);
            String fileName = addExtensionIfMissing(
                    safeFileName(requestedName),
                    mimeType
            );
            byte[] bytes = Base64.decode(
                    dataUrl.substring(comma + 1),
                    Base64.DEFAULT
            );

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                saveWithMediaStore(bytes, fileName, mimeType);
            } else {
                saveLegacy(bytes, fileName);
            }
            showToast(R.string.download_finished);
        } catch (Exception error) {
            showToast(R.string.download_failed);
        }
    }

    private void saveWithMediaStore(byte[] bytes, String fileName, String mimeType)
            throws Exception {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
        values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
        values.put(
                MediaStore.Downloads.RELATIVE_PATH,
                Environment.DIRECTORY_DOWNLOADS + "/KlampSketch"
        );
        values.put(MediaStore.Downloads.IS_PENDING, 1);

        Uri item = getContentResolver().insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
        );
        if (item == null) {
            throw new IllegalStateException("Download item was not created.");
        }

        try (OutputStream output = getContentResolver().openOutputStream(item)) {
            if (output == null) {
                throw new IllegalStateException("Download stream was not opened.");
            }
            output.write(bytes);
        }

        values.clear();
        values.put(MediaStore.Downloads.IS_PENDING, 0);
        getContentResolver().update(item, values, null, null);
    }

    @SuppressWarnings("deprecation")
    private void saveLegacy(byte[] bytes, String fileName) throws Exception {
        File downloads = new File(
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS
                ),
                "KlampSketch"
        );
        if (!downloads.exists() && !downloads.mkdirs()) {
            throw new IllegalStateException("Downloads folder was not created.");
        }

        File outputFile = uniqueFile(downloads, fileName);
        try (FileOutputStream output = new FileOutputStream(outputFile)) {
            output.write(bytes);
        }

        Intent scan = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        scan.setData(Uri.fromFile(outputFile));
        sendBroadcast(scan);
    }

    private File uniqueFile(File directory, String fileName) {
        File candidate = new File(directory, fileName);
        if (!candidate.exists()) {
            return candidate;
        }

        int dot = fileName.lastIndexOf('.');
        String base = dot > 0 ? fileName.substring(0, dot) : fileName;
        String extension = dot > 0 ? fileName.substring(dot) : "";
        return new File(
                directory,
                base + "-" + System.currentTimeMillis() + extension
        );
    }

    private String normalizeMimeType(String dataHeader, String requestedMime) {
        if (dataHeader.startsWith("data:application/pdf")) {
            return "application/pdf";
        }
        if (dataHeader.startsWith("data:image/png")) {
            return "image/png";
        }
        if (dataHeader.startsWith("data:image/jpeg")) {
            return "image/jpeg";
        }
        if (requestedMime != null && requestedMime.startsWith("image/")) {
            return requestedMime;
        }
        return "application/pdf";
    }

    private String addExtensionIfMissing(String fileName, String mimeType) {
        if (fileName.contains(".")) {
            return fileName;
        }
        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType);
        return extension == null ? fileName : fileName + "." + extension;
    }

    private String safeFileName(String input) {
        String fallback =
                "KlampSketch-" +
                new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) +
                ".pdf";
        if (input == null || input.trim().isEmpty()) {
            return fallback;
        }
        String safe = input.replaceAll("[\\\\/:*?\"<>|\\r\\n]", "_").trim();
        return safe.isEmpty() ? fallback : safe;
    }

    private boolean isTrustedAppPage() {
        try {
            Uri uri = Uri.parse(currentPageUrl);
            return "https".equalsIgnoreCase(uri.getScheme())
                    && APP_HOST.equalsIgnoreCase(uri.getHost());
        } catch (Exception ignored) {
            return false;
        }
    }

    private void showOfflinePage() {
        String html =
                "<!doctype html><html lang='sk'><meta name='viewport' " +
                "content='width=device-width,initial-scale=1'>" +
                "<body style='font-family:sans-serif;padding:32px;text-align:center;" +
                "color:#12263a'><h2>KlampSketch je offline</h2>" +
                "<p>Skontrolujte internetové pripojenie a skúste to znova.</p>" +
                "<button style='padding:12px 18px;border:0;border-radius:10px;" +
                "background:#0877c9;color:white;font-size:16px' " +
                "onclick='location.href=" + JSONObject.quote(APP_URL) + "'>" +
                "Skúsiť znova</button></body></html>";
        webView.loadDataWithBaseURL(APP_URL, html, "text/html", "UTF-8", null);
    }

    private void requestOptionalPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            boolean cameraMissing =
                    checkSelfPermission(Manifest.permission.CAMERA)
                            != PackageManager.PERMISSION_GRANTED;
            boolean storageMissing =
                    Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                            && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                            != PackageManager.PERMISSION_GRANTED;

            if (cameraMissing && storageMissing) {
                requestPermissions(
                        new String[]{
                                Manifest.permission.CAMERA,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                        },
                        PERMISSION_REQUEST
                );
            } else if (cameraMissing) {
                requestPermissions(
                        new String[]{Manifest.permission.CAMERA},
                        PERMISSION_REQUEST
                );
            } else if (storageMissing) {
                requestPermissions(
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        PERMISSION_REQUEST
                );
            }
        }
    }

    private void showToast(int messageResource) {
        runOnUiThread(() ->
                Toast.makeText(this, messageResource, Toast.LENGTH_LONG).show()
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("KlampSketchAndroid");
            webView.destroy();
        }
        fileExecutor.shutdownNow();
        super.onDestroy();
    }

    public class AndroidDownloads {
        @JavascriptInterface
        public void saveBase64File(String dataUrl, String fileName, String mimeType) {
            fileExecutor.execute(() -> saveDecodedFile(dataUrl, fileName, mimeType));
        }

        @JavascriptInterface
        public void downloadFailed() {
            showToast(R.string.download_failed);
        }
    }
}
