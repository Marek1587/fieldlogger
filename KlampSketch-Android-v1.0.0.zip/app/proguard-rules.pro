-keepclassmembers class sk.klampsketch.app.MainActivity$AndroidDownloads {
    @android.webkit.JavascriptInterface <methods>;
}
