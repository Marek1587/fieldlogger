(function (root) {
  "use strict";
  const TICKS_PER_MM = 100;

  function parseDimension(value, unit) {
    const normalized = String(value).trim().replace(/\s/g, "").replace(",", ".");
    const number = Number(normalized);
    if (!Number.isFinite(number)) return null;
    return Math.round(number * (unit === "cm" ? 1000 : TICKS_PER_MM));
  }

  function formatDimension(ticks, unit, withUnit) {
    const divider = unit === "cm" ? 1000 : TICKS_PER_MM;
    const value = ticks / divider;
    const text = new Intl.NumberFormat("sk-SK", { maximumFractionDigits: unit === "cm" ? 3 : 2 }).format(value);
    return withUnit === false ? text : text + " " + unit;
  }

  function validate(input) {
    const errors = [];
    if (!Number.isInteger(input.targetLength) || input.targetLength <= 0) errors.push("Cieľová dĺžka musí byť väčšia ako nula.");
    if (!Number.isInteger(input.nominalWidth) || input.nominalWidth <= 0) errors.push("Šírka dielu musí byť väčšia ako nula.");
    if ((input.fixedLeft || 0) < 0 || (input.fixedRight || 0) < 0) errors.push("Pevné kraje nemôžu byť záporné.");
    if ((input.fixedLeft || 0) + (input.fixedRight || 0) >= input.targetLength) errors.push("Pevné kraje musia byť spolu menšie než cieľová dĺžka.");
    if ((input.minCorrection || 0) < 0 || (input.maxCorrection || 0) < 0) errors.push("Tolerancia nemôže byť záporná.");
    return errors;
  }

  function calculateBasicLayout(input) {
    const errors = validate(input);
    if (!errors.length && input.nominalWidth > input.targetLength) errors.push("Šírka dielu nemôže byť väčšia než cieľová dĺžka.");
    if (errors.length) return { ok: false, errors: errors };
    const fullPieceCount = Math.floor(input.targetLength / input.nominalWidth);
    const remainder = input.targetLength - fullPieceCount * input.nominalWidth;
    const leftEdge = remainder / 2;
    const rightEdge = remainder - leftEdge;
    return { ok: true, targetLength: input.targetLength, nominalWidth: input.nominalWidth, fullPieceCount: fullPieceCount, remainder: remainder, leftEdge: leftEdge, rightEdge: rightEdge, achievedLength: leftEdge + fullPieceCount * input.nominalWidth + rightEdge };
  }

  function distributeCorrection(input) {
    const minSteps = Math.ceil(-input.minCorrection / input.step);
    const maxSteps = Math.floor(input.maxCorrection / input.step);
    const wantedSteps = Math.round(input.totalCorrection / input.step);
    const totalSteps = Math.max(input.pieceCount * minSteps, Math.min(input.pieceCount * maxSteps, wantedSteps));
    const base = Math.floor(totalSteps / input.pieceCount);
    const raised = totalSteps - base * input.pieceCount;
    return {
      corrections: Array.from({ length: input.pieceCount }, function (_, index) { return (index < raised ? base + 1 : base) * input.step; }),
      appliedCorrection: totalSteps * input.step
    };
  }

  function makeCandidate(input, pieceCount) {
    const nominalTotal = input.fixedLeft + input.fixedRight + pieceCount * input.nominalWidth;
    const requiredCorrection = input.targetLength - nominalTotal;
    const distribution = distributeCorrection({ pieceCount: pieceCount, totalCorrection: requiredCorrection, step: input.step, minCorrection: input.minCorrection, maxCorrection: input.maxCorrection });
    const pieces = distribution.corrections.map(function (correction, index) { return { index: index + 1, nominalWidth: input.nominalWidth, correction: correction, finalWidth: input.nominalWidth + correction }; });
    const achievedLength = nominalTotal + distribution.appliedCorrection;
    return { targetLength: input.targetLength, nominalWidth: input.nominalWidth, pieceCount: pieceCount, fixedLeft: input.fixedLeft, fixedRight: input.fixedRight, nominalTotal: nominalTotal, requiredCorrection: requiredCorrection, correctionPerPiece: requiredCorrection / pieceCount, pieces: pieces, achievedLength: achievedLength, residualError: achievedLength - input.targetLength, exact: achievedLength === input.targetLength, appliedCorrection: distribution.appliedCorrection, averageCorrection: Math.abs(distribution.appliedCorrection / pieceCount) };
  }

  function solveCorrection(input) {
    const errors = validate(input);
    if (!Number.isInteger(input.step) || input.step <= 0) errors.push("Krok korekcie musí byť väčší ako nula.");
    if (errors.length) return { ok: false, errors: errors };
    const available = input.targetLength - input.fixedLeft - input.fixedRight;
    const minimumWidth = Math.max(1, input.nominalWidth - input.minCorrection);
    const maxCount = Math.min(500, Math.max(1, Math.ceil(available / minimumWidth) + 2));
    const counts = input.pieceCount ? [input.pieceCount] : Array.from({ length: maxCount }, function (_, index) { return index + 1; });
    const candidates = counts.map(function (count) { return makeCandidate(input, count); });
    candidates.sort(function (a, b) { return Math.abs(a.residualError) - Math.abs(b.residualError) || a.averageCorrection - b.averageCorrection || Math.abs(a.pieceCount - available / input.nominalWidth) - Math.abs(b.pieceCount - available / input.nominalWidth); });
    const best = candidates[0];
    best.ok = true;
    best.minimumTolerance = Math.abs(best.requiredCorrection / best.pieceCount);
    return best;
  }

  function groupPieces(pieces) {
    const map = new Map();
    pieces.forEach(function (piece) {
      const key = piece.finalWidth + ":" + piece.correction;
      const group = map.get(key) || { count: 0, finalWidth: piece.finalWidth, correction: piece.correction };
      group.count += 1;
      map.set(key, group);
    });
    return Array.from(map.values()).sort(function (a, b) { return b.correction - a.correction; });
  }

  function solveRightTriangle(values, manualSides) {
    const manual = manualSides.slice(-2);
    const computedSide = ["a", "b", "c"].find(function (side) { return !manual.includes(side); });
    if (!computedSide || manual.some(function (side) { return !Number.isFinite(values[side]) || values[side] <= 0; })) {
      return { ok: false, computedSide: computedSide || null, values: Object.assign({}, values) };
    }
    let squared;
    if (computedSide === "c") squared = values.a * values.a + values.b * values.b;
    if (computedSide === "a") squared = values.c * values.c - values.b * values.b;
    if (computedSide === "b") squared = values.c * values.c - values.a * values.a;
    if (!(squared > 0)) return { ok: false, computedSide: computedSide, values: Object.assign({}, values) };
    const result = Object.assign({}, values);
    result[computedSide] = Math.round(Math.sqrt(squared) / TICKS_PER_MM) * TICKS_PER_MM;
    return { ok: true, computedSide: computedSide, values: result };
  }

  function solveRectangleSquaring(values) {
    const length = values && values.length;
    const d1 = values && values.d1;
    const d2 = values && values.d2;
    if (![length, d1, d2].every(function (value) { return Number.isFinite(value) && value > 0; })) {
      return { ok: false, errors: ["Rozmery musia byť kladné čísla."] };
    }
    const sideSquared = (d1 * d1 + d2 * d2) / 2 - length * length;
    if (!(sideSquared > 0)) return { ok: false, errors: ["Dĺžka L je príliš veľká vzhľadom na diagonály."] };
    const rawSignedX = (d2 * d2 - d1 * d1) / (8 * length);
    const signedX = Math.round(rawSignedX / TICKS_PER_MM) * TICKS_PER_MM;
    const derivedHeight = Math.sqrt(sideSquared);
    const angleRatio = Math.abs(d2 * d2 - d1 * d1) / (4 * length * derivedHeight);
    if (angleRatio > 1 + 1e-9) return { ok: false, errors: ["Z rozmerov nevznikne platný kosodĺžnik."] };
    const skewAngleDegrees = Math.asin(Math.min(1, angleRatio)) * 180 / Math.PI;
    return {
      ok: true,
      x: Math.abs(signedX),
      signedX: signedX,
      wholeSideShift: Math.abs(signedX) * 2,
      longerDiagonal: d2 >= d1 ? "d2" : "d1",
      derivedHeight: Math.round(derivedHeight),
      skewAngleDegrees: skewAngleDegrees,
      signedSkewAngleDegrees: (d2 >= d1 ? 1 : -1) * skewAngleDegrees
    };
  }

  function solveSheetPerpendicular(values) {
    const width = values && values.width;
    const angleDegrees = values && values.angleDegrees;
    if (!Number.isFinite(width) || width <= 0) return { ok: false, errors: ["Šírka pásu musí byť kladná."] };
    if (!Number.isFinite(angleDegrees) || angleDegrees <= 0 || angleDegrees >= 90) {
      return { ok: false, errors: ["Uhol musí byť väčší ako 0° a menší ako 90°."] };
    }
    const angleRadians = angleDegrees * Math.PI / 180;
    return { ok: true, x: Math.round(width * Math.tan(angleRadians) / TICKS_PER_MM) * TICKS_PER_MM, width: width, angleDegrees: angleDegrees };
  }

  const api = { TICKS_PER_MM: TICKS_PER_MM, parseDimension: parseDimension, formatDimension: formatDimension, calculateBasicLayout: calculateBasicLayout, distributeCorrection: distributeCorrection, solveCorrection: solveCorrection, groupPieces: groupPieces, solveRightTriangle: solveRightTriangle, solveRectangleSquaring: solveRectangleSquaring, solveSheetPerpendicular: solveSheetPerpendicular };
  root.GeometrySolver = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
