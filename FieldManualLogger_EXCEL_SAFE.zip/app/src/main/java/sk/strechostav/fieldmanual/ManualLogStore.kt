package sk.strechostav.fieldmanual

import android.content.Context
import android.location.Location
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

object ManualLogStore {
    private val header = listOf(
        "timestamp",
        "event_type",
        "lat",
        "lon",
        "accuracy_m",
        "provider",
        "title",
        "note",
        "photo_path"
    )

    fun baseDir(context: Context): File {
        val d = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "FieldLogger")
        d.mkdirs()
        return d
    }

    fun photoDir(context: Context): File {
        val d = File(baseDir(context), "photos")
        d.mkdirs()
        return d
    }

    fun dataFile(context: Context): File {
        val f = File(baseDir(context), "field_manual_log_data.tsv")
        if (!f.exists()) {
            f.writeText(header.joinToString("\t") + "\n", Charsets.UTF_8)
        }
        return f
    }

    fun localXlsxFile(context: Context): File {
        return File(baseDir(context), "field_manual_log.xlsx")
    }

    fun now(): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
    fun stamp(): String = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    fun append(
        context: Context,
        eventType: String,
        title: String,
        note: String = "",
        location: Location? = null,
        photoPath: String = ""
    ): Boolean {
        return try {
            val values = listOf(
                now(),
                eventType,
                location?.latitude?.toString() ?: "",
                location?.longitude?.toString() ?: "",
                location?.accuracy?.toString() ?: "",
                location?.provider ?: "",
                title,
                note,
                photoPath
            )
            dataFile(context).appendText(values.joinToString("\t") { clean(it) } + "\n", Charsets.UTF_8)
            rebuildLocalXlsx(context)
            exportToConfiguredDocument(context)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun rows(context: Context): List<List<String>> {
        val f = dataFile(context)
        return f.readLines(Charsets.UTF_8).map { it.split("\t") }
    }

    fun rebuildLocalXlsx(context: Context): Boolean {
        return try {
            FileOutputStream(localXlsxFile(context)).use { out ->
                XlsxWriter.writeWorkbook(out, rows(context))
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun configuredDocumentUri(context: Context): Uri? {
        val s = context.getSharedPreferences("field_manual_logger", Context.MODE_PRIVATE)
            .getString("excel_uri", null)
        return if (s.isNullOrBlank()) null else Uri.parse(s)
    }

    fun setConfiguredDocumentUri(context: Context, uri: Uri) {
        context.getSharedPreferences("field_manual_logger", Context.MODE_PRIVATE)
            .edit()
            .putString("excel_uri", uri.toString())
            .apply()
    }

    fun exportToConfiguredDocument(context: Context): Boolean {
        val uri = configuredDocumentUri(context) ?: return false
        return try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { out ->
                XlsxWriter.writeWorkbook(out, rows(context))
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun clean(value: String): String {
        return value.replace("\n", " ").replace("\r", " ").replace("\t", " ").trim()
    }
}
