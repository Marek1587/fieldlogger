# Field Manual Logger EXCEL SAFE

Robustná ručná Android aplikácia pre terénny denník.

## Dôležité

Aplikácia už nezapisuje priamo do verejného priečinka pri štarte.
Používa bezpečné lokálne úložisko a umožní nastaviť Excel súbor v Dokumentoch cez systémový výber súboru.

## Odporúčaný postup v appke

1. Otvor aplikáciu.
2. Klikni "Nastaviť Excel v Dokumentoch".
3. Vyber priečinok Dokumenty a vytvor `field_manual_log.xlsx`.
4. Potom každý záznam prepíše aj tento Excel.
