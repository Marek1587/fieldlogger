package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WallFootprintSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun rectangleProducesOneMainTract() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 7.0),
            LocalPoint(0.0, 7.0)
        )

        val solution = WallFootprintSolver.refresh(project)

        assertEquals(1, solution.parts.size)
        assertEquals(WallFootprintPartType.MAIN_TRACT, solution.parts.single().type)
        assertTrue(solution.parts.single().id.startsWith("wall-part-"))
    }

    @Test
    fun lFootprintProducesMainTractAndSemanticSecondaryRegion() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )

        val solution = WallFootprintSolver.refresh(project)

        assertTrue(solution.parts.any { it.type == WallFootprintPartType.MAIN_TRACT })
        assertTrue(solution.parts.any {
            it.type in setOf(
                WallFootprintPartType.PROJECTION,
                WallFootprintPartType.SEPARATE_WING
            )
        })
        assertTrue(solution.parts.any { it.type == WallFootprintPartType.RECESS })
    }

    @Test
    fun userClassificationSurvivesBoundedOutlineCorrection() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )
        WallFootprintSolver.refresh(project)
        val secondary = project.wallFootprintParts.first {
            it.type in setOf(WallFootprintPartType.PROJECTION, WallFootprintPartType.SEPARATE_WING)
        }
        secondary.type = WallFootprintPartType.SEPARATE_WING
        secondary.source = WallFootprintPartSource.USER

        project.wallFootprint = listOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.1, 0.0),
            LocalPoint(12.1, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        ).map { Geometry.toGeo(it, origin) }.toMutableList()
        val refreshed = WallFootprintSolver.refresh(project)

        assertTrue(refreshed.parts.any {
            it.type == WallFootprintPartType.SEPARATE_WING &&
                it.source == WallFootprintPartSource.USER
        })
    }

    @Test
    fun semanticPartsRoundTripThroughCanonicalProjectJson() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(8.0, 0.0),
            LocalPoint(8.0, 5.0),
            LocalPoint(0.0, 5.0)
        )
        WallFootprintSolver.refresh(project)
        project.wallFootprintParts.single().apply {
            type = WallFootprintPartType.PROJECTION
            source = WallFootprintPartSource.USER
        }

        val restored = ProjectJson.decode(ProjectJson.encode(project))

        assertFalse(restored.wallFootprintPartsSignature.isBlank())
        assertEquals(1, restored.wallFootprintParts.size)
        assertEquals(WallFootprintPartType.PROJECTION, restored.wallFootprintParts.single().type)
        assertEquals(WallFootprintPartSource.USER, restored.wallFootprintParts.single().source)
        assertEquals(project.wallFootprintParts.single().id, restored.wallFootprintParts.single().id)
    }

    private fun projectOf(vararg points: LocalPoint): RoofProject = RoofProject(
        centerLat = origin.lat,
        centerLon = origin.lon,
        geometryGridOriginLat = origin.lat,
        geometryGridOriginLon = origin.lon,
        geometryGridRotationDeg = 0.0,
        polygon = points.map { Geometry.toGeo(it, origin) }.toMutableList(),
        wallFootprint = points.map { Geometry.toGeo(it, origin) }.toMutableList()
    )
}
