# Geometria 1.10.0

Kompletná offline Android aplikácia na presné rozdelenie cieľovej dĺžky na opakované diely a korekciu ich šírky.

## Funkcie

- rozdelenie dĺžky cez jednoduchý technický vstupný nákres s klikateľnými kótami L a a,
- automatický výsledný nákres s počtom dielov a symetrickými krajmi y/2,
- zvislé prerušovacie značky medzi krajnými dielmi `y/2` a strednou časťou `n × a`,
- dva proporcionálne výsledky rozdelenia: symetrické `y/2 + n × a + y/2` a jednostranné `y + n × a`, oba so zdieľaním obrázka,
- automatické hľadanie optimálneho počtu dielov,
- korekcia šírky s toleranciou a krokom 0,1 / 0,5 / 1 mm,
- proporcionálny technický korekčný plán v rovnakom štýle ako rozdelenie so zdieľaním obrázka,
- presná celočíselná aritmetika s interným základom 0,01 mm,
- všetky vstupné dĺžkové kóty cez koliesko alebo šípky po 5 mm; uhlové kóty po 1°,
- pravouhlý trojuholník podľa Pytagorovej vety: dve naposledy upravené strany určujú automaticky dopočítanú tretiu stranu,
- uhlovanie z hornej dĺžky L1, spodnej dĺžky L2 a diagonál d1/d2 s rekonštrukciou lichobežníka, samostatnými posunmi X1/X2 a výpočtom všetkých štyroch uhlov,
- automatické označenie každého 90° rohu štvrťkružnicou s bodkou; pri nepravouhlom výsledku sa žiadny roh neoznačí,
- výpočet kolmice cez šikmý pás plechu zo šírky V a uhla α s výsledným posunom X,
- rozloženie príponiek na páse: dĺžka L po 5 mm, sklon strechy po 1°, pevný raster 300 mm, číslované zóny a presná poloha každej pevnej alebo posuvnej príponky,
- automatická pevná zóna podľa sklonu: stred, 2/3, 3/4 alebo pri hrebeni; dĺžka zóny 1 m do dĺžky pásu 10 m a 3 m nad 10 m,
- pevné príponky ako štvorce, posuvné ako elipsy, jedno-stĺpcový zoznam od odkvapu a automatický súčet skrutiek,
- násobenie počtu pevných a posuvných príponiek aj skrutiek podľa používateľom zadaného počtu pásov,
- samostatný modul dilatácie hornej posuvnej zóny pre oceľ, prepojený s dĺžkou pásu a horným okrajom pevnej zóny z modulu Príponky,
- nastaviteľný priemer skrutky po 0,1 mm, výpočet tepelného pohybu pri ΔT 100 K, minimálnej dĺžky otvoru a normalizovaného párneho otvoru vrátane montážnej rezervy 2 mm,
- modul zvodov s dvoma kolenami 40° / 72° / 87°, nastaviteľnými osovými rozmermi X a Y, priemerom rúry P a zasunutím na oboch koncoch,
- rezná dĺžka šikmej rúry R vrátane zasunutí a automatický návrh korekcie rozmeru Y pre zvolený uhol kolien,
- zdieľanie technických nákresov trojuholníka, uhlovania a kolmice ako PNG obrázkov,
- celé milimetre pre stavebné kóty a automaticky vypočítané hodnoty X,
- technické čiarové nákresy s kótami pre všetky výpočtové režimy,
- podrobný matematický postup a kontrolný súčet,
- montážny výstup s kopírovaním a systémovým zdieľaním,
- vysoký kontrast a kompaktný režim,
- úplná prevádzka bez internetu, účtu a servera.

## Zostavenie

Projekt vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2.

```text
node --test tests/*.test.js
gradle :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

GitHub workflow `.github/workflows/build-apk.yml` spustí testy a vytvorí release APK automaticky.
