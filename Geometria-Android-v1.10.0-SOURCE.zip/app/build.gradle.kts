plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.geometria.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.geometria.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 13
        versionName = "1.10.0"
    }

    signingConfigs {
        create("stableUpdate") {
            storeFile = file("geometria-update-key.jks")
            storePassword = "android"
            keyAlias = "geometria-update"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableUpdate")
            applicationIdSuffix = ""
        }
        release {
            signingConfig = signingConfigs.getByName("stableUpdate")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
}
