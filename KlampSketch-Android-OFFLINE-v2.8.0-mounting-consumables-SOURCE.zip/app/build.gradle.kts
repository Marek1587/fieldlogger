plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.klampsketch.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.klampsketch.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 21
        versionName = "2.8.0-mounting-consumables"
    }

    signingConfigs {
        create("stableUpdate") {
            storeFile = file("klampsketch-update-key.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableUpdate")
        }
        release {
            signingConfig = signingConfigs.getByName("stableUpdate")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
    testImplementation("junit:junit:4.13.2")
}
