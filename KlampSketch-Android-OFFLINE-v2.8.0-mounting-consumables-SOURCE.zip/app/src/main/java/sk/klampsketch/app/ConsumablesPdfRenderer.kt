package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.ceil

object ConsumablesPdfRenderer {
    private const val PAGE_WIDTH = 595f
    private const val PAGE_HEIGHT = 842f
    private const val ROWS_PER_PAGE = 12

    fun pageCount(drawings: List<DrawingRecord>): Int =
        ceil(drawings.size / ROWS_PER_PAGE.toDouble()).toInt().coerceAtLeast(1)

    fun drawPage(
        canvas: Canvas,
        project: ProjectRecord,
        drawings: List<DrawingRecord>,
        summaryPageIndex: Int,
        globalPageNumber: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)
        val dark = Color.rgb(25, 42, 55)
        val muted = Color.rgb(81, 98, 110)
        val blue = Color.rgb(8, 119, 201)
        val green = Color.rgb(28, 111, 66)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(55, 70, 80)
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        val title = textPaint(dark, 17f, true)
        val subtitle = textPaint(muted, 7.5f, true)
        val label = textPaint(muted, 6.2f, true)
        val value = textPaint(dark, 10f, true)
        val tableHeader = textPaint(Color.WHITE, 5.2f, true)
        val tableText = textPaint(dark, 5.8f, false)
        val tableBold = textPaint(dark, 5.8f, true)

        canvas.drawRect(RectF(22f, 22f, PAGE_WIDTH - 22f, PAGE_HEIGHT - 22f), border)
        canvas.drawText("MONTÁŽNY MATERIÁL A TMEL", 34f, 51f, title)
        canvas.drawText("STAVBA: ${project.name}", 34f, 69f, subtitle)
        canvas.drawText("LIST $globalPageNumber/$totalPages", 510f, 51f, subtitle)

        val all = drawings.map { drawing ->
            ConsumableRow(drawing, calculateConsumables(drawing))
        }
        val screws = all.sumOf { it.metrics.screwsTotal }
        val rivets = all.sumOf { it.metrics.rivetsTotal }
        val endSealantMl = all.sumOf { it.metrics.endSealantPerPieceMl * it.drawing.quantity.coerceAtLeast(1) }
        val topSealantMl = all.sumOf { it.metrics.topEdgeSealantPerPieceMl * it.drawing.quantity.coerceAtLeast(1) }
        val totalSealantMl = endSealantMl + topSealantMl
        val cartridges = ceil(totalSealantMl / SEALANT_CARTRIDGE_ML).toInt()

        val boxes = listOf(
            "SKRUTKY á 300 mm" to "$screws ks",
            "NITY - 6 NA KUS" to "$rivets ks",
            "TMEL - KONCE" to "${formatDecimal(endSealantMl)} ml",
            "TMEL - HORNÁ HRANA" to "${formatDecimal(topSealantMl)} ml",
            "TMEL SPOLU" to "${formatDecimal(totalSealantMl)} ml",
            "KARTUŠE 310 ml" to "$cartridges ks"
        )
        boxes.forEachIndexed { index, (boxLabel, boxValue) ->
            val column = index % 3
            val row = index / 3
            val left = 34f + column * 176f
            val top = 88f + row * 52f
            val rect = RectF(left, top, left + 165f, top + 42f)
            canvas.drawRect(rect, border)
            canvas.drawText(boxLabel, rect.left + 7f, rect.top + 13f, label)
            canvas.drawText(boxValue, rect.left + 7f, rect.top + 33f, value)
        }

        canvas.drawText(
            "Skrutky: stropný rozstup 300 mm, zaokrúhlenie nahor. Nity: 3 na každý koniec = 6 na kus.",
            34f,
            201f,
            subtitle
        )
        canvas.drawText(
            "Tmel koncov: predná + zadná rozvinutá šírka × 50 ml/m. Horná hrana: dĺžka profilu × 30 ml/m.",
            34f,
            213f,
            subtitle
        )

        val columns = floatArrayOf(34f, 144f, 166f, 201f, 238f, 278f, 310f, 348f, 413f, 456f, 499f, 561f)
        val headers = arrayOf(
            "ID / VÝROBOK", "KS", "L m", "SKR./KS", "SKR. Σ", "NIT/KS",
            "NIT Σ", "TMELENIE", "KONCE ml", "HRANA ml", "TMEL Σ ml"
        )
        val headerTop = 224f
        val headerBottom = 246f
        val headerFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = blue
            style = Paint.Style.FILL
        }
        headers.indices.forEach { index ->
            val cell = RectF(columns[index], headerTop, columns[index + 1], headerBottom)
            canvas.drawRect(cell, headerFill)
            canvas.drawRect(cell, border)
            drawCenteredFittedText(canvas, headers[index], cell, tableHeader)
        }

        val pageRows = all.drop(summaryPageIndex * ROWS_PER_PAGE).take(ROWS_PER_PAGE)
        val rowHeight = 34f
        pageRows.forEachIndexed { rowIndex, row ->
            val quantity = row.drawing.quantity.coerceAtLeast(1)
            val values = arrayOf(
                "${row.drawing.identifier}  ${row.drawing.name}",
                quantity.toString(),
                formatDecimal(row.drawing.profileLengthM),
                row.metrics.screwsPerPiece.toString(),
                row.metrics.screwsTotal.toString(),
                row.metrics.rivetsPerPiece.toString(),
                row.metrics.rivetsTotal.toString(),
                row.drawing.sealantMode.label,
                formatDecimal(row.metrics.endSealantPerPieceMl * quantity),
                formatDecimal(row.metrics.topEdgeSealantPerPieceMl * quantity),
                formatDecimal(row.metrics.sealantTotalMl)
            )
            val top = headerBottom + rowIndex * rowHeight
            values.forEachIndexed { column, text ->
                val cell = RectF(columns[column], top, columns[column + 1], top + rowHeight)
                canvas.drawRect(cell, border)
                drawCenteredFittedText(
                    canvas,
                    text,
                    RectF(cell.left + 2f, cell.top, cell.right - 2f, cell.bottom),
                    if (column == 0 || column == 10) tableBold else tableText
                )
            }
        }

        val validationY = (headerBottom + pageRows.size * rowHeight + 28f).coerceAtMost(710f)
        canvas.drawText(
            "TMEL SPOLU ${formatDecimal(totalSealantMl)} ml / ${formatDecimal(SEALANT_CARTRIDGE_ML, 0)} ml = " +
                "$cartridges celých kartuší (zaokrúhlené nahor)",
            34f,
            validationY,
            textPaint(dark, 10f, true)
        )
        canvas.drawText(
            "KONTROLA OK: súčet položiek = $screws skrutiek, $rivets nitov a ${formatDecimal(totalSealantMl)} ml tmelu.",
            34f,
            validationY + 22f,
            textPaint(green, 7f, true)
        )
    }

    private fun textPaint(color: Int, size: Float, bold: Boolean) =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun drawCenteredFittedText(
        canvas: Canvas,
        text: String,
        area: RectF,
        sourcePaint: Paint
    ) {
        val paint = Paint(sourcePaint).apply { textAlign = Paint.Align.CENTER }
        var value = text
        while (value.length > 2 && paint.measureText(value) > area.width()) {
            value = value.dropLast(2) + "…"
        }
        val baseline = area.centerY() - (paint.ascent() + paint.descent()) / 2f
        canvas.drawText(value, area.centerX(), baseline, paint)
    }

    private data class ConsumableRow(
        val drawing: DrawingRecord,
        val metrics: ConsumablesMetrics
    )
}
