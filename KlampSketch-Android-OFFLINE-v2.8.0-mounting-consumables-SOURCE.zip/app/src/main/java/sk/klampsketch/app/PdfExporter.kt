package sk.klampsketch.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.core.content.FileProvider

data class ExportedPdf(
    val displayPath: String,
    val shareUri: Uri
)

object PdfExporter {
    private const val A4_PORTRAIT_WIDTH = 595
    private const val A4_PORTRAIT_HEIGHT = 842
    private const val A4_LANDSCAPE_WIDTH = 842
    private const val A4_LANDSCAPE_HEIGHT = 595
    private const val VIRTUAL_PAGE_WIDTH = 1240f
    private const val VIRTUAL_PAGE_HEIGHT = 1754f
    private const val PDF_POINTS_PER_MM = 72f / 25.4f
    private const val MAIN_PAGE_TO_PDF_SCALE = A4_PORTRAIT_WIDTH / VIRTUAL_PAGE_WIDTH

    fun export(
        context: Context,
        project: ProjectRecord,
        drawings: List<DrawingRecord>,
        cutPlan: CoilCutPlan? = null
    ): ExportedPdf {
        require(drawings.isNotEmpty()) { "Nie sú vybrané žiadne výkresy." }
        val pages = drawings.flatMap { drawing ->
            buildList {
                add(PageSpec(drawing, PageType.MAIN))
                if (drawing.validBackPoints() != null) {
                    add(PageSpec(drawing, PageType.DEVELOPED))
                }
            }
        }
        val cutPlanPageCount = cutPlan?.let(CoilCutPlanPdfRenderer::pageCount) ?: 0
        val consumablesPageCount = ConsumablesPdfRenderer.pageCount(drawings)
        val totalPages = pages.size + cutPlanPageCount + consumablesPageCount
        val document = PdfDocument()
        try {
            pages.forEachIndexed { index, spec ->
                val isDeveloped = spec.type == PageType.DEVELOPED
                val pageInfo = PdfDocument.PageInfo.Builder(
                     A4_PORTRAIT_WIDTH ,
                     A4_PORTRAIT_HEIGHT ,
                    index + 1
                ).create()
                val page = document.startPage(pageInfo)
                if (isDeveloped) {
                    DevelopedProfilePdfRenderer.draw(
                        page.canvas,
                        project,
                        spec.drawing,
                        index + 1,
                        totalPages
                    )
                } else {
                    page.canvas.save()
                    page.canvas.scale(
                        A4_PORTRAIT_WIDTH / VIRTUAL_PAGE_WIDTH,
                        A4_PORTRAIT_HEIGHT / VIRTUAL_PAGE_HEIGHT
                    )
                    drawMainPage(
                        page.canvas,
                        project,
                        spec.drawing,
                        cutPlan?.productCosts?.firstOrNull { it.drawingId == spec.drawing.id },
                        index + 1,
                        totalPages
                    )
                    page.canvas.restore()
                }
                document.finishPage(page)
            }

            if (cutPlan != null) {
                repeat(cutPlanPageCount) { planPageIndex ->
                    val globalPageNumber = pages.size + planPageIndex + 1
                    val pageInfo = PdfDocument.PageInfo.Builder(
                        A4_PORTRAIT_WIDTH,
                        A4_PORTRAIT_HEIGHT,
                        globalPageNumber
                    ).create()
                    val page = document.startPage(pageInfo)
                    CoilCutPlanPdfRenderer.drawPage(
                        canvas = page.canvas,
                        project = project,
                        plan = cutPlan,
                        planPageIndex = planPageIndex,
                        globalPageNumber = globalPageNumber,
                        totalPages = totalPages
                    )
                    document.finishPage(page)
                }
            }

            repeat(consumablesPageCount) { summaryPageIndex ->
                val globalPageNumber = pages.size + cutPlanPageCount + summaryPageIndex + 1
                val pageInfo = PdfDocument.PageInfo.Builder(
                    A4_PORTRAIT_WIDTH,
                    A4_PORTRAIT_HEIGHT,
                    globalPageNumber
                ).create()
                val page = document.startPage(pageInfo)
                ConsumablesPdfRenderer.drawPage(
                    canvas = page.canvas,
                    project = project,
                    drawings = drawings,
                    summaryPageIndex = summaryPageIndex,
                    globalPageNumber = globalPageNumber,
                    totalPages = totalPages
                )
                document.finishPage(page)
            }

            val date = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
            val suffix = if (cutPlan == null) "" else "-delenie-zvitku"
            val fileName = "KlampSketch-${safeFileName(project.name)}$suffix-$date.pdf"
            val shareDirectory = File(context.cacheDir, "share/pdfs").apply { mkdirs() }
            val shareFile = File(shareDirectory, fileName)
            FileOutputStream(shareFile).use { output -> document.writeTo(output) }
            shareFile.inputStream().use { input ->
                openOutput(context, fileName).use { output -> input.copyTo(output) }
            }
            return ExportedPdf(
                displayPath = "Downloads/KlampSketch/$fileName",
                shareUri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    shareFile
                )
            )
        } finally {
            document.close()
        }
    }

    private fun drawMainPage(
        canvas: Canvas,
        project: ProjectRecord,
        drawing: DrawingRecord,
        planCost: CoilProductCost?,
        pageNumber: Int,
        totalPages: Int
    ) {
        canvas.drawColor(Color.WHITE)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(35, 50, 62)
            style = Paint.Style.STROKE
            strokeWidth = 2.2f
        }
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            textSize = 30f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(79, 96, 108)
            textSize = 16f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val sectionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(8, 119, 201)
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val pageBorder = RectF(42f, 42f, VIRTUAL_PAGE_WIDTH - 42f, VIRTUAL_PAGE_HEIGHT - 42f)
        canvas.drawRect(pageBorder, borderPaint)
        canvas.drawText("KLAMPIARSKY VÝROBNÝ NÁKRES", 72f, 88f, headerPaint)
        canvas.drawText(drawing.identifier, 72f, 116f, smallPaint)
        canvas.drawText("LIST $pageNumber/$totalPages", 1050f, 88f, smallPaint)

        val technicalArea = RectF(65f, 135f, 820f, 1140f)
        val threeDArea = RectF(845f, 135f, 1175f, 470f)
        val photoArea = RectF(845f, 500f, 1175f, 835f)
        canvas.drawRect(technicalArea, borderPaint)
        canvas.drawRect(threeDArea, borderPaint)
        canvas.drawRect(photoArea, borderPaint)
        drawTechnicalProfiles(canvas, technicalArea, drawing, sectionPaint, borderPaint)
        drawDepth3D(canvas, drawing, threeDArea)
        drawPhoto(canvas, drawing.photoPath, photoArea, smallPaint)

        val metrics = calculateMetrics(drawing)
        val consumables = calculateConsumables(drawing, metrics)
        val widthValue = metrics.rearDevelopedWidthMm?.let {
            "P ${metrics.developedWidthMm} / Z $it mm"
        } ?: "${metrics.developedWidthMm} mm"
        val table = RectF(65f, 1190f, 1175f, 1685f)
        canvas.drawRect(table, borderPaint)
        val lengthTier = profileLengthTier(drawing.profileLengthM)
        val piecePriceValue = if (planCost != null) {
            "${formatDecimal(planCost.totalCostPerPieceEur)} € " +
                "(plech ${formatDecimal(planCost.materialCostPerPieceEur)} + " +
                "ohyb ${formatDecimal(planCost.bendingCostPerPieceEur)} + " +
                "rez ${formatDecimal(planCost.cuttingCostPerPieceEur)})"
        } else {
            "${formatDecimal(metrics.estimatedPricePerPieceEur)} € " +
                "(plech ${formatDecimal(metrics.materialPricePerPieceEur)} + " +
                "ohyb ${formatDecimal(metrics.bendingCostPerPieceEur)}; bez plánu rezania)"
        }
        val totalPriceValue = if (planCost != null) {
            "${formatDecimal(planCost.totalCostEur)} € " +
                "(plech ${formatDecimal(planCost.allocatedMaterialCostEur)} + " +
                "ohyb ${formatDecimal(planCost.bendingCostEur)} + " +
                "rez ${formatDecimal(planCost.cuttingCostEur)})"
        } else {
            "${formatDecimal(metrics.estimatedPriceTotalEur)} € " +
                "(plech ${formatDecimal(metrics.materialPriceTotalEur)} + " +
                "ohyb ${formatDecimal(metrics.bendingCostTotalEur)}; bez plánu rezania)"
        }
        val rows = listOf(
            "STAVBA" to project.name,
            "ZÁKAZNÍK" to project.customer,
            "ADRESA" to project.address,
            "NÁZOV VÝROBKU" to drawing.name,
            "IDENTIFIKAČNÉ ČÍSLO" to drawing.identifier,
            "ROZVINUTÁ ŠÍRKA" to widthValue,
            "POČET OHYBOV / mOHYB" to
                "${metrics.bends} × / ${formatDecimal(planCost?.bendingMeters ?: metrics.bendingMetersTotal)} m",
            "DĹŽKA / KATEGÓRIA / mPROF" to
                "${formatDecimal(drawing.profileLengthM, 2)} m / ${lengthTier.label} / " +
                "${formatDecimal(planCost?.profileMeters ?: drawing.profileLengthM * drawing.quantity)} m",
            "SPOTREBA PLECHU / KUS" to "${formatDecimal(metrics.sheetPerPieceM2)} m²",
            "POČET KUSOV / SKRUTKY á 300 mm" to
                "${drawing.quantity} ks / ${consumables.screwsPerPiece} ks/kus, " +
                "${consumables.screwsTotal} ks spolu",
            "PLECH CELKOM / KLAMPIARSKY TMEL" to
                "${formatDecimal(metrics.sheetTotalM2)} m² / " +
                "${formatDecimal(consumables.sealantPerPieceMl)} ml/kus, " +
                "${formatDecimal(consumables.sealantTotalMl)} ml spolu",
            "DRUH PLECHU" to "${drawing.material}, hr. ${formatDecimal(drawing.thicknessMm, 2)} mm",
            "FARBA / TMELENIE" to "${drawing.ral} / ${drawing.sealantMode.label}",
            "HMOTNOSŤ PROFILU" to "${formatDecimal(metrics.weightPerPieceKg)} kg",
            "HMOTNOSŤ CELKOM / NITY" to
                "${formatDecimal(metrics.weightTotalKg)} kg / " +
                "${consumables.rivetsPerPiece} ks/kus, ${consumables.rivetsTotal} ks spolu",
            "CENA / KUS BEZ DPH (PLECH + VÝROBA)" to piecePriceValue,
            "CENA CELKOM BEZ DPH" to totalPriceValue,
            "DÁTUM" to SimpleDateFormat("d. M. yyyy", Locale("sk", "SK")).format(Date())
        )
        val columnWidth = table.width() / 2f
        val rowHeight = table.height() / 9f
        rows.chunked(9).forEachIndexed { column, columnRows ->
            columnRows.forEachIndexed { row, value ->
                val cell = RectF(
                    table.left + column * columnWidth,
                    table.top + row * rowHeight,
                    table.left + (column + 1) * columnWidth,
                    table.top + (row + 1) * rowHeight
                )
                drawCell(canvas, cell, value.first, value.second, borderPaint)
            }
        }
    }

    private fun drawTechnicalProfiles(
        canvas: Canvas,
        area: RectF,
        drawing: DrawingRecord,
        sectionPaint: Paint,
        borderPaint: Paint
    ) {
        val back = drawing.validBackPoints()
        if (back == null) {
            canvas.drawText("TECHNICKÝ PROFIL", area.left + 17f, area.top + 30f, sectionPaint)
            val result = ProfileRenderer.renderTechnical(
                canvas,
                RectF(area.left + 12f, area.top + 38f, area.right - 12f, area.bottom - 82f),
                drawing.points,
                labelSize = 22f,
                showHandles = false,
                paintedTopSide = drawing.paintedTopSide
            )
            drawTechnicalScale(canvas, area, result)
            return
        }

        val dividerY = area.centerY()
        canvas.drawLine(area.left, dividerY, area.right, dividerY, borderPaint)
        canvas.drawText("PREDNÝ PROFIL", area.left + 17f, area.top + 30f, sectionPaint)
        val frontResult = ProfileRenderer.renderTechnical(
            canvas,
            RectF(area.left + 12f, area.top + 38f, area.right - 12f, dividerY - 72f),
            drawing.points,
            labelSize = 18f,
            showHandles = false,
            paintedTopSide = drawing.paintedTopSide
        )
        drawTechnicalScale(
            canvas,
            RectF(area.left, area.top, area.right, dividerY),
            frontResult
        )
        canvas.drawText("ZADNÝ PROFIL", area.left + 17f, dividerY + 30f, sectionPaint)
        val backResult = ProfileRenderer.renderTechnical(
            canvas,
            RectF(area.left + 12f, dividerY + 38f, area.right - 12f, area.bottom - 72f),
            back,
            labelSize = 18f,
            showHandles = false,
            paintedTopSide = drawing.paintedTopSide
        )
        drawTechnicalScale(
            canvas,
            RectF(area.left, dividerY, area.right, area.bottom),
            backResult
        )
    }

    private fun drawTechnicalScale(
        canvas: Canvas,
        area: RectF,
        result: ProfileRenderResult
    ) {
        if (result.modelToCanvasScale <= 0f) return
        val actualPointsPerModelMm = result.modelToCanvasScale * MAIN_PAGE_TO_PDF_SCALE
        val denominator = PDF_POINTS_PER_MM / actualPointsPerModelMm
        val scaleText = if (denominator >= 1f) {
            "MIERKA 1:${formatScaleRatio(denominator)}"
        } else {
            "MIERKA ${formatScaleRatio(1f / denominator)}:1"
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(49, 70, 84)
            textSize = 15f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            strokeWidth = 2f
        }
        val startX = area.left + 22f
        val endX = startX + 100f * result.modelToCanvasScale
        val y = area.bottom - 24f
        canvas.drawText(scaleText, startX, area.bottom - 50f, textPaint)
        canvas.drawLine(startX, y, endX, y, linePaint)
        canvas.drawLine(startX, y - 7f, startX, y + 7f, linePaint)
        canvas.drawLine(endX, y - 7f, endX, y + 7f, linePaint)
        canvas.drawText("10 cm (100 mm) v skutočnosti", startX, y - 9f, textPaint)
    }

    private fun formatScaleRatio(value: Float): String {
        val rounded = kotlin.math.round(value * 10f) / 10f
        return if (kotlin.math.abs(rounded - rounded.toInt()) < 0.01f) {
            rounded.toInt().toString()
        } else {
            formatDecimal(rounded.toDouble(), 1)
        }
    }

    private fun drawDepth3D(canvas: Canvas, drawing: DrawingRecord, area: RectF) {
        val bitmap = Profile3DBitmapRenderer.render(
            700,
            700,
            drawing.points,
            drawing.validBackPoints(),
            500f,
            drawing.ral,
            drawing.material,
            drawing.paintedTopSide
        )
        val target = RectF(area.left + 8f, area.top + 8f, area.right - 8f, area.bottom - 8f)
        canvas.drawBitmap(bitmap, null, target, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        bitmap.recycle()
    }

    private fun drawPhoto(
        canvas: Canvas,
        photoPath: String?,
        area: RectF,
        labelPaint: Paint
    ) {
        val bitmap = photoPath
            ?.takeIf { File(it).isFile }
            ?.let { BitmapFactory.decodeFile(it) }
        if (bitmap == null) {
            val centered = Paint(labelPaint).apply { textAlign = Paint.Align.CENTER }
            canvas.drawText("FOTOGRAFIA ZO STAVBY", area.centerX(), area.centerY(), centered)
            return
        }

        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        val targetRatio = area.width() / area.height()
        val source = if (sourceRatio > targetRatio) {
            val wantedWidth = (bitmap.height * targetRatio).toInt()
            val left = (bitmap.width - wantedWidth) / 2
            Rect(left, 0, left + wantedWidth, bitmap.height)
        } else {
            val wantedHeight = (bitmap.width / targetRatio).toInt()
            val top = (bitmap.height - wantedHeight) / 2
            Rect(0, top, bitmap.width, top + wantedHeight)
        }
        canvas.drawBitmap(bitmap, source, area, Paint(Paint.ANTI_ALIAS_FLAG))
        bitmap.recycle()
    }

    private fun drawCell(
        canvas: Canvas,
        cell: RectF,
        label: String,
        value: String,
        borderPaint: Paint
    ) {
        canvas.drawRect(cell, borderPaint)
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(91, 106, 118)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 44, 57)
            textSize = 18f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        canvas.drawText(label, cell.left + 12f, cell.top + 18f, labelPaint)
        canvas.drawText(value.ifBlank { "—" }.take(56), cell.left + 12f, cell.top + 43f, valuePaint)
    }

    private fun openOutput(context: Context, fileName: String): OutputStream {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
                put(
                    MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/KlampSketch"
                )
            }
            val uri = context.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                values
            ) ?: error("Súbor sa nepodarilo vytvoriť.")
            return context.contentResolver.openOutputStream(uri)
                ?: error("Súbor sa nepodarilo otvoriť.")
        }

        @Suppress("DEPRECATION")
        val directory = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "KlampSketch"
        )
        if (!directory.exists() && !directory.mkdirs()) {
            error("Priečinok Downloads/KlampSketch sa nepodarilo vytvoriť.")
        }
        return FileOutputStream(File(directory, fileName))
    }

    private fun safeFileName(value: String): String =
        value.replace(Regex("""[\\/:*?"<>|\r\n]"""), "_")
            .trim()
            .ifBlank { "Stavba" }

    private enum class PageType { MAIN, DEVELOPED }
    private data class PageSpec(val drawing: DrawingRecord, val type: PageType)
}
