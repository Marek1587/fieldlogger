package sk.klampsketch.app

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.InputType
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var database: AppDatabase
    private lateinit var currentProject: ProjectRecord
    private val selectedDrawingIds = linkedSetOf<Long>()
    private var currentDraft: DrawingRecord? = null
    private var drawingView: DrawingView? = null
    private var editorMetadata: TextView? = null
    private var editorPhoto: ImageView? = null
    private var inEditor = false
    private var photoOutputFile: File? = null
    private var pendingPdfDrawings: List<DrawingRecord>? = null
    private var pendingPdfAction: PdfAction = PdfAction.SAVE
    private var pendingCutPlan: CoilCutPlan? = null
    private var selectedCoilWidthMm = 1250
    private var includeCuttingSummary = true
    private var editingBackProfile = false
    private var frontProfileButton: Button? = null
    private var backProfileButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = AppDatabase(this)
        currentProject = database.ensureDefaultProject()
        getSharedPreferences("klampsketch-settings", MODE_PRIVATE).let { settings ->
            selectedCoilWidthMm = settings.getInt("coil-width-mm", 1250)
                .takeIf { it == 1000 || it == 1250 }
                ?: 1250
            includeCuttingSummary = settings.getBoolean("coil-summary", true)
        }
        showHome()
    }

    private fun showHome() {
        inEditor = false
        currentDraft = null
        drawingView = null
        editingBackProfile = false
        frontProfileButton = null
        backProfileButton = null
        val root = screenRoot()
        val drawings = database.listDrawings(currentProject.id)
        val stockSheets = database.listStockSheets(currentProject.id)

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(brandBlue)
        }
        toolbar.addView(
            TextView(this).apply {
                text = "KlampSketch Offline"
                setTextColor(Color.WHITE)
                textSize = 21f
                setTypeface(typeface, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        toolbar.addView(compactButton(currentProject.name) { showProjectPicker() })
        root.addView(toolbar)

        val projectInfo = TextView(this).apply {
            text = buildString {
                append("STAVBA: ${currentProject.name}")
                if (currentProject.customer.isNotBlank()) append("\nZákazník: ${currentProject.customer}")
                if (currentProject.address.isNotBlank()) append("\n${currentProject.address}")
            }
            textSize = 15f
            setTextColor(darkText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(14), dp(16), dp(8))
        }
        root.addView(projectInfo)

        val cuttingPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundedBackground(
                Color.WHITE,
                12f,
                strokeColor = Color.rgb(193, 207, 216)
            )
        }
        cuttingPanel.addView(
            TextView(this).apply {
                text = "DELENIE ZVITKU Z VYBRANÝCH VÝROBKOV"
                textSize = 12f
                setTextColor(brandBlueDark)
                setTypeface(typeface, Typeface.BOLD)
            }
        )
        val cuttingOptions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        cuttingOptions.addView(
            TextView(this).apply {
                text = "Šírka:"
                textSize = 13f
                setTextColor(darkText)
                setTypeface(typeface, Typeface.BOLD)
                setPadding(0, 0, dp(6), 0)
            }
        )
        val coilWidths = arrayOf("1000 mm", "1250 mm")
        cuttingOptions.addView(
            Spinner(this).apply {
                adapter = ArrayAdapter(
                    this@MainActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    coilWidths
                )
                setSelection(if (selectedCoilWidthMm == 1000) 0 else 1)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(
                        parent: AdapterView<*>?,
                        view: View?,
                        position: Int,
                        id: Long
                    ) {
                        selectedCoilWidthMm = if (position == 0) 1000 else 1250
                        getSharedPreferences("klampsketch-settings", MODE_PRIVATE)
                            .edit()
                            .putInt("coil-width-mm", selectedCoilWidthMm)
                            .apply()
                    }

                    override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                }
            },
            LinearLayout.LayoutParams(dp(115), ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        cuttingOptions.addView(
            CheckBox(this).apply {
                text = "Pripojiť cenový súhrn"
                textSize = 12f
                isChecked = includeCuttingSummary
                setTextColor(darkText)
                setOnCheckedChangeListener { _, checked ->
                    includeCuttingSummary = checked
                    getSharedPreferences("klampsketch-settings", MODE_PRIVATE)
                        .edit()
                        .putBoolean("coil-summary", checked)
                        .apply()
                }
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        cuttingPanel.addView(cuttingOptions)
        cuttingPanel.addView(
            TextView(this).apply {
                text = if (stockSheets.isEmpty()) {
                    "Skladový plech: zatiaľ nepridaný"
                } else {
                    "Skladový plech: " + stockSheets.joinToString("  •  ") {
                        "${it.quantity}× ${it.lengthMm} × ${it.widthMm} mm, ${it.ral}"
                    }
                }
                textSize = 12f
                setTextColor(mutedText)
                setPadding(0, dp(2), 0, 0)
            }
        )
        root.addView(
            cuttingPanel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(12), dp(2), dp(12), dp(4)) }
        )

        val actions = horizontalActions(
            "Nová stavba" to { showNewProjectDialog() },
            "Nový nákres" to { openEditor(null) },
            "Vybrať všetko" to {
                selectedDrawingIds.clear()
                selectedDrawingIds.addAll(drawings.map { it.id })
                showHome()
            },
            "Zrušiť výber" to {
                selectedDrawingIds.clear()
                showHome()
            },
            "Import JSON" to { openJsonImport() },
            "Plech zo skladu" to { showStockSheetManager() },
            "Uložiť PDF" to { generateSelectedPdf(PdfAction.SAVE) },
            "PDF WhatsApp" to { generateSelectedPdf(PdfAction.WHATSAPP) },
            "JPG WhatsApp" to { shareSelectedJpgViaWhatsApp() },
            "PDF e-mail" to { generateSelectedPdf(PdfAction.EMAIL) },
            "PDF + delenie" to { generateCuttingPdf() }
        )
        root.addView(actions)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        if (drawings.isEmpty()) {
            list.addView(
                TextView(this).apply {
                    text = "V tejto stavbe zatiaľ nie je žiadny nákres.\nZačnite tlačidlom „Nový nákres“."
                    gravity = Gravity.CENTER
                    textSize = 17f
                    setTextColor(mutedText)
                    setPadding(dp(20), dp(80), dp(20), dp(80))
                }
            )
        } else {
            drawings.forEach { drawing -> list.addView(drawingCard(drawing)) }
        }
        scroll.addView(list)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        setContentView(root)
    }

    private fun drawingCard(drawing: DrawingRecord): View {
        val metrics = calculateMetrics(drawing)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.WHITE, 16f, strokeColor = Color.rgb(211, 222, 230))
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 0, 0, dp(12))
        card.layoutParams = params

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val select = CheckBox(this).apply {
            isChecked = drawing.id in selectedDrawingIds
            contentDescription = "Vybrať ${drawing.name} do PDF"
            setOnCheckedChangeListener { _, checked ->
                if (checked) selectedDrawingIds += drawing.id else selectedDrawingIds -= drawing.id
            }
        }
        header.addView(select)
        header.addView(
            TextView(this).apply {
                text = drawing.name
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(darkText)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(
            TextView(this).apply {
                text = drawing.identifier
                textSize = 12f
                setTextColor(brandBlue)
                setTypeface(typeface, Typeface.BOLD)
            }
        )
        card.addView(header)

        val previewBitmap = Profile3DBitmapRenderer.render(
            width = 620,
            height = 260,
            frontPoints = drawing.points,
            backPoints = drawing.validBackPoints(),
            profileLengthMm = 500f,
            ral = drawing.ral,
            material = drawing.material,
            paintedTopSide = drawing.paintedTopSide
        )
        card.addView(
            ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                setImageBitmap(previewBitmap)
                contentDescription = "3D náhľad ${drawing.name}"
                background = roundedBackground(
                    Color.rgb(241, 246, 248),
                    10f,
                    strokeColor = Color.rgb(211, 222, 230)
                )
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(145)
            ).apply { setMargins(dp(4), dp(8), dp(4), dp(4)) }
        )

        card.addView(
            TextView(this).apply {
                val widthInfo = metrics.rearDevelopedWidthMm?.let {
                    "P ${metrics.developedWidthMm} / Z $it mm  •  skosený profil"
                } ?: "${metrics.developedWidthMm} mm"
                text = "$widthInfo  •  ${metrics.bends} ohybov  •  " +
                    "${drawing.quantity} ks  •  ${drawing.ral}\n" +
                    "${drawing.material}, ${formatDecimal(drawing.thicknessMm, 1)} mm  •  " +
                    "L ${formatDecimal(drawing.profileLengthM, 2)} m  •  lak: " +
                    (if (drawing.paintedTopSide) "vrchná strana" else "spodná strana") +
                    "\nTmelenie: ${drawing.sealantMode.label}"
                textSize = 14f
                setTextColor(mutedText)
                setPadding(dp(4), dp(6), dp(4), dp(8))
            }
        )

        val buttons = horizontalActions(
            "Upraviť" to { openEditor(drawing) },
            "Kopírovať" to { showCopyDialog(drawing) },
            "Odstrániť" to { confirmDelete(drawing) }
        )
        card.addView(buttons)
        return card
    }

    private fun openEditor(existing: DrawingRecord?) {
        inEditor = true
        val draft = existing?.copy(
            points = existing.points.map { it.copy() }.toMutableList(),
            backPoints = existing.backPoints?.map { it.copy() }?.toMutableList()
        ) ?: DrawingRecord(
            projectId = currentProject.id,
            name = "Nový klampiarsky prvok",
            identifier = database.nextIdentifier(),
            points = mutableListOf()
        )
        draft.backPoints = draft.validBackPoints()?.let {
            ProfileGeometry.alignDirections(draft.points, it)
        }
        currentDraft = draft
        editingBackProfile = false

        val root = screenRoot()
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(brandBlue)
        }
        toolbar.addView(compactButton("Späť") { confirmLeaveEditor() })
        toolbar.addView(
            TextView(this).apply {
                text = draft.name
                setTextColor(Color.WHITE)
                textSize = 18f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        toolbar.addView(compactButton("Uložiť") { saveCurrentDrawing() })
        root.addView(toolbar)

        val quickTools = horizontalActions(
            "Údaje" to { showMetadataDialog() },
            "Otočiť lak" to { togglePaintedSide() },
            "3D náhľad" to { show3DPreview() },
            "Fotoaparát" to { requestCamera() },
            "Galéria" to { openGallery() }
        )
        root.addView(quickTools)

        val profileSelector = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(2), dp(12), dp(4))
        }
        val frontButton = compactButton("Predný profil") { switchProfileSide(false) }
        val backButton = compactButton("＋ Zadný profil") { switchProfileSide(true) }
        frontProfileButton = frontButton
        backProfileButton = backButton
        profileSelector.addView(
            frontButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(0, 0, dp(4), 0)
            }
        )
        profileSelector.addView(
            backButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, 0, 0)
            }
        )
        root.addView(profileSelector)

        drawingView = DrawingView(this).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4))
            paintedTopSide = draft.paintedTopSide
            setProfile(draft.points)
            allowPointDrag = true
            allowAngleEditing = true
            onProfileChanged = { updated ->
                currentDraft?.let { current ->
                    if (editingBackProfile) {
                        current.backPoints = updated
                    } else {
                        val existingBack = current.validBackPoints()
                        current.points = updated
                        if (existingBack != null) {
                            current.backPoints = ProfileGeometry.alignDirections(updated, existingBack)
                        }
                    }
                }
                refreshEditorSummary()
            }
            onSegmentSelected = { index, current ->
                showLengthWheel(index, current)
            }
            onAngleSelected = { index, current ->
                showAngleWheel(index, current)
            }
            onPointSelectionChanged = {
                refreshEditorSummary()
            }
        }
        root.addView(
            drawingView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply {
                setMargins(dp(8), dp(2), dp(8), dp(6))
            }
        )

        val tools = horizontalActions(
            "Nový tvar" to { resetActiveProfile() },
            "Pridať bod" to { addPointToProfile() },
            "Vymazať bod" to { deleteSelectedPoint() },
            "Priblížiť" to { drawingView?.zoomIn() },
            "Oddialiť" to { drawingView?.zoomOut() },
            "Zrušiť zadný" to { removeBackProfile() }
        )
        root.addView(tools)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        editorPhoto = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundedBackground(Color.rgb(231, 237, 241), 10f)
        }
        bottom.addView(editorPhoto, LinearLayout.LayoutParams(dp(72), dp(60)))
        editorMetadata = TextView(this).apply {
            textSize = 13f
            setTextColor(mutedText)
            setPadding(dp(12), 0, 0, 0)
        }
        bottom.addView(
            editorMetadata,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        root.addView(bottom)
        setContentView(root)
        refreshEditorSummary()
    }

    private fun refreshEditorSummary() {
        val draft = currentDraft ?: return
        editorMetadata?.text =
            "${draft.identifier}\n${draft.material}, ${formatDecimal(draft.thicknessMm, 1)} mm\n" +
                "${draft.ral}  •  L ${formatDecimal(draft.profileLengthM, 2)} m  •  " +
                "${draft.quantity} ks" +
                (if (draft.validBackPoints() != null) "  •  skosený profil" else "") +
                "\nTmelenie: ${draft.sealantMode.label}" +
                "\nLakovaná pohľadová strana: " +
                if (draft.paintedTopSide) {
                    "vrchná (červená čiara hore)"
                } else {
                    "spodná (červená čiara dole)"
                }
        val path = draft.photoPath
        if (path != null && File(path).isFile) {
            editorPhoto?.setImageURI(Uri.fromFile(File(path)))
        } else {
            editorPhoto?.setImageDrawable(null)
        }
        refreshProfileButtons()
    }

    private fun switchProfileSide(back: Boolean) {
        val draft = currentDraft ?: return
        if (back && draft.points.size < 2) {
            Toast.makeText(this, "Najprv vytvorte predný profil.", Toast.LENGTH_SHORT).show()
            return
        }
        if (back && draft.validBackPoints() == null) {
            draft.backPoints = draft.points.map { it.copy() }.toMutableList()
        }
        editingBackProfile = back
        drawingView?.apply {
            allowPointDrag = !back
            allowAngleEditing = !back
            setProfile(if (back) draft.validBackPoints() ?: draft.points else draft.points)
        }
        refreshEditorSummary()
    }

    private fun refreshProfileButtons() {
        val draft = currentDraft ?: return
        frontProfileButton?.apply {
            applyPastelButtonStyle(this, "Predný profil", selected = !editingBackProfile)
        }
        backProfileButton?.apply {
            val label = if (draft.validBackPoints() == null) "Pridať zadný profil" else "Zadný profil"
            applyPastelButtonStyle(this, label, selected = editingBackProfile)
        }
    }

    private fun togglePaintedSide() {
        val draft = currentDraft ?: return
        draft.paintedTopSide = !draft.paintedTopSide
        drawingView?.paintedTopSide = draft.paintedTopSide
        refreshEditorSummary()
        Toast.makeText(
            this,
            if (draft.paintedTopSide) {
                "Lakovaná strana je teraz na vrchnej strane profilu."
            } else {
                "Lakovaná strana je teraz na spodnej strane profilu."
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun resetActiveProfile() {
        val draft = currentDraft ?: return
        if (editingBackProfile) {
            AlertDialog.Builder(this)
                .setTitle("Obnoviť zadný profil?")
                .setMessage("Zadný profil sa znova vytvorí ako kópia predného profilu.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Obnoviť") { _, _ ->
                    draft.backPoints = draft.points.map { it.copy() }.toMutableList()
                    drawingView?.apply {
                        allowPointDrag = false
                        allowAngleEditing = false
                        setProfile(draft.backPoints ?: draft.points)
                    }
                    refreshEditorSummary()
                }
                .show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Nakresliť nový tvar?")
                .setMessage("Predný aj zadný profil sa vymažú.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Áno") { _, _ ->
                    drawingView?.startNewSketch()
                    draft.points = mutableListOf()
                    draft.backPoints = null
                    refreshEditorSummary()
                }
                .show()
        }
    }

    private fun removeBackProfile() {
        val draft = currentDraft ?: return
        if (draft.validBackPoints() == null) {
            Toast.makeText(this, "Zadný profil ešte nie je vytvorený.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Zrušiť zadný profil?")
            .setMessage("Profil sa zmení späť na hranol s rovnakým predným a zadným čelom.")
            .setNegativeButton("Nie", null)
            .setPositiveButton("Zrušiť zadný profil") { _, _ ->
                draft.backPoints = null
                editingBackProfile = false
                drawingView?.apply {
                    allowPointDrag = true
                    allowAngleEditing = true
                    setProfile(draft.points)
                }
                refreshEditorSummary()
            }
            .show()
    }

    private fun deleteSelectedPoint() {
        val draft = currentDraft ?: return
        val result = drawingView?.removeSelectedPoint()
        if (result == null) {
            Toast.makeText(this, "Najprv ťuknite na bod, ktorý chcete vymazať.", Toast.LENGTH_LONG).show()
            return
        }

        if (editingBackProfile) {
            val front = draft.points.map { it.copy() }.toMutableList()
            if (result.deletedIndex in front.indices && front.size > 2) {
                front.removeAt(result.deletedIndex)
            }
            draft.points = ProfileGeometry.snapProfile(front)
            draft.backPoints = ProfileGeometry.alignDirections(draft.points, result.updatedPoints)
            drawingView?.apply {
                allowPointDrag = false
                allowAngleEditing = false
                setProfile(draft.backPoints ?: draft.points)
            }
        } else {
            draft.points = result.updatedPoints
            draft.backPoints = draft.backPoints?.let { back ->
                val updatedBack = back.map { it.copy() }.toMutableList()
                if (result.deletedIndex in updatedBack.indices && updatedBack.size > 2) {
                    updatedBack.removeAt(result.deletedIndex)
                }
                ProfileGeometry.alignDirections(draft.points, updatedBack)
            }
            drawingView?.apply {
                allowPointDrag = true
                allowAngleEditing = true
                setProfile(draft.points)
            }
        }

        refreshEditorSummary()
        Toast.makeText(this, "Bod bol odstránený.", Toast.LENGTH_SHORT).show()
    }

    private fun addPointToProfile() {
        val draft = currentDraft ?: return
        val frontBefore = draft.points.map { it.copy() }.toMutableList()
        val backBefore = draft.validBackPoints()?.map { it.copy() }?.toMutableList()
        val result = drawingView?.addPoint()
        if (result == null) {
            Toast.makeText(
                this,
                "Najprv nakreslite profil. Strana na rozdelenie musí mať aspoň 10 mm.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        if (editingBackProfile) {
            val updatedFront = insertMidpoint(frontBefore, result.segmentIndex)
            draft.points = ProfileGeometry.snapProfile(updatedFront)
            draft.backPoints = ProfileGeometry.alignDirections(draft.points, result.updatedPoints)
        } else {
            draft.points = result.updatedPoints
            draft.backPoints = backBefore?.let { back ->
                val updatedBack = insertMidpoint(back, result.segmentIndex)
                ProfileGeometry.alignDirections(draft.points, updatedBack)
            }
        }
        refreshEditorSummary()
        Toast.makeText(this, "Bod ${result.insertedIndex + 1} bol pridaný.", Toast.LENGTH_SHORT).show()
    }

    private fun insertMidpoint(
        points: MutableList<ProfilePoint>,
        segmentIndex: Int
    ): MutableList<ProfilePoint> {
        if (segmentIndex !in 0 until points.lastIndex) return points
        val start = points[segmentIndex]
        val end = points[segmentIndex + 1]
        val originalLength = ProfileGeometry.segmentLength(points, segmentIndex)
        if (originalLength < 10) return points
        val firstLength = (originalLength / 10 * 5).coerceIn(5, originalLength - 5)
        val angle = atan2(
            (end.y - start.y).toDouble(),
            (end.x - start.x).toDouble()
        )
        points.add(
            segmentIndex + 1,
            ProfilePoint(
                start.x + (cos(angle) * firstLength).toFloat(),
                start.y + (sin(angle) * firstLength).toFloat()
            )
        )
        return points
    }

    private fun showLengthWheel(segmentIndex: Int, currentLength: Int) {
        val upper = max(5000, currentLength + 500)
        val values = (5..upper step 5).map(Int::toString).toTypedArray()
        val picker = NumberPicker(this).apply {
            minValue = 0
            maxValue = values.lastIndex
            displayedValues = values
            value = ((currentLength.coerceAtLeast(5) - 5) / 5).coerceIn(0, values.lastIndex)
            wrapSelectorWheel = false
        }
        AlertDialog.Builder(this)
            .setTitle("Dĺžka strany v mm")
            .setMessage("Krok kolieska je 5 mm.")
            .setView(picker)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Nastaviť") { _, _ ->
                drawingView?.updateSegmentLength(segmentIndex, values[picker.value].toInt())
            }
            .show()
    }

    private fun showAngleWheel(vertexIndex: Int, currentAngle: Int) {
        val picker = NumberPicker(this).apply {
            minValue = 1
            maxValue = 179
            value = currentAngle.coerceIn(1, 179)
            wrapSelectorWheel = false
        }
        AlertDialog.Builder(this)
            .setTitle("Uhol v stupňoch")
            .setMessage("Krok kolieska je 1°.")
            .setView(picker)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Nastaviť") { _, _ ->
                drawingView?.updateAngle(vertexIndex, picker.value)
            }
            .show()
    }

    private fun showMetadataDialog() {
        val draft = currentDraft ?: return
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val name = field(content, "Názov výrobku", draft.name)
        val ral = field(content, "RAL / farba", draft.ral)
        val materials = arrayOf(
            "Farebný pozink",
            "Pozinkovaná oceľ",
            "Lakovaná oceľ",
            "Hliník",
            "Meď",
            "Titánzinok"
        )
        content.addView(fieldLabel("Druh plechu"))
        val material = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                materials
            )
            setSelection(materials.indexOf(draft.material).takeIf { it >= 0 } ?: 0)
        }
        content.addView(material)
        val thickness = field(
            content,
            "Hrúbka plechu (mm)",
            formatDecimal(draft.thicknessMm, 1),
            decimal = true
        )
        val length = field(
            content,
            "Dĺžka profilu (m)",
            formatDecimal(draft.profileLengthM, 2),
            decimal = true
        )
        val quantity = field(
            content,
            "Počet kusov",
            draft.quantity.toString(),
            number = true
        )
        val sealantModes = SealantMode.entries
        content.addView(fieldLabel("Tmelenie profilu"))
        val sealantMode = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                sealantModes.map { it.label }
            )
            setSelection(sealantModes.indexOf(draft.sealantMode).coerceAtLeast(0))
        }
        content.addView(sealantMode)
        content.addView(
            TextView(this).apply {
                text = "Konce: predná + zadná rozvinutá šírka × 50 ml/m. " +
                    "Horná hrana: dĺžka profilu × 30 ml/m."
                textSize = 12f
                setTextColor(mutedText)
                setPadding(0, dp(4), 0, dp(8))
            }
        )
        val scroll = ScrollView(this).apply { addView(content) }

        AlertDialog.Builder(this)
            .setTitle("Údaje klampiarskeho prvku")
            .setView(scroll)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Uložiť") { _, _ ->
                draft.name = name.text.toString().trim().ifBlank { "Klampiarsky prvok" }
                draft.ral = ral.text.toString().trim().ifBlank { "RAL 8028" }
                draft.material = material.selectedItem.toString()
                draft.thicknessMm = parseDecimal(thickness.text.toString(), 0.5)
                    .coerceAtLeast(0.1)
                draft.profileLengthM = parseDecimal(length.text.toString(), 2.0)
                    .coerceAtLeast(0.01)
                draft.quantity = quantity.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                draft.sealantMode = sealantModes[sealantMode.selectedItemPosition]
                refreshEditorSummary()
            }
            .show()
    }

    private fun saveCurrentDrawing() {
        val draft = currentDraft ?: return
        val active = drawingView?.getProfile()
        if (editingBackProfile && active != null) draft.backPoints = active
        if (!editingBackProfile && active != null) draft.points = active
        if (draft.points.size < 2) {
            Toast.makeText(this, "Najprv nakreslite predný profil.", Toast.LENGTH_LONG).show()
            return
        }
        draft.backPoints = draft.backPoints
            ?.takeIf { it.size == draft.points.size && it.size >= 2 }
            ?.let { ProfileGeometry.alignDirections(draft.points, it) }
        draft.updatedAt = System.currentTimeMillis()
        database.saveDrawing(draft)
        Toast.makeText(this, "Nákres bol uložený iba v telefóne.", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun showProjectPicker() {
        val projects = database.listProjects()
        AlertDialog.Builder(this)
            .setTitle("Vyberte stavbu")
            .setItems(projects.map { it.name }.toTypedArray()) { _, index ->
                currentProject = projects[index]
                selectedDrawingIds.clear()
                showHome()
            }
            .setNeutralButton("Nová stavba") { _, _ -> showNewProjectDialog() }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showNewProjectDialog() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val name = field(content, "Názov stavby", "")
        val customer = field(content, "Zákazník", "")
        val address = field(content, "Adresa", "")
        AlertDialog.Builder(this)
            .setTitle("Nová stavba")
            .setView(content)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Vytvoriť") { _, _ ->
                val project = ProjectRecord(
                    name = name.text.toString().trim().ifBlank { "Nová stavba" },
                    customer = customer.text.toString().trim(),
                    address = address.text.toString().trim()
                )
                val id = database.insertProject(project)
                currentProject = project.copy(id = id)
                selectedDrawingIds.clear()
                showHome()
            }
            .show()
    }

    private fun showStockSheetManager() {
        val stockSheets = database.listStockSheets(currentProject.id)
        val labels = stockSheets.map { stock ->
            "${stock.quantity}×  ${stock.lengthMm} × ${stock.widthMm} mm\n" +
                "${stock.material}, ${stock.ral}, hr. ${formatDecimal(stock.thicknessMm, 2)} mm"
        }.toTypedArray()
        val builder = AlertDialog.Builder(this)
            .setTitle("Plech zo skladu - ${currentProject.name}")
            .setMessage(if (stockSheets.isEmpty()) "V tejto stavbe zatiaľ nie je zadaný skladový plech." else null)
            .setPositiveButton("Pridať plech") { _, _ -> showAddStockSheetDialog() }
            .setNegativeButton("Zavrieť", null)
        if (labels.isNotEmpty()) {
            builder.setItems(labels) { _, index -> confirmDeleteStockSheet(stockSheets[index]) }
        }
        builder.show()
    }

    private fun showAddStockSheetDialog() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val length = field(content, "Dĺžka tabule v mm", "3250", number = true)
        val width = field(content, "Šírka tabule v mm", "500", number = true)
        val quantity = field(content, "Počet tabúľ", "1", number = true)
        val material = field(content, "Druh plechu", "Farebný pozink")
        val ral = field(content, "Farba", "RAL 8028")
        val thickness = field(content, "Hrúbka v mm", "0,50", decimal = true)
        val scroll = ScrollView(this).apply { addView(content) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Pridať plech zo skladu")
            .setView(scroll)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Pridať", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val lengthMm = length.text.toString().toIntOrNull() ?: 0
                val widthMm = width.text.toString().toIntOrNull() ?: 0
                val count = quantity.text.toString().toIntOrNull() ?: 0
                val thicknessMm = parseDecimal(thickness.text.toString(), 0.0)
                if (lengthMm !in 50..20_000 || widthMm !in 50..2_500 || count !in 1..1_000 || thicknessMm !in 0.1..5.0) {
                    Toast.makeText(
                        this,
                        "Skontrolujte rozmery, počet tabúľ a hrúbku plechu.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnClickListener
                }
                database.insertStockSheet(
                    StockSheetRecord(
                        projectId = currentProject.id,
                        lengthMm = lengthMm,
                        widthMm = widthMm,
                        quantity = count,
                        material = material.text.toString().trim().ifBlank { "Farebný pozink" },
                        ral = ral.text.toString().trim().ifBlank { "RAL 8028" },
                        thicknessMm = thicknessMm
                    )
                )
                dialog.dismiss()
                Toast.makeText(this, "Skladový plech bol pridaný do stavby.", Toast.LENGTH_SHORT).show()
                showHome()
            }
        }
        dialog.show()
    }

    private fun confirmDeleteStockSheet(stockSheet: StockSheetRecord) {
        AlertDialog.Builder(this)
            .setTitle("Odstrániť skladový plech?")
            .setMessage(
                "${stockSheet.quantity}× ${stockSheet.lengthMm} × ${stockSheet.widthMm} mm, " +
                    "${stockSheet.ral}"
            )
            .setNegativeButton("Ponechať", null)
            .setPositiveButton("Odstrániť") { _, _ ->
                database.deleteStockSheet(stockSheet.id)
                showHome()
            }
            .show()
    }

    private fun openJsonImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("application/json", "text/json", "text/plain")
            )
        }
        startActivityForResult(intent, REQUEST_JSON_IMPORT)
    }

    private fun importDrawingsFromJson(uri: Uri) {
        try {
            val json = contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "JSON súbor sa nedá otvoriť." }
                input.bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
            val firstAutoIdentifier = database.nextIdentifier()
            val firstNumber = firstAutoIdentifier.substringAfterLast('-').toIntOrNull() ?: 1
            val result = DrawingJsonImporter.parse(
                json = json,
                projectId = currentProject.id,
                autoIdentifier = { index -> "KL-${(firstNumber + index).toString().padStart(5, '0')}" }
            )
            val preview = result.drawings.take(8).joinToString("\n") {
                "• ${it.identifier} - ${it.name} (${it.quantity} ks)"
            }
            val more = if (result.drawings.size > 8) {
                "\n… a ďalších ${result.drawings.size - 8} výrobkov"
            } else {
                ""
            }
            val warnings = if (result.warnings.isEmpty()) "" else {
                "\n\nUpozornenia:\n${result.warnings.joinToString("\n")}"
            }
            AlertDialog.Builder(this)
                .setTitle("Importovať ${result.drawings.size} výrobkov?")
                .setMessage("Stavba: ${currentProject.name}\n\n$preview$more$warnings")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Importovať") { _, _ ->
                    database.importDrawings(result.drawings)
                    selectedDrawingIds.clear()
                    Toast.makeText(
                        this,
                        "Importovaných výrobkov: ${result.drawings.size}",
                        Toast.LENGTH_LONG
                    ).show()
                    showHome()
                }
                .show()
        } catch (error: Exception) {
            Toast.makeText(
                this,
                "JSON sa nepodarilo importovať: ${error.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun showCopyDialog(drawing: DrawingRecord) {
        val projects = database.listProjects()
        AlertDialog.Builder(this)
            .setTitle("Skopírovať do stavby")
            .setItems(projects.map { it.name }.toTypedArray()) { _, index ->
                database.copyDrawing(drawing, projects[index].id)
                Toast.makeText(
                    this,
                    "Pôvodný nákres zostal zachovaný a kópia bola vytvorená.",
                    Toast.LENGTH_LONG
                ).show()
                showHome()
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun confirmDelete(drawing: DrawingRecord) {
        AlertDialog.Builder(this)
            .setTitle("Odstrániť nákres?")
            .setMessage(drawing.name)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Odstrániť") { _, _ ->
                database.deleteDrawing(drawing.id)
                selectedDrawingIds -= drawing.id
                showHome()
            }
            .show()
    }

    private fun generateSelectedPdf(action: PdfAction) {
        val drawings = selectedDrawingIds.mapNotNull(database::getDrawing)
        if (drawings.isEmpty()) {
            Toast.makeText(
                this,
                "Zaškrtnite aspoň jeden nákres.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        requestOrExportPdf(drawings, action, cutPlan = null)
    }

    private fun generateCuttingPdf() {
        val drawings = selectedDrawingIds.mapNotNull(database::getDrawing)
        if (drawings.isEmpty()) {
            Toast.makeText(
                this,
                "Zaškrtnite aspoň jeden výrobok pre delenie zvitku.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val plan = try {
            CoilCutPlanner.createPlan(
                drawings = drawings,
                coilWidthMm = selectedCoilWidthMm,
                includeSummary = includeCuttingSummary,
                stockSheets = database.listStockSheets(currentProject.id)
            )
        } catch (error: IllegalArgumentException) {
            Toast.makeText(this, error.message, Toast.LENGTH_LONG).show()
            return
        }
        requestOrExportPdf(drawings, PdfAction.SAVE, plan)
    }

    private fun requestOrExportPdf(
        drawings: List<DrawingRecord>,
        action: PdfAction,
        cutPlan: CoilCutPlan?
    ) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingPdfDrawings = drawings
            pendingPdfAction = action
            pendingCutPlan = cutPlan
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_STORAGE_PERMISSION
            )
            return
        }
        exportPdf(drawings, action, cutPlan)
    }

    private fun exportPdf(
        drawings: List<DrawingRecord>,
        action: PdfAction,
        cutPlan: CoilCutPlan? = null
    ) {
        Toast.makeText(
            this,
            if (cutPlan == null) "Vytváram PDF…" else "Optimalizujem a vytváram PDF s delením…",
            Toast.LENGTH_SHORT
        ).show()
        Thread {
            try {
                val exported = PdfExporter.export(this, currentProject, drawings, cutPlan)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "PDF je uložené v ${exported.displayPath}",
                        Toast.LENGTH_LONG
                    ).show()
                    when (action) {
                        PdfAction.SAVE -> Unit
                        PdfAction.WHATSAPP -> sharePdfViaWhatsApp(exported)
                        PdfAction.EMAIL -> sharePdfViaEmail(exported)
                    }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "PDF sa nepodarilo vytvoriť: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun shareSelectedJpgViaWhatsApp() {
        val drawings = selectedDrawingIds.mapNotNull(database::getDrawing)
        if (drawings.isEmpty()) {
            Toast.makeText(this, "Zaškrtnite aspoň jeden nákres.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Vytváram JPG náhľady…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val uris = ProfileShareImageExporter.export(this, currentProject, drawings)
                runOnUiThread {
                    shareWithWhatsApp(
                        mimeType = "image/jpeg",
                        uris = uris,
                        subject = "Klampiarske profily - ${currentProject.name}"
                    )
                }
            } catch (error: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "JPG náhľady sa nepodarilo vytvoriť: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun sharePdfViaWhatsApp(exported: ExportedPdf) {
        shareWithWhatsApp(
            mimeType = "application/pdf",
            uris = arrayListOf(exported.shareUri),
            subject = "Klampiarsky PDF report - ${currentProject.name}"
        )
    }

    private fun sharePdfViaEmail(exported: ExportedPdf) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, exported.shareUri)
            putExtra(Intent.EXTRA_SUBJECT, "Klampiarsky PDF report - ${currentProject.name}")
            putExtra(
                Intent.EXTRA_TEXT,
                "V prílohe posielam klampiarsky výrobný report pre stavbu ${currentProject.name}."
            )
            clipData = ClipData.newRawUri("KlampSketch PDF", exported.shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching {
            startActivity(Intent.createChooser(intent, "Odoslať PDF e-mailom"))
        }.onFailure {
            Toast.makeText(this, "E-mailovú aplikáciu sa nepodarilo otvoriť.", Toast.LENGTH_LONG).show()
        }
    }

    private fun shareWithWhatsApp(
        mimeType: String,
        uris: ArrayList<Uri>,
        subject: String
    ) {
        if (uris.isEmpty()) return
        val whatsappPackage = listOf("com.whatsapp", "com.whatsapp.w4b")
            .firstOrNull { packageName ->
                runCatching { packageManager.getPackageInfo(packageName, 0) }.isSuccess
            }
        if (whatsappPackage == null) {
            Toast.makeText(
                this,
                "WhatsApp ani WhatsApp Business nie je v telefóne dostupný.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        val intent = Intent(
            if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE
        ).apply {
            type = mimeType
            setPackage(whatsappPackage)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            if (uris.size == 1) {
                putExtra(Intent.EXTRA_STREAM, uris.first())
            } else {
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
            clipData = ClipData.newRawUri("KlampSketch", uris.first()).apply {
                uris.drop(1).forEach { addItem(ClipData.Item(it)) }
            }
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { startActivity(intent) }.onFailure {
            Toast.makeText(this, "WhatsApp sa nepodarilo otvoriť.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val photos = File(filesDir, "photos")
        if (!photos.exists()) photos.mkdirs()
        val file = File(
            photos,
            "photo-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.jpg"
        )
        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.fileprovider",
            file
        )
        photoOutputFile = file
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            clipData = ClipData.newRawUri("KlampSketch photo", uri)
        }
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQUEST_CAMERA)
        } else {
            Toast.makeText(this, "Fotoaparát nie je dostupný.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_GALLERY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when {
            requestCode == REQUEST_CAMERA && resultCode == RESULT_OK -> {
                currentDraft?.photoPath = photoOutputFile?.absolutePath
                refreshEditorSummary()
            }
            requestCode == REQUEST_CAMERA -> {
                photoOutputFile?.takeIf { it.isFile }?.delete()
            }
            requestCode == REQUEST_GALLERY && resultCode == RESULT_OK -> {
                data?.data?.let(::copyGalleryPhoto)
            }
            requestCode == REQUEST_JSON_IMPORT && resultCode == RESULT_OK -> {
                data?.data?.let(::importDrawingsFromJson)
            }
        }
    }

    private fun copyGalleryPhoto(uri: Uri) {
        try {
            val photos = File(filesDir, "photos")
            if (!photos.exists()) photos.mkdirs()
            val mime = contentResolver.getType(uri).orEmpty()
            val extension = if (mime.contains("png")) "png" else "jpg"
            val target = File(
                photos,
                "gallery-${System.currentTimeMillis()}.$extension"
            )
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Fotografia sa nedá otvoriť." }
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            currentDraft?.photoPath = target.absolutePath
            refreshEditorSummary()
        } catch (error: Exception) {
            Toast.makeText(
                this,
                "Fotografiu sa nepodarilo uložiť: ${error.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else if (requestCode == REQUEST_STORAGE_PERMISSION &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            pendingPdfDrawings?.let { exportPdf(it, pendingPdfAction, pendingCutPlan) }
            pendingPdfDrawings = null
            pendingPdfAction = PdfAction.SAVE
            pendingCutPlan = null
        }
    }

    private fun show3DPreview() {
        val draft = currentDraft ?: return
        if (draft.points.size < 2) {
            Toast.makeText(this, "Najprv nakreslite profil.", Toast.LENGTH_SHORT).show()
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        content.addView(
            TextView(this).apply {
                text = "Potiahnutím model otáčate, dvoma prstami približujete. Dvojité ťuknutie obnoví pohľad."
                textSize = 13f
                setTextColor(mutedText)
                setPadding(dp(4), 0, dp(4), dp(8))
            }
        )

        val supportsOpenGl3 = (
            getSystemService(ACTIVITY_SERVICE) as ActivityManager
        ).deviceConfigurationInfo.reqGlEsVersion >= 0x30000

        val previewHeight = dp(470).coerceAtMost(
            (resources.displayMetrics.heightPixels * 0.62f).toInt()
        )
        var glView: Profile3DView? = null
        var fallbackBitmap: android.graphics.Bitmap? = null
        if (supportsOpenGl3) {
            glView = Profile3DView(this).apply {
                setProfile(
                    draft.points,
                    draft.validBackPoints(),
                    (draft.profileLengthM * 1000.0).toFloat(),
                    draft.ral,
                    draft.material,
                    draft.paintedTopSide
                )
            }
            content.addView(
                glView,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    previewHeight
                )
            )
        } else {
            fallbackBitmap = Profile3DBitmapRenderer.render(
                900,
                900,
                draft.points,
                draft.validBackPoints(),
                (draft.profileLengthM * 1000.0).toFloat(),
                draft.ral,
                draft.material,
                draft.paintedTopSide
            )
            content.addView(
                ImageView(this).apply {
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageBitmap(fallbackBitmap)
                    contentDescription = "Trojrozmerný náhľad klampiarskeho profilu"
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    previewHeight
                )
            )
        }

        val status = TextView(this).apply {
            text = if (supportsOpenGl3) {
                "OpenGL ES 3.0  •  Z-buffer  •  4× MSAA podľa podpory zariadenia"
            } else {
                "Softvérový Z-buffer – zariadenie nepodporuje OpenGL ES 3.0"
            }
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(brandBlueDark)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(8), dp(4), 0)
        }
        content.addView(status)

        val dialog = AlertDialog.Builder(this)
            .setTitle("3D náhľad – ${draft.identifier}")
            .setView(content)
            .setNeutralButton("Obnoviť pohľad", null)
            .setPositiveButton("Zavrieť", null)
            .create()
        dialog.setOnShowListener {
            glView?.onResume()
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                glView?.resetView()
            }
        }
        dialog.setOnDismissListener {
            glView?.onPause()
            fallbackBitmap?.recycle()
        }
        dialog.show()
    }

    private fun confirmLeaveEditor() {
        AlertDialog.Builder(this)
            .setTitle("Zavrieť bez uloženia?")
            .setMessage("Neuložené zmeny sa stratia.")
            .setNegativeButton("Pokračovať v úprave", null)
            .setPositiveButton("Zavrieť") { _, _ -> showHome() }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (inEditor) confirmLeaveEditor() else super.onBackPressed()
    }

    private fun screenRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.rgb(245, 248, 250))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        } else {
            fitsSystemWindows = true
        }
    }

    private fun horizontalActions(
        vararg actions: Pair<String, () -> Unit>
    ): HorizontalScrollView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        actions.forEach { (label, action) ->
            row.addView(
                compactButton(label, action),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(4), 0, dp(4), 0) }
            )
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun compactButton(label: String, action: () -> Unit) = Button(this).apply {
        isAllCaps = false
        applyPastelButtonStyle(this, label)
        setOnClickListener { action() }
    }

    private fun applyPastelButtonStyle(
        button: Button,
        rawLabel: String,
        selected: Boolean = false
    ) {
        val title = rawLabel
            .replace("＋", "")
            .replace("‹", "")
            .replace("✎", "")
            .trim()
        val icon = buttonIcon(title)
        val styledText = SpannableString("$icon\n$title").apply {
            setSpan(
                RelativeSizeSpan(1.35f),
                0,
                icon.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                icon.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        val accents = intArrayOf(
            Color.rgb(221, 237, 255),
            Color.rgb(220, 245, 232),
            Color.rgb(255, 230, 213),
            Color.rgb(240, 230, 255),
            Color.rgb(255, 243, 196),
            Color.rgb(252, 224, 228),
            Color.rgb(218, 241, 242)
        )
        val accent = accents[(title.hashCode() and Int.MAX_VALUE) % accents.size]
        button.apply {
            text = styledText
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(darkText)
            setPadding(dp(12), dp(7), dp(10), dp(7))
            minHeight = dp(76)
            minWidth = dp(88)
            maxWidth = dp(116)
            minimumWidth = dp(88)
            setLineSpacing(0f, 0.94f)
            contentDescription = title
            background = PastelEdgeButtonDrawable(
                fillColor = Color.WHITE,
                borderColor = if (selected) brandBlueDark else Color.rgb(54, 64, 70),
                accentColor = accent,
                radius = dp(12).toFloat(),
                stripeWidth = dp(5).toFloat(),
                strokeWidth = dp(if (selected) 2 else 1).toFloat()
            )
        }
    }

    private fun buttonIcon(title: String): String {
        val key = title.lowercase(Locale("sk", "SK"))
        return when {
            "späť" in key -> "<"
            "uložiť" in key -> "✓"
            "pridať bod" in key || "nová stavba" in key -> "+"
            "pridať zadný" in key -> "+"
            "priblížiť" in key -> "+"
            "oddialiť" in key -> "−"
            "vybrať všetko" in key -> "✓"
            "zrušiť výber" in key -> "○"
            "vymazať" in key || "odstrániť" in key || "zrušiť" in key -> "×"
            "whatsapp" in key && "jpg" in key -> "JPG"
            "whatsapp" in key -> "WA"
            "e-mail" in key -> "@"
            "otočiť lak" in key -> "↕"
            "delenie" in key -> "✂"
            "import" in key -> "{}"
            "skladu" in key -> "▣"
            "pdf" in key -> "PDF"
            "3d" in key -> "3D"
            "foto" in key || "galéria" in key -> "▣"
            "kopírovať" in key -> "□"
            "údaje" in key -> "i"
            "profil" in key && "zadný" in key -> "Z"
            "profil" in key && "predný" in key -> "P"
            "nákres" in key || "tvar" in key || "upraviť" in key -> "✎"
            else -> "•"
        }
    }

    private fun field(
        parent: LinearLayout,
        label: String,
        value: String,
        decimal: Boolean = false,
        number: Boolean = false
    ): EditText {
        parent.addView(fieldLabel(label))
        val input = EditText(this).apply {
            setText(value)
            setSelectAllOnFocus(true)
            inputType = when {
                decimal -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                number -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundedBackground(
                Color.WHITE,
                9f,
                strokeColor = Color.rgb(193, 207, 216)
            )
        }
        parent.addView(
            input,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(10)) }
        )
        return input
    }

    private fun fieldLabel(label: String) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(mutedText)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(4), dp(2), dp(3))
    }

    private fun roundedBackground(
        color: Int,
        radiusDp: Float,
        strokeColor: Int? = null
    ) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        strokeColor?.let { setStroke(dp(1), it) }
    }

    private fun parseDecimal(value: String, fallback: Double): Double =
        value.trim().replace(',', '.').toDoubleOrNull() ?: fallback

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val brandBlue get() = Color.rgb(8, 119, 201)
    private val brandBlueDark get() = Color.rgb(6, 83, 139)
    private val darkText get() = Color.rgb(24, 44, 59)
    private val mutedText get() = Color.rgb(88, 105, 118)

    private enum class PdfAction {
        SAVE,
        WHATSAPP,
        EMAIL
    }

    companion object {
        private const val REQUEST_CAMERA = 801
        private const val REQUEST_GALLERY = 802
        private const val REQUEST_CAMERA_PERMISSION = 803
        private const val REQUEST_STORAGE_PERMISSION = 804
        private const val REQUEST_JSON_IMPORT = 805
    }
}

private class PastelEdgeButtonDrawable(
    fillColor: Int,
    borderColor: Int,
    accentColor: Int,
    private val radius: Float,
    private val stripeWidth: Float,
    private val strokeWidth: Float
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = fillColor
        style = Paint.Style.FILL
    }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = borderColor
        style = Paint.Style.STROKE
        this.strokeWidth = this@PastelEdgeButtonDrawable.strokeWidth
    }

    override fun draw(canvas: Canvas) {
        val box = RectF(bounds)
        val clip = Path().apply {
            addRoundRect(box, radius, radius, Path.Direction.CW)
        }
        val save = canvas.save()
        canvas.clipPath(clip)
        canvas.drawRoundRect(box, radius, radius, fillPaint)
        canvas.drawRect(box.left, box.top, box.left + stripeWidth, box.bottom, accentPaint)
        canvas.restoreToCount(save)

        val halfStroke = strokeWidth / 2f
        val borderBox = RectF(
            box.left + halfStroke,
            box.top + halfStroke,
            box.right - halfStroke,
            box.bottom - halfStroke
        )
        canvas.drawRoundRect(borderBox, radius, radius, borderPaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        accentPaint.alpha = alpha
        borderPaint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        accentPaint.colorFilter = colorFilter
        borderPaint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
