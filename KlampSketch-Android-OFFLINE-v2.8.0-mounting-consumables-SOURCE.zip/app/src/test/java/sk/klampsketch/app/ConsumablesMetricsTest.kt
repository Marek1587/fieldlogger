package sk.klampsketch.app

import org.junit.Assert.assertEquals
import org.junit.Test

class ConsumablesMetricsTest {
    @Test
    fun `screws rivets and both sealant paths use exact production formulas`() {
        val drawing = DrawingRecord(
            id = 1,
            projectId = 1,
            name = "Skosený profil",
            identifier = "KL-TMEL",
            points = mutableListOf(
                ProfilePoint(0f, 0f),
                ProfilePoint(100f, 0f),
                ProfilePoint(100f, 200f)
            ),
            backPoints = mutableListOf(
                ProfilePoint(0f, 0f),
                ProfilePoint(150f, 0f),
                ProfilePoint(150f, 250f)
            ),
            profileLengthM = 2.0,
            quantity = 4,
            sealantMode = SealantMode.BOTH
        )

        val result = calculateConsumables(drawing)

        assertEquals(7, result.screwsPerPiece)
        assertEquals(28, result.screwsTotal)
        assertEquals(6, result.rivetsPerPiece)
        assertEquals(24, result.rivetsTotal)
        assertEquals(35.0, result.endSealantPerPieceMl, 1e-9)
        assertEquals(60.0, result.topEdgeSealantPerPieceMl, 1e-9)
        assertEquals(95.0, result.sealantPerPieceMl, 1e-9)
        assertEquals(380.0, result.sealantTotalMl, 1e-9)
        assertEquals(2, result.cartridges)
    }

    @Test
    fun `none and individual sealant modes remain independent`() {
        val base = DrawingRecord(
            id = 2,
            projectId = 1,
            name = "Rovný profil",
            identifier = "KL-ROVNY",
            points = mutableListOf(
                ProfilePoint(0f, 0f),
                ProfilePoint(200f, 0f)
            ),
            profileLengthM = 1.2,
            quantity = 1
        )

        val none = calculateConsumables(base.copy(sealantMode = SealantMode.NONE))
        val ends = calculateConsumables(base.copy(sealantMode = SealantMode.ENDS))
        val top = calculateConsumables(base.copy(sealantMode = SealantMode.TOP_EDGE))

        assertEquals(0.0, none.sealantTotalMl, 1e-9)
        assertEquals(20.0, ends.sealantTotalMl, 1e-9)
        assertEquals(0.0, ends.topEdgeSealantPerPieceMl, 1e-9)
        assertEquals(36.0, top.sealantTotalMl, 1e-9)
        assertEquals(0.0, top.endSealantPerPieceMl, 1e-9)
    }
}
