# KlampSketch 2.8.0

- Každý výrobok má voľbu tmelenia: bez tmelu, iba konce, iba horná hrana alebo oboje.
- Skrutky sa počítajú podľa výrobnej dĺžky pri maximálnom rozstupe 300 mm, vždy smerom nahor.
- Nity sa počítajú pevne 3 na každý koniec, teda 6 nitov na jeden kus profilu.
- Tmel koncov sa počíta zo súčtu prednej a zadnej rozvinutej šírky sadzbou 50 ml/m.
- Tmel hornej hrany sa počíta z výrobnej dĺžky sadzbou 30 ml/m.
- Technický nákres každého výrobku uvádza skrutky, nity, režim tmelenia a spotrebu tmelu na kus aj celkom.
- Každý PDF report končí samostatným súhrnom montážneho materiálu.
- Súhrn uvádza celkové skrutky, nity, tmel koncov, tmel hornej hrany a celé 310 ml kartuše zaokrúhlené nahor.
- Databáza sa migruje z verzie 4 na 5 bez odstránenia existujúcich stavieb, nákresov alebo fotografií.
- JSON import podporuje nepovinné pole `sealantMode`: `NONE`, `ENDS`, `TOP_EDGE` alebo `BOTH`.
- Optimalizácia delenia plechu a kalkulačný solver verzie 2.7.0 zostali nezmenené.
- APK používa rovnaký trvalý aktualizačný podpis ako verzie 2.6.0 a 2.7.0.
