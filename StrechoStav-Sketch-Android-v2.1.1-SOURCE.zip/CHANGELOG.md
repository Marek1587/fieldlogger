# Zmeny

## 2.1.1

- zoom mapy a výkresu kolieskom pripojenej myši.

## 2.1.0

- opravená diagnostika prázdnej Google mapy spôsobenej chýbajúcim alebo nesprávne obmedzeným API kľúčom,
- GitHub build sa bez `MAPS_API_KEY` zastaví namiesto vytvorenia nefunkčnej mapovej zostavy,
- stabilný debug podpis a uvedený SHA-1 pre Android obmedzenie Google API kľúča,
- zoom mapy dvoma prstami aj tlačidlami `+`, `−` a `Celok`,
- import PDF/JPG/PNG/WebP ako kresliaceho podkladu,
- posun, zoom a uloženie transformácie výkresového podkladu,
- výber obvodovej hrany a nastavenie dĺžky číselnými kolieskami,
- kalibrácia celého výkresu podľa jednej známej dĺžky,
- dĺžky obvodových hrán sa zobrazujú priamo v editore.

## 2.0.0

- názov aplikácie zmenený na StrechoStav Sketch,
- Google ortofotomapa, hybridná mapa a terén namiesto OSM dlaždíc,
- samostatné tlačidlo `Bod`,
- bezpečné odsadenie obsahu od hornej a dolnej systémovej lišty Androidu,
- 3D model obsahuje steny pôdorysu s nastaviteľnou výškou od 3 m,
- automatický tvar strechy podľa hrebeňov, nároží a úžľabí v nákrese,
- podpora kombinovaných tvarov vrátane polvalby,
- z výkazu, SVG a PDF odstránená hydroizolácia, podklad a ceny,
- Google Maps API kľúč sa načítava zo `secrets.properties` alebo GitHub secretu.

## 1.0.0

- prvá natívna Android verzia,
- dotykový 2D editor strechy,
- technické línie a prvky,
- lokálne projekty, JSON, SVG, PDF a 3D náhľad,
- GitHub Actions workflow na zostavenie debug APK.
