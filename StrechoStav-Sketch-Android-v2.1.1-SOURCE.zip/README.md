# StrechoStav Sketch pre Android

Natívna Android aplikácia v Kotline na zameranie strechy na Google Maps,
vytvorenie technického 2D nákresu, čistého výkazu výmer a 3D modelu strechy
spolu so stenami budovy.

## Hlavné funkcie

- Google ortofotomapa, hybridná mapa a zobrazenie terénu,
- priblíženie dvoma prstami a vždy dostupné tlačidlá `+`, `−` a `Celok`,
- import JPG, PNG, WebP alebo prvej strany PDF ako podkladu výkresu,
- posun a zoom výkresového podkladu a kalibrácia mierky podľa známej hrany,
- nastavenie presnej dĺžky vybranej strany číselnými kolieskami v metroch a centimetroch,
- vyhľadanie adresy cez Nominatim a načítanie najbližšieho obrysu budovy cez Overpass API,
- zadanie GPS súradníc alebo použitie poslednej polohy telefónu,
- obkreslenie strechy jedným ťahom alebo samostatným tlačidlom `Bod`,
- presúvanie vrcholov a korekcia smerov 0° / 45° / 90°,
- technické čiary: hrebeň, úžľabie, nárožie, atika, pultová hrana a napojenie pri murive,
- automatický 3D povrch podľa nakreslenej siete hrebeňov, nároží a úžľabí; použiteľný aj pre kombinované a polvalbové strechy,
- 3D steny podľa pôdorysu so základnou, používateľsky nastaviteľnou výškou 3 m,
- výpočet pôdorysnej plochy, plochy v sklone, obvodu a dĺžok jednotlivých typov hrán,
- čistý výkaz výmer bez hydroizolácie, podkladu a cenovej kalkulácie,
- lokálne projekty, duplikovanie a JSON import/export,
- technický SVG a PDF export,
- 3D ovládanie: otočenie jedným prstom, zoom dvoma prstami a reset dvojitým ťuknutím.

## Google Maps API kľúč

Google Maps vyžaduje vlastný API kľúč. V Google Cloud zapnite **Maps SDK for Android**,
vytvorte kľúč a obmedzte ho na Android aplikáciu s balíkom `sk.strechasketch.app`
a príslušným SHA-1 podpisom. Pre pribalenú stabilnú debug podpisovú konfiguráciu použite:

```text
Balík: sk.strechasketch.app
Debug SHA-1: B1:59:23:84:AE:CA:A5:08:2A:CF:50:B0:9F:2A:EB:36:2D:3B:11:98
```

V Google Cloud musí byť pre projekt zapnutá fakturácia a **Maps SDK for Android**.
Typy `Ortofoto`, `Hybrid` a `Terén` sú priamo mapové typy Google SDK.

Pre lokálne zostavenie vytvorte v koreňovom priečinku súbor `secrets.properties`:

```properties
MAPS_API_KEY=vas_google_maps_api_kluc
```

Súbor je v `.gitignore` a nesmie sa odoslať do GitHubu.

## Zostavenie APK cez GitHub

1. Rozbaľte obsah ZIP-u priamo do koreňa nového GitHub repozitára.
2. V repozitári otvorte **Settings → Secrets and variables → Actions**.
3. Vytvorte repository secret s názvom `MAPS_API_KEY` a vložte Google Maps API kľúč.
4. Commitnite súbory do vetvy `main` alebo `master`.
5. V karte **Actions** spustite workflow **Build StrechoStav Sketch APK**.
6. Stiahnite artifact `StrechoStav-Sketch-v2.1.1-debug-apk`; obsahuje `app-debug.apk`.

Workflow používa Java 17, Android SDK a Gradle 8.10.2. Gradle Wrapper nie je potrebný.
Ak secret chýba, workflow sa úmyselne zastaví s jasnou chybou, aby nevytvoril APK
s prázdnou Google mapou. Pribalený debug kľúč je iba na skúšanie; produkčnú verziu
treba podpísať vlastným bezpečným release kľúčom.

## PDF/JPG podklad a presné rozmery

1. V editore zvoľte `PDF/JPG` alebo `Nový podklad` a vyberte súbor.
2. V režime `Posun` výkres približujte dvoma prstami alebo tlačidlami `+` a `−`.
3. Obkreslite hrany, zvoľte `Editovať` a klepnite na známu hranu.
4. Otvorte `Rozmer hrany`, nastavte metre a centimetre kolieskami a nechajte
   zapnuté `Kalibrovať celý PDF/JPG podklad`. Celý nákres sa prepočíta bez
   posunutia voči obrázku.
5. Pri ďalších hranách môžete kalibráciu vypnúť a zmeniť iba koncový bod danej strany.

PDF podklad zobrazuje prvú stranu. Aplikácia si ponechá právo na čítanie vybraného
súboru, takže podklad zostane dostupný aj po opätovnom otvorení projektu.

## Lokálne zostavenie

Po nainštalovaní JDK 17 a Android SDK:

```text
gradle :app:assembleDebug
```

Výsledok bude v `app/build/outputs/apk/debug/app-debug.apk`.

## Online a offline režim

Editor projektu, uložené projekty, výpočty, 3D model a export fungujú lokálne.
Google mapový podklad, vyhľadanie novej adresy a nový import obrysu budovy vyžadujú internet.
Mapový podklad poskytuje Google Maps; Nominatim a Overpass sa používajú len na
vyhľadanie adresy a pomocnú geometriu budov.

## Technické upozornenie

Výmera z mapy a automaticky vytvorený 3D tvar sú orientačné. Pred realizáciou
treba rozmery, sklon a strešné detaily overiť priamo na stavbe. Automatický
model vychádza zo zakreslených technických čiar, preto musia byť hrebene,
nárožia a úžľabia vedené a napojené správne.

## Zdroje

- mapový podklad: Google Maps SDK for Android,
- geokódovanie: Nominatim,
- pomocná geometria budov: OpenStreetMap cez Overpass API.
