package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Point
import android.graphics.PointF
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.TextView
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import kotlin.math.roundToInt

@SuppressLint("ViewConstructor", "SetTextI18n")
class GoogleRoofMapHost(
    context: Context,
    val project: RoofProject
) : FrameLayout(context), OnMapReadyCallback {
    val editor = RoofMapEditorView(context, project)
    var onStatusChanged: ((String) -> Unit)? = null

    private val mapView = MapView(context)
    private val documentView = DocumentUnderlayView(context, project)
    private val mapWarning = TextView(context).apply {
        setTextColor(Color.rgb(116, 38, 26))
        setBackgroundColor(0xeefff3d9.toInt())
        setPadding(dp(12), dp(9), dp(12), dp(9))
        textSize = 12f
        gravity = Gravity.CENTER
        visibility = View.GONE
    }
    private var map: GoogleMap? = null
    private var pendingMapType = project.lastGoogleMapType.ifBlank { "HYBRID" }
    private var documentMode = project.mapType == "DOCUMENT" && project.underlayUri.isNotBlank()
    private var mapLoaded = false

    init {
        addView(mapView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(documentView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(mapWarning, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP))
        addView(editor, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        mapView.onCreate(null)
        mapView.getMapAsync(this)

        editor.onModeChanged = { updateGestureMode() }
        editor.onCameraRequested = { point, zoom ->
            showGoogle(project.lastGoogleMapType)
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(point.latLng(), zoom.toFloat()))
        }
        editor.onFitRequested = { points ->
            if (documentMode) documentView.fitDocument() else fitToPolygon(points)
        }
        editor.onZoomRequested = ::zoomBy

        documentView.onTransformChanged = { editor.invalidate() }
        documentView.onLoadStatus = { result ->
            result.onSuccess { onStatusChanged?.invoke(it) }
                .onFailure { onStatusChanged?.invoke("Výkres sa nepodarilo načítať: ${it.message}") }
        }

        if (documentMode) {
            showDocument(Uri.parse(project.underlayUri), project.underlayMime, project.underlayName, false)
        } else {
            showGoogle(project.mapType.takeUnless { it == "DOCUMENT" } ?: pendingMapType)
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        googleMap.mapType = googleMapType(pendingMapType)
        googleMap.isBuildingsEnabled = true
        googleMap.isIndoorEnabled = false
        googleMap.uiSettings.isMapToolbarEnabled = false
        googleMap.uiSettings.isZoomControlsEnabled = true
        googleMap.uiSettings.isZoomGesturesEnabled = true
        googleMap.uiSettings.isCompassEnabled = true
        updateGestureMode()
        googleMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(project.centerLat, project.centerLon),
                project.zoom.toFloat()
            )
        )
        googleMap.setOnCameraMoveListener { editor.invalidate() }
        googleMap.setOnCameraIdleListener {
            val camera = googleMap.cameraPosition
            project.centerLat = camera.target.latitude
            project.centerLon = camera.target.longitude
            project.zoom = camera.zoom.roundToInt().coerceIn(3, 21)
            editor.invalidate()
        }
        googleMap.setOnMapLoadedCallback {
            mapLoaded = true
            if (!documentMode) {
                hideMapWarning()
                onStatusChanged?.invoke("Google mapa je načítaná. Priblíženie: dva prsty alebo tlačidlá +/−.")
            }
        }
        bindGoogleProjection()
        updateBaseVisibility()
        scheduleMapDiagnostic()
        editor.invalidate()
    }

    fun setMapType(type: String) = showGoogle(type)

    fun showDocument(uri: Uri, mime: String, name: String, resetTransform: Boolean = true) {
        if (resetTransform || project.underlayUri != uri.toString()) {
            project.underlayOriginLat = project.centerLat
            project.underlayOriginLon = project.centerLon
            project.underlayCenterX = -1.0
            project.underlayCenterY = -1.0
            project.underlayZoom = 1.0
            project.underlayMetersPerPixel = 0.01
        }
        project.underlayUri = uri.toString()
        project.underlayMime = mime
        project.underlayName = name
        project.mapType = "DOCUMENT"
        documentMode = true
        bindDocumentProjection()
        updateBaseVisibility()
        updateGestureMode()
        documentView.load(uri)
        editor.invalidate()
    }

    fun removeDocument() {
        project.underlayUri = ""
        project.underlayMime = ""
        project.underlayName = ""
        project.underlayCenterX = -1.0
        project.underlayCenterY = -1.0
        documentView.clearBitmap()
        showGoogle(project.lastGoogleMapType)
    }

    fun isDocumentMode(): Boolean = documentMode

    fun zoomBy(steps: Float) {
        if (documentMode) {
            documentView.zoomBy(steps)
        } else {
            map?.moveCamera(CameraUpdateFactory.zoomBy(steps))
        }
    }

    fun fitCurrent() {
        if (documentMode) documentView.fitDocument()
        else if (project.polygon.isNotEmpty()) fitToPolygon(project.polygon)
        else map?.animateCamera(
            CameraUpdateFactory.newLatLngZoom(LatLng(project.centerLat, project.centerLon), project.zoom.toFloat())
        )
    }

    fun onCreate(state: Bundle?) = Unit
    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
    fun onDestroy() {
        documentView.clearBitmap()
        mapView.onDestroy()
    }
    fun onLowMemory() = mapView.onLowMemory()

    private fun showGoogle(type: String) {
        val normalized = type.uppercase().takeIf { it in setOf("SATELLITE", "HYBRID", "TERRAIN", "NORMAL") }
            ?: project.lastGoogleMapType.ifBlank { "HYBRID" }
        pendingMapType = normalized
        project.lastGoogleMapType = normalized
        project.mapType = normalized
        documentMode = false
        mapLoaded = false
        map?.mapType = googleMapType(normalized)
        bindGoogleProjection()
        updateBaseVisibility()
        updateGestureMode()
        scheduleMapDiagnostic()
        editor.invalidate()
    }

    private fun bindGoogleProjection() {
        val googleMap = map
        if (googleMap == null) {
            editor.projectPointToScreen = null
            editor.screenPointToProject = null
            return
        }
        editor.projectPointToScreen = { point ->
            googleMap.projection.toScreenLocation(point.latLng()).let { PointF(it.x.toFloat(), it.y.toFloat()) }
        }
        editor.screenPointToProject = { x, y ->
            googleMap.projection.fromScreenLocation(Point(x.roundToInt(), y.roundToInt())).let {
                GeoPoint(it.latitude, it.longitude)
            }
        }
    }

    private fun bindDocumentProjection() {
        editor.projectPointToScreen = documentView::projectToScreen
        editor.screenPointToProject = documentView::screenToProject
    }

    private fun updateGestureMode() {
        map?.uiSettings?.setAllGesturesEnabled(!documentMode && editor.mode == EditorMode.PAN)
        map?.uiSettings?.isZoomControlsEnabled = !documentMode
        documentView.isEnabled = documentMode && editor.mode == EditorMode.PAN
    }

    private fun updateBaseVisibility() {
        mapView.visibility = if (documentMode) View.GONE else View.VISIBLE
        documentView.visibility = if (documentMode) View.VISIBLE else View.GONE
        if (documentMode) hideMapWarning() else showKeyWarningIfNeeded()
    }

    private fun showKeyWarningIfNeeded() {
        if (!hasUsableApiKey()) {
            mapWarning.text = "Google mapa nemá platný API kľúč. APK treba zostaviť s GitHub secretom MAPS_API_KEY."
            mapWarning.visibility = View.VISIBLE
        } else if (mapLoaded) {
            hideMapWarning()
        }
    }

    private fun scheduleMapDiagnostic() {
        showKeyWarningIfNeeded()
        postDelayed({
            if (!documentMode && !mapLoaded && hasUsableApiKey()) {
                mapWarning.text = "Google dlaždice sa nenačítali. Skontrolujte internet, Maps SDK for Android, fakturáciu a obmedzenie kľúča na správny SHA-1."
                mapWarning.visibility = View.VISIBLE
            }
        }, 8000)
    }

    @Suppress("DEPRECATION")
    private fun hasUsableApiKey(): Boolean {
        val info = context.packageManager.getApplicationInfo(context.packageName, PackageManager.GET_META_DATA)
        val key = info.metaData?.getString("com.google.android.geo.API_KEY").orEmpty()
        return key.startsWith("AIza") && key.length > 24
    }

    private fun hideMapWarning() {
        mapWarning.visibility = View.GONE
    }

    private fun fitToPolygon(points: List<GeoPoint>) {
        val googleMap = map ?: return
        if (points.isEmpty()) return
        if (points.size == 1) {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(points.first().latLng(), 20f))
            return
        }
        val builder = LatLngBounds.Builder()
        points.forEach { builder.include(it.latLng()) }
        post {
            runCatching { googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 72)) }
        }
    }

    private fun googleMapType(type: String): Int = when (type.uppercase()) {
        "SATELLITE" -> GoogleMap.MAP_TYPE_SATELLITE
        "TERRAIN" -> GoogleMap.MAP_TYPE_TERRAIN
        "NORMAL" -> GoogleMap.MAP_TYPE_NORMAL
        else -> GoogleMap.MAP_TYPE_HYBRID
    }

    private fun GeoPoint.latLng() = LatLng(lat, lon)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
}
