package sk.strechasketch.app

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URI
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

data class GeocodedPlace(val displayName: String, val point: GeoPoint)
data class BuildingFootprint(
    val osmId: Long,
    val buildingType: String,
    val name: String,
    val points: MutableList<GeoPoint>,
    val areaM2: Double,
    val distanceM: Double
)

object GeoServices {
    private const val USER_AGENT = "StrechoStav-Sketch-Android/2.0 (roof drawing field application)"
    private val executor = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun geocode(query: String, callback: (Result<GeocodedPlace>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
                val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=sk,cz&addressdetails=1&q=$encoded"
                val array = JSONArray(get(url))
                require(array.length() > 0) { "Adresa sa nenašla." }
                val item = array.getJSONObject(0)
                GeocodedPlace(
                    item.optString("display_name", query),
                    GeoPoint(item.getString("lat").toDouble(), item.getString("lon").toDouble())
                )
            }
            main.post { callback(result) }
        }
    }

    fun nearestBuilding(center: GeoPoint, callback: (Result<BuildingFootprint>) -> Unit) {
        executor.execute {
            val result = runCatching {
                val query = """
                    [out:json][timeout:25];
                    (
                      way["building"](around:120,${center.lat},${center.lon});
                      relation["building"](around:120,${center.lat},${center.lon});
                    );
                    out geom tags;
                """.trimIndent()
                val encoded = URLEncoder.encode(query, StandardCharsets.UTF_8.name())
                val root = JSONObject(get("https://overpass-api.de/api/interpreter?data=$encoded"))
                val elements = root.optJSONArray("elements") ?: JSONArray()
                val candidates = mutableListOf<BuildingFootprint>()
                repeat(elements.length()) { index ->
                    val element = elements.getJSONObject(index)
                    val tags = element.optJSONObject("tags") ?: JSONObject()
                    val polygons = mutableListOf<JSONArray>()
                    element.optJSONArray("geometry")?.let(polygons::add)
                    val members = element.optJSONArray("members")
                    if (members != null) {
                        repeat(members.length()) { memberIndex ->
                            val member = members.getJSONObject(memberIndex)
                            val role = member.optString("role")
                            if (role.isBlank() || role == "outer") {
                                member.optJSONArray("geometry")?.let(polygons::add)
                            }
                        }
                    }
                    polygons.forEach { geometry ->
                        val points = mutableListOf<GeoPoint>()
                        repeat(geometry.length()) { pointIndex ->
                            val point = geometry.getJSONObject(pointIndex)
                            points += GeoPoint(point.optDouble("lat"), point.optDouble("lon"))
                        }
                        if (points.size > 3 && Geometry.distanceM(points.first(), points.last()) < 0.25) {
                            points.removeAt(points.lastIndex)
                        }
                        val area = Geometry.areaM2(points)
                        if (points.size >= 3 && area in 5.0..50_000.0) {
                            candidates += BuildingFootprint(
                                osmId = element.optLong("id"),
                                buildingType = tags.optString("building", "building"),
                                name = tags.optString("name"),
                                points = points,
                                areaM2 = area,
                                distanceM = Geometry.nearestDistanceToPolygon(center, points)
                            )
                        }
                    }
                }
                require(candidates.isNotEmpty()) { "V okruhu 120 m nie je v OpenStreetMap zakreslená budova." }
                candidates.minWith(compareBy<BuildingFootprint> { it.distanceM }.thenBy { it.areaM2 })
            }
            main.post { callback(result) }
        }
    }

    private fun get(url: String): String {
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = 12_000
        connection.readTimeout = 28_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept", "application/json")
        return try {
            val code = connection.responseCode
            require(code in 200..299) { "Mapová služba odpovedala kódom $code." }
            connection.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}
