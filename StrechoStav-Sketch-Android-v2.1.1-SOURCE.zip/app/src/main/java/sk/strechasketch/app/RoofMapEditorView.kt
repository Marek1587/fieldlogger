package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.InputDevice
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

enum class EditorMode(val label: String) {
    PAN("Posun mapy"),
    DRAW_POLYGON("Obrys prstom"),
    ADD_VERTEX("Pridať body"),
    EDIT("Editovať"),
    ADD_LINE("Pridať líniu"),
    ADD_OBJECT("Pridať prvok")
}

private enum class SelectionKind { NONE, VERTEX, EDGE, LINE, OBJECT }

@SuppressLint("ViewConstructor")
class RoofMapEditorView(
    context: Context,
    val project: RoofProject
) : View(context) {
    var mode: EditorMode = EditorMode.PAN
        private set
    var activeLineType: LineType = LineType.RIDGE
        private set
    var activeObjectType: ObjectType = ObjectType.CHIMNEY
        private set
    var onProjectChanged: (() -> Unit)? = null
    var onStatusChanged: ((String) -> Unit)? = null
    var onModeChanged: ((EditorMode) -> Unit)? = null
    var onCameraRequested: ((GeoPoint, Int) -> Unit)? = null
    var onFitRequested: ((List<GeoPoint>) -> Unit)? = null
    var onZoomRequested: ((Float) -> Unit)? = null
    var projectPointToScreen: ((GeoPoint) -> PointF)? = null
    var screenPointToProject: ((Float, Float) -> GeoPoint)? = null

    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val history = ArrayDeque<String>()
    private var pendingLineStart: GeoPoint? = null
    private var selectionKind = SelectionKind.NONE
    private var selectedIndex = -1
    private var lastTouch = PointF()
    private var draggingMap = false
    private var drawingPolygon = false
    private var draggingSelection = false
    private var lastFreehandPoint = PointF()
    private var scaleGestureActive = false
    private var ignoreTouchesUntilUp = false
    private val density = resources.displayMetrics.density
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            scaleGestureActive = true
            ignoreTouchesUntilUp = true
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            onZoomRequested?.invoke((ln(detector.scaleFactor.toDouble()) / ln(2.0)).toFloat())
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            scaleGestureActive = false
        }
    })

    init {
        isFocusable = true
        contentDescription = "Mapový editor strechy"
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun setMode(value: EditorMode, lineType: LineType? = null, objectType: ObjectType? = null) {
        mode = value
        lineType?.let { activeLineType = it }
        objectType?.let { activeObjectType = it }
        pendingLineStart = null
        clearSelection()
        val detail = when (value) {
            EditorMode.ADD_LINE -> ": ${activeLineType.label} – označte dva body"
            EditorMode.ADD_OBJECT -> ": ${activeObjectType.label} – klepnite na polohu"
            EditorMode.DRAW_POLYGON -> " – jedným ťahom obkreslite strechu"
            EditorMode.ADD_VERTEX -> " – klepaním pridávajte rohy obrysu"
            EditorMode.EDIT -> " – potiahnite vrchol alebo prvok"
            EditorMode.PAN -> " – posúvajte a približujte mapu"
        }
        status("${value.label}$detail")
        onModeChanged?.invoke(value)
        invalidate()
    }

    fun setCenter(point: GeoPoint, zoom: Int = 19) {
        project.centerLat = point.lat
        project.centerLon = point.lon
        project.zoom = zoom.coerceIn(3, 21)
        onCameraRequested?.invoke(point, project.zoom)
        changed("Mapa premiestnená na ${"%.6f".format(point.lat)}, ${"%.6f".format(point.lon)}")
    }

    fun importPolygon(points: List<GeoPoint>) {
        if (points.size < 3) return
        pushHistory()
        project.polygon = points.map { it.copy() }.toMutableList()
        project.lines.clear()
        project.objects.clear()
        project.edgeTypes.clear()
        fitToPolygon()
        mode = EditorMode.EDIT
        changed("Importovaný obrys: ${project.polygon.size} bodov, ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
    }

    fun finishPolygon() {
        if (project.polygon.size >= 3) {
            mode = EditorMode.EDIT
            changed("Obrys uzavretý: ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
        } else {
            status("Obrys potrebuje aspoň tri body.")
        }
    }

    fun correctGeometry() {
        if (project.polygon.size < 3) {
            status("Najprv vytvorte obrys strechy.")
            return
        }
        pushHistory()
        project.polygon = Geometry.regularize(project.polygon)
        changed("Geometria bola vyrovnaná na smery 0° / 45° / 90°.")
    }

    fun undo() {
        val snapshot = history.removeLastOrNull() ?: run {
            status("Nie je čo vrátiť.")
            return
        }
        applySnapshot(ProjectJson.decode(snapshot))
        changed("Posledná úprava bola vrátená.")
    }

    fun deleteSelection() {
        if (selectedIndex < 0) {
            status("Najprv vyberte vrchol, líniu alebo prvok.")
            return
        }
        pushHistory()
        when (selectionKind) {
            SelectionKind.VERTEX -> if (project.polygon.size > 3) project.polygon.removeAt(selectedIndex)
            SelectionKind.LINE -> project.lines.removeAt(selectedIndex)
            SelectionKind.OBJECT -> project.objects.removeAt(selectedIndex)
            SelectionKind.EDGE, SelectionKind.NONE -> Unit
        }
        clearSelection()
        changed("Vybraný prvok bol odstránený.")
    }

    fun clearDrawing() {
        pushHistory()
        project.polygon.clear()
        project.lines.clear()
        project.objects.clear()
        project.edgeTypes.clear()
        clearSelection()
        changed("Nákres bol vyčistený.")
    }

    fun cycleSelectedEdgeType(): LineType? {
        if (project.polygon.size < 3) return null
        val edgeIndex = if (selectionKind == SelectionKind.EDGE) selectedIndex
            else selectedEdgeNear(lastTouch.x, lastTouch.y)
        if (edgeIndex < 0) {
            status("V režime editácie klepnite tesne na obvodovú hranu.")
            return null
        }
        pushHistory()
        val types = listOf(LineType.EAVE, LineType.GABLE, LineType.ATTIC, LineType.PULT, LineType.WALL_END)
        val current = project.edgeTypes[edgeIndex] ?: LineType.EAVE
        val next = types[(types.indexOf(current).coerceAtLeast(0) + 1) % types.size]
        project.edgeTypes[edgeIndex] = next
        changed("Hrana ${edgeIndex + 1}: ${next.label}")
        return next
    }

    fun selectedEdgeLengthM(): Double? {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.EDGE } ?: return null
        if (project.polygon.size < 2 || index !in project.polygon.indices) return null
        return Geometry.distanceM(project.polygon[index], project.polygon[(index + 1) % project.polygon.size])
    }

    fun setSelectedEdgeLength(targetLengthM: Double, calibrateWholeDrawing: Boolean): Boolean {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.EDGE } ?: run {
            status("Najprv zvoľte Editovať a klepnite na obvodovú hranu.")
            return false
        }
        val currentLength = selectedEdgeLengthM() ?: return false
        if (targetLengthM !in 0.05..5000.0 || currentLength < 0.0001) return false
        pushHistory()
        if (calibrateWholeDrawing) {
            val origin = GeoPoint(project.underlayOriginLat, project.underlayOriginLon)
            val ratio = targetLengthM / currentLength
            fun scaled(point: GeoPoint): GeoPoint {
                val local = Geometry.toLocal(point, origin)
                return Geometry.toGeo(LocalPoint(local.x * ratio, local.y * ratio), origin)
            }
            project.polygon = project.polygon.map(::scaled).toMutableList()
            project.lines.forEach { line ->
                line.start = scaled(line.start)
                line.end = scaled(line.end)
            }
            project.objects.forEach { item -> item.center = scaled(item.center) }
            project.underlayMetersPerPixel = (project.underlayMetersPerPixel * ratio).coerceIn(0.00001, 1000.0)
            changed("Výkres bol kalibrovaný podľa hrany #${index + 1} na ${"%.2f".format(targetLengthM)} m.")
        } else {
            val start = project.polygon[index]
            val endIndex = (index + 1) % project.polygon.size
            val end = project.polygon[endIndex]
            val local = Geometry.toLocal(end, start)
            val factor = targetLengthM / hypot(local.x, local.y)
            project.polygon[endIndex] = Geometry.toGeo(LocalPoint(local.x * factor, local.y * factor), start)
            changed("Dĺžka hrany #${index + 1} bola zmenená na ${"%.2f".format(targetLengthM)} m.")
        }
        return true
    }

    fun fitToPolygon() {
        if (project.polygon.isEmpty() || width <= 0 || height <= 0) return
        onFitRequested?.let {
            it(project.polygon)
            return
        }
        val center = Geometry.centroid(project.polygon)
        project.centerLat = center.lat
        project.centerLon = center.lon
        for (candidate in 21 downTo 3) {
            val xs = project.polygon.map { Geometry.worldX(it.lon, candidate) }
            val ys = project.polygon.map { Geometry.worldY(it.lat, candidate) }
            if ((xs.maxOrNull()!! - xs.minOrNull()!!) < width * 0.72 &&
                (ys.maxOrNull()!! - ys.minOrNull()!!) < height * 0.65
            ) {
                project.zoom = candidate
                break
            }
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawMap(canvas)
        drawGeometry(canvas)
        drawMapChrome(canvas)
    }

    private fun drawMap(canvas: Canvas) {
        // Mapový podklad kreslí Google Maps MapView pod touto priehľadnou vrstvou.
    }

    private fun drawGeometry(canvas: Canvas) {
        if (project.polygon.isNotEmpty()) {
            val screen = project.polygon.map(::toScreen)
            if (screen.size >= 3) {
                val path = Path().apply {
                    moveTo(screen.first().x, screen.first().y)
                    screen.drop(1).forEach { lineTo(it.x, it.y) }
                    close()
                }
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = 0x4032b847
                canvas.drawPath(path, overlayPaint)
            }
            overlayPaint.style = Paint.Style.STROKE
            project.polygon.indices.forEach { index ->
                if (index == project.polygon.lastIndex && project.polygon.size < 3) return@forEach
                val next = (index + 1) % project.polygon.size
                val type = project.edgeTypes[index] ?: LineType.EAVE
                overlayPaint.strokeWidth = if (selectionKind == SelectionKind.EDGE && selectedIndex == index) {
                    6f * density
                } else 3.2f * density
                overlayPaint.color = type.color
                canvas.drawLine(screen[index].x, screen[index].y, screen[next].x, screen[next].y, overlayPaint)
                if (project.polygon.size >= 3) {
                    val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
                    drawSmallLabel(
                        canvas,
                        "${type.label.take(3)} ${"%.1f".format(length)} m",
                        midpoint(screen[index], screen[next]),
                        type.color
                    )
                }
            }
            screen.forEachIndexed { index, point ->
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = if (selectionKind == SelectionKind.VERTEX && selectedIndex == index) {
                    0xffffb000.toInt()
                } else Color.WHITE
                canvas.drawCircle(point.x, point.y, 7f * density, overlayPaint)
                overlayPaint.style = Paint.Style.STROKE
                overlayPaint.strokeWidth = 2f * density
                overlayPaint.color = 0xff176d19.toInt()
                canvas.drawCircle(point.x, point.y, 7f * density, overlayPaint)
            }
        }

        project.lines.forEachIndexed { index, line ->
            val a = toScreen(line.start)
            val b = toScreen(line.end)
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = if (selectionKind == SelectionKind.LINE && selectedIndex == index) 6f * density else 3f * density
            overlayPaint.color = line.type.color
            if (line.type == LineType.WALL_END) {
                overlayPaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(12f, 8f), 0f)
            }
            canvas.drawLine(a.x, a.y, b.x, b.y, overlayPaint)
            overlayPaint.pathEffect = null
            drawSmallLabel(canvas, line.type.label, midpoint(a, b), line.type.color)
        }
        pendingLineStart?.let {
            val point = toScreen(it)
            overlayPaint.style = Paint.Style.FILL
            overlayPaint.color = activeLineType.color
            canvas.drawCircle(point.x, point.y, 8f * density, overlayPaint)
        }

        project.objects.forEachIndexed { index, item ->
            val point = toScreen(item.center)
            val selected = selectionKind == SelectionKind.OBJECT && selectedIndex == index
            val color = if (selected) 0xffffa000.toInt() else objectColor(item.type)
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = (if (selected) 4f else 2.4f) * density
            overlayPaint.color = color
            val metresPerPixel = Geometry.metersPerPixel(item.center.lat, project.zoom)
            when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH -> {
                    val halfW = max(8.0, item.widthMm / 1000.0 / metresPerPixel / 2).toFloat()
                    val halfH = max(8.0, item.heightMm / 1000.0 / metresPerPixel / 2).toFloat()
                    canvas.save()
                    canvas.rotate(item.rotationDeg.toFloat(), point.x, point.y)
                    canvas.drawRect(point.x - halfW, point.y - halfH, point.x + halfW, point.y + halfH, overlayPaint)
                    canvas.restore()
                }
                ObjectType.VENT, ObjectType.DRAIN -> {
                    val radius = max(7.0, item.diameterMm / 1000.0 / metresPerPixel / 2).toFloat()
                    canvas.drawCircle(point.x, point.y, radius, overlayPaint)
                }
                ObjectType.DOWNSPOUT -> {
                    canvas.drawCircle(point.x, point.y, 7f * density, overlayPaint)
                    canvas.drawLine(point.x, point.y, point.x + 24f * density, point.y + 24f * density, overlayPaint)
                }
                ObjectType.HEIGHT_MARK -> {
                    canvas.drawLine(point.x - 12f * density, point.y, point.x + 12f * density, point.y, overlayPaint)
                    canvas.drawLine(point.x, point.y - 12f * density, point.x, point.y + 12f * density, overlayPaint)
                }
                ObjectType.SLOPE_MARK -> {
                    canvas.drawLine(point.x - 16f * density, point.y + 12f * density, point.x + 16f * density, point.y - 12f * density, overlayPaint)
                    canvas.drawCircle(point.x + 16f * density, point.y - 12f * density, 3f * density, overlayPaint)
                }
            }
            drawSmallLabel(canvas, item.type.label, PointF(point.x, point.y - 15f * density), color)
        }
    }

    private fun drawMapChrome(canvas: Canvas) {
        if (mode == EditorMode.PAN) {
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = 1.5f * density
            overlayPaint.color = 0xff237a35.toInt()
            canvas.drawCircle(width / 2f, height / 2f, 10f * density, overlayPaint)
            canvas.drawLine(width / 2f - 16f * density, height / 2f, width / 2f + 16f * density, height / 2f, overlayPaint)
            canvas.drawLine(width / 2f, height / 2f - 16f * density, width / 2f, height / 2f + 16f * density, overlayPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (mode == EditorMode.PAN) return false
        scaleDetector.onTouchEvent(event)
        if (event.pointerCount > 1 || scaleGestureActive || ignoreTouchesUntilUp) {
            drawingPolygon = false
            draggingSelection = false
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                ignoreTouchesUntilUp = false
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            return true
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastTouch.set(event.x, event.y)
                lastFreehandPoint.set(event.x, event.y)
                when (mode) {
                    EditorMode.PAN -> draggingMap = true
                    EditorMode.DRAW_POLYGON -> {
                        pushHistory()
                        project.polygon.clear()
                        project.lines.clear()
                        project.objects.clear()
                        project.edgeTypes.clear()
                        project.polygon += fromScreen(event.x, event.y)
                        drawingPolygon = true
                    }
                    EditorMode.EDIT -> {
                        hitTest(event.x, event.y)
                        draggingSelection = selectionKind == SelectionKind.VERTEX ||
                            selectionKind == SelectionKind.OBJECT
                    }
                    else -> Unit
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastTouch.x
                val dy = event.y - lastTouch.y
                when {
                    draggingMap -> panBy(dx, dy)
                    drawingPolygon -> {
                        if (hypot(event.x - lastFreehandPoint.x, event.y - lastFreehandPoint.y) > 9f * density) {
                            project.polygon += fromScreen(event.x, event.y)
                            lastFreehandPoint.set(event.x, event.y)
                            invalidate()
                        }
                    }
                    draggingSelection -> {
                        when (selectionKind) {
                            SelectionKind.VERTEX -> project.polygon[selectedIndex] = fromScreen(event.x, event.y)
                            SelectionKind.OBJECT -> project.objects[selectedIndex].center = fromScreen(event.x, event.y)
                            SelectionKind.EDGE, SelectionKind.LINE, SelectionKind.NONE -> Unit
                        }
                        invalidate()
                    }
                }
                lastTouch.set(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                when {
                    drawingPolygon -> {
                        drawingPolygon = false
                        project.polygon = simplifyFreehand(project.polygon)
                        if (project.polygon.size >= 3) {
                            mode = EditorMode.EDIT
                            changed("Obrys vytvorený: ${project.polygon.size} bodov, ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
                        } else status("Ťah bol príliš krátky. Skúste obkresliť celý obrys.")
                    }
                    draggingMap -> {
                        draggingMap = false
                        changed("Stred mapy: ${"%.6f".format(project.centerLat)}, ${"%.6f".format(project.centerLon)}")
                    }
                    draggingSelection -> {
                        draggingSelection = false
                        changed("Poloha prvku bola upravená.")
                    }
                    event.actionMasked == MotionEvent.ACTION_UP -> handleTap(event.x, event.y)
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL &&
            event.source and InputDevice.SOURCE_CLASS_POINTER != 0
        ) {
            val wheel = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (wheel != 0f) {
                onZoomRequested?.invoke(wheel)
                return true
            }
        }
        return super.onGenericMotionEvent(event)
    }

    private fun handleTap(x: Float, y: Float) {
        val point = fromScreen(x, y)
        when (mode) {
            EditorMode.ADD_VERTEX -> {
                pushHistory()
                project.polygon += point
                changed("Pridaný bod obrysu č. ${project.polygon.size}.")
            }
            EditorMode.ADD_LINE -> {
                val first = pendingLineStart
                if (first == null) {
                    pendingLineStart = point
                    status("${activeLineType.label}: označte druhý bod.")
                    invalidate()
                } else {
                    pushHistory()
                    project.lines += RoofLine(type = activeLineType, start = first, end = point)
                    pendingLineStart = null
                    changed("${activeLineType.label} bol pridaný.")
                }
            }
            EditorMode.ADD_OBJECT -> {
                pushHistory()
                project.objects += defaultObject(activeObjectType, point)
                changed("${activeObjectType.label} bol pridaný.")
            }
            else -> Unit
        }
    }

    private fun panBy(dx: Float, dy: Float) {
        val centerX = Geometry.worldX(project.centerLon, project.zoom) - dx
        val centerY = Geometry.worldY(project.centerLat, project.zoom) - dy
        project.centerLon = Geometry.lonFromWorld(centerX, project.zoom)
        project.centerLat = Geometry.latFromWorld(centerY, project.zoom)
        invalidate()
    }

    private fun toScreen(point: GeoPoint): PointF {
        projectPointToScreen?.let { return it(point) }
        val centerX = Geometry.worldX(project.centerLon, project.zoom)
        val centerY = Geometry.worldY(project.centerLat, project.zoom)
        return PointF(
            (Geometry.worldX(point.lon, project.zoom) - centerX + width / 2.0).toFloat(),
            (Geometry.worldY(point.lat, project.zoom) - centerY + height / 2.0).toFloat()
        )
    }

    private fun fromScreen(x: Float, y: Float): GeoPoint {
        screenPointToProject?.let { return it(x, y) }
        val worldX = Geometry.worldX(project.centerLon, project.zoom) + x - width / 2.0
        val worldY = Geometry.worldY(project.centerLat, project.zoom) + y - height / 2.0
        return GeoPoint(
            Geometry.latFromWorld(worldY, project.zoom),
            Geometry.lonFromWorld(worldX, project.zoom)
        )
    }

    private fun hitTest(x: Float, y: Float) {
        clearSelection()
        val threshold = 25f * density
        project.polygon.forEachIndexed { index, geo ->
            val point = toScreen(geo)
            if (hypot(x - point.x, y - point.y) < threshold) {
                selectionKind = SelectionKind.VERTEX
                selectedIndex = index
                status("Vybraný vrchol #${index + 1}.")
                return
            }
        }
        project.objects.forEachIndexed { index, item ->
            val point = toScreen(item.center)
            if (hypot(x - point.x, y - point.y) < threshold) {
                selectionKind = SelectionKind.OBJECT
                selectedIndex = index
                status("Vybraný prvok: ${item.type.label}.")
                return
            }
        }
        project.lines.forEachIndexed { index, line ->
            if (distancePointToScreenSegment(x, y, toScreen(line.start), toScreen(line.end)) < 18f * density) {
                selectionKind = SelectionKind.LINE
                selectedIndex = index
                status("Vybraná línia: ${line.type.label}.")
                return
            }
        }
        val edge = selectedEdgeNear(x, y)
        if (edge >= 0) {
            selectionKind = SelectionKind.EDGE
            selectedIndex = edge
            val length = Geometry.distanceM(project.polygon[edge], project.polygon[(edge + 1) % project.polygon.size])
            status("Vybraná hrana #${edge + 1}: ${"%.2f".format(length)} m. Použite Rozmer hrany alebo Typ hrany.")
        }
        invalidate()
    }

    private fun selectedEdgeNear(x: Float, y: Float): Int {
        if (project.polygon.size < 3) return -1
        return project.polygon.indices
            .map { index ->
                index to distancePointToScreenSegment(
                    x, y,
                    toScreen(project.polygon[index]),
                    toScreen(project.polygon[(index + 1) % project.polygon.size])
                )
            }
            .filter { it.second < 18f * density }
            .minByOrNull { it.second }?.first ?: -1
    }

    private fun distancePointToScreenSegment(x: Float, y: Float, a: PointF, b: PointF): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        if (abs(dx) + abs(dy) < 0.001f) return hypot(x - a.x, y - a.y)
        val t = (((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy)).coerceIn(0f, 1f)
        return hypot(x - (a.x + t * dx), y - (a.y + t * dy))
    }

    private fun simplifyFreehand(points: List<GeoPoint>): MutableList<GeoPoint> {
        if (points.size <= 12) return points.map { it.copy() }.toMutableList()
        val minDistance = max(0.25, Geometry.metersPerPixel(project.centerLat, project.zoom) * 8.0)
        val result = mutableListOf(points.first().copy())
        points.drop(1).forEach { point ->
            if (Geometry.distanceM(result.last(), point) >= minDistance) result += point.copy()
        }
        while (result.size > 36) {
            val reduced = result.filterIndexed { index, _ -> index % 2 == 0 }.toMutableList()
            if (reduced.last() != result.last()) reduced += result.last()
            result.clear()
            result.addAll(reduced)
        }
        return result
    }

    private fun defaultObject(type: ObjectType, center: GeoPoint): RoofObject = when (type) {
        ObjectType.CHIMNEY -> RoofObject(type = type, center = center, widthMm = 700.0, heightMm = 700.0)
        ObjectType.ROOF_WINDOW -> RoofObject(type = type, center = center, widthMm = 780.0, heightMm = 1180.0)
        ObjectType.HATCH -> RoofObject(type = type, center = center, widthMm = 700.0, heightMm = 700.0)
        ObjectType.VENT -> RoofObject(type = type, center = center, diameterMm = 160.0)
        ObjectType.DRAIN -> RoofObject(type = type, center = center, diameterMm = 110.0)
        ObjectType.DOWNSPOUT -> RoofObject(type = type, center = center, diameterMm = 100.0, heightMm = 3000.0)
        ObjectType.HEIGHT_MARK -> RoofObject(type = type, center = center, value = 0.0, note = "+0.000")
        ObjectType.SLOPE_MARK -> RoofObject(type = type, center = center, value = project.slopeDeg)
    }

    private fun objectColor(type: ObjectType): Int = when (type) {
        ObjectType.CHIMNEY -> 0xffc64c32.toInt()
        ObjectType.ROOF_WINDOW -> 0xff0099cc.toInt()
        ObjectType.HATCH -> 0xff7b5ea7.toInt()
        ObjectType.VENT -> 0xffe08a00.toInt()
        ObjectType.DRAIN -> 0xff0066aa.toInt()
        ObjectType.DOWNSPOUT -> 0xff15924a.toInt()
        ObjectType.HEIGHT_MARK -> 0xff333333.toInt()
        ObjectType.SLOPE_MARK -> 0xff111111.toInt()
    }

    private fun midpoint(a: PointF, b: PointF) = PointF((a.x + b.x) / 2f, (a.y + b.y) / 2f)

    private fun drawSmallLabel(canvas: Canvas, text: String, point: PointF, color: Int) {
        textPaint.textSize = 9.5f * density
        textPaint.color = color
        textPaint.isFakeBoldText = true
        val width = textPaint.measureText(text)
        overlayPaint.style = Paint.Style.FILL
        overlayPaint.color = 0xdfffffff.toInt()
        canvas.drawRoundRect(
            point.x - width / 2 - 3f * density,
            point.y - 12f * density,
            point.x + width / 2 + 3f * density,
            point.y + 2f * density,
            3f * density,
            3f * density,
            overlayPaint
        )
        canvas.drawText(text, point.x - width / 2, point.y - 2f * density, textPaint)
    }

    private fun clearSelection() {
        selectionKind = SelectionKind.NONE
        selectedIndex = -1
    }

    private fun pushHistory() {
        history.addLast(ProjectJson.encode(project))
        while (history.size > 30) history.removeFirst()
    }

    private fun applySnapshot(snapshot: RoofProject) {
        project.name = snapshot.name
        project.customer = snapshot.customer
        project.address = snapshot.address
        project.centerLat = snapshot.centerLat
        project.centerLon = snapshot.centerLon
        project.zoom = snapshot.zoom
        project.slopeDeg = snapshot.slopeDeg
        project.wallHeightM = snapshot.wallHeightM
        project.shape = snapshot.shape
        project.mapType = snapshot.mapType
        project.lastGoogleMapType = snapshot.lastGoogleMapType
        project.underlayUri = snapshot.underlayUri
        project.underlayMime = snapshot.underlayMime
        project.underlayName = snapshot.underlayName
        project.underlayOriginLat = snapshot.underlayOriginLat
        project.underlayOriginLon = snapshot.underlayOriginLon
        project.underlayMetersPerPixel = snapshot.underlayMetersPerPixel
        project.underlayZoom = snapshot.underlayZoom
        project.underlayCenterX = snapshot.underlayCenterX
        project.underlayCenterY = snapshot.underlayCenterY
        project.polygon = snapshot.polygon
        project.lines = snapshot.lines
        project.objects = snapshot.objects
        project.edgeTypes = snapshot.edgeTypes
        clearSelection()
    }

    private fun changed(message: String) {
        project.updatedAt = System.currentTimeMillis()
        status(message)
        onProjectChanged?.invoke()
        invalidate()
    }

    private fun status(message: String) {
        onStatusChanged?.invoke(message)
    }
}
