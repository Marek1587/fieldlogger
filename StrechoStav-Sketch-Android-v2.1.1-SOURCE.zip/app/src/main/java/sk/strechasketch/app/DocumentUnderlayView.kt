package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.max

@SuppressLint("ViewConstructor")
class DocumentUnderlayView(
    context: Context,
    private val project: RoofProject
) : View(context) {
    var onTransformChanged: (() -> Unit)? = null
    var onLoadStatus: ((Result<String>) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val imageMatrix = Matrix()
    private val inverseMatrix = Matrix()
    private var bitmap: Bitmap? = null
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomByFactor(detector.scaleFactor.toDouble(), detector.focusX, detector.focusY)
            return true
        }
    })

    init {
        setBackgroundColor(Color.rgb(238, 238, 234))
        isClickable = true
    }

    fun load(uri: Uri) {
        onLoadStatus?.invoke(Result.success("Načítavam výkres…"))
        Thread {
            runCatching { decode(uri) }
                .onSuccess { loaded ->
                    post {
                        bitmap?.takeIf { it !== loaded }?.recycle()
                        bitmap = loaded
                        if (project.underlayCenterX < 0.0 || project.underlayCenterY < 0.0) {
                            project.underlayCenterX = loaded.width / 2.0
                            project.underlayCenterY = loaded.height / 2.0
                            project.underlayZoom = 1.0
                        }
                        invalidate()
                        onTransformChanged?.invoke()
                        onLoadStatus?.invoke(Result.success("Výkres načítaný: ${loaded.width} × ${loaded.height} px"))
                    }
                }
                .onFailure { error -> post { onLoadStatus?.invoke(Result.failure(error)) } }
        }.start()
    }

    fun clearBitmap() {
        bitmap?.recycle()
        bitmap = null
        invalidate()
    }

    fun fitDocument() {
        bitmap?.let {
            project.underlayCenterX = it.width / 2.0
            project.underlayCenterY = it.height / 2.0
            project.underlayZoom = 1.0
            invalidate()
            onTransformChanged?.invoke()
        }
    }

    fun zoomBy(steps: Float) {
        val factor = Math.pow(1.25, steps.toDouble())
        zoomByFactor(factor, width / 2f, height / 2f)
    }

    fun projectToScreen(point: GeoPoint): PointF {
        val image = bitmap ?: return PointF(width / 2f, height / 2f)
        updateMatrices(image)
        val origin = GeoPoint(project.underlayOriginLat, project.underlayOriginLon)
        val local = Geometry.toLocal(point, origin)
        val values = floatArrayOf(
            (image.width / 2.0 + local.x / project.underlayMetersPerPixel).toFloat(),
            (image.height / 2.0 - local.y / project.underlayMetersPerPixel).toFloat()
        )
        imageMatrix.mapPoints(values)
        return PointF(values[0], values[1])
    }

    fun screenToProject(x: Float, y: Float): GeoPoint {
        val image = bitmap ?: return GeoPoint(project.underlayOriginLat, project.underlayOriginLon)
        updateMatrices(image)
        val values = floatArrayOf(x, y)
        inverseMatrix.mapPoints(values)
        val local = LocalPoint(
            (values[0] - image.width / 2.0) * project.underlayMetersPerPixel,
            (image.height / 2.0 - values[1]) * project.underlayMetersPerPixel
        )
        return Geometry.toGeo(local, GeoPoint(project.underlayOriginLat, project.underlayOriginLon))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val image = bitmap ?: return
        updateMatrices(image)
        canvas.drawBitmap(image, imageMatrix, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress && dragging) {
                val scale = currentScale().coerceAtLeast(0.0001f)
                project.underlayCenterX -= (event.x - lastX) / scale
                project.underlayCenterY -= (event.y - lastY) / scale
                lastX = event.x
                lastY = event.y
                invalidate()
                onTransformChanged?.invoke()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun zoomByFactor(rawFactor: Double, focusX: Float, focusY: Float) {
        val image = bitmap ?: return
        updateMatrices(image)
        val before = floatArrayOf(focusX, focusY)
        inverseMatrix.mapPoints(before)
        project.underlayZoom = (project.underlayZoom * rawFactor).coerceIn(0.08, 80.0)
        updateMatrices(image)
        val after = before.copyOf()
        imageMatrix.mapPoints(after)
        val scale = currentScale().coerceAtLeast(0.0001f)
        project.underlayCenterX += (after[0] - focusX) / scale
        project.underlayCenterY += (after[1] - focusY) / scale
        invalidate()
        onTransformChanged?.invoke()
    }

    private fun updateMatrices(image: Bitmap) {
        val scale = currentScale(image)
        imageMatrix.reset()
        imageMatrix.postTranslate(-project.underlayCenterX.toFloat(), -project.underlayCenterY.toFloat())
        imageMatrix.postScale(scale, scale)
        imageMatrix.postTranslate(width / 2f, height / 2f)
        imageMatrix.invert(inverseMatrix)
    }

    private fun currentScale(image: Bitmap? = bitmap): Float {
        image ?: return 1f
        if (width <= 0 || height <= 0) return 1f
        val fit = minOf(width.toFloat() / image.width, height.toFloat() / image.height)
        return (fit * project.underlayZoom).toFloat().coerceAtLeast(0.0001f)
    }

    private fun decode(uri: Uri): Bitmap {
        val mime = project.underlayMime.ifBlank { context.contentResolver.getType(uri).orEmpty() }
        return if (mime.equals("application/pdf", true) || uri.toString().lowercase().endsWith(".pdf")) {
            decodePdf(uri)
        } else {
            decodeImage(uri)
        }
    }

    private fun decodePdf(uri: Uri): Bitmap {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: error("PDF súbor sa nedá otvoriť.")
        descriptor.use { file ->
            PdfRenderer(file).use { renderer ->
                require(renderer.pageCount > 0) { "PDF neobsahuje žiadnu stranu." }
                renderer.openPage(0).use { page ->
                    val factor = (3000.0 / max(page.width, page.height)).coerceAtMost(2.0)
                    val targetWidth = max(1, (page.width * factor).toInt())
                    val targetHeight = max(1, (page.height * factor).toInt())
                    return Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888).also { result ->
                        result.eraseColor(Color.WHITE)
                        page.render(result, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    }
                }
            }
        }
    }

    private fun decodeImage(uri: Uri): Bitmap {
        if (Build.VERSION.SDK_INT >= 28) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            return ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                val longest = max(info.size.width, info.size.height)
                if (longest > 4096) {
                    val ratio = 4096.0 / longest
                    decoder.setTargetSize(
                        max(1, (info.size.width * ratio).toInt()),
                        max(1, (info.size.height * ratio).toInt())
                    )
                }
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "Obrázok sa nedá prečítať." }
        var sample = 1
        while (max(bounds.outWidth / sample, bounds.outHeight / sample) > 4096) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        } ?: error("Obrázok sa nedá otvoriť.")
    }
}
