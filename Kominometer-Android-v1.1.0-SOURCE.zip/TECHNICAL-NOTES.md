# Technické poznámky

## Prevzatá 3D koncepcia

Zo StrechoStav Sketch 3.7.2 boli prispôsobené princípy `Roof3DView` a `Roof3DRenderer`: `GLSurfaceView`, OpenGL ES 3, renderovanie na požiadanie, zachovanie EGL kontextu, rovnaké limity kamery, gestá, VBO, hĺbkový test a perspektívna matica. Strešný solver ani model strechy sa nekopírujú. `ChimneyMeshBuilder` generuje nový mesh výhradne z komínových uzlov.

## Geometrická autorita

`chimneyGeometry.vertices` a `claddingGeometry.vertices` sú jediným zdrojom pravdy. WebView ich používa na SVG pohľady a výpočty; natívny renderer dostane rovnaký JSON bez vedľajšej geometrie.

## Medzera

Každá rohová medzera je podpísaná kolmá vzdialenosť uzla muriva od roviny príslušnej vnútornej steny opláštenia. Záporné číslo sa zachová ako kolízia a nikdy sa neprevedie na zápornú izoláciu.
