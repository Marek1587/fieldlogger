const test = require("node:test");
const assert = require("node:assert/strict");
const S = require("../app/src/main/assets/solver.js");

function boxProject(bottom, top, clad) {
  const p=S.defaultProject();
  for(const k of ["FLB","RLB","FLT","RLT"]) p.chimneyGeometry.vertices[k].x=-(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FRB","RRB","FRT","RRT"]) p.chimneyGeometry.vertices[k].x=(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FLB","FRB","FLT","FRT"]) p.chimneyGeometry.vertices[k].y=-(k.endsWith("B")?bottom:top)/2;
  for(const k of ["RLB","RRB","RLT","RRT"]) p.chimneyGeometry.vertices[k].y=(k.endsWith("B")?bottom:top)/2;
  for(const k of ["FLB","RLB","FLT","RLT"]) p.claddingGeometry.vertices[k].x=-clad/2;
  for(const k of ["FRB","RRB","FRT","RRT"]) p.claddingGeometry.vertices[k].x=clad/2;
  for(const k of ["FLB","FRB","FLT","FRT"]) p.claddingGeometry.vertices[k].y=-clad/2;
  for(const k of ["RLB","RRB","RLT","RRT"]) p.claddingGeometry.vertices[k].y=clad/2;
  return p;
}
test("ideálny komín 500 v opláštení 600 má 50 mm",()=>{for(const g of Object.values(S.solveAllGaps(boxProject(500,500,600))))for(const v of Object.values(g))assert.ok(Math.abs(v-50)<1e-8)});
test("zbiehavý komín zachová dolnú a hornú medzeru",()=>{const g=S.solveAllGaps(boxProject(500,480,600));assert.equal(Math.round(g.front.LD),50);assert.equal(Math.round(g.front.LH),60)});
test("strešná väzba vytvorí rozdiel 200 mm",()=>{const p=S.defaultProject(),g=S.applyRoofLink(p.chimneyGeometry.vertices,200);assert.equal(g.RLB.z-g.FLB.z,200);assert.equal(S.faceDimension(g,"left","left"),1000);assert.equal(S.faceDimension(g,"left","right"),1200)});
test("optimal fit vyváži excentrický komín",()=>{const p=boxProject(500,500,600);Object.values(p.chimneyGeometry.vertices).forEach(v=>{v.x+=28;v.y-=17});const b=Object.values(S.solveAllGaps(p)).flatMap(Object.values),q=S.autoFit(p),a=Object.values(S.solveAllGaps(q)).flatMap(Object.values);assert.ok(Math.max(...a)-Math.min(...a)<Math.max(...b)-Math.min(...b));assert.ok(Math.abs(q.claddingGeometry.offsetX-28)<1)});
test("kolízia zostane zápornou medzerou a izolácia je KOLÍZIA",()=>{const p=boxProject(500,500,480),g=S.solveAllGaps(p);assert.ok(Object.values(g).flatMap(Object.values).some(v=>v<0));assert.equal(S.insulationPlan(g.front,p.insulationMaterial).status,"KOLÍZIA")});
test("spoločný uzol zmení prednú aj ľavú výšku",()=>{const p=S.defaultProject(),g=S.setFaceDimension(p.chimneyGeometry.vertices,"front","left",1100);assert.equal(S.faceDimension(g,"front","left"),1100);assert.equal(S.faceDimension(g,"left","right"),1100)});
test("20 mm doska pri medzere 15 až 25 mm je nevhodná",()=>{const p=S.defaultProject(),plan=S.insulationPlan({LD:15,PD:15,LH:25,PH:25},p.insulationMaterial);assert.equal(plan.status,"NEVHODNÉ");assert.equal(plan.total,20);assert.equal(plan.cornerStates.LD.state,"NADMERNE TLAČÍ");assert.equal(plan.cornerStates.LH.state,"NEDOLIEHA");assert.equal(plan.cornerStates.LH.clearance,5);assert.ok(Math.abs(plan.requiredMin-16.6666667)<1e-4);assert.ok(Math.abs(plan.requiredMax-27.7777778)<1e-4)});
test("kontrolu vydutia nemožno potvrdiť bez tlakovej krivky",()=>{const p=S.defaultProject(),plan={...S.insulationPlan({LD:18,PD:18,LH:18,PH:18},p.insulationMaterial),suitable:true,total:20};const check=S.panelCheck(p,"front",plan);assert.equal(check.status,"NEVYHODNOTENÉ");assert.match(check.reason,/tlaková krivka/)});
