(function (root) {
  "use strict";
  const FACES = ["front", "left", "rear", "right"];
  const FACE_LABELS = { front: "Predná", left: "Ľavá", rear: "Zadná", right: "Pravá" };
  const FACE_VERTICES = {
    front: ["FLB", "FRB", "FLT", "FRT"],
    left: ["RLB", "FLB", "RLT", "FLT"],
    rear: ["RRB", "RLB", "RRT", "RLT"],
    right: ["FRB", "RRB", "FRT", "RRT"]
  };

  function defaultProject() {
    return {
      version: 2,
      chimneyGeometry: {
        roofHeightDifference: 200, roofLinked: true, locks: [],
        vertices: {
          FLB:{x:-250,y:-250,z:0}, FRB:{x:250,y:-250,z:0}, RLB:{x:-250,y:250,z:200}, RRB:{x:250,y:250,z:200},
          FLT:{x:-240,y:-240,z:1200}, FRT:{x:240,y:-240,z:1200}, RLT:{x:-240,y:240,z:1200}, RRT:{x:240,y:240,z:1200}
        }
      },
      claddingGeometry: {
        offsetX:0, offsetY:0, offsetZ:0, folds:25, overlaps:30,
        sheetThickness:0.55, steelModulus:200000, maxAllowedBulge:2, freeSpanOverride:0,
        vertices: {
          FLB:{x:-300,y:-300,z:0}, FRB:{x:300,y:-300,z:0}, RLB:{x:-300,y:300,z:200}, RRB:{x:300,y:300,z:200},
          FLT:{x:-300,y:-300,z:1200}, FRT:{x:300,y:-300,z:1200}, RLT:{x:-300,y:300,z:1200}, RRT:{x:300,y:300,z:1200}
        }
      },
      insulationMaterial: {
        manufacturer:"Vlastný materiál", product:"Kamenná vata", thicknessOptions:[20,30,40,50,60],
        compressionMin:5, compressionTarget:10, compressionMax:20, reservePercent:12,
        frictionCoefficient:.35, pressureCurve:"", requiredContactPressure:0
      }
    };
  }
  const clone = x => JSON.parse(JSON.stringify(x));
  const sub = (a,b) => ({x:a.x-b.x,y:a.y-b.y,z:a.z-b.z});
  const cross = (a,b) => ({x:a.y*b.z-a.z*b.y,y:a.z*b.x-a.x*b.z,z:a.x*b.y-a.y*b.x});
  const dot = (a,b) => a.x*b.x+a.y*b.y+a.z*b.z;
  const norm = a => Math.hypot(a.x,a.y,a.z);
  const normalize = a => { const n=norm(a)||1; return {x:a.x/n,y:a.y/n,z:a.z/n}; };
  const avg = p => ({x:p.reduce((s,v)=>s+v.x,0)/p.length,y:p.reduce((s,v)=>s+v.y,0)/p.length,z:p.reduce((s,v)=>s+v.z,0)/p.length});

  function translatedCladding(project) {
    const c=project.claddingGeometry;
    return Object.fromEntries(Object.entries(c.vertices).map(([k,v])=>[k,{x:v.x+c.offsetX,y:v.y+c.offsetY,z:v.z+c.offsetZ}]));
  }
  function faceDimension(g,face,edge) {
    const [bl,br,tl,tr]=FACE_VERTICES[face];
    if(edge==="bottom") return face==="front"||face==="rear"?Math.abs(g[br].x-g[bl].x):Math.abs(g[br].y-g[bl].y);
    if(edge==="top") return face==="front"||face==="rear"?Math.abs(g[tr].x-g[tl].x):Math.abs(g[tr].y-g[tl].y);
    return edge==="left"?Math.abs(g[tl].z-g[bl].z):Math.abs(g[tr].z-g[br].z);
  }
  function setFaceDimension(g,face,edge,value) {
    const next=clone(g), [bl,br,tl,tr]=FACE_VERTICES[face];
    if(!Number.isFinite(value)||value<=0) return next;
    if(edge==="left"||edge==="right") { const b=edge==="left"?bl:br,t=edge==="left"?tl:tr; next[t].z=next[b].z+value; return next; }
    const a=edge==="bottom"?bl:tl,b=edge==="bottom"?br:tr,axis=face==="front"||face==="rear"?"x":"y";
    const mid=(next[a][axis]+next[b][axis])/2,sign=next[b][axis]>=next[a][axis]?1:-1;
    next[a][axis]=mid-sign*value/2; next[b][axis]=mid+sign*value/2; return next;
  }
  function applyRoofLink(g,difference) {
    const n=clone(g); n.FLB.z=0;n.FRB.z=0;n.RLB.z=difference;n.RRB.z=difference;
    const top=(n.FLT.z+n.FRT.z)/2;n.RLT.z=top;n.RRT.z=top;return n;
  }
  function gapsForFace(chimney,cladding,face) {
    const keys=FACE_VERTICES[face],cp=keys.map(k=>cladding[k]);let normal=normalize(cross(sub(cp[1],cp[0]),sub(cp[2],cp[0])));
    if(dot(normal,sub(avg(cp),avg(Object.values(cladding))))<0) normal={x:-normal.x,y:-normal.y,z:-normal.z};
    const v=keys.map(k=>-dot(normal,sub(chimney[k],cp[0])));return {LD:v[0],PD:v[1],LH:v[2],PH:v[3]};
  }
  function solveAllGaps(project) { const c=project.chimneyGeometry.vertices,o=translatedCladding(project);return Object.fromEntries(FACES.map(f=>[f,gapsForFace(c,o,f)])); }
  function gapStats(g) { const v=Object.values(g),min=Math.min(...v),max=Math.max(...v);return {min,max,average:v.reduce((s,x)=>s+x,0)/v.length,spread:max-min}; }
  function autoFit(project) {
    let best=clone(project),bestScore=Infinity,cx=project.claddingGeometry.offsetX,cy=project.claddingGeometry.offsetY,step=100;
    const score=p=>{const v=Object.values(solveAllGaps(p)).flatMap(Object.values),collision=v.filter(x=>x<0).reduce((s,x)=>s+x*x*1000,0);return collision+(Math.max(...v)-Math.min(...v))**2+Math.max(...v)*.01;};
    for(let round=0;round<14;round++){for(const dx of[-step,0,step])for(const dy of[-step,0,step]){const p=clone(project);p.claddingGeometry.offsetX=cx+dx;p.claddingGeometry.offsetY=cy+dy;const s=score(p);if(s<bestScore){bestScore=s;best=p;}}cx=best.claddingGeometry.offsetX;cy=best.claddingGeometry.offsetY;step/=2;}return best;
  }
  function combinations(options,maxLayers=3){const r=[];function walk(start,a){if(a.length)r.push(a);if(a.length===maxLayers)return;for(let i=start;i<options.length;i++)walk(i,a.concat(options[i]));}walk(0,[]);return r;}
  function insulationPlan(gaps,material){
    const stats=gapStats(gaps),target=stats.average/(1-material.compressionTarget/100);
    if(stats.min<0)return{layers:[],total:0,targetNominal:0,compressionMin:0,compressionMax:0,status:"KOLÍZIA",suitable:false,constantFeasible:false,baseLayer:0,supplements:{LD:0,PD:0,LH:0,PH:0},cornerStates:{},requiredNominal:{}};
    const opts=[...new Set(material.thicknessOptions.filter(n=>n>0))].sort((a,b)=>a-b);
    const candidates=combinations(opts).map(layers=>{const total=layers.reduce((s,n)=>s+n,0),comps=Object.values(gaps).map(g=>(total-g)/total*100),contact=Object.values(gaps).every(g=>total>=g),valid=contact&&Math.min(...comps)>=material.compressionMin&&Math.max(...comps)<=material.compressionMax;return{layers,total,comps,contact,valid,score:Math.abs(total-target)+layers.length*.1};});
    const validCandidate=candidates.filter(x=>x.valid).sort((a,b)=>a.score-b.score)[0];
    const c=validCandidate||candidates.sort((a,b)=>a.score-b.score)[0]||{layers:[],total:0,comps:[0],contact:false,valid:false};
    const requiredNominal=Object.fromEntries(Object.entries(gaps).map(([k,g])=>[k,g/(1-material.compressionTarget/100)]));
    const requiredValues=Object.values(requiredNominal),base=Math.min(...requiredValues);
    const supplements=Object.fromEntries(Object.entries(requiredNominal).map(([k,t])=>[k,Math.max(0,Math.round((t-base)*10)/10)]));
    const feasibleMin=Math.max(...Object.values(gaps).map(g=>g/(1-material.compressionMin/100)));
    const feasibleMax=Math.min(...Object.values(gaps).map(g=>g/(1-material.compressionMax/100)));
    const constantFeasible=feasibleMin<=feasibleMax;
    const cornerStates=Object.fromEntries(Object.entries(gaps).map(([k,g])=>{const compression=c.total>0?(c.total-g)/c.total*100:0;return[k,{gap:g,compression,clearance:Math.max(0,g-c.total),overCompression:Math.max(0,compression-material.compressionMax),state:c.total<g?"NEDOLIEHA":compression<material.compressionMin?"SLABÝ KONTAKT":compression>material.compressionMax?"NADMERNE TLAČÍ":"KONTAKT OK"}]}));
    return{layers:c.layers,total:c.total,targetNominal:target,compressionMin:Math.min(...c.comps),compressionMax:Math.max(...c.comps),status:c.valid?(constantFeasible?"OK":"POZOR"):"NEVHODNÉ",suitable:c.valid,constantFeasible,feasibleMin,feasibleMax,baseLayer:base,supplements,requiredNominal,requiredMin:Math.min(...requiredValues),requiredMax:Math.max(...requiredValues),cornerStates};
  }
  function parsePressureCurve(input){return String(input||"").split(",").map(x=>x.trim().split(":").map(Number)).filter(x=>x.length===2&&x.every(Number.isFinite)).sort((a,b)=>a[0]-b[0]);}
  function pressureAt(compression,curveText){const curve=parsePressureCurve(curveText);if(!curve.length||compression<curve[0][0]||compression>curve.at(-1)[0])return null;if(compression===curve[0][0])return curve[0][1];for(let i=1;i<curve.length;i++)if(compression<=curve[i][0]){const[a,p0]=curve[i-1],[b,p1]=curve[i];return p0+(compression-a)/(b-a)*(p1-p0)}return null;}
  function panelCheck(project,face,plan){
    const c=project.claddingGeometry,m=project.insulationMaterial,gaps=solveAllGaps(project)[face],height=(faceDimension(c.vertices,face,"left")+faceDimension(c.vertices,face,"right"))/2,span=c.freeSpanOverride>0?c.freeSpanOverride:height;
    if(plan.status==="KOLÍZIA")return{status:"KOLÍZIA",reason:"Najprv odstráňte geometrickú kolíziu."};
    if(!plan.suitable)return{status:"NEVYHODNOTENÉ",reason:"Navrhovaná rovná skladba nemá správny kontakt vo všetkých rohoch."};
    const pressures=Object.entries(gaps).map(([k,g])=>{const compression=(plan.total-g)/plan.total*100;return[k,pressureAt(compression,m.pressureCurve),compression]});
    if(pressures.some(x=>x[1]===null))return{status:"NEVYHODNOTENÉ",reason:"Chýba tlaková krivka výrobku pre celý vypočítaný rozsah stlačenia.",pressures};
    const maxPressure=Math.max(...pressures.map(x=>x[1])),minPressure=Math.min(...pressures.map(x=>x[1]));
    const t=c.sheetThickness,E=c.steelModulus,I=t**3/12,q=maxPressure/1000;
    const linearBulge=5*q*span**4/(384*E*I),smallDeflectionValid=linearBulge<=t;
    const contactOk=minPressure>=(m.requiredContactPressure||0);
    const bulgeOk=smallDeflectionValid&&linearBulge<=c.maxAllowedBulge;
    return{status:bulgeOk&&contactOk?"PREDbeŽNE OK":"RIZIKO VYDUTIA",reason:!smallDeflectionValid?"Lineárny výpočet prekročil rozsah malej deformácie; 0,55 mm plech potrebuje výstuhu alebo odborný nelineárny výpočet.":!bulgeOk?"Odhad priehybu prekračuje zadaný limit.":!contactOk?"Minimálny tlak je nižší než požadovaný tlak proti vibráciám.":"Kontaktný tlak aj priehyb sú v zadaných limitoch.",maxPressure,minPressure,linearBulge,smallDeflectionValid,contactOk,span};
  }
  function faceArea(g,face){const [bl,br,tl,tr]=FACE_VERTICES[face].map(k=>g[k]);const tri=(a,b,c)=>norm(cross(sub(b,a),sub(c,a)))/2;return(tri(bl,br,tl)+tri(br,tr,tl))/1e6;}
  const api={FACES,FACE_LABELS,FACE_VERTICES,defaultProject,clone,translatedCladding,faceDimension,setFaceDimension,applyRoofLink,gapsForFace,solveAllGaps,gapStats,autoFit,insulationPlan,parsePressureCurve,pressureAt,panelCheck,faceArea};
  root.KominSolver=api;if(typeof module!=="undefined"&&module.exports)module.exports=api;
})(typeof globalThis!=="undefined"?globalThis:this);
