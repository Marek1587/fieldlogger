package sk.kominometer.app

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Offline Android host podľa architektúry Geometria 2.2.0.
 * Technický 2D priestor beží v lokálnom WebView; 3D je natívny OpenGL ES renderer.
 */
class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var active3DView: Chimney3DView? = null
    private var showing3D = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BRAND_DARK
        window.navigationBarColor = BRAND_DARK
        webView = createWebView()
        setContentView(webView)
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html")
        else webView.restoreState(savedInstanceState)
    }

    private fun createWebView() = WebView(this).apply {
        setBackgroundColor(PAPER)
        overScrollMode = View.OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_DEFAULT
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        webChromeClient = WebChromeClient()
        webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.scheme !in setOf("file", "about")
        }
        addJavascriptInterface(KominometerBridge(), "Kominometer")
    }

    private fun show3D(json: String) {
        val scene = runCatching { ChimneyScene.fromJson(JSONObject(json)) }.getOrElse {
            toast("3D model sa nepodarilo pripraviť: ${it.message}")
            return
        }
        showing3D = true
        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(244, 247, 244)) }
        val model = Chimney3DView(this).apply {
            setScene(scene)
            contentDescription = "Interaktívny trojrozmerný model komína a opláštenia"
        }
        active3DView = model
        root.addView(model, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(7))
            background = rounded(BRAND_DARK, 0f)
            addView(compactButton("‹ Späť") { close3D() })
            addView(TextView(this@MainActivity).apply {
                text = "3D MODEL · KOMÍNOMETER"
                setTextColor(Color.WHITE)
                textSize = 16f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, dp(44), 1f))
            addView(compactButton("↻ Pohľad") { model.resetView() })
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58), Gravity.TOP))

        val minGap = scene.minimumGapMm()
        val maxGap = scene.maximumGapMm()
        root.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(Color.argb(232, 22, 43, 35), 10f, Color.rgb(92, 127, 105))
            addView(TextView(this@MainActivity).apply {
                text = if (minGap < 0) "KOLÍZIA · zásah ${formatMm(-minGap)} mm" else "MEDZERA ${formatMm(minGap)} – ${formatMm(maxGap)} mm"
                setTextColor(if (minGap < 0) Color.rgb(255, 166, 148) else Color.WHITE)
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
            })
            addView(TextView(this@MainActivity).apply {
                text = "1 prst: otočenie  ·  2 prsty: posun a zoom  ·  dvojklik: reset"
                setTextColor(Color.rgb(190, 205, 196))
                textSize = 9f
            })
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            setMargins(dp(12), 0, dp(12), dp(18))
        })
        setContentView(root)
        model.onResume()
    }

    private fun close3D() {
        active3DView?.onPause()
        active3DView = null
        showing3D = false
        setContentView(webView)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onResume() { super.onResume(); active3DView?.onResume() }
    override fun onPause() { active3DView?.onPause(); super.onPause() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            showing3D -> close3D()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        active3DView?.onPause()
        webView.removeJavascriptInterface("Kominometer")
        webView.stopLoading()
        webView.destroy()
        super.onDestroy()
    }

    inner class KominometerBridge {
        @JavascriptInterface fun open3D(projectJson: String) = runOnUiThread { show3D(projectJson) }

        @JavascriptInterface fun copyText(text: String) = runOnUiThread {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Komínometer – montážny plán", text))
            toast("Montážny plán bol skopírovaný.")
        }

        @JavascriptInterface fun shareProject(json: String) {
            runCatching {
                val directory = File(cacheDir, "shared").apply { mkdirs() }
                val file = File(directory, "kominometer-projekt.json").apply { writeText(json, Charsets.UTF_8) }
                val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                runOnUiThread {
                    startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                        type = "application/json"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        clipData = ClipData.newRawUri("Komínometer", uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }, "Zdieľať projekt"))
                }
            }.onFailure { runOnUiThread { toast("Projekt sa nepodarilo zdieľať.") } }
        }
    }

    private fun compactButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 11f
        background = rounded(Color.rgb(51, 103, 65), 8f, Color.rgb(117, 156, 126))
        setPadding(dp(9), 0, dp(9), 0)
        minWidth = 0
        minHeight = dp(38)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply { setMargins(0, 0, dp(7), 0) }
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp.roundToInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }
    private fun formatMm(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()

    companion object {
        private val BRAND_DARK = Color.rgb(22, 84, 38)
        private val PAPER = Color.rgb(244, 247, 244)
    }
}
