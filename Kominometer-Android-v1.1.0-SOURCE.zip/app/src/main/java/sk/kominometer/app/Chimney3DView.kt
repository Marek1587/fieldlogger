package sk.kominometer.app

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** OpenGL kamera a gestá sú prispôsobené z Roof3DView v StrechoStav Sketch 3.7.2. */
class Chimney3DView(context: Context) : GLSurfaceView(context) {
    private val sceneRenderer = Chimney3DRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                sceneRenderer.zoom = (sceneRenderer.zoom * detector.scaleFactor).coerceIn(0.45f, 3.2f)
                requestRender()
                return true
            }
        })
    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { resetView(); return true }
        })

    init {
        setEGLContextClientVersion(3)
        setPreserveEGLContextOnPause(true)
        setRenderer(sceneRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    internal fun setScene(scene: ChimneyScene) { sceneRenderer.setScene(scene); requestRender() }
    fun resetView() { sceneRenderer.resetView(); requestRender() }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x; lastY = event.y
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) {
                lastMidX = (event.getX(0) + event.getX(1)) / 2f
                lastMidY = (event.getY(0) + event.getY(1)) / 2f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val density = resources.displayMetrics.density.coerceAtLeast(1f)
                if (event.pointerCount >= 2) {
                    val midX = (event.getX(0) + event.getX(1)) / 2f
                    val midY = (event.getY(0) + event.getY(1)) / 2f
                    sceneRenderer.panX += (midX - lastMidX) / density * 0.008f
                    sceneRenderer.panY -= (midY - lastMidY) / density * 0.008f
                    lastMidX = midX; lastMidY = midY
                } else if (!scaleDetector.isInProgress) {
                    sceneRenderer.yawDegrees += (event.x - lastX) / density * 0.62f
                    sceneRenderer.pitchDegrees = (sceneRenderer.pitchDegrees + (event.y - lastY) / density * 0.62f).coerceIn(-82f, 82f)
                }
                lastX = event.x; lastY = event.y
                requestRender()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

internal data class SceneVec3(val x: Float, val y: Float, val z: Float) {
    operator fun plus(o: SceneVec3) = SceneVec3(x + o.x, y + o.y, z + o.z)
    operator fun minus(o: SceneVec3) = SceneVec3(x - o.x, y - o.y, z - o.z)
    operator fun times(s: Float) = SceneVec3(x * s, y * s, z * s)
    fun length() = sqrt(x * x + y * y + z * z)
    fun normalized(): SceneVec3 { val n = length().coerceAtLeast(1e-8f); return SceneVec3(x / n, y / n, z / n) }
    fun dot(o: SceneVec3) = x * o.x + y * o.y + z * o.z
    fun cross(o: SceneVec3) = SceneVec3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x)
}

internal data class ChimneyScene(
    val chimney: Map<String, SceneVec3>,
    val cladding: Map<String, SceneVec3>,
    val roofHeightDifference: Float
) {
    private val faceKeys = listOf(
        listOf("FLB", "FRB", "FLT", "FRT"),
        listOf("RLB", "FLB", "RLT", "FLT"),
        listOf("RRB", "RLB", "RRT", "RLT"),
        listOf("FRB", "RRB", "FRT", "RRT")
    )

    fun allGapsMm(): List<Double> = faceKeys.flatMap { keys ->
        val cp = keys.map { cladding.getValue(it) }
        var normal = (cp[1] - cp[0]).cross(cp[2] - cp[0]).normalized()
        val faceCenter = cp.reduce(SceneVec3::plus) * 0.25f
        val center = cladding.values.reduce(SceneVec3::plus) * (1f / cladding.size)
        if (normal.dot(faceCenter - center) < 0f) normal = normal * -1f
        keys.map { key -> (-normal.dot(chimney.getValue(key) - cp[0])).toDouble() }
    }
    fun minimumGapMm() = allGapsMm().minOrNull() ?: 0.0
    fun maximumGapMm() = allGapsMm().maxOrNull() ?: 0.0

    companion object {
        private val keys = listOf("FLB", "FRB", "RLB", "RRB", "FLT", "FRT", "RLT", "RRT")
        fun fromJson(root: JSONObject): ChimneyScene {
            fun readGeometry(path: String): Map<String, SceneVec3> {
                val vertices = root.getJSONObject(path).getJSONObject("vertices")
                return keys.associateWith { key ->
                    val p = vertices.getJSONObject(key)
                    SceneVec3(p.getDouble("x").toFloat(), p.getDouble("y").toFloat(), p.getDouble("z").toFloat())
                }
            }
            val chimneyBlock = root.getJSONObject("chimneyGeometry")
            val claddingBlock = root.getJSONObject("claddingGeometry")
            val rawCladding = readGeometry("claddingGeometry")
            val offset = SceneVec3(
                claddingBlock.optDouble("offsetX", 0.0).toFloat(),
                claddingBlock.optDouble("offsetY", 0.0).toFloat(),
                claddingBlock.optDouble("offsetZ", 0.0).toFloat()
            )
            return ChimneyScene(
                readGeometry("chimneyGeometry"),
                rawCladding.mapValues { it.value + offset },
                chimneyBlock.optDouble("roofHeightDifference", 200.0).toFloat()
            )
        }
    }
}

internal data class ChimneyMesh(
    val opaque: FloatArray,
    val opaqueNormals: FloatArray,
    val opaqueMaterials: FloatArray,
    val transparent: FloatArray,
    val transparentNormals: FloatArray,
    val edges: FloatArray
)

internal object ChimneyMeshBuilder {
    private val faces = listOf(
        listOf("FLB", "FRB", "FRT", "FLT"),
        listOf("RLB", "FLB", "FLT", "RLT"),
        listOf("RRB", "RLB", "RLT", "RRT"),
        listOf("FRB", "RRB", "RRT", "FRT"),
        listOf("FLT", "FRT", "RRT", "RLT")
    )

    fun build(scene: ChimneyScene): ChimneyMesh {
        val all = scene.chimney.values + scene.cladding.values
        val minX = all.minOf { it.x }; val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }; val maxY = all.maxOf { it.y }
        val minZ = min(all.minOf { it.z }, 0f); val maxZ = all.maxOf { it.z }
        val span = max(maxX - minX, max(maxY - minY, maxZ - minZ)).coerceAtLeast(1f)
        val scale = 2.45f / span
        val cx = (minX + maxX) / 2f; val cy = (minY + maxY) / 2f; val cz = (minZ + maxZ) / 2f
        fun map(p: SceneVec3) = SceneVec3((p.x - cx) * scale, (p.z - cz) * scale, (p.y - cy) * scale)
        val chimney = scene.chimney.mapValues { map(it.value) }
        val cladding = scene.cladding.mapValues { map(it.value) }
        val opaque = arrayListOf<Float>(); val opaqueNormals = arrayListOf<Float>(); val materials = arrayListOf<Float>()
        val transparent = arrayListOf<Float>(); val transparentNormals = arrayListOf<Float>(); val edges = arrayListOf<Float>()

        faces.forEach { keys ->
            val c = keys.map { chimney.getValue(it) }
            addQuad(opaque, opaqueNormals, materials, c[0], c[1], c[2], c[3], 0f)
            addQuadEdges(edges, c)
            val o = keys.map { cladding.getValue(it) }
            addQuad(transparent, transparentNormals, null, o[0], o[1], o[2], o[3], 1f)
            addQuadEdges(edges, o)
        }

        val roofMargin = span * 0.35f
        val rawRoof = listOf(
            SceneVec3(minX - roofMargin, minY - roofMargin, 0f),
            SceneVec3(maxX + roofMargin, minY - roofMargin, 0f),
            SceneVec3(maxX + roofMargin, maxY + roofMargin, scene.roofHeightDifference),
            SceneVec3(minX - roofMargin, maxY + roofMargin, scene.roofHeightDifference)
        ).map(::map)
        addQuad(opaque, opaqueNormals, materials, rawRoof[0], rawRoof[1], rawRoof[2], rawRoof[3], 2f)
        addQuadEdges(edges, rawRoof)
        return ChimneyMesh(opaque.toFloatArray(), opaqueNormals.toFloatArray(), materials.toFloatArray(), transparent.toFloatArray(), transparentNormals.toFloatArray(), edges.toFloatArray())
    }

    private fun addQuad(
        vertices: MutableList<Float>, normals: MutableList<Float>, materials: MutableList<Float>?,
        a: SceneVec3, b: SceneVec3, c: SceneVec3, d: SceneVec3, material: Float
    ) {
        addTriangle(vertices, normals, materials, a, b, c, material)
        addTriangle(vertices, normals, materials, a, c, d, material)
    }

    private fun addTriangle(
        vertices: MutableList<Float>, normals: MutableList<Float>, materials: MutableList<Float>?,
        a: SceneVec3, b: SceneVec3, c: SceneVec3, material: Float
    ) {
        val normal = (b - a).cross(c - a).normalized()
        listOf(a, b, c).forEach { p ->
            vertices += p.x; vertices += p.y; vertices += p.z
            normals += normal.x; normals += normal.y; normals += normal.z
            materials?.add(material)
        }
    }

    private fun addQuadEdges(edges: MutableList<Float>, p: List<SceneVec3>) {
        p.indices.forEach { i -> addLine(edges, p[i], p[(i + 1) % p.size]) }
    }
    private fun addLine(out: MutableList<Float>, a: SceneVec3, b: SceneVec3) {
        out += a.x; out += a.y; out += a.z; out += b.x; out += b.y; out += b.z
    }
}

private class Chimney3DRenderer : GLSurfaceView.Renderer {
    @Volatile private var pendingMesh = ChimneyMesh(FloatArray(0), FloatArray(0), FloatArray(0), FloatArray(0), FloatArray(0), FloatArray(0))
    @Volatile var yawDegrees = -34f
    @Volatile var pitchDegrees = 28f
    @Volatile var zoom = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f

    private var width = 1; private var height = 1
    private var surfaceProgram = 0; private var edgeProgram = 0
    private var opaqueVbo = 0; private var transparentVbo = 0; private var edgeVbo = 0
    private var opaqueCount = 0; private var transparentCount = 0; private var edgeCount = 0
    private var uploaded: ChimneyMesh? = null

    fun setScene(scene: ChimneyScene) { pendingMesh = ChimneyMeshBuilder.build(scene) }
    fun resetView() { yawDegrees = -34f; pitchDegrees = 28f; zoom = 1f; panX = 0f; panY = 0f }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.957f, 0.969f, 0.957f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        surfaceProgram = createProgram(SURFACE_VERTEX, SURFACE_FRAGMENT)
        edgeProgram = createProgram(EDGE_VERTEX, EDGE_FRAGMENT)
        val buffers = IntArray(3); GLES30.glGenBuffers(3, buffers, 0)
        opaqueVbo = buffers[0]; transparentVbo = buffers[1]; edgeVbo = buffers[2]
        uploaded = null
    }

    override fun onSurfaceChanged(gl: GL10?, widthValue: Int, heightValue: Int) {
        width = max(1, widthValue); height = max(1, heightValue)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (opaqueCount == 0) return
        val model = FloatArray(16); val mvp = buildMvp(model)
        drawSurface(opaqueVbo, opaqueCount, model, mvp, transparent = false)
        drawSurface(transparentVbo, transparentCount, model, mvp, transparent = true)
        drawEdges(mvp)
    }

    private fun buildMvp(model: FloatArray): FloatArray {
        val view = FloatArray(16); val projection = FloatArray(16); val vp = FloatArray(16); val mvp = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, zoom, zoom, zoom)
        Matrix.translateM(model, 0, panX, panY, 0f)
        Matrix.setLookAtM(view, 0, 0f, 0.35f, 5.2f, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projection, 0, 34f, width.toFloat() / height.coerceAtLeast(1), 0.1f, 20f)
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        return mvp
    }

    private fun uploadIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploaded) return
        fun interleave(points: FloatArray, normals: FloatArray, materials: FloatArray?, defaultMaterial: Float): FloatArray {
            val count = points.size / 3; val result = FloatArray(count * 7)
            var out = 0
            for (i in 0 until count) {
                result[out++] = points[i * 3]; result[out++] = points[i * 3 + 1]; result[out++] = points[i * 3 + 2]
                result[out++] = normals[i * 3]; result[out++] = normals[i * 3 + 1]; result[out++] = normals[i * 3 + 2]
                result[out++] = materials?.getOrElse(i) { defaultMaterial } ?: defaultMaterial
            }
            return result
        }
        val opaqueData = interleave(mesh.opaque, mesh.opaqueNormals, mesh.opaqueMaterials, 0f)
        val transparentData = interleave(mesh.transparent, mesh.transparentNormals, null, 1f)
        upload(opaqueVbo, opaqueData); upload(transparentVbo, transparentData); upload(edgeVbo, mesh.edges)
        opaqueCount = mesh.opaque.size / 3; transparentCount = mesh.transparent.size / 3; edgeCount = mesh.edges.size / 3
        uploaded = mesh
    }

    private fun upload(vbo: Int, values: FloatArray) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, values.size * 4, values.nativeBuffer(), GLES30.GL_STATIC_DRAW)
    }

    private fun drawSurface(vbo: Int, count: Int, model: FloatArray, mvp: FloatArray, transparent: Boolean) {
        if (count == 0) return
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uModel"), 1, false, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uLight"), -0.42f, 0.72f, 0.86f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        val material = GLES30.glGetAttribLocation(surfaceProgram, "aMaterial")
        GLES30.glEnableVertexAttribArray(position); GLES30.glEnableVertexAttribArray(normal); GLES30.glEnableVertexAttribArray(material)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 28, 0)
        GLES30.glVertexAttribPointer(normal, 3, GLES30.GL_FLOAT, false, 28, 12)
        GLES30.glVertexAttribPointer(material, 1, GLES30.GL_FLOAT, false, 28, 24)
        if (transparent) {
            GLES30.glEnable(GLES30.GL_BLEND)
            GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
            GLES30.glDepthMask(false)
        }
        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
        if (transparent) { GLES30.glDepthMask(true); GLES30.glDisable(GLES30.GL_BLEND) }
        GLES30.glDisableVertexAttribArray(position); GLES30.glDisableVertexAttribArray(normal); GLES30.glDisableVertexAttribArray(material)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(edgeProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(edgeProgram, "uColor"), 0.055f, 0.10f, 0.07f, 0.96f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glLineWidth(1.5f)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeCount)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertex); val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragment)
        val program = GLES30.glCreateProgram(); GLES30.glAttachShader(program, vs); GLES30.glAttachShader(program, fs); GLES30.glLinkProgram(program)
        val status = IntArray(1); GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL program: ${GLES30.glGetProgramInfoLog(program)}" }
        GLES30.glDeleteShader(vs); GLES30.glDeleteShader(fs)
        return program
    }
    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type); GLES30.glShaderSource(shader, source); GLES30.glCompileShader(shader)
        val status = IntArray(1); GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL shader: ${GLES30.glGetShaderInfoLog(shader)}" }
        return shader
    }

    companion object {
        private const val SURFACE_VERTEX = """#version 300 es
            uniform mat4 uModel; uniform mat4 uMvp;
            in vec3 aPosition; in vec3 aNormal; in float aMaterial;
            out vec3 vNormal; out float vMaterial;
            void main(){ gl_Position=uMvp*vec4(aPosition,1.0); vNormal=mat3(uModel)*aNormal; vMaterial=aMaterial; }
        """
        private const val SURFACE_FRAGMENT = """#version 300 es
            precision mediump float; uniform vec3 uLight;
            in vec3 vNormal; in float vMaterial; out vec4 outColor;
            void main(){
                float light=0.58+0.42*abs(dot(normalize(vNormal),normalize(uLight)));
                vec3 color=vMaterial<0.5?vec3(0.56,0.50,0.40):(vMaterial<1.5?vec3(0.24,0.57,0.43):vec3(0.55,0.59,0.56));
                float alpha=vMaterial<1.5&&vMaterial>0.5?0.30:1.0;
                outColor=vec4(color*light,alpha);
            }
        """
        private const val EDGE_VERTEX = """#version 300 es
            uniform mat4 uMvp; in vec3 aPosition; void main(){ gl_Position=uMvp*vec4(aPosition,1.0); }
        """
        private const val EDGE_FRAGMENT = """#version 300 es
            precision mediump float; uniform vec4 uColor; out vec4 outColor; void main(){ outColor=uColor; }
        """
    }
}

private fun FloatArray.nativeBuffer(): FloatBuffer =
    ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(this@nativeBuffer); position(0) }
