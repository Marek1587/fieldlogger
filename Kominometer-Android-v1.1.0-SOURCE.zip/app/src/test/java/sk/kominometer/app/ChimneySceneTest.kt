package sk.kominometer.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChimneySceneTest {
    private fun scene(cladding: Int = 600): ChimneyScene {
        val vertices = listOf("FLB","FRB","RLB","RRB","FLT","FRT","RLT","RRT")
        fun geometry(size: Int): JSONObject {
            val out=JSONObject()
            vertices.forEach { key ->
                val right=key.startsWith("FR")||key.startsWith("RR")
                val rear=key.startsWith("RL")||key.startsWith("RR")
                val top=key.endsWith("T")
                out.put(key,JSONObject().put("x",if(right)size/2 else -size/2).put("y",if(rear)size/2 else -size/2).put("z",if(top)1200 else if(rear)200 else 0))
            }
            return out
        }
        return ChimneyScene.fromJson(JSONObject()
            .put("chimneyGeometry",JSONObject().put("vertices",geometry(500)).put("roofHeightDifference",200))
            .put("claddingGeometry",JSONObject().put("vertices",geometry(cladding)).put("offsetX",0).put("offsetY",0).put("offsetZ",0)))
    }
    @Test fun idealSceneHasFiftyMillimetreGap(){val s=scene();assertEquals(50.0,s.minimumGapMm(),1e-5);assertEquals(50.0,s.maximumGapMm(),1e-5)}
    @Test fun collisionIsPreserved(){assertTrue(scene(480).minimumGapMm()<0.0)}
    @Test fun meshContainsOpaqueTransparentAndEdgeGeometry(){val m=ChimneyMeshBuilder.build(scene());assertTrue(m.opaque.isNotEmpty());assertTrue(m.transparent.isNotEmpty());assertTrue(m.edges.isNotEmpty())}
}
