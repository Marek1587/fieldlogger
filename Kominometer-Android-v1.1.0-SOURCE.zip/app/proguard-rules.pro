# Aplikácia nepoužíva reflexívne frameworky. Pravidlá sú pripravené pre budúce minifikovanie.
