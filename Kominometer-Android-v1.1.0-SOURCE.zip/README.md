# Komínometer Android 1.1.0

Kompletná offline Android aplikácia na zameranie komína, kontrolu hotového plechového opláštenia a návrh skladby kamennej vaty.

## Architektúra

- natívny Kotlin host podľa vzoru Geometria 2.2.0,
- lokálny WebView pracovný priestor bez internetu,
- jeden model ôsmich 3D uzlov pre všetky štyri technické pohľady,
- natívny OpenGL ES 3.0 renderer prispôsobený z `Roof3DView` aplikácie StrechoStav Sketch 3.7.2,
- hĺbkový buffer, VBO, perspektívna kamera, rotácia jedným prstom, posun dvoma prstami, pinch zoom a reset dvojklikom,
- priehľadné opláštenie, murivo a šikmá strešná rovina z rovnakých dát ako solver,
- projekt sa automaticky ukladá lokálne a možno ho zdieľať ako JSON.
- výsledok osobitne označuje nedoliehanie, správny kontakt a nadmerné stlačenie,
- 20 mm kandidát sa nikdy neoznačí ako vhodný, ak miestami necháva dutinu alebo prekračuje povolené stlačenie,
- konzervatívna kontrola voľného poľa plechu 0,55 mm vyžaduje reálnu tlakovú krivku výrobku.

## Zostavenie

Vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2.

```text
node --test tests/*.test.js
gradle :app:testDebugUnitTest :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

Zdrojový ZIP má Android projekt priamo v koreňovej úrovni a používa POSIX oddeľovače
ciest. Je preto kompatibilný s priloženým GitHub Actions workflow na Ubuntu.

Distribuovaný zdrojový ZIP zámerne neobsahuje súkromný podpisový kľúč. Bez súboru
`app/kominometer-release-key.jks` Gradle vytvorí nepodpísaný release; vlastník aplikácie
si má vytvoriť a bezpečne archivovať vlastný kľúč. Priložené hotové APK je podpísané.

## Bezpečnostné obmedzenie

Výpočet tlaku a trenia kamennej vaty je iba montážny údaj. Nenahrádza statické, požiarne ani mechanické posúdenie opláštenia.
