package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

data class Roof3DPreparationResult(
    val topology: RoofTopology,
    val graph: RoofGraph,
    val planeSolution: RoofPlaneSolution,
    val topologyWasAdjusted: Boolean,
    val planeWasApproximated: Boolean
)

/** Single preparation path shared by live 3D, bitmap/PDF and quantities. */
object Roof3DPreparation {
    private data class TopologyQuality(
        val coverage: Double,
        val faceCount: Int,
        val unattachedDividerCount: Int
    )

    private fun faceCoverage(topology: RoofTopology): Double {
        val ordered = RoofTopologyMigration.orderedBoundary(topology)?.first ?: return 0.0
        val nodes = topology.nodes.associateBy { it.id }
        val boundary = ordered.mapNotNull(nodes::get)
        if (boundary.size < 3) return 0.0
        val boundaryArea = abs(boundary.indices.sumOf { index ->
            val a = boundary[index]
            val b = boundary[(index + 1) % boundary.size]
            a.x * b.y - b.x * a.y
        } / 2.0)
        if (boundaryArea <= 1e-9) return 0.0
        return RoofTopologySolver.extractFaces(topology).sumOf { abs(it.signedAreaM2) } / boundaryArea
    }

    /**
     * A closed footprint by itself always reports 100 % area coverage, even when all
     * drawn roof lines are dangling bridges inside that face.  Such a graph is not a
     * roof subdivision.  Every structural divider must bound two distinct roof faces.
     */
    private fun topologyQuality(topology: RoofTopology): TopologyQuality {
        val faces = RoofTopologySolver.extractFaces(topology)
        val dividerTypes = setOf(LineType.RIDGE, LineType.HIP, LineType.VALLEY)
        val unattached = topology.edges.count { edge ->
            !edge.boundary && edge.type in dividerTypes &&
                faces.count { edge.id in it.edgeIds } < 2
        }
        return TopologyQuality(faceCoverage(topology), faces.size, unattached)
    }

    fun prepare(project: RoofProject): Roof3DPreparationResult {
        val base = project.roofGraph?.toTopology()
            ?: project.roofTopology
            ?: RoofTopologyMigration.fromLegacyProject(project)

        // First perform the same bounded, topology-preserving cleanup offered
        // by card 2. This may merge existing near-coincident endpoints but can
        // never add a node or an edge.
        val conservative = RoofTopologySolver.solveInternal(base).proposed

        // Keep the derived 3D/PDF/quantity graph on the same physical roof-tract axis
        // as the outline correction. A near-symmetric collinear gable subdivision may
        // move by at most 300 mm; recess corners and deliberately asymmetric footprints
        // are never regularized by this pass.
        val tractPrepared = RoofTractSymmetrySolver.solve(conservative).topology
        var prepared = tractPrepared

        // An empty OR only partly subdivided footprint may use the derived topology-building
        // pass. Merely finding one or two closed cycles is not sufficient for an L/K roof: all
        // bounded faces together must cover the whole building footprint. This pass changes the
        // derived 3D topology only and caps XY movement at 10% of the measured edge scale.
        val conservativeQuality = topologyQuality(prepared)
        if (conservativeQuality.coverage < 0.995 || conservativeQuality.unattachedDividerCount > 0) {
            val nodeById = prepared.nodes.associateBy { it.id }
            val lengths = prepared.edges.mapNotNull { edge ->
                val a = nodeById[edge.startNodeId] ?: return@mapNotNull null
                val b = nodeById[edge.endNodeId] ?: return@mapNotNull null
                hypot(b.x - a.x, b.y - a.y).takeIf { it > 1e-6 }
            }.sorted()
            val referenceLength = lengths.getOrNull(lengths.size / 2) ?: 1.0
            val rebuilt = RoofTopologySolver.solve(
                prepared,
                RoofSolverConfig(
                    regularizeAngles = true,
                    maximumRegularizationDisplacementM = (referenceLength * 0.10).coerceIn(0.05, 4.0)
                )
            ).proposed
            val rebuiltQuality = topologyQuality(rebuilt)
            val hasBetterCoverage = rebuiltQuality.coverage > conservativeQuality.coverage + 1e-6
            val hasBetterDividerIncidence =
                rebuiltQuality.unattachedDividerCount < conservativeQuality.unattachedDividerCount
            val hasMoreCompleteSubdivision =
                rebuiltQuality.unattachedDividerCount == 0 &&
                    rebuiltQuality.coverage >= conservativeQuality.coverage - 1e-6 &&
                    rebuiltQuality.faceCount > conservativeQuality.faceCount
            if (hasBetterCoverage || hasBetterDividerIncidence || hasMoreCompleteSubdivision) {
                prepared = rebuilt
            }
        }

        val graph = RoofGraphFactory.fromTopology(prepared, project.roofGraph)
        val flatRoofMode = project.shape == RoofShape.FLAT || graph.edges.values.any {
            it.boundary && it.semanticRole == EdgeSemantic.ATTIC
        }
        val exact = RoofPlaneSolver.solve(
            graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
        )
        val planes = if (exact.hasBlockingIssues) {
            RoofPlaneSolver.solveForRendering(
                graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
            )
        } else exact
        return Roof3DPreparationResult(
            topology = prepared,
            graph = planes.graph,
            planeSolution = planes,
            topologyWasAdjusted = prepared != base,
            planeWasApproximated = planes.issues.any { it.code == "APPROXIMATED_HARD_CONSTRAINTS" }
        )
    }
}
