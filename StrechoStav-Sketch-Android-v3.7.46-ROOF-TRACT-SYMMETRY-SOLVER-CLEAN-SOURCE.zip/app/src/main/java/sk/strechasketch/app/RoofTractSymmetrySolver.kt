package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Bounded plan correction for a ridge crossing a straight gable side.
 *
 * Orthophoto tracing often leaves the two collinear halves of one physical gable a
 * few centimetres different. The connecting ridge then follows those noisy split
 * points and the complete roof tract becomes skewed. This solver recognizes only a
 * real straight subdivision (never a corner) and centers it between the two physical
 * corners when each half needs at most [MAX_HALF_LENGTH_CORRECTION_M] correction.
 * Recess corners remain untouched; the roof plane can consequently continue across
 * them without moving the wall footprint.
 */
internal object RoofTractSymmetrySolver {
    data class Result(
        val topology: RoofTopology,
        val movements: List<NodeMovement>,
        val centeredRidgeContacts: Int
    )

    const val MAX_HALF_LENGTH_CORRECTION_M = 0.30
    private const val ATTACHMENT_TOLERANCE_M = 0.35
    private const val STRAIGHT_TOLERANCE_DEG = 3.0
    private const val EPSILON = 1e-7

    fun solve(input: RoofTopology): Result {
        val ordered = RoofTopologyMigration.orderedBoundary(input)
            ?: return Result(copyOf(input), emptyList(), 0)
        val boundaryIds = ordered.first
        if (boundaryIds.size < 4) return Result(copyOf(input), emptyList(), 0)

        val nodes = input.nodes.associateBy { it.id }.toMutableMap()
        val boundarySet = boundaryIds.toSet()
        val ridgeEndpoints = input.edges.asSequence()
            .filter { !it.boundary && !it.locked && it.type == LineType.RIDGE }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
            .distinct()
            .mapNotNull(nodes::get)
            .filterNot { it.locked }
            .toList()
        if (ridgeEndpoints.isEmpty()) return Result(copyOf(input), emptyList(), 0)

        fun boundaryNode(index: Int): TopologyNode =
            requireNotNull(nodes[boundaryIds[(index + boundaryIds.size) % boundaryIds.size]])

        fun isStraight(index: Int): Boolean {
            val previous = boundaryNode(index - 1)
            val center = boundaryNode(index)
            val next = boundaryNode(index + 1)
            val inX = center.x - previous.x
            val inY = center.y - previous.y
            val outX = next.x - center.x
            val outY = next.y - center.y
            val inLength = hypot(inX, inY)
            val outLength = hypot(outX, outY)
            if (inLength <= EPSILON || outLength <= EPSILON) return false
            val cross = abs(inX * outY - inY * outX) / (inLength * outLength)
            val dot = (inX * outX + inY * outY) / (inLength * outLength)
            return cross <= kotlin.math.sin(Math.toRadians(STRAIGHT_TOLERANCE_DEG)) && dot > 0.0
        }

        fun previousCorner(index: Int): TopologyNode {
            var current = index - 1
            repeat(boundaryIds.size) {
                if (!isStraight(current)) return boundaryNode(current)
                current--
            }
            return boundaryNode(index - 1)
        }

        fun nextCorner(index: Int): TopologyNode {
            var current = index + 1
            repeat(boundaryIds.size) {
                if (!isStraight(current)) return boundaryNode(current)
                current++
            }
            return boundaryNode(index + 1)
        }

        val movements = mutableListOf<NodeMovement>()
        val processedBoundaryIds = mutableSetOf<String>()
        var centeredContacts = 0
        boundaryIds.indices.filter(::isStraight).forEach { index ->
            val split = boundaryNode(index)
            if (split.locked || split.id in processedBoundaryIds) return@forEach
            val attachedRidges = ridgeEndpoints.filter { endpoint ->
                endpoint.id == split.id || distance(endpoint, split) <= ATTACHMENT_TOLERANCE_M
            }
            if (attachedRidges.isEmpty()) return@forEach

            val sideStart = previousCorner(index)
            val sideEnd = nextCorner(index)
            val targetX = (sideStart.x + sideEnd.x) / 2.0
            val targetY = (sideStart.y + sideEnd.y) / 2.0
            val correction = hypot(targetX - split.x, targetY - split.y)
            val firstHalf = distance(sideStart, split)
            val secondHalf = distance(split, sideEnd)
            if (correction > MAX_HALF_LENGTH_CORRECTION_M + EPSILON ||
                abs(firstHalf - secondHalf) > 2.0 * MAX_HALF_LENGTH_CORRECTION_M + EPSILON
            ) return@forEach

            val idsToMove = buildSet {
                add(split.id)
                attachedRidges.forEach { add(it.id) }
                // Keep every already magnetized internal endpoint on the same real junction.
                input.edges.asSequence().filterNot { it.boundary }.forEach { edge ->
                    sequenceOf(edge.startNodeId, edge.endNodeId).forEach { endpointId ->
                        val endpoint = nodes[endpointId] ?: return@forEach
                        if (!endpoint.locked && distance(endpoint, split) <= ATTACHMENT_TOLERANCE_M) add(endpointId)
                    }
                }
            }
            idsToMove.sorted().forEach { nodeId ->
                val old = nodes[nodeId] ?: return@forEach
                if (hypot(targetX - old.x, targetY - old.y) <= EPSILON) return@forEach
                nodes[nodeId] = old.copy(x = targetX, y = targetY)
                movements += NodeMovement(
                    nodeId, nodeId, old.x, old.y, targetX, targetY, "CENTER_RIDGE_IN_ROOF_TRACT"
                )
            }
            processedBoundaryIds += split.id
            centeredContacts += attachedRidges.size
        }

        val proposed = input.copy(nodes = input.nodes.map { nodes.getValue(it.id) })
        return Result(proposed, movements, centeredContacts)
    }

    private fun distance(a: TopologyNode, b: TopologyNode): Double = hypot(a.x - b.x, a.y - b.y)

    private fun copyOf(topology: RoofTopology): RoofTopology = topology.copy(
        nodes = topology.nodes.map(TopologyNode::copy),
        edges = topology.edges.map(TopologyEdge::copy)
    )
}
