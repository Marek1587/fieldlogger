package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofGeometryEngineRegressionTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun node(
        id: String,
        x: Double,
        y: Double,
        type: TopologyNodeType = TopologyNodeType.LINE_ENDPOINT,
        locked: Boolean = false
    ) = TopologyNode(id, x, y, type, locked)

    private fun edge(
        id: String,
        start: String,
        end: String,
        type: LineType = LineType.EAVE,
        boundary: Boolean = false,
        locked: Boolean = false
    ) = TopologyEdge(
        id = id,
        startNodeId = start,
        endNodeId = end,
        type = type,
        locked = locked,
        boundary = boundary
    )

    private fun topology(
        nodes: List<TopologyNode>,
        edges: List<TopologyEdge>,
        rotationDeg: Double = 0.0
    ) = RoofTopology(
        origin = origin,
        nodes = nodes,
        edges = edges,
        gridRotationDeg = rotationDeg
    )

    private fun simpleSquare(
        extraNodes: List<TopologyNode> = emptyList(),
        extraEdges: List<TopologyEdge> = emptyList()
    ): RoofTopology = topology(
        nodes = listOf(
            node("corner-0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            node("corner-1", 4.0, 0.0, TopologyNodeType.FOOTPRINT),
            node("corner-2", 4.0, 4.0, TopologyNodeType.FOOTPRINT),
            node("corner-3", 0.0, 4.0, TopologyNodeType.FOOTPRINT)
        ) + extraNodes,
        edges = listOf(
            edge("boundary-0", "corner-0", "corner-1", boundary = true),
            edge("boundary-1", "corner-1", "corner-2", boundary = true),
            edge("boundary-2", "corner-2", "corner-3", boundary = true),
            edge("boundary-3", "corner-3", "corner-0", boundary = true)
        ) + extraEdges
    )

    /** Two full internal lines cross at (2, 2), so both authored edges must be split in two. */
    private fun crossedSquare(): RoofTopology = topology(
        nodes = listOf(
            node("p0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            node("p1", 2.0, 0.0, TopologyNodeType.FOOTPRINT),
            node("p2", 4.0, 0.0, TopologyNodeType.FOOTPRINT),
            node("p3", 4.0, 2.0, TopologyNodeType.FOOTPRINT),
            node("p4", 4.0, 4.0, TopologyNodeType.FOOTPRINT),
            node("p5", 2.0, 4.0, TopologyNodeType.FOOTPRINT),
            node("p6", 0.0, 4.0, TopologyNodeType.FOOTPRINT),
            node("p7", 0.0, 2.0, TopologyNodeType.FOOTPRINT)
        ),
        edges = listOf(
            edge("b0", "p0", "p1", boundary = true),
            edge("b1", "p1", "p2", boundary = true),
            edge("b2", "p2", "p3", boundary = true),
            edge("b3", "p3", "p4", boundary = true),
            edge("b4", "p4", "p5", boundary = true),
            edge("b5", "p5", "p6", boundary = true),
            edge("b6", "p6", "p7", boundary = true),
            edge("b7", "p7", "p0", boundary = true),
            edge("horizontal", "p7", "p3", LineType.RIDGE),
            edge("vertical", "p1", "p5", LineType.VALLEY)
        )
    )

    private fun assertValid(result: RoofGeometryResult) {
        assertTrue(
            result.issues.joinToString { "${it.code}: ${it.message}" },
            result.isValid
        )
        assertNotNull(result.subdivision)
        assertNotNull(result.graph)
    }

    @Test
    fun midEdgeCrossingSplitsBothEdgesAndKeepsCompleteProvenance() {
        val result = DefaultRoofGeometryEngine.canonicalize(crossedSquare())
        assertValid(result)

        val subdivision = result.subdivision!!
        val junction = subdivision.vertices.values.single { vertex ->
            vertex.sourceNodeIds.isEmpty() &&
                abs(vertex.x - 2.0) < 1e-6 && abs(vertex.y - 2.0) < 1e-6
        }
        assertEquals(4, subdivision.edges.values.count { edge ->
            junction.id == edge.startVertexId || junction.id == edge.endVertexId
        })

        listOf("horizontal", "vertical").forEach { sourceId ->
            val children = result.mappings.authoredEdgeToSolvedSegments.getValue(sourceId)
            assertEquals(sourceId, 2, children.size)
            children.forEach { childId ->
                val child = subdivision.edges.getValue(childId)
                assertEquals(childId, setOf(sourceId), child.sourceEdgeIds)
            }
        }
        assertEquals(1, result.statistics.createdIntersections)
        assertEquals(4, result.graph!!.faces.size)
    }

    @Test
    fun nearbyCrossingsAndCloseAuthoredPointsRemainPhysicallyDistinct() {
        val source = simpleSquare(
            extraNodes = listOf(
                node("bottom-a", 1.0, 0.0),
                node("bottom-b", 1.01, 0.0),
                node("top-shared", 3.0, 4.0),
                node("left-mid", 0.0, 2.0),
                node("right-mid", 4.0, 2.0)
            ),
            extraEdges = listOf(
                edge("diagonal-a", "bottom-a", "top-shared", LineType.HIP),
                edge("diagonal-b", "bottom-b", "top-shared", LineType.HIP),
                edge("cross-line", "left-mid", "right-mid", LineType.RIDGE)
            )
        )

        val result = DefaultRoofGeometryEngine.canonicalize(source)
        assertValid(result)
        val subdivision = result.subdivision!!

        val bottomA = result.mappings.authoredNodeToSolvedNode.getValue("bottom-a")
        val bottomB = result.mappings.authoredNodeToSolvedNode.getValue("bottom-b")
        assertNotEquals(bottomA, bottomB)
        val firstBottom = subdivision.vertices.getValue(bottomA)
        val secondBottom = subdivision.vertices.getValue(bottomB)
        assertTrue(hypot(firstBottom.x - secondBottom.x, firstBottom.y - secondBottom.y) > 0.009)

        val crossings = subdivision.vertices.values.filter { vertex ->
            vertex.sourceNodeIds.isEmpty() && abs(vertex.y - 2.0) < 2e-6
        }.sortedBy { it.x }
        assertEquals(2, crossings.size)
        assertNotEquals(crossings[0].id, crossings[1].id)
        assertEquals(0.005, crossings[1].x - crossings[0].x, 2e-6)
    }

    @Test
    fun coincidentAuthoredEdgesAreRejectedInsteadOfSilentlyCoalesced() {
        val source = simpleSquare(
            extraEdges = listOf(
                edge("ridge-a", "corner-0", "corner-2", LineType.RIDGE),
                edge("ridge-b", "corner-0", "corner-2", LineType.RIDGE)
            )
        )

        val result = DefaultRoofGeometryEngine.canonicalize(source)
        assertFalse(result.isValid)
        assertNull(result.graph)
        val overlap = result.issues.firstOrNull { it.code == "COLLINEAR_EDGE_OVERLAP" }
        assertNotNull(result.issues.joinToString { it.code }, overlap)
        assertEquals(setOf("ridge-a", "ridge-b"), overlap!!.edgeIds.toSet())
    }

    @Test
    fun rotatedTwentyThreeDegreeGridKeepsIncidenceAndAuthoredCoordinates() {
        val rotation = 23.0
        val radians = Math.toRadians(rotation)
        val c = cos(radians)
        val s = sin(radians)
        fun rotated(u: Double, v: Double) = LocalPoint(u * c - v * s, u * s + v * c)

        val lattice = listOf(
            "r0" to rotated(0.0, 0.0),
            "r1" to rotated(4.0, 0.0),
            "r2" to rotated(4.0, 2.0),
            "r3" to rotated(4.0, 4.0),
            "r4" to rotated(0.0, 4.0),
            "r5" to rotated(0.0, 2.0)
        )
        val source = topology(
            nodes = lattice.map { (id, point) ->
                node(id, point.x, point.y, TopologyNodeType.FOOTPRINT)
            },
            edges = listOf(
                edge("rb0", "r0", "r1", boundary = true),
                edge("rb1", "r1", "r2", boundary = true),
                edge("rb2", "r2", "r3", boundary = true),
                edge("rb3", "r3", "r4", boundary = true),
                edge("rb4", "r4", "r5", boundary = true),
                edge("rb5", "r5", "r0", boundary = true),
                edge("rotated-ridge", "r5", "r2", LineType.RIDGE)
            ),
            rotationDeg = rotation
        )

        val result = DefaultRoofGeometryEngine.canonicalize(source)
        assertValid(result)
        assertEquals(2, result.graph!!.faces.size)
        assertEquals(16.0, result.graph!!.faces.values.sumOf { it.signedAreaM2 }, 1e-5)
        assertTrue(result.issues.none { it.code == "INTERSECTION_OFF_SOLVER_GRID" })
        source.nodes.forEach { authored ->
            val solvedId = result.mappings.authoredNodeToSolvedNode.getValue(authored.id)
            val solved = result.subdivision!!.vertices.getValue(solvedId)
            assertEquals(authored.id, authored.x, solved.x, 2e-6)
            assertEquals(authored.id, authored.y, solved.y, 2e-6)
        }
    }

    @Test
    fun lockedOffGridConstraintIsRejectedWithoutMovingAuthoredNodes() {
        val lockedLeft = node("locked-left", 0.0, 2.013, locked = true)
        val lockedRight = node("locked-right", 4.0, 2.013, locked = true)
        val source = simpleSquare(
            extraNodes = listOf(lockedLeft, lockedRight),
            extraEdges = listOf(
                edge(
                    "locked-ridge",
                    lockedLeft.id,
                    lockedRight.id,
                    type = LineType.RIDGE,
                    locked = true
                )
            )
        )

        val result = DefaultRoofGeometryEngine.solve(source)
        assertFalse(result.isValid)
        assertNull(result.graph)
        assertTrue(result.issues.joinToString { it.code }, result.issues.any {
            it.code == "INTERNAL_CONSTRAINTS_INFEASIBLE"
        })
        assertTrue(result.movements.isEmpty())
        listOf(lockedLeft, lockedRight).forEach { authored ->
            val proposed = result.correctedAuthoredTopology.nodes.single { it.id == authored.id }
            assertTrue(proposed.locked)
            assertEquals(authored.x, proposed.x, 0.0)
            assertEquals(authored.y, proposed.y, 0.0)
        }
    }

    @Test
    fun canonicalizationIsDeterministicAndIdempotentForAuthoredInput() {
        val source = crossedSquare()
        val first = DefaultRoofGeometryEngine.canonicalize(source)
        val reordered = DefaultRoofGeometryEngine.canonicalize(
            source.copy(nodes = source.nodes.asReversed(), edges = source.edges.asReversed())
        )
        val repeated = DefaultRoofGeometryEngine.canonicalize(first.correctedAuthoredTopology)

        assertValid(first)
        assertValid(reordered)
        assertValid(repeated)
        assertEquals(first.signature, reordered.signature)
        assertEquals(first.signature, repeated.signature)
        assertEquals(first.solvedTopology, reordered.solvedTopology)
        assertEquals(first.solvedTopology, repeated.solvedTopology)
        assertEquals(first.mappings, reordered.mappings)
        assertEquals(first.mappings, repeated.mappings)
        assertEquals(first.graph!!.topologySignature(), reordered.graph!!.topologySignature())
        assertEquals(first.graph!!.topologySignature(), repeated.graph!!.topologySignature())
        assertTrue(repeated.timings.cacheHit)
    }

    @Test
    fun invalidAuthoredIdsAndShortEdgesProduceBlockingDiagnostics() {
        val valid = simpleSquare()
        val duplicateNode = DefaultRoofGeometryEngine.canonicalize(
            valid.copy(nodes = valid.nodes + valid.nodes.first().copy(x = 1.0))
        )
        assertFalse(duplicateNode.isValid)
        assertTrue(duplicateNode.issues.any { it.code == "INVALID_AUTHORED_NODE_IDS" })

        val duplicateEdge = DefaultRoofGeometryEngine.canonicalize(
            valid.copy(edges = valid.edges + valid.edges.first().copy(endNodeId = "corner-2"))
        )
        assertFalse(duplicateEdge.isValid)
        assertTrue(duplicateEdge.issues.any { it.code == "INVALID_AUTHORED_EDGE_IDS" })

        val reservedId = DefaultRoofGeometryEngine.canonicalize(
            valid.copy(nodes = valid.nodes + node("junction-authored", 2.0, 2.0))
        )
        assertFalse(reservedId.isValid)
        assertTrue(reservedId.issues.any { it.code == "RESERVED_RUNTIME_ID" })

        val shortEdge = DefaultRoofGeometryEngine.canonicalize(
            simpleSquare(
                extraNodes = listOf(node("short-a", 1.0, 1.0), node("short-b", 1.005, 1.0)),
                extraEdges = listOf(edge("too-short", "short-a", "short-b", LineType.RIDGE))
            )
        )
        assertFalse(shortEdge.isValid)
        val issue = shortEdge.issues.firstOrNull { it.code == "SHORT_INTERNAL_EDGE" }
        assertNotNull(shortEdge.issues.joinToString { it.code }, issue)
        assertEquals(listOf("too-short"), issue!!.edgeIds)
    }

    @Test
    fun dcelMaintainsTwinNextPreviousAndFaceCycleInvariants() {
        val result = DefaultRoofGeometryEngine.canonicalize(crossedSquare())
        assertValid(result)
        val subdivision = result.subdivision!!
        assertEquals(subdivision.edges.size * 2, subdivision.halfEdges.size)

        subdivision.edges.values.forEach { planarEdge ->
            assertEquals(
                planarEdge.id,
                2,
                subdivision.halfEdges.values.count { it.edgeId == planarEdge.id }
            )
        }
        subdivision.halfEdges.values.forEach { half ->
            val twin = subdivision.halfEdges.getValue(half.twinId)
            val next = subdivision.halfEdges.getValue(half.nextId)
            val previous = subdivision.halfEdges.getValue(half.previousId)
            assertEquals(half.id, twin.twinId)
            assertEquals(half.originVertexId, twin.targetVertexId)
            assertEquals(half.targetVertexId, twin.originVertexId)
            assertEquals(half.id, next.previousId)
            assertEquals(half.id, previous.nextId)
            assertEquals(half.targetVertexId, next.originVertexId)
            assertEquals(half.originVertexId, previous.targetVertexId)
            assertEquals(half.faceId, next.faceId)
            assertEquals(half.faceId, previous.faceId)
        }
        subdivision.faces.values.forEach { face ->
            assertEquals(face.orderedEdgeIds.size, face.halfEdgeIds.size)
            face.halfEdgeIds.indices.forEach { index ->
                val half = subdivision.halfEdges.getValue(face.halfEdgeIds[index])
                assertEquals(face.id, half.faceId)
                assertEquals(face.halfEdgeIds[(index + 1) % face.halfEdgeIds.size], half.nextId)
                assertEquals(
                    face.halfEdgeIds[(index - 1 + face.halfEdgeIds.size) % face.halfEdgeIds.size],
                    half.previousId
                )
            }
        }
    }
}
