package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofGeometryEngineTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun geo(point: LocalPoint) = Geometry.toGeo(point, origin)

    private fun project(
        footprint: List<LocalPoint>,
        lines: List<Triple<String, LineType, Pair<LocalPoint, LocalPoint>>>,
        boundaryTypes: List<LineType> = footprint.map { LineType.EAVE }
    ) = RoofProject(
        polygon = footprint.map(::geo).toMutableList(),
        wallFootprint = footprint.map(::geo).toMutableList(),
        lines = lines.map { (id, type, points) ->
            RoofLine(id = id, type = type, start = geo(points.first), end = geo(points.second))
        }.toMutableList(),
        edgeTypes = footprint.indices.associateWith { boundaryTypes[it] }.toMutableMap(),
        geometryGridOriginLat = origin.lat,
        geometryGridOriginLon = origin.lon,
        geometryGridRotationDeg = 0.0,
        slopeDeg = 30.0,
        wallHeightM = 3.0
    )

    private fun correctAndPrepare(project: RoofProject): Pair<RoofSolverPreview, Roof3DPreparationResult> {
        val authored = RoofTopologyMigration.fromLegacyProject(project)
        val preview = RoofTopologySolver.solveInternal(
            authored,
            footprintContext = WallFootprintSolver.context(project)
        )
        val nodesById = preview.proposed.nodes.associateBy { it.id }
        val geometry = preview.proposed.edges.filterNot { it.boundary }.joinToString { edge ->
            val start = nodesById[edge.startNodeId]
            val end = nodesById[edge.endNodeId]
            "${edge.id}=(${start?.x},${start?.y})->(${end?.x},${end?.y})"
        }
        assertTrue(
            preview.issues.joinToString { "${it.code}: ${it.message}" } + "; $geometry",
            preview.isValid
        )
        val applied = ProjectGeometryCorrection.apply(
            project,
            preview,
            kind = GeometryCorrectionKind.INTERNAL
        )
        assertTrue(applied.issues.joinToString { it.code }, applied.applied)
        return preview to Roof3DPreparation.prepare(project)
    }

    @Test
    fun authoredAliasesRemainDistinctButSolvedLayerHasOnePhysicalJunction() {
        val footprint = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
            LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val project = project(
            footprint,
            listOf(
                Triple("hip-left-bottom", LineType.HIP, LocalPoint(0.0, 0.0) to LocalPoint(4.10, 3.95)),
                Triple("hip-left-top", LineType.HIP, LocalPoint(0.0, 8.0) to LocalPoint(3.95, 4.10)),
                Triple("ridge", LineType.RIDGE, LocalPoint(4.05, 4.00) to LocalPoint(6.0, 4.0)),
                Triple("hip-right-bottom", LineType.HIP, LocalPoint(10.0, 0.0) to LocalPoint(6.0, 4.0)),
                Triple("hip-right-top", LineType.HIP, LocalPoint(10.0, 8.0) to LocalPoint(6.0, 4.0))
            )
        )
        val authored = RoofTopologyMigration.fromLegacyProject(project)
        val preview = RoofTopologySolver.solveInternal(
            authored,
            footprintContext = WallFootprintSolver.context(project)
        )

        assertEquals(authored.nodes.map { it.id }, preview.proposed.nodes.map { it.id })
        assertEquals(authored.edges, preview.proposed.edges)
        val solved = DefaultRoofGeometryEngine.canonicalize(
            preview.proposed,
            WallFootprintSolver.context(project)
        )
        assertTrue(solved.issues.joinToString { "${it.code}: ${it.message}" }, solved.isValid)
        val aliasesAtLeftJunction = preview.proposed.nodes
            .filter { kotlin.math.abs(it.x - 4.0) < 1e-9 && kotlin.math.abs(it.y - 4.0) < 1e-9 }
            .map { it.id }
            .toSet()
        assertEquals(3, aliasesAtLeftJunction.size)
        val canonical = solved.subdivision!!.vertices.values.single { vertex ->
            vertex.sourceNodeIds.containsAll(aliasesAtLeftJunction)
        }
        assertEquals(aliasesAtLeftJunction, canonical.sourceNodeIds.intersect(aliasesAtLeftJunction))
        assertEquals(1, aliasesAtLeftJunction.map { solved.mappings.authoredNodeToSolvedNode.getValue(it) }.toSet().size)
        assertEquals(3, solved.graph!!.edges.values.count { canonical.id in setOf(it.startNodeId, it.endNodeId) })
    }

    @Test
    fun rectangleHipNetworkUsesSharedNodedGraphForThreeDimensionalPreparation() {
        val footprint = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
            LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val project = project(
            footprint,
            listOf(
                Triple("h1", LineType.HIP, footprint[0] to LocalPoint(4.0, 4.0)),
                Triple("h2", LineType.HIP, footprint[3] to LocalPoint(4.0, 4.0)),
                Triple("r", LineType.RIDGE, LocalPoint(4.0, 4.0) to LocalPoint(6.0, 4.0)),
                Triple("h3", LineType.HIP, footprint[1] to LocalPoint(6.0, 4.0)),
                Triple("h4", LineType.HIP, footprint[2] to LocalPoint(6.0, 4.0))
            )
        )

        val (_, prepared) = correctAndPrepare(project)
        assertFalse(prepared.planeSolution.issues.joinToString { it.code }, prepared.planeSolution.hasBlockingIssues)
        assertEquals(4, prepared.graph.faces.size)
        assertTrue(RoofSurfaceCoverageValidator.validate(prepared.graph).isEmpty())
        assertEquals(80.0, prepared.graph.faces.values.sumOf { it.signedAreaM2 }, 1e-7)
        assertEquals(DefaultRoofGeometryEngine.ENGINE_VERSION, prepared.graph.geometryEngineVersion)
        assertNotNull(prepared.graph.authoredGeometrySignature)
    }

    @Test
    fun concaveLTHPlansKeepOneCompleteSubdivisionThroughRealProjectPath() {
        val cases = listOf(
            project(
                listOf(
                    LocalPoint(0.0, 0.0), LocalPoint(16.0, 0.0), LocalPoint(16.0, 8.0),
                    LocalPoint(8.0, 8.0), LocalPoint(8.0, 16.0), LocalPoint(0.0, 16.0)
                ),
                listOf(
                    Triple("l-hip", LineType.HIP, LocalPoint(0.0, 0.0) to LocalPoint(4.10, 3.90)),
                    Triple("l-ridge-east", LineType.RIDGE, LocalPoint(3.90, 4.10) to LocalPoint(16.0, 4.0)),
                    Triple("l-ridge-north", LineType.RIDGE, LocalPoint(4.0, 16.0) to LocalPoint(4.05, 4.15)),
                    Triple("l-valley", LineType.VALLEY, LocalPoint(3.95, 4.05) to LocalPoint(8.0, 8.0))
                ),
                listOf(LineType.EAVE, LineType.GABLE, LineType.EAVE, LineType.EAVE, LineType.GABLE, LineType.EAVE)
            ),
            project(
                listOf(
                    LocalPoint(0.0, 0.0), LocalPoint(20.0, 0.0), LocalPoint(20.0, 12.0),
                    LocalPoint(16.0, 12.0), LocalPoint(16.0, 24.0), LocalPoint(4.0, 24.0),
                    LocalPoint(4.0, 12.0), LocalPoint(0.0, 12.0)
                ),
                listOf(
                    Triple("t-ridge-main", LineType.RIDGE, LocalPoint(0.0, 6.0) to LocalPoint(20.0, 6.0)),
                    Triple("t-ridge-stem", LineType.RIDGE, LocalPoint(10.0, 6.0) to LocalPoint(10.0, 24.0)),
                    Triple("t-valley-right", LineType.VALLEY, LocalPoint(10.0, 6.0) to LocalPoint(16.0, 12.0)),
                    Triple("t-valley-left", LineType.VALLEY, LocalPoint(4.0, 12.0) to LocalPoint(10.0, 6.0))
                ),
                listOf(
                    LineType.EAVE, LineType.GABLE, LineType.EAVE, LineType.EAVE,
                    LineType.GABLE, LineType.EAVE, LineType.EAVE, LineType.GABLE
                )
            ),
            project(
                listOf(
                    LocalPoint(0.0, 0.0), LocalPoint(8.0, 0.0), LocalPoint(8.0, 8.0),
                    LocalPoint(16.0, 8.0), LocalPoint(16.0, 0.0), LocalPoint(24.0, 0.0),
                    LocalPoint(24.0, 24.0), LocalPoint(16.0, 24.0), LocalPoint(16.0, 16.0),
                    LocalPoint(8.0, 16.0), LocalPoint(8.0, 24.0), LocalPoint(0.0, 24.0)
                ),
                listOf(
                    Triple("h-ridge-left", LineType.RIDGE, LocalPoint(4.0, 0.0) to LocalPoint(4.0, 24.0)),
                    Triple("h-ridge-right", LineType.RIDGE, LocalPoint(20.0, 0.0) to LocalPoint(20.0, 24.0)),
                    Triple("h-ridge-bridge", LineType.RIDGE, LocalPoint(4.0, 12.0) to LocalPoint(20.0, 12.0)),
                    Triple("h-valley-left-bottom", LineType.VALLEY, LocalPoint(8.0, 8.0) to LocalPoint(4.0, 12.0)),
                    Triple("h-valley-left-top", LineType.VALLEY, LocalPoint(8.0, 16.0) to LocalPoint(4.0, 12.0)),
                    Triple("h-valley-right-bottom", LineType.VALLEY, LocalPoint(16.0, 8.0) to LocalPoint(20.0, 12.0)),
                    Triple("h-valley-right-top", LineType.VALLEY, LocalPoint(16.0, 16.0) to LocalPoint(20.0, 12.0))
                ),
                listOf(
                    LineType.GABLE, LineType.EAVE, LineType.EAVE, LineType.EAVE,
                    LineType.GABLE, LineType.EAVE, LineType.GABLE, LineType.EAVE,
                    LineType.EAVE, LineType.EAVE, LineType.GABLE, LineType.EAVE
                )
            )
        )

        cases.forEachIndexed { index, project ->
            val (_, prepared) = correctAndPrepare(project)
            val coverage = RoofSurfaceCoverageValidator.validate(prepared.graph)
            assertTrue("Case $index: ${coverage.joinToString { it.code }}", coverage.isEmpty())
            assertFalse(
                "Case $index: ${prepared.planeSolution.issues.joinToString { it.code }}",
                prepared.planeSolution.hasBlockingIssues
            )
            assertEquals(
                Geometry.areaM2(project.polygon),
                prepared.graph.faces.values.sumOf { it.signedAreaM2 },
                1e-3
            )
            prepared.graph.edges.values.filterNot { it.boundary }.forEach { edge ->
                assertEquals("Case $index, edge ${edge.id}", 2, edge.adjacentFaceIds.size)
            }
        }
    }

    @Test
    fun canonicalizationIsDeterministicAndInputOrderIndependent() {
        val topology = RoofTopologyMigration.fromLegacyProject(
            project(
                listOf(
                    LocalPoint(0.0, 0.0), LocalPoint(8.0, 0.0),
                    LocalPoint(8.0, 8.0), LocalPoint(0.0, 8.0)
                ),
                listOf(
                    Triple("cross-a", LineType.HIP, LocalPoint(0.0, 0.0) to LocalPoint(8.0, 8.0)),
                    Triple("cross-b", LineType.VALLEY, LocalPoint(8.0, 0.0) to LocalPoint(0.0, 8.0))
                )
            )
        )
        val first = DefaultRoofGeometryEngine.canonicalize(topology)
        val reordered = topology.copy(
            nodes = topology.nodes.asReversed(),
            edges = topology.edges.asReversed()
        )
        val second = DefaultRoofGeometryEngine.canonicalize(reordered)

        assertTrue(first.issues.joinToString { "${it.code}: ${it.message}" }, first.isValid)
        assertTrue(second.issues.joinToString { "${it.code}: ${it.message}" }, second.isValid)
        assertEquals(first.signature, second.signature)
        assertEquals(first.solvedTopology, second.solvedTopology)
        assertEquals(first.graph!!.topologySignature(), second.graph!!.topologySignature())
    }
}
