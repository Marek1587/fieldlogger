package sk.strechasketch.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectJsonSerializationTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun schemaElevenSeparatesAuthoredStateFromSolvedCache() {
        val project = solvedProject()

        val root = JSONObject(ProjectJson.encode(project))
        val legacy = RoofGraphJson.decode(root.getJSONObject("roof_graph"))
        val state = RoofGraphJson.decode(
            root.getJSONObject("roof_authored_state").getJSONObject("graph")
        )
        val cache = RoofGraphJson.decode(
            root.getJSONObject("roof_solved_cache").getJSONObject("graph")
        )

        assertEquals(11, root.getInt("schema_version"))
        assertEquals(0, legacy.geometryEngineVersion)
        assertNull(legacy.faces.values.single().plane)
        assertEquals(37.0, legacy.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
        assertTrue(legacy.nodes.values.all { it.z == 0.0 })
        assertTrue(legacy.nodes.values.all { it.sourceNodeIds == setOf(it.id) })
        assertTrue(legacy.edges.values.all { it.sourceEdgeIds == setOf(it.id) })

        assertEquals(DefaultRoofGeometryEngine.ENGINE_VERSION, state.geometryEngineVersion)
        assertNull(state.faces.values.single().plane)
        assertEquals(SlopeConstraintSource.USER, state.faces.values.single().slopeConstraint!!.source)
        assertTrue(state.nodes.values.all { it.z == 0.0 })

        assertNotNull(cache.faces.values.single().plane)
        assertTrue(cache.nodes.values.all { it.z == 5.0 })
        assertTrue(root.getJSONObject("roof_solved_cache").has("authored_state_signature"))
        assertTrue(root.getJSONObject("roof_solved_cache").has("solve_inputs_signature"))
    }

    @Test
    fun deletingSolvedCacheKeepsUserAuthoredControls() {
        val root = JSONObject(ProjectJson.encode(solvedProject()))
        root.remove("roof_solved_cache")

        val restored = ProjectJson.decode(root.toString())
        val graph = requireNotNull(restored.roofGraph)

        assertEquals(37.0, graph.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
        assertEquals(SlopeConstraintSource.USER, graph.faces.values.single().slopeConstraint!!.source)
        assertNull(graph.faces.values.single().plane)
        assertTrue(graph.nodes.values.all { it.z == 0.0 })
        assertEquals(1_700_000_000_123L, restored.updatedAt)
    }

    @Test
    fun newerAuthoredStateRejectsOtherwiseCompatibleSolvedCache() {
        val root = JSONObject(ProjectJson.encode(solvedProject()))
        val stateEnvelope = root.getJSONObject("roof_authored_state")
        val stored = RoofGraphJson.decode(stateEnvelope.getJSONObject("graph"))
        val changed = stored.copy(faces = stored.faces.mapValues { (_, face) ->
            face.copy(slopeConstraint = face.slopeConstraint!!.copy(angleDeg = 44.0))
        })
        stateEnvelope.put("graph", RoofGraphJson.encode(changed))

        val restored = ProjectJson.decode(root.toString())
        val graph = requireNotNull(restored.roofGraph)

        assertEquals(44.0, graph.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
        assertNull("Stale solved plane must not override newer authored controls", graph.faces.values.single().plane)
        assertTrue(graph.nodes.values.all { it.z == 0.0 })
    }

    @Test
    fun changedSolveInputsRejectSolvedValuesButKeepAuthoredState() {
        val root = JSONObject(ProjectJson.encode(solvedProject()))
        root.put("slope_deg", 42.0)

        val restored = ProjectJson.decode(root.toString())
        val graph = requireNotNull(restored.roofGraph)

        assertEquals(42.0, restored.slopeDeg, 0.0)
        assertEquals(37.0, graph.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
        assertNull(graph.faces.values.single().plane)
        assertTrue(graph.nodes.values.all { it.z == 0.0 })
    }

    @Test
    fun schemaTenRuntimeGraphMigratesOnlyAuthoredControls() {
        val original = solvedProject()
        val root = JSONObject(ProjectJson.encode(original)).apply {
            put("schema", "strechostav-sketch-project-10")
            put("schema_version", 10)
            put("roof_graph", RoofGraphJson.encode(requireNotNull(original.roofGraph)))
            remove("roof_authored_state")
            remove("roof_solved_cache")
        }

        val restored = ProjectJson.decode(root.toString())
        val graph = requireNotNull(restored.roofGraph)

        assertEquals(37.0, graph.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
        assertEquals(SlopeConstraintSource.USER, graph.faces.values.single().slopeConstraint!!.source)
        assertNull("A v10 runtime graph is metadata, not a trusted solved cache", graph.faces.values.single().plane)
        assertTrue(graph.nodes.values.all { it.z == 0.0 })
        assertEquals(original.roofTopology, restored.roofTopology)
        assertEquals(original.updatedAt, restored.updatedAt)
    }

    @Test
    fun schemaTenLegacyGraphCannotRestoreSolvedValues() {
        val original = solvedProject()
        val root = JSONObject(ProjectJson.encode(original))
        val legacyWithStaleSolvedValues = RoofGraphJson.decode(root.getJSONObject("roof_graph")).let { graph ->
            graph.copy(
                nodes = graph.nodes.mapValues { (_, node) -> node.copy(z = 99.0) },
                faces = graph.faces.mapValues { (_, face) ->
                    face.copy(plane = RoofPlane(0.0, 0.0, 99.0))
                }
            )
        }
        root.put("schema", "strechostav-sketch-project-10")
        root.put("schema_version", 10)
        root.put("roof_graph", RoofGraphJson.encode(legacyWithStaleSolvedValues))
        root.remove("roof_authored_state")
        root.remove("roof_solved_cache")

        val graph = requireNotNull(ProjectJson.decode(root.toString()).roofGraph)

        assertNull(graph.faces.values.single().plane)
        assertTrue(graph.nodes.values.all { it.z == 0.0 })
        assertEquals(37.0, graph.faces.values.single().slopeConstraint!!.angleDeg, 0.0)
    }

    @Test
    fun legacyEncodingIsPureAndStableAcrossHydration() {
        val project = RoofProject(
            id = "legacy-pure",
            name = "Legacy pure",
            polygon = mutableListOf(
                geo(0.03, 0.02), geo(8.01, 0.01), geo(8.02, 5.98), geo(0.02, 6.01)
            ),
            wallFootprint = mutableListOf(
                geo(0.03, 0.02), geo(8.01, 0.01), geo(8.02, 5.98), geo(0.02, 6.01)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.GABLE
            ),
            createdAt = 1_700_000_000_000L,
            updatedAt = 1_700_000_000_123L
        )
        val polygonBefore = project.polygon.map(GeoPoint::copy)

        val first = ProjectJson.encode(project)

        assertEquals(polygonBefore, project.polygon)
        assertTrue(project.geometryGridOriginLat.isNaN())
        assertTrue(project.geometryGridOriginLon.isNaN())
        assertTrue(project.geometryGridRotationDeg.isNaN())
        assertNull(project.roofTopology)
        assertNull(project.roofGraph)
        assertEquals(1_700_000_000_123L, project.updatedAt)

        val restored = ProjectJson.decode(first)
        val second = ProjectJson.encode(restored)

        assertEquals(first, second)
        assertEquals(1_700_000_000_123L, restored.updatedAt)
        assertFalse(JSONObject(first).getJSONObject("roof_graph").has("authored_geometry_signature"))
    }

    private fun solvedProject(): RoofProject {
        val topology = rectangleTopology()
        val project = RoofProject(
            id = "separated-state",
            name = "Separated state",
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 0.0,
            polygon = topology.nodes.map { Geometry.toGeo(LocalPoint(it.x, it.y), origin) }.toMutableList(),
            wallFootprint = topology.nodes.map { Geometry.toGeo(LocalPoint(it.x, it.y), origin) }.toMutableList(),
            edgeTypes = topology.edges.mapIndexed { index, edge -> index to edge.type }.toMap().toMutableMap(),
            roofTopology = topology,
            slopeDeg = 30.0,
            wallHeightM = 3.0,
            createdAt = 1_700_000_000_000L,
            updatedAt = 1_700_000_000_123L
        )
        val signature = RoofGeometrySignature.compute(
            topology,
            WallFootprintSolver.context(project),
            RoofSolverConfig(),
            DefaultRoofGeometryEngine.ENGINE_VERSION
        )
        val base = RoofGraphFactory.fromTopology(topology, normalizeGrid = false)
        project.roofGraph = base.copy(
            nodes = base.nodes.mapValues { (_, node) -> node.copy(z = 5.0) },
            faces = base.faces.mapValues { (_, face) ->
                face.copy(
                    plane = RoofPlane(0.0, 0.0, 5.0),
                    slopeConstraint = FaceSlopeConstraint(
                        angleDeg = 37.0,
                        directionX = 0.0,
                        directionY = 1.0,
                        hard = true,
                        source = SlopeConstraintSource.USER
                    )
                )
            },
            geometryEngineVersion = DefaultRoofGeometryEngine.ENGINE_VERSION,
            authoredGeometrySignature = signature
        )
        return project
    }

    private fun rectangleTopology() = RoofTopology(
        origin = origin,
        nodes = listOf(
            TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("c", 8.0, 6.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("d", 0.0, 6.0, TopologyNodeType.FOOTPRINT)
        ),
        edges = listOf(
            TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true, sourceId = "wall-0"),
            TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true, sourceId = "wall-1"),
            TopologyEdge("cd", "c", "d", LineType.EAVE, boundary = true, sourceId = "wall-2"),
            TopologyEdge("da", "d", "a", LineType.GABLE, boundary = true, sourceId = "wall-3")
        ),
        gridRotationDeg = 0.0
    )

    private fun geo(x: Double, y: Double): GeoPoint = Geometry.toGeo(LocalPoint(x, y), origin)
}
