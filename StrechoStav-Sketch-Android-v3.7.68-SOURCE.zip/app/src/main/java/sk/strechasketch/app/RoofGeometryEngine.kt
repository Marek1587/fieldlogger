package sk.strechasketch.app

import org.locationtech.jts.geom.Coordinate
import org.locationtech.jts.geom.Geometry
import org.locationtech.jts.geom.GeometryFactory
import org.locationtech.jts.geom.Polygon
import org.locationtech.jts.geom.PrecisionModel
import org.locationtech.jts.noding.NodedSegmentString
import org.locationtech.jts.noding.SegmentString
import org.locationtech.jts.noding.snapround.SnapRoundingNoder
import org.locationtech.jts.operation.polygonize.Polygonizer
import org.locationtech.jts.operation.valid.IsValidOp
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sin

/** One physical solved vertex. Authored aliases are retained in [sourceNodeIds]. */
data class PlanarVertex(
    val id: String,
    val x: Double,
    val y: Double,
    val sourceNodeIds: Set<String> = emptySet(),
    val locked: Boolean = false
)

/** One non-overlapping noded segment with complete authored provenance. */
data class PlanarEdge(
    val id: String,
    val startVertexId: String,
    val endVertexId: String,
    val boundary: Boolean,
    val type: LineType,
    val sourceEdgeIds: Set<String>,
    val sourceIds: Set<String>,
    val locked: Boolean = false,
    val note: String = ""
)

data class RoofHalfEdge(
    val id: String,
    val edgeId: String,
    val originVertexId: String,
    val targetVertexId: String,
    val twinId: String,
    val nextId: String,
    val previousId: String,
    val faceId: String
)

data class PlanarFace(
    val id: String,
    val orderedVertexIds: List<String>,
    val orderedEdgeIds: List<String>,
    val halfEdgeIds: List<String>,
    val signedAreaM2: Double,
    val exterior: Boolean
)

data class RoofPlanarSubdivision(
    val vertices: Map<String, PlanarVertex>,
    val edges: Map<String, PlanarEdge>,
    val halfEdges: Map<String, RoofHalfEdge>,
    val faces: Map<String, PlanarFace>,
    val exteriorFaceId: String?
) {
    val interiorFaces: List<PlanarFace>
        get() = faces.values.filterNot { it.exterior }.sortedBy { it.id }
}

data class RoofGeometryMappings(
    val authoredNodeToSolvedNode: Map<String, String> = emptyMap(),
    val authoredEdgeToSolvedSegments: Map<String, List<String>> = emptyMap()
)

data class RoofGeometryTimings(
    val constraintMillis: Long = 0,
    val nodingMillis: Long = 0,
    val subdivisionMillis: Long = 0,
    val validationMillis: Long = 0,
    val adapterMillis: Long = 0,
    val cacheHit: Boolean = false
)

data class RoofGeometryResult(
    val correctedAuthoredTopology: RoofTopology,
    val solvedTopology: RoofTopology,
    val subdivision: RoofPlanarSubdivision?,
    val graph: RoofGraph?,
    val movements: List<NodeMovement>,
    val mappings: RoofGeometryMappings,
    val issues: List<TopologyIssue>,
    val statistics: RoofSolverStatistics,
    val signature: String,
    val timings: RoofGeometryTimings
) {
    val isValid: Boolean
        get() = graph != null && subdivision != null && issues.none {
            it.severity == TopologyIssueSeverity.ERROR
        }
}

interface RoofGeometryEngine {
    fun solve(
        authoredTopology: RoofTopology,
        footprintContext: WallFootprintSolver.Context? = null,
        config: RoofSolverConfig = RoofSolverConfig(),
        previousGraph: RoofGraph? = null
    ): RoofGeometryResult
}

/**
 * Coordinate constraints and physical incidence are intentionally separate. The coordinate
 * stage may move authored records but never changes their inventory. Noding then creates the
 * canonical derived layer and is the only authority for faces consumed downstream.
 */
interface RoofConstraintSolver {
    fun solve(
        authoredTopology: RoofTopology,
        footprintContext: WallFootprintSolver.Context?,
        config: RoofSolverConfig
    ): RoofSolverPreview
}

object DeterministicRoofConstraintSolver : RoofConstraintSolver {
    override fun solve(
        authoredTopology: RoofTopology,
        footprintContext: WallFootprintSolver.Context?,
        config: RoofSolverConfig
    ): RoofSolverPreview = HierarchicalInternalLineSolver.solve(
        input = authoredTopology,
        footprintContext = footprintContext,
        junctionToleranceM = config.snapToleranceM,
        maximumBoundaryShiftM = HierarchicalInternalLineSolver.MAX_BOUNDARY_SHIFT_M
    )
}

private data class GridKey(val x: Long, val y: Long) : Comparable<GridKey> {
    override fun compareTo(other: GridKey): Int = compareValuesBy(this, other, GridKey::x, GridKey::y)
}

private data class SourceSegment(
    val edge: TopologyEdge,
    val startKey: GridKey,
    val endKey: GridKey
)

private data class PhysicalSegmentKey(val first: GridKey, val second: GridKey) : Comparable<PhysicalSegmentKey> {
    override fun compareTo(other: PhysicalSegmentKey): Int =
        compareValuesBy(this, other, PhysicalSegmentKey::first, PhysicalSegmentKey::second)

    companion object {
        fun of(a: GridKey, b: GridKey) = if (a <= b) PhysicalSegmentKey(a, b) else PhysicalSegmentKey(b, a)
    }
}

internal data class NodedRoofNetwork(
    val vertices: Map<String, PlanarVertex>,
    val edges: Map<String, PlanarEdge>,
    val mappings: RoofGeometryMappings,
    val issues: List<TopologyIssue>,
    val statistics: RoofSolverStatistics
)

/** Robust snap-rounding over boundary and internal lines in one operation. */
object JtsRoofNoder {
    /** The confirmed solver lattice: 1 / 40 m = 25 mm. */
    internal const val PRECISION_SCALE = 40.0
    /** Noding precision is deliberately finer than the authored 25 mm lattice.
     *
     * A crossing of two legal 45-degree lines can lie on a 12.5 mm half-step. Using
     * PrecisionModel(40) inside the noder would silently kink both source lines to a
     * neighbouring hot pixel. The coordinate solver owns the 25/50 mm lattice; the
     * noder only creates exact incidence and then diagnoses an off-grid generated
     * junction instead of moving confirmed geometry.
     */
    private const val NODING_PRECISION_SCALE = 1_000_000.0

    private data class NodingFrame(
        val scale: Double,
        val c: Double,
        val s: Double
    ) {
        fun key(x: Double, y: Double): GridKey {
            val u = x * c + y * s
            val v = -x * s + y * c
            return GridKey(round(u * scale).toLong(), round(v * scale).toLong())
        }

        fun coordinate(key: GridKey): Coordinate = Coordinate(key.x / scale, key.y / scale)

        fun local(key: GridKey): LocalPoint {
            val u = key.x / scale
            val v = key.y / scale
            return LocalPoint(clean(u * c - v * s), clean(u * s + v * c))
        }

        private fun clean(value: Double): Double = if (abs(value) < 1e-12) 0.0 else value
    }

    internal fun node(topology: RoofTopology, config: RoofSolverConfig = RoofSolverConfig()): NodedRoofNetwork {
        val issues = mutableListOf<TopologyIssue>()
        val duplicateNodeIds = topology.nodes.groupBy { it.id }.filterValues { it.size > 1 }.keys
        val duplicateEdgeIds = topology.edges.groupBy { it.id }.filterValues { it.size > 1 }.keys
        if (topology.nodes.any { it.id.isBlank() } || duplicateNodeIds.isNotEmpty()) {
            issues += errorIssue(
                "INVALID_AUTHORED_NODE_IDS",
                "Autorská topológia obsahuje prázdne alebo duplicitné ID uzlov.",
                nodeIds = duplicateNodeIds.toList()
            )
        }
        if (topology.edges.any { it.id.isBlank() } || duplicateEdgeIds.isNotEmpty()) {
            issues += errorIssue(
                "INVALID_AUTHORED_EDGE_IDS",
                "Autorská topológia obsahuje prázdne alebo duplicitné ID hrán.",
                edgeIds = duplicateEdgeIds.toList()
            )
        }
        val nonFiniteNodes = topology.nodes.filter { !it.x.isFinite() || !it.y.isFinite() }.map { it.id }
        if (nonFiniteNodes.isNotEmpty() || !topology.origin.lat.isFinite() || !topology.origin.lon.isFinite()) {
            issues += errorIssue(
                "NON_FINITE_AUTHORED_GEOMETRY",
                "Autorská topológia obsahuje nečíselnú alebo nekonečnú súradnicu.",
                nodeIds = nonFiniteNodes
            )
        }
        val reservedNodes = topology.nodes.filter { it.id.startsWith("junction-") }.map { it.id }
        val reservedEdges = topology.edges.filter {
            "::noded-" in it.id || it.id.startsWith("overlap-") || it.id.startsWith("half:")
        }.map { it.id }
        if (reservedNodes.isNotEmpty() || reservedEdges.isNotEmpty()) {
            issues += errorIssue(
                "RESERVED_RUNTIME_ID",
                "Autorský záznam používa menný priestor vyhradený odvodenému DCEL grafu.",
                nodeIds = reservedNodes,
                edgeIds = reservedEdges
            )
        }
        if (issues.isNotEmpty()) {
            return NodedRoofNetwork(emptyMap(), emptyMap(), RoofGeometryMappings(), issues, RoofSolverStatistics())
        }
        val nodes = topology.nodes.associateBy { it.id }
        val rotation = MetricPlanGrid.axisDeg(topology) ?: 0.0
        val angle = Math.toRadians(rotation)
        val alreadyOnSolverGrid = topology.nodes.all { node ->
            MetricPlanGrid.isOnInternalGrid(LocalPoint(node.x, node.y), rotation, toleranceM = 1e-6)
        }
        val frame = NodingFrame(
            scale = NODING_PRECISION_SCALE,
            c = cos(angle),
            s = sin(angle)
        )
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val sourceNodesByKey = topology.nodes.groupBy { frame.key(it.x, it.y) }
        val segmentStrings = mutableListOf<NodedSegmentString>()

        topology.edges.sortedBy { it.id }.forEach { edge ->
            val a = nodes[edge.startNodeId]
            val b = nodes[edge.endNodeId]
            if (a == null || b == null) {
                issues += errorIssue(
                    "MISSING_EDGE_NODE",
                    "Hrana ${edge.id} odkazuje na neexistujúci autorský uzol.",
                    edgeIds = listOf(edge.id),
                    nodeIds = listOf(edge.startNodeId, edge.endNodeId)
                )
                return@forEach
            }
            val length = hypot(b.x - a.x, b.y - a.y)
            val minimumLength = if (edge.boundary) {
                config.minimumBoundaryEdgeLengthM
            } else config.minimumEdgeLengthM
            if (length + config.intersectionEpsilon < minimumLength) {
                issues += errorIssue(
                    if (edge.boundary) "SHORT_BOUNDARY_EDGE" else "SHORT_INTERNAL_EDGE",
                    "Hrana ${edge.id} má dĺžku $length m, minimum je $minimumLength m.",
                    edgeIds = listOf(edge.id),
                    nodeIds = listOf(a.id, b.id)
                )
                return@forEach
            }
            val start = frame.key(a.x, a.y)
            val end = frame.key(b.x, b.y)
            if (start == end) {
                issues += errorIssue(
                    "ZERO_LENGTH_AUTHORED_EDGE",
                    "Autorská hrana ${edge.id} má po robustnom kvantovaní nulovú dĺžku.",
                    edgeIds = listOf(edge.id),
                    nodeIds = listOf(a.id, b.id)
                )
                return@forEach
            }
            val metadata = SourceSegment(edge, start, end)
            segmentStrings += NodedSegmentString(
                arrayOf(frame.coordinate(start), frame.coordinate(end)),
                metadata
            )
        }
        if (issues.any { it.severity == TopologyIssueSeverity.ERROR }) {
            return NodedRoofNetwork(emptyMap(), emptyMap(), RoofGeometryMappings(), issues, RoofSolverStatistics())
        }

        val grouped = linkedMapOf<PhysicalSegmentKey, MutableList<SourceSegment>>()
        try {
            val noder = SnapRoundingNoder(PrecisionModel(frame.scale))
            noder.computeNodes(segmentStrings)
            @Suppress("UNCHECKED_CAST")
            val nodedSubstrings = noder.nodedSubstrings as Collection<SegmentString>
            nodedSubstrings.forEach { segmentString ->
                val source = segmentString.getData() as? SourceSegment
                if (source == null) {
                    issues += errorIssue(
                        "MISSING_NODED_PROVENANCE",
                        "JTS vrátil segment bez väzby na pôvodnú autorskú hranu."
                    )
                    return@forEach
                }
                segmentString.getCoordinates().asList().zipWithNext().forEach { (a, b) ->
                    val start = GridKey(round(a.x * frame.scale).toLong(), round(a.y * frame.scale).toLong())
                    val end = GridKey(round(b.x * frame.scale).toLong(), round(b.y * frame.scale).toLong())
                    if (start != end) grouped.getOrPut(PhysicalSegmentKey.of(start, end)) { mutableListOf() } += source
                }
            }
        } catch (failure: Throwable) {
            issues += errorIssue(
                "JTS_NODING_FAILED",
                "Robustné delenie strešnej siete zlyhalo: ${failure.message ?: failure::class.java.simpleName}."
            )
            return NodedRoofNetwork(emptyMap(), emptyMap(), RoofGeometryMappings(), issues, RoofSolverStatistics())
        }

        val allKeys = (grouped.keys.asSequence().flatMap { sequenceOf(it.first, it.second) } +
            sourceNodesByKey.keys.asSequence()).toSortedSet()
        val vertexIdByKey = linkedMapOf<GridKey, String>()
        val vertices = linkedMapOf<String, PlanarVertex>()
        allKeys.forEach { point ->
            val aliases = sourceNodesByKey[point].orEmpty().sortedWith(
                compareByDescending<TopologyNode> { it.id in boundaryNodeIds }
                    .thenByDescending { it.locked }
                    .thenBy { it.id }
            )
            val id = aliases.firstOrNull()?.id ?: stableId("junction", "${point.x}:${point.y}")
            if (id in vertices) {
                issues += errorIssue(
                    "CANONICAL_VERTEX_ID_COLLISION",
                    "Dva fyzické body vytvorili rovnaké kanonické ID $id.",
                    nodeIds = aliases.map { it.id }
                )
                return@forEach
            }
            vertexIdByKey[point] = id
            val local = frame.local(point)
            vertices[id] = PlanarVertex(
                id = id,
                x = local.x,
                y = local.y,
                sourceNodeIds = aliases.map { it.id }.toSet(),
                locked = aliases.any { it.locked }
            )
        }
        if (alreadyOnSolverGrid) {
            vertices.values.filter { it.sourceNodeIds.isEmpty() }.forEach { vertex ->
                if (!MetricPlanGrid.isOnInternalGrid(
                        LocalPoint(vertex.x, vertex.y), rotation, toleranceM = 2e-6
                    )
                ) {
                    issues += errorIssue(
                        "INTERSECTION_OFF_SOLVER_GRID",
                        "Priesečník (${vertex.x}, ${vertex.y}) neleží na 25 mm mriežke; " +
                            "súradnicový solver musí vybrať inú konzistentnú väzbu.",
                        nodeIds = listOf(vertex.id)
                    )
                }
            }
        }

        data class EdgeDraft(
            val key: PhysicalSegmentKey,
            val sources: List<SourceSegment>,
            val boundary: Boolean,
            val type: LineType,
            val locked: Boolean,
            val note: String
        )

        val drafts = grouped.entries.sortedBy { it.key }.map { (segmentKey, rawSources) ->
            val sources = rawSources.distinctBy { it.edge.id }.sortedBy { it.edge.id }
            val boundarySources = sources.filter { it.edge.boundary }
            val internalSources = sources.filterNot { it.edge.boundary }
            val concreteTypes = sources.map { it.edge.type }.filter { it != LineType.UNKNOWN }.distinct()
            if (sources.size > 1) {
                issues += errorIssue(
                    "COLLINEAR_EDGE_OVERLAP",
                    "Viac autorských hrán pokrýva rovnaký fyzický segment; prekrytie treba jednoznačne vyriešiť.",
                    edgeIds = sources.map { it.edge.id }
                )
            }
            if (boundarySources.isNotEmpty() && internalSources.isNotEmpty()) {
                issues += errorIssue(
                    "INTERNAL_EDGE_OVERLAPS_BOUNDARY",
                    "Vnútorná línia sa kolineárne prekrýva s fyzickým obvodom.",
                    edgeIds = sources.map { it.edge.id }
                )
            }
            if (boundarySources.map { it.edge.id }.distinct().size > 1) {
                issues += errorIssue(
                    "OVERLAPPING_BOUNDARY_EDGES",
                    "Dve obvodové hrany sa kolineárne prekrývajú.",
                    edgeIds = boundarySources.map { it.edge.id }
                )
            }
            if (concreteTypes.size > 1) {
                issues += errorIssue(
                    "CONFLICTING_COLLINEAR_SEMANTICS",
                    "Prekrývajúce sa línie majú nezlučiteľné typy ${concreteTypes.joinToString()}.",
                    edgeIds = sources.map { it.edge.id }
                )
            }
            EdgeDraft(
                key = segmentKey,
                sources = sources,
                boundary = boundarySources.isNotEmpty(),
                type = concreteTypes.singleOrNull() ?: sources.firstOrNull()?.edge?.type ?: LineType.UNKNOWN,
                locked = sources.any { it.edge.locked },
                note = sources.map { it.edge.note }.filter { it.isNotBlank() }.distinct().joinToString(" | ")
            )
        }

        val draftsBySource = mutableMapOf<String, MutableList<EdgeDraft>>()
        drafts.forEach { draft ->
            draft.sources.forEach { source -> draftsBySource.getOrPut(source.edge.id) { mutableListOf() } += draft }
        }
        draftsBySource.values.forEach { list -> list.sortBy { it.key } }
        val edges = linkedMapOf<String, PlanarEdge>()
        val draftId = linkedMapOf<PhysicalSegmentKey, String>()
        drafts.forEach { draft ->
            val sourceEdgeIds = draft.sources.map { it.edge.id }.toSortedSet()
            val id = if (sourceEdgeIds.size == 1) {
                val sourceId = sourceEdgeIds.single()
                val sourceDrafts = draftsBySource.getValue(sourceId)
                val index = sourceDrafts.indexOf(draft)
                if (index == 0) sourceId else "$sourceId::noded-$index"
            } else stableId(
                "overlap",
                sourceEdgeIds.joinToString("|") + ":${draft.key.first.x}:${draft.key.first.y}:" +
                    "${draft.key.second.x}:${draft.key.second.y}"
            )
            if (id in edges) {
                issues += errorIssue(
                    "CANONICAL_EDGE_ID_COLLISION",
                    "Dva odvodené segmenty vytvorili rovnaké ID $id.",
                    edgeIds = sourceEdgeIds.toList()
                )
                return@forEach
            }
            draftId[draft.key] = id
            edges[id] = PlanarEdge(
                id = id,
                startVertexId = vertexIdByKey.getValue(draft.key.first),
                endVertexId = vertexIdByKey.getValue(draft.key.second),
                boundary = draft.boundary,
                type = draft.type,
                sourceEdgeIds = sourceEdgeIds,
                sourceIds = draft.sources.map { it.edge.sourceId ?: it.edge.id }.toSortedSet(),
                locked = draft.locked,
                note = draft.note
            )
        }

        val nodeMapping = topology.nodes.mapNotNull { source ->
            vertexIdByKey[frame.key(source.x, source.y)]?.let { source.id to it }
        }.toMap()
        val edgeMapping = topology.edges.associate { source ->
            source.id to draftsBySource[source.id].orEmpty().mapNotNull { draftId[it.key] }.distinct()
        }
        edgeMapping.filterValues { it.isEmpty() }.keys.forEach { sourceEdgeId ->
            issues += errorIssue(
                "AUTHORED_EDGE_LOST_DURING_NODING",
                "Autorská hrana $sourceEdgeId nemá vo vyriešenej vrstve žiadny segment.",
                edgeIds = listOf(sourceEdgeId)
            )
        }
        val missingNodeMappings = topology.nodes.map { it.id }.filterNot(nodeMapping::containsKey)
        if (missingNodeMappings.isNotEmpty()) {
            issues += errorIssue(
                "AUTHORED_NODE_LOST_DURING_NODING",
                "Niektoré autorské uzly nemajú kanonické mapovanie.",
                nodeIds = missingNodeMappings
            )
        }
        val aliasCount = sourceNodesByKey.values.sumOf { (it.size - 1).coerceAtLeast(0) }
        val createdIntersections = vertices.values.count { it.sourceNodeIds.isEmpty() }
        val splitEdges = edgeMapping.values.sumOf { (it.size - 1).coerceAtLeast(0) }
        return NodedRoofNetwork(
            vertices = vertices,
            edges = edges,
            mappings = RoofGeometryMappings(nodeMapping, edgeMapping),
            issues = issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) },
            statistics = RoofSolverStatistics(
                mergedNodes = aliasCount,
                createdIntersections = createdIntersections,
                splitEdges = splitEdges
            )
        )
    }

}

internal data class DcelResult(
    val subdivision: RoofPlanarSubdivision?,
    val issues: List<TopologyIssue>,
    val footprint: Polygon?
)

object RoofTopologyCanonicalizer {
    private val geometryFactory = GeometryFactory()

    internal fun build(topology: RoofTopology, network: NodedRoofNetwork): DcelResult {
        val issues = network.issues.toMutableList()
        if (network.vertices.isEmpty() || network.edges.isEmpty()) {
            issues += errorIssue("EMPTY_NODED_NETWORK", "Vyriešená strešná sieť je prázdna.")
            return DcelResult(null, issues, null)
        }
        val footprint = footprintPolygon(topology, network, issues)
            ?: return DcelResult(null, issues, null)

        data class MutableHalfEdge(
            val id: String,
            val edgeId: String,
            val origin: String,
            val target: String,
            val twin: String,
            var next: String = "",
            var previous: String = "",
            var face: String = ""
        )

        val halfEdges = linkedMapOf<String, MutableHalfEdge>()
        network.edges.values.sortedBy { it.id }.forEach { edge ->
            val forward = "half:${edge.id}:0"
            val reverse = "half:${edge.id}:1"
            halfEdges[forward] = MutableHalfEdge(
                forward, edge.id, edge.startVertexId, edge.endVertexId, reverse
            )
            halfEdges[reverse] = MutableHalfEdge(
                reverse, edge.id, edge.endVertexId, edge.startVertexId, forward
            )
        }
        val outgoing = halfEdges.values.groupBy { it.origin }.mapValues { (origin, list) ->
            val center = network.vertices.getValue(origin)
            list.sortedWith(compareBy<MutableHalfEdge> { half ->
                val target = network.vertices.getValue(half.target)
                atan2(target.y - center.y, target.x - center.x)
            }.thenBy { it.edgeId }.thenBy { it.id })
        }
        halfEdges.values.forEach { half ->
            val options = outgoing[half.target].orEmpty()
            val reverseIndex = options.indexOfFirst { it.id == half.twin }
            if (reverseIndex < 0 || options.isEmpty()) {
                issues += errorIssue(
                    "MISSING_HALF_EDGE_TWIN",
                    "Polhrana ${half.id} nemá platnú protismernú incidenciu.",
                    edgeIds = listOf(half.edgeId),
                    nodeIds = listOf(half.origin, half.target)
                )
            } else {
                half.next = options[(reverseIndex - 1 + options.size) % options.size].id
            }
        }
        halfEdges.values.forEach { half ->
            halfEdges[half.next]?.previous = half.id
        }

        data class Cycle(
            val halfIds: List<String>,
            val vertexIds: List<String>,
            val edgeIds: List<String>,
            val area: Double
        )
        val cycles = mutableListOf<Cycle>()
        val visited = mutableSetOf<String>()
        halfEdges.keys.sorted().forEach { seed ->
            if (seed in visited) return@forEach
            val local = linkedSetOf<String>()
            val halfIds = mutableListOf<String>()
            var current = seed
            var closed = false
            while (current !in local && halfIds.size <= halfEdges.size + 1) {
                val half = halfEdges[current] ?: break
                local += current
                halfIds += current
                current = half.next
                if (current == seed) {
                    closed = true
                    break
                }
            }
            visited += local
            if (!closed) {
                issues += errorIssue(
                    "OPEN_HALF_EDGE_CYCLE",
                    "Polhrany od ${seed} nevytvorili uzavretý orientovaný cyklus.",
                    edgeIds = halfIds.mapNotNull { halfEdges[it]?.edgeId }.distinct()
                )
                return@forEach
            }
            val vertexIds = halfIds.map { halfEdges.getValue(it).origin }
            val edgeIds = halfIds.map { halfEdges.getValue(it).edgeId }
            val area = signedArea(vertexIds.map(network.vertices::getValue))
            cycles += Cycle(halfIds, vertexIds, edgeIds, area)
        }

        val negativeCycles = cycles.filter { it.area < -1e-9 }
        if (negativeCycles.size != 1) {
            issues += errorIssue(
                "INVALID_EXTERIOR_FACE_COUNT",
                "Planárny graf musí mať práve jednu exteriérovú plochu; zistené: ${negativeCycles.size}."
            )
        }
        val exteriorCycle = negativeCycles.minByOrNull { it.area }
        val faces = linkedMapOf<String, PlanarFace>()
        cycles.sortedWith(compareBy<Cycle> { it.area }.thenBy { canonicalCycle(it.vertexIds) }).forEach { cycle ->
            val isExterior = cycle === exteriorCycle
            val id = if (isExterior) "face-exterior" else stableId(
                if (cycle.area > 0.0) "face" else "invalid-face",
                canonicalCycle(cycle.vertexIds)
            )
            cycle.halfIds.forEach { halfEdges.getValue(it).face = id }
            faces[id] = PlanarFace(
                id = id,
                orderedVertexIds = cycle.vertexIds,
                orderedEdgeIds = cycle.edgeIds,
                halfEdgeIds = cycle.halfIds,
                signedAreaM2 = cycle.area,
                exterior = isExterior
            )
            if (!isExterior && cycle.area <= 1e-9) {
                issues += errorIssue(
                    "DEGENERATE_DCEL_FACE",
                    "Orientovaný cyklus $id nemá kladnú plochu.",
                    edgeIds = cycle.edgeIds,
                    nodeIds = cycle.vertexIds
                )
            }
        }
        halfEdges.values.filter { it.next.isBlank() || it.previous.isBlank() || it.face.isBlank() }.forEach { half ->
            issues += errorIssue(
                "INCOMPLETE_HALF_EDGE",
                "Polhrana ${half.id} nemá twin/next/previous/face väzbu.",
                edgeIds = listOf(half.edgeId)
            )
        }
        val immutableHalfEdges = halfEdges.mapValues { (_, half) ->
            RoofHalfEdge(
                id = half.id,
                edgeId = half.edgeId,
                originVertexId = half.origin,
                targetVertexId = half.target,
                twinId = half.twin,
                nextId = half.next,
                previousId = half.previous,
                faceId = half.face
            )
        }
        val subdivision = RoofPlanarSubdivision(
            vertices = network.vertices,
            edges = network.edges,
            halfEdges = immutableHalfEdges,
            faces = faces,
            exteriorFaceId = exteriorCycle?.let { "face-exterior" }
        )
        issues += validateSubdivision(subdivision, footprint)
        return DcelResult(
            subdivision,
            issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) },
            footprint
        )
    }

    private fun footprintPolygon(
        topology: RoofTopology,
        network: NodedRoofNetwork,
        issues: MutableList<TopologyIssue>
    ): Polygon? {
        val boundary = RoofTopologyMigration.orderedBoundary(topology)
        if (boundary == null) {
            issues += errorIssue("BOUNDARY_NOT_SINGLE_CYCLE", "Vonkajší obrys netvorí jeden cyklus.")
            return null
        }
        val coordinates = boundary.first.mapNotNull { authoredNodeId ->
            val solvedNodeId = network.mappings.authoredNodeToSolvedNode[authoredNodeId]
            solvedNodeId?.let(network.vertices::get)?.let { Coordinate(it.x, it.y) }
        }
        if (coordinates.size != boundary.first.size || coordinates.size < 3) {
            issues += errorIssue("INVALID_BOUNDARY_COORDINATES", "Obrys obsahuje chýbajúce alebo neplatné body.")
            return null
        }
        val polygon = runCatching {
            geometryFactory.createPolygon(
                geometryFactory.createLinearRing((coordinates + coordinates.first()).toTypedArray())
            )
        }.getOrElse { failure ->
            issues += errorIssue("INVALID_BOUNDARY", "Obrys nemožno vytvoriť: ${failure.message}.")
            return null
        }
        val validity = IsValidOp(polygon).validationError
        if (validity != null || polygon.area <= 1e-9) {
            issues += errorIssue(
                "INVALID_BOUNDARY",
                "Vonkajší obrys nie je jednoduchý platný polygon${validity?.message?.let { ": $it" } ?: ""}."
            )
            return null
        }
        return polygon
    }

    private fun validateSubdivision(
        subdivision: RoofPlanarSubdivision,
        footprint: Polygon
    ): List<TopologyIssue> {
        val issues = mutableListOf<TopologyIssue>()
        val faces = subdivision.interiorFaces
        if (faces.isEmpty()) {
            issues += errorIssue("NO_CLOSED_FACE", "Sieť nevytvorila žiadnu uzavretú strešnú plochu.")
            return issues
        }

        subdivision.edges.values.forEach { edge ->
            val pair = subdivision.halfEdges.values.filter { it.edgeId == edge.id }
            if (pair.size != 2) {
                issues += errorIssue(
                    "DCEL_EDGE_HALFEDGE_COUNT",
                    "Segment ${edge.id} nemá presne dve protismerné polhrany.",
                    edgeIds = listOf(edge.id)
                )
            }
        }
        subdivision.halfEdges.values.forEach { half ->
            val twin = subdivision.halfEdges[half.twinId]
            val next = subdivision.halfEdges[half.nextId]
            val previous = subdivision.halfEdges[half.previousId]
            if (twin == null || twin.twinId != half.id ||
                twin.originVertexId != half.targetVertexId || twin.targetVertexId != half.originVertexId
            ) {
                issues += errorIssue(
                    "DCEL_TWIN_INVARIANT",
                    "Polhrana ${half.id} nemá konzistentnú protismernú dvojicu.",
                    edgeIds = listOf(half.edgeId)
                )
            }
            if (next == null || previous == null || next.previousId != half.id ||
                previous.nextId != half.id || next.originVertexId != half.targetVertexId
            ) {
                issues += errorIssue(
                    "DCEL_LINK_INVARIANT",
                    "Polhrana ${half.id} nemá konzistentné next/previous väzby.",
                    edgeIds = listOf(half.edgeId)
                )
            }
        }
        subdivision.faces.values.forEach { face ->
            val declared = face.halfEdgeIds
            if (declared.isEmpty()) {
                issues += errorIssue("DCEL_EMPTY_FACE_CYCLE", "Plocha ${face.id} nemá polhranový cyklus.")
                return@forEach
            }
            val walked = mutableListOf<String>()
            var current = declared.first()
            while (current !in walked && walked.size <= subdivision.halfEdges.size) {
                val half = subdivision.halfEdges[current] ?: break
                if (half.faceId != face.id) break
                walked += current
                current = half.nextId
            }
            if (current != declared.first() || walked != declared) {
                issues += errorIssue(
                    "DCEL_FACE_CYCLE_INVARIANT",
                    "Plocha ${face.id} nezodpovedá svojmu next-cyklu.",
                    edgeIds = face.orderedEdgeIds,
                    nodeIds = face.orderedVertexIds
                )
            }
        }

        val connectedVertices = mutableSetOf<String>()
        val queue = ArrayDeque<String>()
        subdivision.vertices.keys.minOrNull()?.let { queue += it }
        val incident = subdivision.edges.values.flatMap { edge ->
            listOf(edge.startVertexId to edge.endVertexId, edge.endVertexId to edge.startVertexId)
        }.groupBy({ it.first }, { it.second })
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            if (!connectedVertices.add(node)) continue
            incident[node].orEmpty().sorted().forEach { if (it !in connectedVertices) queue += it }
        }
        if (connectedVertices.size != subdivision.vertices.size) {
            issues += errorIssue(
                "DISCONNECTED_ROOF_NETWORK",
                "Strešné línie netvoria jeden spoločný planárny graf.",
                nodeIds = subdivision.vertices.keys.filter { it !in connectedVertices }
            )
        }

        subdivision.edges.values.forEach { edge ->
            val adjacent = subdivision.halfEdges.values.filter { it.edgeId == edge.id }
                .map { it.faceId }.filter { it != subdivision.exteriorFaceId }.toSet()
            val required = if (edge.boundary) 1 else 2
            if (adjacent.size != required) {
                issues += errorIssue(
                    if (edge.boundary) "BOUNDARY_FACE_INCIDENCE" else "INTERNAL_FACE_INCIDENCE",
                    "${if (edge.boundary) "Obvodová" else "Vnútorná"} hrana ${edge.id} má ${adjacent.size} " +
                        "susedných plôch namiesto $required.",
                    edgeIds = listOf(edge.id),
                    nodeIds = listOf(edge.startVertexId, edge.endVertexId)
                )
            }
        }

        val facePolygons = mutableListOf<Pair<PlanarFace, Polygon>>()
        faces.forEach { face ->
            val coords = face.orderedVertexIds.map { id ->
                val vertex = subdivision.vertices.getValue(id)
                Coordinate(vertex.x, vertex.y)
            }
            val polygon = runCatching {
                geometryFactory.createPolygon(
                    geometryFactory.createLinearRing((coords + coords.first()).toTypedArray())
                )
            }.getOrNull()
            val validity = polygon?.let { IsValidOp(it).validationError }
            if (polygon == null || validity != null || abs(polygon.area - face.signedAreaM2) > 1e-7) {
                issues += errorIssue(
                    "INVALID_DCEL_FACE",
                    "Plocha ${face.id} nie je jednoduchý uzavretý polygon${validity?.message?.let { ": $it" } ?: ""}.",
                    edgeIds = face.orderedEdgeIds,
                    nodeIds = face.orderedVertexIds
                )
            } else {
                if (!footprint.covers(polygon)) {
                    issues += errorIssue(
                        "FACE_OUTSIDE_FOOTPRINT",
                        "Plocha ${face.id} leží mimo autoritatívneho obrysu.",
                        edgeIds = face.orderedEdgeIds,
                        nodeIds = face.orderedVertexIds
                    )
                }
                facePolygons += face to polygon
            }
        }
        for (i in facePolygons.indices) for (j in i + 1 until facePolygons.size) {
            val overlap = runCatching { facePolygons[i].second.intersection(facePolygons[j].second).area }
                .getOrDefault(Double.POSITIVE_INFINITY)
            if (overlap > 1e-8) {
                issues += errorIssue(
                    "OVERLAPPING_ROOF_FACES",
                    "Strešné plochy ${facePolygons[i].first.id} a ${facePolygons[j].first.id} sa prekrývajú."
                )
            }
        }
        if (facePolygons.isNotEmpty()) {
            val union = runCatching {
                facePolygons.drop(1).fold< Pair<PlanarFace, Polygon>, Geometry>(facePolygons.first().second) {
                        geometry, (_, polygon) -> geometry.union(polygon)
                }
            }.getOrNull()
            val uncovered = union?.let { runCatching { footprint.symDifference(it).area }.getOrNull() }
            if (uncovered == null || uncovered > 1e-7 ||
                abs(facePolygons.sumOf { it.second.area } - footprint.area) > 1e-7
            ) {
                issues += errorIssue(
                    "INCOMPLETE_FOOTPRINT_COVERAGE",
                    "Zjednotenie strešných plôch sa nerovná autoritatívnemu obrysu."
                )
            }
        }

        // `extractOnlyPolygonal=true` deliberately returns only a non-overlapping
        // subset (for example alternating faces of a fully noded hip roof), so it
        // is not a face-count oracle for a planar subdivision.  We need every
        // minimal edge-ring here and validate overlap/coverage independently above.
        val polygonizer = Polygonizer(false)
        subdivision.edges.values.forEach { edge ->
            val a = subdivision.vertices.getValue(edge.startVertexId)
            val b = subdivision.vertices.getValue(edge.endVertexId)
            polygonizer.add(geometryFactory.createLineString(arrayOf(Coordinate(a.x, a.y), Coordinate(b.x, b.y))))
        }
        val independentlyPolygonized = polygonizer.polygons
        if (polygonizer.dangles.isNotEmpty() || polygonizer.cutEdges.isNotEmpty() ||
            polygonizer.invalidRingLines.isNotEmpty()
        ) {
            issues += errorIssue(
                "POLYGONIZER_REJECTED_LINEWORK",
                "Nezávislá kontrola našla voľné, rezné alebo neplatné línie v strešnej sieti."
            )
        }
        if (independentlyPolygonized.size != faces.size) {
            issues += errorIssue(
                "POLYGONIZER_FACE_MISMATCH",
                "DCEL a nezávislá polygonizácia nesúhlasia v počte plôch " +
                    "(${faces.size} oproti ${independentlyPolygonized.size})."
            )
        }
        return issues
    }
}

object SolvedRoofGraphAdapter {
    private val geometryFactory = GeometryFactory()

    fun adapt(
        solvedTopology: RoofTopology,
        subdivision: RoofPlanarSubdivision,
        mappings: RoofGeometryMappings,
        previous: RoofGraph?,
        signature: String,
        engineVersion: Int
    ): RoofGraph {
        val previousNodes = previous?.nodes.orEmpty()
        val graphNodes = subdivision.vertices.values.sortedBy { it.id }.associate { vertex ->
            val old = previousNodes[vertex.id]
                ?: vertex.sourceNodeIds.asSequence().sorted().mapNotNull(previousNodes::get).firstOrNull()
            vertex.id to GraphNode(
                id = vertex.id,
                x = vertex.x,
                y = vertex.y,
                z = old?.z ?: 0.0,
                lockX = old?.lockX ?: vertex.locked,
                lockY = old?.lockY ?: vertex.locked,
                lockZ = old?.lockZ ?: false,
                sourceNodeIds = vertex.sourceNodeIds
            )
        }

        val previousFaces = previous?.faces?.values.orEmpty().toMutableSet()
        val assignedFaceIds = linkedMapOf<String, String>()
        val faceSource = linkedMapOf<String, GraphFace?>()
        subdivision.interiorFaces.forEach { face ->
            val provenanceKey = provenanceCycle(face.orderedEdgeIds) { edgeId ->
                subdivision.edges[edgeId]?.sourceEdgeIds.orEmpty().ifEmpty { setOf(edgeId) }
            }
            val geometryKey = normalizedGeometryKey(face.orderedVertexIds.map(graphNodes::getValue))
            val exact = previousFaces.firstOrNull { candidate ->
                provenanceCycle(candidate.orderedEdgeIds) { edgeId ->
                    previous?.edges?.get(edgeId)?.sourceEdgeIds.orEmpty().ifEmpty { setOf(edgeId) }
                } == provenanceKey
            }
            val overlap = exact ?: bestOverlap(face, graphNodes, previous, previousFaces)
            if (overlap != null) previousFaces.remove(overlap)
            val assigned = overlap?.id ?: stableId("face", "$provenanceKey;$geometryKey")
            assignedFaceIds[face.id] = assigned
            faceSource[face.id] = overlap
        }

        val faces = linkedMapOf<String, GraphFace>()
        subdivision.interiorFaces.forEach { face ->
            val old = faceSource[face.id]
            val id = assignedFaceIds.getValue(face.id)
            faces[id] = GraphFace(
                id = id,
                orderedNodeIds = face.orderedVertexIds,
                orderedEdgeIds = face.orderedEdgeIds,
                signedAreaM2 = face.signedAreaM2,
                plane = old?.plane,
                slopeConstraint = old?.slopeConstraint,
                elevationConstraints = old?.elevationConstraints.orEmpty().map { constraint ->
                    constraint.copy(nodeId = constraint.nodeId?.let {
                        mappings.authoredNodeToSolvedNode[it] ?: it.takeIf(graphNodes::containsKey)
                    })
                },
                underconstrained = old?.underconstrained ?: false,
                holeNodeIdLoops = old?.holeNodeIdLoops.orEmpty(),
                componentId = old?.componentId ?: "main",
                hostFaceId = old?.hostFaceId
            )
        }

        val previousEdges = previous?.edges.orEmpty()
        val graphEdges = subdivision.edges.values.sortedBy { it.id }.associate { edge ->
            val old = previousEdges[edge.id]
                ?: edge.sourceEdgeIds.asSequence().sorted().mapNotNull(previousEdges::get).firstOrNull()
            val adjacentFaceIds = subdivision.halfEdges.values.asSequence()
                .filter { it.edgeId == edge.id }
                .mapNotNull { half -> assignedFaceIds[half.faceId] }
                .toSet()
            edge.id to GraphEdge(
                id = edge.id,
                startNodeId = edge.startVertexId,
                endNodeId = edge.endVertexId,
                boundary = edge.boundary,
                semanticRole = EdgeSemantic.fromLegacy(edge.type),
                adjacentFaceIds = adjacentFaceIds,
                locked = old?.locked ?: edge.locked,
                note = edge.note,
                elevationZ = old?.elevationZ,
                sourceEdgeIds = edge.sourceEdgeIds,
                sourceIds = edge.sourceIds
            )
        }

        fun mappedEdge(id: String): String? = mappings.authoredEdgeToSolvedSegments[id]?.singleOrNull()
            ?: id.takeIf(graphEdges::containsKey)
        fun mappedNode(id: String): String? = mappings.authoredNodeToSolvedNode[id]
            ?: id.takeIf(graphNodes::containsKey)

        val dimensions = previous?.dimensions.orEmpty().mapNotNull { (id, item) ->
            val first = mappedEdge(item.supportAEdgeId) ?: return@mapNotNull null
            val second = mappedEdge(item.supportBEdgeId) ?: return@mapNotNull null
            id to item.copy(
                supportAEdgeId = first,
                supportBEdgeId = second,
                fixedSupportEdgeId = item.fixedSupportEdgeId?.let(::mappedEdge),
                movingNodeIds = item.movingNodeIds.mapNotNull(::mappedNode).toSet()
            )
        }.toMap()
        val edgeLengths = previous?.edgeLengthConstraints.orEmpty().mapNotNull { (id, item) ->
            val edgeId = mappedEdge(item.edgeId) ?: return@mapNotNull null
            val fixedNode = mappedNode(item.fixedNodeId) ?: return@mapNotNull null
            id to item.copy(edgeId = edgeId, fixedNodeId = fixedNode)
        }.toMap()
        val drains = previous?.drainPointConstraints.orEmpty().mapNotNull { (id, item) ->
            val faceIds = item.faceIds.filter(faces::containsKey).toSet()
            if (faceIds.isEmpty()) return@mapNotNull null
            id to item.copy(faceIds = faceIds, nodeId = item.nodeId?.let(::mappedNode))
        }.toMap()

        val components = previous?.components.orEmpty().toMutableMap()
        val main = components["main"] ?: RoofComponent("main", "Hlavná strecha")
        components["main"] = main.copy(
            faceIds = faces.values.filter { it.componentId == "main" }.map { it.id }.toSet()
        )
        return RoofGraph(
            origin = solvedTopology.origin.copy(),
            nodes = graphNodes,
            edges = graphEdges,
            faces = faces,
            dimensions = dimensions,
            schemaVersion = previous?.schemaVersion ?: 2,
            edgeLengthConstraints = edgeLengths,
            components = components,
            drainPointConstraints = drains,
            gridRotationDeg = solvedTopology.gridRotationDeg,
            geometryEngineVersion = engineVersion,
            authoredGeometrySignature = signature
        )
    }

    private fun bestOverlap(
        face: PlanarFace,
        nodes: Map<String, GraphNode>,
        previous: RoofGraph?,
        candidates: Set<GraphFace>
    ): GraphFace? {
        if (previous == null || candidates.isEmpty()) return null
        val candidatePolygon = polygon(face.orderedVertexIds.map(nodes::getValue)) ?: return null
        return candidates.mapNotNull { old ->
            val oldPolygon = polygon(old.orderedNodeIds.mapNotNull(previous.nodes::get)) ?: return@mapNotNull null
            val overlap = runCatching { candidatePolygon.intersection(oldPolygon).area }.getOrDefault(0.0)
            val ratio = overlap / maxOf(candidatePolygon.area, oldPolygon.area, 1e-9)
            old to ratio
        }.filter { it.second >= 0.80 }
            .sortedWith(compareByDescending<Pair<GraphFace, Double>> { it.second }.thenBy { it.first.id })
            .firstOrNull()?.first
    }

    private fun polygon(nodes: List<GraphNode>): Polygon? {
        if (nodes.size < 3) return null
        return runCatching {
            val coords = nodes.map { Coordinate(it.x, it.y) }
            geometryFactory.createPolygon(
                geometryFactory.createLinearRing((coords + coords.first()).toTypedArray())
            )
        }.getOrNull()
    }

    private fun normalizedGeometryKey(nodes: List<GraphNode>): String {
        if (nodes.isEmpty()) return ""
        val simplified = nodes.indices.filter { index ->
            val previous = nodes[(index - 1 + nodes.size) % nodes.size]
            val current = nodes[index]
            val next = nodes[(index + 1) % nodes.size]
            abs((current.x - previous.x) * (next.y - current.y) -
                (current.y - previous.y) * (next.x - current.x)) > 1e-9
        }.map { index ->
            "${round(nodes[index].x * 1_000_000.0).toLong()}:" +
                round(nodes[index].y * 1_000_000.0).toLong()
        }.ifEmpty {
            nodes.map {
                "${round(it.x * 1_000_000.0).toLong()}:" +
                    round(it.y * 1_000_000.0).toLong()
            }
        }
        return canonicalCycle(simplified)
    }

    private fun provenanceCycle(
        orderedEdgeIds: List<String>,
        sources: (String) -> Set<String>
    ): String {
        val tokens = orderedEdgeIds.map { edgeId -> sources(edgeId).sorted().joinToString("&") }
            .fold(mutableListOf<String>()) { result, token ->
                if (result.lastOrNull() != token) result += token
                result
            }
        if (tokens.size > 1 && tokens.first() == tokens.last()) tokens.removeAt(tokens.lastIndex)
        return canonicalCycle(tokens)
    }
}

object RoofGeometrySignature {
    fun compute(
        topology: RoofTopology,
        footprintContext: WallFootprintSolver.Context?,
        config: RoofSolverConfig,
        engineVersion: Int
    ): String {
        val payload = buildString {
            append("engine=").append(engineVersion).append(';')
            append("origin=").append(topology.origin.lat.toHex()).append(',')
                .append(topology.origin.lon.toHex()).append(';')
            append("grid=").append(topology.gridRotationDeg.toHex()).append(';')
            topology.nodes.sortedBy { it.id }.forEach { node ->
                append("n:").append(node.id).append(':').append(node.x.toHex()).append(':')
                    .append(node.y.toHex()).append(':').append(node.type).append(':')
                    .append(node.locked).append(';')
            }
            topology.edges.sortedBy { it.id }.forEach { edge ->
                append("e:").append(edge.id).append(':').append(edge.startNodeId).append('>')
                    .append(edge.endNodeId).append(':').append(edge.type).append(':')
                    .append(edge.boundary).append(':').append(edge.locked).append(':')
                    .append(edge.sourceId).append(':').append(edge.note).append(';')
            }
            footprintContext?.parts?.sortedBy { it.id }?.forEach { part ->
                append("p:").append(part.id).append(':').append(part.type).append(':')
                    .append(part.hostPartId).append(':')
                part.polygon.forEach { point ->
                    append(point.x.toHex()).append(',').append(point.y.toHex()).append('|')
                }
                append(';')
            }
            append("config=").append(config.mergeToleranceM.toHex()).append(':')
                .append(config.snapToleranceM.toHex()).append(':')
                .append(config.minimumEdgeLengthM.toHex()).append(':')
                .append(config.intersectionEpsilon.toHex()).append(':')
                .append(config.allowFreeInternalEnds).append(':')
                .append(config.regularizeAngles).append(':')
                .append(config.maximumRegularizationDisplacementM.toHex()).append(':')
                .append(config.minimumBoundaryEdgeLengthM.toHex()).append(';')
        }
        return MessageDigest.getInstance("SHA-256")
            .digest(payload.toByteArray(StandardCharsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
    }

    private fun Double.toHex() = java.lang.Double.toHexString(this)
}

object DefaultRoofGeometryEngine : RoofGeometryEngine {
    const val ENGINE_VERSION = 1
    private const val CACHE_LIMIT = 16

    private data class CachedCanonical(
        val solvedTopology: RoofTopology,
        val subdivision: RoofPlanarSubdivision?,
        val mappings: RoofGeometryMappings,
        val issues: List<TopologyIssue>,
        val statistics: RoofSolverStatistics,
        val nodingMillis: Long,
        val subdivisionMillis: Long,
        val validationMillis: Long
    )

    private val cache = object : LinkedHashMap<String, CachedCanonical>(CACHE_LIMIT, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedCanonical>?): Boolean =
            size > CACHE_LIMIT
    }

    override fun solve(
        authoredTopology: RoofTopology,
        footprintContext: WallFootprintSolver.Context?,
        config: RoofSolverConfig,
        previousGraph: RoofGraph?
    ): RoofGeometryResult {
        val constraintStart = System.nanoTime()
        val constrained = DeterministicRoofConstraintSolver.solve(
            authoredTopology,
            footprintContext,
            config
        )
        val constraintMillis = elapsedMillis(constraintStart)
        if (!constrained.isValid) {
            val signature = RoofGeometrySignature.compute(
                constrained.proposed,
                footprintContext,
                config,
                ENGINE_VERSION
            )
            return RoofGeometryResult(
                correctedAuthoredTopology = constrained.proposed,
                solvedTopology = constrained.proposed,
                subdivision = null,
                graph = null,
                movements = constrained.movements,
                mappings = RoofGeometryMappings(),
                issues = constrained.issues,
                statistics = constrained.statistics,
                signature = signature,
                timings = RoofGeometryTimings(constraintMillis = constraintMillis)
            )
        }
        val canonical = canonicalize(
            constrained.proposed,
            footprintContext,
            config,
            previousGraph
        )
        return canonical.copy(
            correctedAuthoredTopology = constrained.proposed,
            movements = constrained.movements,
            issues = (constrained.issues + canonical.issues).distinctBy {
                Triple(it.code, it.nodeIds, it.edgeIds)
            },
            statistics = mergeStatistics(constrained.statistics, canonical.statistics),
            timings = canonical.timings.copy(constraintMillis = constraintMillis)
        )
    }

    fun canonicalize(
        correctedAuthoredTopology: RoofTopology,
        footprintContext: WallFootprintSolver.Context? = null,
        config: RoofSolverConfig = RoofSolverConfig(),
        previousGraph: RoofGraph? = null
    ): RoofGeometryResult {
        val signature = RoofGeometrySignature.compute(
            correctedAuthoredTopology,
            footprintContext,
            config,
            ENGINE_VERSION
        )
        val cached = synchronized(cache) { cache[signature] }
        val canonical = cached ?: run {
            val nodingStart = System.nanoTime()
            val network = JtsRoofNoder.node(correctedAuthoredTopology, config)
            val nodingMillis = elapsedMillis(nodingStart)
            val subdivisionStart = System.nanoTime()
            val dcel = RoofTopologyCanonicalizer.build(correctedAuthoredTopology, network)
            val subdivisionMillis = elapsedMillis(subdivisionStart)
            val solvedTopology = if (dcel.subdivision == null) {
                correctedAuthoredTopology.deepCopyForGeometryEngine()
            } else solvedTopology(correctedAuthoredTopology, dcel.subdivision)
            val result = CachedCanonical(
                solvedTopology = solvedTopology,
                subdivision = dcel.subdivision,
                mappings = network.mappings,
                issues = dcel.issues,
                statistics = network.statistics,
                nodingMillis = nodingMillis,
                subdivisionMillis = subdivisionMillis,
                validationMillis = 0
            )
            synchronized(cache) { cache[signature] = result }
            result
        }
        val adapterStart = System.nanoTime()
        val compatiblePrevious = when {
            previousGraph == null -> null
            isGraphCompatible(previousGraph, correctedAuthoredTopology, footprintContext, config) -> previousGraph
            previousGraph.geometryEngineVersion == 0 &&
                RoofGraphFactory.isAuthoredTopologyCompatible(correctedAuthoredTopology, previousGraph) ->
                legacyAuthoredMetadata(previousGraph)
            else -> null
        }
        val adaptationIssues = compatiblePrevious?.let { previous ->
            validateMetadataMappings(previous, canonical.mappings, canonical.subdivision)
        }.orEmpty()
        val resultIssues = (canonical.issues + adaptationIssues).distinctBy {
            Triple(it.code, it.nodeIds, it.edgeIds)
        }
        val blocking = resultIssues.any { it.severity == TopologyIssueSeverity.ERROR }
        val graph = if (!blocking && canonical.subdivision != null) {
            SolvedRoofGraphAdapter.adapt(
                solvedTopology = canonical.solvedTopology,
                subdivision = canonical.subdivision,
                mappings = canonical.mappings,
                previous = compatiblePrevious,
                signature = signature,
                engineVersion = ENGINE_VERSION
            )
        } else null
        val adapterMillis = elapsedMillis(adapterStart)
        return RoofGeometryResult(
            correctedAuthoredTopology = correctedAuthoredTopology.deepCopyForGeometryEngine(),
            solvedTopology = canonical.solvedTopology,
            subdivision = canonical.subdivision,
            graph = graph,
            movements = emptyList(),
            mappings = canonical.mappings,
            issues = resultIssues,
            statistics = canonical.statistics,
            signature = signature,
            timings = RoofGeometryTimings(
                nodingMillis = canonical.nodingMillis,
                subdivisionMillis = canonical.subdivisionMillis,
                validationMillis = canonical.validationMillis,
                adapterMillis = adapterMillis,
                cacheHit = cached != null
            )
        )
    }

    fun isGraphCompatible(
        graph: RoofGraph,
        topology: RoofTopology,
        footprintContext: WallFootprintSolver.Context?,
        config: RoofSolverConfig = RoofSolverConfig()
    ): Boolean = graph.geometryEngineVersion == ENGINE_VERSION &&
        graph.authoredGeometrySignature == RoofGeometrySignature.compute(
            topology,
            footprintContext,
            config,
            ENGINE_VERSION
        )

    /** Legacy graphs may contribute explicit user/import metadata, never solved planes or Z. */
    private fun legacyAuthoredMetadata(graph: RoofGraph): RoofGraph = graph.copy(
        nodes = graph.nodes.mapValues { (_, node) ->
            node.copy(z = if (node.lockZ) node.z else 0.0)
        },
        faces = graph.faces.mapValues { (_, face) ->
            face.copy(
                plane = null,
                slopeConstraint = face.slopeConstraint?.takeIf {
                    it.source != SlopeConstraintSource.AUTOMATIC_GABLE
                },
                underconstrained = false
            )
        },
        geometryEngineVersion = 0,
        authoredGeometrySignature = null
    )

    private fun validateMetadataMappings(
        previous: RoofGraph,
        mappings: RoofGeometryMappings,
        subdivision: RoofPlanarSubdivision?
    ): List<TopologyIssue> {
        val runtimeEdgeIds = subdivision?.edges?.keys.orEmpty()
        fun ambiguous(authoredEdgeId: String?): Boolean {
            authoredEdgeId ?: return false
            if (authoredEdgeId in runtimeEdgeIds) return false
            return mappings.authoredEdgeToSolvedSegments[authoredEdgeId].orEmpty().size != 1
        }
        val issues = mutableListOf<TopologyIssue>()
        previous.dimensions.values.forEach { item ->
            val refs = listOf(item.supportAEdgeId, item.supportBEdgeId, item.fixedSupportEdgeId)
                .filterNotNull().filter(::ambiguous)
            if (refs.isNotEmpty()) issues += errorIssue(
                "AMBIGUOUS_SPLIT_DIMENSION_CONSTRAINT",
                "Rozmer ${item.id} odkazuje na autorskú hranu rozdelenú na viac segmentov.",
                edgeIds = refs
            )
        }
        previous.edgeLengthConstraints.values.forEach { item ->
            if (ambiguous(item.edgeId)) issues += errorIssue(
                "AMBIGUOUS_SPLIT_LENGTH_CONSTRAINT",
                "Dĺžková väzba ${item.id} odkazuje na hranu rozdelenú na viac segmentov.",
                edgeIds = listOf(item.edgeId)
            )
        }
        return issues
    }

    private fun solvedTopology(source: RoofTopology, subdivision: RoofPlanarSubdivision): RoofTopology {
        val degree = subdivision.edges.values.flatMap {
            listOf(it.startVertexId, it.endVertexId)
        }.groupingBy { it }.eachCount()
        val boundaryIds = subdivision.edges.values.filter { it.boundary }
            .flatMap { listOf(it.startVertexId, it.endVertexId) }.toSet()
        val nodes = subdivision.vertices.values.sortedBy { it.id }.map { vertex ->
            TopologyNode(
                id = vertex.id,
                x = vertex.x,
                y = vertex.y,
                type = when {
                    vertex.id in boundaryIds -> TopologyNodeType.FOOTPRINT
                    vertex.sourceNodeIds.isEmpty() -> TopologyNodeType.INTERSECTION
                    vertex.sourceNodeIds.size > 1 || degree[vertex.id].orZero() > 2 -> TopologyNodeType.JUNCTION
                    else -> TopologyNodeType.LINE_ENDPOINT
                },
                locked = vertex.locked
            )
        }
        val edges = subdivision.edges.values.sortedBy { it.id }.map { edge ->
            TopologyEdge(
                id = edge.id,
                startNodeId = edge.startVertexId,
                endNodeId = edge.endVertexId,
                type = edge.type,
                locked = edge.locked,
                boundary = edge.boundary,
                sourceId = edge.sourceIds.singleOrNull()
                    ?: edge.sourceEdgeIds.singleOrNull()
                    ?: edge.sourceIds.sorted().joinToString("+"),
                note = edge.note
            )
        }
        return RoofTopology(
            origin = source.origin.copy(),
            nodes = nodes,
            edges = edges,
            schemaVersion = source.schemaVersion,
            gridRotationDeg = source.gridRotationDeg
        )
    }

    private fun Int?.orZero() = this ?: 0
}

private fun mergeStatistics(a: RoofSolverStatistics, b: RoofSolverStatistics) = RoofSolverStatistics(
    mergedNodes = a.mergedNodes + b.mergedNodes,
    createdIntersections = a.createdIntersections + b.createdIntersections,
    splitEdges = a.splitEdges + b.splitEdges,
    snappedFreeEnds = a.snappedFreeEnds + b.snappedFreeEnds,
    removedShortEdges = a.removedShortEdges + b.removedShortEdges,
    removedDuplicateEdges = a.removedDuplicateEdges + b.removedDuplicateEdges,
    removedConflictingInternalEdges = a.removedConflictingInternalEdges + b.removedConflictingInternalEdges,
    regularizedBoundaryNodes = a.regularizedBoundaryNodes + b.regularizedBoundaryNodes,
    alignedHipValleyNodes = a.alignedHipValleyNodes + b.alignedHipValleyNodes,
    alignedRidgeNodes = a.alignedRidgeNodes + b.alignedRidgeNodes
)

private fun signedArea(vertices: List<PlanarVertex>): Double = vertices.indices.sumOf { index ->
    val next = vertices[(index + 1) % vertices.size]
    vertices[index].x * next.y - next.x * vertices[index].y
} / 2.0

private fun canonicalCycle(values: List<String>): String {
    if (values.isEmpty()) return ""
    fun rotations(input: List<String>) = input.indices.map { index ->
        (input.drop(index) + input.take(index)).joinToString("|")
    }
    return (rotations(values) + rotations(values.asReversed())).minOrNull().orEmpty()
}

private fun stableId(prefix: String, payload: String): String = "$prefix-" + UUID.nameUUIDFromBytes(
    payload.toByteArray(StandardCharsets.UTF_8)
)

private fun elapsedMillis(startNanos: Long): Long =
    ((System.nanoTime() - startNanos) / 1_000_000L).coerceAtLeast(0L)

private fun errorIssue(
    code: String,
    message: String,
    nodeIds: List<String> = emptyList(),
    edgeIds: List<String> = emptyList()
) = TopologyIssue(
    code = code,
    message = message,
    severity = TopologyIssueSeverity.ERROR,
    nodeIds = nodeIds,
    edgeIds = edgeIds
)

private fun RoofTopology.deepCopyForGeometryEngine() = copy(
    origin = origin.copy(),
    nodes = nodes.map { it.copy() },
    edges = edges.map { it.copy() }
)
