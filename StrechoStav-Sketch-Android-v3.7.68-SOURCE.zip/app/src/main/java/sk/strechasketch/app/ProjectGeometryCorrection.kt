package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

enum class GeometryCorrectionKind { OUTLINE, INTERNAL }

data class GeometryCorrectionLimits(
    val maxInternalBoundaryShiftM: Double = HierarchicalInternalLineSolver.MAX_BOUNDARY_SHIFT_M
)

/** Atomic commit of one already-solved geometry preview. No second solver runs here. */
object ProjectGeometryCorrection {
    fun contextFingerprint(project: RoofProject): String = ProjectJson.encode(project)

    fun apply(
        project: RoofProject,
        preview: RoofSolverPreview,
        kind: GeometryCorrectionKind = GeometryCorrectionKind.OUTLINE,
        expectedContextFingerprint: String? = null,
        limits: GeometryCorrectionLimits = GeometryCorrectionLimits()
    ): TopologyApplyResult {
        if (expectedContextFingerprint != null && contextFingerprint(project) != expectedContextFingerprint) {
            return rejection(
                "STALE_SOLVER_CONTEXT",
                "Pôdorys alebo význam strešného traktu sa po vytvorení náhľadu zmenil; korekciu treba prepočítať."
            )
        }
        val current = RoofTopologyMigration.fromProject(project)
        if (!sameExactOrderedState(current, preview.original)) {
            return rejection(
                "STALE_SOLVER_PREVIEW",
                "Nákres sa po vytvorení náhľadu zmenil; korekciu treba prepočítať."
            )
        }
        if (!sameOrderedIdentityAndSemantics(preview.original, preview.proposed)) {
            return topologyMutationRejected()
        }
        val ownershipIssue = coordinateOwnershipIssue(preview.original, preview.proposed, kind, limits)
        if (ownershipIssue != null) return TopologyApplyResult(false, listOf(ownershipIssue))
        if (!validBoundary(preview.original, preview.proposed, kind, limits)) {
            return rejection(
                "CORRECTION_BOUNDARY_INVALID",
                "Korekcia by vytvorila neplatný, prekrížený alebo nesprávne zaokrúhlený obrys. Operácia bola zrušená."
            )
        }

        val rollback = ProjectGeometryState.capture(project)
        return try {
            // The preview is authoritative. normalizeGrid=false is essential: a hidden second
            // quantisation used to move internal endpoints again after the user confirmed them.
            val beforeGraph = RoofGraphFactory.fromTopology(
                preview.original,
                project.roofGraph,
                normalizeGrid = false
            )
            val afterGraph = RoofGraphFactory.fromTopology(
                preview.proposed,
                beforeGraph,
                normalizeGrid = false
            )
            if (!ProjectPlanSynchronizer.apply(
                    project,
                    beforeGraph,
                    afterGraph,
                    normalizeBoundaryGrid = false
                )
            ) {
                rollback.restore(project)
                return rejection(
                    "PROJECT_PLAN_SYNCHRONIZATION_FAILED",
                    "Opravu nemožno preniesť do pôdorysu stien a strešných traktov."
                )
            }

            // Never persist the lossy Graph -> Topology mirror. It may sort records and omit
            // provenance. The confirmed authored candidate keeps exact identity and ordering.
            project.roofTopology = preview.proposed.deepCopyForCommit()
            val canonical = if (kind == GeometryCorrectionKind.INTERNAL) {
                DefaultRoofGeometryEngine.canonicalize(
                    correctedAuthoredTopology = preview.proposed,
                    footprintContext = WallFootprintSolver.context(project),
                    previousGraph = afterGraph
                )
            } else null
            if (canonical != null && !canonical.isValid) {
                rollback.restore(project)
                return TopologyApplyResult(false, canonical.issues)
            }
            project.roofGraph = canonical?.graph ?: RoofGraphFactory.fromTopology(
                preview.proposed,
                afterGraph,
                normalizeGrid = false
            )
            // ProjectPlanSynchronizer deliberately invalidates the tract signature when the
            // boundary moved. The deformed rectangles are only a temporary semantic carrier;
            // stamping them with a fresh signature would falsely present a stale decomposition
            // as if it had been rebuilt from the corrected canonical polygon.

            val committed = project.roofTopology
            val sourceLineIds = rollback.lines.map(RoofLine::id)
            val sourceLineIdSet = sourceLineIds.toSet()
            val lineOrderMatches = project.lines.map(RoofLine::id)
                .filter { it in sourceLineIdSet } == sourceLineIds
            val lineInventoryMatches = project.lines.map { it.id to it.type }.toSet() ==
                preview.original.edges.filterNot { it.boundary }.map { it.id to it.type }.toSet()
            val componentMeaningMatches = semanticPartMeaning(rollback.wallFootprintParts) ==
                semanticPartMeaning(project.wallFootprintParts)
            if (committed == null ||
                !sameOrderedIdentityAndSemantics(preview.original, committed) ||
                !sameCoordinates(preview.proposed, committed) ||
                !lineInventoryMatches || !lineOrderMatches ||
                project.edgeTypes != rollback.edgeTypes || !componentMeaningMatches
            ) {
                rollback.restore(project)
                return topologyMutationRejected()
            }

            val validation = canonical?.issues ?: RoofTopologySolver.validate(preview.proposed)
            TopologyApplyResult(true, validation)
        } catch (_: Throwable) {
            rollback.restore(project)
            rejection(
                "GEOMETRY_CORRECTION_TRANSACTION_FAILED",
                "Korekcia bola úplne vrátená, pretože sa ju nepodarilo bezpečne uložiť."
            )
        }
    }

    /** Compatibility for older callers/tests. false now means the explicit INTERNAL policy. */
    fun apply(
        project: RoofProject,
        preview: RoofSolverPreview,
        allowBoundaryChanges: Boolean
    ): TopologyApplyResult = apply(
        project = project,
        preview = preview,
        kind = if (allowBoundaryChanges) GeometryCorrectionKind.OUTLINE else GeometryCorrectionKind.INTERNAL
    )

    private fun coordinateOwnershipIssue(
        original: RoofTopology,
        candidate: RoofTopology,
        kind: GeometryCorrectionKind,
        limits: GeometryCorrectionLimits
    ): TopologyIssue? {
        val boundaryIds = original.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val candidateNodes = candidate.nodes.associateBy { it.id }
        original.nodes.forEach { source ->
            val result = candidateNodes.getValue(source.id)
            if (!result.x.isFinite() || !result.y.isFinite()) {
                return issue("NON_FINITE_CORRECTION", "Korekcia vytvorila neplatnú súradnicu.")
            }
            if (source.locked && (source.x != result.x || source.y != result.y)) {
                return issue("LOCKED_NODE_CHANGED", "Solver sa pokúsil posunúť uzamknutý bod ${source.id}.")
            }
            if (kind == GeometryCorrectionKind.OUTLINE && source.id !in boundaryIds &&
                (source.x != result.x || source.y != result.y)
            ) {
                return issue(
                    "OUTLINE_INTERNAL_COORDINATE_CHANGED",
                    "Korekcia obrysu nesmie meniť vnútorné línie."
                )
            }
            if (kind == GeometryCorrectionKind.INTERNAL && source.id in boundaryIds &&
                hypot(result.x - source.x, result.y - source.y) > limits.maxInternalBoundaryShiftM + 1e-8
            ) {
                return issue(
                    "INTERNAL_BOUNDARY_SHIFT_LIMIT",
                    "Vnútorný solver prekročil povolený posun obrysu ${limits.maxInternalBoundaryShiftM * 1000.0} mm."
                )
            }
        }
        return null
    }

    private fun sameOrderedIdentityAndSemantics(original: RoofTopology, candidate: RoofTopology): Boolean {
        if (original.origin != candidate.origin || original.schemaVersion != candidate.schemaVersion) return false
        if (original.gridRotationDeg.isFinite()) {
            if (!candidate.gridRotationDeg.isFinite() ||
                abs(original.gridRotationDeg - candidate.gridRotationDeg) > 1e-10
            ) return false
        }
        if (original.nodes.map { it.id } != candidate.nodes.map { it.id }) return false
        if (original.edges.map { it.id } != candidate.edges.map { it.id }) return false
        if (original.edges != candidate.edges) return false
        return original.nodes.indices.all { index ->
            val source = original.nodes[index]
            val result = candidate.nodes[index]
            source.copy(x = result.x, y = result.y) == result
        }
    }

    private fun sameExactOrderedState(left: RoofTopology, right: RoofTopology): Boolean {
        if (left.origin != right.origin || left.schemaVersion != right.schemaVersion) return false
        if (left.gridRotationDeg.isFinite() != right.gridRotationDeg.isFinite()) return false
        if (left.gridRotationDeg.isFinite() && abs(left.gridRotationDeg - right.gridRotationDeg) > 1e-10) return false
        return left.nodes == right.nodes && left.edges == right.edges
    }

    private fun sameCoordinates(expected: RoofTopology, actual: RoofTopology): Boolean =
        expected.nodes.map { Triple(it.id, it.x, it.y) } == actual.nodes.map { Triple(it.id, it.x, it.y) }

    private fun validBoundary(
        original: RoofTopology,
        candidate: RoofTopology,
        kind: GeometryCorrectionKind,
        limits: GeometryCorrectionLimits
    ): Boolean {
        val originalCycle = RoofTopologyMigration.orderedBoundary(original) ?: return false
        val candidateCycle = RoofTopologyMigration.orderedBoundary(candidate) ?: return false
        if (originalCycle.first != candidateCycle.first || originalCycle.second != candidateCycle.second) return false
        val originalNodes = original.nodes.associateBy { it.id }
        val candidateNodes = candidate.nodes.associateBy { it.id }
        val before = originalCycle.first.map { originalNodes.getValue(it) }
        val after = candidateCycle.first.map { candidateNodes.getValue(it) }
        val rotation = MetricPlanGrid.axisDeg(candidate) ?: 0.0
        if (after.any { !MetricPlanGrid.isOnGrid(LocalPoint(it.x, it.y), rotation) }) return false
        if (MetricPlanGrid.offDirectionEdgeIds(candidate, includeBoundary = true, includeInternal = false).isNotEmpty()) {
            return false
        }
        if (kind == GeometryCorrectionKind.INTERNAL && before.indices.any { index ->
                hypot(after[index].x - before[index].x, after[index].y - before[index].y) >
                    limits.maxInternalBoundaryShiftM + 1e-8
            }
        ) return false
        val beforeArea = signedArea(before)
        val afterArea = signedArea(after)
        if (abs(beforeArea) < 1e-8 || abs(afterArea) < 1e-8 || beforeArea * afterArea <= 0.0) return false
        if (after.indices.any { index ->
                val next = after[(index + 1) % after.size]
                hypot(next.x - after[index].x, next.y - after[index].y) < 0.05 - 1e-8
            }
        ) return false
        for (i in after.indices) for (j in i + 1 until after.size) {
            if (j == (i + 1) % after.size || i == (j + 1) % after.size) continue
            val a = after[i]
            val b = after[(i + 1) % after.size]
            val c = after[j]
            val d = after[(j + 1) % after.size]
            if (properIntersection(a, b, c, d)) return false
        }
        return true
    }

    private fun signedArea(nodes: List<TopologyNode>): Double = nodes.indices.sumOf { index ->
        val next = nodes[(index + 1) % nodes.size]
        nodes[index].x * next.y - next.x * nodes[index].y
    } / 2.0

    private fun properIntersection(
        a: TopologyNode,
        b: TopologyNode,
        c: TopologyNode,
        d: TopologyNode
    ): Boolean {
        fun cross(p: TopologyNode, q: TopologyNode, r: TopologyNode): Double =
            (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
        return cross(a, b, c) * cross(a, b, d) < -1e-8 &&
            cross(c, d, a) * cross(c, d, b) < -1e-8
    }

    private data class PartMeaning(
        val id: String,
        val type: WallFootprintPartType,
        val source: WallFootprintPartSource,
        val hostPartId: String?,
        val sourceObjectId: String?
    )

    private fun semanticPartMeaning(parts: List<WallFootprintPart>) = parts.map {
        PartMeaning(it.id, it.type, it.source, it.hostPartId, it.sourceObjectId)
    }

    private fun topologyMutationRejected() = rejection(
        "INTERNAL_TOPOLOGY_MUTATION_REJECTED",
        "Korekcia zmenila počet, poradie, spojenie alebo typ línie; celá operácia bola zrušená."
    )

    private fun rejection(code: String, message: String) = TopologyApplyResult(
        applied = false,
        issues = listOf(issue(code, message))
    )

    private fun issue(code: String, message: String) = TopologyIssue(
        code = code,
        message = message,
        severity = TopologyIssueSeverity.ERROR
    )

    private data class ProjectGeometryState(
        val polygon: List<GeoPoint>,
        val wallFootprint: List<GeoPoint>,
        val wallFootprintParts: List<WallFootprintPart>,
        val wallFootprintPartsSignature: String,
        val lines: List<RoofLine>,
        val objects: List<RoofObject>,
        val edgeTypes: Map<Int, LineType>,
        val roofTopology: RoofTopology?,
        val roofGraph: RoofGraph?,
        val geometryGridOriginLat: Double,
        val geometryGridOriginLon: Double,
        val geometryGridRotationDeg: Double,
        val updatedAt: Long
    ) {
        fun restore(project: RoofProject) {
            project.polygon = polygon.map(GeoPoint::copy).toMutableList()
            project.wallFootprint = wallFootprint.map(GeoPoint::copy).toMutableList()
            project.wallFootprintParts = wallFootprintParts.map { part ->
                part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
            }.toMutableList()
            project.wallFootprintPartsSignature = wallFootprintPartsSignature
            project.lines = lines.map { it.copy(start = it.start.copy(), end = it.end.copy()) }.toMutableList()
            project.objects = objects.map { it.copy(center = it.center.copy()) }.toMutableList()
            project.edgeTypes = edgeTypes.toMutableMap()
            project.roofTopology = roofTopology
            project.roofGraph = roofGraph
            project.geometryGridOriginLat = geometryGridOriginLat
            project.geometryGridOriginLon = geometryGridOriginLon
            project.geometryGridRotationDeg = geometryGridRotationDeg
            project.updatedAt = updatedAt
        }

        companion object {
            fun capture(project: RoofProject) = ProjectGeometryState(
                polygon = project.polygon.map(GeoPoint::copy),
                wallFootprint = project.wallFootprint.map(GeoPoint::copy),
                wallFootprintParts = project.wallFootprintParts.map { part ->
                    part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
                },
                wallFootprintPartsSignature = project.wallFootprintPartsSignature,
                lines = project.lines.map { it.copy(start = it.start.copy(), end = it.end.copy()) },
                objects = project.objects.map { it.copy(center = it.center.copy()) },
                edgeTypes = project.edgeTypes.toMap(),
                roofTopology = project.roofTopology,
                roofGraph = project.roofGraph,
                geometryGridOriginLat = project.geometryGridOriginLat,
                geometryGridOriginLon = project.geometryGridOriginLon,
                geometryGridRotationDeg = project.geometryGridRotationDeg,
                updatedAt = project.updatedAt
            )
        }
    }

    private fun RoofTopology.deepCopyForCommit() = copy(
        origin = origin.copy(),
        nodes = nodes.map { it.copy() },
        edges = edges.map { it.copy() }
    )
}
