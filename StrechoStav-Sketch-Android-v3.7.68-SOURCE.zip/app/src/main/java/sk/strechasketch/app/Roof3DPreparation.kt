package sk.strechasketch.app

data class Roof3DPreparationResult(
    val topology: RoofTopology,
    val graph: RoofGraph,
    val planeSolution: RoofPlaneSolution,
    val topologyWasAdjusted: Boolean,
    val planeWasApproximated: Boolean
)

/** Single solved-graph preparation path shared by live 3D, PDF, IFC and quantities. */
object Roof3DPreparation {
    fun prepare(project: RoofProject): Roof3DPreparationResult {
        val footprintContext = WallFootprintSolver.context(project)
        val authored = project.roofTopology
            ?: project.roofGraph?.takeIf { it.geometryEngineVersion == 0 }?.toTopology()
            // A solved graph is never converted back into an authored drawing because that
            // would erase endpoint aliases, locks, ordering and provenance.
            ?: RoofTopologyMigration.fromLegacyProject(project.copy())

        // Pure incidence construction: no second coordinate solver runs after confirmation.
        val geometry = DefaultRoofGeometryEngine.canonicalize(
            correctedAuthoredTopology = authored,
            footprintContext = footprintContext,
            previousGraph = project.roofGraph
        )
        if (!geometry.isValid || geometry.graph == null) {
            val emptyGraph = RoofGraph(
                origin = authored.origin.copy(),
                nodes = emptyMap(),
                edges = emptyMap(),
                faces = emptyMap(),
                gridRotationDeg = authored.gridRotationDeg,
                geometryEngineVersion = DefaultRoofGeometryEngine.ENGINE_VERSION,
                authoredGeometrySignature = geometry.signature
            )
            val blocking = geometry.issues.ifEmpty {
                listOf(
                    TopologyIssue(
                        code = "ROOF_SUBDIVISION_REJECTED",
                        message = "Strešnú sieť nemožno zostaviť ako úplnú planárnu subdivíziu.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            }.map { issue ->
                RoofPlaneSolverIssue(
                    code = "PLAN_${issue.code}",
                    message = issue.message,
                    blocking = issue.severity == TopologyIssueSeverity.ERROR
                )
            }
            val planes = RoofPlaneSolution(emptyGraph, blocking, 0.0)
            return Roof3DPreparationResult(
                topology = geometry.solvedTopology,
                graph = emptyGraph,
                planeSolution = planes,
                topologyWasAdjusted = geometry.solvedTopology != authored,
                planeWasApproximated = false
            )
        }

        val graph = GableTractSlopeSolver.apply(
            geometry.graph,
            project.slopeDeg,
            footprintContext
        )
        val flatRoofMode = project.shape == RoofShape.FLAT || graph.edges.values.any {
            it.boundary && it.semanticRole == EdgeSemantic.ATTIC
        }
        val coverageIssues = RoofSurfaceCoverageValidator.validate(graph)
        val exact = if (coverageIssues.isEmpty()) RoofPlaneSolver.solve(
            graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
        ) else RoofPlaneSolution(
            graph = graph,
            issues = coverageIssues,
            maximumCoplanarityResidualM = 0.0
        )
        // Existing Z-only approximation is not a topology fallback: it cannot change XY,
        // incidence or the anthracite face inventory.
        val planes = if (coverageIssues.isEmpty() && exact.hasBlockingIssues) {
            RoofPlaneSolver.solveForRendering(
                graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
            )
        } else exact
        return Roof3DPreparationResult(
            topology = geometry.solvedTopology,
            graph = planes.graph,
            planeSolution = planes,
            topologyWasAdjusted = geometry.solvedTopology != authored,
            planeWasApproximated = planes.issues.any { it.code == "APPROXIMATED_HARD_CONSTRAINTS" }
        )
    }
}
