package sk.strechasketch.app

/**
 * Converts references produced by the disposable 3D incidence graph back to authored IDs.
 *
 * 3D is allowed to split an authored edge into `-segment-...` and `::virtual-...` records so
 * faces can be solved. Those IDs must never be stored in [RoofProject]: after another correction
 * the runtime split may be different even though the user's footprint and lines did not change.
 */
internal object AuthoredRoofReferenceResolver {
    fun authoredGraph(project: RoofProject): RoofGraph {
        val topology = project.roofTopology
            ?: project.roofGraph?.takeIf { it.geometryEngineVersion == 0 }?.toTopology()
            ?: RoofTopologyMigration.fromLegacyProject(project.copy())
        val context = WallFootprintSolver.context(project)
        project.roofGraph?.takeIf { candidate ->
            DefaultRoofGeometryEngine.isGraphCompatible(candidate, topology, context)
        }?.let { return it }
        return DefaultRoofGeometryEngine.canonicalize(
            correctedAuthoredTopology = topology,
            footprintContext = context,
            previousGraph = project.roofGraph
        ).graph ?: RoofGraph(
            origin = topology.origin.copy(),
            nodes = emptyMap(),
            edges = emptyMap(),
            faces = emptyMap(),
            gridRotationDeg = topology.gridRotationDeg
        )
    }

    fun authoredEdgeId(project: RoofProject, runtimeEdgeId: String?): String? {
        runtimeEdgeId ?: return null
        val authoredIds = (project.roofTopology?.edges?.map(TopologyEdge::id)
            ?: project.roofGraph?.edges?.keys?.toList()).orEmpty()
        if (runtimeEdgeId in authoredIds) return runtimeEdgeId
        project.roofGraph?.edges?.get(runtimeEdgeId)?.sourceEdgeIds
            ?.filter { it in authoredIds }
            ?.singleOrNull()
            ?.let { return it }
        return authoredIds.asSequence()
            .filter { authoredId -> isRuntimeChildOf(runtimeEdgeId, authoredId) }
            .maxByOrNull(String::length)
    }

    fun authoredFaceIdAt(
        project: RoofProject,
        runtimeOrigin: GeoPoint,
        runtimePoint: LocalPoint,
        preferredFaceId: String? = null
    ): String? {
        val graph = authoredGraph(project)
        val geographicPoint = Geometry.toGeo(runtimePoint, runtimeOrigin)
        val point = Geometry.toLocal(geographicPoint, graph.origin)
        preferredFaceId?.let(graph.faces::get)
            ?.takeIf { face -> contains(graph, face, point) }
            ?.let(GraphFace::id)
            ?.let { return it }
        return graph.faces.values.firstOrNull { face -> contains(graph, face, point) }?.id
    }

    /** Accepts old runtime references as input too, so existing projects repair themselves. */
    fun edgeIdsMatch(storedReferenceId: String?, runtimeEdgeId: String): Boolean {
        storedReferenceId ?: return false
        return storedReferenceId == runtimeEdgeId ||
            isRuntimeChildOf(runtimeEdgeId, storedReferenceId) ||
            isRuntimeChildOf(storedReferenceId, runtimeEdgeId)
    }

    fun edgeIdsMatch(storedReferenceId: String?, runtimeEdge: GraphEdge): Boolean {
        storedReferenceId ?: return false
        return storedReferenceId == runtimeEdge.id ||
            storedReferenceId in runtimeEdge.sourceEdgeIds ||
            storedReferenceId in runtimeEdge.sourceIds ||
            edgeIdsMatch(storedReferenceId, runtimeEdge.id)
    }

    fun runtimeEdgeForReference(
        graph: RoofGraph,
        storedReferenceId: String,
        near: LocalPoint
    ): GraphEdge? = graph.edges.values.asSequence()
        .filter { edge -> edgeIdsMatch(storedReferenceId, edge) }
        .minByOrNull { edge ->
            val a = graph.nodes[edge.startNodeId] ?: return@minByOrNull Double.MAX_VALUE
            val b = graph.nodes[edge.endNodeId] ?: return@minByOrNull Double.MAX_VALUE
            Geometry.distanceToSegment(near, LocalPoint(a.x, a.y), LocalPoint(b.x, b.y))
        }

    private fun isRuntimeChildOf(candidateId: String, authoredId: String): Boolean =
        candidateId.startsWith("$authoredId::virtual-") ||
            candidateId.startsWith("$authoredId-segment-") ||
            candidateId.startsWith("$authoredId::noded-")

    private fun contains(graph: RoofGraph, face: GraphFace, point: LocalPoint): Boolean {
        val outer = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        if (outer.size < 3 || !Geometry.pointInPolygon(point, outer)) return false
        return face.holeNodeIdLoops.none { loop ->
            val hole = loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
            hole.size >= 3 && Geometry.pointInPolygon(point, hole)
        }
    }
}
