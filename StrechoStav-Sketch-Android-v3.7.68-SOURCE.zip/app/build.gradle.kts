plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val legacyDebugKeystore = file("strechostav-debug.keystore")

android {
    namespace = "sk.strechasketch.app"
    compileSdk = 35

    buildFeatures {
        buildConfig = true
    }

    defaultConfig {
        applicationId = "sk.strechasketch.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 88
        versionName = "3.7.68"
    }

    signingConfigs {
        getByName("debug") {
            if (legacyDebugKeystore.isFile) {
                storeFile = legacyDebugKeystore
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("org.locationtech.jts:jts-core:1.20.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
