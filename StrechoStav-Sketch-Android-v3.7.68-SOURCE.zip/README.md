# StrechoStav Sketch pre Android 3.7.68

Offline-first nástroj pre pracovný tok:

`2D obrys → topologická sieť → typológia → parametrický 3D model → výkaz → rozsah prác → PDF / IFC`

## IFC4X3 BIM export

Karta 8 ponúka `Generovať IFC BIM model`. Export používa rovnaký vyriešený `RoofGraph` ako 3D, PDF a výkaz a vytvára štandardnú priestorovú štruktúru, `IfcRoof` a samostatný `IfcSlab` pre každú strešnú plochu. Súbor deklaruje `IFC4X3_ADD2`, zachováva otvory, stabilné FaceId/GUID, štandardné Qto a úplný kanonický StrechoStav JSON so SHA-256 pre budúci BIM Viewer.

Implementovaný je interný sanity validator. Externá schema/normative validácia cez buildingSMART Validation Service nie je súčasťou runtime aplikácie a musí sa vykonať samostatne vo vývojovom procese.

## Jedenásť pracovných kariet

1. **Obrys** – ZBGIS ortofoto alebo jeden PDF/JPG podklad, freehand do 10 bodov a presná korekcia.
2. **Strešné trakty** – automatický rozklad `WallFootprint` na hlavný trakt, rizalit, výklenok, samostatné krídlo a nadstavbu; dlhé podržanie umožní návrh dopresniť.
3. **Vnútorné línie** – jeden spoločný solver zarovná nárožia a úžľabia presne na ±45°, vystredí hrebeň v jeho trakte/krídle/výstupku, spojí blízke konce v jednom fyzickom uzle a v nevyhnutnom prípade smie posunúť existujúci bod obrysu najviac o 300 mm.
4. **Typológia** – zamknuté XY; dlhé podržanie hrany mení iba jej technický význam.
5. **Vikiere a strojovne** – dlaždica určí typ a klepnutie polohu; rozmery sa nastavujú parametricky v 3D.
6. **3D geometria** – model z `FaceId` a rovín `z = ax + by + c`, nie z názvu strechy.
7. **3D prvky** – parametrické kóty a polohy komínov, okien, výlezov, vikierov, strojovní, šácht a terás.
8. **Žľaby a zvody** – systémové rohy, háky, objímky, ručné zvody a ich ukončenia.
9. **Výkaz výmer** – skutočné 3D plochy a 3D dĺžky s auditom podľa `FaceId`/`EdgeId`.
10. **Rozsah prác** – lokálny katalóg, automatické množstvá, ručný override a editovateľné ceny.
11. **PDF** – situácia osadenia, štyri izometrické pohľady, technický pôdorys, výkaz, rozpočet a export IFC.

## Jednotný geometrický reťazec

Pôdorys je jediná autoritatívna definícia tvaru. Z neho vznikne topológia a vyriešené antracitové strešné plochy. Až z ich presných rovín a obvodových úsekov sa odvodzujú čierny obvod, podbitie, strešná skladba, horné profily stien, žľaby a zvody. Dočasné priesečníky a segmenty potrebné na zostavenie 3D plôch zostávajú iba v pamäti a nikdy nenahradia používateľské línie.

Pri prekrývaní konštrukčných častí platí poradie `hlavný trakt → krídlo → výstupok → výklenok`. Zmena rozmeru nižšej priority preto nemení rovinu ani geometriu hlavného traktu.

## Canonical RoofGraph

Schéma projektu 11 oddeľuje nezmenenú autorskú kresbu od kanonickej vyriešenej subdivízie. Fyzický obrys a používateľské vnútorné línie zostávajú zdrojom pravdy; odvodený `RoofGraph` s kontrolovaným podpisom používa rovnakú incidenciu pre 3D, PDF, výkaz aj IFC:

- `GraphNode(id, x, y, z, lockX, lockY, lockZ)`
- `GraphEdge(id, startNodeId, endNodeId, boundary, semanticRole, adjacentFaceIds, elevationZ)`
- `GraphFace(id, orderedNodeIds, holeNodeIdLoops, orderedEdgeIds, plane, slopeConstraint, elevationConstraints, componentId, hostFaceId)`
- tvrdé dĺžkové a všeobecné dimension constraints

ID zostávajú stabilné pri parametrickej zmene. Spoločný `NodeId` je jediný spoločný 3D bod všetkých incidentných plôch. Staré projekty sa automaticky migrujú; `RoofShape` sa uchováva iba ako legacy metadata a nový generátor ho nepoužíva.

## Presný univerzálny solver 3.1

- smer sklonu je jednoznačne `downhillDirection`; gradient roviny smeruje opačne,
- staré grafy so smerom interpretovaným ako „uphill“ sa pri načítaní automaticky invertujú,
- incidencie `Node–Face`, pevné výšky, bodové kóty, vpuste a nízke hrany sa riešia ako presné lineárne rovnice,
- presný audit hard constraints zostáva bez aproximácie a nekompatibilný systém označí ako chybu,
- 3D, bitmapový renderer, PDF a výkaz používajú až po neúspešnom presnom audite spoločný deterministický aproximačný režim; incidencie a ID hrán sa nemenia a odchýlka zostáva evidovaná v audite,
- podporované sú `RAKE`, `LOW_EDGE`, `ELEVATED_LOW_EDGE`, `STEP` a `OPENING_BOUNDARY`,
- schéma podporuje otvory plôch, sekundárny `RoofComponent`, hostiteľskú plochu a `DrainPointConstraint`,
- stenový pôdorys je oddelený od fyzickej hranice strechy,
- zánik hrebeňa, hrany, plochy alebo polvalbového rezu je explicitná topologická udalosť,
- kanonický JSON adaptér normalizuje mm/cm/m, stabilné ID a downhill sklony,
- komíny, strešné okná, výlezy a prestupy sú odvodené 3D telesá a nevlastnia topológiu strechy.

## Dve nezávislé 3D vykresľovacie cesty

- interaktívna obrazovka používa `GLSurfaceView`, OpenGL ES 3.0, VBO a GLSL `#version 300 es`, pričom zdrojové texty shaderov sú priamo v `Roof3DView.kt`,
- statické 3D obrázky pre PDF používajú samostatný Kotlin Z-buffer s per-pixel testom plôch, hrán a loga, takže skryté steny ani hrany nepresvitajú,
- PDF izometrie používajú samostatný fotorealistický profil s modelovo stabilným materiálom, filmovým tónovaním, mäkkým kontaktným tieňovaním a jemnejšími obrysmi; technický profil ostatných obrazoviek zostáva predvolený,
- `RoofBitmapRenderer.kt` je samostatný Kotlin/Canvas renderer, ktorý vytvára deterministický `Bitmap` bez EGL alebo OpenGL kontextu,
- oba renderery čítajú rovnaký validovaný odvodený `RoofMesh`, takže nemenia topológiu ani výpočtový model,
- materiál je explicitnou vlastnosťou vrcholu: strecha zostáva antracitová s kontrolovanou odtieňovou zmenou približne do 20 % a steny sú svetlobéžové bez zámeny materiálu pri otočení,
- skutočné logo StrechoStav s obrysom strechy a komínom je textúrované na dvoch najväčších strešných plochách; zdrojové SVG je v `app/src/main/assets/strechostav-logo.svg`,
- 3D kóty používajú hĺbkový test, kandidátne polohy a pixelovú kolíznu kontrolu štítkov a čiar; skrytá alebo kolízna kóta sa nepretlačí pred model,
- pravouhlý štvorstranný pôdorys má dve spoločné kóty protiľahlých strán; jedna zmena ortogonalizuje pôdorys a parametricky transformuje incidentné vnútorné uzly bez zmeny ID,
- priamo v modeli sú editovateľné kóty pôdorysu, výšky stien, presahu strechy a značka sklonu; L/T/H pôdorysy si ponechávajú potrebný vyšší počet kót,
- plochá strecha funguje ako jedna vnútorná spádová rovina bez povinného hrebeňa; atika sa počíta samostatne, má predvolenú výšku 300 mm, vodorovnú hornú korunu a vlastnú editovateľnú kótu,
- karta Rozsah prác používa statický bitmapový náhľad a PDF vkladá dve bitmapové izometrie bez potreby predchádzajúceho otvorenia 3D obrazovky.

## Mapy a offline režim

- používateľská mapová vrstva je **ZBGIS ortofoto** (WMS 1.3.0, EPSG:3857), bez API kľúča,
- PDF/JPG/PNG/WebP podklad funguje úplne offline,
- viditeľné ZBGIS dlaždice sa ukladajú do persistentnej cache konkrétneho projektu,
- Nominatim a Overpass sú iba voliteľné online vstupy pre adresu/GPS a import obrysu budovy,
- OSM mapa, OSM terén a trvalý nástroj Posun nie sú používateľské voľby,
- podržanie prsta 1 sekundu na voľnom mieste aktivuje dočasný posun; pinch zoomuje podklad aj geometriu.

## Zostavenie

Projekt nepotrebuje Google API secret:

```text
gradle :app:testDebugUnitTest :app:assembleDebug
```

Vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2. GitHub Actions workflow v `.github/workflows/build-apk.yml` zostaví najnovší ZIP zdrojového projektu. APK vznikne v:

`app/build/outputs/apk/debug/app-debug.apk`

## Presnosť

Geometria, 3D, výkaz, rozsah prác a PDF sa počítajú lokálne a deterministicky. Údaje odvodené iba z ortofotomapy sú orientačné; pred výrobou alebo realizáciou ich treba overiť meraním na stavbe.
