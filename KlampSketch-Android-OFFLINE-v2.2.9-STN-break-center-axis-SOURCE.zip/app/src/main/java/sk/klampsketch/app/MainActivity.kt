package sk.klampsketch.app

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var database: AppDatabase
    private lateinit var currentProject: ProjectRecord
    private val selectedDrawingIds = linkedSetOf<Long>()
    private var currentDraft: DrawingRecord? = null
    private var drawingView: DrawingView? = null
    private var editorStatus: TextView? = null
    private var editorMetadata: TextView? = null
    private var editorPhoto: ImageView? = null
    private var inEditor = false
    private var photoOutputFile: File? = null
    private var pendingPdfDrawings: List<DrawingRecord>? = null
    private var editingBackProfile = false
    private var frontProfileButton: Button? = null
    private var backProfileButton: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        database = AppDatabase(this)
        currentProject = database.ensureDefaultProject()
        showHome()
    }

    private fun showHome() {
        inEditor = false
        currentDraft = null
        drawingView = null
        editingBackProfile = false
        frontProfileButton = null
        backProfileButton = null
        val root = screenRoot()

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(brandBlue)
        }
        toolbar.addView(
            TextView(this).apply {
                text = "KlampSketch Offline"
                setTextColor(Color.WHITE)
                textSize = 21f
                setTypeface(typeface, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        toolbar.addView(
            compactButton(currentProject.name) { showProjectPicker() }.apply {
                setTextColor(brandBlue)
                background = roundedBackground(Color.WHITE, 12f)
            }
        )
        root.addView(toolbar)

        val projectInfo = TextView(this).apply {
            text = buildString {
                append("STAVBA: ${currentProject.name}")
                if (currentProject.customer.isNotBlank()) append("\nZákazník: ${currentProject.customer}")
                if (currentProject.address.isNotBlank()) append("\n${currentProject.address}")
            }
            textSize = 15f
            setTextColor(darkText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(14), dp(16), dp(8))
        }
        root.addView(projectInfo)

        val actions = horizontalActions(
            "＋ Nová stavba" to { showNewProjectDialog() },
            "✎ Nový nákres" to { openEditor(null) },
            "PDF z vybraných" to { generateSelectedPdf() }
        )
        root.addView(actions)

        val drawings = database.listDrawings(currentProject.id)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        if (drawings.isEmpty()) {
            list.addView(
                TextView(this).apply {
                    text = "V tejto stavbe zatiaľ nie je žiadny nákres.\nZačnite tlačidlom „Nový nákres“."
                    gravity = Gravity.CENTER
                    textSize = 17f
                    setTextColor(mutedText)
                    setPadding(dp(20), dp(80), dp(20), dp(80))
                }
            )
        } else {
            drawings.forEach { drawing -> list.addView(drawingCard(drawing)) }
        }
        scroll.addView(list)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        setContentView(root)
    }

    private fun drawingCard(drawing: DrawingRecord): View {
        val metrics = calculateMetrics(drawing)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundedBackground(Color.WHITE, 16f, strokeColor = Color.rgb(211, 222, 230))
        }
        val params = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        params.setMargins(0, 0, 0, dp(12))
        card.layoutParams = params

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val select = CheckBox(this).apply {
            isChecked = drawing.id in selectedDrawingIds
            contentDescription = "Vybrať ${drawing.name} do PDF"
            setOnCheckedChangeListener { _, checked ->
                if (checked) selectedDrawingIds += drawing.id else selectedDrawingIds -= drawing.id
            }
        }
        header.addView(select)
        header.addView(
            TextView(this).apply {
                text = drawing.name
                textSize = 18f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(darkText)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(
            TextView(this).apply {
                text = drawing.identifier
                textSize = 12f
                setTextColor(brandBlue)
                setTypeface(typeface, Typeface.BOLD)
            }
        )
        card.addView(header)

        card.addView(
            TextView(this).apply {
                val widthInfo = metrics.rearDevelopedWidthMm?.let {
                    "P ${metrics.developedWidthMm} / Z $it mm  •  skosený profil"
                } ?: "${metrics.developedWidthMm} mm"
                text = "$widthInfo  •  ${metrics.bends} ohybov  •  " +
                    "${drawing.quantity} ks  •  ${drawing.ral}\n" +
                    "${drawing.material}, ${formatDecimal(drawing.thicknessMm, 1)} mm  •  " +
                    "L ${formatDecimal(drawing.profileLengthM, 2)} m"
                textSize = 14f
                setTextColor(mutedText)
                setPadding(dp(4), dp(6), dp(4), dp(8))
            }
        )

        val buttons = horizontalActions(
            "Upraviť" to { openEditor(drawing) },
            "Kopírovať" to { showCopyDialog(drawing) },
            "Odstrániť" to { confirmDelete(drawing) }
        )
        card.addView(buttons)
        return card
    }

    private fun openEditor(existing: DrawingRecord?) {
        inEditor = true
        val draft = existing?.copy(
            points = existing.points.map { it.copy() }.toMutableList(),
            backPoints = existing.backPoints?.map { it.copy() }?.toMutableList()
        ) ?: DrawingRecord(
            projectId = currentProject.id,
            name = "Nový klampiarsky prvok",
            identifier = database.nextIdentifier(),
            points = mutableListOf()
        )
        draft.backPoints = draft.validBackPoints()?.let {
            ProfileGeometry.alignDirections(draft.points, it)
        }
        currentDraft = draft
        editingBackProfile = false

        val root = screenRoot()
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setBackgroundColor(brandBlue)
        }
        toolbar.addView(compactButton("‹ Späť") { confirmLeaveEditor() }.apply {
            setTextColor(Color.WHITE)
            background = roundedBackground(brandBlueDark, 10f)
        })
        toolbar.addView(
            TextView(this).apply {
                text = draft.name
                setTextColor(Color.WHITE)
                textSize = 18f
                gravity = Gravity.CENTER
                setTypeface(typeface, Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        toolbar.addView(compactButton("Uložiť") { saveCurrentDrawing() }.apply {
            setTextColor(brandBlue)
            background = roundedBackground(Color.WHITE, 10f)
        })
        root.addView(toolbar)

        editorStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(darkText)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(6))
        }
        root.addView(editorStatus)

        val profileSelector = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(2), dp(12), dp(4))
        }
        val frontButton = compactButton("Predný profil") { switchProfileSide(false) }
        val backButton = compactButton("＋ Zadný profil") { switchProfileSide(true) }
        frontProfileButton = frontButton
        backProfileButton = backButton
        profileSelector.addView(
            frontButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(0, 0, dp(4), 0)
            }
        )
        profileSelector.addView(
            backButton,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), 0, 0, 0)
            }
        )
        root.addView(profileSelector)

        drawingView = DrawingView(this).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4))
            setProfile(draft.points)
            allowPointDrag = true
            allowAngleEditing = true
            onProfileChanged = { updated ->
                currentDraft?.let { current ->
                    if (editingBackProfile) {
                        current.backPoints = updated
                    } else {
                        val existingBack = current.validBackPoints()
                        current.points = updated
                        if (existingBack != null) {
                            current.backPoints = ProfileGeometry.alignDirections(updated, existingBack)
                        }
                    }
                }
                refreshEditorSummary()
            }
            onSegmentSelected = { index, current ->
                showLengthWheel(index, current)
            }
            onAngleSelected = { index, current ->
                showAngleWheel(index, current)
            }
            onPointSelectionChanged = {
                refreshEditorSummary()
            }
        }
        root.addView(
            drawingView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply {
                setMargins(dp(8), dp(2), dp(8), dp(6))
            }
        )

        val tools = horizontalActions(
            "Nový tvar" to { resetActiveProfile() },
            "Vymazať bod" to { deleteSelectedPoint() },
            "Zrušiť zadný" to { removeBackProfile() },
            "Údaje" to { showMetadataDialog() },
            "3D náhľad" to { show3DPreview() },
            "Fotoaparát" to { requestCamera() },
            "Galéria" to { openGallery() }
        )
        root.addView(tools)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        editorPhoto = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundedBackground(Color.rgb(231, 237, 241), 10f)
        }
        bottom.addView(editorPhoto, LinearLayout.LayoutParams(dp(72), dp(60)))
        editorMetadata = TextView(this).apply {
            textSize = 13f
            setTextColor(mutedText)
            setPadding(dp(12), 0, 0, 0)
        }
        bottom.addView(
            editorMetadata,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        root.addView(bottom)
        setContentView(root)
        refreshEditorSummary()
    }

    private fun refreshEditorSummary() {
        val draft = currentDraft ?: return
        val metrics = calculateMetrics(draft)
        val activePoints = if (editingBackProfile) draft.validBackPoints() ?: draft.points else draft.points
        val sideName = if (editingBackProfile) "ZADNÝ PROFIL" else "PREDNÝ PROFIL"
        editorStatus?.text = if (activePoints.size < 2) {
            "$sideName: nakreslite profil jedným ťahom. Magic ho po zdvihnutí prsta vyrovná."
        } else {
            val widths = metrics.rearDevelopedWidthMm?.let {
                "Predný rozvin ${metrics.developedWidthMm} mm  •  zadný rozvin $it mm"
            } ?: "Rozvinutá šírka ${metrics.developedWidthMm} mm"
            val selectedInfo = drawingView?.getSelectedPointIndex()?.let { "  •  vybraný bod ${it + 1}" } ?: ""
            "$sideName  •  $widths  •  ${metrics.bends} ohybov$selectedInfo\n" +
                if (editingBackProfile) {
                    "Ťuknite na bod pre výber, na kótu pre zadný rozmer. Vymazať bod odstráni vybraný lom. Jedným prstom mimo profilu plátno posúvate, dvoma prstami zoomujete."
                } else {
                    "Ťuknite na bod pre výber, na kótu alebo uhol pre úpravu. Vymazať bod odstráni vybraný lom. Jedným prstom mimo profilu plátno posúvate, dvoma prstami zoomujete."
                }
        }
        editorMetadata?.text =
            "${draft.identifier}\n${draft.material}, ${formatDecimal(draft.thicknessMm, 1)} mm\n" +
                "${draft.ral}  •  L ${formatDecimal(draft.profileLengthM, 2)} m  •  " +
                "${draft.quantity} ks" +
                if (draft.validBackPoints() != null) "  •  skosený profil" else ""
        val path = draft.photoPath
        if (path != null && File(path).isFile) {
            editorPhoto?.setImageURI(Uri.fromFile(File(path)))
        } else {
            editorPhoto?.setImageDrawable(null)
        }
        refreshProfileButtons()
    }

    private fun switchProfileSide(back: Boolean) {
        val draft = currentDraft ?: return
        if (back && draft.points.size < 2) {
            Toast.makeText(this, "Najprv vytvorte predný profil.", Toast.LENGTH_SHORT).show()
            return
        }
        if (back && draft.validBackPoints() == null) {
            draft.backPoints = draft.points.map { it.copy() }.toMutableList()
        }
        editingBackProfile = back
        drawingView?.apply {
            allowPointDrag = !back
            allowAngleEditing = !back
            setProfile(if (back) draft.validBackPoints() ?: draft.points else draft.points)
        }
        refreshEditorSummary()
    }

    private fun refreshProfileButtons() {
        val draft = currentDraft ?: return
        frontProfileButton?.apply {
            background = roundedBackground(if (!editingBackProfile) brandBlueDark else brandBlue, 12f)
        }
        backProfileButton?.apply {
            text = if (draft.validBackPoints() == null) "＋ Zadný profil" else "Zadný profil"
            background = roundedBackground(if (editingBackProfile) brandBlueDark else brandBlue, 12f)
        }
    }

    private fun resetActiveProfile() {
        val draft = currentDraft ?: return
        if (editingBackProfile) {
            AlertDialog.Builder(this)
                .setTitle("Obnoviť zadný profil?")
                .setMessage("Zadný profil sa znova vytvorí ako kópia predného profilu.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Obnoviť") { _, _ ->
                    draft.backPoints = draft.points.map { it.copy() }.toMutableList()
                    drawingView?.apply {
                        allowPointDrag = false
                        allowAngleEditing = false
                        setProfile(draft.backPoints ?: draft.points)
                    }
                    refreshEditorSummary()
                }
                .show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Nakresliť nový tvar?")
                .setMessage("Predný aj zadný profil sa vymažú.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Áno") { _, _ ->
                    drawingView?.startNewSketch()
                    draft.points = mutableListOf()
                    draft.backPoints = null
                    refreshEditorSummary()
                }
                .show()
        }
    }

    private fun removeBackProfile() {
        val draft = currentDraft ?: return
        if (draft.validBackPoints() == null) {
            Toast.makeText(this, "Zadný profil ešte nie je vytvorený.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Zrušiť zadný profil?")
            .setMessage("Profil sa zmení späť na hranol s rovnakým predným a zadným čelom.")
            .setNegativeButton("Nie", null)
            .setPositiveButton("Zrušiť zadný profil") { _, _ ->
                draft.backPoints = null
                editingBackProfile = false
                drawingView?.apply {
                    allowPointDrag = true
                    allowAngleEditing = true
                    setProfile(draft.points)
                }
                refreshEditorSummary()
            }
            .show()
    }

    private fun deleteSelectedPoint() {
        val draft = currentDraft ?: return
        val result = drawingView?.removeSelectedPoint()
        if (result == null) {
            Toast.makeText(this, "Najprv ťuknite na bod, ktorý chcete vymazať.", Toast.LENGTH_LONG).show()
            return
        }

        if (editingBackProfile) {
            val front = draft.points.map { it.copy() }.toMutableList()
            if (result.deletedIndex in front.indices && front.size > 2) {
                front.removeAt(result.deletedIndex)
            }
            draft.points = ProfileGeometry.snapProfile(front)
            draft.backPoints = ProfileGeometry.alignDirections(draft.points, result.updatedPoints)
            drawingView?.apply {
                allowPointDrag = false
                allowAngleEditing = false
                setProfile(draft.backPoints ?: draft.points)
            }
        } else {
            draft.points = result.updatedPoints
            draft.backPoints = draft.backPoints?.let { back ->
                val updatedBack = back.map { it.copy() }.toMutableList()
                if (result.deletedIndex in updatedBack.indices && updatedBack.size > 2) {
                    updatedBack.removeAt(result.deletedIndex)
                }
                ProfileGeometry.alignDirections(draft.points, updatedBack)
            }
            drawingView?.apply {
                allowPointDrag = true
                allowAngleEditing = true
                setProfile(draft.points)
            }
        }

        refreshEditorSummary()
        Toast.makeText(this, "Bod bol odstránený.", Toast.LENGTH_SHORT).show()
    }
    private fun showLengthWheel(segmentIndex: Int, currentLength: Int) {
        val upper = max(5000, currentLength + 500)
        val values = (5..upper step 5).map(Int::toString).toTypedArray()
        val picker = NumberPicker(this).apply {
            minValue = 0
            maxValue = values.lastIndex
            displayedValues = values
            value = ((currentLength.coerceAtLeast(5) - 5) / 5).coerceIn(0, values.lastIndex)
            wrapSelectorWheel = false
        }
        AlertDialog.Builder(this)
            .setTitle("Dĺžka strany v mm")
            .setMessage("Krok kolieska je 5 mm.")
            .setView(picker)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Nastaviť") { _, _ ->
                drawingView?.updateSegmentLength(segmentIndex, values[picker.value].toInt())
            }
            .show()
    }

    private fun showAngleWheel(vertexIndex: Int, currentAngle: Int) {
        val picker = NumberPicker(this).apply {
            minValue = 1
            maxValue = 179
            value = currentAngle.coerceIn(1, 179)
            wrapSelectorWheel = false
        }
        AlertDialog.Builder(this)
            .setTitle("Uhol v stupňoch")
            .setMessage("Krok kolieska je 1°.")
            .setView(picker)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Nastaviť") { _, _ ->
                drawingView?.updateAngle(vertexIndex, picker.value)
            }
            .show()
    }

    private fun showMetadataDialog() {
        val draft = currentDraft ?: return
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val name = field(content, "Názov výrobku", draft.name)
        val ral = field(content, "RAL / farba", draft.ral)
        val materials = arrayOf(
            "Farebný pozink",
            "Pozinkovaná oceľ",
            "Lakovaná oceľ",
            "Hliník",
            "Meď",
            "Titánzinok"
        )
        content.addView(fieldLabel("Druh plechu"))
        val material = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                materials
            )
            setSelection(materials.indexOf(draft.material).takeIf { it >= 0 } ?: 0)
        }
        content.addView(material)
        val thickness = field(
            content,
            "Hrúbka plechu (mm)",
            formatDecimal(draft.thicknessMm, 1),
            decimal = true
        )
        val length = field(
            content,
            "Dĺžka profilu (m)",
            formatDecimal(draft.profileLengthM, 2),
            decimal = true
        )
        val quantity = field(
            content,
            "Počet kusov",
            draft.quantity.toString(),
            number = true
        )
        val scroll = ScrollView(this).apply { addView(content) }

        AlertDialog.Builder(this)
            .setTitle("Údaje klampiarskeho prvku")
            .setView(scroll)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Uložiť") { _, _ ->
                draft.name = name.text.toString().trim().ifBlank { "Klampiarsky prvok" }
                draft.ral = ral.text.toString().trim().ifBlank { "RAL 8028" }
                draft.material = material.selectedItem.toString()
                draft.thicknessMm = parseDecimal(thickness.text.toString(), 0.5)
                    .coerceAtLeast(0.1)
                draft.profileLengthM = parseDecimal(length.text.toString(), 2.0)
                    .coerceAtLeast(0.01)
                draft.quantity = quantity.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                refreshEditorSummary()
            }
            .show()
    }

    private fun saveCurrentDrawing() {
        val draft = currentDraft ?: return
        val active = drawingView?.getProfile()
        if (editingBackProfile && active != null) draft.backPoints = active
        if (!editingBackProfile && active != null) draft.points = active
        if (draft.points.size < 2) {
            Toast.makeText(this, "Najprv nakreslite predný profil.", Toast.LENGTH_LONG).show()
            return
        }
        draft.backPoints = draft.backPoints
            ?.takeIf { it.size == draft.points.size && it.size >= 2 }
            ?.let { ProfileGeometry.alignDirections(draft.points, it) }
        draft.updatedAt = System.currentTimeMillis()
        database.saveDrawing(draft)
        Toast.makeText(this, "Nákres bol uložený iba v telefóne.", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun showProjectPicker() {
        val projects = database.listProjects()
        AlertDialog.Builder(this)
            .setTitle("Vyberte stavbu")
            .setItems(projects.map { it.name }.toTypedArray()) { _, index ->
                currentProject = projects[index]
                selectedDrawingIds.clear()
                showHome()
            }
            .setNeutralButton("Nová stavba") { _, _ -> showNewProjectDialog() }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showNewProjectDialog() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val name = field(content, "Názov stavby", "")
        val customer = field(content, "Zákazník", "")
        val address = field(content, "Adresa", "")
        AlertDialog.Builder(this)
            .setTitle("Nová stavba")
            .setView(content)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Vytvoriť") { _, _ ->
                val project = ProjectRecord(
                    name = name.text.toString().trim().ifBlank { "Nová stavba" },
                    customer = customer.text.toString().trim(),
                    address = address.text.toString().trim()
                )
                val id = database.insertProject(project)
                currentProject = project.copy(id = id)
                selectedDrawingIds.clear()
                showHome()
            }
            .show()
    }

    private fun showCopyDialog(drawing: DrawingRecord) {
        val projects = database.listProjects()
        AlertDialog.Builder(this)
            .setTitle("Skopírovať do stavby")
            .setItems(projects.map { it.name }.toTypedArray()) { _, index ->
                database.copyDrawing(drawing, projects[index].id)
                Toast.makeText(
                    this,
                    "Pôvodný nákres zostal zachovaný a kópia bola vytvorená.",
                    Toast.LENGTH_LONG
                ).show()
                showHome()
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun confirmDelete(drawing: DrawingRecord) {
        AlertDialog.Builder(this)
            .setTitle("Odstrániť nákres?")
            .setMessage(drawing.name)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Odstrániť") { _, _ ->
                database.deleteDrawing(drawing.id)
                selectedDrawingIds -= drawing.id
                showHome()
            }
            .show()
    }

    private fun generateSelectedPdf() {
        val drawings = selectedDrawingIds.mapNotNull(database::getDrawing)
        if (drawings.isEmpty()) {
            Toast.makeText(
                this,
                "Zaškrtnite aspoň jeden nákres.",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            pendingPdfDrawings = drawings
            requestPermissions(
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQUEST_STORAGE_PERMISSION
            )
            return
        }
        exportPdf(drawings)
    }

    private fun exportPdf(drawings: List<DrawingRecord>) {
        Toast.makeText(this, "Vytváram PDF…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val destination = PdfExporter.export(this, currentProject, drawings)
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "PDF je uložené v $destination",
                        Toast.LENGTH_LONG
                    ).show()
                }
            } catch (error: Exception) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "PDF sa nepodarilo vytvoriť: ${error.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun requestCamera() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
        } else {
            openCamera()
        }
    }

    private fun openCamera() {
        val photos = File(filesDir, "photos")
        if (!photos.exists()) photos.mkdirs()
        val file = File(
            photos,
            "photo-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}.jpg"
        )
        val uri = FileProvider.getUriForFile(
            this,
            "$packageName.fileprovider",
            file
        )
        photoOutputFile = file
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            clipData = ClipData.newRawUri("KlampSketch photo", uri)
        }
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQUEST_CAMERA)
        } else {
            Toast.makeText(this, "Fotoaparát nie je dostupný.", Toast.LENGTH_LONG).show()
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, REQUEST_GALLERY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when {
            requestCode == REQUEST_CAMERA && resultCode == RESULT_OK -> {
                currentDraft?.photoPath = photoOutputFile?.absolutePath
                refreshEditorSummary()
            }
            requestCode == REQUEST_CAMERA -> {
                photoOutputFile?.takeIf { it.isFile }?.delete()
            }
            requestCode == REQUEST_GALLERY && resultCode == RESULT_OK -> {
                data?.data?.let(::copyGalleryPhoto)
            }
        }
    }

    private fun copyGalleryPhoto(uri: Uri) {
        try {
            val photos = File(filesDir, "photos")
            if (!photos.exists()) photos.mkdirs()
            val mime = contentResolver.getType(uri).orEmpty()
            val extension = if (mime.contains("png")) "png" else "jpg"
            val target = File(
                photos,
                "gallery-${System.currentTimeMillis()}.$extension"
            )
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Fotografia sa nedá otvoriť." }
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            currentDraft?.photoPath = target.absolutePath
            refreshEditorSummary()
        } catch (error: Exception) {
            Toast.makeText(
                this,
                "Fotografiu sa nepodarilo uložiť: ${error.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            openCamera()
        } else if (requestCode == REQUEST_STORAGE_PERMISSION &&
            grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED
        ) {
            pendingPdfDrawings?.let(::exportPdf)
            pendingPdfDrawings = null
        }
    }

    private fun show3DPreview() {
        val draft = currentDraft ?: return
        if (draft.points.size < 2) {
            Toast.makeText(this, "Najprv nakreslite profil.", Toast.LENGTH_SHORT).show()
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        content.addView(
            TextView(this).apply {
                text = "Potiahnutím model otáčate, dvoma prstami približujete. Dvojité ťuknutie obnoví pohľad."
                textSize = 13f
                setTextColor(mutedText)
                setPadding(dp(4), 0, dp(4), dp(8))
            }
        )

        val supportsOpenGl3 = (
            getSystemService(ACTIVITY_SERVICE) as ActivityManager
        ).deviceConfigurationInfo.reqGlEsVersion >= 0x30000

        val previewHeight = dp(470).coerceAtMost(
            (resources.displayMetrics.heightPixels * 0.62f).toInt()
        )
        var glView: Profile3DView? = null
        var fallbackBitmap: android.graphics.Bitmap? = null
        if (supportsOpenGl3) {
            glView = Profile3DView(this).apply {
                setProfile(
                    draft.points,
                    draft.validBackPoints(),
                    (draft.profileLengthM * 1000.0).toFloat(),
                    draft.ral,
                    draft.material
                )
            }
            content.addView(
                glView,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    previewHeight
                )
            )
        } else {
            fallbackBitmap = Profile3DBitmapRenderer.render(
                900,
                900,
                draft.points,
                draft.validBackPoints(),
                (draft.profileLengthM * 1000.0).toFloat(),
                draft.ral,
                draft.material
            )
            content.addView(
                ImageView(this).apply {
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setImageBitmap(fallbackBitmap)
                    contentDescription = "Trojrozmerný náhľad klampiarskeho profilu"
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    previewHeight
                )
            )
        }

        val status = TextView(this).apply {
            text = if (supportsOpenGl3) {
                "OpenGL ES 3.0  •  Z-buffer  •  4× MSAA podľa podpory zariadenia"
            } else {
                "Softvérový Z-buffer – zariadenie nepodporuje OpenGL ES 3.0"
            }
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(brandBlueDark)
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(4), dp(8), dp(4), 0)
        }
        content.addView(status)

        val dialog = AlertDialog.Builder(this)
            .setTitle("3D náhľad – ${draft.identifier}")
            .setView(content)
            .setNeutralButton("Obnoviť pohľad", null)
            .setPositiveButton("Zavrieť", null)
            .create()
        dialog.setOnShowListener {
            glView?.onResume()
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                glView?.resetView()
            }
        }
        dialog.setOnDismissListener {
            glView?.onPause()
            fallbackBitmap?.recycle()
        }
        dialog.show()
    }

    private fun confirmLeaveEditor() {
        AlertDialog.Builder(this)
            .setTitle("Zavrieť bez uloženia?")
            .setMessage("Neuložené zmeny sa stratia.")
            .setNegativeButton("Pokračovať v úprave", null)
            .setPositiveButton("Zavrieť") { _, _ -> showHome() }
            .show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (inEditor) confirmLeaveEditor() else super.onBackPressed()
    }

    private fun screenRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.rgb(245, 248, 250))
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
        } else {
            fitsSystemWindows = true
        }
    }

    private fun horizontalActions(
        vararg actions: Pair<String, () -> Unit>
    ): HorizontalScrollView {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        actions.forEach { (label, action) ->
            row.addView(
                compactButton(label, action),
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp(4), 0, dp(4), 0) }
            )
        }
        return HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun compactButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 14f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setPadding(dp(12), dp(6), dp(12), dp(6))
        minHeight = dp(42)
        minimumWidth = 0
        background = roundedBackground(brandBlue, 12f)
        setOnClickListener { action() }
    }

    private fun field(
        parent: LinearLayout,
        label: String,
        value: String,
        decimal: Boolean = false,
        number: Boolean = false
    ): EditText {
        parent.addView(fieldLabel(label))
        val input = EditText(this).apply {
            setText(value)
            setSelectAllOnFocus(true)
            inputType = when {
                decimal -> InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                number -> InputType.TYPE_CLASS_NUMBER
                else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            }
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = roundedBackground(
                Color.WHITE,
                9f,
                strokeColor = Color.rgb(193, 207, 216)
            )
        }
        parent.addView(
            input,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(10)) }
        )
        return input
    }

    private fun fieldLabel(label: String) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(mutedText)
        setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(2), dp(4), dp(2), dp(3))
    }

    private fun roundedBackground(
        color: Int,
        radiusDp: Float,
        strokeColor: Int? = null
    ) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        strokeColor?.let { setStroke(dp(1), it) }
    }

    private fun parseDecimal(value: String, fallback: Double): Double =
        value.trim().replace(',', '.').toDoubleOrNull() ?: fallback

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private val brandBlue get() = Color.rgb(8, 119, 201)
    private val brandBlueDark get() = Color.rgb(6, 83, 139)
    private val darkText get() = Color.rgb(24, 44, 59)
    private val mutedText get() = Color.rgb(88, 105, 118)

    companion object {
        private const val REQUEST_CAMERA = 801
        private const val REQUEST_GALLERY = 802
        private const val REQUEST_CAMERA_PERMISSION = 803
        private const val REQUEST_STORAGE_PERMISSION = 804
    }
}
