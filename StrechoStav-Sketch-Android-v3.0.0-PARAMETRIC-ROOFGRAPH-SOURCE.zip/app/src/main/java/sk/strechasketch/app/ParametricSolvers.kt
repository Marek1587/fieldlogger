package sk.strechasketch.app

data class ParametricEditResult(
    val applied: Boolean,
    val graph: RoofGraph,
    val issues: List<String> = emptyList()
)

object TopologyValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = RoofGraphValidator.validate(graph)

    fun sameIncidence(before: RoofGraph, after: RoofGraph): Boolean =
        before.nodes.keys == after.nodes.keys &&
            before.edges.keys == after.edges.keys &&
            before.faces.keys == after.faces.keys &&
            before.edges.all { (id, edge) ->
                after.edges[id]?.let { it.startNodeId == edge.startNodeId && it.endNodeId == edge.endNodeId } == true
            } &&
            before.faces.all { (id, face) ->
                after.faces[id]?.let {
                    it.orderedNodeIds == face.orderedNodeIds && it.orderedEdgeIds == face.orderedEdgeIds
                } == true
            }
}

object PlanConstraintSolver {
    fun setEdgeLength(graph: RoofGraph, edgeId: String, targetLengthM: Double): ParametricEditResult {
        val candidate = RoofGraphOperations.setEdgeLength(graph, edgeId, targetLengthM)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutým uzlom."))
        if (!TopologyValidator.sameIncidence(graph, candidate)) {
            return ParametricEditResult(false, graph, listOf("Parametrická zmena by zmenila topológiu."))
        }
        val issues = TopologyValidator.validate(candidate)
        if (issues.any { it.code in setOf("NON_FINITE_NODE", "ZERO_EDGE", "BROKEN_FACE_REFERENCE") }) {
            return ParametricEditResult(false, graph, issues.map { it.message })
        }
        return ParametricEditResult(true, candidate)
    }
}

object ParametricEditSolver {
    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double
    ): ParametricEditResult {
        val plan = PlanConstraintSolver.setEdgeLength(graph, edgeId, targetLengthM)
        if (!plan.applied) return plan
        val roof = RoofPlaneSolver.solve(plan.graph, wallHeightM, defaultSlopeDeg)
        if (!TopologyValidator.sameIncidence(graph, roof.graph)) {
            return ParametricEditResult(false, graph, listOf("RoofPlaneSolver zmenil topologickú incidenciu."))
        }
        return ParametricEditResult(true, roof.graph, roof.issues.map { it.message })
    }
}
