package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

data class FaceQuantityAudit(
    val faceId: String,
    val area3DM2: Double,
    val plane: RoofPlane,
    val underconstrained: Boolean
)

data class EdgeQuantityAudit(
    val edgeId: String,
    val semanticRole: EdgeSemantic,
    val boundary: Boolean,
    val length3DM: Double
)

data class RoofQuantityAudit(
    val graph: RoofGraph,
    val faces: List<FaceQuantityAudit>,
    val edges: List<EdgeQuantityAudit>,
    val totals: ProjectTotals
)

object RoofQuantityEngine {
    fun calculate(project: RoofProject): RoofQuantityAudit {
        val topology = project.roofGraph?.toTopology()
            ?: project.roofTopology
            ?: RoofTopologyMigration.fromLegacyProject(project)
        val planar = if (RoofTopologySolver.extractFaces(topology).isEmpty()) {
            RoofTopologySolver.solve(topology).proposed
        } else topology
        val baseGraph = RoofGraphFactory.fromTopology(planar, project.roofGraph)
        val solved = RoofPlaneSolver.solve(baseGraph, project.wallHeightM, project.slopeDeg).graph
        val faces = solved.faces.values.sortedBy { it.id }.mapNotNull { face ->
            val plane = face.plane ?: return@mapNotNull null
            FaceQuantityAudit(
                face.id,
                abs(face.signedAreaM2) * sqrt(1.0 + plane.a * plane.a + plane.b * plane.b),
                plane,
                face.underconstrained
            )
        }
        val edges = solved.edges.values.sortedBy { it.id }.mapNotNull { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = solved.nodes[edge.endNodeId] ?: return@mapNotNull null
            EdgeQuantityAudit(
                edge.id,
                edge.semanticRole,
                edge.boundary,
                sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y) + (b.z - a.z) * (b.z - a.z))
            )
        }
        fun length(role: EdgeSemantic) = edges.filter { it.semanticRole == role }.sumOf { it.length3DM }
        fun count(type: ObjectType) = project.objects.count { it.type == type }
        val footprint = solved.faces.values.sumOf { abs(it.signedAreaM2) }
            .takeIf { it > 0.0 } ?: Geometry.areaM2(project.polygon)
        val totals = ProjectTotals(
            footprintAreaM2 = footprint,
            roofAreaM2 = faces.sumOf { it.area3DM2 },
            perimeterM = edges.filter { it.boundary }.sumOf { it.length3DM },
            ridgeM = length(EdgeSemantic.RIDGE),
            valleyM = length(EdgeSemantic.VALLEY),
            hipM = length(EdgeSemantic.HIP),
            atticM = length(EdgeSemantic.ATTIC),
            pultM = length(EdgeSemantic.PULT),
            wallEndM = length(EdgeSemantic.WALL_END),
            eaveM = length(EdgeSemantic.EAVE),
            gableM = length(EdgeSemantic.GABLE),
            chimneys = count(ObjectType.CHIMNEY),
            roofWindows = count(ObjectType.ROOF_WINDOW),
            hatches = count(ObjectType.HATCH),
            vents = count(ObjectType.VENT),
            drains = count(ObjectType.DRAIN),
            downspouts = count(ObjectType.DOWNSPOUT),
            heightMarks = count(ObjectType.HEIGHT_MARK),
            slopeMarks = count(ObjectType.SLOPE_MARK)
        )
        return RoofQuantityAudit(solved, faces, edges, totals)
    }
}
