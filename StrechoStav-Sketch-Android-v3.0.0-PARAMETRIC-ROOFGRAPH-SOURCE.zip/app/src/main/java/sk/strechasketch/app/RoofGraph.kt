package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

enum class EdgeSemantic {
    UNKNOWN, EAVE, GABLE, PULT, ATTIC, WALL_END, RIDGE, HIP, VALLEY;

    fun toLegacy(): LineType = when (this) {
        UNKNOWN -> LineType.UNKNOWN
        EAVE -> LineType.EAVE
        GABLE -> LineType.GABLE
        PULT -> LineType.PULT
        ATTIC -> LineType.ATTIC
        WALL_END -> LineType.WALL_END
        RIDGE -> LineType.RIDGE
        HIP -> LineType.HIP
        VALLEY -> LineType.VALLEY
    }

    companion object {
        fun fromLegacy(type: LineType): EdgeSemantic = when (type) {
            LineType.UNKNOWN -> UNKNOWN
            LineType.EAVE -> EAVE
            LineType.GABLE -> GABLE
            LineType.PULT -> PULT
            LineType.ATTIC -> ATTIC
            LineType.WALL_END -> WALL_END
            LineType.RIDGE -> RIDGE
            LineType.HIP -> HIP
            LineType.VALLEY -> VALLEY
        }
    }
}

data class RoofPlane(val a: Double, val b: Double, val c: Double) {
    fun zAt(x: Double, y: Double): Double = a * x + b * y + c
}

data class FaceSlopeConstraint(
    val angleDeg: Double,
    val directionX: Double,
    val directionY: Double,
    val hard: Boolean = true
)

data class ElevationConstraint(
    val nodeId: String? = null,
    val x: Double? = null,
    val y: Double? = null,
    val elevationZ: Double,
    val hard: Boolean = true
)

data class DimensionConstraint(
    val id: String = UUID.randomUUID().toString(),
    val supportAEdgeId: String,
    val supportBEdgeId: String,
    val directionX: Double,
    val directionY: Double,
    val valueMm: Double,
    val fixedSupportEdgeId: String? = null,
    val hard: Boolean = true
)

data class EdgeLengthConstraint(
    val id: String,
    val edgeId: String,
    val valueMm: Double,
    val fixedNodeId: String,
    val hard: Boolean = true
)

data class GraphNode(
    val id: String,
    val x: Double,
    val y: Double,
    val z: Double = 0.0,
    val lockX: Boolean = false,
    val lockY: Boolean = false,
    val lockZ: Boolean = false
)

data class GraphEdge(
    val id: String,
    val startNodeId: String,
    val endNodeId: String,
    val boundary: Boolean,
    val semanticRole: EdgeSemantic = EdgeSemantic.UNKNOWN,
    val adjacentFaceIds: Set<String> = emptySet(),
    val locked: Boolean = false,
    val note: String = ""
)

data class GraphFace(
    val id: String,
    val orderedNodeIds: List<String>,
    val orderedEdgeIds: List<String>,
    val signedAreaM2: Double,
    val plane: RoofPlane? = null,
    val slopeConstraint: FaceSlopeConstraint? = null,
    val elevationConstraints: List<ElevationConstraint> = emptyList(),
    val underconstrained: Boolean = false
)

data class RoofGraph(
    val origin: GeoPoint,
    val nodes: Map<String, GraphNode>,
    val edges: Map<String, GraphEdge>,
    val faces: Map<String, GraphFace>,
    val dimensions: Map<String, DimensionConstraint> = emptyMap(),
    val schemaVersion: Int = 1,
    val edgeLengthConstraints: Map<String, EdgeLengthConstraint> = emptyMap()
) {
    fun toTopology(): RoofTopology = RoofTopology(
        origin = origin.copy(),
        nodes = nodes.values.sortedBy { it.id }.map { node ->
            TopologyNode(
                id = node.id,
                x = node.x,
                y = node.y,
                type = if (edges.values.any { it.boundary && (it.startNodeId == node.id || it.endNodeId == node.id) }) {
                    TopologyNodeType.FOOTPRINT
                } else TopologyNodeType.JUNCTION,
                locked = node.lockX && node.lockY
            )
        },
        edges = edges.values.sortedBy { it.id }.map { edge ->
            TopologyEdge(
                id = edge.id,
                startNodeId = edge.startNodeId,
                endNodeId = edge.endNodeId,
                type = edge.semanticRole.toLegacy(),
                locked = edge.locked,
                boundary = edge.boundary,
                sourceId = edge.id,
                note = edge.note
            )
        },
        schemaVersion = 3
    )

    fun topologySignature(): String = buildString {
        edges.values.sortedBy { it.id }.forEach { edge ->
            append(edge.id).append(':').append(edge.startNodeId).append('>').append(edge.endNodeId)
                .append(':').append(edge.boundary).append(';')
        }
        faces.values.sortedBy { it.id }.forEach { face ->
            append(face.id).append(':').append(face.orderedNodeIds.joinToString(",")).append(';')
        }
    }
}

object RoofGraphFactory {
    fun fromTopology(topology: RoofTopology, previous: RoofGraph? = null): RoofGraph {
        val previousFacesByCycle = previous?.faces?.values.orEmpty().associateBy {
            canonicalCycle(it.orderedEdgeIds.ifEmpty { it.orderedNodeIds })
        }
        val unusedPreviousFaces = previous?.faces?.values.orEmpty().toMutableSet()
        val topologyFaces = RoofTopologySolver.extractFaces(topology)
        val faces = linkedMapOf<String, GraphFace>()
        topologyFaces.forEach { face ->
            val cycleKey = canonicalCycle(face.edgeIds.ifEmpty { face.nodeIds })
            val previousFace = previousFacesByCycle[cycleKey]
                ?: unusedPreviousFaces
                    .filter { isCyclicRefinement(face.nodeIds, it.orderedNodeIds) }
                    .minByOrNull { old -> face.nodeIds.size - old.orderedNodeIds.size }
            if (previousFace != null) unusedPreviousFaces.remove(previousFace)
            val id = previousFace?.id ?: stableFaceId(cycleKey)
            faces[id] = GraphFace(
                id = id,
                orderedNodeIds = face.nodeIds,
                orderedEdgeIds = face.edgeIds,
                signedAreaM2 = face.signedAreaM2,
                plane = previousFace?.plane,
                slopeConstraint = previousFace?.slopeConstraint,
                elevationConstraints = previousFace?.elevationConstraints.orEmpty(),
                underconstrained = previousFace?.underconstrained ?: false
            )
        }
        val adjacent = mutableMapOf<String, MutableSet<String>>()
        faces.values.forEach { face ->
            face.orderedEdgeIds.forEach { edgeId -> adjacent.getOrPut(edgeId) { linkedSetOf() } += face.id }
        }
        val previousNodes = previous?.nodes.orEmpty()
        val graphNodes = topology.nodes.associate { node ->
            val old = previousNodes[node.id]
            node.id to GraphNode(
                id = node.id,
                x = node.x,
                y = node.y,
                z = old?.z ?: 0.0,
                lockX = old?.lockX ?: node.locked,
                lockY = old?.lockY ?: node.locked,
                lockZ = old?.lockZ ?: false
            )
        }
        val previousEdges = previous?.edges.orEmpty()
        val graphEdges = topology.edges.associate { edge ->
            val old = previousEdges[edge.id]
            edge.id to GraphEdge(
                id = edge.id,
                startNodeId = edge.startNodeId,
                endNodeId = edge.endNodeId,
                boundary = edge.boundary,
                semanticRole = EdgeSemantic.fromLegacy(edge.type),
                adjacentFaceIds = adjacent[edge.id].orEmpty(),
                locked = old?.locked ?: edge.locked,
                note = edge.note
            )
        }
        return RoofGraph(
            origin = topology.origin.copy(),
            nodes = graphNodes,
            edges = graphEdges,
            faces = faces,
            dimensions = previous?.dimensions.orEmpty(),
            edgeLengthConstraints = previous?.edgeLengthConstraints.orEmpty()
        )
    }

    private fun stableFaceId(cycleKey: String): String = "face-" + UUID.nameUUIDFromBytes(
        cycleKey.toByteArray(StandardCharsets.UTF_8)
    )

    private fun canonicalCycle(values: List<String>): String {
        if (values.isEmpty()) return ""
        fun rotations(input: List<String>) = input.indices.map { index ->
            (input.drop(index) + input.take(index)).joinToString("|")
        }
        return (rotations(values) + rotations(values.asReversed())).minOrNull().orEmpty()
    }

    /** Keeps a face identity when an edge is split by inserting nodes into its cycle. */
    private fun isCyclicRefinement(candidate: List<String>, previous: List<String>): Boolean {
        if (previous.isEmpty() || candidate.size < previous.size) return false
        val previousSet = previous.toSet()
        if (!candidate.containsAll(previousSet)) return false
        return canonicalCycle(candidate.filter { it in previousSet }) == canonicalCycle(previous)
    }
}

data class RoofGraphValidationIssue(
    val code: String,
    val message: String,
    val nodeIds: Set<String> = emptySet(),
    val edgeIds: Set<String> = emptySet(),
    val faceIds: Set<String> = emptySet()
)

object RoofGraphValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = buildList {
        graph.nodes.values.forEach { node ->
            if (!node.x.isFinite() || !node.y.isFinite() || !node.z.isFinite()) {
                add(RoofGraphValidationIssue("NON_FINITE_NODE", "Uzol obsahuje neplatnú súradnicu.", nodeIds = setOf(node.id)))
            }
        }
        graph.edges.values.forEach { edge ->
            val a = graph.nodes[edge.startNodeId]
            val b = graph.nodes[edge.endNodeId]
            if (a == null || b == null) {
                add(RoofGraphValidationIssue("MISSING_EDGE_NODE", "Hrana odkazuje na chýbajúci uzol.", edgeIds = setOf(edge.id)))
            } else if (kotlin.math.hypot(b.x - a.x, b.y - a.y) < 0.001) {
                add(RoofGraphValidationIssue("ZERO_EDGE", "Hrana má nulovú dĺžku.", nodeIds = setOf(a.id, b.id), edgeIds = setOf(edge.id)))
            }
        }
        graph.faces.values.forEach { face ->
            val missingNodes = face.orderedNodeIds.filterNot(graph.nodes::containsKey).toSet()
            val missingEdges = face.orderedEdgeIds.filterNot(graph.edges::containsKey).toSet()
            if (missingNodes.isNotEmpty() || missingEdges.isNotEmpty()) {
                add(RoofGraphValidationIssue("BROKEN_FACE_REFERENCE", "Plocha odkazuje na chýbajúci prvok.", missingNodes, missingEdges, setOf(face.id)))
            }
            if (kotlin.math.abs(face.signedAreaM2) <= 1e-8) {
                add(RoofGraphValidationIssue("DEGENERATE_FACE", "Plocha je degenerovaná.", faceIds = setOf(face.id)))
            }
        }
        graph.edges.values.forEach { edge ->
            val actual = graph.faces.values.filter { edge.id in it.orderedEdgeIds }.map { it.id }.toSet()
            if (actual != edge.adjacentFaceIds) {
                add(RoofGraphValidationIssue("FACE_INCIDENCE_MISMATCH", "Väzba hrana–plocha nie je konzistentná.", edgeIds = setOf(edge.id), faceIds = actual + edge.adjacentFaceIds))
            }
        }
    }
}

/** Pure graph operations. One call is one undoable user transaction. */
object RoofGraphOperations {
    fun moveNode(graph: RoofGraph, nodeId: String, x: Double, y: Double, z: Double? = null): RoofGraph? {
        val node = graph.nodes[nodeId] ?: return null
        if ((node.lockX && x != node.x) || (node.lockY && y != node.y) || (z != null && node.lockZ && z != node.z)) return null
        val moved = node.copy(x = x, y = y, z = z ?: node.z)
        return rebuild(graph, graph.nodes + (nodeId to moved), graph.edges)
    }

    fun translateEdge(graph: RoofGraph, edgeId: String, deltaX: Double, deltaY: Double): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        val a = graph.nodes[edge.startNodeId] ?: return null
        val b = graph.nodes[edge.endNodeId] ?: return null
        if (a.lockX || a.lockY || b.lockX || b.lockY || edge.locked) return null
        val movedNodes = graph.nodes + mapOf(
            a.id to a.copy(x = a.x + deltaX, y = a.y + deltaY),
            b.id to b.copy(x = b.x + deltaX, y = b.y + deltaY)
        )
        return rebuild(graph, movedNodes, graph.edges)
    }

    fun setSemanticRole(graph: RoofGraph, edgeId: String, role: EdgeSemantic): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        return graph.copy(edges = graph.edges + (edgeId to edge.copy(semanticRole = role)))
    }

    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        fixedNodeId: String? = null
    ): RoofGraph? {
        if (targetLengthM !in 0.05..5000.0) return null
        val edge = graph.edges[edgeId] ?: return null
        val fixedId = fixedNodeId?.takeIf { it == edge.startNodeId || it == edge.endNodeId } ?: edge.startNodeId
        val movingId = if (fixedId == edge.startNodeId) edge.endNodeId else edge.startNodeId
        val fixed = graph.nodes[fixedId] ?: return null
        val moving = graph.nodes[movingId] ?: return null
        if (moving.lockX || moving.lockY) return null
        val dx = moving.x - fixed.x
        val dy = moving.y - fixed.y
        val length = kotlin.math.hypot(dx, dy)
        if (length < 1e-9) return null
        val moved = moving.copy(
            x = fixed.x + dx / length * targetLengthM,
            y = fixed.y + dy / length * targetLengthM
        )
        val constraint = EdgeLengthConstraint(
            id = "edge-length-$edgeId",
            edgeId = edgeId,
            valueMm = targetLengthM * 1000.0,
            fixedNodeId = fixedId
        )
        return rebuild(graph, graph.nodes + (movingId to moved), graph.edges).copy(
            edgeLengthConstraints = graph.edgeLengthConstraints + (constraint.id to constraint)
        )
    }

    fun splitEdge(graph: RoofGraph, edgeId: String, newNodeId: String = UUID.randomUUID().toString()): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        val a = graph.nodes[edge.startNodeId] ?: return null
        val b = graph.nodes[edge.endNodeId] ?: return null
        if (newNodeId in graph.nodes) return null
        val middle = GraphNode(
            id = newNodeId,
            x = (a.x + b.x) / 2.0,
            y = (a.y + b.y) / 2.0,
            z = (a.z + b.z) / 2.0
        )
        val suffix = newNodeId.filter(Char::isLetterOrDigit).take(8).ifBlank { "mid" }
        val first = edge.copy(
            id = "${edge.id}A-$suffix",
            endNodeId = middle.id,
            adjacentFaceIds = emptySet()
        )
        val second = edge.copy(
            id = "${edge.id}B-$suffix",
            startNodeId = middle.id,
            adjacentFaceIds = emptySet()
        )
        val newEdges = graph.edges.toMutableMap().apply {
            remove(edge.id)
            put(first.id, first)
            put(second.id, second)
        }
        return rebuild(graph, graph.nodes + (middle.id to middle), newEdges).copy(
            edgeLengthConstraints = graph.edgeLengthConstraints.filterValues { it.edgeId != edgeId }
        )
    }

    private fun rebuild(graph: RoofGraph, nodes: Map<String, GraphNode>, edges: Map<String, GraphEdge>): RoofGraph {
        val topology = graph.copy(nodes = nodes, edges = edges, faces = emptyMap()).toTopology()
        val rebuilt = RoofGraphFactory.fromTopology(topology, graph)
        return rebuilt.copy(
            nodes = rebuilt.nodes.mapValues { (id, node) ->
                nodes[id]?.let { source ->
                    node.copy(z = source.z, lockX = source.lockX, lockY = source.lockY, lockZ = source.lockZ)
                } ?: node
            },
            dimensions = graph.dimensions,
            edgeLengthConstraints = graph.edgeLengthConstraints
        )
    }
}

data class RoofGraphTransaction(val label: String, val before: RoofGraph, val after: RoofGraph)

class RoofGraphUndoManager(private val capacity: Int = 30) {
    private val undo = ArrayDeque<RoofGraphTransaction>()
    private val redo = ArrayDeque<RoofGraphTransaction>()

    fun commit(label: String, before: RoofGraph, after: RoofGraph) {
        if (before == after) return
        undo.addLast(RoofGraphTransaction(label, before, after))
        while (undo.size > capacity) undo.removeFirst()
        redo.clear()
    }

    fun undo(current: RoofGraph): RoofGraph? {
        val transaction = undo.removeLastOrNull() ?: return null
        if (transaction.after.topologySignature() != current.topologySignature()) return null
        redo.addLast(transaction)
        return transaction.before
    }

    fun redo(current: RoofGraph): RoofGraph? {
        val transaction = redo.removeLastOrNull() ?: return null
        if (transaction.before.topologySignature() != current.topologySignature()) return null
        undo.addLast(transaction)
        return transaction.after
    }
}

object RoofGraphJson {
    fun encode(graph: RoofGraph): JSONObject = JSONObject().apply {
        put("schema_version", graph.schemaVersion)
        put("origin", point(graph.origin))
        put("nodes", JSONArray().also { array -> graph.nodes.values.sortedBy { it.id }.forEach { node ->
            array.put(JSONObject().apply {
                put("id", node.id); put("x", node.x); put("y", node.y); put("z", node.z)
                put("lock_x", node.lockX); put("lock_y", node.lockY); put("lock_z", node.lockZ)
            })
        } })
        put("edges", JSONArray().also { array -> graph.edges.values.sortedBy { it.id }.forEach { edge ->
            array.put(JSONObject().apply {
                put("id", edge.id); put("start_node_id", edge.startNodeId); put("end_node_id", edge.endNodeId)
                put("boundary", edge.boundary); put("semantic_role", edge.semanticRole.name)
                put("adjacent_face_ids", JSONArray(edge.adjacentFaceIds.sorted()))
                put("locked", edge.locked); put("note", edge.note)
            })
        } })
        put("faces", JSONArray().also { array -> graph.faces.values.sortedBy { it.id }.forEach { face ->
            array.put(JSONObject().apply {
                put("id", face.id); put("ordered_node_ids", JSONArray(face.orderedNodeIds))
                put("ordered_edge_ids", JSONArray(face.orderedEdgeIds)); put("signed_area_m2", face.signedAreaM2)
                face.plane?.let { put("plane", JSONObject().put("a", it.a).put("b", it.b).put("c", it.c)) }
                face.slopeConstraint?.let { slope -> put("slope_constraint", JSONObject().apply {
                    put("angle_deg", slope.angleDeg); put("direction_x", slope.directionX)
                    put("direction_y", slope.directionY); put("hard", slope.hard)
                }) }
                put("elevation_constraints", JSONArray().also { constraints -> face.elevationConstraints.forEach { item ->
                    constraints.put(JSONObject().apply {
                        item.nodeId?.let { put("node_id", it) }; item.x?.let { put("x", it) }; item.y?.let { put("y", it) }
                        put("elevation_z", item.elevationZ); put("hard", item.hard)
                    })
                } })
                put("underconstrained", face.underconstrained)
            })
        } })
        put("dimensions", JSONArray().also { array -> graph.dimensions.values.sortedBy { it.id }.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id); put("support_a_edge_id", item.supportAEdgeId)
                put("support_b_edge_id", item.supportBEdgeId); put("direction_x", item.directionX)
                put("direction_y", item.directionY); put("value_mm", item.valueMm)
                item.fixedSupportEdgeId?.let { put("fixed_support_edge_id", it) }; put("hard", item.hard)
            })
        } })
        put("edge_length_constraints", JSONArray().also { array ->
            graph.edgeLengthConstraints.values.sortedBy { it.id }.forEach { item ->
                array.put(JSONObject().apply {
                    put("id", item.id); put("edge_id", item.edgeId); put("value_mm", item.valueMm)
                    put("fixed_node_id", item.fixedNodeId); put("hard", item.hard)
                })
            }
        })
    }

    fun decode(value: JSONObject): RoofGraph {
        val origin = value.optJSONObject("origin")?.let {
            GeoPoint(it.optDouble("lat"), it.optDouble("lon", it.optDouble("lng")))
        } ?: GeoPoint(49.0663, 18.9236)
        val nodes = linkedMapOf<String, GraphNode>()
        value.optJSONArray("nodes")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            nodes[id] = GraphNode(id, item.optDouble("x"), item.optDouble("y"), item.optDouble("z"),
                item.optBoolean("lock_x"), item.optBoolean("lock_y"), item.optBoolean("lock_z"))
        } }
        val edges = linkedMapOf<String, GraphEdge>()
        value.optJSONArray("edges")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            edges[id] = GraphEdge(id, item.optString("start_node_id"), item.optString("end_node_id"),
                item.optBoolean("boundary"), runCatching { EdgeSemantic.valueOf(item.optString("semantic_role")) }.getOrDefault(EdgeSemantic.UNKNOWN),
                strings(item.optJSONArray("adjacent_face_ids")).toSet(), item.optBoolean("locked"), item.optString("note"))
        } }
        val faces = linkedMapOf<String, GraphFace>()
        value.optJSONArray("faces")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            val plane = item.optJSONObject("plane")?.let { RoofPlane(it.optDouble("a"), it.optDouble("b"), it.optDouble("c")) }
            val slope = item.optJSONObject("slope_constraint")?.let { FaceSlopeConstraint(
                it.optDouble("angle_deg"), it.optDouble("direction_x"), it.optDouble("direction_y"), it.optBoolean("hard", true)
            ) }
            val elevations = mutableListOf<ElevationConstraint>()
            item.optJSONArray("elevation_constraints")?.let { list -> repeat(list.length()) { i ->
                val c = list.getJSONObject(i); elevations += ElevationConstraint(
                    c.optString("node_id").takeIf(String::isNotBlank), c.optDoubleOrNull("x"), c.optDoubleOrNull("y"),
                    c.optDouble("elevation_z"), c.optBoolean("hard", true)
                )
            } }
            faces[id] = GraphFace(id, strings(item.optJSONArray("ordered_node_ids")), strings(item.optJSONArray("ordered_edge_ids")),
                item.optDouble("signed_area_m2"), plane, slope, elevations, item.optBoolean("underconstrained"))
        } }
        val dimensions = linkedMapOf<String, DimensionConstraint>()
        value.optJSONArray("dimensions")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            dimensions[id] = DimensionConstraint(id, item.optString("support_a_edge_id"), item.optString("support_b_edge_id"),
                item.optDouble("direction_x"), item.optDouble("direction_y"), item.optDouble("value_mm"),
                item.optString("fixed_support_edge_id").takeIf(String::isNotBlank), item.optBoolean("hard", true))
        } }
        val edgeLengths = linkedMapOf<String, EdgeLengthConstraint>()
        value.optJSONArray("edge_length_constraints")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index)
            val id = item.optString("id").ifBlank { "edge-length-${item.optString("edge_id")}" }
            edgeLengths[id] = EdgeLengthConstraint(
                id = id,
                edgeId = item.optString("edge_id"),
                valueMm = item.optDouble("value_mm"),
                fixedNodeId = item.optString("fixed_node_id"),
                hard = item.optBoolean("hard", true)
            )
        } }
        return RoofGraph(
            origin, nodes, edges, faces, dimensions, value.optInt("schema_version", 1), edgeLengths
        )
    }

    private fun strings(array: JSONArray?): List<String> = buildList {
        if (array != null) repeat(array.length()) { add(array.optString(it)) }
    }

    private fun point(point: GeoPoint) = JSONObject().put("lat", point.lat).put("lon", point.lon)
    private fun JSONObject.optDoubleOrNull(key: String): Double? = if (has(key) && !isNull(key)) optDouble(key) else null
}
