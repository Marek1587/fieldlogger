package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.tan

data class RoofPlaneSolverIssue(
    val code: String,
    val message: String,
    val faceId: String? = null,
    val residualM: Double = 0.0
)

data class RoofPlaneSolution(
    val graph: RoofGraph,
    val issues: List<RoofPlaneSolverIssue>,
    val maximumCoplanarityResidualM: Double
)

/**
 * Deterministic, preset-free Z solver. XY topology is immutable. Every face owns
 * one plane and every NodeId owns exactly one Z shared by all incident faces.
 */
object RoofPlaneSolver {
    private val lowRoles = setOf(
        EdgeSemantic.EAVE, EdgeSemantic.PULT, EdgeSemantic.ATTIC, EdgeSemantic.WALL_END
    )

    fun solve(
        input: RoofGraph,
        wallHeightM: Double,
        defaultSlopeDeg: Double,
        iterations: Int = 120
    ): RoofPlaneSolution {
        if (input.faces.isEmpty()) {
            return RoofPlaneSolution(
                input,
                listOf(RoofPlaneSolverIssue("NO_FACES", "Topologická sieť neobsahuje uzavretú strešnú plochu.")),
                0.0
            )
        }
        val wallHeight = wallHeightM.coerceIn(0.5, 100.0)
        val nodeZ = input.nodes.mapValues { it.value.z.takeIf(Double::isFinite) ?: wallHeight }.toMutableMap()
        val hardZ = linkedMapOf<String, Double>()
        input.nodes.values.filter { it.lockZ }.forEach { hardZ[it.id] = it.z }
        input.faces.values.forEach { face ->
            face.elevationConstraints.forEach { constraint ->
                constraint.nodeId?.takeIf(input.nodes::containsKey)?.let { hardZ[it] = constraint.elevationZ }
            }
        }
        input.edges.values.filter { it.semanticRole in lowRoles }.forEach { edge ->
            if (edge.startNodeId !in hardZ) hardZ[edge.startNodeId] = wallHeight
            if (edge.endNodeId !in hardZ) hardZ[edge.endNodeId] = wallHeight
        }

        data class Gradient(val a: Double, val b: Double, val underconstrained: Boolean)
        val gradients = input.faces.mapValues { (_, face) ->
            val explicit = face.slopeConstraint
            if (explicit != null) {
                val length = hypot(explicit.directionX, explicit.directionY).coerceAtLeast(1e-12)
                val magnitude = tan(Math.toRadians(explicit.angleDeg.coerceIn(0.0, 75.0)))
                Gradient(magnitude * explicit.directionX / length, magnitude * explicit.directionY / length, false)
            } else {
                val low = face.orderedEdgeIds.mapNotNull(input.edges::get)
                    .filter { it.semanticRole in lowRoles }
                    .maxByOrNull { edge ->
                        val a = input.nodes[edge.startNodeId] ?: return@maxByOrNull 0.0
                        val b = input.nodes[edge.endNodeId] ?: return@maxByOrNull 0.0
                        hypot(b.x - a.x, b.y - a.y)
                    }
                if (low == null) Gradient(0.0, 0.0, true)
                else {
                    val a = input.nodes.getValue(low.startNodeId)
                    val b = input.nodes.getValue(low.endNodeId)
                    val centroidX = face.orderedNodeIds.mapNotNull(input.nodes::get).map { it.x }.average()
                    val centroidY = face.orderedNodeIds.mapNotNull(input.nodes::get).map { it.y }.average()
                    val edgeDx = b.x - a.x
                    val edgeDy = b.y - a.y
                    val length = hypot(edgeDx, edgeDy).coerceAtLeast(1e-12)
                    var nx = -edgeDy / length
                    var ny = edgeDx / length
                    val midX = (a.x + b.x) / 2.0
                    val midY = (a.y + b.y) / 2.0
                    if (nx * (centroidX - midX) + ny * (centroidY - midY) < 0.0) {
                        nx = -nx; ny = -ny
                    }
                    val magnitude = tan(Math.toRadians(defaultSlopeDeg.coerceIn(0.0, 75.0)))
                    Gradient(nx * magnitude, ny * magnitude, false)
                }
            }
        }

        val intercepts = input.faces.mapValues { (_, face) ->
            val gradient = gradients.getValue(face.id)
            val lowNodes = face.orderedEdgeIds.mapNotNull(input.edges::get)
                .filter { it.semanticRole in lowRoles }
                .flatMap { listOf(it.startNodeId, it.endNodeId) }
                .distinct()
                .mapNotNull(input.nodes::get)
            if (lowNodes.isNotEmpty()) {
                lowNodes.map { wallHeight - gradient.a * it.x - gradient.b * it.y }.average()
            } else {
                face.orderedNodeIds.mapNotNull(input.nodes::get)
                    .map { node -> (hardZ[node.id] ?: wallHeight) - gradient.a * node.x - gradient.b * node.y }
                    .average()
            }
        }.toMutableMap()

        val incidentFaces = mutableMapOf<String, MutableList<String>>()
        input.faces.values.forEach { face ->
            face.orderedNodeIds.forEach { nodeId -> incidentFaces.getOrPut(nodeId) { mutableListOf() } += face.id }
        }
        repeat(iterations.coerceIn(8, 500)) {
            input.nodes.keys.sorted().forEach { nodeId ->
                hardZ[nodeId]?.let { nodeZ[nodeId] = it; return@forEach }
                val node = input.nodes.getValue(nodeId)
                val predictions = incidentFaces[nodeId].orEmpty().map { faceId ->
                    val gradient = gradients.getValue(faceId)
                    gradient.a * node.x + gradient.b * node.y + intercepts.getValue(faceId)
                }
                if (predictions.isNotEmpty()) nodeZ[nodeId] = predictions.average()
            }
            input.faces.keys.sorted().forEach { faceId ->
                val face = input.faces.getValue(faceId)
                val gradient = gradients.getValue(faceId)
                val values = face.orderedNodeIds.mapNotNull { nodeId ->
                    val node = input.nodes[nodeId] ?: return@mapNotNull null
                    nodeZ[nodeId]?.minus(gradient.a * node.x + gradient.b * node.y)
                }
                if (values.isNotEmpty()) intercepts[faceId] = values.average()
            }
        }

        val solvedNodes = input.nodes.mapValues { (id, node) -> node.copy(z = hardZ[id] ?: nodeZ.getValue(id)) }
        val issues = mutableListOf<RoofPlaneSolverIssue>()
        var maximumResidual = 0.0
        val solvedFaces = input.faces.mapValues { (_, face) ->
            val gradient = gradients.getValue(face.id)
            val plane = RoofPlane(gradient.a, gradient.b, intercepts.getValue(face.id))
            val residual = face.orderedNodeIds.maxOfOrNull { nodeId ->
                val node = solvedNodes.getValue(nodeId)
                abs(node.z - plane.zAt(node.x, node.y))
            } ?: 0.0
            maximumResidual = max(maximumResidual, residual)
            val underconstrained = gradient.underconstrained || residual > 0.002
            if (gradient.underconstrained) issues += RoofPlaneSolverIssue(
                "FACE_WITHOUT_SLOPE", "Plocha nemá sklon ani jednoznačnú nízku hranu; použil sa vodorovný fallback.", face.id
            )
            if (residual > 0.002) issues += RoofPlaneSolverIssue(
                "PLANE_RESIDUAL", "Constraints plochy nie sú úplne kompatibilné.", face.id, residual
            )
            face.copy(plane = plane, underconstrained = underconstrained)
        }
        return RoofPlaneSolution(
            input.copy(nodes = solvedNodes, faces = solvedFaces),
            issues,
            maximumResidual
        )
    }
}
