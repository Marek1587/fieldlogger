from pathlib import Path

from PIL import Image
from reportlab.lib.colors import Color, HexColor, white
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas


ROOT = Path(__file__).resolve().parents[3]
UNDERLAY = ROOT / "tmp" / "pdfs" / "zbgis-situation-underlay.jpg"
OUTPUT = ROOT / "output" / "pdf" / "StrechoStav-Sketch-v3.7.26-Situacia-osadenia-stavby-vzor.pdf"


def register_fonts() -> None:
    pdfmetrics.registerFont(TTFont("Arial", "C:/Windows/Fonts/arial.ttf"))
    pdfmetrics.registerFont(TTFont("Arial-Bold", "C:/Windows/Fonts/arialbd.ttf"))


def crop_to_ratio(source: Path, target: Path, ratio: float) -> None:
    with Image.open(source) as image:
        current = image.width / image.height
        if current > ratio:
            width = int(image.height * ratio)
            left = (image.width - width) // 2
            crop = image.crop((left, 0, left + width, image.height))
        else:
            height = int(image.width / ratio)
            top = (image.height - height) // 2
            crop = image.crop((0, top, image.width, top + height))
        crop.save(target, quality=94)


def main() -> None:
    register_fonts()
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    cropped = ROOT / "tmp" / "pdfs" / "zbgis-situation-cropped.jpg"
    page_w, page_h = A4
    map_box = (24, 55, 571, 799)
    map_w = map_box[2] - map_box[0]
    map_h = map_box[3] - map_box[1]
    crop_to_ratio(UNDERLAY, cropped, map_w / map_h)

    pdf = canvas.Canvas(str(OUTPUT), pagesize=A4, pageCompression=1)
    pdf.setTitle("Situácia osadenia stavby")
    pdf.setAuthor("StrechoStav Sketch")
    pdf.setFillColor(white)
    pdf.rect(0, 0, page_w, page_h, fill=1, stroke=0)
    pdf.setStrokeColor(HexColor("#101010"))
    pdf.setLineWidth(1)
    pdf.rect(10, 10, 575, 822, fill=0, stroke=1)
    pdf.setFillColor(HexColor("#111111"))
    pdf.setFont("Arial-Bold", 15)
    pdf.drawString(24, 808, "SITUÁCIA OSADENIA STAVBY")
    pdf.setFont("Arial", 8)
    pdf.drawRightString(571, 808, "StrechoStav Sketch • vzor projektu")

    pdf.drawImage(str(cropped), map_box[0], page_h - map_box[3], map_w, map_h, preserveAspectRatio=False)
    polygon = [
        (154, 582),
        (400, 608),
        (452, 462),
        (412, 276),
        (174, 250),
        (127, 397),
    ]
    polygon = [(x, page_h - y) for x, y in polygon]
    path = pdf.beginPath()
    path.moveTo(*polygon[0])
    for point in polygon[1:]:
        path.lineTo(*point)
    path.close()
    pdf.saveState()
    pdf.setFillColor(Color(20 / 255, 126 / 255, 67 / 255, alpha=0.20))
    pdf.drawPath(path, fill=1, stroke=0)
    pdf.clipPath(path, stroke=0, fill=0)
    pdf.setStrokeColor(Color(15 / 255, 106 / 255, 55 / 255, alpha=0.72))
    pdf.setLineWidth(1.1)
    for offset in range(-500, 950, 13):
        pdf.line(80 + offset, 185, 620 + offset, 725)
    pdf.restoreState()
    pdf.setStrokeColor(Color(1, 1, 1, alpha=0.90))
    pdf.setLineWidth(4.0)
    pdf.drawPath(path, fill=0, stroke=1)
    pdf.setStrokeColor(HexColor("#0D6935"))
    pdf.setLineWidth(2.2)
    pdf.drawPath(path, fill=0, stroke=1)
    pdf.setStrokeColor(HexColor("#808782"))
    pdf.setLineWidth(0.7)
    pdf.rect(map_box[0], page_h - map_box[3], map_w, map_h, fill=0, stroke=1)
    pdf.setFillColor(HexColor("#222222"))
    pdf.setFont("Arial", 7.5)
    pdf.drawString(28, 24, "Ortofoto © GKÚ Bratislava, CC BY 4.0")
    pdf.showPage()
    pdf.save()


if __name__ == "__main__":
    main()
