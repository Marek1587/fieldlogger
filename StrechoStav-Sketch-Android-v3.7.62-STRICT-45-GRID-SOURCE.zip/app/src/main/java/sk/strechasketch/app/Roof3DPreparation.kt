package sk.strechasketch.app

import kotlin.math.hypot

data class Roof3DPreparationResult(
    val topology: RoofTopology,
    val graph: RoofGraph,
    val planeSolution: RoofPlaneSolution,
    val topologyWasAdjusted: Boolean,
    val planeWasApproximated: Boolean
)

/** Single preparation path shared by live 3D, bitmap/PDF and quantities. */
object Roof3DPreparation {
    /**
     * Creates only a derived incidence representation for 3D. If an already existing internal
     * endpoint lies exactly on an unsplit boundary edge, that edge is represented by two virtual
     * edge records meeting in the same node. No node is created or moved and this topology is
     * never persisted back to [RoofProject].
     */
    private fun addVirtualBoundaryIncidence(source: RoofTopology): RoofTopology {
        val nodes = source.nodes.associateBy { it.id }
        val internalEndpointIds = source.edges.asSequence().filterNot { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val replacements = source.edges.filter { it.boundary }.associate { edge ->
            val a = nodes[edge.startNodeId]
            val b = nodes[edge.endNodeId]
            if (a == null || b == null) return@associate edge.id to listOf(edge.copy())
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length2 = dx * dx + dy * dy
            if (length2 <= 1e-18) return@associate edge.id to listOf(edge.copy())
            val splits = internalEndpointIds.asSequence()
                .filter { it != edge.startNodeId && it != edge.endNodeId }
                .mapNotNull { id ->
                    val point = nodes[id] ?: return@mapNotNull null
                    val t = ((point.x - a.x) * dx + (point.y - a.y) * dy) / length2
                    if (t <= 1e-8 || t >= 1.0 - 1e-8) return@mapNotNull null
                    val distance = hypot(point.x - (a.x + t * dx), point.y - (a.y + t * dy))
                    if (distance > 1e-7) null else t to id
                }.sortedBy { it.first }.distinctBy { it.second }.toList()
            if (splits.isEmpty()) edge.id to listOf(edge.copy())
            else {
                val chain = listOf(edge.startNodeId) + splits.map { it.second } + edge.endNodeId
                edge.id to chain.zipWithNext().mapIndexed { index, pair ->
                    edge.copy(
                        id = if (index == 0) edge.id else "${edge.id}::virtual-$index",
                        startNodeId = pair.first,
                        endNodeId = pair.second
                    )
                }
            }
        }
        return source.copy(
            nodes = source.nodes.map { it.copy() },
            edges = source.edges.flatMap { edge -> replacements[edge.id] ?: listOf(edge.copy()) }
        )
    }

    fun prepare(project: RoofProject): Roof3DPreparationResult {
        val footprintContext = WallFootprintSolver.context(project)
        val base = project.roofGraph?.toTopology()
            ?: project.roofTopology
            // Legacy adaptation may initialise the persistent metric frame. 3D is a read-only
            // consumer, therefore it operates on a shallow project value copy.
            ?: RoofTopologyMigration.fromLegacyProject(project.copy())

        // First perform the same bounded, topology-preserving cleanup offered
        // by card 2. This may merge existing near-coincident endpoints but can
        // never add a node or an edge.
        val conservative = RoofTopologySolver.solveInternal(
            base,
            footprintContext = footprintContext,
            completeRepair = false
        ).proposed
        val prepared = addVirtualBoundaryIncidence(conservative)

        val graph = GableTractSlopeSolver.apply(
            RoofGraphFactory.fromTopology(prepared, project.roofGraph, normalizeGrid = false),
            project.slopeDeg,
            footprintContext
        )
        val flatRoofMode = project.shape == RoofShape.FLAT || graph.edges.values.any {
            it.boundary && it.semanticRole == EdgeSemantic.ATTIC
        }
        val exact = RoofPlaneSolver.solve(
            graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
        )
        val planes = if (exact.hasBlockingIssues) {
            RoofPlaneSolver.solveForRendering(
                graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
            )
        } else exact
        return Roof3DPreparationResult(
            topology = prepared,
            graph = planes.graph,
            planeSolution = planes,
            topologyWasAdjusted = prepared != base,
            planeWasApproximated = planes.issues.any { it.code == "APPROXIMATED_HARD_CONSTRAINTS" }
        )
    }
}
