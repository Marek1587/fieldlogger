package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class GeoPoint(var lat: Double, var lon: Double)
data class LocalPoint(var x: Double, var y: Double)

enum class RoofShape(val label: String) {
    AUTO("Automaticky podľa čiar"),
    FLAT("Plochá"),
    GABLE("Sedlová"),
    HIP("Valbová / stanová"),
    SHED("Pultová");

    companion object {
        fun from(value: String?): RoofShape =
            entries.firstOrNull { it.name == value } ?: AUTO
    }
}

enum class LineType(val label: String, val color: Int) {
    UNKNOWN("Neurčená", 0xff607d8b.toInt()),
    RIDGE("Hrebeň", 0xffd52222.toInt()),
    VALLEY("Úžľabie", 0xff1f60d4.toInt()),
    HIP("Nárožie", 0xff8a2bb8.toInt()),
    ATTIC("Atika", 0xffd77a00.toInt()),
    PULT("Pultová hrana", 0xff795548.toInt()),
    WALL_END("Pri murive", 0xff666666.toInt()),
    EAVE("Odkvap", 0xff15924a.toInt()),
    GABLE("Štít", 0xff222222.toInt()),
    RAKE("Šikmá obvodová hrana", 0xff455a64.toInt()),
    LOW_EDGE("Nízka hrana", 0xff00897b.toInt()),
    ELEVATED_LOW_EDGE("Zvýšená nízka hrana", 0xff00695c.toInt()),
    STEP("Výškový odskok", 0xff6d4c41.toInt()),
    OPENING_BOUNDARY("Hrana otvoru", 0xff546e7a.toInt());

    companion object {
        fun from(value: String?): LineType =
            entries.firstOrNull { it.name == value } ?: RIDGE
    }
}

enum class ObjectType(val label: String) {
    CHIMNEY("Komín"),
    ROOF_WINDOW("Strešné okno"),
    HATCH("Výlez"),
    VENT("Prestup / vetranie"),
    DORMER("Vikier"),
    MACHINE_ROOM("Strojovňa výťahu"),
    SHAFT("Šachta"),
    TERRACE("Strešná terasa"),
    DRAIN("Strešná vpusť"),
    DOWNSPOUT("Zvodová rúra"),
    HEIGHT_MARK("Výšková kóta"),
    SLOPE_MARK("Sklon");

    companion object {
        fun from(value: String?): ObjectType =
            entries.firstOrNull { it.name == value } ?: CHIMNEY
    }
}

enum class DormerType(val label: String) {
    GABLE("Sedlový vikier"),
    SHED("Pultový vikier"),
    HIPPED("Valbový vikier"),
    NAPOLEON("Napoleonský vikier"),
    EYEBROW("Volské oko"),
    TRIANGULAR("Štítový (trojuholníkový) vikier"),
    ARCHED("Oblúkový vikier"),
    TRAPEZOID("Trapézový vikier");

    /** Initial pitch used only when a dormer is created or its type is changed. */
    fun defaultSlopeDeg(): Double = when (this) {
        SHED, ARCHED, TRAPEZOID -> 10.0
        else -> 25.0
    }

    companion object {
        fun from(value: String?): DormerType =
            entries.firstOrNull { it.name == value } ?: GABLE
    }
}

enum class DownspoutTermination(val label: String) {
    ELBOW_72("Koleno 72°"),
    SOAKAWAY("Zaústenie do trativodu");

    companion object {
        fun from(value: String?): DownspoutTermination =
            entries.firstOrNull { it.name == value } ?: ELBOW_72
    }
}

/** Semantic decomposition of the wall footprint used by plan correction and 3D preparation. */
enum class WallFootprintPartType(val label: String) {
    MAIN_TRACT("Hlavný strešný trakt"),
    PROJECTION("Výstupok / rizalit"),
    RECESS("Výklenok"),
    SEPARATE_WING("Samostatné krídlo"),
    SUPERSTRUCTURE("Nadstavba / vikier");

    companion object {
        fun from(value: String?): WallFootprintPartType =
            entries.firstOrNull { it.name == value } ?: MAIN_TRACT
    }
}

enum class WallFootprintPartSource {
    AUTOMATIC,
    USER;

    companion object {
        fun from(value: String?): WallFootprintPartSource =
            entries.firstOrNull { it.name == value } ?: AUTOMATIC
    }
}

/**
 * One solver-recognised footprint region. The current solver emits orthogonal rectangles,
 * while the polygon representation keeps the schema ready for non-rectangular future tracts.
 */
data class WallFootprintPart(
    val id: String,
    var type: WallFootprintPartType,
    var polygon: MutableList<GeoPoint>,
    var source: WallFootprintPartSource = WallFootprintPartSource.AUTOMATIC,
    var confidence: Double = 1.0,
    var hostPartId: String? = null,
    var sourceObjectId: String? = null
)

data class RoofLine(
    val id: String = UUID.randomUUID().toString(),
    var type: LineType,
    var start: GeoPoint,
    var end: GeoPoint,
    var note: String = ""
)

data class RoofObject(
    val id: String = UUID.randomUUID().toString(),
    var type: ObjectType,
    var center: GeoPoint,
    var widthMm: Double = 0.0,
    var heightMm: Double = 0.0,
    var diameterMm: Double = 0.0,
    var value: Double = 0.0,
    /** True after the user explicitly changes chimney height with the dimension wheel. */
    var chimneyHeightManual: Boolean = false,
    var rotationDeg: Double = 0.0,
    var note: String = "",
    var attachedFaceId: String? = null,
    var attachedEdgeId: String? = null,
    var directionX: Double = 0.0,
    var directionY: Double = 1.0,
    /** Shape of the secondary roof envelope when [type] is [ObjectType.DORMER]. */
    var dormerType: DormerType = DormerType.GABLE,
    /** Finished height/elevation above the host roof eave reference, in metres. */
    var superstructureHeightM: Double = 1.2,
    /** Roof pitch of a dormer; machine rooms and shafts stay flat. */
    var superstructureSlopeDeg: Double = 15.0,
    /** Dormer roof overhang measured horizontally from the dormer wall, in millimetres. */
    var dormerOverhangMm: Double = 250.0,
    /** Persistent configuration for a roof-drainage downspout. */
    var downspoutTermination: DownspoutTermination = DownspoutTermination.ELBOW_72,
    /** True when this object overrides a deterministic solver-created downspout. */
    var downspoutAutomatic: Boolean = false,
    /** Keeps a removed automatic downspout suppressed across future solver runs. */
    var downspoutSuppressed: Boolean = false
)

data class RoofProject(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Nová strecha",
    var customer: String = "",
    var address: String = "",
    var centerLat: Double = 49.0663,
    var centerLon: Double = 18.9236,
    var zoom: Int = 19,
    var mapRotationDeg: Double = 0.0,
    /** Stable origin of the invisible 100 mm plan grid; independent of the map camera. */
    var geometryGridOriginLat: Double = Double.NaN,
    var geometryGridOriginLon: Double = Double.NaN,
    /** Grid U-axis relative to local east. A square lattice is invariant modulo 90 degrees. */
    var geometryGridRotationDeg: Double = Double.NaN,
    var slopeDeg: Double = 10.0,
    var wallHeightM: Double = 3.0,
    var atticHeightM: Double = 0.3,
    /** Finished parapet thickness measured inward from the roof boundary. */
    var atticWidthM: Double = 0.25,
    var shape: RoofShape = RoofShape.AUTO,
    var mapType: String = "ZBGIS_ORTHO",
    var lastGoogleMapType: String = "ZBGIS_ORTHO",
    var underlayUri: String = "",
    var underlayMime: String = "",
    var underlayName: String = "",
    var underlayOriginLat: Double = 49.0663,
    var underlayOriginLon: Double = 18.9236,
    var underlayMetersPerPixel: Double = 0.01,
    var underlayZoom: Double = 1.0,
    var underlayCenterX: Double = -1.0,
    var underlayCenterY: Double = -1.0,
    /** Physical roof boundary. It may differ from the wall footprint because of overhangs. */
    var polygon: MutableList<GeoPoint> = mutableListOf(),
    var wallFootprint: MutableList<GeoPoint> = mutableListOf(),
    /** Persisted automatic/user-refined decomposition of [wallFootprint]. */
    var wallFootprintParts: MutableList<WallFootprintPart> = mutableListOf(),
    /** Geometry digest used to detect when an automatic decomposition became stale. */
    var wallFootprintPartsSignature: String = "",
    var lines: MutableList<RoofLine> = mutableListOf(),
    var objects: MutableList<RoofObject> = mutableListOf(),
    var edgeTypes: MutableMap<Int, LineType> = mutableMapOf(),
    var roofTopology: RoofTopology? = null,
    var roofGraph: RoofGraph? = null,
    var selectedWorkItems: MutableMap<String, SelectedWorkItem> = mutableMapOf(),
    /** VAT used only for the commercial offer; geometry and quantities remain VAT-neutral. */
    var budgetVatPercent: Double = 23.0,
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis()
)

object ProjectJson {
    fun encode(project: RoofProject, preparedTotals: ProjectTotals? = null): String = JSONObject().apply {
        put("schema", "strechostav-sketch-project-10")
        put("schema_version", 10)
        put("id", project.id)
        put("name", project.name)
        put("customer", project.customer)
        put("address", project.address)
        put("center_lat", project.centerLat)
        put("center_lon", project.centerLon)
        put("zoom", project.zoom)
        put("map_rotation_deg", project.mapRotationDeg)
        if (project.geometryGridOriginLat.isFinite() && project.geometryGridOriginLon.isFinite()) {
            put("geometry_grid_origin_lat", project.geometryGridOriginLat)
            put("geometry_grid_origin_lon", project.geometryGridOriginLon)
        }
        if (project.geometryGridRotationDeg.isFinite()) {
            put("geometry_grid_rotation_deg", project.geometryGridRotationDeg)
        }
        put("slope_deg", project.slopeDeg)
        put("wall_height_m", project.wallHeightM)
        put("attic_height_m", project.atticHeightM)
        put("attic_width_m", project.atticWidthM)
        put("roof_shape", project.shape.name)
        put("map_type", project.mapType)
        put("last_google_map_type", project.lastGoogleMapType)
        put("underlay_uri", project.underlayUri)
        put("underlay_mime", project.underlayMime)
        put("underlay_name", project.underlayName)
        put("underlay_origin_lat", project.underlayOriginLat)
        put("underlay_origin_lon", project.underlayOriginLon)
        put("underlay_meters_per_pixel", project.underlayMetersPerPixel)
        put("underlay_zoom", project.underlayZoom)
        put("underlay_center_x", project.underlayCenterX)
        put("underlay_center_y", project.underlayCenterY)
        put("created_at", project.createdAt)
        put("updated_at", project.updatedAt)
        put("polygon", JSONArray().also { array ->
            project.polygon.forEach { array.put(pointJson(it)) }
        })
        put("wall_footprint", JSONArray().also { array ->
            project.wallFootprint.forEach { array.put(pointJson(it)) }
        })
        put("wall_footprint_parts_signature", project.wallFootprintPartsSignature)
        put("wall_footprint_parts", JSONArray().also { array ->
            project.wallFootprintParts.sortedBy { it.id }.forEach { part ->
                array.put(JSONObject().apply {
                    put("id", part.id)
                    put("type", part.type.name)
                    put("source", part.source.name)
                    put("confidence", part.confidence)
                    part.hostPartId?.let { put("host_part_id", it) }
                    part.sourceObjectId?.let { put("source_object_id", it) }
                    put("polygon", JSONArray().also { points ->
                        part.polygon.forEach { points.put(pointJson(it)) }
                    })
                })
            }
        })
        put("lines", JSONArray().also { array ->
            project.lines.forEach { line ->
                array.put(JSONObject().apply {
                    put("id", line.id)
                    put("type", line.type.name)
                    put("start", pointJson(line.start))
                    put("end", pointJson(line.end))
                    put("note", line.note)
                })
            }
        })
        put("objects", JSONArray().also { array ->
            project.objects.forEach { item ->
                array.put(JSONObject().apply {
                    put("id", item.id)
                    put("type", item.type.name)
                    put("center", pointJson(item.center))
                    put("width_mm", item.widthMm)
                    put("height_mm", item.heightMm)
                    put("diameter_mm", item.diameterMm)
                    put("value", item.value)
                    put("chimney_height_manual", item.chimneyHeightManual)
                    put("rotation_deg", item.rotationDeg)
                    put("note", item.note)
                    item.attachedFaceId?.let { put("attached_face_id", it) }
                    item.attachedEdgeId?.let { put("attached_edge_id", it) }
                    put("direction_x", item.directionX)
                    put("direction_y", item.directionY)
                    put("dormer_type", item.dormerType.name)
                    put("superstructure_height_m", item.superstructureHeightM)
                    put("superstructure_slope_deg", item.superstructureSlopeDeg)
                    put("dormer_overhang_mm", item.dormerOverhangMm)
                    put("downspout_termination", item.downspoutTermination.name)
                    put("downspout_automatic", item.downspoutAutomatic)
                    put("downspout_suppressed", item.downspoutSuppressed)
                })
            }
        })
        put("edge_types", JSONObject().also { edges ->
            project.edgeTypes.forEach { (index, type) -> edges.put(index.toString(), type.name) }
        })
        val graph = project.roofGraph ?: RoofGraphFactory.fromTopology(
            project.roofTopology ?: RoofTopologyMigration.fromLegacyProject(project)
        )
        put("roof_graph", RoofGraphJson.encode(graph))
        put("roof_topology", topologyJson(graph.toTopology()))
        put("selected_work_items", JSONArray().also { array ->
            project.selectedWorkItems.values.sortedBy { it.code }.forEach { item ->
                array.put(JSONObject().apply {
                    put("code", item.code); put("selected", item.selected)
                    item.unitPrice?.let { put("unit_price", it) }
                    item.manualQuantityOverride?.let { put("manual_quantity_override", it) }
                })
            }
        })
        put("budget_vat_percent", project.budgetVatPercent)
        put("summary", (preparedTotals ?: ProjectSummary.calculate(project)).toJson())
    }.toString(2)

    fun decode(text: String): RoofProject {
        val root = JSONObject(text)
        if (isCanonicalRoofModel(root)) return decodeCanonicalRoofModel(root)
        val project = RoofProject(
            id = root.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = root.optString("name", "Strecha"),
            customer = root.optString("customer"),
            address = root.optString("address"),
            centerLat = root.optDouble("center_lat", 49.0663),
            centerLon = root.optDouble("center_lon", 18.9236),
            zoom = root.optInt("zoom", 19).coerceIn(3, 26),
            mapRotationDeg = root.optDouble("map_rotation_deg", 0.0).let { value ->
                ((value % 360.0) + 360.0) % 360.0
            },
            geometryGridOriginLat = root.optDouble("geometry_grid_origin_lat", Double.NaN),
            geometryGridOriginLon = root.optDouble("geometry_grid_origin_lon", Double.NaN),
            geometryGridRotationDeg = root.optDouble("geometry_grid_rotation_deg", Double.NaN),
            slopeDeg = root.optDouble("slope_deg", 10.0).coerceIn(0.0, 75.0),
            wallHeightM = root.optDouble("wall_height_m", 3.0).coerceIn(0.5, 100.0),
            atticHeightM = root.optDouble("attic_height_m", 0.3).coerceIn(0.1, 3.0),
            atticWidthM = root.optDouble("attic_width_m", 0.25).coerceIn(0.06, 1.5),
            shape = RoofShape.from(root.optString("roof_shape")),
            mapType = root.optString("map_type", "ZBGIS_ORTHO").let {
                when (it.uppercase()) {
                    "SATELLITE", "HYBRID" -> "ZBGIS_ORTHO"
                    "NORMAL", "OSM", "TERRAIN", "OSM_TERRAIN" -> "ZBGIS_ORTHO"
                    else -> it
                }
            },
            lastGoogleMapType = root.optString("last_google_map_type", root.optString("map_type", "ZBGIS_ORTHO")).let {
                when (it.uppercase()) {
                    "DOCUMENT", "SATELLITE", "HYBRID" -> "ZBGIS_ORTHO"
                    "NORMAL", "OSM", "TERRAIN", "OSM_TERRAIN" -> "ZBGIS_ORTHO"
                    else -> it
                }
            },
            underlayUri = root.optString("underlay_uri"),
            underlayMime = root.optString("underlay_mime"),
            underlayName = root.optString("underlay_name"),
            underlayOriginLat = root.optDouble("underlay_origin_lat", root.optDouble("center_lat", 49.0663)),
            underlayOriginLon = root.optDouble("underlay_origin_lon", root.optDouble("center_lon", 18.9236)),
            underlayMetersPerPixel = root.optDouble("underlay_meters_per_pixel", 0.01).coerceIn(0.00001, 1000.0),
            underlayZoom = root.optDouble("underlay_zoom", 1.0).coerceIn(0.05, 100.0),
            underlayCenterX = root.optDouble("underlay_center_x", -1.0),
            underlayCenterY = root.optDouble("underlay_center_y", -1.0),
            budgetVatPercent = root.optDouble("budget_vat_percent", 23.0).coerceIn(0.0, 100.0),
            createdAt = root.optLong("created_at", System.currentTimeMillis()),
            updatedAt = root.optLong("updated_at", System.currentTimeMillis())
        )
        val polygon = root.optJSONArray("polygon") ?: JSONArray()
        repeat(polygon.length()) { index ->
            project.polygon += point(polygon.getJSONObject(index))
        }
        val wallFootprint = root.optJSONArray("wall_footprint")
        if (wallFootprint != null) repeat(wallFootprint.length()) { index ->
            project.wallFootprint += point(wallFootprint.getJSONObject(index))
        }
        if (project.wallFootprint.isEmpty()) project.wallFootprint = project.polygon.map { it.copy() }.toMutableList()
        project.wallFootprintPartsSignature = root.optString("wall_footprint_parts_signature")
        root.optJSONArray("wall_footprint_parts")?.let { parts ->
            repeat(parts.length()) { index ->
                val item = parts.optJSONObject(index) ?: return@repeat
                val partPolygon = mutableListOf<GeoPoint>()
                item.optJSONArray("polygon")?.let { points ->
                    repeat(points.length()) { pointIndex ->
                        points.optJSONObject(pointIndex)?.let { partPolygon += point(it) }
                    }
                }
                if (partPolygon.size >= 3) project.wallFootprintParts += WallFootprintPart(
                    id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                    type = WallFootprintPartType.from(item.optString("type")),
                    polygon = partPolygon,
                    source = WallFootprintPartSource.from(item.optString("source")),
                    confidence = item.optDouble("confidence", 1.0).coerceIn(0.0, 1.0),
                    hostPartId = item.optString("host_part_id").takeIf(String::isNotBlank),
                    sourceObjectId = item.optString("source_object_id").takeIf(String::isNotBlank)
                )
            }
        }
        val lines = root.optJSONArray("lines") ?: JSONArray()
        repeat(lines.length()) { index ->
            val item = lines.getJSONObject(index)
            project.lines += RoofLine(
                id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = LineType.from(item.optString("type")),
                start = point(item.getJSONObject("start")),
                end = point(item.getJSONObject("end")),
                note = item.optString("note")
            )
        }
        val objects = root.optJSONArray("objects") ?: JSONArray()
        repeat(objects.length()) { index ->
            val item = objects.getJSONObject(index)
            project.objects += RoofObject(
                id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = ObjectType.from(item.optString("type")),
                center = point(item.getJSONObject("center")),
                widthMm = item.optDouble("width_mm"),
                heightMm = item.optDouble("height_mm"),
                diameterMm = item.optDouble("diameter_mm"),
                value = item.optDouble("value"),
                chimneyHeightManual = if (item.has("chimney_height_manual")) {
                    item.optBoolean("chimney_height_manual", false)
                } else {
                    // Before this flag existed, a positive stored chimney height could only
                    // have come from the user's dimension editor. Preserve that intent.
                    ObjectType.from(item.optString("type")) == ObjectType.CHIMNEY &&
                        item.optDouble("value") > 0.0
                },
                rotationDeg = item.optDouble("rotation_deg"),
                note = item.optString("note"),
                attachedFaceId = item.optString("attached_face_id").takeIf(String::isNotBlank),
                attachedEdgeId = item.optString("attached_edge_id").takeIf(String::isNotBlank),
                directionX = item.optDouble("direction_x", 0.0),
                directionY = item.optDouble("direction_y", 1.0),
                dormerType = DormerType.from(item.optString("dormer_type")),
                superstructureHeightM = item.optDouble("superstructure_height_m", 1.2),
                superstructureSlopeDeg = item.optDouble("superstructure_slope_deg", 15.0),
                dormerOverhangMm = item.optDouble("dormer_overhang_mm", 250.0),
                downspoutTermination = DownspoutTermination.from(item.optString("downspout_termination")),
                downspoutAutomatic = item.optBoolean("downspout_automatic", false),
                downspoutSuppressed = item.optBoolean("downspout_suppressed", false)
            )
        }
        val edges = root.optJSONObject("edge_types")
        edges?.keys()?.forEach { key ->
            key.toIntOrNull()?.let { project.edgeTypes[it] = LineType.from(edges.optString(key)) }
        }
        project.roofGraph = root.optJSONObject("roof_graph")?.let(RoofGraphJson::decode)
            ?: root.optJSONObject("roof_topology")?.let(::topologyFromJson)?.let(RoofGraphFactory::fromTopology)
            ?: RoofGraphFactory.fromTopology(RoofTopologyMigration.fromLegacyProject(project))
        project.roofTopology = project.roofGraph?.toTopology()
        // Schema 5 owns geometry in roof_graph. Legacy fields are retained only as
        // a compatibility mirror for the staged UI migration and are refreshed
        // from the graph whenever the graph contains a valid boundary cycle.
        project.roofGraph?.let { graph ->
            RoofTopologyMigration.applyToProject(project, graph.toTopology(), requireFullyValid = false)
        }
        root.optJSONArray("selected_work_items")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index)
            val code = item.optString("code")
            if (code.isNotBlank()) project.selectedWorkItems[code] = SelectedWorkItem(
                code = code,
                selected = item.optBoolean("selected"),
                unitPrice = item.optDoubleOrNull("unit_price"),
                manualQuantityOverride = item.optDoubleOrNull("manual_quantity_override")
            )
        } }
        return project
    }

    /**
     * Imports the neutral face-based `roof-face-model/1.x` interchange model.
     * Roof geometry remains owned by stable node/edge/face IDs; the legacy
     * polygon fields are rebuilt only as an editor compatibility projection.
     */
    private fun decodeCanonicalRoofModel(root: JSONObject): RoofProject {
        val origin = GeoPoint(49.0663, 18.9236)
        val graph = CanonicalRoofJson.decode(root, origin)
        val metadata = root.optJSONObject("metadata")
        val project = RoofProject(
            id = metadata?.optString("id")?.takeIf(String::isNotBlank) ?: UUID.randomUUID().toString(),
            name = metadata?.optString("title")?.takeIf(String::isNotBlank) ?: "Importovaná strecha",
            centerLat = origin.lat,
            centerLon = origin.lon,
            slopeDeg = graph.faces.values.mapNotNull { it.slopeConstraint?.angleDeg }.averageOrNull() ?: 10.0,
            wallHeightM = graph.nodes.values.filter { it.lockZ }.minOfOrNull { it.z }?.coerceIn(0.5, 100.0) ?: 3.0,
            mapType = "ZBGIS_ORTHO"
        )
        project.roofGraph = graph
        project.roofTopology = graph.toTopology()

        val boundaryIds = root.optJSONObject("plan")
            ?.optJSONArray("roofBoundaries")
            ?.optJSONObject(0)
            ?.optJSONArray("outerLoopNodeIds")
            ?.let(::jsonStrings)
            .orEmpty()
        val fallbackBoundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())?.first.orEmpty()
        (boundaryIds.ifEmpty { fallbackBoundary }).mapNotNull(graph.nodes::get).forEach { node ->
            project.polygon += Geometry.toGeo(LocalPoint(node.x, node.y), origin)
        }

        val scale = canonicalUnitScale(root)
        root.optJSONObject("plan")?.optJSONArray("wallFootprints")?.optJSONObject(0)
            ?.optJSONArray("outerLoop")?.let { loop ->
                repeat(loop.length()) { index ->
                    val xy = loop.optJSONArray(index) ?: return@repeat
                    project.wallFootprint += Geometry.toGeo(
                        LocalPoint(xy.optDouble(0) * scale, xy.optDouble(1) * scale), origin
                    )
                }
            }
        if (project.wallFootprint.isEmpty()) {
            project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
        }
        RoofTopologyMigration.applyToProject(project, graph.toTopology(), requireFullyValid = false)
        return project
    }

    private fun isCanonicalRoofModel(root: JSONObject): Boolean =
        root.optString("schema").startsWith("roof-face-model/") ||
            (root.has("coordinateSystem") && root.has("nodes") && root.has("edges") && root.has("faces"))

    private fun canonicalUnitScale(root: JSONObject): Double = when (
        root.optJSONObject("coordinateSystem")?.optString("units", "mm")?.lowercase()
    ) {
        "m" -> 1.0
        "cm" -> 0.01
        else -> 0.001
    }

    private fun jsonStrings(array: JSONArray): List<String> =
        List(array.length()) { index -> array.optString(index) }.filter(String::isNotBlank)

    private fun List<Double>.averageOrNull(): Double? = if (isEmpty()) null else average()

    private fun topologyJson(topology: RoofTopology) = JSONObject().apply {
        put("schema_version", topology.schemaVersion)
        put("origin", pointJson(topology.origin))
        if (topology.gridRotationDeg.isFinite()) put("grid_rotation_deg", topology.gridRotationDeg)
        put("nodes", JSONArray().also { array ->
            topology.nodes.forEach { node ->
                array.put(JSONObject().apply {
                    put("id", node.id)
                    put("x", node.x)
                    put("y", node.y)
                    put("type", node.type.name)
                    put("locked", node.locked)
                })
            }
        })
        put("edges", JSONArray().also { array ->
            topology.edges.forEach { edge ->
                array.put(JSONObject().apply {
                    put("id", edge.id)
                    put("start_node_id", edge.startNodeId)
                    put("end_node_id", edge.endNodeId)
                    put("type", edge.type.name)
                    put("locked", edge.locked)
                    put("boundary", edge.boundary)
                    edge.sourceId?.let { put("source_id", it) }
                    put("note", edge.note)
                })
            }
        })
    }

    private fun topologyFromJson(value: JSONObject): RoofTopology {
        val origin = value.optJSONObject("origin")?.let(::point) ?: GeoPoint(49.0663, 18.9236)
        val nodesJson = value.optJSONArray("nodes") ?: JSONArray()
        val nodes = MutableList(nodesJson.length()) { index ->
            val node = nodesJson.getJSONObject(index)
            TopologyNode(
                id = node.optString("id").ifBlank { UUID.randomUUID().toString() },
                x = node.optDouble("x"),
                y = node.optDouble("y"),
                type = runCatching { TopologyNodeType.valueOf(node.optString("type")) }
                    .getOrDefault(TopologyNodeType.LINE_ENDPOINT),
                locked = node.optBoolean("locked")
            )
        }
        val edgesJson = value.optJSONArray("edges") ?: JSONArray()
        val topologyEdges = MutableList(edgesJson.length()) { index ->
            val edge = edgesJson.getJSONObject(index)
            TopologyEdge(
                id = edge.optString("id").ifBlank { UUID.randomUUID().toString() },
                startNodeId = edge.optString("start_node_id"),
                endNodeId = edge.optString("end_node_id"),
                type = LineType.from(edge.optString("type")),
                locked = edge.optBoolean("locked"),
                boundary = edge.optBoolean("boundary"),
                sourceId = edge.optString("source_id").takeIf { it.isNotBlank() },
                note = edge.optString("note")
            )
        }
        return RoofTopology(
            origin = origin,
            nodes = nodes,
            edges = topologyEdges,
            schemaVersion = value.optInt("schema_version", 2),
            gridRotationDeg = value.optDouble("grid_rotation_deg", Double.NaN)
        )
    }

    private fun pointJson(point: GeoPoint) =
        JSONObject().put("lat", point.lat).put("lon", point.lon)

    private fun point(value: JSONObject) =
        GeoPoint(value.optDouble("lat"), value.optDouble("lon", value.optDouble("lng")))

    private fun JSONObject.optDoubleOrNull(key: String): Double? =
        if (has(key) && !isNull(key)) optDouble(key) else null
}

data class ProjectTotals(
    val footprintAreaM2: Double,
    val roofAreaM2: Double,
    val perimeterM: Double,
    val ridgeM: Double,
    val valleyM: Double,
    val hipM: Double,
    val atticM: Double,
    val pultM: Double,
    val wallEndM: Double,
    val eaveM: Double,
    val gableM: Double,
    val chimneys: Int,
    val roofWindows: Int,
    val hatches: Int,
    val vents: Int,
    val drains: Int,
    val downspouts: Int,
    val heightMarks: Int,
    val slopeMarks: Int,
    val gutterHooks: Int = 0,
    val downspoutClamps: Int = 0,
    val innerGutterCorners90: Int = 0,
    val outerGutterCorners90: Int = 0,
    val dormers: Int = 0,
    val machineRooms: Int = 0,
    val shafts: Int = 0,
    val terraces: Int = 0,
    val superstructureOpeningAreaM2: Double = 0.0,
    val superstructureRoofAreaM2: Double = 0.0
) {
    fun toJson() = JSONObject().apply {
        put("footprint_area_m2", footprintAreaM2)
        put("roof_area_m2", roofAreaM2)
        put("perimeter_m", perimeterM)
        put("ridge_m", ridgeM)
        put("valley_m", valleyM)
        put("hip_m", hipM)
        put("attic_m", atticM)
        put("pult_m", pultM)
        put("wall_end_m", wallEndM)
        put("eave_m", eaveM)
        put("gable_m", gableM)
        put("chimneys", chimneys)
        put("roof_windows", roofWindows)
        put("hatches", hatches)
        put("vents", vents)
        put("drains", drains)
        put("downspouts", downspouts)
        put("gutter_hooks", gutterHooks)
        put("downspout_clamps", downspoutClamps)
        put("dormers", dormers)
        put("machine_rooms", machineRooms)
        put("shafts", shafts)
        put("terraces", terraces)
        put("superstructure_opening_area_m2", superstructureOpeningAreaM2)
        put("superstructure_roof_area_m2", superstructureRoofAreaM2)
        put("inner_gutter_corners_90", innerGutterCorners90)
        put("outer_gutter_corners_90", outerGutterCorners90)
        put("height_marks", heightMarks)
        put("slope_marks", slopeMarks)
    }
}

object ProjectSummary {
    fun calculate(project: RoofProject): ProjectTotals = RoofQuantityEngine.calculate(project).totals
}

object Geometry {
    private const val EARTH_R = 6_378_137.0

    fun centroid(points: List<GeoPoint>): GeoPoint {
        if (points.isEmpty()) return GeoPoint(49.0663, 18.9236)
        return GeoPoint(points.sumOf { it.lat } / points.size, points.sumOf { it.lon } / points.size)
    }

    fun toLocal(point: GeoPoint, origin: GeoPoint): LocalPoint {
        val x = Math.toRadians(point.lon - origin.lon) * EARTH_R * cos(Math.toRadians(origin.lat))
        val y = Math.toRadians(point.lat - origin.lat) * EARTH_R
        return LocalPoint(x, y)
    }

    fun toGeo(point: LocalPoint, origin: GeoPoint): GeoPoint {
        val lat = origin.lat + Math.toDegrees(point.y / EARTH_R)
        val lon = origin.lon + Math.toDegrees(point.x / (EARTH_R * cos(Math.toRadians(origin.lat))))
        return GeoPoint(lat, lon)
    }

    fun areaM2(points: List<GeoPoint>): Double {
        if (points.size < 3) return 0.0
        val origin = centroid(points)
        val local = points.map { toLocal(it, origin) }
        var sum = 0.0
        local.indices.forEach { index ->
            val next = (index + 1) % local.size
            sum += local[index].x * local[next].y - local[next].x * local[index].y
        }
        return abs(sum) / 2.0
    }

    fun perimeterM(points: List<GeoPoint>): Double {
        if (points.size < 2) return 0.0
        return points.indices.sumOf { index ->
            distanceM(points[index], points[(index + 1) % points.size])
        }
    }

    fun distanceM(a: GeoPoint, b: GeoPoint): Double {
        // All editable building geometry is solved in the local EPSG:3857-compatible
        // engineering frame above. Measuring the same points with a second haversine
        // radius (6 371 008.8 m) made an exact 7.000 m grid edge appear as 6.992 m.
        // Use the same metric definition for solving, labels, perimeter and exports.
        val local = toLocal(b, a)
        return hypot(local.x, local.y)
    }

    fun pointInPolygon(point: LocalPoint, polygon: List<LocalPoint>): Boolean {
        var inside = false
        if (polygon.size < 3) return false
        var previous = polygon.lastIndex
        polygon.indices.forEach { current ->
            val a = polygon[current]
            val b = polygon[previous]
            if ((a.y > point.y) != (b.y > point.y) &&
                point.x < (b.x - a.x) * (point.y - a.y) / ((b.y - a.y).takeIf { abs(it) > 1e-9 } ?: 1e-9) + a.x
            ) inside = !inside
            previous = current
        }
        return inside
    }

    fun distanceToSegment(point: LocalPoint, a: LocalPoint, b: LocalPoint): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        if (abs(dx) + abs(dy) < 1e-9) return hypot(point.x - a.x, point.y - a.y)
        val t = (((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy))
            .coerceIn(0.0, 1.0)
        return hypot(point.x - (a.x + t * dx), point.y - (a.y + t * dy))
    }

    /**
     * Distance that defines the zero-height line of an automatically solved roof.
     * Only eaves lower a pitched roof to the wall plate. A gable, wall junction,
     * attic or high purlin edge may contain an elevated ridge endpoint and must
     * therefore not be treated as an eave. Legacy projects without explicit eave
     * metadata retain the previous all-boundaries behaviour.
     */
    fun distanceToRoofBaseBoundary(
        point: LocalPoint,
        polygon: List<LocalPoint>,
        edgeTypes: Map<Int, LineType>
    ): Double {
        if (polygon.size < 2) return 0.0
        val explicitEaves = polygon.indices.filter { index ->
            (edgeTypes[index] ?: LineType.EAVE) == LineType.EAVE
        }
        val baseEdges = explicitEaves.ifEmpty { polygon.indices.toList() }
        return baseEdges.minOf { index ->
            distanceToSegment(point, polygon[index], polygon[(index + 1) % polygon.size])
        }
    }

    fun nearestDistanceToPolygon(point: GeoPoint, polygon: List<GeoPoint>): Double {
        if (polygon.size < 2) return Double.MAX_VALUE
        val local = polygon.map { toLocal(it, point) }
        if (pointInPolygon(LocalPoint(0.0, 0.0), local)) return 0.0
        return local.indices.minOf { index ->
            distanceToSegment(LocalPoint(0.0, 0.0), local[index], local[(index + 1) % local.size])
        }
    }

    fun regularize(points: List<GeoPoint>): MutableList<GeoPoint> {
        if (points.size < 3) return points.map { it.copy() }.toMutableList()
        val origin = centroid(points)
        val local = points.map { toLocal(it, origin) }
        val longest = local.indices.maxByOrNull { index ->
            val next = (index + 1) % local.size
            hypot(local[next].x - local[index].x, local[next].y - local[index].y)
        } ?: 0
        val nextLongest = (longest + 1) % local.size
        val base = atan2(
            local[nextLongest].y - local[longest].y,
            local[nextLongest].x - local[longest].x
        )
        val corrected = mutableListOf(local.first().copy())
        for (index in 0 until local.lastIndex) {
            val a = local[index]
            val b = local[index + 1]
            val length = hypot(b.x - a.x, b.y - a.y)
            val raw = atan2(b.y - a.y, b.x - a.x)
            val snapped = base + (kotlin.math.round((raw - base) / (PI / 4.0)) * (PI / 4.0))
            corrected += LocalPoint(
                corrected.last().x + cos(snapped) * length,
                corrected.last().y + sin(snapped) * length
            )
        }
        val closingRaw = local.first()
        val closingFrom = local.last()
        val closingLength = hypot(closingRaw.x - closingFrom.x, closingRaw.y - closingFrom.y)
        val closingAngleRaw = atan2(closingRaw.y - closingFrom.y, closingRaw.x - closingFrom.x)
        val closingAngle = base + (kotlin.math.round((closingAngleRaw - base) / (PI / 4.0)) * (PI / 4.0))
        val projectedEnd = LocalPoint(
            corrected.last().x + cos(closingAngle) * closingLength,
            corrected.last().y + sin(closingAngle) * closingLength
        )
        val errorX = projectedEnd.x - corrected.first().x
        val errorY = projectedEnd.y - corrected.first().y
        corrected.indices.forEach { index ->
            val share = index.toDouble() / corrected.size
            corrected[index].x -= errorX * share
            corrected[index].y -= errorY * share
        }
        return corrected.map { toGeo(it, origin) }.toMutableList()
    }

    fun worldX(lon: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        return (lon + 180.0) / 360.0 * scale
    }

    fun worldY(lat: Double, zoom: Int): Double {
        val safe = lat.coerceIn(-85.05112878, 85.05112878)
        val sinLat = sin(Math.toRadians(safe))
        val scale = 256.0 * (1 shl zoom)
        return (0.5 - ln((1 + sinLat) / (1 - sinLat)) / (4 * PI)) * scale
    }

    fun lonFromWorld(x: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        return x / scale * 360.0 - 180.0
    }

    fun latFromWorld(y: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        val n = PI - 2.0 * PI * y / scale
        return Math.toDegrees(atan2(0.5 * (kotlin.math.exp(n) - kotlin.math.exp(-n)), 1.0))
    }

    fun metersPerPixel(lat: Double, zoom: Int): Double =
        156543.03392 * cos(Math.toRadians(lat)) / (1 shl zoom)
}
