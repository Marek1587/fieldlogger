package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.InputDevice
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class EditorMode(val label: String) {
    PAN("Posun mapy"),
    DRAW_POLYGON("Obrys prstom"),
    ADD_VERTEX("Pridať body"),
    EDIT("Editovať"),
    EDIT_LINES("Strešné línie"),
    ADD_LINE("Pridať líniu"),
    ADD_OBJECT("Pridať prvok"),
    TYPOLOGY("Typológia")
}

enum class EditorWorkspace { OUTLINE, WALL_FOOTPRINT, INTERNAL_LINES, TYPOLOGY, SUPERSTRUCTURES }

private enum class SelectionKind { NONE, VERTEX, EDGE, LINE, OBJECT, FOOTPRINT_PART }
private enum class LineEndpoint { START, END }
private data class SnapCandidate(val point: GeoPoint, val distancePx: Float)

@SuppressLint("ViewConstructor")
class RoofMapEditorView(
    context: Context,
    val project: RoofProject
) : View(context) {
    var mode: EditorMode = EditorMode.PAN
        private set
    var activeLineType: LineType = LineType.RIDGE
        private set
    var activeObjectType: ObjectType = ObjectType.CHIMNEY
        private set
    var activeDormerType: DormerType = DormerType.GABLE
        private set
    var workspace: EditorWorkspace = EditorWorkspace.OUTLINE
        private set
    var onProjectChanged: (() -> Unit)? = null
    var onStatusChanged: ((String) -> Unit)? = null
    var onModeChanged: ((EditorMode) -> Unit)? = null
    var onBoundaryEdgeLongPressed: ((Int) -> Unit)? = null
    var onBoundaryDimensionLongPressed: ((Int) -> Unit)? = null
    var onLineLongPressed: ((Int) -> Unit)? = null
    var onObjectLongPressed: ((Int) -> Unit)? = null
    var onWallFootprintPartLongPressed: ((Int) -> Unit)? = null
    var onObjectAdded: ((Int) -> Unit)? = null
    var onCameraRequested: ((GeoPoint, Int) -> Unit)? = null
    var onFitRequested: ((List<GeoPoint>) -> Unit)? = null
    var onZoomRequested: ((Float) -> Unit)? = null
    var onPanRequested: ((Float, Float) -> Boolean)? = null
    var onViewportChanged: (() -> Unit)? = null
    var projectPointToScreen: ((GeoPoint) -> PointF)? = null
    var screenPointToProject: ((Float, Float) -> GeoPoint)? = null

    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val history = ArrayDeque<String>()
    private val redoHistory = ArrayDeque<String>()
    private var pendingLineStart: GeoPoint? = null
    private var selectionKind = SelectionKind.NONE
    private var selectedIndex = -1
    private var selectedEndpoint: LineEndpoint? = null
    private var selectedBoundaryVertexIndex = -1
    private var edgeLengthFailureMessage: String? = null
    private var solverPreview: RoofSolverPreview? = null
    private var focusedIssueIndex = -1
    private var lastTouch = PointF()
    private var draggingMap = false
    private var drawingPolygon = false
    private var draggingSelection = false
    private var lastFreehandPoint = PointF()
    private var scaleGestureActive = false
    private var ignoreTouchesUntilUp = false
    private var lastTwoFingerAngle: Float? = null
    private var longPressTriggered = false
    private var longPressRunnable: Runnable? = null
    private var temporaryPanRunnable: Runnable? = null
    private var temporaryPan = false
    private val freehandStroke = mutableListOf<GeoPoint>()
    private val boundaryDimensionHitBoxes = mutableMapOf<Int, RectF>()
    private var downX = 0f
    private var downY = 0f
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private val density = resources.displayMetrics.density
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            scaleGestureActive = true
            ignoreTouchesUntilUp = true
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            onZoomRequested?.invoke((ln(detector.scaleFactor.toDouble()) / ln(2.0)).toFloat())
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            scaleGestureActive = false
        }
    })

    init {
        isFocusable = true
        contentDescription = "Mapový editor strechy"
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun setMode(value: EditorMode, lineType: LineType? = null, objectType: ObjectType? = null) {
        val allowed = when (workspace) {
            EditorWorkspace.OUTLINE -> value in setOf(EditorMode.PAN, EditorMode.DRAW_POLYGON, EditorMode.ADD_VERTEX, EditorMode.EDIT)
            EditorWorkspace.INTERNAL_LINES -> value in setOf(EditorMode.PAN, EditorMode.ADD_LINE, EditorMode.EDIT_LINES)
            EditorWorkspace.WALL_FOOTPRINT, EditorWorkspace.TYPOLOGY, EditorWorkspace.SUPERSTRUCTURES ->
                value in setOf(EditorMode.PAN, EditorMode.TYPOLOGY, EditorMode.ADD_OBJECT)
        }
        if (!allowed) {
            status("Tento nástroj nepatrí do aktuálnej pracovnej karty.")
            return
        }
        mode = value
        lineType?.let { activeLineType = it }
        if (workspace == EditorWorkspace.INTERNAL_LINES && value == EditorMode.ADD_LINE) activeLineType = LineType.UNKNOWN
        objectType?.let { activeObjectType = it }
        pendingLineStart = null
        clearSelection()
        val detail = when (value) {
            EditorMode.ADD_LINE -> ": ${activeLineType.label} – označte dva body"
            EditorMode.ADD_OBJECT -> ": ${activeObjectType.label} – klepnite na polohu"
            EditorMode.DRAW_POLYGON -> " – jedným ťahom; výsledok sa vyhladí na najviac 10 bodov"
            EditorMode.ADD_VERTEX -> " – klepaním pridávajte rohy obrysu"
            EditorMode.EDIT -> " – bod chvíľu podržte, potom ho potiahnite"
            EditorMode.EDIT_LINES -> " – koniec chvíľu podržte; pri pustení sa magneticky pripojí"
            EditorMode.PAN -> " – jeden prst posúva, dva približujú a otáčajú"
            EditorMode.TYPOLOGY -> " – podržte hranu a priraďte jej technický význam"
        }
        status("${value.label}$detail")
        onModeChanged?.invoke(value)
        invalidate()
    }

    fun setDormerPlacement(type: DormerType) {
        activeDormerType = type
        setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.DORMER)
    }

    fun setWorkspace(value: EditorWorkspace) {
        workspace = value
        mode = when (value) {
            EditorWorkspace.OUTLINE -> EditorMode.EDIT
            EditorWorkspace.INTERNAL_LINES -> EditorMode.EDIT_LINES
            EditorWorkspace.WALL_FOOTPRINT, EditorWorkspace.TYPOLOGY, EditorWorkspace.SUPERSTRUCTURES -> EditorMode.TYPOLOGY
        }
        pendingLineStart = null
        clearSelection()
        status(when (value) {
            EditorWorkspace.OUTLINE -> "Obrys: upravujte iba vonkajší polygon."
            EditorWorkspace.WALL_FOOTPRINT ->
                "Strešné trakty: podržte šrafovanú oblasť a upravte jej význam."
            EditorWorkspace.INTERNAL_LINES -> "Vnútorné línie: obrys je zamknutý; nové hrany sú zatiaľ neurčené."
            EditorWorkspace.TYPOLOGY -> "Typológia: XY geometria je zamknutá; podržte hranu a nastavte jej typ."
            EditorWorkspace.SUPERSTRUCTURES ->
                "Vikiere a strojovne: vyberte dlaždicu a klepnite na polohu v strešnej ploche."
        })
        invalidate()
    }

    fun setCenter(point: GeoPoint, zoom: Int = 19) {
        project.centerLat = point.lat
        project.centerLon = point.lon
        project.zoom = zoom.coerceIn(3, 21)
        onCameraRequested?.invoke(point, project.zoom)
        onViewportChanged?.invoke()
        changed("Mapa premiestnená na ${"%.6f".format(point.lat)}, ${"%.6f".format(point.lon)}")
    }

    fun resetMapRotation() {
        project.mapRotationDeg = 0.0
        onViewportChanged?.invoke()
        changed("Mapa a celý nákres sú otočené späť na sever.")
    }

    fun importPolygon(points: List<GeoPoint>) {
        if (points.size < 3) return
        pushHistory()
        resetMetricGridFrame()
        MetricPlanGrid.ensureProjectFrame(project, points)
        project.polygon = points.map { MetricPlanGrid.snap(project, it, points) }.toMutableList()
        // Import creates a new roof topology. A wall footprint from the previous polygon must
        // never survive as a stale rectangle below an L/T/K-shaped building.
        project.wallFootprint = project.polygon.map { it.copy() }.toMutableList()
        project.lines.clear()
        project.objects.clear()
        project.edgeTypes.clear()
        invalidateTopology()
        fitToPolygon()
        mode = EditorMode.EDIT
        changed("Importovaný obrys: ${project.polygon.size} bodov, ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
    }

    fun finishPolygon() {
        if (project.polygon.size >= 3) {
            if (project.wallFootprint.size != project.polygon.size) {
                project.wallFootprint = project.polygon.map { it.copy() }.toMutableList()
            }
            mode = EditorMode.EDIT
            changed("Obrys uzavretý: ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
        } else {
            status("Obrys potrebuje aspoň tri body.")
        }
    }

    fun refreshWallFootprintParts(resetUserOverrides: Boolean = false) {
        if (project.wallFootprint.size < 3 && project.polygon.size < 3) {
            status("Najprv vytvorte obrys stavby.")
            return
        }
        if (resetUserOverrides) WallFootprintSolver.resetAutomaticProposal(project)
        else WallFootprintSolver.refresh(project)
        clearSelection()
        changed("Návrh strešných traktov bol prepočítaný.")
    }

    fun correctGeometry() = prepareSolverPreview()

    fun prepareSolverPreview(): RoofSolverPreview? {
        if (project.polygon.size < 3) {
            status("Najprv vytvorte obrys strechy.")
            return null
        }
        val candidate = ProjectJson.decode(ProjectJson.encode(project)).apply {
            roofTopology = null
        }
        val topology = RoofTopologyMigration.fromProject(candidate)
        solverPreview = when (workspace) {
            EditorWorkspace.OUTLINE -> RoofTopologySolver.solveOutline(topology, WallFootprintSolver.context(project))
            EditorWorkspace.INTERNAL_LINES -> RoofTopologySolver.solveInternal(
                topology, footprintContext = WallFootprintSolver.context(project)
            )
            EditorWorkspace.WALL_FOOTPRINT -> {
                status("Na karte Strešné trakty sa geometria nemení; upravuje sa jej význam.")
                return null
            }
            EditorWorkspace.TYPOLOGY -> {
                status("Na karte Typológia sa XY geometria nekoriguje.")
                return null
            }
            EditorWorkspace.SUPERSTRUCTURES -> {
                status("Na karte Vikierov sa hlavná XY geometria nekoriguje.")
                return null
            }
        }
        focusedIssueIndex = -1
        status("Náhľad opráv je pripravený. Projekt zatiaľ nebol zmenený.")
        invalidate()
        return solverPreview
    }

    fun applySolverPreview(): Boolean {
        val preview = solverPreview ?: return false
        pushHistory()
        val result = ProjectGeometryCorrection.apply(
            project,
            preview,
            allowBoundaryChanges = workspace == EditorWorkspace.OUTLINE
        )
        if (!result.applied) {
            status(result.issues.firstOrNull()?.message ?: "Topológiu sa nepodarilo použiť.")
            return false
        }
        solverPreview = null
        changed("Kompletné opravy geometrie boli použité ako jedna vratná úprava.")
        return true
    }

    fun cancelSolverPreview() {
        solverPreview = null
        focusedIssueIndex = -1
        status("Náhľad opráv bol zrušený; projekt sa nezmenil.")
        invalidate()
    }

    fun focusNextSolverIssue(): TopologyIssue? {
        val issues = solverPreview?.issues.orEmpty()
        if (issues.isEmpty()) return null
        focusedIssueIndex = (focusedIssueIndex + 1) % issues.size
        return issues[focusedIssueIndex].also {
            status("Problém ${focusedIssueIndex + 1}/${issues.size}: ${it.message}")
            invalidate()
        }
    }

    fun undo() {
        val snapshot = history.removeLastOrNull() ?: run {
            status("Nie je čo vrátiť.")
            return
        }
        redoHistory.addLast(ProjectJson.encode(project))
        while (redoHistory.size > 30) redoHistory.removeFirst()
        applySnapshot(ProjectJson.decode(snapshot))
        changed("Posledná úprava bola vrátená.")
    }

    fun redo() {
        val snapshot = redoHistory.removeLastOrNull() ?: run {
            status("Nie je čo zopakovať.")
            return
        }
        history.addLast(ProjectJson.encode(project))
        while (history.size > 30) history.removeFirst()
        applySnapshot(ProjectJson.decode(snapshot))
        changed("Vrátená úprava bola znovu použitá.")
    }

    fun recordExternalChange() = pushHistory()

    fun deleteSelectedPoint(): Boolean {
        val boundaryVertex = when (selectionKind) {
            SelectionKind.VERTEX -> selectedIndex
            SelectionKind.EDGE -> selectedBoundaryVertexIndex
            else -> -1
        }
        if (boundaryVertex in project.polygon.indices) {
            val result = BoundaryEdgeOperations.removeVertex(
                project.polygon, project.edgeTypes, boundaryVertex
            ) ?: run {
                status("Obrys musí mať najmenej tri body.")
                return false
            }
            pushHistory()
            project.polygon = result.polygon
            project.wallFootprint = result.polygon.map(GeoPoint::copy).toMutableList()
            project.edgeTypes = result.edgeTypes
            invalidateTopology()
            clearSelection()
            changed("Vybraný oranžový bod obrysu bol odstránený.")
            return true
        }
        if (selectionKind == SelectionKind.LINE && selectedEndpoint != null && selectedIndex in project.lines.indices) {
            pushHistory()
            project.lines.removeAt(selectedIndex)
            invalidateTopology()
            clearSelection()
            changed("Línia pripojená k vybranému bodu bola odstránená.")
            return true
        }
        status("Najprv bod chvíľu podržte, kým sa nezafarbí na oranžovo.")
        return false
    }

    fun cycleSelectedLineType(): LineType? {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.LINE } ?: run {
            status("Najprv vyberte strešnú líniu.")
            return null
        }
        pushHistory()
        val types = listOf(
            LineType.RIDGE, LineType.HIP, LineType.VALLEY, LineType.STEP,
            LineType.OPENING_BOUNDARY, LineType.LOW_EDGE, LineType.ELEVATED_LOW_EDGE,
            LineType.ATTIC, LineType.PULT, LineType.WALL_END
        )
        val current = project.lines[index].type
        val next = types[(types.indexOf(current).coerceAtLeast(0) + 1) % types.size]
        project.lines[index].type = next
        invalidateTopology()
        changed("Typ línie bol zmenený na ${next.label}.")
        return next
    }

    fun joinSelectedEndpointToNearest(): Boolean {
        if (selectionKind != SelectionKind.LINE || selectedEndpoint == null) {
            status("Vyberte koncový bod línie, ktorý chcete pripojiť.")
            return false
        }
        pushHistory()
        if (!snapSelectedEndpoint()) {
            history.removeLastOrNull()
            status("V dosahu nie je ďalší uzol. Presuňte koniec bližšie.")
            return false
        }
        invalidateTopology()
        changed("Koniec línie bol pripojený k spoločnému uzlu.")
        return true
    }

    fun disconnectSelectedEndpoint(): Boolean {
        if (selectionKind != SelectionKind.LINE || selectedEndpoint == null) {
            status("Vyberte koncový bod línie, ktorý chcete odpojiť.")
            return false
        }
        pushHistory()
        // Legacy konce sú samostatné súradnice. Zrušením odvodeného grafu sa zvolený
        // koniec stane samostatne pohyblivým a nový graf vznikne až po ďalšej korekcii.
        invalidateTopology()
        changed("Koniec je odpojený. Teraz ho môžete samostatne presunúť.")
        return true
    }

    fun splitSelectedLine(): Boolean {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.LINE } ?: run {
            status("Najprv vyberte strešnú líniu.")
            return false
        }
        val line = project.lines[index]
        val a = Geometry.toLocal(line.end, line.start)
        if (hypot(a.x, a.y) < 0.02) return false
        val middle = gridPoint(Geometry.toGeo(LocalPoint(a.x / 2.0, a.y / 2.0), line.start))
        pushHistory()
        project.lines.removeAt(index)
        project.lines.add(index, line.copy(id = java.util.UUID.randomUUID().toString(), start = middle.copy()))
        project.lines.add(index, line.copy(id = java.util.UUID.randomUUID().toString(), end = middle.copy()))
        invalidateTopology()
        clearSelection()
        changed("Línia bola rozdelená v polovici na dve hrany.")
        return true
    }

    fun deleteSelection() {
        if (selectedIndex < 0) {
            status("Najprv vyberte vrchol, líniu alebo prvok.")
            return
        }
        pushHistory()
        when (selectionKind) {
            SelectionKind.VERTEX -> if (project.polygon.size > 3) {
                project.polygon.removeAt(selectedIndex)
                project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
            }
            SelectionKind.LINE -> project.lines.removeAt(selectedIndex)
            SelectionKind.OBJECT -> project.objects.removeAt(selectedIndex)
            SelectionKind.EDGE, SelectionKind.FOOTPRINT_PART, SelectionKind.NONE -> Unit
        }
        if (selectionKind == SelectionKind.VERTEX || selectionKind == SelectionKind.LINE) invalidateTopology()
        clearSelection()
        changed("Vybraný prvok bol odstránený.")
    }

    fun clearDrawing() {
        pushHistory()
        project.polygon.clear()
        project.wallFootprint.clear()
        project.lines.clear()
        project.objects.clear()
        project.edgeTypes.clear()
        invalidateTopology()
        clearSelection()
        changed("Nákres bol vyčistený.")
    }

    fun cycleSelectedEdgeType(): LineType? {
        if (project.polygon.size < 3) return null
        val edgeIndex = if (selectionKind == SelectionKind.EDGE) selectedIndex
            else selectedEdgeNear(lastTouch.x, lastTouch.y)
        if (edgeIndex < 0) {
            status("V režime editácie klepnite tesne na obvodovú hranu.")
            return null
        }
        pushHistory()
        val types = listOf(
            LineType.EAVE, LineType.GABLE, LineType.RAKE, LineType.LOW_EDGE,
            LineType.ELEVATED_LOW_EDGE, LineType.ATTIC, LineType.PULT,
            LineType.WALL_END, LineType.STEP, LineType.OPENING_BOUNDARY
        )
        val current = project.edgeTypes[edgeIndex] ?: LineType.EAVE
        val next = types[(types.indexOf(current).coerceAtLeast(0) + 1) % types.size]
        project.edgeTypes[edgeIndex] = next
        invalidateTopology()
        changed("Hrana ${edgeIndex + 1}: ${next.label}")
        return next
    }

    fun setBoundaryEdgeType(index: Int, type: LineType, elevationZ: Double? = null): Boolean {
        if (index !in project.polygon.indices || project.polygon.size < 3) return false
        val graph = canonicalGraph()
        val edgeId = boundaryEdgeIdForPolygonIndex(graph, index)
            ?: return false
        val edge = graph.edges[edgeId] ?: return false
        val updated = graph.copy(edges = graph.edges + (edgeId to edge.copy(
            semanticRole = EdgeSemantic.fromLegacy(type),
            elevationZ = if (type == LineType.ELEVATED_LOW_EDGE) elevationZ ?: edge.elevationZ else null
        )))
        pushHistory()
        if (!installGraph(updated)) {
            history.removeLastOrNull()
            return false
        }
        selectionKind = SelectionKind.EDGE
        selectedIndex = index
        changed("Obvodová hrana ${index + 1} je teraz: ${type.label}.")
        return true
    }

    fun boundaryEdgeType(index: Int): LineType? {
        if (index !in project.polygon.indices || project.polygon.size < 3) return null
        val graph = canonicalGraph()
        val edgeId = boundaryEdgeIdForPolygonIndex(graph, index)
            ?: return project.edgeTypes[index]
        return graph.edges[edgeId]?.semanticRole?.toLegacy() ?: project.edgeTypes[index]
    }

    fun setLineType(index: Int, type: LineType, elevationZ: Double? = null): Boolean {
        val line = project.lines.getOrNull(index) ?: return false
        val graph = canonicalGraph()
        val edgeId = graph.edges[line.id]?.id
            ?: graph.edges.values.firstOrNull { !it.boundary && it.id == line.id }?.id
            ?: return false
        val edge = graph.edges[edgeId] ?: return false
        val updated = graph.copy(edges = graph.edges + (edgeId to edge.copy(
            semanticRole = EdgeSemantic.fromLegacy(type),
            elevationZ = if (type == LineType.ELEVATED_LOW_EDGE) elevationZ ?: edge.elevationZ else null
        )))
        pushHistory()
        if (!installGraph(updated)) {
            history.removeLastOrNull()
            return false
        }
        selectionKind = SelectionKind.LINE
        selectedIndex = project.lines.indexOfFirst { it.id == edgeId }.coerceAtLeast(0)
        changed("Technický význam hrany bol nastavený na ${type.label}; XY poloha sa nezmenila.")
        return true
    }

    fun lineType(index: Int): LineType? = project.lines.getOrNull(index)?.type

    fun addMidpointToSelectedEdge(): Boolean {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.EDGE } ?: run {
            status("Najprv klepnite na obvodovú hranu; vybraná hrana sa zvýrazní oranžovo.")
            return false
        }
        return addBoundaryMidpoint(index)
    }

    fun addBoundaryMidpoint(index: Int): Boolean {
        val graph = canonicalGraph()
        val edgeId = boundaryEdgeIdForPolygonIndex(graph, index) ?: return false
        val updated = RoofGraphOperations.splitEdge(graph, edgeId) ?: run {
            status("Vybranú obvodovú hranu nemožno rozdeliť.")
            return false
        }
        pushHistory()
        if (!installGraph(updated)) {
            history.removeLastOrNull()
            status("Rozdelenie by vytvorilo neplatný obrys.")
            return false
        }
        selectionKind = SelectionKind.EDGE
        selectedIndex = index
        selectedBoundaryVertexIndex = (index + 1) % project.polygon.size
        changed("Do stredu obvodovej hrany ${index + 1} bol pridaný bod. Typ oboch segmentov zostal zachovaný.")
        return true
    }

    fun selectedEdgeLengthM(): Double? {
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.EDGE } ?: return null
        if (project.polygon.size < 2 || index !in project.polygon.indices) return null
        return Geometry.distanceM(project.polygon[index], project.polygon[(index + 1) % project.polygon.size])
    }

    fun selectedEdgeLengthFailure(): String? = edgeLengthFailureMessage

    fun setSelectedEdgeLength(targetLengthM: Double, calibrateWholeDrawing: Boolean): Boolean {
        edgeLengthFailureMessage = null
        val index = selectedIndex.takeIf { selectionKind == SelectionKind.EDGE } ?: run {
            edgeLengthFailureMessage = "Najprv zvoľte Editovať a klepnite na obvodovú hranu."
            status(edgeLengthFailureMessage!!)
            return false
        }
        val currentLength = selectedEdgeLengthM() ?: run {
            edgeLengthFailureMessage = "Vybraná hrana už v obryse neexistuje."
            return false
        }
        if (targetLengthM !in 0.05..5000.0) {
            edgeLengthFailureMessage = "Rozmer musí byť v rozsahu 0,05 až 5 000 m."
            return false
        }
        if (currentLength < 0.0001) {
            edgeLengthFailureMessage = "Vybraná hrana má nulovú dĺžku."
            return false
        }
        pushHistory()
        if (calibrateWholeDrawing) {
            val origin = GeoPoint(project.underlayOriginLat, project.underlayOriginLon)
            val ratio = targetLengthM / currentLength
            fun scaled(point: GeoPoint): GeoPoint {
                val local = Geometry.toLocal(point, origin)
                return Geometry.toGeo(LocalPoint(local.x * ratio, local.y * ratio), origin)
            }
            val scaledPolygon = project.polygon.map(::scaled)
            resetMetricGridFrame()
            MetricPlanGrid.ensureProjectFrame(project, scaledPolygon)
            project.polygon = scaledPolygon.map {
                MetricPlanGrid.snap(project, it, scaledPolygon)
            }.toMutableList()
            project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
            project.lines.forEach { line ->
                line.start = gridPoint(scaled(line.start))
                line.end = gridPoint(scaled(line.end))
            }
            project.objects.forEach { item -> item.center = scaled(item.center) }
            project.underlayMetersPerPixel = (project.underlayMetersPerPixel * ratio).coerceIn(0.00001, 1000.0)
            invalidateTopology()
            changed("Výkres bol kalibrovaný podľa hrany #${index + 1} na ${"%.2f".format(targetLengthM)} m.")
        } else {
            val graph = canonicalGraph()
            val edgeId = boundaryEdgeIdForPolygonIndex(graph, index)
            val result = edgeId?.let {
                ParametricEditSolver.setBoundaryDimension(
                    graph,
                    listOf(it),
                    targetLengthM,
                    project.wallHeightM,
                    project.slopeDeg,
                    WallFootprintSolver.context(project)
                )
            }
            if (result == null || !result.applied || !installGraph(result.graph)) {
                history.removeLastOrNull()
                edgeLengthFailureMessage = result?.issues?.firstOrNull()
                    ?: "Rozmer nemožno použiť bez porušenia obrysu."
                status(edgeLengthFailureMessage!!)
                return false
            }
            changed(
                "Dĺžka hrany #${index + 1} je ${"%.0f".format(targetLengthM * 1000.0)} mm " +
                    "a zostáva tvrdým obmedzením solvera."
            )
        }
        return true
    }

    fun fitToPolygon() {
        if (project.polygon.isEmpty() || width <= 0 || height <= 0) return
        onFitRequested?.let {
            it(project.polygon)
            return
        }
        fitToPolygonLocally(project.polygon)
    }

    fun fitToPolygonLocally(points: List<GeoPoint>) {
        if (points.isEmpty() || width <= 0 || height <= 0) return
        val center = Geometry.centroid(points)
        project.centerLat = center.lat
        project.centerLon = center.lon
        for (candidate in 21 downTo 3) {
            val xs = points.map { Geometry.worldX(it.lon, candidate) }
            val ys = points.map { Geometry.worldY(it.lat, candidate) }
            if ((xs.maxOrNull()!! - xs.minOrNull()!!) < width * 0.72 &&
                (ys.maxOrNull()!! - ys.minOrNull()!!) < height * 0.65
            ) {
                project.zoom = candidate
                break
            }
        }
        onViewportChanged?.invoke()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        drawMap(canvas)
        drawGeometry(canvas)
        drawMapChrome(canvas)
    }

    private fun drawMap(canvas: Canvas) {
        // Mapový podklad kreslí RasterTileMapView pod touto priehľadnou vrstvou.
    }

    private fun drawGeometry(canvas: Canvas) {
        boundaryDimensionHitBoxes.clear()
        if (drawingPolygon && freehandStroke.size >= 2) {
            val stroke = freehandStroke.map(::toScreen)
            val path = Path().apply {
                moveTo(stroke.first().x, stroke.first().y)
                stroke.drop(1).forEach { lineTo(it.x, it.y) }
            }
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = 4f * density
            overlayPaint.strokeCap = Paint.Cap.ROUND
            overlayPaint.strokeJoin = Paint.Join.ROUND
            overlayPaint.color = 0xff15924a.toInt()
            canvas.drawPath(path, overlayPaint)
        }
        if (project.polygon.isNotEmpty() && !drawingPolygon) {
            if (workspace == EditorWorkspace.WALL_FOOTPRINT) drawWallFootprintParts(canvas)
            project.roofGraph?.takeIf { it.nodes.isNotEmpty() }?.let { gutterGraph ->
                val gutterFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.FILL
                    color = 0x809aa2a6.toInt()
                }
                val gutterOutline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE
                    strokeWidth = 1.4f * density
                    color = 0xff5c6468.toInt()
                }
                val rainwater = RainwaterDrainageSolver.solve(gutterGraph)
                fun drawGutterPolygon(localPoints: List<LocalPoint>) {
                    val corners = localPoints.map { local ->
                        toScreen(Geometry.toGeo(local, gutterGraph.origin))
                    }
                    val gutterPath = Path().apply {
                        moveTo(corners.first().x, corners.first().y)
                        corners.drop(1).forEach { lineTo(it.x, it.y) }
                        close()
                    }
                    canvas.drawPath(gutterPath, gutterFill)
                    canvas.drawPath(gutterPath, gutterOutline)
                }
                rainwater.gutters.forEach { gutter -> drawGutterPolygon(gutter.bandCorners()) }
                rainwater.gutterCorners.forEach { corner -> drawGutterPolygon(corner.bandPolygon()) }
            }
            val screen = project.polygon.map(::toScreen)
            if (screen.size >= 3) {
                val path = Path().apply {
                    moveTo(screen.first().x, screen.first().y)
                    screen.drop(1).forEach { lineTo(it.x, it.y) }
                    close()
                }
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = 0x4032b847
                canvas.drawPath(path, overlayPaint)
            }
            overlayPaint.style = Paint.Style.STROKE
            project.polygon.indices.forEach { index ->
                if (index == project.polygon.lastIndex && project.polygon.size < 3) return@forEach
                val next = (index + 1) % project.polygon.size
                val type = project.edgeTypes[index] ?: LineType.EAVE
                overlayPaint.strokeWidth = if (selectionKind == SelectionKind.EDGE && selectedIndex == index) {
                    6f * density
                } else 3.2f * density
                overlayPaint.color = if (selectionKind == SelectionKind.EDGE && selectedIndex == index) {
                    0xffff9800.toInt()
                } else type.color
                canvas.drawLine(screen[index].x, screen[index].y, screen[next].x, screen[next].y, overlayPaint)
                if (project.polygon.size >= 3) {
                    val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
                    val dx = screen[next].x - screen[index].x
                    val dy = screen[next].y - screen[index].y
                    val segmentLength = hypot(dx, dy).coerceAtLeast(1f)
                    val offset = 20f * density
                    val labelPoint = PointF(
                        (screen[index].x + screen[next].x) / 2f - dy / segmentLength * offset,
                        (screen[index].y + screen[next].y) / 2f + dx / segmentLength * offset
                    )
                    val label = String.format(java.util.Locale("sk", "SK"), "%,.0f mm", length * 1000.0)
                    if (workspace != EditorWorkspace.WALL_FOOTPRINT) drawSmallLabel(
                        canvas,
                        if (workspace == EditorWorkspace.OUTLINE) label else type.label,
                        labelPoint,
                        type.color
                    )
                    if (workspace == EditorWorkspace.OUTLINE) {
                        textPaint.textSize = 9.5f * density
                        val halfWidth = textPaint.measureText(label) / 2f + 8f * density
                        boundaryDimensionHitBoxes[index] = RectF(
                            labelPoint.x - halfWidth, labelPoint.y - 18f * density,
                            labelPoint.x + halfWidth, labelPoint.y + 7f * density
                        )
                    }
                }
            }
            if (workspace == EditorWorkspace.OUTLINE && !drawingPolygon) screen.forEachIndexed { index, point ->
                val belongsToSelectedEdge = selectionKind != SelectionKind.EDGE ||
                    index == selectedIndex || index == (selectedIndex + 1) % project.polygon.size
                val radius = if (belongsToSelectedEdge) 7f else 4f
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = if (
                    selectionKind == SelectionKind.VERTEX && selectedIndex == index ||
                    selectionKind == SelectionKind.EDGE && selectedBoundaryVertexIndex == index
                ) {
                    0xffffb000.toInt()
                } else if (belongsToSelectedEdge) Color.WHITE else 0xffb8c0b8.toInt()
                canvas.drawCircle(point.x, point.y, radius * density, overlayPaint)
                overlayPaint.style = Paint.Style.STROKE
                overlayPaint.strokeWidth = 2f * density
                overlayPaint.color = if (belongsToSelectedEdge) 0xff176d19.toInt() else 0xff7a827a.toInt()
                canvas.drawCircle(point.x, point.y, radius * density, overlayPaint)
            }
        }

        if (workspace !in setOf(EditorWorkspace.OUTLINE, EditorWorkspace.WALL_FOOTPRINT)) project.lines.forEachIndexed { index, line ->
            val a = toScreen(line.start)
            val b = toScreen(line.end)
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = if (selectionKind == SelectionKind.LINE && selectedIndex == index) 6f * density else 3f * density
            overlayPaint.color = if (selectionKind == SelectionKind.LINE && selectedIndex == index) {
                0xffff9800.toInt()
            } else line.type.color
            if (line.type == LineType.WALL_END) {
                overlayPaint.pathEffect = android.graphics.DashPathEffect(floatArrayOf(12f, 8f), 0f)
            }
            canvas.drawLine(a.x, a.y, b.x, b.y, overlayPaint)
            overlayPaint.pathEffect = null
            drawSmallLabel(canvas, line.type.label, midpoint(a, b), line.type.color)
            if (selectionKind == SelectionKind.LINE && selectedIndex == index) {
                listOf(a to LineEndpoint.START, b to LineEndpoint.END).forEach { (point, endpoint) ->
                    overlayPaint.style = Paint.Style.FILL
                    overlayPaint.color = if (selectedIndex == index && selectedEndpoint == endpoint) 0xffffb000.toInt() else Color.WHITE
                    canvas.drawCircle(point.x, point.y, 8f * density, overlayPaint)
                    overlayPaint.style = Paint.Style.STROKE
                    overlayPaint.strokeWidth = 2.5f * density
                    overlayPaint.color = line.type.color
                    canvas.drawCircle(point.x, point.y, 8f * density, overlayPaint)
                }
            }
        }
        pendingLineStart?.let {
            val point = toScreen(it)
            overlayPaint.style = Paint.Style.FILL
            overlayPaint.color = activeLineType.color
            canvas.drawCircle(point.x, point.y, 8f * density, overlayPaint)
        }

        if (workspace in setOf(EditorWorkspace.TYPOLOGY, EditorWorkspace.SUPERSTRUCTURES)) project.objects.forEachIndexed { index, item ->
            if (workspace == EditorWorkspace.SUPERSTRUCTURES && item.type !in SUPERSTRUCTURE_TYPES) return@forEachIndexed
            val point = toScreen(item.center)
            val selected = selectionKind == SelectionKind.OBJECT && selectedIndex == index
            val color = if (selected) 0xffffa000.toInt() else objectColor(item.type)
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = (if (selected) 4f else 2.4f) * density
            overlayPaint.color = color
            val metresPerPixel = Geometry.metersPerPixel(item.center.lat, project.zoom)
            when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH,
                ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT -> {
                    val halfW = max(8.0, item.widthMm / 1000.0 / metresPerPixel / 2).toFloat()
                    val halfH = max(8.0, item.heightMm / 1000.0 / metresPerPixel / 2).toFloat()
                    canvas.save()
                    canvas.rotate(item.rotationDeg.toFloat(), point.x, point.y)
                    canvas.drawRect(point.x - halfW, point.y - halfH, point.x + halfW, point.y + halfH, overlayPaint)
                    canvas.restore()
                }
                ObjectType.TERRACE -> {
                    val halfW = max(8.0, item.widthMm / 1000.0 / metresPerPixel / 2).toFloat()
                    val halfH = max(8.0, item.heightMm / 1000.0 / metresPerPixel / 2).toFloat()
                    canvas.save()
                    canvas.rotate(item.rotationDeg.toFloat(), point.x, point.y)
                    canvas.drawRect(point.x - halfW, point.y - halfH, point.x + halfW, point.y + halfH, overlayPaint)
                    canvas.drawLine(point.x - halfW, point.y - halfH, point.x + halfW, point.y + halfH, overlayPaint)
                    canvas.drawLine(point.x + halfW, point.y - halfH, point.x - halfW, point.y + halfH, overlayPaint)
                    canvas.restore()
                }
                ObjectType.VENT, ObjectType.DRAIN -> {
                    val radius = max(7.0, item.diameterMm / 1000.0 / metresPerPixel / 2).toFloat()
                    canvas.drawCircle(point.x, point.y, radius, overlayPaint)
                }
                ObjectType.DOWNSPOUT -> {
                    canvas.drawCircle(point.x, point.y, 7f * density, overlayPaint)
                    canvas.drawLine(point.x, point.y, point.x + 24f * density, point.y + 24f * density, overlayPaint)
                }
                ObjectType.HEIGHT_MARK -> {
                    canvas.drawLine(point.x - 12f * density, point.y, point.x + 12f * density, point.y, overlayPaint)
                    canvas.drawLine(point.x, point.y - 12f * density, point.x, point.y + 12f * density, overlayPaint)
                }
                ObjectType.SLOPE_MARK -> {
                    canvas.drawLine(point.x - 16f * density, point.y + 12f * density, point.x + 16f * density, point.y - 12f * density, overlayPaint)
                    canvas.drawCircle(point.x + 16f * density, point.y - 12f * density, 3f * density, overlayPaint)
                }
            }
            drawSmallLabel(canvas, item.type.label, PointF(point.x, point.y - 15f * density), color)
        }

        solverPreview?.let { preview ->
            fun localToScreen(x: Double, y: Double) = toScreen(Geometry.toGeo(LocalPoint(x, y), preview.proposed.origin))
            val nodes = preview.proposed.nodes.associateBy { it.id }
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = 4f * density
            overlayPaint.color = 0xff20a04a.toInt()
            preview.proposed.edges.forEach { edge ->
                val a = nodes[edge.startNodeId] ?: return@forEach
                val b = nodes[edge.endNodeId] ?: return@forEach
                val pa = localToScreen(a.x, a.y)
                val pb = localToScreen(b.x, b.y)
                canvas.drawLine(pa.x, pa.y, pb.x, pb.y, overlayPaint)
            }
            overlayPaint.strokeWidth = 2f * density
            overlayPaint.color = 0xffffa000.toInt()
            preview.movements.forEach { move ->
                val a = localToScreen(move.fromX, move.fromY)
                val b = localToScreen(move.toX, move.toY)
                canvas.drawLine(a.x, a.y, b.x, b.y, overlayPaint)
                canvas.drawCircle(b.x, b.y, 5f * density, overlayPaint)
            }
            preview.issues.forEachIndexed { index, issue ->
                if (issue.x == null || issue.y == null) return@forEachIndexed
                val point = localToScreen(issue.x, issue.y)
                overlayPaint.style = Paint.Style.FILL
                overlayPaint.color = if (index == focusedIssueIndex) 0xffff9800.toInt() else 0xffd32f2f.toInt()
                canvas.drawCircle(point.x, point.y, 7f * density, overlayPaint)
            }
        }
    }

    private fun drawWallFootprintParts(canvas: Canvas) {
        val parts = project.wallFootprintParts
        if (parts.isEmpty()) return
        parts.forEachIndexed { index, part ->
            val points = part.polygon.map(::toScreen)
            if (points.size < 3) return@forEachIndexed
            val path = Path().apply {
                moveTo(points.first().x, points.first().y)
                points.drop(1).forEach { lineTo(it.x, it.y) }
                close()
            }
            val selected = selectionKind == SelectionKind.FOOTPRINT_PART && selectedIndex == index
            val color = footprintPartColor(part.type)
            overlayPaint.style = Paint.Style.FILL
            overlayPaint.color = if (selected) 0x66ffb000 else (color and 0x00ffffff) or 0x3d000000
            canvas.drawPath(path, overlayPaint)

            canvas.save()
            canvas.clipPath(path)
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = (if (selected) 2.2f else 1.1f) * density
            overlayPaint.color = if (selected) 0xffffa000.toInt() else color
            val bounds = RectF()
            path.computeBounds(bounds, true)
            val spacing = 12f * density
            var offset = bounds.left - bounds.height()
            while (offset <= bounds.right + bounds.height()) {
                canvas.drawLine(offset, bounds.bottom, offset + bounds.height(), bounds.top, overlayPaint)
                offset += spacing
            }
            canvas.restore()

            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = (if (selected) 4f else 2f) * density
            overlayPaint.color = if (selected) 0xffffa000.toInt() else color
            canvas.drawPath(path, overlayPaint)
            val center = PointF(points.map { it.x }.average().toFloat(), points.map { it.y }.average().toFloat())
            drawSmallLabel(canvas, part.type.label, center, if (selected) 0xffb36b00.toInt() else color)
        }
    }

    private fun footprintPartColor(type: WallFootprintPartType): Int = when (type) {
        WallFootprintPartType.MAIN_TRACT -> 0xff176d19.toInt()
        WallFootprintPartType.PROJECTION -> 0xff1976d2.toInt()
        WallFootprintPartType.RECESS -> 0xffc62828.toInt()
        WallFootprintPartType.SEPARATE_WING -> 0xff6a1b9a.toInt()
        WallFootprintPartType.SUPERSTRUCTURE -> 0xffef6c00.toInt()
    }

    private fun drawMapChrome(canvas: Canvas) {
        if (mode == EditorMode.PAN) {
            overlayPaint.style = Paint.Style.STROKE
            overlayPaint.strokeWidth = 1.5f * density
            overlayPaint.color = 0xff237a35.toInt()
            canvas.drawCircle(width / 2f, height / 2f, 10f * density, overlayPaint)
            canvas.drawLine(width / 2f - 16f * density, height / 2f, width / 2f + 16f * density, height / 2f, overlayPaint)
            canvas.drawLine(width / 2f, height / 2f - 16f * density, width / 2f, height / 2f + 16f * density, overlayPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_POINTER_DOWN && event.pointerCount >= 2) {
            cancelNodeLongPress()
            cancelTemporaryPan()
            drawingPolygon = false
            draggingSelection = false
            draggingMap = false
            lastTwoFingerAngle = twoFingerAngle(event)
        } else if (event.actionMasked == MotionEvent.ACTION_MOVE && event.pointerCount >= 2 &&
            workspace == EditorWorkspace.OUTLINE
        ) {
            val current = twoFingerAngle(event)
            lastTwoFingerAngle?.let { previous ->
                var delta = current - previous
                while (delta > 180f) delta -= 360f
                while (delta < -180f) delta += 360f
                if (abs(delta) >= 0.15f) {
                    project.mapRotationDeg = ((project.mapRotationDeg + delta) % 360.0 + 360.0) % 360.0
                    onViewportChanged?.invoke()
                    invalidate()
                }
            }
            lastTwoFingerAngle = current
        }
        if (event.pointerCount > 1 || scaleGestureActive || ignoreTouchesUntilUp) {
            cancelNodeLongPress()
            cancelTemporaryPan()
            drawingPolygon = false
            draggingSelection = false
            if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (event.actionMasked == MotionEvent.ACTION_UP && lastTwoFingerAngle != null) {
                    changed("Zobrazenie: zoom ${project.zoom}, otočenie ${project.mapRotationDeg.toInt()}°.")
                }
                ignoreTouchesUntilUp = false
                lastTwoFingerAngle = null
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            return true
        }
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastTouch.set(event.x, event.y)
                lastFreehandPoint.set(event.x, event.y)
                downX = event.x
                downY = event.y
                longPressTriggered = false
                when (mode) {
                    EditorMode.PAN -> draggingMap = true
                    EditorMode.DRAW_POLYGON -> {
                        freehandStroke.clear()
                        freehandStroke += fromScreen(event.x, event.y)
                        drawingPolygon = true
                    }
                    EditorMode.EDIT, EditorMode.EDIT_LINES, EditorMode.TYPOLOGY -> {
                        if (isFreeSpace(event.x, event.y)) scheduleTemporaryPan(event.x, event.y)
                        else scheduleNodeLongPress(event.x, event.y)
                    }
                    EditorMode.ADD_LINE, EditorMode.ADD_OBJECT -> {
                        if (isFreeSpace(event.x, event.y)) scheduleTemporaryPan(event.x, event.y)
                    }
                    else -> Unit
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - lastTouch.x
                val dy = event.y - lastTouch.y
                if (!longPressTriggered && hypot(event.x - downX, event.y - downY) > touchSlop) {
                    cancelNodeLongPress()
                    cancelTemporaryPan()
                }
                when {
                    draggingMap -> panBy(dx, dy)
                    drawingPolygon -> {
                        if (hypot(event.x - lastFreehandPoint.x, event.y - lastFreehandPoint.y) > 9f * density) {
                            freehandStroke += fromScreen(event.x, event.y)
                            lastFreehandPoint.set(event.x, event.y)
                            invalidate()
                        }
                    }
                    draggingSelection -> {
                        when (selectionKind) {
                            SelectionKind.VERTEX -> {
                                project.polygon[selectedIndex] = gridPoint(fromScreen(event.x, event.y))
                                invalidateTopology()
                            }
                            SelectionKind.OBJECT -> project.objects[selectedIndex].center = fromScreen(event.x, event.y)
                            SelectionKind.LINE -> selectedEndpoint?.let { endpoint ->
                                val line = project.lines[selectedIndex]
                                if (endpoint == LineEndpoint.START) line.start = gridPoint(fromScreen(event.x, event.y))
                                else line.end = gridPoint(fromScreen(event.x, event.y))
                                invalidateTopology()
                            }
                            SelectionKind.EDGE -> if (selectedBoundaryVertexIndex in project.polygon.indices) {
                                project.polygon[selectedBoundaryVertexIndex] = gridPoint(fromScreen(event.x, event.y))
                                invalidateTopology()
                            } else if (selectedIndex in project.polygon.indices) {
                                val next = (selectedIndex + 1) % project.polygon.size
                                val origin = Geometry.centroid(project.polygon)
                                val oldTouch = Geometry.toLocal(fromScreen(lastTouch.x, lastTouch.y), origin)
                                val newTouch = Geometry.toLocal(fromScreen(event.x, event.y), origin)
                                val deltaX = newTouch.x - oldTouch.x
                                val deltaY = newTouch.y - oldTouch.y
                                listOf(selectedIndex, next).forEach { vertexIndex ->
                                    val local = Geometry.toLocal(project.polygon[vertexIndex], origin)
                                    project.polygon[vertexIndex] = gridPoint(Geometry.toGeo(
                                        LocalPoint(local.x + deltaX, local.y + deltaY), origin
                                    ))
                                }
                                invalidateTopology()
                            }
                            SelectionKind.FOOTPRINT_PART, SelectionKind.NONE -> Unit
                        }
                        invalidate()
                    }
                }
                lastTouch.set(event.x, event.y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                cancelNodeLongPress()
                cancelTemporaryPan()
                when {
                    drawingPolygon -> {
                        drawingPolygon = false
                        if (event.actionMasked == MotionEvent.ACTION_CANCEL) {
                            freehandStroke.clear()
                            status("Kreslenie obrysu bolo zrušené.")
                            invalidate()
                            return true
                        }
                        val simplified = simplifyFreehand(freehandStroke)
                        freehandStroke.clear()
                        if (simplified.size >= 3) {
                            pushHistory()
                            resetMetricGridFrame()
                            MetricPlanGrid.ensureProjectFrame(project, simplified)
                            project.polygon = simplified.map {
                                MetricPlanGrid.snap(project, it, simplified)
                            }.toMutableList()
                            project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
                            project.lines.clear()
                            project.objects.clear()
                            project.edgeTypes.clear()
                            invalidateTopology()
                            mode = EditorMode.EDIT
                            changed("Obrys vytvorený: ${project.polygon.size} bodov, ${"%.1f".format(Geometry.areaM2(project.polygon))} m²")
                        } else status("Ťah bol príliš krátky. Skúste obkresliť celý obrys.")
                    }
                    draggingMap -> {
                        draggingMap = false
                        if (temporaryPan) {
                            temporaryPan = false
                            status("Podklad bol posunutý; aktívny nástroj zostal zachovaný.")
                        } else changed("Stred mapy: ${"%.6f".format(project.centerLat)}, ${"%.6f".format(project.centerLon)}")
                    }
                    draggingSelection -> {
                        draggingSelection = false
                        if (selectionKind == SelectionKind.LINE && selectedEndpoint != null) snapSelectedEndpoint()
                        changed(
                            if (selectionKind == SelectionKind.EDGE) "Koncový bod vybratej obvodovej hrany bol upravený."
                            else "Koncový bod vybratej línie bol upravený."
                        )
                    }
                    event.actionMasked == MotionEvent.ACTION_UP && mode == EditorMode.EDIT ->
                        hitTest(event.x, event.y, allowVertices = false)
                    event.actionMasked == MotionEvent.ACTION_UP && mode == EditorMode.EDIT_LINES ->
                        hitTestLineOnly(event.x, event.y)
                    event.actionMasked == MotionEvent.ACTION_UP && mode == EditorMode.TYPOLOGY ->
                        hitTest(event.x, event.y, allowVertices = false)
                    event.actionMasked == MotionEvent.ACTION_UP -> handleTap(event.x, event.y)
                }
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_SCROLL &&
            event.source and InputDevice.SOURCE_CLASS_POINTER != 0
        ) {
            val wheel = event.getAxisValue(MotionEvent.AXIS_VSCROLL)
            if (wheel != 0f) {
                onZoomRequested?.invoke(wheel)
                return true
            }
        }
        return super.onGenericMotionEvent(event)
    }

    private fun handleTap(x: Float, y: Float) {
        val rawPoint = fromScreen(x, y)
        when (mode) {
            EditorMode.ADD_VERTEX -> {
                pushHistory()
                project.polygon += MetricPlanGrid.snap(project, rawPoint, project.polygon + rawPoint)
                project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
                invalidateTopology()
                changed("Pridaný bod obrysu č. ${project.polygon.size}.")
            }
            EditorMode.ADD_LINE -> {
                val point = gridPoint(snapCandidate(rawPoint)?.point ?: rawPoint)
                val first = pendingLineStart
                if (first == null) {
                    pendingLineStart = point
                    status("${activeLineType.label}: označte druhý bod.")
                    invalidate()
                } else {
                    pushHistory()
                    project.lines += RoofLine(type = activeLineType, start = first, end = point)
                    invalidateTopology()
                    pendingLineStart = null
                    changed("${activeLineType.label} bol pridaný.")
                }
            }
            EditorMode.ADD_OBJECT -> {
                pushHistory()
                val item = defaultObject(activeObjectType, rawPoint)
                project.objects += item
                attachObjectToGraph(item)
                changed("${activeObjectType.label} bol pridaný.")
                onObjectAdded?.invoke(project.objects.lastIndex)
            }
            else -> Unit
        }
    }

    private fun panBy(dx: Float, dy: Float) {
        if (onPanRequested?.invoke(dx, dy) == true) {
            onViewportChanged?.invoke()
            invalidate()
            return
        }
        val angle = Math.toRadians(project.mapRotationDeg)
        val worldDx = dx * cos(angle) + dy * sin(angle)
        val worldDy = -dx * sin(angle) + dy * cos(angle)
        val centerX = Geometry.worldX(project.centerLon, project.zoom) - worldDx
        val centerY = Geometry.worldY(project.centerLat, project.zoom) - worldDy
        project.centerLon = Geometry.lonFromWorld(centerX, project.zoom)
        project.centerLat = Geometry.latFromWorld(centerY, project.zoom)
        onViewportChanged?.invoke()
        invalidate()
    }

    private fun toScreen(point: GeoPoint): PointF {
        projectPointToScreen?.let { return it(point) }
        val centerX = Geometry.worldX(project.centerLon, project.zoom)
        val centerY = Geometry.worldY(project.centerLat, project.zoom)
        val dx = Geometry.worldX(point.lon, project.zoom) - centerX
        val dy = Geometry.worldY(point.lat, project.zoom) - centerY
        val angle = Math.toRadians(project.mapRotationDeg)
        return PointF(
            (dx * cos(angle) - dy * sin(angle) + width / 2.0).toFloat(),
            (dx * sin(angle) + dy * cos(angle) + height / 2.0).toFloat()
        )
    }

    private fun fromScreen(x: Float, y: Float): GeoPoint {
        screenPointToProject?.let { return it(x, y) }
        val angle = Math.toRadians(project.mapRotationDeg)
        val screenDx = x - width / 2.0
        val screenDy = y - height / 2.0
        val dx = screenDx * cos(angle) + screenDy * sin(angle)
        val dy = -screenDx * sin(angle) + screenDy * cos(angle)
        val worldX = Geometry.worldX(project.centerLon, project.zoom) + dx
        val worldY = Geometry.worldY(project.centerLat, project.zoom) + dy
        return GeoPoint(
            Geometry.latFromWorld(worldY, project.zoom),
            Geometry.lonFromWorld(worldX, project.zoom)
        )
    }

    private fun hitTest(x: Float, y: Float, allowVertices: Boolean = true) {
        clearSelection()
        val threshold = 25f * density
        if (allowVertices) {
            project.polygon.forEachIndexed { index, geo ->
                val point = toScreen(geo)
                if (hypot(x - point.x, y - point.y) < threshold) {
                    selectionKind = SelectionKind.VERTEX
                    selectedIndex = index
                    status("Vybraný vrchol #${index + 1}.")
                    return
                }
            }
        }
        project.objects.forEachIndexed { index, item ->
            val point = toScreen(item.center)
            if (hypot(x - point.x, y - point.y) < threshold) {
                selectionKind = SelectionKind.OBJECT
                selectedIndex = index
                status("Vybraný prvok: ${item.type.label}.")
                return
            }
        }
        project.lines.forEachIndexed { index, line ->
            if (distancePointToScreenSegment(x, y, toScreen(line.start), toScreen(line.end)) < 18f * density) {
                selectionKind = SelectionKind.LINE
                selectedIndex = index
                status("Vybraná línia: ${line.type.label}.")
                return
            }
        }
        val edge = selectedEdgeNear(x, y)
        if (edge >= 0) {
            selectionKind = SelectionKind.EDGE
            selectedIndex = edge
            val length = Geometry.distanceM(project.polygon[edge], project.polygon[(edge + 1) % project.polygon.size])
            status("Vybraná hrana #${edge + 1}: ${"%.2f".format(length)} m. Použite Rozmer hrany alebo Typ hrany.")
        }
        invalidate()
    }

    private fun hitTestLineEndpoint(x: Float, y: Float) {
        clearSelection()
        val threshold = 22f * density
        project.lines.forEachIndexed { index, line ->
            listOf(line.start to LineEndpoint.START, line.end to LineEndpoint.END).forEach { (geo, endpoint) ->
                val point = toScreen(geo)
                if (hypot(x - point.x, y - point.y) <= threshold) {
                    selectionKind = SelectionKind.LINE
                    selectedIndex = index
                    selectedEndpoint = endpoint
                    status("Vybraný koniec línie ${line.type.label}. Potiahnite ho na uzol alebo hranu.")
                    invalidate()
                    return
                }
            }
        }
        project.lines.forEachIndexed { index, line ->
            if (distancePointToScreenSegment(x, y, toScreen(line.start), toScreen(line.end)) < 18f * density) {
                selectionKind = SelectionKind.LINE
                selectedIndex = index
                status("Vybraná línia: ${line.type.label}.")
                invalidate()
                return
            }
        }
        status("Klepnite na koncový bod alebo líniu.")
    }

    private fun hitTestLineOnly(x: Float, y: Float) {
        clearSelection()
        project.lines.forEachIndexed { index, line ->
            if (distancePointToScreenSegment(x, y, toScreen(line.start), toScreen(line.end)) < 18f * density) {
                selectionKind = SelectionKind.LINE
                selectedIndex = index
                status("Vybraná línia: ${line.type.label}. Bod vyberiete dlhším podržaním.")
                invalidate()
                return
            }
        }
        status("Bod vyberiete dlhším podržaním prsta.")
        invalidate()
    }

    private fun scheduleNodeLongPress(x: Float, y: Float) {
        cancelNodeLongPress()
        val task = Runnable {
            val dimensionIndex = boundaryDimensionHitBoxes.entries.firstOrNull { it.value.contains(x, y) }?.key
            if (workspace == EditorWorkspace.OUTLINE && dimensionIndex != null) {
                selectionKind = SelectionKind.EDGE
                selectedIndex = dimensionIndex
                longPressTriggered = true
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                invalidate()
                onBoundaryDimensionLongPressed?.invoke(dimensionIndex)
            } else if (mode != EditorMode.TYPOLOGY && hitTestEditableNode(x, y)) {
                longPressTriggered = true
                draggingSelection = true
                pushHistory()
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                status("Bod je vybraný oranžovou farbou. Môžete ho potiahnuť alebo odstrániť.")
                invalidate()
            } else if (mode == EditorMode.EDIT) {
                val edgeIndex = selectedEdgeNear(x, y)
                if (edgeIndex >= 0) {
                    selectionKind = SelectionKind.EDGE
                    selectedIndex = edgeIndex
                    selectedBoundaryVertexIndex = -1
                    longPressTriggered = true
                    draggingSelection = true
                    pushHistory()
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    invalidate()
                    onBoundaryEdgeLongPressed?.invoke(edgeIndex)
                }
            } else if (mode == EditorMode.TYPOLOGY) {
                if (workspace == EditorWorkspace.WALL_FOOTPRINT) {
                    val partIndex = wallFootprintPartAt(x, y)
                    if (partIndex >= 0) {
                        selectionKind = SelectionKind.FOOTPRINT_PART
                        selectedIndex = partIndex
                        longPressTriggered = true
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        status("Vybraná oblasť: ${project.wallFootprintParts[partIndex].type.label}.")
                        invalidate()
                        onWallFootprintPartLongPressed?.invoke(partIndex)
                    }
                    return@Runnable
                }
                val objectIndex = selectedObjectNear(x, y)
                val lineIndex = selectedLineNear(x, y)
                val edgeIndex = selectedEdgeNear(x, y)
                when {
                    objectIndex >= 0 -> {
                        selectionKind = SelectionKind.OBJECT
                        selectedIndex = objectIndex
                        longPressTriggered = true
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        invalidate()
                        onObjectLongPressed?.invoke(objectIndex)
                    }
                    lineIndex >= 0 -> {
                        selectionKind = SelectionKind.LINE
                        selectedIndex = lineIndex
                        longPressTriggered = true
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        invalidate()
                        onLineLongPressed?.invoke(lineIndex)
                    }
                    edgeIndex >= 0 -> {
                        selectionKind = SelectionKind.EDGE
                        selectedIndex = edgeIndex
                        longPressTriggered = true
                        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                        invalidate()
                        onBoundaryEdgeLongPressed?.invoke(edgeIndex)
                    }
                }
            }
        }
        longPressRunnable = task
        val onDimension = boundaryDimensionHitBoxes.values.any { it.contains(x, y) }
        postDelayed(task, if (mode == EditorMode.TYPOLOGY || onDimension) 1_000L else 480L)
    }

    private fun cancelNodeLongPress() {
        longPressRunnable?.let(::removeCallbacks)
        longPressRunnable = null
    }

    private fun scheduleTemporaryPan(x: Float, y: Float) {
        cancelTemporaryPan()
        val task = Runnable {
            if (!isFreeSpace(x, y)) return@Runnable
            longPressTriggered = true
            temporaryPan = true
            draggingMap = true
            lastTouch.set(x, y)
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            status("Dočasný posun podkladu – ťahajte prstom, po pustení sa vráti pôvodný nástroj.")
        }
        temporaryPanRunnable = task
        postDelayed(task, 1_000L)
    }

    private fun cancelTemporaryPan() {
        temporaryPanRunnable?.let(::removeCallbacks)
        temporaryPanRunnable = null
    }

    private fun isFreeSpace(x: Float, y: Float): Boolean {
        val pointThreshold = 24f * density
        if (boundaryDimensionHitBoxes.values.any { it.contains(x, y) }) return false
        if (project.polygon.any { point ->
                val screen = toScreen(point)
                hypot(x - screen.x, y - screen.y) <= pointThreshold
            }) return false
        if (selectedEdgeNear(x, y) >= 0 || selectedLineNear(x, y) >= 0) return false
        if (project.objects.any { item ->
                val screen = toScreen(item.center)
                hypot(x - screen.x, y - screen.y) <= pointThreshold
            }) return false
        if (workspace == EditorWorkspace.WALL_FOOTPRINT && wallFootprintPartAt(x, y) >= 0) return false
        return true
    }

    private fun hitTestEditableNode(x: Float, y: Float): Boolean {
        val threshold = 24f * density
        when (selectionKind) {
            SelectionKind.EDGE -> {
                val edgeIndex = selectedIndex
                if (edgeIndex !in project.polygon.indices) return false
                val endpointIndices = intArrayOf(edgeIndex, (edgeIndex + 1) % project.polygon.size)
                endpointIndices.forEach { vertexIndex ->
                    val point = toScreen(project.polygon[vertexIndex])
                    if (hypot(x - point.x, y - point.y) <= threshold) {
                        selectedBoundaryVertexIndex = vertexIndex
                        selectedEndpoint = null
                        return true
                    }
                }
            }
            SelectionKind.LINE -> {
                val lineIndex = selectedIndex
                if (lineIndex !in project.lines.indices) return false
                val line = project.lines[lineIndex]
                listOf(line.start to LineEndpoint.START, line.end to LineEndpoint.END).forEach { (geo, endpoint) ->
                    val point = toScreen(geo)
                    if (hypot(x - point.x, y - point.y) <= threshold) {
                        selectedEndpoint = endpoint
                        selectedBoundaryVertexIndex = -1
                        return true
                    }
                }
            }
            SelectionKind.NONE, SelectionKind.VERTEX, SelectionKind.OBJECT, SelectionKind.FOOTPRINT_PART -> Unit
        }
        return false
    }

    private fun twoFingerAngle(event: MotionEvent): Float {
        if (event.pointerCount < 2) return 0f
        return Math.toDegrees(
            atan2(
                (event.getY(1) - event.getY(0)).toDouble(),
                (event.getX(1) - event.getX(0)).toDouble()
            )
        ).toFloat()
    }

    private fun snapCandidate(point: GeoPoint, excludeLineIndex: Int = -1): SnapCandidate? {
        val screen = toScreen(point)
        var best: SnapCandidate? = null
        fun consider(candidate: GeoPoint, distance: Float) {
            if (distance <= 26f * density && (best == null || distance < best!!.distancePx)) {
                best = SnapCandidate(candidate.copy(), distance)
            }
        }
        fun considerPoint(candidate: GeoPoint) {
            val p = toScreen(candidate)
            consider(candidate, hypot(screen.x - p.x, screen.y - p.y))
        }
        fun considerSegment(a: GeoPoint, b: GeoPoint) {
            val sa = toScreen(a)
            val sb = toScreen(b)
            val dx = sb.x - sa.x
            val dy = sb.y - sa.y
            if (abs(dx) + abs(dy) < 0.001f) return
            val t = (((screen.x - sa.x) * dx + (screen.y - sa.y) * dy) / (dx * dx + dy * dy)).coerceIn(0f, 1f)
            val projected = PointF(sa.x + dx * t, sa.y + dy * t)
            consider(gridPoint(fromScreen(projected.x, projected.y)), hypot(screen.x - projected.x, screen.y - projected.y))
        }
        project.polygon.forEach(::considerPoint)
        project.polygon.indices.forEach { index ->
            considerSegment(project.polygon[index], project.polygon[(index + 1) % project.polygon.size])
        }
        project.lines.forEachIndexed { index, line ->
            if (index != excludeLineIndex) {
                considerPoint(line.start)
                considerPoint(line.end)
                considerSegment(line.start, line.end)
            }
        }
        return best
    }

    private fun snapSelectedEndpoint(): Boolean {
        val index = selectedIndex
        val endpoint = selectedEndpoint ?: return false
        if (index !in project.lines.indices) return false
        val line = project.lines[index]
        val current = if (endpoint == LineEndpoint.START) line.start else line.end
        val target = snapCandidate(current, excludeLineIndex = index) ?: return false
        if (endpoint == LineEndpoint.START) line.start = gridPoint(target.point) else line.end = gridPoint(target.point)
        return true
    }

    private fun selectedEdgeNear(x: Float, y: Float): Int {
        if (project.polygon.size < 3) return -1
        return project.polygon.indices
            .map { index ->
                index to distancePointToScreenSegment(
                    x, y,
                    toScreen(project.polygon[index]),
                    toScreen(project.polygon[(index + 1) % project.polygon.size])
                )
            }
            .filter { it.second < 18f * density }
            .minByOrNull { it.second }?.first ?: -1
    }

    private fun selectedLineNear(x: Float, y: Float): Int = project.lines.indices
        .map { index -> index to distancePointToScreenSegment(
            x, y, toScreen(project.lines[index].start), toScreen(project.lines[index].end)
        ) }
        .filter { it.second < 18f * density }
        .minByOrNull { it.second }?.first ?: -1

    private fun selectedObjectNear(x: Float, y: Float): Int = project.objects.indices
        .filter { workspace != EditorWorkspace.SUPERSTRUCTURES || project.objects[it].type in SUPERSTRUCTURE_TYPES }
        .map { index ->
            val point = toScreen(project.objects[index].center)
            index to hypot(x - point.x, y - point.y)
        }
        .filter { it.second < 28f * density }
        .minByOrNull { it.second }?.first ?: -1

    private fun wallFootprintPartAt(x: Float, y: Float): Int {
        if (project.wallFootprintParts.isEmpty()) return -1
        val geo = fromScreen(x, y)
        return project.wallFootprintParts.indices.reversed().firstOrNull { index ->
            val polygon = project.wallFootprintParts[index].polygon
            if (polygon.size < 3) false else {
                val origin = polygon.first()
                Geometry.pointInPolygon(
                    Geometry.toLocal(geo, origin),
                    polygon.map { Geometry.toLocal(it, origin) }
                )
            }
        } ?: -1
    }

    private fun distancePointToScreenSegment(x: Float, y: Float, a: PointF, b: PointF): Float {
        val dx = b.x - a.x
        val dy = b.y - a.y
        if (abs(dx) + abs(dy) < 0.001f) return hypot(x - a.x, y - a.y)
        val t = (((x - a.x) * dx + (y - a.y) * dy) / (dx * dx + dy * dy)).coerceIn(0f, 1f)
        return hypot(x - (a.x + t * dx), y - (a.y + t * dy))
    }

    private fun simplifyFreehand(points: List<GeoPoint>): MutableList<GeoPoint> {
        val minDistance = max(0.12, Geometry.metersPerPixel(project.centerLat, project.zoom) * 5.0)
        return FreehandSimplifier.simplify(points, minDistance, maxPoints = 10)
    }

    private fun defaultObject(type: ObjectType, center: GeoPoint): RoofObject = when (type) {
        ObjectType.CHIMNEY -> RoofObject(type = type, center = center, widthMm = 700.0, heightMm = 700.0)
        ObjectType.ROOF_WINDOW -> RoofObject(type = type, center = center, widthMm = 780.0, heightMm = 1180.0)
        ObjectType.HATCH -> RoofObject(type = type, center = center, widthMm = 700.0, heightMm = 700.0)
        ObjectType.VENT -> RoofObject(type = type, center = center, diameterMm = 160.0)
        ObjectType.DORMER -> RoofObject(
            type = type, center = center, widthMm = 1800.0, heightMm = 2400.0,
            dormerType = activeDormerType, superstructureHeightM = 1.2,
            superstructureSlopeDeg = activeDormerType.defaultSlopeDeg(), dormerOverhangMm = 250.0
        )
        ObjectType.MACHINE_ROOM -> RoofObject(
            type = type, center = center, widthMm = 4000.0, heightMm = 5000.0,
            superstructureHeightM = 2.8, superstructureSlopeDeg = 0.0
        )
        ObjectType.SHAFT -> RoofObject(
            type = type, center = center, widthMm = 1800.0, heightMm = 1800.0,
            superstructureHeightM = 1.5, superstructureSlopeDeg = 0.0
        )
        ObjectType.TERRACE -> RoofObject(
            type = type, center = center, widthMm = 3000.0, heightMm = 4000.0,
            superstructureHeightM = 0.20, superstructureSlopeDeg = 0.0
        )
        ObjectType.DRAIN -> RoofObject(
            type = type, center = center, diameterMm = 110.0,
            value = (project.wallHeightM - 0.10).coerceAtLeast(0.0), note = "nízky bod"
        )
        ObjectType.DOWNSPOUT -> RoofObject(type = type, center = center, diameterMm = 100.0, heightMm = 3000.0)
        ObjectType.HEIGHT_MARK -> RoofObject(
            type = type, center = center, value = project.wallHeightM,
            note = "+${"%.3f".format(project.wallHeightM)}"
        )
        ObjectType.SLOPE_MARK -> RoofObject(type = type, center = center, value = project.slopeDeg)
    }

    private fun attachObjectToGraph(item: RoofObject) {
        val graph = canonicalGraph()
        val local = Geometry.toLocal(item.center, graph.origin)
        val containingFaces = graph.faces.values.filter { candidate ->
            val polygon = candidate.orderedNodeIds.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
            val insideOuter = polygon.size >= 3 && Geometry.pointInPolygon(local, polygon)
            val insideHole = candidate.holeNodeIdLoops.any { loop ->
                val hole = loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
                hole.size >= 3 && Geometry.pointInPolygon(local, hole)
            }
            insideOuter && !insideHole
        }
        val face = containingFaces.firstOrNull()
        item.attachedFaceId = face?.id
        val nearestEdge = graph.edges.values.minByOrNull { edge ->
            val a = graph.nodes[edge.startNodeId] ?: return@minByOrNull Double.MAX_VALUE
            val b = graph.nodes[edge.endNodeId] ?: return@minByOrNull Double.MAX_VALUE
            Geometry.distanceToSegment(local, LocalPoint(a.x, a.y), LocalPoint(b.x, b.y))
        }
        if (item.type == ObjectType.DOWNSPOUT) item.attachedEdgeId = nearestEdge?.id
        if (face == null) {
            project.roofGraph = graph
            project.roofTopology = graph.toTopology()
            return
        }
        val updatedFace = when (item.type) {
            ObjectType.SLOPE_MARK -> face.copy(
                slopeConstraint = FaceSlopeConstraint(item.value, item.directionX, item.directionY, hard = true)
            )
            ObjectType.HEIGHT_MARK -> face.copy(
                elevationConstraints = face.elevationConstraints + ElevationConstraint(
                    x = local.x, y = local.y, elevationZ = item.value, hard = true
                )
            )
            else -> face
        }
        val drains = if (item.type == ObjectType.DRAIN) {
            val constraint = DrainPointConstraint(
                id = "drain-${item.id}", faceIds = containingFaces.map { it.id }.toSet(),
                x = local.x, y = local.y, elevationZ = item.value, hard = true
            )
            graph.drainPointConstraints + (constraint.id to constraint)
        } else graph.drainPointConstraints
        project.roofGraph = graph.copy(
            faces = graph.faces + (face.id to updatedFace),
            drainPointConstraints = drains
        )
        project.roofTopology = graph.toTopology()
    }

    private fun objectColor(type: ObjectType): Int = when (type) {
        ObjectType.CHIMNEY -> 0xffc64c32.toInt()
        ObjectType.ROOF_WINDOW -> 0xff0099cc.toInt()
        ObjectType.HATCH -> 0xff7b5ea7.toInt()
        ObjectType.VENT -> 0xffe08a00.toInt()
        ObjectType.DORMER -> 0xff8e24aa.toInt()
        ObjectType.MACHINE_ROOM -> 0xff5d4037.toInt()
        ObjectType.SHAFT -> 0xff455a64.toInt()
        ObjectType.TERRACE -> 0xff00838f.toInt()
        ObjectType.DRAIN -> 0xff0066aa.toInt()
        ObjectType.DOWNSPOUT -> 0xff15924a.toInt()
        ObjectType.HEIGHT_MARK -> 0xff333333.toInt()
        ObjectType.SLOPE_MARK -> 0xff111111.toInt()
    }

    private companion object {
        val SUPERSTRUCTURE_TYPES = setOf(
            ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT, ObjectType.TERRACE
        )
    }

    private fun midpoint(a: PointF, b: PointF) = PointF((a.x + b.x) / 2f, (a.y + b.y) / 2f)

    private fun drawSmallLabel(canvas: Canvas, text: String, point: PointF, color: Int) {
        textPaint.textSize = 9.5f * density
        textPaint.color = color
        textPaint.isFakeBoldText = true
        val width = textPaint.measureText(text)
        overlayPaint.style = Paint.Style.FILL
        overlayPaint.color = 0xdfffffff.toInt()
        canvas.drawRoundRect(
            point.x - width / 2 - 3f * density,
            point.y - 12f * density,
            point.x + width / 2 + 3f * density,
            point.y + 2f * density,
            3f * density,
            3f * density,
            overlayPaint
        )
        canvas.drawText(text, point.x - width / 2, point.y - 2f * density, textPaint)
    }

    private fun clearSelection() {
        selectionKind = SelectionKind.NONE
        selectedIndex = -1
        selectedEndpoint = null
        selectedBoundaryVertexIndex = -1
    }

    private fun pushHistory() {
        history.addLast(ProjectJson.encode(project))
        while (history.size > 30) history.removeFirst()
        redoHistory.clear()
    }

    private fun canonicalGraph(): RoofGraph = project.roofGraph
        ?: RoofGraphFactory.fromTopology(project.roofTopology ?: RoofTopologyMigration.fromLegacyProject(project))

    /**
     * Legacy polygon order follows the user's drawing; canonical graph order starts at a stable
     * node ID. Match by real endpoints so index 0 can never silently address another wall.
     */
    private fun boundaryEdgeIdForPolygonIndex(graph: RoofGraph, index: Int): String? {
        if (index !in project.polygon.indices || project.polygon.size < 2) return null
        val targetA = Geometry.toLocal(project.polygon[index], graph.origin)
        val targetB = Geometry.toLocal(project.polygon[(index + 1) % project.polygon.size], graph.origin)
        return graph.edges.values.asSequence().filter { it.boundary }.mapNotNull { edge ->
            val a = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
            val direct = hypot(a.x - targetA.x, a.y - targetA.y) + hypot(b.x - targetB.x, b.y - targetB.y)
            val reverse = hypot(a.x - targetB.x, a.y - targetB.y) + hypot(b.x - targetA.x, b.y - targetA.y)
            edge.id to min(direct, reverse)
        }.minByOrNull { it.second }?.takeIf { it.second <= 0.10 }?.first
    }

    private fun installGraph(graph: RoofGraph): Boolean {
        val beforeGraph = canonicalGraph()
        val previousGraph = project.roofGraph
        val previousTopology = project.roofTopology
        val previousPolygon = project.polygon.map(GeoPoint::copy)
        val previousWallFootprint = project.wallFootprint.map(GeoPoint::copy)
        val previousObjects = project.objects.map { it.copy(center = it.center.copy()) }
        val sameBoundaryIds = RoofTopologyMigration.orderedBoundary(beforeGraph.toTopology())?.first ==
            RoofTopologyMigration.orderedBoundary(graph.toTopology())?.first
        val applied = if (sameBoundaryIds) {
            ProjectPlanSynchronizer.apply(
                project, beforeGraph, graph, previousWallFootprint, previousObjects
            )
        } else {
            project.roofGraph = graph
            RoofTopologyMigration.applyToProject(project, graph.toTopology(), requireFullyValid = false).applied
        }
        if (!applied) {
            project.roofGraph = previousGraph
            project.roofTopology = previousTopology
            project.polygon = previousPolygon.toMutableList()
            project.wallFootprint = previousWallFootprint.toMutableList()
            project.objects = previousObjects.toMutableList()
            return false
        }
        if (project.wallFootprint.size != project.polygon.size) {
            project.wallFootprint = project.polygon.map(GeoPoint::copy).toMutableList()
        }
        return true
    }

    private fun applySnapshot(snapshot: RoofProject) {
        project.name = snapshot.name
        project.customer = snapshot.customer
        project.address = snapshot.address
        project.centerLat = snapshot.centerLat
        project.centerLon = snapshot.centerLon
        project.zoom = snapshot.zoom
        project.mapRotationDeg = snapshot.mapRotationDeg
        project.slopeDeg = snapshot.slopeDeg
        project.wallHeightM = snapshot.wallHeightM
        project.atticHeightM = snapshot.atticHeightM
        project.shape = snapshot.shape
        project.mapType = snapshot.mapType
        project.lastGoogleMapType = snapshot.lastGoogleMapType
        project.underlayUri = snapshot.underlayUri
        project.underlayMime = snapshot.underlayMime
        project.underlayName = snapshot.underlayName
        project.underlayOriginLat = snapshot.underlayOriginLat
        project.underlayOriginLon = snapshot.underlayOriginLon
        project.underlayMetersPerPixel = snapshot.underlayMetersPerPixel
        project.underlayZoom = snapshot.underlayZoom
        project.underlayCenterX = snapshot.underlayCenterX
        project.underlayCenterY = snapshot.underlayCenterY
        project.geometryGridOriginLat = snapshot.geometryGridOriginLat
        project.geometryGridOriginLon = snapshot.geometryGridOriginLon
        project.geometryGridRotationDeg = snapshot.geometryGridRotationDeg
        project.polygon = snapshot.polygon
        project.wallFootprint = snapshot.wallFootprint
        project.wallFootprintParts = snapshot.wallFootprintParts
        project.wallFootprintPartsSignature = snapshot.wallFootprintPartsSignature
        project.lines = snapshot.lines
        project.objects = snapshot.objects
        project.edgeTypes = snapshot.edgeTypes
        project.roofTopology = snapshot.roofTopology
        project.roofGraph = snapshot.roofGraph
        project.selectedWorkItems = snapshot.selectedWorkItems
        clearSelection()
    }

    private fun invalidateTopology() {
        project.roofTopology = null
        // The legacy lists are still an editor mirror during the staged schema-5
        // migration. Never leave a stale canonical graph behind after that mirror
        // was edited; it will be deterministically rebuilt before the next solve,
        // save or 3D calculation.
        project.roofGraph = null
    }

    private fun gridPoint(point: GeoPoint): GeoPoint = MetricPlanGrid.snap(
        project,
        point,
        project.polygon.ifEmpty { listOf(point) }
    )

    private fun resetMetricGridFrame() {
        project.geometryGridOriginLat = Double.NaN
        project.geometryGridOriginLon = Double.NaN
        project.geometryGridRotationDeg = Double.NaN
    }

    private fun changed(message: String) {
        project.updatedAt = System.currentTimeMillis()
        status(message)
        onProjectChanged?.invoke()
        invalidate()
    }

    private fun status(message: String) {
        onStatusChanged?.invoke(message)
    }
}
