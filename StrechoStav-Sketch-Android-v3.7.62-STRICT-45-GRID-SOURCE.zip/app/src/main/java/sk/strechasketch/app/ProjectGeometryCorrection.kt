package sk.strechasketch.app

/**
 * Commits one confirmed outline/internal-line correction as one project-wide XY deformation.
 *
 * A correction is not valid when only RoofGraph moves. The masonry footprint, semantic roof
 * tracts and attached technical objects must follow the same node displacement; otherwise the
 * next 3D/IFC preparation receives mutually inconsistent coordinate owners.
 */
object ProjectGeometryCorrection {
    fun apply(
        project: RoofProject,
        preview: RoofSolverPreview,
        allowBoundaryChanges: Boolean = true
    ): TopologyApplyResult {
        if (!allowBoundaryChanges && !sameBoundary(preview.original, preview.proposed)) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "LOCKED_BOUNDARY_CHANGED",
                        message = "Korekcia vnútorných línií sa pokúsila zmeniť uzamknutý obrys.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }
        val beforeGraph = RoofGraphFactory.fromTopology(
            preview.original,
            project.roofGraph,
            normalizeGrid = allowBoundaryChanges
        )
        val afterGraph = RoofGraphFactory.fromTopology(
            preview.proposed,
            beforeGraph,
            normalizeGrid = allowBoundaryChanges
        )
        if (!ProjectPlanSynchronizer.apply(
                project,
                beforeGraph,
                afterGraph,
                normalizeBoundaryGrid = allowBoundaryChanges
            )
        ) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "PROJECT_PLAN_SYNCHRONIZATION_FAILED",
                        message = "Opravu nemožno bezpečne preniesť do pôdorysu stien a strešných traktov.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }

        // Persist a fresh semantic decomposition now, not lazily during a later 3D screen.
        // This guarantees that JSON/IFC exported directly after correction contains the same XY.
        if (allowBoundaryChanges) {
            WallFootprintSolver.refresh(project, force = true)
        }
        if (!allowBoundaryChanges) {
            // Keep the confirmed card-3 topology itself, not a lossy Graph -> Topology mirror.
            // In particular this retains every boundary edge record exactly and prevents a
            // later legacy migration from re-splitting gables merely for 3D incidence.
            project.roofTopology = preview.proposed.copy(
                nodes = preview.proposed.nodes.map { it.copy() },
                edges = preview.proposed.edges.map { it.copy() }
            )
        } else if (!preview.isValid) {
            project.roofTopology = null
        }
        return TopologyApplyResult(true, RoofTopologySolver.validate(afterGraph.toTopology()))
    }

    private fun sameBoundary(a: RoofTopology, b: RoofTopology): Boolean {
        val aBoundary = RoofTopologyMigration.orderedBoundary(a) ?: return false
        val bBoundary = RoofTopologyMigration.orderedBoundary(b) ?: return false
        if (aBoundary.first != bBoundary.first) return false
        val aEdges = aBoundary.second
        val bEdges = bBoundary.second
        if (aEdges.size != bEdges.size) return false
        if (aEdges.indices.any { index -> aEdges[index] != bEdges[index] }) return false
        val aNodes = a.nodes.associateBy { it.id }
        val bNodes = b.nodes.associateBy { it.id }
        return aBoundary.first.all { id ->
            val first = aNodes[id] ?: return@all false
            val second = bNodes[id] ?: return@all false
            first == second
        }
    }
}
