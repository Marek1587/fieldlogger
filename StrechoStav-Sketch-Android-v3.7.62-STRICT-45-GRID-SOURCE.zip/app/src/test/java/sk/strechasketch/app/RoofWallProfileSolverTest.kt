package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofWallProfileSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun `recess walls follow continuous roof underside instead of constant wall height`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 3.0),
            GraphNode("b", 10.0, 0.0, 3.0),
            GraphNode("c", 10.0, 8.0, 6.2),
            GraphNode("d", 0.0, 8.0, 6.2)
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                GraphEdge("ab", "a", "b", true, EdgeSemantic.EAVE, setOf("face")),
                GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
                GraphEdge("cd", "c", "d", true, EdgeSemantic.RIDGE, setOf("face")),
                GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
            ).associateBy { it.id },
            faces = mapOf(
                "face" to GraphFace(
                    "face", listOf("a", "b", "c", "d"),
                    listOf("ab", "bc", "cd", "da"), 80.0,
                    plane = RoofPlane(0.0, 0.4, 3.0)
                )
            )
        )
        val recessedWall = listOf(
            LocalPoint(1.0, 1.0), LocalPoint(9.0, 1.0),
            LocalPoint(9.0, 7.0), LocalPoint(1.0, 7.0),
            LocalPoint(1.0, 5.0), LocalPoint(3.0, 5.0),
            LocalPoint(3.0, 3.0), LocalPoint(1.0, 3.0)
        )

        val solution = RoofWallProfileSolver.solve(graph, recessedWall, 3.0)
        val recessSide = solution.segments.single { it.index == 5 }.samples

        assertEquals(4.82, recessSide.first().node.z, 1e-9)
        assertEquals(4.02, recessSide.last().node.z, 1e-9)
        assertTrue(solution.raisedSegmentCount >= 3)
    }

    @Test
    fun `ridge crossing adds one apex support without splitting the physical wall`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("m0", 5.0, 0.0),
            GraphNode("b", 10.0, 0.0), GraphNode("c", 10.0, 8.0),
            GraphNode("m1", 5.0, 8.0), GraphNode("d", 0.0, 8.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("am0", "a", "m0", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("m0b", "m0", "b", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("right")),
            GraphEdge("cm1", "c", "m1", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("m1d", "m1", "d", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("left")),
            GraphEdge("ridge", "m0", "m1", false, EdgeSemantic.RIDGE, setOf("left", "right"))
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin, nodes, edges,
            faces = mapOf(
                "left" to GraphFace(
                    "left", listOf("a", "m0", "m1", "d"),
                    listOf("am0", "ridge", "m1d", "da"), 40.0,
                    plane = RoofPlane(0.5, 0.0, 3.0)
                ),
                "right" to GraphFace(
                    "right", listOf("m0", "b", "c", "m1"),
                    listOf("m0b", "bc", "cm1", "ridge"), 40.0,
                    plane = RoofPlane(-0.5, 0.0, 8.0)
                )
            )
        )

        val result = RoofWallProfileSolver.solve(
            graph,
            listOf(LocalPoint(1.0, 4.0), LocalPoint(9.0, 4.0), LocalPoint(9.0, 5.0), LocalPoint(1.0, 5.0)),
            3.0
        )
        val crossing = result.segments.first().samples

        assertEquals(3, crossing.size)
        assertEquals(0.5, crossing[1].t, 1e-9)
        assertEquals(5.32, crossing[1].node.z, 1e-9)
    }

    @Test
    fun `wall inset inside a roof recess extrapolates the nearest solved plane`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("b", 10.0, 0.0),
            GraphNode("c", 10.0, 8.0), GraphNode("d", 6.0, 8.0),
            GraphNode("e", 6.0, 4.0), GraphNode("f", 4.0, 4.0),
            GraphNode("g", 4.0, 8.0), GraphNode("h", 0.0, 8.0)
        ).associateBy { it.id }
        val order = listOf("a", "b", "c", "d", "e", "f", "g", "h")
        val edges = order.indices.map { index ->
            val start = order[index]
            val end = order[(index + 1) % order.size]
            GraphEdge("edge-$index", start, end, true, EdgeSemantic.EAVE, setOf("face"))
        }.associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = edges,
            faces = mapOf(
                "face" to GraphFace(
                    id = "face",
                    orderedNodeIds = order,
                    orderedEdgeIds = edges.keys.toList(),
                    signedAreaM2 = 72.0,
                    plane = RoofPlane(0.0, 0.4, 3.0)
                )
            )
        )
        // The inset wall sides x=4.5 and x=5.5 are in the concave roof notch. The roof
        // plane still extends above them as an overhang and must define their top edge.
        val wallLoop = listOf(
            LocalPoint(1.0, 1.0), LocalPoint(9.0, 1.0),
            LocalPoint(9.0, 7.0), LocalPoint(5.5, 7.0),
            LocalPoint(5.5, 4.5), LocalPoint(4.5, 4.5),
            LocalPoint(4.5, 7.0), LocalPoint(1.0, 7.0)
        )

        val solution = RoofWallProfileSolver.solve(graph, wallLoop, 3.0)
        val rightRecessWall = solution.segments.single { it.index == 3 }.samples
        val leftRecessWall = solution.segments.single { it.index == 5 }.samples

        assertEquals(5.62, rightRecessWall.first().node.z, 1e-9)
        assertEquals(4.62, rightRecessWall.last().node.z, 1e-9)
        assertEquals(4.62, leftRecessWall.first().node.z, 1e-9)
        assertEquals(5.62, leftRecessWall.last().node.z, 1e-9)
        assertTrue(solution.raisedSegmentCount >= 2)
    }

    @Test
    fun `eave and two gable projection bypasses generic wall floor and follows one roof plane`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("b", 10.0, 0.0),
            GraphNode("c", 10.0, 8.0), GraphNode("d", 0.0, 8.0),
            GraphNode("p0", -3.0, 3.0), GraphNode("p1", 0.0, 3.0),
            GraphNode("p2", 0.0, 5.0), GraphNode("p3", -3.0, 5.0)
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                GraphEdge("ab", "a", "b", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("cd", "c", "d", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("dp2", "d", "p2", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("p2p3", "p2", "p3", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("p3p0", "p3", "p0", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("p0p1", "p0", "p1", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("p1a", "p1", "a", true, EdgeSemantic.EAVE, setOf("main-plane"))
            ).associateBy { it.id },
            faces = mapOf(
                "main-plane" to GraphFace(
                    id = "main-plane",
                    orderedNodeIds = listOf("a", "b", "c", "d", "p2", "p3", "p0", "p1"),
                    orderedEdgeIds = listOf("ab", "bc", "cd", "dp2", "p2p3", "p3p0", "p0p1", "p1a"),
                    signedAreaM2 = 86.0,
                    // The main roof underside is 3.22 m at x=0 and descends over
                    // the projection to 2.02 m at x=-3 after shell subtraction.
                    plane = RoofPlane(0.4, 0.0, 3.4)
                )
            )
        )
        val wallLoop = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
            LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0),
            LocalPoint(0.0, 5.0), LocalPoint(-3.0, 5.0),
            LocalPoint(-3.0, 3.0), LocalPoint(0.0, 3.0)
        )
        val context = WallFootprintSolver.Context(
            origin,
            listOf(
                WallFootprintSolver.Context.LocalPart(
                    "main", WallFootprintPartType.MAIN_TRACT,
                    listOf(
                        LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
                        LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0)
                    ),
                    80.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    "projection", WallFootprintPartType.PROJECTION,
                    listOf(
                        LocalPoint(-3.0, 3.0), LocalPoint(0.0, 3.0),
                        LocalPoint(0.0, 5.0), LocalPoint(-3.0, 5.0)
                    ),
                    6.0
                )
            )
        )

        val semantic = RoofWallProfileSolver.solve(
            graph, wallLoop, 3.0, footprintContext = context
        )
        val legacy = RoofWallProfileSolver.solve(graph, wallLoop, 3.0)
        val projectionRules = ProjectionWallProfileSolver.rules(graph, context)
        val upperReturn = semantic.segments.single { it.index == 4 }.samples
        val outerFacade = semantic.segments.single { it.index == 5 }.samples

        assertEquals(1, projectionRules.size)
        assertEquals("p3p0", projectionRules.single().frontEaveEdgeId)
        assertEquals(setOf("p2p3", "p0p1"), projectionRules.single().sideGableEdgeIds)
        assertEquals(3.22, upperReturn.first().node.z, 1e-9)
        assertEquals(2.02, upperReturn.last().node.z, 1e-9)
        assertEquals(2.02, outerFacade.first().node.z, 1e-9)
        assertEquals(2.02, outerFacade.last().node.z, 1e-9)
        assertEquals(3.0, legacy.segments.single { it.index == 5 }.samples.first().node.z, 1e-9)

        // A physical wall support can be inset/outset from the classified roof contour.
        // The already validated projection plane must continue over that small offset so the
        // side masonry remains trapezoidal instead of jumping back to storey height.
        val offsetWallLoop = wallLoop.mapIndexed { index, point ->
            if (index == 5 || index == 6) point.copy(x = -3.30) else point
        }
        val offsetProfile = RoofWallProfileSolver.solve(
            graph, offsetWallLoop, 3.0, footprintContext = context
        )
        val offsetFacade = offsetProfile.segments.single { it.index == 5 }.samples
        assertEquals(1.90, offsetFacade.first().node.z, 1e-9)
        assertEquals(1.90, offsetFacade.last().node.z, 1e-9)

        val invalidEdges = graph.edges.toMutableMap().apply {
            this["p0p1"] = getValue("p0p1").copy(semanticRole = EdgeSemantic.EAVE)
        }
        val invalidGraph = graph.copy(edges = invalidEdges)
        assertTrue(ProjectionWallProfileSolver.rules(invalidGraph, context).isEmpty())
        assertEquals(
            "Without the exact EAVE + 2x GABLE assembly the generic wall floor stays active",
            3.0,
            RoofWallProfileSolver.solve(
                invalidGraph, wallLoop, 3.0, footprintContext = context
            ).segments.single { it.index == 5 }.samples.first().node.z,
            1e-9
        )
    }

    @Test
    fun `field ifc coordinate mismatch is rejected instead of hidden by wall tolerance`() {
        val ridgeStart = GraphNode("ridge-start", 5.030558871245469, 6.727813719399008, 9.31189290332207)
        val ridgeEnd = GraphNode("ridge-end", -4.949764353560792, -6.786739485512827, 9.311892903322068)
        val boundaryNodes = listOf(
            GraphNode("n0", -2.3746161700747908, 5.568769886143558, 6.699122293039054),
            GraphNode("n1", -5.026275645196644, 1.9330165903331147, 6.699140683633731),
            GraphNode("n2", -3.571974326872467, 0.8723528002843732, 6.700376531595986),
            GraphNode("n3", -7.696777954839794, -4.783263437642983, 6.700405139187706),
            GraphNode("n4", -2.121956234597114, -8.849141299496491, 6.700096326399199),
            GraphNode("n5", 7.77757247252447, 4.724337671529163, 6.7001644041754345),
            GraphNode("n6", 2.2027507522817906, 8.790215533382671, 6.70033648096758),
            GraphNode("n7", -0.9203148517506139, 4.508106096094817, 6.70035814100131)
        )
        val nodes = (boundaryNodes + ridgeStart + ridgeEnd).associateBy { it.id }
        val faceId = "field-face"
        val edges = listOf(
            GraphEdge("e0", "n0", "n1", true, EdgeSemantic.EAVE, setOf(faceId)),
            GraphEdge("e1", "n1", "n2", true, EdgeSemantic.GABLE, setOf(faceId)),
            GraphEdge("e2", "n2", "n3", true, EdgeSemantic.EAVE, setOf(faceId)),
            GraphEdge("e3", "n3", "ridge-end", true, EdgeSemantic.GABLE, setOf(faceId)),
            GraphEdge("e4", "ridge-end", "n4", true, EdgeSemantic.GABLE, setOf("other")),
            GraphEdge("e5", "n4", "n5", true, EdgeSemantic.EAVE, setOf("other")),
            GraphEdge("e6", "n5", "ridge-start", true, EdgeSemantic.GABLE, setOf("other")),
            GraphEdge("e7", "ridge-start", "n6", true, EdgeSemantic.GABLE, setOf(faceId)),
            GraphEdge("e8", "n6", "n7", true, EdgeSemantic.EAVE, setOf(faceId)),
            GraphEdge("e9", "n7", "n0", true, EdgeSemantic.GABLE, setOf(faceId)),
            GraphEdge("ridge", "ridge-start", "ridge-end", false, EdgeSemantic.RIDGE, setOf(faceId, "other"))
        ).associateBy { it.id }
        val plane = RoofPlane(0.552864913099575, -0.4082836072140929, 9.407894751466163)
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = edges,
            faces = mapOf(
                faceId to GraphFace(
                    faceId,
                    listOf("ridge-end", "ridge-start", "n6", "n7", "n0", "n1", "n2", "n3"),
                    listOf("ridge", "e7", "e8", "e9", "e0", "e1", "e2", "e3"),
                    66.06,
                    plane = plane
                ),
                "other" to GraphFace(
                    "other", listOf("ridge-start", "ridge-end", "n4", "n5"),
                    listOf("ridge", "e4", "e5", "e6"), 57.96,
                    plane = RoofPlane(-0.5481909343656411, 0.40483193420624414, 9.215600543011057)
                )
            )
        )
        val projection = listOf(
            LocalPoint(-3.2336079931487873, 0.9968848207305522),
            LocalPoint(-0.8765773486551708, 4.228665528643813),
            LocalPoint(-2.250084149306982, 5.230403552111897),
            LocalPoint(-4.607114793800599, 1.9986228449896086)
        )
        val context = WallFootprintSolver.Context(
            origin,
            listOf(
                WallFootprintSolver.Context.LocalPart(
                    "field-projection", WallFootprintPartType.PROJECTION,
                    projection, 6.8
                )
            )
        )
        val wallLoop = listOf(
            LocalPoint(-2.3199442910362142, 5.219469176773183),
            LocalPoint(-4.676974935788473, 1.9876884696508945),
            LocalPoint(-3.2226736172991184, 0.9270246795381194),
            LocalPoint(-7.347477245421588, -4.72859155832137),
            LocalPoint(-4.802449938194539, -6.584753191414214),
            LocalPoint(-2.1766281136472307, -8.499840590360774),
            LocalPoint(7.42827176300049, 4.669665792467653),
            LocalPoint(4.883244456032082, 6.525827425560495),
            LocalPoint(2.2574226312261327, 8.440914823716085),
            LocalPoint(-0.8656429728055016, 4.158805386660408)
        )

        val rules = ProjectionWallProfileSolver.rules(graph, context)

        assertTrue("Stale tract coordinates must not activate a different wall rule", rules.isEmpty())
    }
}
