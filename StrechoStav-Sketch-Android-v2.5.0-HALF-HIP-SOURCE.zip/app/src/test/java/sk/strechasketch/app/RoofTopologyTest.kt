package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class RoofTopologyTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    private fun rectangleProject(): RoofProject = RoofProject(
        polygon = mutableListOf(geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0))
    )

    @Test
    fun crossingRoofLinesCreateSharedIntersection() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            lines += RoofLine(type = LineType.VALLEY, start = geo(6.0, 0.0), end = geo(6.0, 8.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.createdIntersections >= 1)
        assertTrue(preview.statistics.splitEdges >= 2)
        assertTrue(preview.faces.isNotEmpty())
        assertTrue(preview.isValid)
    }

    @Test
    fun nearCoincidentEndpointsAreMergedDeterministically() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(6.0, 4.0))
            lines += RoofLine(type = LineType.RIDGE, start = geo(6.02, 4.01), end = geo(12.0, 4.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.mergedNodes >= 1)
        assertTrue(preview.proposed.edges.none { it.startNodeId == it.endNodeId })
    }

    @Test
    fun legacyJsonMigratesWithoutLosingReportInputs() {
        val project = rectangleProject().apply {
            name = "Regresný projekt"
            slopeDeg = 31.5
            wallHeightM = 4.2
            mapRotationDeg = 37.0
            atticHeightM = 0.85
            objects += RoofObject(type = ObjectType.CHIMNEY, center = geo(3.0, 3.0))
        }
        val encoded = ProjectJson.encode(project)
        val decoded = ProjectJson.decode(encoded)
        assertEquals(project.name, decoded.name)
        assertEquals(project.slopeDeg, decoded.slopeDeg, 0.0001)
        assertEquals(project.wallHeightM, decoded.wallHeightM, 0.0001)
        assertEquals(project.mapRotationDeg, decoded.mapRotationDeg, 0.0001)
        assertEquals(project.atticHeightM, decoded.atticHeightM, 0.0001)
        assertEquals(1, decoded.objects.size)
        assertTrue(decoded.roofTopology != null)
    }

    @Test
    fun concaveFootprintProducesValidFace() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 4.0),
                geo(5.0, 4.0), geo(5.0, 9.0), geo(0.0, 9.0)
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.isValid)
        assertEquals(1, preview.faces.size)
    }

    @Test
    fun freehandOutlineIsSmoothedToAtMostTenPoints() {
        val noisyCircle = (0 until 80).map { index ->
            val angle = 2.0 * PI * index / 80.0
            val noise = if (index % 2 == 0) 0.18 else -0.18
            geo((5.0 + noise) * cos(angle), (5.0 + noise) * sin(angle))
        }
        val simplified = FreehandSimplifier.simplify(noisyCircle, minimumDistanceM = 0.05, maxPoints = 10)
        assertTrue(simplified.size in 3..10)
        assertTrue(Geometry.areaM2(simplified) > 50.0)
    }

    @Test
    fun halfHipWithTwoGableSegmentsCreatesThreeValidFaces() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 4.0),
                geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(5.0, 4.0), end = geo(12.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 0.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 8.0))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.GABLE,
                3 to LineType.EAVE,
                4 to LineType.EAVE
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertEquals(3, preview.faces.size)
    }

    @Test
    fun gableBoundaryDoesNotPullRidgeEndpointDownToWallHeight() {
        val polygon = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(12.0, 0.0), LocalPoint(12.0, 4.0),
            LocalPoint(12.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val edgeTypes = mapOf(
            0 to LineType.EAVE,
            1 to LineType.GABLE,
            2 to LineType.GABLE,
            3 to LineType.EAVE,
            4 to LineType.EAVE
        )

        val centerDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(5.0, 4.0), polygon, edgeTypes)
        val gableRidgeDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 4.0), polygon, edgeTypes)
        val eaveDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 0.0), polygon, edgeTypes)

        assertEquals(4.0, centerDistance, 0.0001)
        assertEquals(centerDistance, gableRidgeDistance, 0.0001)
        assertEquals(0.0, eaveDistance, 0.0001)
    }
}
