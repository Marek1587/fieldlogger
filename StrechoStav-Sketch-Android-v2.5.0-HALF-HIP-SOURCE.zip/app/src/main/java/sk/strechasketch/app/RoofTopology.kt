package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Model-space (metre) topology used by the roof solver.  It intentionally lives
 * beside the legacy [RoofProject] model: loading an old project never rewrites it
 * until [RoofTopologyMigration.applyToProject] is called explicitly.
 */
enum class TopologyNodeType {
    FOOTPRINT,
    LINE_ENDPOINT,
    INTERSECTION,
    JUNCTION
}

data class TopologyNode(
    val id: String,
    val x: Double,
    val y: Double,
    val type: TopologyNodeType,
    val locked: Boolean = false
)

data class TopologyEdge(
    val id: String,
    val startNodeId: String,
    val endNodeId: String,
    val type: LineType,
    val locked: Boolean = false,
    val boundary: Boolean = false,
    val sourceId: String? = null,
    val note: String = ""
)

data class RoofTopology(
    val origin: GeoPoint,
    val nodes: List<TopologyNode>,
    val edges: List<TopologyEdge>,
    val schemaVersion: Int = 2
)

data class RoofSolverConfig(
    /** Solver tolerances are metres. Pixel tolerances belong to the editor only. */
    val mergeToleranceM: Double = 0.05,
    val snapToleranceM: Double = 0.35,
    val minimumEdgeLengthM: Double = 0.01,
    val intersectionEpsilon: Double = 1e-7,
    val allowFreeInternalEnds: Boolean = false
) {
    init {
        require(mergeToleranceM >= 0.0)
        require(snapToleranceM >= mergeToleranceM)
        require(minimumEdgeLengthM >= 0.0)
        require(intersectionEpsilon > 0.0)
    }
}

enum class TopologyIssueSeverity { WARNING, ERROR }

data class TopologyIssue(
    val code: String,
    val message: String,
    val severity: TopologyIssueSeverity,
    val nodeIds: List<String> = emptyList(),
    val edgeIds: List<String> = emptyList(),
    val x: Double? = null,
    val y: Double? = null,
    val distanceM: Double? = null
)

data class RoofSolverStatistics(
    val mergedNodes: Int = 0,
    val createdIntersections: Int = 0,
    val splitEdges: Int = 0,
    val snappedFreeEnds: Int = 0,
    val removedShortEdges: Int = 0,
    val removedDuplicateEdges: Int = 0
) {
    val totalChanges: Int
        get() = mergedNodes + createdIntersections + splitEdges + snappedFreeEnds +
            removedShortEdges + removedDuplicateEdges
}

data class NodeMovement(
    val sourceNodeId: String,
    val targetNodeId: String,
    val fromX: Double,
    val fromY: Double,
    val toX: Double,
    val toY: Double,
    val reason: String
)

/** Immutable preview. The caller applies [proposed] only after user confirmation. */
data class RoofSolverPreview(
    val original: RoofTopology,
    val proposed: RoofTopology,
    val statistics: RoofSolverStatistics,
    val movements: List<NodeMovement>,
    val issues: List<TopologyIssue>,
    val faces: List<TopologyFace>
) {
    val isValid: Boolean get() = issues.none { it.severity == TopologyIssueSeverity.ERROR }
}

data class TopologyFace(
    val nodeIds: List<String>,
    val edgeIds: List<String>,
    val signedAreaM2: Double
)

data class TopologyApplyResult(
    val applied: Boolean,
    val issues: List<TopologyIssue>
)

/** Backwards-compatible adapter for the current polygon/lines representation. */
object RoofTopologyMigration {
    fun fromProject(
        project: RoofProject,
        lockedNodeIds: Set<String> = emptySet(),
        lockedEdgeIds: Set<String> = emptySet()
    ): RoofTopology {
        val allPoints = buildList {
            addAll(project.polygon)
            project.lines.forEach { add(it.start); add(it.end) }
        }
        val origin = if (allPoints.isEmpty()) {
            GeoPoint(project.centerLat, project.centerLon)
        } else {
            Geometry.centroid(allPoints)
        }
        val nodes = mutableListOf<TopologyNode>()
        val edges = mutableListOf<TopologyEdge>()

        project.polygon.forEachIndexed { index, point ->
            val local = Geometry.toLocal(point, origin)
            val id = "footprint-node-${index.toString().padStart(4, '0')}"
            nodes += TopologyNode(id, local.x, local.y, TopologyNodeType.FOOTPRINT, id in lockedNodeIds)
        }
        if (project.polygon.size >= 2) {
            project.polygon.indices.forEach { index ->
                val id = "footprint-edge-${index.toString().padStart(4, '0')}"
                edges += TopologyEdge(
                    id = id,
                    startNodeId = "footprint-node-${index.toString().padStart(4, '0')}",
                    endNodeId = "footprint-node-${((index + 1) % project.polygon.size).toString().padStart(4, '0')}",
                    type = project.edgeTypes[index] ?: LineType.EAVE,
                    locked = id in lockedEdgeIds,
                    boundary = true,
                    sourceId = index.toString()
                )
            }
        }
        project.lines.forEachIndexed { index, line ->
            val stableLineId = line.id.ifBlank { "legacy-line-${index.toString().padStart(4, '0')}" }
            val startId = "line-$stableLineId-start"
            val endId = "line-$stableLineId-end"
            val start = Geometry.toLocal(line.start, origin)
            val end = Geometry.toLocal(line.end, origin)
            nodes += TopologyNode(startId, start.x, start.y, TopologyNodeType.LINE_ENDPOINT, startId in lockedNodeIds)
            nodes += TopologyNode(endId, end.x, end.y, TopologyNodeType.LINE_ENDPOINT, endId in lockedNodeIds)
            edges += TopologyEdge(
                id = stableLineId,
                startNodeId = startId,
                endNodeId = endId,
                type = line.type,
                locked = stableLineId in lockedEdgeIds,
                boundary = false,
                sourceId = stableLineId,
                note = line.note
            )
        }
        return RoofTopology(origin.copy(), nodes, edges)
    }

    /**
     * Writes a confirmed topology back to the legacy model. Invalid boundary
     * topology leaves the project untouched.
     */
    fun applyToProject(project: RoofProject, topology: RoofTopology): TopologyApplyResult {
        val validation = RoofTopologySolver.validate(topology)
        val boundary = orderedBoundary(topology)
        if (boundary == null) {
            return TopologyApplyResult(
                false,
                validation + TopologyIssue(
                    code = "BOUNDARY_NOT_SINGLE_CYCLE",
                    message = "Vonkajší obrys netvorí jeden uzavretý cyklus.",
                    severity = TopologyIssueSeverity.ERROR
                )
            )
        }
        if (validation.any { it.severity == TopologyIssueSeverity.ERROR }) {
            return TopologyApplyResult(false, validation)
        }
        val nodeById = topology.nodes.associateBy { it.id }
        val newPolygon = boundary.first.map { nodeId ->
            val node = requireNotNull(nodeById[nodeId])
            Geometry.toGeo(LocalPoint(node.x, node.y), topology.origin)
        }.toMutableList()
        val newEdgeTypes = boundary.second.mapIndexed { index, edge -> index to edge.type }.toMap().toMutableMap()
        val newLines = topology.edges.asSequence()
            .filterNot { it.boundary }
            .sortedBy { it.id }
            .map { edge ->
                val a = requireNotNull(nodeById[edge.startNodeId])
                val b = requireNotNull(nodeById[edge.endNodeId])
                RoofLine(
                    id = edge.id,
                    type = edge.type,
                    start = Geometry.toGeo(LocalPoint(a.x, a.y), topology.origin),
                    end = Geometry.toGeo(LocalPoint(b.x, b.y), topology.origin),
                    note = edge.note
                )
            }.toMutableList()

        project.polygon = newPolygon
        project.edgeTypes = newEdgeTypes
        project.lines = newLines
        project.updatedAt = System.currentTimeMillis()
        return TopologyApplyResult(true, validation)
    }

    private fun orderedBoundary(topology: RoofTopology): Pair<List<String>, List<TopologyEdge>>? {
        val boundaryEdges = topology.edges.filter { it.boundary }
        if (boundaryEdges.size < 3) return null
        val adjacency = mutableMapOf<String, MutableList<TopologyEdge>>()
        boundaryEdges.forEach { edge ->
            adjacency.getOrPut(edge.startNodeId) { mutableListOf() } += edge
            adjacency.getOrPut(edge.endNodeId) { mutableListOf() } += edge
        }
        if (adjacency.values.any { it.size != 2 }) return null
        val start = adjacency.keys.minOrNull() ?: return null
        val first = adjacency.getValue(start).minBy { it.id }
        val nodeIds = mutableListOf(start)
        val walkedEdges = mutableListOf<TopologyEdge>()
        var current = start
        var edge = first
        val used = mutableSetOf<String>()
        while (edge.id !in used) {
            used += edge.id
            walkedEdges += edge
            val next = if (edge.startNodeId == current) edge.endNodeId else edge.startNodeId
            if (next == start) break
            nodeIds += next
            current = next
            edge = adjacency.getValue(current).firstOrNull { it.id !in used } ?: return null
        }
        if (used.size != boundaryEdges.size || walkedEdges.lastOrNull()?.let {
                if (it.startNodeId == current) it.endNodeId else it.startNodeId
            } != start
        ) return null
        val nodeById = topology.nodes.associateBy { it.id }
        val area = signedArea(nodeIds.map { requireNotNull(nodeById[it]) })
        return if (area >= 0.0) {
            nodeIds to walkedEdges
        } else {
            val reversedEdges = walkedEdges.asReversed().let { it.drop(1) + it.first() }
            nodeIds.asReversed() to reversedEdges
        }
    }
}

object RoofTopologySolver {
    fun solve(input: RoofTopology, config: RoofSolverConfig = RoofSolverConfig()): RoofSolverPreview {
        val graph = MutableGraph(input)
        graph.mergeNearbyNodes(config)
        graph.splitAllIntersections(config)
        graph.snapFreeInternalEnds(config)
        graph.mergeNearbyNodes(config)
        graph.splitAllIntersections(config)
        graph.removeShortAndDuplicateEdges(config)
        graph.normalizeNodeTypes()
        val proposed = graph.freeze()
        val issues = validate(proposed, config) + graph.operationIssues
        return RoofSolverPreview(
            original = input.deepCopy(),
            proposed = proposed,
            statistics = graph.statistics,
            movements = graph.movements.toList(),
            issues = issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) },
            faces = extractFaces(proposed, config.intersectionEpsilon)
        )
    }

    fun validate(
        topology: RoofTopology,
        config: RoofSolverConfig = RoofSolverConfig()
    ): List<TopologyIssue> {
        val issues = mutableListOf<TopologyIssue>()
        val nodes = topology.nodes.associateBy { it.id }
        if (nodes.size != topology.nodes.size) {
            issues += error("DUPLICATE_NODE_ID", "Topológia obsahuje duplicitné ID uzla.")
        }
        if (topology.edges.map { it.id }.toSet().size != topology.edges.size) {
            issues += error("DUPLICATE_EDGE_ID", "Topológia obsahuje duplicitné ID hrany.")
        }
        topology.nodes.forEach { node ->
            if (!node.x.isFinite() || !node.y.isFinite()) {
                issues += error("NON_FINITE_NODE", "Uzol ${node.id} nemá platné súradnice.", nodes = listOf(node.id))
            }
        }
        val validEdges = topology.edges.filter { edge ->
            val a = nodes[edge.startNodeId]
            val b = nodes[edge.endNodeId]
            if (a == null || b == null) {
                issues += error(
                    "MISSING_EDGE_NODE",
                    "Hrana ${edge.id} odkazuje na neexistujúci uzol.",
                    edges = listOf(edge.id)
                )
                false
            } else {
                val length = distance(a, b)
                if (edge.startNodeId == edge.endNodeId || length <= config.minimumEdgeLengthM) {
                    issues += error(
                        "ZERO_OR_SHORT_EDGE",
                        "Hrana ${edge.id} je nulová alebo kratšia než ${formatM(config.minimumEdgeLengthM)} m.",
                        nodes = listOf(edge.startNodeId, edge.endNodeId),
                        edges = listOf(edge.id),
                        x = (a.x + b.x) / 2.0,
                        y = (a.y + b.y) / 2.0,
                        distance = length
                    )
                }
                true
            }
        }
        validEdges.groupBy { unorderedPair(it.startNodeId, it.endNodeId) }.values
            .filter { it.size > 1 }
            .forEach { duplicates ->
                issues += error(
                    "DUPLICATE_EDGE",
                    "Medzi rovnakými uzlami existuje viac hrán.",
                    nodes = listOf(duplicates.first().startNodeId, duplicates.first().endNodeId),
                    edges = duplicates.map { it.id }
                )
            }
        val sortedNodes = topology.nodes.sortedBy { it.id }
        for (i in sortedNodes.indices) for (j in i + 1 until sortedNodes.size) {
            val d = distance(sortedNodes[i], sortedNodes[j])
            if (d <= config.mergeToleranceM) {
                issues += error(
                    "NEAR_DUPLICATE_NODES",
                    "Uzly ${sortedNodes[i].id} a ${sortedNodes[j].id} sú od seba iba ${formatM(d)} m.",
                    nodes = listOf(sortedNodes[i].id, sortedNodes[j].id),
                    x = (sortedNodes[i].x + sortedNodes[j].x) / 2.0,
                    y = (sortedNodes[i].y + sortedNodes[j].y) / 2.0,
                    distance = d
                )
            }
        }
        val sortedEdges = validEdges.sortedBy { it.id }
        for (i in sortedEdges.indices) for (j in i + 1 until sortedEdges.size) {
            val first = sortedEdges[i]
            val second = sortedEdges[j]
            val a = nodes[first.startNodeId] ?: continue
            val b = nodes[first.endNodeId] ?: continue
            val c = nodes[second.startNodeId] ?: continue
            val d = nodes[second.endNodeId] ?: continue
            val hit = segmentIntersection(a, b, c, d, config.intersectionEpsilon)
            if (hit.collinearOverlap) {
                issues += error(
                    "COLLINEAR_OVERLAP",
                    "Hrany ${first.id} a ${second.id} sa nejednoznačne prekrývajú.",
                    edges = listOf(first.id, second.id)
                )
            } else if (hit.exists) {
                val shared = setOf(first.startNodeId, first.endNodeId)
                    .intersect(setOf(second.startNodeId, second.endNodeId))
                if (shared.isEmpty()) {
                    issues += error(
                        "UNSPLIT_INTERSECTION",
                        "Pretínajúce sa hrany ${first.id} a ${second.id} nemajú spoločný uzol.",
                        edges = listOf(first.id, second.id),
                        x = hit.x,
                        y = hit.y
                    )
                }
            }
        }
        val incident = mutableMapOf<String, MutableList<TopologyEdge>>()
        validEdges.forEach { edge ->
            incident.getOrPut(edge.startNodeId) { mutableListOf() } += edge
            incident.getOrPut(edge.endNodeId) { mutableListOf() } += edge
        }
        if (!config.allowFreeInternalEnds) {
            validEdges.filterNot { it.boundary }.forEach { edge ->
                listOf(edge.startNodeId, edge.endNodeId).forEach { nodeId ->
                    if (incident[nodeId]?.size == 1) {
                        val node = nodes[nodeId]
                        issues += error(
                            "FREE_INTERNAL_END",
                            "Koniec línie ${edge.type.label} nie je pripojený k inej strešnej hrane.",
                            nodes = listOf(nodeId),
                            edges = listOf(edge.id),
                            x = node?.x,
                            y = node?.y
                        )
                    }
                }
            }
        }
        val boundaryIncident = mutableMapOf<String, Int>()
        validEdges.filter { it.boundary }.forEach { edge ->
            boundaryIncident[edge.startNodeId] = (boundaryIncident[edge.startNodeId] ?: 0) + 1
            boundaryIncident[edge.endNodeId] = (boundaryIncident[edge.endNodeId] ?: 0) + 1
        }
        boundaryIncident.filterValues { it != 2 }.forEach { (nodeId, degree) ->
            issues += error(
                "OPEN_BOUNDARY",
                "Uzol obrysu $nodeId má stupeň $degree namiesto 2.",
                nodes = listOf(nodeId)
            )
        }
        val bridges = findBridges(topology)
        validEdges.filterNot { it.boundary }.filter { it.id in bridges }.forEach { edge ->
            issues += error(
                "INTERNAL_EDGE_NOT_IN_FACE",
                "Hrana ${edge.type.label} ${edge.id} nevytvára hranicu uzavretej strešnej plochy.",
                edges = listOf(edge.id),
                nodes = listOf(edge.startNodeId, edge.endNodeId)
            )
        }
        if (topology.edges.any { it.boundary } && extractFaces(topology, config.intersectionEpsilon).isEmpty()) {
            issues += error("NO_CLOSED_FACE", "Topológia neobsahuje žiadnu platnú uzavretú plochu.")
        }
        return issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) }
    }

    /** Extracts bounded planar faces. Exterior and degenerate walks are omitted. */
    fun extractFaces(topology: RoofTopology, epsilon: Double = 1e-7): List<TopologyFace> {
        val nodes = topology.nodes.associateBy { it.id }
        val edges = topology.edges.filter { nodes.containsKey(it.startNodeId) && nodes.containsKey(it.endNodeId) }
        val outgoing = mutableMapOf<String, MutableList<Pair<String, TopologyEdge>>>()
        edges.forEach { edge ->
            outgoing.getOrPut(edge.startNodeId) { mutableListOf() } += edge.endNodeId to edge
            outgoing.getOrPut(edge.endNodeId) { mutableListOf() } += edge.startNodeId to edge
        }
        outgoing.forEach { (nodeId, list) ->
            val center = requireNotNull(nodes[nodeId])
            list.sortWith(compareBy<Pair<String, TopologyEdge>> {
                val target = requireNotNull(nodes[it.first])
                atan2(target.y - center.y, target.x - center.x)
            }.thenBy { it.second.id }.thenBy { it.first })
        }
        val visited = mutableSetOf<Pair<String, String>>()
        val result = mutableListOf<TopologyFace>()
        edges.sortedBy { it.id }.forEach { seed ->
            listOf(seed.startNodeId to seed.endNodeId, seed.endNodeId to seed.startNodeId).forEach direction@{ startDirection ->
                if (startDirection in visited) return@direction
                val faceNodes = mutableListOf<String>()
                val faceEdges = mutableListOf<String>()
                var from = startDirection.first
                var to = startDirection.second
                var guard = 0
                while ((from to to) !in visited && guard++ <= edges.size * 2 + 2) {
                    visited += from to to
                    faceNodes += from
                    val options = outgoing[to] ?: break
                    val reverseIndex = options.indexOfFirst { it.first == from }
                    if (reverseIndex < 0) break
                    val usedEdge = options[reverseIndex].second
                    faceEdges += usedEdge.id
                    val next = options[(reverseIndex - 1 + options.size) % options.size]
                    from = to
                    to = next.first
                    if (from == startDirection.first && to == startDirection.second) break
                }
                if (faceNodes.size >= 3 && from == startDirection.first && to == startDirection.second) {
                    val area = signedArea(faceNodes.mapNotNull(nodes::get))
                    if (area > epsilon) {
                        result += TopologyFace(faceNodes, faceEdges, area)
                    }
                }
            }
        }
        return result.distinctBy { canonicalCycle(it.nodeIds) }.sortedBy { canonicalCycle(it.nodeIds) }
    }

    /** Pure manual operation backing the future “Spojiť do uzla” command. */
    fun mergeSelectedNodes(
        topology: RoofTopology,
        nodeIds: Set<String>,
        preferredNodeId: String? = null,
        epsilon: Double = 1e-7
    ): RoofSolverPreview {
        val graph = MutableGraph(topology)
        graph.mergeSelected(nodeIds, preferredNodeId, epsilon)
        graph.removeShortAndDuplicateEdges(RoofSolverConfig(intersectionEpsilon = epsilon))
        graph.normalizeNodeTypes()
        val proposed = graph.freeze()
        return RoofSolverPreview(
            topology.deepCopy(), proposed, graph.statistics, graph.movements,
            validate(proposed), extractFaces(proposed)
        )
    }

    /** Pure manual operation backing the future “Rozpojiť uzol” command. */
    fun disconnectNode(topology: RoofTopology, nodeId: String): RoofTopology {
        val graph = MutableGraph(topology)
        graph.disconnect(nodeId)
        graph.normalizeNodeTypes()
        return graph.freeze()
    }

    /** Pure edge split; returns the original topology when the point is not on the edge. */
    fun splitEdge(
        topology: RoofTopology,
        edgeId: String,
        x: Double,
        y: Double,
        toleranceM: Double = 0.05
    ): RoofTopology {
        val graph = MutableGraph(topology)
        graph.splitEdgeAt(edgeId, x, y, toleranceM)
        graph.normalizeNodeTypes()
        return graph.freeze()
    }

    private class MutableGraph(topology: RoofTopology) {
        val nodes = linkedMapOf<String, TopologyNode>()
        val edges = linkedMapOf<String, TopologyEdge>()
        val movements = mutableListOf<NodeMovement>()
        val operationIssues = mutableListOf<TopologyIssue>()
        var statistics = RoofSolverStatistics()
        private val origin = topology.origin.copy()
        private var generatedNodeCounter = 0

        init {
            topology.nodes.sortedBy { it.id }.forEach { nodes[it.id] = it.copy() }
            topology.edges.sortedBy { it.id }.forEach { edges[it.id] = it.copy() }
        }

        fun freeze() = RoofTopology(origin.copy(), nodes.values.toList(), edges.values.toList())

        fun mergeNearbyNodes(config: RoofSolverConfig) {
            val candidates = mutableListOf<Triple<Double, String, String>>()
            val list = nodes.values.sortedBy { it.id }
            for (i in list.indices) for (j in i + 1 until list.size) {
                val d = distance(list[i], list[j])
                if (d <= config.mergeToleranceM) candidates += Triple(d, list[i].id, list[j].id)
            }
            candidates.sortWith(compareBy<Triple<Double, String, String>> { it.first }
                .thenBy { it.second }.thenBy { it.third })
            val clusters = list.associate { it.id to mutableSetOf(it.id) }.toMutableMap()
            fun rootOf(id: String): String = clusters.entries.first { id in it.value }.key
            candidates.forEach { (_, aId, bId) ->
                val aRoot = rootOf(aId)
                val bRoot = rootOf(bId)
                if (aRoot == bRoot) return@forEach
                val merged = (clusters.getValue(aRoot) + clusters.getValue(bRoot)).toSet()
                val members = merged.mapNotNull(nodes::get)
                val locked = members.filter { it.locked }
                if (locked.size > 1 && locked.any { distance(it, locked.first()) > config.intersectionEpsilon }) {
                    return@forEach
                }
                var diameter = 0.0
                for (i in members.indices) for (j in i + 1 until members.size) {
                    diameter = max(diameter, distance(members[i], members[j]))
                }
                if (diameter > config.mergeToleranceM) return@forEach
                val keep = minOf(aRoot, bRoot)
                val remove = maxOf(aRoot, bRoot)
                clusters[keep] = merged.toMutableSet()
                clusters.remove(remove)
            }
            clusters.values.filter { it.size > 1 }.sortedBy { it.minOrNull() }.forEach { ids ->
                mergeCluster(ids)
            }
            removeShortAndDuplicateEdges(config)
        }

        private fun mergeCluster(
            ids: Set<String>,
            forcedTargetId: String? = null,
            forcedX: Double? = null,
            forcedY: Double? = null
        ) {
            val members = ids.mapNotNull(nodes::get).sortedBy { it.id }
            if (members.size < 2) return
            val locked = members.firstOrNull { it.locked }
            val targetId = forcedTargetId?.takeIf { id -> members.any { it.id == id } }
                ?: locked?.id ?: members.first().id
            val targetX = forcedX ?: locked?.x ?: members.map { it.x }.average()
            val targetY = forcedY ?: locked?.y ?: members.map { it.y }.average()
            val targetType = members.maxBy { nodeTypePriority(it.type) }.type
            val targetWasLocked = members.first { it.id == targetId }.locked
            val target = TopologyNode(targetId, targetX, targetY, targetType, targetWasLocked || locked != null)
            members.forEach { node ->
                if (node.id != targetId || distance(node.x, node.y, targetX, targetY) > 0.0) {
                    movements += NodeMovement(node.id, targetId, node.x, node.y, targetX, targetY, "MERGE")
                }
            }
            ids.forEach { nodes.remove(it) }
            nodes[targetId] = target
            edges.replaceAll { _, edge ->
                edge.copy(
                    startNodeId = if (edge.startNodeId in ids) targetId else edge.startNodeId,
                    endNodeId = if (edge.endNodeId in ids) targetId else edge.endNodeId
                )
            }
            statistics = statistics.copy(mergedNodes = statistics.mergedNodes + members.size - 1)
        }

        fun splitAllIntersections(config: RoofSolverConfig) {
            val snapshot = edges.values.sortedBy { it.id }
            val cuts = snapshot.associate { it.id to mutableListOf(0.0 to it.startNodeId, 1.0 to it.endNodeId) }.toMutableMap()
            for (i in snapshot.indices) for (j in i + 1 until snapshot.size) {
                val first = snapshot[i]
                val second = snapshot[j]
                val a = nodes[first.startNodeId] ?: continue
                val b = nodes[first.endNodeId] ?: continue
                val c = nodes[second.startNodeId] ?: continue
                val d = nodes[second.endNodeId] ?: continue
                val hit = segmentIntersection(a, b, c, d, config.intersectionEpsilon)
                if (hit.collinearOverlap) continue
                if (!hit.exists) continue
                val firstNode = endpointNode(first, hit.t, config.intersectionEpsilon)
                val secondNode = endpointNode(second, hit.u, config.intersectionEpsilon)
                val sharedNodeId = when {
                    firstNode != null && secondNode != null -> {
                        if (firstNode != secondNode) {
                            val firstValue = nodes[firstNode]
                            val secondValue = nodes[secondNode]
                            if (firstValue != null && secondValue != null &&
                                distance(firstValue, secondValue) <= config.mergeToleranceM
                            ) {
                                if (firstValue.locked && secondValue.locked &&
                                    distance(firstValue, secondValue) > config.intersectionEpsilon
                                ) continue
                                mergeCluster(setOf(firstNode, secondNode))
                                if (nodes.containsKey(firstNode)) firstNode else secondNode
                            } else continue
                        } else firstNode
                    }
                    firstNode != null -> firstNode
                    secondNode != null -> secondNode
                    else -> ensureIntersectionNode(hit.x, hit.y, config.intersectionEpsilon)
                }
                cuts[first.id]?.add(hit.t.coerceIn(0.0, 1.0) to sharedNodeId)
                cuts[second.id]?.add(hit.u.coerceIn(0.0, 1.0) to sharedNodeId)
            }
            snapshot.forEach { original ->
                val raw = cuts[original.id].orEmpty().sortedWith(compareBy<Pair<Double, String>> { it.first }.thenBy { it.second })
                val unique = mutableListOf<Pair<Double, String>>()
                raw.forEach { cut ->
                    if (unique.isEmpty() || abs(cut.first - unique.last().first) > config.intersectionEpsilon) {
                        unique += cut
                    } else if (cut.second < unique.last().second) {
                        unique[unique.lastIndex] = cut
                    }
                }
                if (unique.size <= 2) return@forEach
                edges.remove(original.id)
                unique.zipWithNext().forEachIndexed { index, (from, to) ->
                    if (from.second == to.second) return@forEachIndexed
                    val id = segmentId(original.id, index, unique.size - 1)
                    edges[id] = original.copy(id = id, startNodeId = from.second, endNodeId = to.second)
                }
                statistics = statistics.copy(splitEdges = statistics.splitEdges + unique.size - 2)
            }
        }

        private fun endpointNode(edge: TopologyEdge, t: Double, epsilon: Double): String? = when {
            t <= epsilon -> edge.startNodeId
            t >= 1.0 - epsilon -> edge.endNodeId
            else -> null
        }

        private fun ensureIntersectionNode(x: Double, y: Double, epsilon: Double): String {
            nodes.values.firstOrNull { distance(it.x, it.y, x, y) <= epsilon }?.let { return it.id }
            val id = nextNodeId("intersection")
            nodes[id] = TopologyNode(id, x, y, TopologyNodeType.INTERSECTION)
            statistics = statistics.copy(createdIntersections = statistics.createdIntersections + 1)
            return id
        }

        fun snapFreeInternalEnds(config: RoofSolverConfig) {
            val endpoints = edges.values.filterNot { it.boundary }.flatMap { edge ->
                listOf(edge.id to edge.startNodeId, edge.id to edge.endNodeId)
            }.sortedWith(compareBy<Pair<String, String>> { it.second }.thenBy { it.first })
            endpoints.forEach { (edgeId, nodeId) ->
                val edge = edges[edgeId] ?: return@forEach
                val degree = edges.values.count { it.startNodeId == nodeId || it.endNodeId == nodeId }
                if (degree != 1) return@forEach
                val node = nodes[nodeId] ?: return@forEach
                val otherId = if (edge.startNodeId == nodeId) edge.endNodeId else edge.startNodeId
                val nodeCandidate = nodes.values.asSequence()
                    .filter { it.id != nodeId && it.id != otherId }
                    .map { it to distance(node, it) }
                    .filter { it.second <= config.snapToleranceM }
                    .sortedWith(compareBy<Pair<TopologyNode, Double>> { it.second }.thenBy { it.first.id })
                    .firstOrNull()
                val edgeCandidate = edges.values.asSequence()
                    .filter { it.id != edgeId && it.startNodeId != nodeId && it.endNodeId != nodeId }
                    .mapNotNull { candidate ->
                        val a = nodes[candidate.startNodeId] ?: return@mapNotNull null
                        val b = nodes[candidate.endNodeId] ?: return@mapNotNull null
                        val projection = projectToSegment(node.x, node.y, a, b)
                        if (projection.t <= config.intersectionEpsilon || projection.t >= 1.0 - config.intersectionEpsilon) null
                        else Triple(candidate, projection, hypot(node.x - projection.x, node.y - projection.y))
                    }
                    .filter { it.third <= config.snapToleranceM }
                    .sortedWith(compareBy<Triple<TopologyEdge, Projection, Double>> { it.third }.thenBy { it.first.id })
                    .firstOrNull()
                val useNode = nodeCandidate != null && (edgeCandidate == null || nodeCandidate.second <= edgeCandidate.third)
                if (node.locked) {
                    if (nodeCandidate != null || edgeCandidate != null) {
                        operationIssues += TopologyIssue(
                            "LOCKED_FREE_END",
                            "Uzamknutý koniec ${edge.type.label} sa nepresunul.",
                            TopologyIssueSeverity.WARNING,
                            nodeIds = listOf(node.id), edgeIds = listOf(edge.id), x = node.x, y = node.y
                        )
                    }
                    return@forEach
                }
                if (useNode) {
                    val target = nodeCandidate!!.first
                    rewireEndpoint(edgeId, nodeId, target.id)
                    nodes.remove(nodeId)
                    movements += NodeMovement(nodeId, target.id, node.x, node.y, target.x, target.y, "SNAP_TO_NODE")
                    statistics = statistics.copy(snappedFreeEnds = statistics.snappedFreeEnds + 1)
                } else if (edgeCandidate != null) {
                    val targetEdge = edgeCandidate.first
                    val p = edgeCandidate.second
                    val junctionId = nextNodeId("junction")
                    nodes[junctionId] = TopologyNode(junctionId, p.x, p.y, TopologyNodeType.JUNCTION)
                    rewireEndpoint(edgeId, nodeId, junctionId)
                    nodes.remove(nodeId)
                    splitExistingEdge(targetEdge.id, junctionId)
                    movements += NodeMovement(nodeId, junctionId, node.x, node.y, p.x, p.y, "SNAP_TO_EDGE")
                    statistics = statistics.copy(
                        snappedFreeEnds = statistics.snappedFreeEnds + 1,
                        splitEdges = statistics.splitEdges + 1
                    )
                }
            }
        }

        private fun rewireEndpoint(edgeId: String, oldNodeId: String, newNodeId: String) {
            val edge = edges[edgeId] ?: return
            edges[edgeId] = edge.copy(
                startNodeId = if (edge.startNodeId == oldNodeId) newNodeId else edge.startNodeId,
                endNodeId = if (edge.endNodeId == oldNodeId) newNodeId else edge.endNodeId
            )
        }

        private fun splitExistingEdge(edgeId: String, nodeId: String) {
            val edge = edges.remove(edgeId) ?: return
            edges[segmentId(edgeId, 0, 2)] = edge.copy(
                id = segmentId(edgeId, 0, 2), endNodeId = nodeId
            )
            edges[segmentId(edgeId, 1, 2)] = edge.copy(
                id = segmentId(edgeId, 1, 2), startNodeId = nodeId
            )
        }

        fun removeShortAndDuplicateEdges(config: RoofSolverConfig) {
            var short = 0
            edges.values.toList().forEach { edge ->
                val a = nodes[edge.startNodeId]
                val b = nodes[edge.endNodeId]
                if (a == null || b == null || edge.startNodeId == edge.endNodeId || distance(a, b) <= config.minimumEdgeLengthM) {
                    edges.remove(edge.id)
                    short++
                }
            }
            var duplicates = 0
            edges.values.groupBy { unorderedPair(it.startNodeId, it.endNodeId) }.values.forEach { group ->
                if (group.size > 1) {
                    val keep = group.sortedWith(compareByDescending<TopologyEdge> { it.locked }
                        .thenByDescending { it.boundary }.thenBy { it.id }).first()
                    group.filter { it.id != keep.id }.forEach { edges.remove(it.id); duplicates++ }
                }
            }
            val usedNodes = edges.values.flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
            nodes.keys.toList().filter { it !in usedNodes }.forEach(nodes::remove)
            statistics = statistics.copy(
                removedShortEdges = statistics.removedShortEdges + short,
                removedDuplicateEdges = statistics.removedDuplicateEdges + duplicates
            )
        }

        fun normalizeNodeTypes() {
            val incident = nodes.keys.associateWith { id ->
                edges.values.filter { it.startNodeId == id || it.endNodeId == id }
            }
            nodes.replaceAll { id, node ->
                val at = incident[id].orEmpty()
                val type = when {
                    at.any { it.boundary } -> TopologyNodeType.FOOTPRINT
                    at.size > 2 -> TopologyNodeType.JUNCTION
                    node.type == TopologyNodeType.INTERSECTION -> TopologyNodeType.INTERSECTION
                    else -> TopologyNodeType.LINE_ENDPOINT
                }
                node.copy(type = type)
            }
        }

        fun mergeSelected(ids: Set<String>, preferred: String?, epsilon: Double) {
            val members = ids.mapNotNull(nodes::get).sortedBy { it.id }
            if (members.size < 2) return
            val locked = members.filter { it.locked }
            if (locked.size > 1 && locked.any { distance(it, locked.first()) > epsilon }) {
                operationIssues += error(
                    "LOCKED_NODES_CONFLICT",
                    "Dva uzamknuté body s rozdielnou polohou nemožno zlúčiť.",
                    nodes = locked.map { it.id }
                )
                return
            }
            val chosen = locked.firstOrNull()
                ?: preferred?.takeIf { it in ids }?.let(nodes::get)
            val targetId = chosen?.id ?: members.first().id
            val x = chosen?.x ?: members.map { it.x }.average()
            val y = chosen?.y ?: members.map { it.y }.average()
            mergeCluster(ids, forcedTargetId = targetId, forcedX = x, forcedY = y)
        }

        fun disconnect(nodeId: String) {
            val node = nodes[nodeId] ?: return
            val incident = edges.values.filter { it.startNodeId == nodeId || it.endNodeId == nodeId }.sortedBy { it.id }
            incident.drop(1).forEachIndexed { index, edge ->
                val newId = uniqueId("$nodeId-disconnected-${(index + 1).toString().padStart(2, '0')}", nodes.keys)
                nodes[newId] = node.copy(id = newId, type = TopologyNodeType.LINE_ENDPOINT, locked = false)
                edges[edge.id] = edge.copy(
                    startNodeId = if (edge.startNodeId == nodeId) newId else edge.startNodeId,
                    endNodeId = if (edge.endNodeId == nodeId) newId else edge.endNodeId
                )
            }
        }

        fun splitEdgeAt(edgeId: String, x: Double, y: Double, toleranceM: Double) {
            val edge = edges[edgeId] ?: return
            val a = nodes[edge.startNodeId] ?: return
            val b = nodes[edge.endNodeId] ?: return
            val p = projectToSegment(x, y, a, b)
            if (p.t <= 1e-7 || p.t >= 1.0 - 1e-7 || hypot(x - p.x, y - p.y) > toleranceM) return
            val nodeId = nextNodeId("manual-split")
            nodes[nodeId] = TopologyNode(nodeId, p.x, p.y, TopologyNodeType.JUNCTION)
            splitExistingEdge(edge.id, nodeId)
            statistics = statistics.copy(splitEdges = statistics.splitEdges + 1)
        }

        private fun nextNodeId(kind: String): String {
            while (true) {
                generatedNodeCounter++
                val id = "topology-$kind-${generatedNodeCounter.toString().padStart(6, '0')}"
                if (id !in nodes) return id
            }
        }

        private fun segmentId(base: String, index: Int, total: Int): String {
            if (total == 1 && base !in edges) return base
            return uniqueId("$base-segment-${(index + 1).toString().padStart(3, '0')}", edges.keys)
        }
    }

    private data class Projection(val x: Double, val y: Double, val t: Double)

    private data class SegmentHit(
        val exists: Boolean,
        val x: Double = Double.NaN,
        val y: Double = Double.NaN,
        val t: Double = Double.NaN,
        val u: Double = Double.NaN,
        val collinearOverlap: Boolean = false
    )

    private fun segmentIntersection(
        a: TopologyNode,
        b: TopologyNode,
        c: TopologyNode,
        d: TopologyNode,
        epsilon: Double
    ): SegmentHit {
        val rx = b.x - a.x
        val ry = b.y - a.y
        val sx = d.x - c.x
        val sy = d.y - c.y
        val denominator = cross(rx, ry, sx, sy)
        val qpx = c.x - a.x
        val qpy = c.y - a.y
        if (abs(denominator) <= epsilon) {
            if (abs(cross(qpx, qpy, rx, ry)) > epsilon) return SegmentHit(false)
            val rr = rx * rx + ry * ry
            if (rr <= epsilon * epsilon) return SegmentHit(false)
            val t0 = (qpx * rx + qpy * ry) / rr
            val t1 = t0 + (sx * rx + sy * ry) / rr
            val overlapStart = max(0.0, min(t0, t1))
            val overlapEnd = min(1.0, max(t0, t1))
            return SegmentHit(false, collinearOverlap = overlapEnd - overlapStart > epsilon)
        }
        val t = cross(qpx, qpy, sx, sy) / denominator
        val u = cross(qpx, qpy, rx, ry) / denominator
        if (t < -epsilon || t > 1.0 + epsilon || u < -epsilon || u > 1.0 + epsilon) return SegmentHit(false)
        return SegmentHit(true, a.x + t * rx, a.y + t * ry, t, u)
    }

    private fun projectToSegment(x: Double, y: Double, a: TopologyNode, b: TopologyNode): Projection {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val length2 = dx * dx + dy * dy
        if (length2 <= 1e-20) return Projection(a.x, a.y, 0.0)
        val t = (((x - a.x) * dx + (y - a.y) * dy) / length2).coerceIn(0.0, 1.0)
        return Projection(a.x + t * dx, a.y + t * dy, t)
    }

    private fun findBridges(topology: RoofTopology): Set<String> {
        val adjacency = mutableMapOf<String, MutableList<Pair<String, String>>>()
        topology.edges.forEach { edge ->
            adjacency.getOrPut(edge.startNodeId) { mutableListOf() } += edge.endNodeId to edge.id
            adjacency.getOrPut(edge.endNodeId) { mutableListOf() } += edge.startNodeId to edge.id
        }
        val discovery = mutableMapOf<String, Int>()
        val low = mutableMapOf<String, Int>()
        val bridges = mutableSetOf<String>()
        var time = 0
        fun visit(node: String, parentEdge: String?) {
            discovery[node] = ++time
            low[node] = time
            adjacency[node].orEmpty().sortedWith(compareBy<Pair<String, String>> { it.second }.thenBy { it.first })
                .forEach { (next, edgeId) ->
                    if (edgeId == parentEdge) return@forEach
                    if (next !in discovery) {
                        visit(next, edgeId)
                        low[node] = min(low.getValue(node), low.getValue(next))
                        if (low.getValue(next) > discovery.getValue(node)) bridges += edgeId
                    } else {
                        low[node] = min(low.getValue(node), discovery.getValue(next))
                    }
                }
        }
        adjacency.keys.sorted().forEach { if (it !in discovery) visit(it, null) }
        return bridges
    }

    private fun error(
        code: String,
        message: String,
        nodes: List<String> = emptyList(),
        edges: List<String> = emptyList(),
        x: Double? = null,
        y: Double? = null,
        distance: Double? = null
    ) = TopologyIssue(code, message, TopologyIssueSeverity.ERROR, nodes, edges, x, y, distance)
}

private fun RoofTopology.deepCopy() = RoofTopology(
    origin = origin.copy(),
    nodes = nodes.map { it.copy() },
    edges = edges.map { it.copy() },
    schemaVersion = schemaVersion
)

private fun distance(a: TopologyNode, b: TopologyNode): Double = hypot(a.x - b.x, a.y - b.y)
private fun distance(ax: Double, ay: Double, bx: Double, by: Double): Double = hypot(ax - bx, ay - by)
private fun cross(ax: Double, ay: Double, bx: Double, by: Double): Double = ax * by - ay * bx
private fun unorderedPair(a: String, b: String) = if (a <= b) a to b else b to a
private fun nodeTypePriority(type: TopologyNodeType): Int = when (type) {
    TopologyNodeType.FOOTPRINT -> 4
    TopologyNodeType.INTERSECTION -> 3
    TopologyNodeType.JUNCTION -> 2
    TopologyNodeType.LINE_ENDPOINT -> 1
}

private fun signedArea(nodes: List<TopologyNode>): Double {
    if (nodes.size < 3) return 0.0
    return nodes.indices.sumOf { index ->
        val next = (index + 1) % nodes.size
        nodes[index].x * nodes[next].y - nodes[next].x * nodes[index].y
    } / 2.0
}

private fun canonicalCycle(ids: List<String>): String {
    if (ids.isEmpty()) return ""
    fun rotations(values: List<String>) = values.indices.map { shift ->
        values.indices.joinToString("|") { values[(it + shift) % values.size] }
    }
    return (rotations(ids) + rotations(ids.asReversed())).minOrNull().orEmpty()
}

private fun uniqueId(base: String, existing: Collection<String>): String {
    if (base !in existing) return base
    var suffix = 2
    while ("$base-$suffix" in existing) suffix++
    return "$base-$suffix"
}

private fun formatM(value: Double): String = "%.3f".format(java.util.Locale.US, value)
