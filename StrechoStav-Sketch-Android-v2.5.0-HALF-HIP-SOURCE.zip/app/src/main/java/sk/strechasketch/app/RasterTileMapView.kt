package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.LruCache
import android.view.View
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Raster map renderer with a retained active layer and a separately prepared layer.
 *
 * The view deliberately does not own roof geometry.  Moving a roof point therefore
 * invalidates only the transparent editor above this view, while viewport changes are
 * batched through [requestRender].
 */
@SuppressLint("ViewConstructor")
class RasterTileMapView(
    context: Context,
    private val project: RoofProject
) : View(context) {
    var onStatusChanged: ((String) -> Unit)? = null

    private enum class Provider(
        val id: String,
        val sourceMaxZoom: Int,
        val label: String,
        val attribution: String
    ) {
        ZBGIS_ORTHO(
            "zbgis-ortho",
            21,
            "ZBGIS ortofoto",
            "Ortofoto © GKÚ Bratislava, CC BY 4.0"
        ),
        OSM(
            "osm",
            19,
            "OpenStreetMap",
            "© OpenStreetMap prispievatelia"
        ),
        OSM_TERRAIN(
            "osm-terrain",
            17,
            "OSM terén",
            "© OpenStreetMap prispievatelia | štýl © OpenTopoMap"
        )
    }

    private data class TileKey(
        val provider: Provider,
        val zoom: Int,
        val x: Int,
        val y: Int
    ) {
        val cacheKey: String get() = "${provider.id}/$zoom/$x/$y"
    }

    private data class TilePlacement(
        val rawX: Int,
        val y: Int,
        val key: TileKey
    )

    private data class LayerSignature(
        val provider: Provider,
        val sourceZoom: Int,
        val displayZoom: Int,
        val firstX: Int,
        val lastX: Int,
        val firstY: Int,
        val lastY: Int
    )

    private class RenderLayer(
        val signature: LayerSignature,
        val placements: List<TilePlacement>
    ) {
        val keys: Set<TileKey> = placements.mapTo(linkedSetOf()) { it.key }
        val bitmaps: MutableMap<TileKey, Bitmap> = linkedMapOf()
    }

    private class RequestHandle {
        @Volatile var future: Future<*>? = null
        @Volatile var connection: HttpURLConnection? = null
        @Volatile var cancelled: Boolean = false
    }

    private val executor = Executors.newFixedThreadPool(4)
    private val memoryCache = object : LruCache<String, Bitmap>(MEMORY_CACHE_KB) {
        override fun sizeOf(key: String, value: Bitmap): Int = max(1, value.byteCount / 1024)
    }
    private val inFlight = ConcurrentHashMap<TileKey, RequestHandle>()
    private val failedUntil = ConcurrentHashMap<TileKey, Long>()
    private val requestLock = Any()
    private val cacheDir = File(context.cacheDir, "strechostav-map-tiles-v2").apply { mkdirs() }

    // No filtering is intentional: digital zoom must stay sharp rather than blurred.
    private val bitmapPaint = Paint().apply {
        isAntiAlias = false
        isFilterBitmap = false
        isDither = false
    }
    private val placeholderPaint = Paint().apply {
        color = Color.rgb(238, 236, 226)
        style = Paint.Style.FILL
    }
    private val attributionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = 10f * resources.displayMetrics.scaledDensity
    }
    private val chromePaint = Paint()

    private var activeLayer: RenderLayer? = null
    private var preparingLayer: RenderLayer? = null
    private val renderPosted = AtomicBoolean(false)
    private var lastLoadedProvider: Provider? = null
    private var lastErrorAt = 0L

    init {
        setBackgroundColor(Color.rgb(238, 236, 226))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        renderPosted.set(false)
        if (width <= 0 || height <= 0 || project.mapType == "DOCUMENT") return

        val target = createTargetLayer()
        ensureTarget(target)
        hydrateFromMemory(activeLayer)
        hydrateFromMemory(preparingLayer)

        canvas.save()
        canvas.rotate(project.mapRotationDeg.toFloat(), width / 2f, height / 2f)
        val active = activeLayer
        if (active != null) {
            drawLayer(canvas, active)
            preparingLayer?.takeIf(::isReadyToReveal)?.let { drawLayer(canvas, it) }
        } else {
            // First launch has no retained layer yet; reveal cached/downloaded tiles progressively.
            preparingLayer?.let { drawLayer(canvas, it, drawMissingPlaceholders = true) }
        }
        canvas.restore()

        val preparing = preparingLayer
        if (preparing != null && isComplete(preparing)) {
            activeLayer = preparing
            preparingLayer = null
            cancelRequestsNoLongerNeeded()
            announceLoaded(preparing.signature.provider)
        }
        drawAttribution(canvas, activeLayer?.signature?.provider ?: target.signature.provider)
    }

    /** Coalesces repeated viewport callbacks into one draw on the next display frame. */
    fun requestRender() {
        if (!renderPosted.compareAndSet(false, true)) return
        postInvalidateOnAnimation()
    }

    fun clearMemoryCache() {
        memoryCache.evictAll()
        // Retained layers own their Bitmap references and remain visible until replacement is ready.
    }

    fun resetLayers() {
        preparingLayer = null
        cancelRequestsNoLongerNeeded()
        requestRender()
    }

    fun shutdown() {
        inFlight.values.forEach(::cancelRequest)
        inFlight.clear()
        executor.shutdownNow()
        activeLayer = null
        preparingLayer = null
        memoryCache.evictAll()
    }

    private fun createTargetLayer(): RenderLayer {
        val provider = normalizedProvider(project.mapType)
        val displayZoom = project.zoom.coerceIn(MIN_ZOOM, provider.sourceMaxZoom + DIGITAL_ZOOM_LEVELS)
        val sourceZoom = min(displayZoom, provider.sourceMaxZoom)
        val displayScale = 2.0.pow((displayZoom - sourceZoom).toDouble())
        val centerX = Geometry.worldX(project.centerLon, sourceZoom)
        val centerY = Geometry.worldY(project.centerLat, sourceZoom)
        val angle = Math.toRadians(project.mapRotationDeg)
        val halfWidthAtSource = (abs(cos(angle)) * width / 2.0 + abs(sin(angle)) * height / 2.0) / displayScale
        val halfHeightAtSource = (abs(sin(angle)) * width / 2.0 + abs(cos(angle)) * height / 2.0) / displayScale
        val firstX = floor((centerX - halfWidthAtSource) / TILE_SIZE).toInt() - RETAINED_MARGIN_TILES
        val lastX = floor((centerX + halfWidthAtSource) / TILE_SIZE).toInt() + RETAINED_MARGIN_TILES
        val firstY = floor((centerY - halfHeightAtSource) / TILE_SIZE).toInt() - RETAINED_MARGIN_TILES
        val lastY = floor((centerY + halfHeightAtSource) / TILE_SIZE).toInt() + RETAINED_MARGIN_TILES
        val tileCount = 1 shl sourceZoom
        val clampedFirstY = max(0, firstY)
        val clampedLastY = min(tileCount - 1, lastY)
        val signature = LayerSignature(
            provider,
            sourceZoom,
            displayZoom,
            firstX,
            lastX,
            clampedFirstY,
            clampedLastY
        )
        val placements = buildList {
            if (clampedFirstY <= clampedLastY) {
                for (rawX in firstX..lastX) {
                    val tileX = floorMod(rawX, tileCount)
                    for (tileY in clampedFirstY..clampedLastY) {
                        add(TilePlacement(rawX, tileY, TileKey(provider, sourceZoom, tileX, tileY)))
                    }
                }
            }
        }
        return RenderLayer(signature, placements)
    }

    private fun ensureTarget(target: RenderLayer) {
        if (activeLayer?.signature == target.signature) {
            preparingLayer = null
            requestMissing(activeLayer!!)
            cancelRequestsNoLongerNeeded()
            return
        }
        if (preparingLayer?.signature != target.signature) {
            preparingLayer = target
        }
        hydrateFromMemory(preparingLayer)
        requestMissing(preparingLayer!!)
        cancelRequestsNoLongerNeeded()
    }

    private fun hydrateFromMemory(layer: RenderLayer?) {
        layer ?: return
        layer.keys.forEach { key ->
            if (layer.bitmaps.containsKey(key)) return@forEach
            memoryCache.get(key.cacheKey)?.takeUnless(Bitmap::isRecycled)?.let { layer.bitmaps[key] = it }
        }
    }

    private fun requestMissing(layer: RenderLayer) {
        val now = System.currentTimeMillis()
        layer.keys.forEach { key ->
            if (!layer.bitmaps.containsKey(key) && (failedUntil[key] ?: 0L) <= now) {
                requestTile(key)
            }
        }
    }

    private fun isReadyToReveal(layer: RenderLayer): Boolean {
        if (layer.keys.isEmpty()) return true
        val loaded = layer.keys.count { layer.bitmaps.containsKey(it) }
        return loaded.toDouble() / layer.keys.size.toDouble() >= READY_FRACTION
    }

    private fun isComplete(layer: RenderLayer): Boolean =
        layer.keys.all { layer.bitmaps.containsKey(it) }

    private fun drawLayer(
        canvas: Canvas,
        layer: RenderLayer,
        drawMissingPlaceholders: Boolean = false
    ) {
        val displayZoom = project.zoom.coerceIn(MIN_ZOOM, MAX_SAFE_DISPLAY_ZOOM)
        val scale = 2.0.pow((displayZoom - layer.signature.sourceZoom).toDouble())
        val centerX = Geometry.worldX(project.centerLon, layer.signature.sourceZoom)
        val centerY = Geometry.worldY(project.centerLat, layer.signature.sourceZoom)
        val tileDisplaySize = TILE_SIZE * scale

        layer.placements.forEach { placement ->
            val leftExact = (placement.rawX * TILE_SIZE - centerX) * scale + width / 2.0
            val topExact = (placement.y * TILE_SIZE - centerY) * scale + height / 2.0
            val rightExact = leftExact + tileDisplaySize
            val bottomExact = topExact + tileDisplaySize
            // Round every shared boundary consistently, then overlap right/bottom by one pixel.
            val destination = RectF(
                leftExact.roundToInt().toFloat(),
                topExact.roundToInt().toFloat(),
                rightExact.roundToInt() + TILE_OVERLAP_PX,
                bottomExact.roundToInt() + TILE_OVERLAP_PX
            )
            val bitmap = layer.bitmaps[placement.key]
            if (bitmap != null && !bitmap.isRecycled) {
                canvas.drawBitmap(bitmap, null, destination, bitmapPaint)
            } else if (drawMissingPlaceholders) {
                canvas.drawRect(destination, placeholderPaint)
            }
        }
    }

    private fun requestTile(key: TileKey) {
        synchronized(requestLock) {
            if (inFlight.containsKey(key)) return
            val handle = RequestHandle()
            inFlight[key] = handle
            handle.future = executor.submit {
                try {
                    if (handle.cancelled || Thread.currentThread().isInterrupted) return@submit
                    val file = tileFile(key)
                    val bitmap = loadDiskBitmap(file) ?: download(key, file, handle)
                        ?: error("Server neposlal obrazovú dlaždicu.")
                    if (!handle.cancelled && !Thread.currentThread().isInterrupted) {
                        memoryCache.put(key.cacheKey, bitmap)
                        failedUntil.remove(key)
                        requestRender()
                    }
                } catch (error: Exception) {
                    if (!handle.cancelled) {
                        failedUntil[key] = System.currentTimeMillis() + FAILED_RETRY_MS
                        reportLoadError(error)
                        requestRender()
                        postDelayed(::requestRender, FAILED_RETRY_MS)
                    }
                } finally {
                    handle.connection = null
                    inFlight.remove(key, handle)
                }
            }
        }
    }

    private fun loadDiskBitmap(file: File): Bitmap? {
        if (!file.isFile || System.currentTimeMillis() - file.lastModified() >= CACHE_TTL_MS) return null
        return BitmapFactory.decodeFile(file.absolutePath)
    }

    private fun download(key: TileKey, target: File, handle: RequestHandle): Bitmap? {
        val connection = URI(tileUrl(key)).toURL().openConnection() as HttpURLConnection
        handle.connection = connection
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept", "image/png,image/jpeg,image/*")
        return try {
            val code = connection.responseCode
            require(code in 200..299) { "mapová služba odpovedala kódom $code" }
            val bytes = connection.inputStream.use { it.readBytes() }
            if (handle.cancelled || Thread.currentThread().isInterrupted) return null
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: error("neplatný formát dlaždice")
            writeDiskCacheAtomically(target, bytes)
            bitmap
        } finally {
            connection.disconnect()
            handle.connection = null
        }
    }

    private fun writeDiskCacheAtomically(target: File, bytes: ByteArray) {
        runCatching {
            target.parentFile?.mkdirs()
            val temporary = File(target.parentFile, "${target.name}.part")
            temporary.writeBytes(bytes)
            if (!temporary.renameTo(target)) {
                target.writeBytes(bytes)
                temporary.delete()
            }
        }
    }

    private fun tileFile(key: TileKey): File =
        File(cacheDir, "${key.provider.id}/${key.zoom}/${key.x}/${key.y}.tile")

    private fun cancelRequestsNoLongerNeeded() {
        val needed = buildSet {
            activeLayer?.keys?.let(::addAll)
            preparingLayer?.keys?.let(::addAll)
        }
        inFlight.entries.forEach { (key, handle) ->
            if (key !in needed && inFlight.remove(key, handle)) cancelRequest(handle)
        }
    }

    private fun cancelRequest(handle: RequestHandle) {
        handle.cancelled = true
        handle.connection?.disconnect()
        handle.future?.cancel(true)
    }

    private fun announceLoaded(provider: Provider) {
        if (lastLoadedProvider == provider) return
        lastLoadedProvider = provider
        post {
            onStatusChanged?.invoke(
                "${provider.label} je načítaná. Viditeľná plocha sa skladá z dlaždíc uložených v cache."
            )
        }
    }

    private fun reportLoadError(error: Exception) {
        val now = System.currentTimeMillis()
        if (now - lastErrorAt <= ERROR_MESSAGE_THROTTLE_MS) return
        lastErrorAt = now
        post { onStatusChanged?.invoke("Mapový podklad sa nenačítal: ${error.message}") }
    }

    private fun tileUrl(key: TileKey): String = when (key.provider) {
        Provider.OSM -> "https://tile.openstreetmap.org/${key.zoom}/${key.x}/${key.y}.png"
        Provider.OSM_TERRAIN -> "https://a.tile.opentopomap.org/${key.zoom}/${key.x}/${key.y}.png"
        Provider.ZBGIS_ORTHO -> zbgisWmsUrl(key.zoom, key.x, key.y)
    }

    private fun zbgisWmsUrl(zoom: Int, x: Int, y: Int): String {
        val world = 20_037_508.342789244
        val resolution = 2.0 * world / (TILE_SIZE * 2.0.pow(zoom.toDouble()))
        val minX = x * TILE_SIZE * resolution - world
        val maxX = (x + 1) * TILE_SIZE * resolution - world
        val maxY = world - y * TILE_SIZE * resolution
        val minY = world - (y + 1) * TILE_SIZE * resolution
        val bbox = String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", minX, minY, maxX, maxY)
        return "https://zbgisws.skgeodesy.sk/zbgis_ortofoto_wms/service.svc/get" +
            "?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=1&STYLES=" +
            "&CRS=EPSG:3857&BBOX=$bbox&WIDTH=512&HEIGHT=512&FORMAT=image/jpeg"
    }

    private fun drawAttribution(canvas: Canvas, provider: Provider) {
        val text = provider.attribution
        val padding = 6f * resources.displayMetrics.density
        val textWidth = attributionPaint.measureText(text)
        val baseline = height - padding
        chromePaint.color = 0xdfffffff.toInt()
        canvas.drawRect(
            0f,
            baseline - attributionPaint.textSize - padding,
            textWidth + padding * 2,
            height.toFloat(),
            chromePaint
        )
        canvas.drawText(text, padding, baseline, attributionPaint)
    }

    private fun normalizedProvider(type: String): Provider = when (type.uppercase()) {
        "OSM", "NORMAL" -> Provider.OSM
        "OSM_TERRAIN", "TERRAIN" -> Provider.OSM_TERRAIN
        else -> Provider.ZBGIS_ORTHO
    }

    private fun floorMod(value: Int, modulus: Int): Int = ((value % modulus) + modulus) % modulus

    companion object {
        private const val TILE_SIZE = 256
        private const val TILE_OVERLAP_PX = 1f
        private const val RETAINED_MARGIN_TILES = 2
        private const val MIN_ZOOM = 3
        private const val DIGITAL_ZOOM_LEVELS = 5
        private const val MAX_SAFE_DISPLAY_ZOOM = 26
        private const val MEMORY_CACHE_KB = 64 * 1024
        private const val READY_FRACTION = 0.80
        private const val CACHE_TTL_MS = 7L * 24L * 60L * 60L * 1000L
        private const val FAILED_RETRY_MS = 30_000L
        private const val ERROR_MESSAGE_THROTTLE_MS = 8_000L
        private const val USER_AGENT = "StrechoStav-Sketch-Android/2.4 (interactive roof drawing map)"

        fun sourceMaxZoomFor(mapType: String): Int = when (mapType.uppercase()) {
            "OSM", "NORMAL" -> 19
            "OSM_TERRAIN", "TERRAIN" -> 17
            else -> 21
        }

        fun maxDisplayZoomFor(mapType: String): Int = sourceMaxZoomFor(mapType) + DIGITAL_ZOOM_LEVELS
    }
}
