package sk.strechasketch.app

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class Roof3DView(context: Context) : GLSurfaceView(context) {
    private val roofRenderer = Roof3DRenderer()
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                roofRenderer.zoom = (roofRenderer.zoom * detector.scaleFactor).coerceIn(0.45f, 3.2f)
                requestRender()
                return true
            }
        }
    )
    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        setPreserveEGLContextOnPause(true)
        setRenderer(roofRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        contentDescription = "Interaktívny trojrozmerný model strechy"
    }

    fun setProject(project: RoofProject) {
        roofRenderer.setProject(project)
        requestRender()
    }

    fun resetView() {
        roofRenderer.resetView()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.yawDegrees += (event.x - lastX) / density * 0.62f
                    roofRenderer.pitchDegrees = (
                        roofRenderer.pitchDegrees + (event.y - lastY) / density * 0.62f
                    ).coerceIn(-82f, 82f)
                    requestRender()
                }
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

private data class RoofVec3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(other: RoofVec3) = RoofVec3(x - other.x, y - other.y, z - other.z)
}

private data class RoofMesh(
    val triangles: FloatArray,
    val normals: FloatArray,
    val edges: FloatArray
)

private object RoofMeshBuilder {
    private data class HeightPoint(val p: LocalPoint, val h: Double)
    private data class Triangle(val a: Int, val b: Int, val c: Int)
    private data class Edge(val a: Int, val b: Int) {
        fun normalized() = if (a < b) this else Edge(b, a)
    }

    fun build(project: RoofProject): RoofMesh {
        if (project.polygon.size < 3) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val origin = Geometry.centroid(project.polygon)
        val local = project.polygon.map { Geometry.toLocal(it, origin) }
        val maxSpan = max(
            (local.maxOf { it.x } - local.minOf { it.x }),
            (local.maxOf { it.y } - local.minOf { it.y })
        ).coerceAtLeast(1.0)
        val wallHeight = project.wallHeightM.coerceIn(0.5, 100.0)
        val centerLocal = LocalPoint(local.sumOf { it.x } / local.size, local.sumOf { it.y } / local.size)
        val longestIndex = local.indices.maxByOrNull { index ->
            val b = local[(index + 1) % local.size]
            hypot(b.x - local[index].x, b.y - local[index].y)
        } ?: 0
        val longestNext = local[(longestIndex + 1) % local.size]
        val baseAngle = atan2(longestNext.y - local[longestIndex].y, longestNext.x - local[longestIndex].x)
        val ux = cos(baseAngle)
        val uy = sin(baseAngle)
        val vx = -uy
        val vy = ux
        fun u(p: LocalPoint) = p.x * ux + p.y * uy
        fun v(p: LocalPoint) = p.x * vx + p.y * vy
        val uMin = local.minOf(::u)
        val uMax = local.maxOf(::u)
        val vMin = local.minOf(::v)
        val vMax = local.maxOf(::v)
        val vMid = (vMin + vMax) / 2.0
        val halfWidth = ((vMax - vMin) / 2.0).coerceAtLeast(0.25)
        val slopeHeight = (tan(Math.toRadians(project.slopeDeg.coerceIn(0.0, 75.0))) * halfWidth)
            .coerceIn(maxSpan * 0.015, maxSpan * 0.75)
        val normalization = (2.2 / max(maxSpan, wallHeight + slopeHeight)).toFloat()
        val verticalCenter = (wallHeight + slopeHeight * 0.55) / 2.0
        fun point(p: LocalPoint, height: Double) = RoofVec3(
            ((p.x - centerLocal.x) * normalization).toFloat(),
            ((height - verticalCenter) * normalization).toFloat(),
            ((p.y - centerLocal.y) * normalization).toFloat()
        )
        fun fromUv(up: Double, vp: Double) = LocalPoint(up * ux + vp * vx, up * uy + vp * vy)

        val positions = arrayListOf<Float>()
        val normals = arrayListOf<Float>()
        val edges = arrayListOf<Float>()

        val localLines = project.lines.map { line ->
            Triple(line.type, Geometry.toLocal(line.start, origin), Geometry.toLocal(line.end, origin))
        }

        fun distanceToRoofBase(p: LocalPoint): Double =
            Geometry.distanceToRoofBaseBoundary(p, local, project.edgeTypes)

        fun automaticRoofHeight(p: LocalPoint): Double {
            val slope = tan(Math.toRadians(project.slopeDeg.coerceIn(0.0, 75.0)))
            if (slope < 0.001) return wallHeight + maxSpan * 0.02
            var relative = distanceToRoofBase(p) * slope
            localLines.filter { it.first == LineType.RIDGE || it.first == LineType.HIP }.forEach { (_, a, b) ->
                val projected = projectToSegment(p, a, b)
                val anchor = distanceToRoofBase(projected) * slope
                val influence = anchor - Geometry.distanceToSegment(p, a, b) * slope
                relative = max(relative, influence)
            }
            localLines.filter { it.first == LineType.VALLEY }.forEach { (_, a, b) ->
                val projected = projectToSegment(p, a, b)
                val anchor = distanceToRoofBase(projected) * slope
                val valleyCeiling = anchor + Geometry.distanceToSegment(p, a, b) * slope * 0.72
                relative = kotlin.math.min(relative, valleyCeiling)
            }
            return wallHeight + relative.coerceIn(0.0, maxSpan * 0.9)
        }

        fun shedHeight(p: LocalPoint): Double {
            val fraction = ((v(p) - vMin) / (vMax - vMin).coerceAtLeast(0.1)).coerceIn(0.0, 1.0)
            return wallHeight + maxSpan * 0.025 + fraction * slopeHeight * 1.6
        }

        fun boundaryTopHeight(p: LocalPoint): Double = when (project.shape) {
            RoofShape.AUTO -> automaticRoofHeight(p)
            RoofShape.FLAT -> wallHeight + maxSpan * 0.035
            RoofShape.SHED -> shedHeight(p)
            RoofShape.GABLE, RoofShape.HIP -> wallHeight
        }

        when (project.shape) {
            RoofShape.AUTO -> {
                val topology = project.roofTopology ?: RoofTopologySolver.solve(
                    RoofTopologyMigration.fromProject(project)
                ).proposed
                val topologyNodes = topology.nodes.associateBy { it.id }
                RoofTopologySolver.extractFaces(topology).forEach { face ->
                    val facePoints = face.nodeIds.mapNotNull { nodeId -> topologyNodes[nodeId] }.map { node ->
                        Geometry.toLocal(
                            Geometry.toGeo(LocalPoint(node.x, node.y), topology.origin),
                            origin
                        )
                    }
                    earClip(facePoints).forEach { triangle ->
                        val a = facePoints[triangle.a]
                        val b = facePoints[triangle.b]
                        val c = facePoints[triangle.c]
                        addTriangle(
                            positions, normals,
                            point(a, automaticRoofHeight(a)),
                            point(b, automaticRoofHeight(b)),
                            point(c, automaticRoofHeight(c))
                        )
                    }
                }
                local.indices.forEach { index ->
                    val a = local[index]
                    val b = local[(index + 1) % local.size]
                    addLine(edges, point(a, automaticRoofHeight(a)), point(b, automaticRoofHeight(b)))
                }
            }
            RoofShape.FLAT -> {
                val height = wallHeight + maxSpan * 0.035
                earClip(local).forEach { triangle ->
                    addTriangle(
                        positions, normals,
                        point(local[triangle.a], height),
                        point(local[triangle.b], height),
                        point(local[triangle.c], height)
                    )
                }
                local.indices.forEach { index -> addLine(edges, point(local[index], height), point(local[(index + 1) % local.size], height)) }
            }
            RoofShape.HIP -> {
                val apex = point(centerLocal, wallHeight + slopeHeight)
                local.indices.forEach { index ->
                    val a = point(local[index], wallHeight)
                    val b = point(local[(index + 1) % local.size], wallHeight)
                    addTriangle(positions, normals, a, b, apex)
                    addLine(edges, a, b)
                    addLine(edges, a, apex)
                }
            }
            RoofShape.SHED -> {
                earClip(local).forEach { triangle ->
                    val a = local[triangle.a]
                    val b = local[triangle.b]
                    val c = local[triangle.c]
                    addTriangle(positions, normals, point(a, shedHeight(a)), point(b, shedHeight(b)), point(c, shedHeight(c)))
                }
                local.indices.forEach { index ->
                    val a = local[index]
                    val b = local[(index + 1) % local.size]
                    addLine(edges, point(a, shedHeight(a)), point(b, shedHeight(b)))
                }
            }
            RoofShape.GABLE -> {
                fun ridgeAt(up: Double) = point(fromUv(up.coerceIn(uMin, uMax), vMid), wallHeight + slopeHeight)
                val ridgeA = ridgeAt(uMin)
                val ridgeB = ridgeAt(uMax)
                addLine(edges, ridgeA, ridgeB)
                local.indices.forEach { index ->
                    val aLocal = local[index]
                    val bLocal = local[(index + 1) % local.size]
                    val a = point(aLocal, wallHeight)
                    val b = point(bLocal, wallHeight)
                    val du = abs(u(bLocal) - u(aLocal))
                    val dv = abs(v(bLocal) - v(aLocal))
                    if (du >= dv * 0.65) {
                        val ra = ridgeAt(u(aLocal))
                        val rb = ridgeAt(u(bLocal))
                        addTriangle(positions, normals, a, b, rb)
                        addTriangle(positions, normals, a, rb, ra)
                        addLine(edges, a, ra)
                        addLine(edges, b, rb)
                    } else {
                        val ridge = if (abs((u(aLocal) + u(bLocal)) / 2 - uMin) <
                            abs((u(aLocal) + u(bLocal)) / 2 - uMax)
                        ) ridgeA else ridgeB
                        addTriangle(positions, normals, a, b, ridge)
                        addLine(edges, a, ridge)
                        addLine(edges, b, ridge)
                    }
                    addLine(edges, a, b)
                }
            }
        }

        // Steny budovy: pôdorys je vytiahnutý od terénu po odkvapovú hranu.
        local.indices.forEach { index ->
            val bIndex = (index + 1) % local.size
            val a = point(local[index], boundaryTopHeight(local[index]))
            val b = point(local[bIndex], boundaryTopHeight(local[bIndex]))
            val c = point(local[bIndex], 0.0)
            val d = point(local[index], 0.0)
            addTriangle(positions, normals, a, c, b)
            addTriangle(positions, normals, a, d, c)
            addLine(edges, d, c)
            addLine(edges, d, a)
        }

        fun addAtticWall(aLocal: LocalPoint, bLocal: LocalPoint, aBase: Double, bBase: Double) {
            val height = project.atticHeightM.coerceIn(0.1, 3.0)
            val aBottom = point(aLocal, aBase)
            val bBottom = point(bLocal, bBase)
            val aTop = point(aLocal, aBase + height)
            val bTop = point(bLocal, bBase + height)
            addTriangle(positions, normals, aBottom, bBottom, bTop)
            addTriangle(positions, normals, aBottom, bTop, aTop)
            // Obe strany zostanú viditeľné aj pri pohľade zvnútra pôdorysu.
            addTriangle(positions, normals, bBottom, aBottom, aTop)
            addTriangle(positions, normals, bBottom, aTop, bTop)
            addLine(edges, aBottom, aTop)
            addLine(edges, aTop, bTop)
            addLine(edges, bTop, bBottom)
        }

        project.polygon.indices.forEach { index ->
            if (project.edgeTypes[index] == LineType.ATTIC) {
                val next = (index + 1) % local.size
                addAtticWall(
                    local[index], local[next],
                    boundaryTopHeight(local[index]), boundaryTopHeight(local[next])
                )
            }
        }
        project.lines.filter { it.type == LineType.ATTIC }.forEach { line ->
            val aLocal = Geometry.toLocal(line.start, origin)
            val bLocal = Geometry.toLocal(line.end, origin)
            val aBase = when (project.shape) {
                RoofShape.AUTO -> automaticRoofHeight(aLocal)
                RoofShape.FLAT -> wallHeight + maxSpan * 0.035
                RoofShape.SHED -> shedHeight(aLocal)
                RoofShape.GABLE, RoofShape.HIP -> wallHeight
            }
            val bBase = when (project.shape) {
                RoofShape.AUTO -> automaticRoofHeight(bLocal)
                RoofShape.FLAT -> wallHeight + maxSpan * 0.035
                RoofShape.SHED -> shedHeight(bLocal)
                RoofShape.GABLE, RoofShape.HIP -> wallHeight
            }
            addAtticWall(aLocal, bLocal, aBase, bBase)
        }
        project.lines.forEach { line ->
            val aLocal = Geometry.toLocal(line.start, origin)
            val bLocal = Geometry.toLocal(line.end, origin)
            val aHeight = if (project.shape == RoofShape.AUTO) automaticRoofHeight(aLocal) else wallHeight +
                if (line.type == LineType.RIDGE) slopeHeight else slopeHeight * 0.3
            val bHeight = if (project.shape == RoofShape.AUTO) automaticRoofHeight(bLocal) else wallHeight +
                if (line.type == LineType.RIDGE) slopeHeight else slopeHeight * 0.3
            addLine(
                edges,
                point(aLocal, aHeight + maxSpan * 0.008),
                point(bLocal, bHeight + maxSpan * 0.008)
            )
        }
        return RoofMesh(positions.toFloatArray(), normals.toFloatArray(), edges.toFloatArray())
    }

    /** Deterministic ear clipping for a simple face; unlike triangle fans it is safe for concave polygons. */
    private fun earClip(polygon: List<LocalPoint>): List<Triangle> {
        if (polygon.size < 3) return emptyList()
        fun cross2(a: LocalPoint, b: LocalPoint, c: LocalPoint) =
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        val signedArea = polygon.indices.sumOf { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            a.x * b.y - b.x * a.y
        }
        val indices = if (signedArea >= 0.0) polygon.indices.toMutableList()
        else polygon.indices.reversed().toMutableList()
        fun inside(p: LocalPoint, a: LocalPoint, b: LocalPoint, c: LocalPoint): Boolean {
            val ab = cross2(a, b, p)
            val bc = cross2(b, c, p)
            val ca = cross2(c, a, p)
            return ab >= -1e-8 && bc >= -1e-8 && ca >= -1e-8
        }
        val result = mutableListOf<Triangle>()
        var guard = 0
        while (indices.size > 3 && guard++ < polygon.size * polygon.size) {
            var clipped = false
            for (position in indices.indices) {
                val previous = indices[(position - 1 + indices.size) % indices.size]
                val current = indices[position]
                val next = indices[(position + 1) % indices.size]
                val a = polygon[previous]
                val b = polygon[current]
                val c = polygon[next]
                if (cross2(a, b, c) <= 1e-8) continue
                if (indices.any { candidate ->
                        candidate != previous && candidate != current && candidate != next &&
                            inside(polygon[candidate], a, b, c)
                    }
                ) continue
                result += Triangle(previous, current, next)
                indices.removeAt(position)
                clipped = true
                break
            }
            if (!clipped) return emptyList()
        }
        if (indices.size == 3 && abs(cross2(polygon[indices[0]], polygon[indices[1]], polygon[indices[2]])) > 1e-8) {
            result += Triangle(indices[0], indices[1], indices[2])
        }
        return result
    }

    private fun buildSurfaceSamples(
        polygon: List<LocalPoint>,
        lines: List<Triple<LineType, LocalPoint, LocalPoint>>,
        maxSpan: Double,
        wallHeight: Double,
        height: (LocalPoint) -> Double
    ): List<HeightPoint> {
        val spacing = (maxSpan / 11.0).coerceAtLeast(0.35)
        val points = mutableListOf<LocalPoint>()
        fun addUnique(point: LocalPoint) {
            if (points.none { hypot(it.x - point.x, it.y - point.y) < spacing * 0.08 }) points += point
        }
        polygon.indices.forEach { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(1, kotlin.math.ceil(length / spacing).toInt())
            for (step in 0 until count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        lines.forEach { (_, a, b) ->
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(2, kotlin.math.ceil(length / (spacing * 0.55)).toInt())
            for (step in 0..count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        val minX = polygon.minOf { it.x }
        val maxX = polygon.maxOf { it.x }
        val minY = polygon.minOf { it.y }
        val maxY = polygon.maxOf { it.y }
        var y = minY + spacing * 0.5
        while (y < maxY) {
            var x = minX + spacing * 0.5
            while (x < maxX) {
                val p = LocalPoint(x, y)
                if (Geometry.pointInPolygon(p, polygon)) addUnique(p)
                x += spacing
            }
            y += spacing
        }
        return points.map { HeightPoint(it, max(wallHeight, height(it))) }
    }

    private fun delaunay(points: List<LocalPoint>, polygon: List<LocalPoint>): List<Triangle> {
        if (points.size < 3) return emptyList()
        val all = points.toMutableList()
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val span = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
        val midX = (minX + maxX) / 2.0
        val midY = (minY + maxY) / 2.0
        val originalCount = all.size
        all += LocalPoint(midX - span * 20, midY - span * 10)
        all += LocalPoint(midX, midY + span * 20)
        all += LocalPoint(midX + span * 20, midY - span * 10)
        val triangles = mutableListOf(Triangle(originalCount, originalCount + 1, originalCount + 2))
        for (index in 0 until originalCount) {
            val bad = triangles.filter { circumcircleContains(all, it, all[index]) }
            val counts = linkedMapOf<Edge, Int>()
            bad.forEach { triangle ->
                listOf(Edge(triangle.a, triangle.b), Edge(triangle.b, triangle.c), Edge(triangle.c, triangle.a))
                    .map { it.normalized() }
                    .forEach { edge -> counts[edge] = (counts[edge] ?: 0) + 1 }
            }
            triangles.removeAll(bad.toSet())
            counts.filterValues { it == 1 }.keys.forEach { edge -> triangles += Triangle(edge.a, edge.b, index) }
        }
        return triangles.filter { triangle ->
            triangle.a < originalCount && triangle.b < originalCount && triangle.c < originalCount &&
                Geometry.pointInPolygon(
                    LocalPoint(
                        (all[triangle.a].x + all[triangle.b].x + all[triangle.c].x) / 3.0,
                        (all[triangle.a].y + all[triangle.b].y + all[triangle.c].y) / 3.0
                    ),
                    polygon
                )
        }
    }

    private fun circumcircleContains(points: List<LocalPoint>, triangle: Triangle, point: LocalPoint): Boolean {
        val a = points[triangle.a]
        val b = points[triangle.b]
        val c = points[triangle.c]
        val d = 2.0 * (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y))
        if (abs(d) < 1e-9) return false
        val a2 = a.x * a.x + a.y * a.y
        val b2 = b.x * b.x + b.y * b.y
        val c2 = c.x * c.x + c.y * c.y
        val ux = (a2 * (b.y - c.y) + b2 * (c.y - a.y) + c2 * (a.y - b.y)) / d
        val uy = (a2 * (c.x - b.x) + b2 * (a.x - c.x) + c2 * (b.x - a.x)) / d
        val radius2 = (ux - a.x) * (ux - a.x) + (uy - a.y) * (uy - a.y)
        val pointDistance2 = (ux - point.x) * (ux - point.x) + (uy - point.y) * (uy - point.y)
        return pointDistance2 <= radius2 + 1e-7
    }

    private fun projectToSegment(point: LocalPoint, a: LocalPoint, b: LocalPoint): LocalPoint {
        val dx = b.x - a.x
        val dy = b.y - a.y
        if (abs(dx) + abs(dy) < 1e-9) return a
        val t = (((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy)).coerceIn(0.0, 1.0)
        return LocalPoint(a.x + dx * t, a.y + dy * t)
    }

    private fun addTriangle(
        positions: MutableList<Float>,
        normals: MutableList<Float>,
        a: RoofVec3,
        b: RoofVec3,
        c: RoofVec3
    ) {
        var normal = normalized(cross(b - a, c - a))
        if (normal.y < 0f) {
            normal = RoofVec3(-normal.x, -normal.y, -normal.z)
            addVertex(positions, a)
            addVertex(positions, c)
            addVertex(positions, b)
        } else {
            addVertex(positions, a)
            addVertex(positions, b)
            addVertex(positions, c)
        }
        repeat(3) { addVertex(normals, normal) }
    }

    private fun addLine(values: MutableList<Float>, a: RoofVec3, b: RoofVec3) {
        addVertex(values, a)
        addVertex(values, b)
    }

    private fun addVertex(values: MutableList<Float>, value: RoofVec3) {
        values += value.x
        values += value.y
        values += value.z
    }

    private fun cross(a: RoofVec3, b: RoofVec3) = RoofVec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )

    private fun normalized(value: RoofVec3): RoofVec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) RoofVec3(0f, 1f, 0f)
        else RoofVec3(value.x / length, value.y / length, value.z / length)
    }
}

private class Roof3DRenderer : GLSurfaceView.Renderer {
    @Volatile private var pendingMesh = RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
    @Volatile var yawDegrees = -34f
    @Volatile var pitchDegrees = 28f
    @Volatile var zoom = 1f

    private var width = 1
    private var height = 1
    private var surfaceProgram = 0
    private var edgeProgram = 0
    private var triangleVbo = 0
    private var edgeVbo = 0
    private var triangleCount = 0
    private var edgeCount = 0
    private var uploaded: RoofMesh? = null

    fun setProject(project: RoofProject) {
        pendingMesh = RoofMeshBuilder.build(project)
    }

    fun resetView() {
        yawDegrees = -34f
        pitchDegrees = 28f
        zoom = 1f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.945f, 0.965f, 0.950f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        surfaceProgram = createProgram(SURFACE_VERTEX, SURFACE_FRAGMENT)
        edgeProgram = createProgram(EDGE_VERTEX, EDGE_FRAGMENT)
        val buffers = IntArray(2)
        GLES30.glGenBuffers(2, buffers, 0)
        triangleVbo = buffers[0]
        edgeVbo = buffers[1]
        uploaded = null
    }

    override fun onSurfaceChanged(gl: GL10?, widthValue: Int, heightValue: Int) {
        width = max(1, widthValue)
        height = max(1, heightValue)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (triangleCount == 0) return
        val model = FloatArray(16)
        val view = FloatArray(16)
        val projection = FloatArray(16)
        val viewProjection = FloatArray(16)
        val mvp = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, zoom, zoom, zoom)
        Matrix.setLookAtM(view, 0, 0f, 0.35f, 5.2f, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projection, 0, 34f, width.toFloat() / height, 0.1f, 20f)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)
        drawSurfaces(model, mvp)
        drawEdges(mvp)
    }

    private fun uploadIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploaded) return
        val interleaved = FloatArray(mesh.triangles.size * 2)
        var source = 0
        var target = 0
        while (source < mesh.triangles.size) {
            interleaved[target++] = mesh.triangles[source]
            interleaved[target++] = mesh.triangles[source + 1]
            interleaved[target++] = mesh.triangles[source + 2]
            interleaved[target++] = mesh.normals[source]
            interleaved[target++] = mesh.normals[source + 1]
            interleaved[target++] = mesh.normals[source + 2]
            source += 3
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, interleaved.size * 4, interleaved.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        triangleCount = mesh.triangles.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, mesh.edges.size * 4, mesh.edges.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        edgeCount = mesh.edges.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        uploaded = mesh
    }

    private fun drawSurfaces(model: FloatArray, mvp: FloatArray) {
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uModel"), 1, false, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uColor"), 0.68f, 0.16f, 0.12f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uLight"), -0.3f, 0.8f, 0.55f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(normal)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glVertexAttribPointer(normal, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, triangleCount)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(normal)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(edgeProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(edgeProgram, "uColor"), 0.08f, 0.10f, 0.11f, 0.95f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glLineWidth(1.5f)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeCount)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragment)
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL program: ${GLES30.glGetProgramInfoLog(program)}" }
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return program
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL shader: ${GLES30.glGetShaderInfoLog(shader)}" }
        return shader
    }

    private fun FloatArray.nativeBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(this@nativeBuffer)
            position(0)
        }

    companion object {
        private const val SURFACE_VERTEX = """
            #version 300 es
            uniform mat4 uModel;
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec3 aNormal;
            out vec3 vNormal;
            void main() {
                vNormal = mat3(uModel) * aNormal;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val SURFACE_FRAGMENT = """
            #version 300 es
            precision highp float;
            uniform vec3 uColor;
            uniform vec3 uLight;
            in vec3 vNormal;
            out vec4 outColor;
            void main() {
                vec3 normal = normalize(vNormal);
                if (!gl_FrontFacing) normal = -normal;
                float diffuse = max(dot(normal, normalize(uLight)), 0.0);
                vec3 wallColor = vec3(0.72, 0.70, 0.65);
                float roofMix = smoothstep(0.28, 0.58, abs(normal.y));
                vec3 baseColor = mix(wallColor, uColor, roofMix);
                vec3 color = baseColor * (0.40 + 0.60 * diffuse);
                outColor = vec4(color, 1.0);
            }
        """
        private const val EDGE_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            void main() { gl_Position = uMvp * vec4(aPosition, 1.0); }
        """
        private const val EDGE_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform vec4 uColor;
            out vec4 outColor;
            void main() { outColor = uColor; }
        """
    }
}
