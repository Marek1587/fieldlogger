# Zmeny

## 2.5.0

- priame kontextové menu typu obvodovej hrany po dlhšom podržaní,
- odstránené skryté pretváranie pôdorysu pred topologickou korekciou,
- korektný solver polvalby s dvoma štítovými úsekmi, hrebeňom a dvoma nárožiami,
- automatické 3D rozlišuje odkvap od štítu, pultovej hrany, atiky a napojenia pri murive,
- zvýšený koniec hrebeňa na štíte už neklesne na výšku muriva,
- regresné testy pre tri plochy polvalby a výškovú väzbu hrebeňa na štíte,
- zrozumiteľnejší náhľad korekcie bez technického počítadla „Chyby“.

## 2.4.0

- spoločný posun, zoom a dvojprstová rotácia mapy, polygónu, línií a objektov,
- tlačidlo Sever na okamžité vynulovanie natočenia,
- vyhladenie voľnej ruky a limit najviac 10 významných bodov obrysu,
- magnetické prichytenie vnútorných línií k uzlom, vrcholom a hranám,
- výber editovateľného bodu dlhým podržaním, oranžové zvýraznenie a vibrácia,
- samostatné spodné tlačidlo Odstrániť bod,
- nastaviteľná výška atiky a skutočná zvislá atiková stena v 3D,
- JSON schéma 4 so spätným načítaním projektov bez rotácie a výšky atiky.

## 2.3.0

- stabilný dvojvrstvový renderer máp bez odkrývania prázdnych dlaždíc,
- päť úrovní digitálneho zoomu nad zdrojovým limitom ZBGIS/OSM,
- topologický graf uzlov a hrán so solverom priesečníkov, T-napojení, snapu a merge,
- nezáväzný vizuálny náhľad korekcie pred zápisom do projektu,
- režim editácie koncov vnútorných strešných línií,
- Undo aj Redo a transakčné prijatie solvera,
- validácia topológie pred 3D a triangulácia automatickej strechy po plochách,
- ear clipping pre konkávne ploché a pultové pôdorysy,
- JSON schéma 3 so spätnou migráciou starších projektov,
- kompaktná päťtlačidlová spodná lišta s vektorovými ikonami,
- regresné testy topológie, konkávneho pôdorysu a JSON migrácie.

## 2.2.0

- Google Maps SDK aj API kľúč boli úplne odstránené,
- bezplatná cestná vrstva OpenStreetMap a terénna vrstva OpenTopoMap,
- slovenské ortofoto cez verejnú WMS službu ZBGIS v EPSG:3857,
- automatické skladanie všetkých dlaždíc potrebných pre aktuálnu obrazovku a zoom,
- sedemdňová lokálna cache dlaždíc a povinné uvedenie zdroja dát,
- adresa sa naďalej mení na GPS cez Nominatim s cache a obmedzením požiadaviek,
- staré projekty s Google typmi máp sa automaticky prevedú na nové bezplatné vrstvy.

## 2.1.1

- zoom mapy a výkresu kolieskom pripojenej myši.

## 2.1.0

- opravená diagnostika prázdnej Google mapy spôsobenej chýbajúcim alebo nesprávne obmedzeným API kľúčom,
- GitHub build sa bez `MAPS_API_KEY` zastaví namiesto vytvorenia nefunkčnej mapovej zostavy,
- stabilný debug podpis a uvedený SHA-1 pre Android obmedzenie Google API kľúča,
- zoom mapy dvoma prstami aj tlačidlami `+`, `−` a `Celok`,
- import PDF/JPG/PNG/WebP ako kresliaceho podkladu,
- posun, zoom a uloženie transformácie výkresového podkladu,
- výber obvodovej hrany a nastavenie dĺžky číselnými kolieskami,
- kalibrácia celého výkresu podľa jednej známej dĺžky,
- dĺžky obvodových hrán sa zobrazujú priamo v editore.

## 2.0.0

- názov aplikácie zmenený na StrechoStav Sketch,
- Google ortofotomapa, hybridná mapa a terén namiesto OSM dlaždíc,
- samostatné tlačidlo `Bod`,
- bezpečné odsadenie obsahu od hornej a dolnej systémovej lišty Androidu,
- 3D model obsahuje steny pôdorysu s nastaviteľnou výškou od 3 m,
- automatický tvar strechy podľa hrebeňov, nároží a úžľabí v nákrese,
- podpora kombinovaných tvarov vrátane polvalby,
- z výkazu, SVG a PDF odstránená hydroizolácia, podklad a ceny,
- Google Maps API kľúč sa načítava zo `secrets.properties` alebo GitHub secretu.

## 1.0.0

- prvá natívna Android verzia,
- dotykový 2D editor strechy,
- technické línie a prvky,
- lokálne projekty, JSON, SVG, PDF a 3D náhľad,
- GitHub Actions workflow na zostavenie debug APK.
