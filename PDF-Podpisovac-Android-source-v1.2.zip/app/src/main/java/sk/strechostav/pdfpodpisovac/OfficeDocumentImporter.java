package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

final class OfficeDocumentImporter {
    private static final long MAX_XML_BYTES = 32L * 1024L * 1024L;

    private OfficeDocumentImporter() {
    }

    static void appendDocx(
            Context context,
            Uri uri,
            PdfDocument output,
            DocumentCombiner.PageCounter counter
    ) throws IOException {
        File localCopy = DocumentCombiner.copyToCache(context, uri, ".docx");
        try (ZipFile zip = new ZipFile(localCopy)) {
            ZipEntry documentEntry = zip.getEntry("word/document.xml");
            if (documentEntry == null) {
                throw new IOException("DOCX neobsahuje dokument word/document.xml.");
            }
            List<String> paragraphs = parseDocxParagraphs(zip, documentEntry);
            renderParagraphs(output, counter, paragraphs);
        } finally {
            //noinspection ResultOfMethodCallIgnored
            localCopy.delete();
        }
    }

    static void appendXlsx(
            Context context,
            Uri uri,
            PdfDocument output,
            DocumentCombiner.PageCounter counter
    ) throws IOException {
        File localCopy = DocumentCombiner.copyToCache(context, uri, ".xlsx");
        try (ZipFile zip = new ZipFile(localCopy)) {
            List<String> sharedStrings = parseSharedStrings(zip);
            ArrayList<ZipEntry> sheets = new ArrayList<>();
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String name = entry.getName();
                if (!entry.isDirectory()
                        && name.startsWith("xl/worksheets/sheet")
                        && name.endsWith(".xml")) {
                    sheets.add(entry);
                }
            }
            sheets.sort(Comparator.comparing(ZipEntry::getName));
            if (sheets.isEmpty()) {
                throw new IOException("XLSX neobsahuje žiadny pracovný hárok.");
            }
            for (int index = 0; index < sheets.size(); index++) {
                List<SpreadsheetRow> rows =
                        parseWorksheet(zip, sheets.get(index), sharedStrings);
                renderWorksheet(
                        output,
                        counter,
                        "Hárok " + (index + 1),
                        rows
                );
            }
        } finally {
            //noinspection ResultOfMethodCallIgnored
            localCopy.delete();
        }
    }

    private static List<String> parseDocxParagraphs(ZipFile zip, ZipEntry entry)
            throws IOException {
        ArrayList<String> paragraphs = new ArrayList<>();
        try (InputStream raw = zip.getInputStream(entry);
             InputStream input = new LimitedInputStream(raw, MAX_XML_BYTES)) {
            XmlPullParser parser = newParser(input);
            StringBuilder paragraph = null;
            boolean insideText = false;
            int event;
            while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                String tag = parser.getName();
                if (event == XmlPullParser.START_TAG) {
                    if ("p".equals(tag)) {
                        paragraph = new StringBuilder();
                    } else if ("t".equals(tag) && paragraph != null) {
                        insideText = true;
                    } else if ("tab".equals(tag) && paragraph != null) {
                        paragraph.append("    ");
                    } else if ("br".equals(tag) && paragraph != null) {
                        paragraph.append('\n');
                    }
                } else if (event == XmlPullParser.TEXT
                        && insideText
                        && paragraph != null) {
                    paragraph.append(parser.getText());
                } else if (event == XmlPullParser.END_TAG) {
                    if ("t".equals(tag)) {
                        insideText = false;
                    } else if ("p".equals(tag) && paragraph != null) {
                        paragraphs.add(paragraph.toString());
                        paragraph = null;
                    }
                }
            }
        } catch (XmlPullParserException exception) {
            throw new IOException("DOCX obsahuje poškodené XML.", exception);
        }
        return paragraphs;
    }

    private static List<String> parseSharedStrings(ZipFile zip) throws IOException {
        ZipEntry entry = zip.getEntry("xl/sharedStrings.xml");
        if (entry == null) {
            return Collections.emptyList();
        }
        ArrayList<String> values = new ArrayList<>();
        try (InputStream raw = zip.getInputStream(entry);
             InputStream input = new LimitedInputStream(raw, MAX_XML_BYTES)) {
            XmlPullParser parser = newParser(input);
            StringBuilder current = null;
            boolean insideText = false;
            int event;
            while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                String tag = parser.getName();
                if (event == XmlPullParser.START_TAG) {
                    if ("si".equals(tag)) {
                        current = new StringBuilder();
                    } else if ("t".equals(tag) && current != null) {
                        insideText = true;
                    }
                } else if (event == XmlPullParser.TEXT
                        && insideText
                        && current != null) {
                    current.append(parser.getText());
                } else if (event == XmlPullParser.END_TAG) {
                    if ("t".equals(tag)) {
                        insideText = false;
                    } else if ("si".equals(tag) && current != null) {
                        values.add(current.toString());
                        current = null;
                    }
                }
            }
        } catch (XmlPullParserException exception) {
            throw new IOException("XLSX obsahuje poškodené zdieľané texty.", exception);
        }
        return values;
    }

    private static List<SpreadsheetRow> parseWorksheet(
            ZipFile zip,
            ZipEntry entry,
            List<String> sharedStrings
    ) throws IOException {
        ArrayList<SpreadsheetRow> rows = new ArrayList<>();
        try (InputStream raw = zip.getInputStream(entry);
             InputStream input = new LimitedInputStream(raw, MAX_XML_BYTES)) {
            XmlPullParser parser = newParser(input);
            SpreadsheetRow currentRow = null;
            int automaticRowNumber = 1;
            int currentColumn = -1;
            String currentType = null;
            StringBuilder cellValue = null;
            boolean readingValue = false;
            boolean readingInlineText = false;
            int event;
            while ((event = parser.next()) != XmlPullParser.END_DOCUMENT) {
                String tag = parser.getName();
                if (event == XmlPullParser.START_TAG) {
                    if ("row".equals(tag)) {
                        int rowNumber = parseInteger(
                                parser.getAttributeValue(null, "r"),
                                automaticRowNumber
                        );
                        currentRow = new SpreadsheetRow(rowNumber);
                        automaticRowNumber = rowNumber + 1;
                    } else if ("c".equals(tag) && currentRow != null) {
                        String reference = parser.getAttributeValue(null, "r");
                        currentColumn = columnIndex(reference);
                        currentType = parser.getAttributeValue(null, "t");
                        cellValue = new StringBuilder();
                    } else if ("v".equals(tag) && cellValue != null) {
                        readingValue = true;
                    } else if ("t".equals(tag)
                            && cellValue != null
                            && "inlineStr".equals(currentType)) {
                        readingInlineText = true;
                    }
                } else if (event == XmlPullParser.TEXT && cellValue != null) {
                    if (readingValue || readingInlineText) {
                        cellValue.append(parser.getText());
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    if ("v".equals(tag)) {
                        readingValue = false;
                    } else if ("t".equals(tag)) {
                        readingInlineText = false;
                    } else if ("c".equals(tag)
                            && currentRow != null
                            && currentColumn >= 0
                            && cellValue != null) {
                        String value = resolveCellValue(
                                cellValue.toString(),
                                currentType,
                                sharedStrings
                        );
                        if (!value.isEmpty()) {
                            currentRow.cells.put(currentColumn, value);
                        }
                        currentColumn = -1;
                        currentType = null;
                        cellValue = null;
                    } else if ("row".equals(tag) && currentRow != null) {
                        if (!currentRow.cells.isEmpty()) {
                            rows.add(currentRow);
                            if (rows.size() >= 10_000) {
                                break;
                            }
                        }
                        currentRow = null;
                    }
                }
            }
        } catch (XmlPullParserException exception) {
            throw new IOException("XLSX obsahuje poškodený pracovný hárok.", exception);
        }
        return rows;
    }

    private static String resolveCellValue(
            String raw,
            String type,
            List<String> sharedStrings
    ) {
        if ("s".equals(type)) {
            int index = parseInteger(raw, -1);
            if (index >= 0 && index < sharedStrings.size()) {
                return sharedStrings.get(index);
            }
            return "";
        }
        if ("b".equals(type)) {
            return "1".equals(raw) ? "TRUE" : "FALSE";
        }
        return raw;
    }

    private static void renderParagraphs(
            PdfDocument document,
            DocumentCombiner.PageCounter counter,
            List<String> paragraphs
    ) {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK);
        paint.setTextSize(12f);
        float margin = 44f;
        float maximumWidth = 595f - margin * 2f;
        float lineHeight = 18f;
        PdfDocument.Page page = null;
        Canvas canvas = null;
        float y = margin;

        List<String> content = paragraphs.isEmpty()
                ? Collections.singletonList("")
                : paragraphs;
        for (String paragraph : content) {
            String[] explicitLines = paragraph.split("\\n", -1);
            for (String explicitLine : explicitLines) {
                List<String> wrapped = wrapText(explicitLine, paint, maximumWidth);
                for (String line : wrapped) {
                    if (page == null || y + lineHeight > 842f - margin) {
                        if (page != null) {
                            DocumentCombiner.finishPage(document, page);
                        }
                        page = DocumentCombiner.startA4Page(document, counter, false);
                        canvas = page.getCanvas();
                        y = margin;
                    }
                    canvas.drawText(line, margin, y + paint.getTextSize(), paint);
                    y += lineHeight;
                }
            }
            y += 7f;
        }
        if (page == null) {
            page = DocumentCombiner.startA4Page(document, counter, false);
        }
        DocumentCombiner.finishPage(document, page);
    }

    private static void renderWorksheet(
            PdfDocument document,
            DocumentCombiner.PageCounter counter,
            String sheetName,
            List<SpreadsheetRow> rows
    ) {
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(Color.BLACK);
        textPaint.setTextSize(9f);
        Paint headerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        headerPaint.setColor(Color.rgb(23, 78, 166));
        headerPaint.setTextSize(12f);
        headerPaint.setFakeBoldText(true);
        Paint gridPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridPaint.setColor(Color.rgb(170, 178, 190));
        gridPaint.setStyle(Paint.Style.STROKE);
        gridPaint.setStrokeWidth(0.7f);
        Paint headerFill = new Paint();
        headerFill.setColor(Color.rgb(232, 238, 248));

        int maximumColumn = 0;
        for (SpreadsheetRow row : rows) {
            for (Integer column : row.cells.keySet()) {
                maximumColumn = Math.max(maximumColumn, column);
            }
        }
        maximumColumn = Math.min(maximumColumn, 199);

        int columnsPerPage = 6;
        int rowsPerPage = 17;
        int rowCount = Math.max(1, rows.size());
        for (int columnStart = 0;
             columnStart <= maximumColumn;
             columnStart += columnsPerPage) {
            for (int rowStart = 0; rowStart < rowCount; rowStart += rowsPerPage) {
                PdfDocument.Page page =
                        DocumentCombiner.startA4Page(document, counter, true);
                Canvas canvas = page.getCanvas();
                float margin = 24f;
                float titleY = 20f;
                canvas.drawText(
                        sheetName + "  •  stĺpce "
                                + columnName(columnStart)
                                + "–"
                                + columnName(
                                Math.min(maximumColumn, columnStart + columnsPerPage - 1)
                        ),
                        margin,
                        titleY,
                        headerPaint
                );

                float tableTop = 34f;
                float rowNumberWidth = 38f;
                float cellWidth = (842f - margin * 2f - rowNumberWidth) / columnsPerPage;
                float rowHeight = 30f;

                canvas.drawRect(
                        margin,
                        tableTop,
                        842f - margin,
                        tableTop + rowHeight,
                        headerFill
                );
                drawCell(
                        canvas,
                        "#",
                        margin,
                        tableTop,
                        rowNumberWidth,
                        rowHeight,
                        textPaint,
                        gridPaint
                );
                for (int columnOffset = 0;
                     columnOffset < columnsPerPage;
                     columnOffset++) {
                    int column = columnStart + columnOffset;
                    String label = column <= maximumColumn ? columnName(column) : "";
                    drawCell(
                            canvas,
                            label,
                            margin + rowNumberWidth + columnOffset * cellWidth,
                            tableTop,
                            cellWidth,
                            rowHeight,
                            textPaint,
                            gridPaint
                    );
                }

                for (int rowOffset = 0; rowOffset < rowsPerPage; rowOffset++) {
                    int rowIndex = rowStart + rowOffset;
                    float top = tableTop + rowHeight * (rowOffset + 1);
                    SpreadsheetRow row = rowIndex < rows.size() ? rows.get(rowIndex) : null;
                    drawCell(
                            canvas,
                            row == null ? "" : String.valueOf(row.rowNumber),
                            margin,
                            top,
                            rowNumberWidth,
                            rowHeight,
                            textPaint,
                            gridPaint
                    );
                    for (int columnOffset = 0;
                         columnOffset < columnsPerPage;
                         columnOffset++) {
                        String value = "";
                        if (row != null) {
                            value = row.cells.getOrDefault(
                                    columnStart + columnOffset,
                                    ""
                            );
                        }
                        drawCell(
                                canvas,
                                value,
                                margin + rowNumberWidth + columnOffset * cellWidth,
                                top,
                                cellWidth,
                                rowHeight,
                                textPaint,
                                gridPaint
                        );
                    }
                }
                DocumentCombiner.finishPage(document, page);
            }
        }
    }

    private static void drawCell(
            Canvas canvas,
            String value,
            float left,
            float top,
            float width,
            float height,
            Paint textPaint,
            Paint gridPaint
    ) {
        RectF rect = new RectF(left, top, left + width, top + height);
        canvas.drawRect(rect, gridPaint);
        String text = ellipsize(value, textPaint, width - 8f);
        canvas.save();
        canvas.clipRect(left + 3f, top + 2f, left + width - 3f, top + height - 2f);
        canvas.drawText(text, left + 4f, top + 18f, textPaint);
        canvas.restore();
    }

    private static List<String> wrapText(String text, Paint paint, float maximumWidth) {
        if (text == null || text.isEmpty()) {
            return Collections.singletonList("");
        }
        ArrayList<String> lines = new ArrayList<>();
        String[] words = text.trim().split("\\s+");
        StringBuilder line = new StringBuilder();
        for (String word : words) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (paint.measureText(candidate) <= maximumWidth) {
                line.setLength(0);
                line.append(candidate);
            } else {
                if (line.length() > 0) {
                    lines.add(line.toString());
                    line.setLength(0);
                }
                if (paint.measureText(word) <= maximumWidth) {
                    line.append(word);
                } else {
                    int start = 0;
                    while (start < word.length()) {
                        int count = paint.breakText(
                                word,
                                start,
                                word.length(),
                                true,
                                maximumWidth,
                                null
                        );
                        count = Math.max(1, count);
                        lines.add(word.substring(start, Math.min(word.length(), start + count)));
                        start += count;
                    }
                }
            }
        }
        if (line.length() > 0) {
            lines.add(line.toString());
        }
        return lines.isEmpty() ? Collections.singletonList("") : lines;
    }

    private static String ellipsize(String text, Paint paint, float maximumWidth) {
        if (text == null) {
            return "";
        }
        String singleLine = text.replace('\n', ' ').replace('\r', ' ');
        if (paint.measureText(singleLine) <= maximumWidth) {
            return singleLine;
        }
        String suffix = "…";
        int count = paint.breakText(
                singleLine,
                true,
                Math.max(1f, maximumWidth - paint.measureText(suffix)),
                null
        );
        return singleLine.substring(0, Math.max(0, count)) + suffix;
    }

    private static int columnIndex(String reference) {
        if (reference == null || reference.isEmpty()) {
            return -1;
        }
        int value = 0;
        int letters = 0;
        for (int index = 0; index < reference.length(); index++) {
            char character = Character.toUpperCase(reference.charAt(index));
            if (character < 'A' || character > 'Z') {
                break;
            }
            value = value * 26 + (character - 'A' + 1);
            letters++;
        }
        return letters == 0 ? -1 : value - 1;
    }

    private static String columnName(int index) {
        int value = Math.max(0, index) + 1;
        StringBuilder result = new StringBuilder();
        while (value > 0) {
            int remainder = (value - 1) % 26;
            result.append((char) ('A' + remainder));
            value = (value - 1) / 26;
        }
        return result.reverse().toString();
    }

    private static int parseInteger(String value, int fallback) {
        try {
            return Integer.parseInt(value);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private static XmlPullParser newParser(InputStream input)
            throws XmlPullParserException {
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true);
        parser.setInput(input, "UTF-8");
        return parser;
    }

    private static final class SpreadsheetRow {
        final int rowNumber;
        final Map<Integer, String> cells = new HashMap<>();

        SpreadsheetRow(int rowNumber) {
            this.rowNumber = rowNumber;
        }
    }

    private static final class LimitedInputStream extends FilterInputStream {
        private final long maximum;
        private long count;

        LimitedInputStream(InputStream input, long maximum) {
            super(input);
            this.maximum = maximum;
        }

        @Override
        public int read() throws IOException {
            int value = super.read();
            if (value >= 0) {
                increase(1);
            }
            return value;
        }

        @Override
        public int read(byte[] buffer, int offset, int length) throws IOException {
            int read = super.read(buffer, offset, length);
            if (read > 0) {
                increase(read);
            }
            return read;
        }

        private void increase(int amount) throws IOException {
            count += amount;
            if (count > maximum) {
                throw new IOException("Kancelársky XML súbor je príliš veľký.");
            }
        }
    }
}
