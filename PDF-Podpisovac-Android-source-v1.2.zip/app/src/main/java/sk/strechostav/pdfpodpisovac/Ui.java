package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

final class Ui {
    private Ui() {
    }

    static int dp(Context context, float value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                context.getResources().getDisplayMetrics()
        ));
    }

    static TextView text(Context context, String value, float sp, int color) {
        TextView view = new TextView(context);
        view.setText(value);
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        view.setTextColor(color);
        return view;
    }

    static Button button(Context context, String label, boolean primary) {
        Button button = new Button(context);
        button.setText(label);
        button.setAllCaps(false);
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        button.setTextColor(primary ? Color.WHITE : Color.rgb(23, 78, 166));
        button.setMinHeight(dp(context, 48));

        GradientDrawable background = new GradientDrawable();
        background.setCornerRadius(dp(context, 10));
        background.setColor(primary ? Color.rgb(23, 78, 166) : Color.WHITE);
        background.setStroke(dp(context, 1), Color.rgb(23, 78, 166));
        button.setBackground(background);
        button.setPadding(dp(context, 16), dp(context, 8), dp(context, 16), dp(context, 8));
        return button;
    }

    static GradientDrawable cardBackground(Context context) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(context, 16));
        background.setStroke(dp(context, 1), Color.rgb(220, 226, 235));
        return background;
    }

    static void setMargins(View view, int leftDp, int topDp, int rightDp, int bottomDp) {
        if (!(view.getLayoutParams() instanceof android.view.ViewGroup.MarginLayoutParams)) {
            return;
        }
        Context context = view.getContext();
        android.view.ViewGroup.MarginLayoutParams params =
                (android.view.ViewGroup.MarginLayoutParams) view.getLayoutParams();
        params.setMargins(
                dp(context, leftDp),
                dp(context, topDp),
                dp(context, rightDp),
                dp(context, bottomDp)
        );
        view.setLayoutParams(params);
    }
}
