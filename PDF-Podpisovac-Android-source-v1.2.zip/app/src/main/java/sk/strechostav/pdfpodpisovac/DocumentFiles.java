package sk.strechostav.pdfpodpisovac;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.OpenableColumns;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

final class DocumentFiles {
    private DocumentFiles() {
    }

    static String displayName(Context context, Uri uri) {
        String result = null;
        Cursor cursor = null;
        try {
            cursor = context.getContentResolver().query(
                    uri,
                    new String[]{OpenableColumns.DISPLAY_NAME},
                    null,
                    null,
                    null
            );
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) {
                    result = cursor.getString(column);
                }
            }
        } catch (Exception ignored) {
            // A provider may not expose a display name.
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return result == null || result.trim().isEmpty() ? "dokument" : result;
    }

    static String mimeType(Context context, Uri uri, String fallback) {
        String mime = context.getContentResolver().getType(uri);
        if (mime == null || mime.isEmpty()) {
            mime = fallback;
        }
        if (mime == null || mime.isEmpty()) {
            String name = displayName(context, uri).toLowerCase(Locale.ROOT);
            mime = name.endsWith(".pdf") ? "application/pdf" : "image/*";
        }
        return mime;
    }

    static boolean isPdf(String mimeType, String displayName) {
        return "application/pdf".equalsIgnoreCase(mimeType)
                || displayName.toLowerCase(Locale.ROOT).endsWith(".pdf");
    }

    static Bitmap renderPdfPage(PdfRenderer renderer, int pageIndex, int maxDimension)
            throws IOException {
        synchronized (renderer) {
            try (PdfRenderer.Page page = renderer.openPage(pageIndex)) {
                int sourceWidth = page.getWidth();
                int sourceHeight = page.getHeight();
                float scale = Math.min(
                        (float) maxDimension / Math.max(sourceWidth, sourceHeight),
                        2.2f
                );
                scale = Math.max(scale, 0.5f);
                int width = Math.max(1, Math.round(sourceWidth * scale));
                int height = Math.max(1, Math.round(sourceHeight * scale));

                Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(Color.WHITE);
                Matrix matrix = new Matrix();
                matrix.setScale(scale, scale);
                page.render(bitmap, null, matrix, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return bitmap;
            }
        }
    }

    static Bitmap decodeImage(Context context, Uri uri, int maxDimension) throws IOException {
        ContentResolver resolver = context.getContentResolver();
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream stream = resolver.openInputStream(uri)) {
            if (stream == null) {
                throw new IOException("Súbor sa nepodarilo otvoriť.");
            }
            BitmapFactory.decodeStream(stream, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IOException("Obrázok má neplatný formát.");
        }

        int sampleSize = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sampleSize > maxDimension) {
            sampleSize *= 2;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sampleSize;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap decoded;
        try (InputStream stream = resolver.openInputStream(uri)) {
            if (stream == null) {
                throw new IOException("Súbor sa nepodarilo otvoriť.");
            }
            decoded = BitmapFactory.decodeStream(stream, null, options);
        }
        if (decoded == null) {
            throw new IOException("Obrázok sa nepodarilo načítať.");
        }

        int rotation = readExifRotation(resolver, uri);
        if (rotation == 0) {
            return decoded;
        }
        Matrix matrix = new Matrix();
        matrix.postRotate(rotation);
        Bitmap rotated = Bitmap.createBitmap(
                decoded,
                0,
                0,
                decoded.getWidth(),
                decoded.getHeight(),
                matrix,
                true
        );
        if (rotated != decoded) {
            decoded.recycle();
        }
        return rotated;
    }

    static Bitmap createCheckerPreview(Bitmap transparentBitmap, int width, int height) {
        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        int cell = Math.max(8, width / 28);
        for (int y = 0; y < height; y += cell) {
            for (int x = 0; x < width; x += cell) {
                boolean even = ((x / cell) + (y / cell)) % 2 == 0;
                PaintHolder.PAINT.setColor(even ? Color.WHITE : Color.rgb(232, 235, 240));
                canvas.drawRect(x, y, x + cell, y + cell, PaintHolder.PAINT);
            }
        }

        float margin = Math.max(8f, width * 0.04f);
        Rect destination = fitRect(
                transparentBitmap.getWidth(),
                transparentBitmap.getHeight(),
                Math.round(margin),
                Math.round(margin),
                Math.round(width - margin),
                Math.round(height - margin)
        );
        canvas.drawBitmap(transparentBitmap, null, destination, PaintHolder.FILTER_PAINT);
        return output;
    }

    private static int readExifRotation(ContentResolver resolver, Uri uri) {
        try (InputStream stream = resolver.openInputStream(uri)) {
            if (stream == null) {
                return 0;
            }
            ExifInterface exif = new ExifInterface(stream);
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
            );
            if (orientation == ExifInterface.ORIENTATION_ROTATE_90) {
                return 90;
            }
            if (orientation == ExifInterface.ORIENTATION_ROTATE_180) {
                return 180;
            }
            if (orientation == ExifInterface.ORIENTATION_ROTATE_270) {
                return 270;
            }
        } catch (Exception ignored) {
            // Orientation is optional.
        }
        return 0;
    }

    private static Rect fitRect(
            int sourceWidth,
            int sourceHeight,
            int left,
            int top,
            int right,
            int bottom
    ) {
        float availableWidth = right - left;
        float availableHeight = bottom - top;
        float scale = Math.min(
                availableWidth / sourceWidth,
                availableHeight / sourceHeight
        );
        int width = Math.max(1, Math.round(sourceWidth * scale));
        int height = Math.max(1, Math.round(sourceHeight * scale));
        int x = left + Math.round((availableWidth - width) / 2f);
        int y = top + Math.round((availableHeight - height) / 2f);
        return new Rect(x, y, x + width, y + height);
    }

    private static final class PaintHolder {
        static final android.graphics.Paint PAINT = new android.graphics.Paint();
        static final android.graphics.Paint FILTER_PAINT =
                new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG
                        | android.graphics.Paint.FILTER_BITMAP_FLAG);
    }
}
