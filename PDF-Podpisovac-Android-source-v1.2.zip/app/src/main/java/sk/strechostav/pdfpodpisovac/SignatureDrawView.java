package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public final class SignatureDrawView extends View {
    private final Path path = new Path();
    private final Paint inkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint guidePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean hasInk;

    public SignatureDrawView(Context context) {
        super(context);
        setBackgroundColor(Color.WHITE);

        inkPaint.setColor(Color.rgb(36, 55, 190));
        inkPaint.setStyle(Paint.Style.STROKE);
        inkPaint.setStrokeWidth(Ui.dp(context, 2f));
        inkPaint.setStrokeCap(Paint.Cap.ROUND);
        inkPaint.setStrokeJoin(Paint.Join.ROUND);

        guidePaint.setColor(Color.rgb(210, 216, 226));
        guidePaint.setStrokeWidth(Ui.dp(context, 1));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float baseline = getHeight() * 0.72f;
        canvas.drawLine(
                Ui.dp(getContext(), 16),
                baseline,
                getWidth() - Ui.dp(getContext(), 16),
                baseline,
                guidePaint
        );
        canvas.drawPath(path, inkPaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(event.getX(), event.getY());
                hasInk = true;
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                for (int index = 0; index < event.getHistorySize(); index++) {
                    path.lineTo(event.getHistoricalX(index), event.getHistoricalY(index));
                }
                path.lineTo(event.getX(), event.getY());
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                path.lineTo(event.getX(), event.getY());
                invalidate();
                performClick();
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    public boolean hasInk() {
        return hasInk;
    }

    public void clearSignature() {
        path.reset();
        hasInk = false;
        invalidate();
    }

    public void setInkColor(int color) {
        inkPaint.setColor(color);
        invalidate();
    }

    public void setStrokeWidthDp(float widthDp) {
        inkPaint.setStrokeWidth(Ui.dp(getContext(), widthDp));
        invalidate();
    }

    public Bitmap createTransparentSignature() {
        if (!hasInk) {
            return null;
        }

        RectF bounds = new RectF();
        path.computeBounds(bounds, true);
        int horizontalPadding = Ui.dp(getContext(), 16);
        int verticalPadding = Ui.dp(getContext(), 28);
        int width = Math.max(1, Math.round(bounds.width()) + horizontalPadding * 2);
        int height = Math.max(1, Math.round(bounds.height()) + verticalPadding * 2);

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        canvas.drawColor(Color.TRANSPARENT);
        canvas.translate(
                -bounds.left + horizontalPadding,
                -bounds.top + verticalPadding
        );
        canvas.drawPath(path, inkPaint);
        return bitmap;
    }
}
