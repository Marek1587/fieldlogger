package sk.strechostav.pdfpodpisovac;

import android.graphics.Bitmap;

/**
 * One visual signature/stamp placed on a document page.
 * Coordinates and dimensions are normalized to the displayed page, so they
 * remain correct when the PDF is rendered at a different resolution.
 */
public final class Placement {
    public final Bitmap bitmap;
    public final String label;
    public final int pageIndex;

    public float centerX;
    public float centerY;
    public float width;
    public float height;
    public float rotationDegrees;

    public Placement(
            Bitmap bitmap,
            String label,
            int pageIndex,
            float centerX,
            float centerY,
            float width,
            float height
    ) {
        this.bitmap = bitmap;
        this.label = label;
        this.pageIndex = pageIndex;
        this.centerX = centerX;
        this.centerY = centerY;
        this.width = width;
        this.height = height;
        this.rotationDegrees = 0f;
    }
}
