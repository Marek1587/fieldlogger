# The project currently builds an unminified release. Keep this file for future rules.
