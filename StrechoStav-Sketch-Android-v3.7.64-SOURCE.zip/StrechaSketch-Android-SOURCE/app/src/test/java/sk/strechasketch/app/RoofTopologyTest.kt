package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class RoofTopologyTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    private fun rectangleProject(): RoofProject = RoofProject(
        polygon = mutableListOf(geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0))
    )

    private fun internalAngleProject(angleDeg: Double): RoofProject = rectangleProject().apply {
        val length = 3.0
        val radians = Math.toRadians(angleDeg)
        lines += RoofLine(
            type = LineType.HIP,
            start = geo(0.0, 0.0),
            end = geo(kotlin.math.cos(radians) * length, kotlin.math.sin(radians) * length)
        )
    }

    @Test
    fun completeInternalCorrectionKeepsFreeHipAndDoesNotMoveBoundary() {
        val input = RoofTopologyMigration.fromLegacyProject(internalAngleProject(44.0))
        val boundaryBefore = input.nodes.filter { it.type == TopologyNodeType.FOOTPRINT }.associate { it.id to (it.x to it.y) }
        val preview = RoofTopologySolver.solveInternal(input)
        val nodes = preview.proposed.nodes.associateBy { it.id }
        boundaryBefore.forEach { (id, xy) ->
            assertEquals(xy.first, nodes.getValue(id).x, 1e-9)
            assertEquals(xy.second, nodes.getValue(id).y, 1e-9)
        }
        assertEquals(input.edges, preview.proposed.edges)
        assertEquals(0, preview.statistics.removedConflictingInternalEdges)
    }

    @Test
    fun completeInternalCorrectionReportsButDoesNotDeleteFreeThirtyThreeDegreeLine() {
        val input = RoofTopologyMigration.fromLegacyProject(internalAngleProject(33.0))
        val preview = RoofTopologySolver.solveInternal(input)
        assertEquals(input.edges, preview.proposed.edges)
        assertEquals(input.edges.single { !it.boundary }.type,
            preview.proposed.edges.single { !it.boundary }.type)
        assertTrue(preview.issues.any { it.severity == TopologyIssueSeverity.ERROR })
    }

    @Test
    fun internalCardKeepsAuthoredLinesWhileRuntimeGraphCreatesSharedIntersection() {
        val project = rectangleProject().apply {
            // Both diagonals are exact 45-degree grid directions. Their visual
            // crossing must become one shared topological junction.
            lines += RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = geo(8.0, 8.0))
            lines += RoofLine(type = LineType.VALLEY, start = geo(8.0, 0.0), end = geo(0.0, 8.0))
        }
        val input = RoofTopologyMigration.fromLegacyProject(project)
        val originalBoundaryNodes = input.nodes.filter { node ->
            input.edges.filter { it.boundary }.any { it.startNodeId == node.id || it.endNodeId == node.id }
        }.associateBy { it.id }
        val originalBoundaryEdges = input.edges.filter { it.boundary }
        val preview = RoofTopologySolver.solveInternal(input)

        assertEquals(0, preview.statistics.createdIntersections)
        assertEquals(0, preview.statistics.splitEdges)
        assertEquals(input.edges, preview.proposed.edges)
        assertEquals(originalBoundaryEdges, preview.proposed.edges.filter { it.boundary })
        val resultNodes = preview.proposed.nodes.associateBy { it.id }
        originalBoundaryNodes.forEach { (id, node) -> assertEquals(node, resultNodes[id]) }

        val runtime = RoofTopologySolver.deriveIncidenceFor3D(preview.proposed)
        assertTrue(runtime.statistics.createdIntersections >= 1)
        assertTrue(runtime.statistics.splitEdges >= 2)
        assertTrue(runtime.faces.isNotEmpty())
    }

    @Test
    fun isolatedRidgeIsReportedButNeverRemovedOrRetyped() {
        val project = rectangleProject().apply {
            val angle = Math.toRadians(6.0)
            lines += RoofLine(
                type = LineType.RIDGE,
                start = geo(2.0, 3.0),
                end = geo(2.0 + cos(angle) * 6.0, 3.0 + sin(angle) * 6.0)
            )
        }
        val input = RoofTopologyMigration.fromLegacyProject(project)
        val preview = RoofTopologySolver.solveInternal(input)
        assertEquals(input.edges, preview.proposed.edges)
        assertTrue(preview.issues.any { it.severity == TopologyIssueSeverity.ERROR })
        assertEquals(0, preview.statistics.removedConflictingInternalEdges)
    }

    @Test
    fun crossingRoofLinesCreateSharedIntersection() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            lines += RoofLine(type = LineType.VALLEY, start = geo(6.0, 0.0), end = geo(6.0, 8.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.createdIntersections >= 1)
        assertTrue(preview.statistics.splitEdges >= 2)
        assertTrue(preview.faces.isNotEmpty())
        assertTrue(preview.isValid)
    }

    @Test
    fun nearCoincidentEndpointsAreMergedDeterministically() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(6.0, 4.0))
            lines += RoofLine(type = LineType.RIDGE, start = geo(6.02, 4.01), end = geo(12.0, 4.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.mergedNodes >= 1)
        assertTrue(preview.proposed.edges.none { it.startNodeId == it.endNodeId })
    }

    @Test
    fun legacyJsonMigratesWithoutLosingReportInputs() {
        val project = rectangleProject().apply {
            name = "Regresný projekt"
            slopeDeg = 31.5
            wallHeightM = 4.2
            mapRotationDeg = 37.0
            atticHeightM = 0.85
            atticWidthM = 0.32
            objects += RoofObject(type = ObjectType.CHIMNEY, center = geo(3.0, 3.0))
        }
        val encoded = ProjectJson.encode(project)
        val decoded = ProjectJson.decode(encoded)
        assertEquals(project.name, decoded.name)
        assertEquals(project.slopeDeg, decoded.slopeDeg, 0.0001)
        assertEquals(project.wallHeightM, decoded.wallHeightM, 0.0001)
        assertEquals(project.mapRotationDeg, decoded.mapRotationDeg, 0.0001)
        assertEquals(project.atticHeightM, decoded.atticHeightM, 0.0001)
        assertEquals(project.atticWidthM, decoded.atticWidthM, 0.0001)
        assertEquals(1, decoded.objects.size)
        assertTrue(decoded.roofTopology != null)
    }

    @Test
    fun concaveFootprintProducesValidFace() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 4.0),
                geo(5.0, 4.0), geo(5.0, 9.0), geo(0.0, 9.0)
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.isValid)
        assertEquals(1, preview.faces.size)
    }

    @Test
    fun freehandOutlineIsSmoothedToAtMostTenPoints() {
        val noisyCircle = (0 until 80).map { index ->
            val angle = 2.0 * PI * index / 80.0
            val noise = if (index % 2 == 0) 0.18 else -0.18
            geo((5.0 + noise) * cos(angle), (5.0 + noise) * sin(angle))
        }
        val simplified = FreehandSimplifier.simplify(noisyCircle, minimumDistanceM = 0.05, maxPoints = 10)
        assertTrue(simplified.size in 3..10)
        assertTrue(Geometry.areaM2(simplified) > 50.0)
    }

    @Test
    fun halfHipWithTwoGableSegmentsCreatesThreeValidFaces() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 4.0),
                geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(5.0, 4.0), end = geo(12.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 0.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 8.0))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.GABLE,
                3 to LineType.EAVE,
                4 to LineType.EAVE
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertEquals(3, preview.faces.size)
    }

    @Test
    fun internalCorrectionPreservesNearCornerBoundaryAndProducesRenderableHalfHipPlanes() {
        // Regression for the photographed 76 mm / 183 mm boundary fragments.
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(0.183, 0.0), geo(12.716, 0.0),
                geo(12.716, 6.20), geo(12.716, 12.276), geo(0.076, 12.276),
                geo(0.0, 12.276)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.183, 0.0), end = geo(6.20, 6.08)),
                RoofLine(type = LineType.HIP, start = geo(0.076, 12.236), end = geo(6.20, 6.08)),
                RoofLine(type = LineType.RIDGE, start = geo(6.20, 6.08), end = geo(12.716, 6.20))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE,
                2 to LineType.GABLE, 3 to LineType.GABLE,
                4 to LineType.EAVE, 5 to LineType.EAVE, 6 to LineType.EAVE
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        // The real editor pipeline locks the outline only after card 1 has put
        // it on the shared 50 mm project grid. Card 3 must preserve that exact
        // corrected outline while solving its 25 mm internal grid.
        val migrated = RoofTopologyMigration.fromLegacyProject(project)
        val outline = RoofTopologySolver.solveOutline(migrated)
        assertTrue(
            outline.issues.joinToString { it.code },
            outline.issues.none {
                it.code == "OUTLINE_NODE_OFF_GRID" || it.code == "OUTLINE_EDGE_OFF_45_GRID"
            }
        )
        val correctedOutline = outline.proposed
        val preview = RoofTopologySolver.solveInternal(correctedOutline)
        assertEquals(correctedOutline.edges, preview.proposed.edges)
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val boundaryLengths = preview.proposed.edges.filter { it.boundary }.map { edge ->
            val a = nodes.getValue(edge.startNodeId)
            val b = nodes.getValue(edge.endNodeId)
            kotlin.math.hypot(b.x - a.x, b.y - a.y)
        }
        assertEquals("Card 2 must not rebuild the boundary", 7, boundaryLengths.size)
        assertEquals(0, preview.statistics.createdIntersections)
        assertEquals(0, preview.statistics.splitEdges)
        assertEquals(
            correctedOutline.edges.size,
            preview.proposed.edges.size
        )

        val runtime = RoofTopologySolver.deriveIncidenceFor3D(preview.proposed)
        assertEquals(3, runtime.faces.size)
        val graph = RoofGraphFactory.fromTopology(runtime.proposed)
        val planes = RoofPlaneSolver.solveForRendering(graph, project.wallHeightM, project.slopeDeg)
        assertTrue(planes.issues.joinToString { it.code }, !planes.hasBlockingIssues)
        assertEquals(3, planes.graph.faces.size)
    }

    @Test
    fun gableBoundaryDoesNotPullRidgeEndpointDownToWallHeight() {
        val polygon = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(12.0, 0.0), LocalPoint(12.0, 4.0),
            LocalPoint(12.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val edgeTypes = mapOf(
            0 to LineType.EAVE,
            1 to LineType.GABLE,
            2 to LineType.GABLE,
            3 to LineType.EAVE,
            4 to LineType.EAVE
        )

        val centerDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(5.0, 4.0), polygon, edgeTypes)
        val gableRidgeDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 4.0), polygon, edgeTypes)
        val eaveDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 0.0), polygon, edgeTypes)

        assertEquals(4.0, centerDistance, 0.0001)
        assertEquals(centerDistance, gableRidgeDistance, 0.0001)
        assertEquals(0.0, eaveDistance, 0.0001)
    }

    @Test
    fun noisyRectangleIsRegularizedToParallelOrthogonalSides() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.12, 0.16), geo(12.10, -0.11),
                geo(12.18, 8.13), geo(-0.09, 7.88)
            )
        )

        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertTrue(preview.statistics.regularizedBoundaryNodes > 0)

        val nodeById = preview.proposed.nodes.associateBy { it.id }
        val boundary = preview.proposed.edges.filter { it.boundary }.sortedBy { it.sourceId?.toIntOrNull() ?: 0 }
        val vectors = boundary.map { edge ->
            val a = requireNotNull(nodeById[edge.startNodeId])
            val b = requireNotNull(nodeById[edge.endNodeId])
            (b.x - a.x) to (b.y - a.y)
        }
        fun normalizedCross(first: Pair<Double, Double>, second: Pair<Double, Double>): Double =
            abs(first.first * second.second - first.second * second.first) /
                (kotlin.math.hypot(first.first, first.second) * kotlin.math.hypot(second.first, second.second))
        fun normalizedDot(first: Pair<Double, Double>, second: Pair<Double, Double>): Double =
            abs(first.first * second.first + first.second * second.second) /
                (kotlin.math.hypot(first.first, first.second) * kotlin.math.hypot(second.first, second.second))

        assertTrue(
            "Opposite sides must be parallel: ${normalizedCross(vectors[0], vectors[2])}; $vectors",
            normalizedCross(vectors[0], vectors[2]) < 1e-6
        )
        assertTrue(
            "Opposite sides must be parallel: ${normalizedCross(vectors[1], vectors[3])}; $vectors",
            normalizedCross(vectors[1], vectors[3]) < 1e-6
        )
        assertTrue(
            "Adjacent sides must be perpendicular: ${normalizedDot(vectors[0], vectors[1])}; $vectors",
            normalizedDot(vectors[0], vectors[1]) < 1e-6
        )
    }

    @Test
    fun connectedHipLinesBecomeExactFortyFiveDegreesAndStayTopological() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.08, 0.10), geo(12.12, -0.07),
                geo(12.08, 8.09), geo(-0.11, 7.92)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(5.7, 4.15), end = geo(12.08, 4.02)),
                RoofLine(type = LineType.HIP, start = geo(5.7, 4.15), end = geo(-0.08, 0.10)),
                RoofLine(type = LineType.HIP, start = geo(5.7, 4.15), end = geo(-0.11, 7.92))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.EAVE
            )
        )

        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertTrue(preview.statistics.alignedHipValleyNodes >= 1)
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val boundaryNodeIds = preview.proposed.edges.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        preview.proposed.edges.filter { it.type == LineType.HIP && !it.boundary }.forEach { hip ->
            val anchorId = listOf(hip.startNodeId, hip.endNodeId).single { it in boundaryNodeIds }
            val mobileId = if (hip.startNodeId == anchorId) hip.endNodeId else hip.startNodeId
            val anchor = requireNotNull(nodes[anchorId])
            val mobile = requireNotNull(nodes[mobileId])
            val connectedEave = preview.proposed.edges.first {
                it.boundary && it.type == LineType.EAVE &&
                    (it.startNodeId == anchorId || it.endNodeId == anchorId)
            }
            val eaveOtherId = if (connectedEave.startNodeId == anchorId) connectedEave.endNodeId else connectedEave.startNodeId
            val eaveOther = requireNotNull(nodes[eaveOtherId])
            val hipAngle = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
            val eaveAngle = atan2(eaveOther.y - anchor.y, eaveOther.x - anchor.x)
            var difference = abs((hipAngle - eaveAngle) % PI)
            difference = minOf(difference, PI - difference)
            // A strict 100 mm square lattice cannot represent every diagonal
            // intersection exactly; the nearest lattice node stays within one cell.
            assertEquals(PI / 4.0, difference, Math.toRadians(1.0))
            assertTrue("HIP must share a real boundary node", hip.startNodeId == anchorId || hip.endNodeId == anchorId)
        }
    }

    @Test
    fun safeCorrectionsCanBeAppliedBeforeAnUnconnectedLineIsFinished() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.1, 0.1), geo(10.1, -0.1),
                geo(10.0, 8.1), geo(0.1, 7.9)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(3.0, 4.0), end = geo(7.0, 4.1))
            )
        )
        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue("A deliberately unfinished ridge must remain detectable", !preview.isValid)

        val strictCopy = ProjectJson.decode(ProjectJson.encode(project))
        assertTrue(!RoofTopologyMigration.applyToProject(strictCopy, preview.proposed).applied)

        val result = RoofTopologyMigration.applyToProject(
            project, preview.proposed, requireFullyValid = false
        )
        assertTrue(result.applied)
        assertEquals(4, project.polygon.size)
        assertEquals(1, project.lines.size)
    }

    @Test
    fun unequalLWingWidthsShiftConnectedRidgeWithoutChangingTopology() {
        val nodes = listOf(
            TopologyNode("b0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b1", 14.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b2", 14.0, 6.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b3", 5.0, 6.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b4", 5.0, 13.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b5", 0.0, 13.0, TopologyNodeType.FOOTPRINT),
            // Different arm widths put the two ridge axes at y=3.0 and x=2.5.
            TopologyNode("main", 2.7, 3.2, TopologyNodeType.JUNCTION),
            TopologyNode("wing", 2.4, 10.4, TopologyNodeType.JUNCTION)
        )
        val boundary = listOf("b0", "b1", "b2", "b3", "b4", "b5")
        val edges = boundary.indices.map { index ->
            TopologyEdge(
                id = "e$index", startNodeId = boundary[index],
                endNodeId = boundary[(index + 1) % boundary.size],
                type = LineType.EAVE, boundary = true
            )
        } + listOf(
            TopologyEdge("hip-main", "b0", "main", LineType.HIP, boundary = false),
            TopologyEdge("ridge-link", "main", "wing", LineType.RIDGE, boundary = false),
            TopologyEdge("hip-wing", "b4", "wing", LineType.HIP, boundary = false)
        )
        val input = RoofTopology(origin, nodes, edges)
        val preview = RoofTopologySolver.solveInternal(input)
        val result = preview.proposed.nodes.associateBy { it.id }
        val main = result.getValue("main")
        val wing = result.getValue("wing")

        assertEquals(input.nodes.size, preview.proposed.nodes.size)
        assertEquals(input.edges.size, preview.proposed.edges.size)
        assertEquals(0, preview.statistics.createdIntersections)
        assertEquals(0, preview.statistics.splitEdges)
        assertTrue(abs(main.x - main.y) < abs(2.7 - 3.2))
        assertTrue(abs(main.x - wing.x) < abs(2.7 - 2.4))
        assertTrue(preview.statistics.alignedHipValleyNodes >= 2)
        assertTrue(preview.statistics.alignedRidgeNodes >= 1)
    }

    @Test
    fun outlineCorrectionDoesNotMoveRidgeOrTractGeometry() {
        val nodes = listOf(
            TopologyNode("tl", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ts", 4.20, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("tr", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("br", 8.0, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bs", 3.75, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bl", 0.0, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ridge-top", 4.18, 0.02, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("ridge-bottom", 3.76, 13.98, TopologyNodeType.LINE_ENDPOINT)
        )
        val boundary = listOf("tl", "ts", "tr", "br", "bs", "bl")
        val edges = boundary.indices.map { index ->
            TopologyEdge(
                "boundary-$index", boundary[index], boundary[(index + 1) % boundary.size],
                if (index in setOf(0, 1, 3, 4)) LineType.GABLE else LineType.EAVE,
                boundary = true
            )
        } + TopologyEdge(
            "ridge", "ridge-top", "ridge-bottom", LineType.RIDGE, boundary = false
        )

        val preview = RoofTopologySolver.solveOutline(RoofTopology(origin, nodes, edges))
        val result = preview.proposed.nodes.associateBy { it.id }

        assertEquals(4.20, result.getValue("ts").x, 1e-9)
        assertEquals(3.75, result.getValue("bs").x, 1e-9)
        assertEquals(4.18, result.getValue("ridge-top").x, 1e-9)
        assertEquals(3.76, result.getValue("ridge-bottom").x, 1e-9)
        assertEquals(0, preview.statistics.alignedRidgeNodes)
        assertEquals(112.0, abs(preview.faces.sumOf { it.signedAreaM2 }), 1e-8)
    }

    @Test
    fun outlineCorrectionPreservesDeliberatelyAsymmetricOrTriangularGeometry() {
        val nodes = listOf(
            TopologyNode("tl", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("split", 4.75, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("tr", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("br", 8.0, 10.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bl", 0.0, 10.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ridge-start", 4.75, 0.0, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("ridge-end", 4.75, 8.0, TopologyNodeType.LINE_ENDPOINT)
        )
        val boundary = listOf("tl", "split", "tr", "br", "bl")
        val edges = boundary.indices.map { index ->
            TopologyEdge("boundary-$index", boundary[index], boundary[(index + 1) % boundary.size], LineType.EAVE, boundary = true)
        } + TopologyEdge("ridge", "ridge-start", "ridge-end", LineType.RIDGE, boundary = false)

        val preview = RoofTopologySolver.solveOutline(RoofTopology(origin, nodes, edges))
        val result = preview.proposed.nodes.associateBy { it.id }
        val ridge = preview.proposed.edges.first { it.id == "ridge" }

        assertEquals(4.75, result.getValue("split").x, 1e-9)
        // Card 1 owns only the footprint. An already drawn ridge remains byte-for-byte
        // untouched; its incidence is resolved by the internal-line correction step.
        assertEquals("ridge-start", ridge.startNodeId)
        assertEquals(4.75, result.getValue("ridge-start").x, 1e-9)
        assertEquals(0, preview.statistics.alignedRidgeNodes)
    }

    @Test
    fun outlineCorrectionCreatesSharedNodeAtRealBoundaryIntersection() {
        val nodes = listOf(
            TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b", 6.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("c", 6.0, 4.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("d", 0.0, 4.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ridge-boundary", 3.0, 0.0, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("ridge-inner", 3.0, 2.0, TopologyNodeType.LINE_ENDPOINT)
        )
        val edges = listOf(
            TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true),
            TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true),
            TopologyEdge("cd", "c", "d", LineType.EAVE, boundary = true),
            TopologyEdge("da", "d", "a", LineType.GABLE, boundary = true),
            TopologyEdge("ridge", "ridge-boundary", "ridge-inner", LineType.RIDGE)
        )
        val original = RoofTopology(origin, nodes, edges, gridRotationDeg = 0.0)

        val preview = RoofTopologySolver.solveOutline(original)
        val boundaryIds = preview.proposed.edges.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        val correctedRidge = preview.proposed.edges.first { it.id == "ridge" }

        // Correcting the outline must not split it because of an internal ridge.
        assertTrue(correctedRidge.startNodeId !in boundaryIds)
        assertEquals("ridge-boundary", correctedRidge.startNodeId)
        assertEquals(0, preview.statistics.splitEdges)

        val project = RoofProject(
            polygon = listOf(
                LocalPoint(0.0, 0.0), LocalPoint(6.0, 0.0),
                LocalPoint(6.0, 4.0), LocalPoint(0.0, 4.0)
            ).map { Geometry.toGeo(it, origin) }.toMutableList(),
            roofTopology = original,
            roofGraph = RoofGraphFactory.fromTopology(original)
        )
        val applied = ProjectGeometryCorrection.apply(project, preview, allowBoundaryChanges = true)
        assertTrue(applied.issues.joinToString(), applied.applied)
        assertEquals(4, project.polygon.size)
    }

    @Test
    fun internalCorrectionNeverMovesOppositeGableBoundaryNodes() {
        val nodes = listOf(
            TopologyNode("tl", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ts", 3.20, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("tr", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("br", 8.0, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bs", 3.28, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bl", 0.0, 14.0, TopologyNodeType.FOOTPRINT)
        )
        val boundary = listOf("tl", "ts", "tr", "br", "bs", "bl")
        val edges = boundary.indices.map { index ->
            TopologyEdge(
                "boundary-$index", boundary[index], boundary[(index + 1) % boundary.size],
                if (index in setOf(0, 1, 3, 4)) LineType.GABLE else LineType.EAVE,
                boundary = true
            )
        } + TopologyEdge("ridge", "ts", "bs", LineType.RIDGE, boundary = false)

        val original = RoofTopology(origin, nodes, edges)
        val preview = RoofTopologySolver.solveInternal(original)
        val result = preview.proposed.nodes.associateBy { it.id }

        assertEquals(3.2, result.getValue("ts").x, 1e-9)
        assertEquals(3.28, result.getValue("bs").x, 1e-9)
        assertEquals(0.4, result.getValue("ts").x / 8.0, 1e-9)
        assertEquals(original.nodes.map { it.id }.toSet(), preview.proposed.nodes.map { it.id }.toSet())
        assertEquals(original.edges.map { it.id }.toSet(), preview.proposed.edges.map { it.id }.toSet())
        val boundaryIds = original.edges.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        assertEquals(
            original.nodes.filter { it.id in boundaryIds },
            preview.proposed.nodes.filter { it.id in boundaryIds }
        )
        assertEquals(original.edges.filter { it.boundary }, preview.proposed.edges.filter { it.boundary })
    }

    @Test
    fun internalCorrectionPreservesThreeDistinctAuthoredLineEnds() {
        val nodes = listOf(
            TopologyNode("b0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b1", 10.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bm", 10.0, 4.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b2", 10.0, 8.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b3", 0.0, 8.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("j1", 4.10, 3.95, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("j2", 3.95, 4.10, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("j3", 4.05, 4.00, TopologyNodeType.LINE_ENDPOINT)
        )
        val edges = listOf(
            TopologyEdge("e0", "b0", "b1", LineType.EAVE, boundary = true),
            TopologyEdge("e1", "b1", "bm", LineType.EAVE, boundary = true),
            TopologyEdge("e2", "bm", "b2", LineType.EAVE, boundary = true),
            TopologyEdge("e3", "b2", "b3", LineType.EAVE, boundary = true),
            TopologyEdge("e4", "b3", "b0", LineType.EAVE, boundary = true),
            TopologyEdge("hip-bottom", "b0", "j1", LineType.HIP),
            TopologyEdge("hip-top", "b3", "j2", LineType.HIP),
            TopologyEdge("ridge", "j3", "bm", LineType.RIDGE)
        )
        val preview = RoofTopologySolver.solveInternal(
            RoofTopology(origin, nodes, edges, gridRotationDeg = 0.0)
        )
        assertEquals(nodes.map { it.id }, preview.proposed.nodes.map { it.id })
        assertEquals(edges, preview.proposed.edges)
        assertEquals(
            setOf("j1", "j2", "j3"),
            preview.proposed.nodes.map { it.id }.filter { it.startsWith("j") }.toSet()
        )
        assertEquals(0, preview.statistics.mergedNodes)
        assertEquals(0, preview.statistics.createdIntersections)
        assertEquals(0, preview.statistics.splitEdges)
        assertEquals(0, preview.statistics.removedShortEdges)
        assertEquals(0, preview.statistics.removedDuplicateEdges)
    }

    @Test
    fun projectJsonNeverLetsStaleRuntimeGraphReplaceAuthoredInternalLines() {
        val authored = RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("b0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b1", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b2", 8.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b3", 0.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("r0", 0.0, 3.0, TopologyNodeType.LINE_ENDPOINT),
                TopologyNode("r1", 8.0, 3.0, TopologyNodeType.LINE_ENDPOINT)
            ),
            edges = listOf(
                TopologyEdge("e0", "b0", "b1", LineType.EAVE, boundary = true),
                TopologyEdge("e1", "b1", "b2", LineType.GABLE, boundary = true),
                TopologyEdge("e2", "b2", "b3", LineType.EAVE, boundary = true),
                TopologyEdge("e3", "b3", "b0", LineType.GABLE, boundary = true),
                TopologyEdge("authored-ridge", "r0", "r1", LineType.RIDGE, note = "keep")
            ),
            gridRotationDeg = 0.0
        )
        val staleRuntime = RoofGraphFactory.fromTopology(
            authored.copy(
                nodes = authored.nodes.filterNot { it.id.startsWith("r") },
                edges = authored.edges.filterNot { it.id == "authored-ridge" }
            ),
            normalizeGrid = false
        )
        val project = RoofProject(
            polygon = listOf(geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 6.0), geo(0.0, 6.0)).toMutableList(),
            roofTopology = authored,
            roofGraph = staleRuntime
        )

        val restored = ProjectJson.decode(ProjectJson.encode(project))
        val restoredTopology = requireNotNull(restored.roofTopology)
        val ridge = restoredTopology.edges.single { it.id == "authored-ridge" }

        assertEquals("r0", ridge.startNodeId)
        assertEquals("r1", ridge.endNodeId)
        assertEquals(LineType.RIDGE, ridge.type)
        assertEquals("keep", ridge.note)
        assertTrue(requireNotNull(restored.roofGraph).edges.containsKey("authored-ridge"))
        assertEquals(1, restored.lines.count { it.id == "authored-ridge" })
    }
}
