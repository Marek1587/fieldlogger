package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Applies one plan deformation to every project representation that owns XY geometry.
 * RoofGraph remains canonical; polygon, wall footprint and technical objects are mirrors.
 */
object ProjectPlanSynchronizer {
    fun apply(
        project: RoofProject,
        beforeGraph: RoofGraph,
        afterGraph: RoofGraph,
        sourceWallFootprint: List<GeoPoint> = project.wallFootprint.map(GeoPoint::copy),
        sourceObjects: List<RoofObject> = project.objects.map { it.copy(center = it.center.copy()) },
        normalizeBoundaryGrid: Boolean = true
    ): Boolean {
        val sourcePolygon = project.polygon.map(GeoPoint::copy)
        val sourceEdgeTypes = project.edgeTypes.toMap()
        val sourceLineOrder = project.lines.map(RoofLine::id)
        val sourceParts = project.wallFootprintParts.map { part ->
            part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
        }.toMutableList()
        val sourcePartsSignature = project.wallFootprintPartsSignature
        val beforeBoundary = boundaryNodes(beforeGraph) ?: return false
        val afterBoundary = boundaryNodes(afterGraph) ?: return false
        val afterBoundaryById = afterBoundary.associateBy { it.id }
        // Card 1 may create a real incidence node where an existing internal line ends on
        // the middle of a footprint edge. All original footprint vertices must survive,
        // but the corrected cycle is allowed to contain additional split vertices.
        if (beforeBoundary.any { it.id !in afterBoundaryById }) return false

        val displacementById = beforeBoundary.associate { before ->
            val after = afterBoundaryById.getValue(before.id)
            before.id to LocalPoint(after.x - before.x, after.y - before.y)
        }
        val boundaryGeometryChanged = displacementById.values.any { delta ->
            abs(delta.x) > 1e-10 || abs(delta.y) > 1e-10
        }
        // A line ending on the middle of a footprint edge creates a legitimate extra
        // boundary vertex even when no old corner moved. Treat this as a boundary change,
        // otherwise the legacy polygon mirror would be restored from its old unsplit copy
        // and the shared incidence would be lost immediately after confirmation.
        val boundaryTopologyChanged = beforeBoundary.size != afterBoundary.size
        val boundaryChanged = boundaryGeometryChanged || boundaryTopologyChanged
        val transformedWalls = if (boundaryChanged) {
            transformLoop(sourceWallFootprint, beforeGraph.origin, beforeBoundary, displacementById)
        } else sourceWallFootprint.map(GeoPoint::copy)
        val transformedObjects = if (boundaryChanged) {
            sourceObjects.map { item ->
                item.copy(center = transformPoint(item.center, beforeGraph.origin, beforeBoundary, displacementById))
            }
        } else sourceObjects.map { it.copy(center = it.center.copy()) }
        val transformedParts = if (boundaryChanged) {
            sourceParts.map { part ->
                part.copy(
                    polygon = part.polygon.map { point ->
                        transformPoint(point, beforeGraph.origin, beforeBoundary, displacementById)
                    }.toMutableList()
                )
            }.toMutableList()
        } else sourceParts

        val applied = RoofTopologyMigration.applyToProject(
            project,
            afterGraph.toTopology(),
            requireFullyValid = false,
            normalizeGrid = normalizeBoundaryGrid
        )
        if (!applied.applied) return false
        project.roofGraph = afterGraph
        project.roofTopology = afterGraph.toTopology()
        if (!boundaryChanged) {
            // Card 3 owns only internal topology. Avoid even a GeoPoint round-trip: the confirmed
            // physical outline stays byte-for-byte identical, including point order.
            project.polygon = sourcePolygon.toMutableList()
            // edgeTypes is indexed by the legacy polygon order, whereas applyToProject() emits
            // the canonical boundary-cycle order. Replacing one without the other silently
            // assigns a gable/eave meaning to another physical wall on clockwise or cyclically
            // shifted drawings. Internal correction owns neither representation.
            project.edgeTypes = sourceEdgeTypes.toMutableMap()
            // applyToProject() sorts graph edges by ID. Preserve the user's stable legacy list
            // order so index-based editor selection cannot jump to another line after correction.
            val orderById = sourceLineOrder.withIndex().associate { (index, id) -> id to index }
            project.lines = project.lines.withIndex()
                .sortedWith(compareBy<IndexedValue<RoofLine>> {
                    orderById[it.value.id] ?: Int.MAX_VALUE
                }.thenBy(IndexedValue<RoofLine>::index))
                .map(IndexedValue<RoofLine>::value)
                .toMutableList()
        }
        // The wall loop is a derived masonry support, not a second editable roof outline.
        // Independent snapping here used to move wall corners after an internal-line edit
        // and made an overhang appear to change the wall cut. It must follow only the
        // canonical boundary displacement calculated above.
        project.wallFootprint = transformedWalls.map(GeoPoint::copy).toMutableList()
        // Keep the semantic regions in the same deformation immediately. The classifier will
        // subsequently rebuild their exact rectangles, while USER meanings survive by proximity.
        project.wallFootprintParts = transformedParts
        project.wallFootprintPartsSignature = if (boundaryChanged) "" else sourcePartsSignature
        project.objects = transformedObjects.toMutableList()
        return true
    }

    private fun boundaryNodes(graph: RoofGraph): List<GraphNode>? {
        val ids = RoofTopologyMigration.orderedBoundary(graph.toTopology())?.first ?: return null
        return ids.map { graph.nodes[it] ?: return null }
    }

    private fun transformLoop(
        loop: List<GeoPoint>,
        origin: GeoPoint,
        boundary: List<GraphNode>,
        displacementById: Map<String, LocalPoint>
    ): List<GeoPoint> {
        if (loop.isEmpty()) return emptyList()
        val local = loop.map { Geometry.toLocal(it, origin) }
        if (local.size == boundary.size) {
            val mapping = bestCyclicMapping(local, boundary)
            if (mapping != null) {
                // Emit the wall loop in canonical boundary order. This also keeps the 3D base
                // dimension index attached to the same real graph edge after a cyclic reorder.
                return boundary.indices.map { supportIndex ->
                    val index = mapping.indexOf(supportIndex)
                    val support = boundary[supportIndex]
                    val delta = displacementById.getValue(support.id)
                    Geometry.toGeo(LocalPoint(local[index].x + delta.x, local[index].y + delta.y), origin)
                }
            }
        }
        return loop.map { transformPoint(it, origin, boundary, displacementById) }
    }

    /** Aligns an inset wall loop with the roof corners independent of cyclic start/winding. */
    private fun bestCyclicMapping(local: List<LocalPoint>, boundary: List<GraphNode>): IntArray? {
        if (local.size != boundary.size || local.isEmpty()) return null
        val count = local.size
        var bestScore = Double.POSITIVE_INFINITY
        var best: IntArray? = null
        listOf(1, -1).forEach { direction ->
            for (shift in 0 until count) {
                val mapping = IntArray(count) { index ->
                    ((shift + direction * index) % count + count) % count
                }
                val score = local.indices.sumOf { index ->
                    val support = boundary[mapping[index]]
                    hypot(local[index].x - support.x, local[index].y - support.y)
                }
                if (score < bestScore) {
                    bestScore = score
                    best = mapping
                }
            }
        }
        return best
    }

    private fun transformPoint(
        point: GeoPoint,
        origin: GeoPoint,
        boundary: List<GraphNode>,
        displacementById: Map<String, LocalPoint>
    ): GeoPoint {
        val local = Geometry.toLocal(point, origin)
        var totalWeight = 0.0
        var dx = 0.0
        var dy = 0.0
        boundary.forEach { support ->
            val distance2 = (local.x - support.x) * (local.x - support.x) +
                (local.y - support.y) * (local.y - support.y)
            if (distance2 < 1e-10) {
                val exact = displacementById.getValue(support.id)
                return Geometry.toGeo(LocalPoint(local.x + exact.x, local.y + exact.y), origin)
            }
            val weight = 1.0 / distance2.coerceAtLeast(0.01)
            val delta = displacementById.getValue(support.id)
            totalWeight += weight
            dx += delta.x * weight
            dy += delta.y * weight
        }
        if (totalWeight > 0.0) {
            dx /= totalWeight
            dy /= totalWeight
        }
        return Geometry.toGeo(LocalPoint(local.x + dx, local.y + dy), origin)
    }
}
