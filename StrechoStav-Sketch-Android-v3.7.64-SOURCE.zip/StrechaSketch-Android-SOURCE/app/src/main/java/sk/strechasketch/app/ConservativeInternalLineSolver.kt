package sk.strechasketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Correction used exclusively by card 2 (internal roof lines).
 *
 * The operation is deliberately topology preserving: it never creates an edge
 * or a node and never splits, removes, reconnects or retypes an edge. It may only
 * move the XY coordinate of an existing internal node. Boundary geometry is
 * immutable.  This makes the preview deterministic and prevents a correction
 * intended for drawing cleanup from silently redesigning the roof graph.
 */
object ConservativeInternalLineSolver {
    private data class DesiredPoint(val x: Double, val y: Double, val reason: String)
    private data class LinearConstraint(val coefficients: DoubleArray, val value: Double, val weight: Double)

    fun solve(
        input: RoofTopology,
        angleToleranceDeg: Double = 10.0,
        maximumLengthChangeFraction: Double = 0.10,
        snapToleranceM: Double = 0.35,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofSolverPreview {
        // Kept for source compatibility. Endpoint merging is intentionally forbidden.
        @Suppress("UNUSED_VARIABLE") val retainedSnapTolerance = snapToleranceM
        val original = input.copy(
            origin = input.origin.copy(),
            nodes = input.nodes.map { it.copy() },
            edges = input.edges.map { it.copy() }
        )
        val nodes = input.nodes.associateBy { it.id }.toMutableMap()
        val edges = input.edges.associateBy { it.id }.toMutableMap()
        val boundaryNodeIds = input.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val originalPositions = input.nodes.associate { it.id to (it.x to it.y) }
        val originalLengths = input.edges.associate { edge ->
            val a = input.nodes.first { it.id == edge.startNodeId }
            val b = input.nodes.first { it.id == edge.endNodeId }
            edge.id to hypot(b.x - a.x, b.y - a.y)
        }
        val movements = mutableListOf<NodeMovement>()
        val alignedHipValley = mutableSetOf<String>()
        val alignedRidge = mutableSetOf<String>()

        fun incidentInternal(nodeId: String): List<TopologyEdge> = edges.values.filter {
            !it.boundary && (it.startNodeId == nodeId || it.endNodeId == nodeId)
        }

        fun movementLimit(nodeId: String): Double {
            val shortest = incidentInternal(nodeId).mapNotNull { originalLengths[it.id] }
                .filter { it > 1e-9 }.minOrNull() ?: return 0.0
            // Rotation around an edge midpoint preserves length although both
            // nodes travel. The actual edge-length bound is enforced below.
            return shortest * maximumLengthChangeFraction
        }

        repeat(6) {
            val desired = mutableMapOf<String, MutableList<DesiredPoint>>()
            val boundaryDirections = edges.values.filter { it.boundary }.mapNotNull { edge ->
                val a = nodes[edge.startNodeId] ?: return@mapNotNull null
                val b = nodes[edge.endNodeId] ?: return@mapNotNull null
                if (hypot(b.x - a.x, b.y - a.y) < 1e-9) null
                else Triple(edge, atan2(b.y - a.y, b.x - a.x), edge.type == LineType.EAVE)
            }

            fun supportsFor(a: TopologyNode, b: TopologyNode) = boundaryDirections.filter { (support, _, _) ->
                val supportA = nodes[support.startNodeId] ?: return@filter false
                val supportB = nodes[support.endNodeId] ?: return@filter false
                footprintContext?.sameStructuralPart(
                    (a.x + b.x) / 2.0,
                    (a.y + b.y) / 2.0,
                    (supportA.x + supportB.x) / 2.0,
                    (supportA.y + supportB.y) / 2.0
                ) != false
            }

            edges.values.sortedBy { it.id }.filterNot { it.boundary }.forEach { edge ->
                val a = nodes[edge.startNodeId] ?: return@forEach
                val b = nodes[edge.endNodeId] ?: return@forEach
                val length = hypot(b.x - a.x, b.y - a.y)
                if (length < 1e-9) return@forEach
                val raw = atan2(b.y - a.y, b.x - a.x)
                when (edge.type) {
                    LineType.RIDGE -> {
                        val target = supportsFor(a, b)
                            .minByOrNull { angularDistance(raw, it.second) }?.second
                            ?: return@forEach
                        if (Math.toDegrees(angularDistance(raw, target)) > angleToleranceDeg + 1e-9) return@forEach
                        var dx = cos(target)
                        var dy = sin(target)
                        if (dx * (b.x - a.x) + dy * (b.y - a.y) < 0.0) { dx = -dx; dy = -dy }
                        val midX = (a.x + b.x) / 2.0
                        val midY = (a.y + b.y) / 2.0
                        if (a.id !in boundaryNodeIds && !a.locked) desired.getOrPut(a.id) { mutableListOf() } +=
                            DesiredPoint(midX - dx * length / 2.0, midY - dy * length / 2.0, "RIDGE_PARALLEL_TO_BOUNDARY")
                        if (b.id !in boundaryNodeIds && !b.locked) desired.getOrPut(b.id) { mutableListOf() } +=
                            DesiredPoint(midX + dx * length / 2.0, midY + dy * length / 2.0, "RIDGE_PARALLEL_TO_BOUNDARY")
                        alignedRidge += edge.id
                    }

                    LineType.HIP, LineType.VALLEY -> {
                        val anchor: TopologyNode
                        val mobile: TopologyNode
                        if (a.id in boundaryNodeIds && b.id !in boundaryNodeIds) {
                            anchor = a; mobile = b
                        } else if (b.id in boundaryNodeIds && a.id !in boundaryNodeIds) {
                            anchor = b; mobile = a
                        } else return@forEach
                        if (mobile.locked) return@forEach
                        val supports = boundaryDirections.filter { (support, _, _) ->
                            support.startNodeId == anchor.id || support.endNodeId == anchor.id
                        }.let { incident ->
                            val eaves = incident.filter { it.third }
                            if (eaves.isNotEmpty()) eaves else incident
                        }
                        val candidates = supports.flatMap { (_, direction, _) ->
                            listOf(direction + PI / 4.0, direction - PI / 4.0)
                        }
                        val mobileRaw = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
                        val target = candidates.minByOrNull { angularDistance(mobileRaw, it) } ?: return@forEach
                        if (Math.toDegrees(angularDistance(mobileRaw, target)) > angleToleranceDeg + 1e-9) return@forEach
                        var dx = cos(target)
                        var dy = sin(target)
                        if (dx * (mobile.x - anchor.x) + dy * (mobile.y - anchor.y) < 0.0) { dx = -dx; dy = -dy }
                        desired.getOrPut(mobile.id) { mutableListOf() } += DesiredPoint(
                            anchor.x + dx * length,
                            anchor.y + dy * length,
                            "${edge.type.name}_45_DEGREES_TO_BOUNDARY"
                        )
                        alignedHipValley += edge.id
                    }

                    else -> Unit
                }
            }

            var movedAny = false
            desired.toSortedMap().forEach { (nodeId, targets) ->
                val node = nodes[nodeId] ?: return@forEach
                if (nodeId in boundaryNodeIds || node.locked || targets.isEmpty()) return@forEach
                val wantedX = targets.map { it.x }.average()
                val wantedY = targets.map { it.y }.average()
                val dx = wantedX - node.x
                val dy = wantedY - node.y
                val distance = hypot(dx, dy)
                val original = originalPositions[nodeId] ?: (node.x to node.y)
                val maxFromOriginal = movementLimit(nodeId)
                if (distance < 1e-8 || maxFromOriginal <= 0.0) return@forEach
                var nextX = wantedX
                var nextY = wantedY
                val fromOriginalX = nextX - original.first
                val fromOriginalY = nextY - original.second
                val fromOriginalDistance = hypot(fromOriginalX, fromOriginalY)
                if (fromOriginalDistance > maxFromOriginal) {
                    nextX = original.first + fromOriginalX / fromOriginalDistance * maxFromOriginal
                    nextY = original.second + fromOriginalY / fromOriginalDistance * maxFromOriginal
                }
                if (hypot(nextX - node.x, nextY - node.y) > 1e-8) {
                    nodes[nodeId] = node.copy(x = nextX, y = nextY)
                    movedAny = true
                }
            }
            if (!movedAny) return@repeat
        }

        /*
         * Coupled L-wing pass, equivalent to the canonical-axis branch in the PHP solver.
         * A wider secondary wing is not clipped: HIP/VALLEY support lines and all connected
         * ridges are solved as one network. Exchanging the dominant axes therefore produces
         * the same result automatically, while node/edge IDs and the drawn topology remain
         * untouched. This is important for saved projects and parametric dimensions.
         */
        run {
            val structural = edges.values.filter {
                !it.boundary && it.type in setOf(LineType.RIDGE, LineType.HIP, LineType.VALLEY)
            }
            val unknownIds = structural.asSequence()
                .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
                .distinct().filter { id -> id !in boundaryNodeIds && nodes[id]?.locked != true }
                .sorted().toList()
            val hasCoupledInternalRidge = structural.any { edge ->
                edge.type == LineType.RIDGE && edge.startNodeId in unknownIds && edge.endNodeId in unknownIds
            }
            if (unknownIds.isNotEmpty() && hasCoupledInternalRidge) {
                val variableIndex = unknownIds.withIndex().associate { it.value to it.index * 2 }
                val variableCount = unknownIds.size * 2
                val constraints = mutableListOf<LinearConstraint>()
                fun addConstraint(terms: List<Triple<String, Double, Double>>, value: Double, weight: Double) {
                    val coefficients = DoubleArray(variableCount)
                    var adjustedValue = value
                    terms.forEach { (nodeId, cx, cy) ->
                        val index = variableIndex[nodeId]
                        val node = nodes[nodeId] ?: return@forEach
                        if (index == null) adjustedValue -= cx * node.x + cy * node.y
                        else {
                            coefficients[index] += cx
                            coefficients[index + 1] += cy
                        }
                    }
                    if (coefficients.any { abs(it) > 1e-12 }) {
                        constraints += LinearConstraint(coefficients, adjustedValue, weight)
                    }
                }

                val boundaryDirections = edges.values.filter { it.boundary }.mapNotNull { edge ->
                    val a = nodes[edge.startNodeId] ?: return@mapNotNull null
                    val b = nodes[edge.endNodeId] ?: return@mapNotNull null
                    val length = hypot(b.x - a.x, b.y - a.y)
                    if (length <= 1e-9) null else Triple(edge, atan2(b.y - a.y, b.x - a.x), length)
                }

                fun supportsFor(a: TopologyNode, b: TopologyNode) = boundaryDirections.filter { (support, _, _) ->
                    val supportA = nodes[support.startNodeId] ?: return@filter false
                    val supportB = nodes[support.endNodeId] ?: return@filter false
                    footprintContext?.sameStructuralPart(
                        (a.x + b.x) / 2.0,
                        (a.y + b.y) / 2.0,
                        (supportA.x + supportB.x) / 2.0,
                        (supportA.y + supportB.y) / 2.0
                    ) != false
                }

                structural.sortedBy { it.id }.forEach { edge ->
                    val a = nodes[edge.startNodeId] ?: return@forEach
                    val b = nodes[edge.endNodeId] ?: return@forEach
                    val raw = atan2(b.y - a.y, b.x - a.x)
                    when (edge.type) {
                        LineType.HIP, LineType.VALLEY -> {
                            val anchor = when {
                                a.id in boundaryNodeIds && b.id !in boundaryNodeIds -> a
                                b.id in boundaryNodeIds && a.id !in boundaryNodeIds -> b
                                else -> return@forEach
                            }
                            val mobile = if (anchor.id == a.id) b else a
                            if (mobile.id !in variableIndex) return@forEach
                            val incident = boundaryDirections.filter { (support, _, _) ->
                                support.startNodeId == anchor.id || support.endNodeId == anchor.id
                            }
                            val preferred = incident.filter { it.first.type == LineType.EAVE }
                                .ifEmpty { incident }
                            val candidates = preferred.flatMap { (_, direction, _) ->
                                listOf(direction + PI / 4.0, direction - PI / 4.0)
                            }
                            val target = candidates.minByOrNull { angularDistance(raw, it) } ?: return@forEach
                            if (Math.toDegrees(angularDistance(raw, target)) > angleToleranceDeg + 1e-9) return@forEach
                            var dx = cos(target); var dy = sin(target)
                            if (dx * (mobile.x - anchor.x) + dy * (mobile.y - anchor.y) < 0.0) {
                                dx = -dx; dy = -dy
                            }
                            // Point-on-line equation n.p = n.anchor.
                            val nx = -dy; val ny = dx
                            addConstraint(
                                listOf(Triple(mobile.id, nx, ny)),
                                nx * anchor.x + ny * anchor.y,
                                1_000_000.0
                            )
                            alignedHipValley += edge.id
                        }
                        LineType.RIDGE -> {
                            val target = supportsFor(a, b).minByOrNull { angularDistance(raw, it.second) }
                                ?.second ?: return@forEach
                            if (Math.toDegrees(angularDistance(raw, target)) > angleToleranceDeg + 1e-9) return@forEach
                            val nx = -sin(target); val ny = cos(target)
                            // n.(B-A)=0 keeps the complete ridge network parallel after a
                            // junction moves because one L wing is wider than the other.
                            addConstraint(
                                listOf(
                                    Triple(a.id, -nx, -ny),
                                    Triple(b.id, nx, ny)
                                ),
                                0.0,
                                1_000_000.0
                            )
                            alignedRidge += edge.id
                        }
                        else -> Unit
                    }
                }
                // Weak positional priors make underdetermined networks deterministic without
                // defeating the geometric support lines above.
                unknownIds.forEach { nodeId ->
                    val original = originalPositions[nodeId] ?: return@forEach
                    addConstraint(listOf(Triple(nodeId, 1.0, 0.0)), original.first, 1.0)
                    addConstraint(listOf(Triple(nodeId, 0.0, 1.0)), original.second, 1.0)
                }
                solveLeastSquares(variableCount, constraints)?.let { solution ->
                    unknownIds.forEach { nodeId ->
                        val node = nodes[nodeId] ?: return@forEach
                        val original = originalPositions[nodeId] ?: return@forEach
                        val index = variableIndex.getValue(nodeId)
                        var dx = solution[index] - original.first
                        var dy = solution[index + 1] - original.second
                        val movement = hypot(dx, dy)
                        val limit = movementLimit(nodeId)
                        if (limit <= 0.0 || movement <= 1e-9) return@forEach
                        if (movement > limit) {
                            dx *= limit / movement
                            dy *= limit / movement
                        }
                        nodes[nodeId] = node.copy(x = original.first + dx, y = original.second + dy)
                    }
                }
            }
        }

        // Enforce the contractual ±10% edge-length envelope after all shared
        // junction compromises. No topology or IDs are changed here.
        repeat(4) {
            edges.values.sortedBy { it.id }.filterNot { it.boundary }.forEach { edge ->
                val originalLength = originalLengths[edge.id]?.takeIf { it > 1e-9 } ?: return@forEach
                val a = nodes[edge.startNodeId] ?: return@forEach
                val b = nodes[edge.endNodeId] ?: return@forEach
                val currentLength = hypot(b.x - a.x, b.y - a.y)
                if (currentLength < 1e-9) return@forEach
                val boundedLength = currentLength.coerceIn(
                    originalLength * (1.0 - maximumLengthChangeFraction),
                    originalLength * (1.0 + maximumLengthChangeFraction)
                )
                if (abs(currentLength - boundedLength) < 1e-9) return@forEach
                val ux = (b.x - a.x) / currentLength
                val uy = (b.y - a.y) / currentLength
                val aFixed = a.id in boundaryNodeIds || a.locked
                val bFixed = b.id in boundaryNodeIds || b.locked
                when {
                    aFixed && !bFixed -> nodes[b.id] = b.copy(x = a.x + ux * boundedLength, y = a.y + uy * boundedLength)
                    bFixed && !aFixed -> nodes[a.id] = a.copy(x = b.x - ux * boundedLength, y = b.y - uy * boundedLength)
                    !aFixed && !bFixed -> {
                        val midX = (a.x + b.x) / 2.0
                        val midY = (a.y + b.y) / 2.0
                        nodes[a.id] = a.copy(x = midX - ux * boundedLength / 2.0, y = midY - uy * boundedLength / 2.0)
                        nodes[b.id] = b.copy(x = midX + ux * boundedLength / 2.0, y = midY + uy * boundedLength / 2.0)
                    }
                }
            }
        }

        // Restore the complete identity layer from the source drawing. Node type, lock state,
        // ordering and every edge field are user-authored topology, not solver variables.
        val correctedNodes = input.nodes.map { originalNode ->
            if (originalNode.id in boundaryNodeIds) originalNode.copy()
            else nodes[originalNode.id]?.let { corrected ->
                originalNode.copy(x = corrected.x, y = corrected.y)
            } ?: originalNode.copy()
        }
        correctedNodes.forEach { finalNode ->
            val originalNode = input.nodes.firstOrNull { it.id == finalNode.id } ?: return@forEach
            if (hypot(finalNode.x - originalNode.x, finalNode.y - originalNode.y) > 1e-8) {
                movements += NodeMovement(
                    finalNode.id, finalNode.id,
                    originalNode.x, originalNode.y, finalNode.x, finalNode.y,
                    "LIMITED_INTERNAL_GEOMETRY_CORRECTION"
                )
            }
        }
        val proposed = input.copy(
            nodes = correctedNodes,
            edges = input.edges.map { it.copy() }
        )
        return RoofSolverPreview(
            original = original,
            proposed = proposed,
            statistics = RoofSolverStatistics(
                mergedNodes = 0,
                createdIntersections = 0,
                splitEdges = 0,
                snappedFreeEnds = 0,
                removedShortEdges = 0,
                removedDuplicateEdges = 0,
                regularizedBoundaryNodes = 0,
                alignedHipValleyNodes = alignedHipValley.size,
                alignedRidgeNodes = alignedRidge.size
            ),
            movements = movements.distinctBy { listOf(it.sourceNodeId, it.targetNodeId, it.toX, it.toY, it.reason) },
            issues = RoofTopologySolver.validate(proposed),
            faces = RoofTopologySolver.extractFaces(proposed)
        )
    }

    private fun angularDistance(a: Double, b: Double): Double {
        var delta = abs(a - b) % PI
        if (delta > PI / 2.0) delta = PI - delta
        return abs(delta)
    }

    /** Small deterministic normal-equation solver; roof networks have only a handful of nodes. */
    private fun solveLeastSquares(
        variableCount: Int,
        constraints: List<LinearConstraint>
    ): DoubleArray? {
        if (variableCount == 0 || constraints.isEmpty()) return null
        val matrix = Array(variableCount) { DoubleArray(variableCount + 1) }
        constraints.forEach { row ->
            val weight = row.weight.coerceAtLeast(1e-9)
            for (i in 0 until variableCount) {
                val ci = row.coefficients[i]
                if (abs(ci) <= 1e-15) continue
                for (j in 0 until variableCount) {
                    matrix[i][j] += weight * ci * row.coefficients[j]
                }
                matrix[i][variableCount] += weight * ci * row.value
            }
        }
        for (column in 0 until variableCount) {
            val pivot = (column until variableCount).maxByOrNull { abs(matrix[it][column]) } ?: return null
            if (abs(matrix[pivot][column]) < 1e-10) return null
            val swap = matrix[column]; matrix[column] = matrix[pivot]; matrix[pivot] = swap
            val divisor = matrix[column][column]
            for (j in column..variableCount) matrix[column][j] /= divisor
            for (row in 0 until variableCount) {
                if (row == column) continue
                val factor = matrix[row][column]
                if (abs(factor) <= 1e-15) continue
                for (j in column..variableCount) matrix[row][j] -= factor * matrix[column][j]
            }
        }
        return DoubleArray(variableCount) { matrix[it][variableCount] }
            .takeIf { values -> values.all(Double::isFinite) }
    }
}
