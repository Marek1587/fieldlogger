package sk.strechasketch.app

/**
 * Commits one confirmed outline/internal-line correction as one project-wide XY deformation.
 *
 * A correction is not valid when only RoofGraph moves. The masonry footprint, semantic roof
 * tracts and attached technical objects must follow the same node displacement; otherwise the
 * next 3D/IFC preparation receives mutually inconsistent coordinate owners.
 */
object ProjectGeometryCorrection {
    fun apply(
        project: RoofProject,
        preview: RoofSolverPreview,
        allowBoundaryChanges: Boolean = true
    ): TopologyApplyResult {
        // A preview is an optimistic transaction over one exact authored snapshot. Never let a
        // delayed dialog overwrite edits made after that snapshot was prepared.
        val current = RoofTopologyMigration.fromProject(project)
        if (!sameExactAuthoredState(current, preview.original)) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "STALE_SOLVER_PREVIEW",
                        message = "Nákres sa po vytvorení náhľadu zmenil; korekciu treba prepočítať.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }
        if (!allowBoundaryChanges && !sameBoundary(preview.original, preview.proposed)) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "LOCKED_BOUNDARY_CHANGED",
                        message = "Korekcia vnútorných línií sa pokúsila zmeniť uzamknutý obrys.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }
        if (!allowBoundaryChanges && !sameAuthoredTopology(preview.original, preview.proposed)) {
            return topologyMutationRejected()
        }
        val rollback = ProjectGeometryState.capture(project)
        val beforeGraph = RoofGraphFactory.fromTopology(
            preview.original,
            project.roofGraph,
            normalizeGrid = allowBoundaryChanges
        )
        val afterGraph = RoofGraphFactory.fromTopology(
            preview.proposed,
            beforeGraph,
            normalizeGrid = allowBoundaryChanges
        )
        if (!allowBoundaryChanges && !sameAuthoredTopology(
                preview.original,
                afterGraph.toTopology(),
                requireNodeMetadata = false,
                requireEdgeProvenance = false
            )
        ) {
            return topologyMutationRejected()
        }
        if (!ProjectPlanSynchronizer.apply(
                project,
                beforeGraph,
                afterGraph,
                normalizeBoundaryGrid = allowBoundaryChanges
            )
        ) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "PROJECT_PLAN_SYNCHRONIZATION_FAILED",
                        message = "Opravu nemožno bezpečne preniesť do pôdorysu stien a strešných traktov.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }

        // Persist a fresh semantic decomposition now, not lazily during a later 3D screen.
        // This guarantees that JSON/IFC exported directly after correction contains the same XY.
        if (allowBoundaryChanges) {
            WallFootprintSolver.refresh(project, force = true)
        }
        if (!allowBoundaryChanges) {
            // Keep the confirmed card-3 topology itself, not a lossy Graph -> Topology mirror.
            // In particular this retains every boundary edge record exactly and prevents a
            // later legacy migration from re-splitting gables merely for 3D incidence.
            project.roofTopology = preview.proposed.copy(
                nodes = preview.proposed.nodes.map { it.copy() },
                edges = preview.proposed.edges.map { it.copy() }
            )
        } else if (!preview.isValid) {
            project.roofTopology = null
        }
        if (!allowBoundaryChanges) {
            val committed = project.roofTopology
            val lineInventoryMatches = project.lines.map { it.id to it.type }.toSet() ==
                preview.original.edges.filterNot { it.boundary }.map { it.id to it.type }.toSet()
            val sourceLineIds = rollback.lines.map(RoofLine::id)
            val sourceLineIdSet = sourceLineIds.toSet()
            // Some imported projects have a complete topology but an incomplete legacy mirror.
            // Newly materialised mirror lines may be appended; every pre-existing stable ID must
            // nevertheless retain its relative order.
            val lineOrderMatches = project.lines.map(RoofLine::id)
                .filter { it in sourceLineIdSet } == sourceLineIds
            val boundaryMirrorMatches = project.edgeTypes == rollback.edgeTypes
            if (committed == null || !sameAuthoredTopology(preview.original, committed) ||
                !lineInventoryMatches || !lineOrderMatches || !boundaryMirrorMatches
            ) {
                rollback.restore(project)
                return topologyMutationRejected()
            }
        }
        return TopologyApplyResult(true, RoofTopologySolver.validate(afterGraph.toTopology()))
    }

    /** Internal-line correction owns coordinates only, never graph identity or semantics. */
    private fun sameAuthoredTopology(
        original: RoofTopology,
        candidate: RoofTopology,
        requireNodeMetadata: Boolean = true,
        requireEdgeProvenance: Boolean = true
    ): Boolean {
        if (original.origin != candidate.origin || original.schemaVersion != candidate.schemaVersion) return false
        if (original.gridRotationDeg.isFinite() || candidate.gridRotationDeg.isFinite()) {
            if (!original.gridRotationDeg.isFinite() || !candidate.gridRotationDeg.isFinite() ||
                kotlin.math.abs(original.gridRotationDeg - candidate.gridRotationDeg) > 1e-10
            ) return false
        }
        if (original.nodes.map { it.id }.toSet() != candidate.nodes.map { it.id }.toSet()) return false
        if (original.nodes.size != candidate.nodes.size || original.edges.size != candidate.edges.size) return false
        val candidateEdges = candidate.edges.associateBy { it.id }
        if (original.edges.any { source ->
                val result = candidateEdges[source.id]
                result == null || source.startNodeId != result.startNodeId ||
                     source.endNodeId != result.endNodeId || source.type != result.type ||
                     source.locked != result.locked || source.boundary != result.boundary ||
                     (requireEdgeProvenance && source.sourceId != result.sourceId) ||
                     source.note != result.note
             }
        ) return false
        val candidateNodes = candidate.nodes.associateBy { it.id }
        return original.nodes.all { source ->
            val result = candidateNodes[source.id] ?: return@all false
            (!requireNodeMetadata || source.copy(x = result.x, y = result.y) == result) &&
                (!source.locked || (source.x == result.x && source.y == result.y && result.locked))
        }
    }

    /** Exact preview revision check; unlike coordinate correction, no field may differ here. */
    private fun sameExactAuthoredState(left: RoofTopology, right: RoofTopology): Boolean {
        if (left.origin != right.origin || left.schemaVersion != right.schemaVersion) return false
        if (left.gridRotationDeg.isFinite() != right.gridRotationDeg.isFinite()) return false
        if (left.gridRotationDeg.isFinite() &&
            kotlin.math.abs(left.gridRotationDeg - right.gridRotationDeg) > 1e-10
        ) return false
        if (left.nodes.size != right.nodes.size || left.edges.size != right.edges.size) return false
        val rightNodes = right.nodes.associateBy(TopologyNode::id)
        val rightEdges = right.edges.associateBy(TopologyEdge::id)
        if (rightNodes.size != right.nodes.size || rightEdges.size != right.edges.size) return false
        return left.nodes.all { node -> rightNodes[node.id] == node } &&
            left.edges.all { edge -> rightEdges[edge.id] == edge }
    }

    private fun topologyMutationRejected() = TopologyApplyResult(
        applied = false,
        issues = listOf(
            TopologyIssue(
                code = "INTERNAL_TOPOLOGY_MUTATION_REJECTED",
                message = "Korekcia vnútorných línií zmenila počet, spojenie alebo typ línie; celá operácia bola zrušená.",
                severity = TopologyIssueSeverity.ERROR
            )
        )
    )

    /** Exact rollback boundary for the coordinate-only transaction. */
    private data class ProjectGeometryState(
        val polygon: List<GeoPoint>,
        val wallFootprint: List<GeoPoint>,
        val wallFootprintParts: List<WallFootprintPart>,
        val wallFootprintPartsSignature: String,
        val lines: List<RoofLine>,
        val objects: List<RoofObject>,
        val edgeTypes: Map<Int, LineType>,
        val roofTopology: RoofTopology?,
        val roofGraph: RoofGraph?,
        val geometryGridOriginLat: Double,
        val geometryGridOriginLon: Double,
        val geometryGridRotationDeg: Double,
        val updatedAt: Long
    ) {
        fun restore(project: RoofProject) {
            project.polygon = polygon.map(GeoPoint::copy).toMutableList()
            project.wallFootprint = wallFootprint.map(GeoPoint::copy).toMutableList()
            project.wallFootprintParts = wallFootprintParts.map { part ->
                part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
            }.toMutableList()
            project.wallFootprintPartsSignature = wallFootprintPartsSignature
            project.lines = lines.map { line ->
                line.copy(start = line.start.copy(), end = line.end.copy())
            }.toMutableList()
            project.objects = objects.map { item -> item.copy(center = item.center.copy()) }.toMutableList()
            project.edgeTypes = edgeTypes.toMutableMap()
            project.roofTopology = roofTopology
            project.roofGraph = roofGraph
            project.geometryGridOriginLat = geometryGridOriginLat
            project.geometryGridOriginLon = geometryGridOriginLon
            project.geometryGridRotationDeg = geometryGridRotationDeg
            project.updatedAt = updatedAt
        }

        companion object {
            fun capture(project: RoofProject) = ProjectGeometryState(
                polygon = project.polygon.map(GeoPoint::copy),
                wallFootprint = project.wallFootprint.map(GeoPoint::copy),
                wallFootprintParts = project.wallFootprintParts.map { part ->
                    part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
                },
                wallFootprintPartsSignature = project.wallFootprintPartsSignature,
                lines = project.lines.map { line ->
                    line.copy(start = line.start.copy(), end = line.end.copy())
                },
                objects = project.objects.map { item -> item.copy(center = item.center.copy()) },
                edgeTypes = project.edgeTypes.toMap(),
                roofTopology = project.roofTopology,
                roofGraph = project.roofGraph,
                geometryGridOriginLat = project.geometryGridOriginLat,
                geometryGridOriginLon = project.geometryGridOriginLon,
                geometryGridRotationDeg = project.geometryGridRotationDeg,
                updatedAt = project.updatedAt
            )
        }
    }

    private fun sameBoundary(a: RoofTopology, b: RoofTopology): Boolean {
        val aBoundary = RoofTopologyMigration.orderedBoundary(a) ?: return false
        val bBoundary = RoofTopologyMigration.orderedBoundary(b) ?: return false
        if (aBoundary.first != bBoundary.first) return false
        val aEdges = aBoundary.second
        val bEdges = bBoundary.second
        if (aEdges.size != bEdges.size) return false
        if (aEdges.indices.any { index -> aEdges[index] != bEdges[index] }) return false
        val aNodes = a.nodes.associateBy { it.id }
        val bNodes = b.nodes.associateBy { it.id }
        return aBoundary.first.all { id ->
            val first = aNodes[id] ?: return@all false
            val second = bNodes[id] ?: return@all false
            first == second
        }
    }
}
