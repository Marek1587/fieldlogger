package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface

/** Runtime rendering of the supplied StrechoStav roof/chimney SVG identity. */
object StrechoStavLogo {
    fun bitmap(width: Int = 1024, height: Int = 470): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val scaleX = width / 1000f
        val scaleY = height / 470f
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(205, 214, 218)
            style = Paint.Style.STROKE
            strokeWidth = 14f * minOf(scaleX, scaleY)
            strokeJoin = Paint.Join.MITER
            strokeCap = Paint.Cap.SQUARE
        }
        val roof = Path().apply {
            moveTo(70f * scaleX, 225f * scaleY)
            lineTo(445f * scaleX, 70f * scaleY)
            lineTo(615f * scaleX, 145f * scaleY)
            lineTo(615f * scaleX, 45f * scaleY)
            lineTo(690f * scaleX, 45f * scaleY)
            lineTo(690f * scaleX, 178f * scaleY)
            lineTo(930f * scaleX, 225f * scaleY)
            lineTo(900f * scaleX, 325f * scaleY)
            lineTo(876f * scaleX, 315f * scaleY)
            moveTo(70f * scaleX, 225f * scaleY)
            lineTo(100f * scaleX, 325f * scaleY)
            lineTo(124f * scaleX, 315f * scaleY)
        }
        canvas.drawPath(roof, line)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(205, 214, 218)
            textAlign = Paint.Align.CENTER
            textSize = 128f * scaleY
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD)
        }
        canvas.drawText("StrechoStav", width / 2f, 370f * scaleY, text)
        return bitmap
    }
}
