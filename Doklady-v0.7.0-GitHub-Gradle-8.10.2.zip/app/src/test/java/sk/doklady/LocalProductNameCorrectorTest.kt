package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.processing.LocalProductNameCorrector

class LocalProductNameCorrectorTest {
    private val corrector = LocalProductNameCorrector()

    @Test fun `corrects close Slovak OCR product names locally`() {
        assertEquals("Dojčenská voda", corrector.correct("Doičenská voda").value)
        assertEquals("Cottage light", corrector.correct("Cottade 1ight").value)
        assertEquals("Gr. jogurt 2%, 1kg", corrector.correct("Gr.ioaurt 2%.1kc").value)
        assertTrue(corrector.correct("Šunková sal áma").changed)
    }

    @Test fun `does not invent unknown item or touch summary labels`() {
        assertEquals("PPRCT HOT S3.2 SDR7", corrector.correct("PPRCT HOT S3.2 SDR7").value)
        assertFalse(corrector.correct("NA UHRADU EUR").changed)
    }
}
