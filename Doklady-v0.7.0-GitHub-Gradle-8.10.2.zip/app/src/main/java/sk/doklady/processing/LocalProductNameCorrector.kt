package sk.doklady.processing

import java.text.Normalizer
import kotlin.math.max

data class NameCorrection(
    val value: String,
    val changed: Boolean,
    val confidence: Int,
)

/**
 * Conservative, fully local post-OCR correction. It may replace only a product
 * name with a close vocabulary candidate; quantities, prices and totals never
 * enter this component. User-edited/high-confidence names extend the vocabulary
 * automatically, so it improves without merchant-specific parsing rules.
 */
class LocalProductNameCorrector(localVocabulary: Collection<String> = emptyList()) {
    private val vocabulary = (BOOTSTRAP_VOCABULARY + localVocabulary)
        .map(::clean).filter { it.count(Char::isLetter) >= 3 }.distinctBy(::matchKey)

    fun correct(source: String): NameCorrection {
        val cleanSource = clean(source)
        if (cleanSource.length < 4 || isProtected(cleanSource)) return NameCorrection(cleanSource, false, 0)
        val sourceKey = matchKey(cleanSource)
        val sourceNumbers = numericSignature(cleanSource)
        val best = vocabulary.asSequence()
            .filter { numericSignature(it) == sourceNumbers }
            .map { it to similarity(sourceKey, matchKey(it)) }
            .filter { (_, score) -> score >= minimumScore(sourceKey.length) }
            .maxByOrNull { it.second }
            ?: return NameCorrection(cleanSource, false, 0)
        if (plainKey(best.first) == plainKey(cleanSource)) {
            val diacriticsChanged = best.first != cleanSource
            return NameCorrection(if (diacriticsChanged) best.first else cleanSource, diacriticsChanged, 98)
        }
        if (best.first.firstOrNull()?.uppercaseChar() != cleanSource.firstOrNull()?.uppercaseChar() && best.second < 0.88f) {
            return NameCorrection(cleanSource, false, 0)
        }
        return NameCorrection(best.first, true, (best.second * 100).toInt().coerceIn(72, 97))
    }

    private fun minimumScore(length: Int): Float = when {
        length <= 6 -> 0.86f
        length <= 11 -> 0.78f
        else -> 0.72f
    }

    private fun isProtected(value: String): Boolean {
        val key = plainKey(value)
        return PROTECTED.any(key::contains) || value.count(Char::isDigit) > value.count(Char::isLetter)
    }

    private fun clean(value: String): String = value.trim().replace(Regex("\\s+"), " ")

    private fun numericSignature(value: String): List<String> =
        Regex("\\d+(?:[,.]\\d+)?").findAll(value.replace(Regex("(?i)\\b1ight\\b"), "light"))
            .map { it.value.replace(',', '.') }.toList()

    private fun plainKey(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").lowercase().filter(Char::isLetterOrDigit)

    private fun matchKey(value: String): String = plainKey(value)
        .replace('0', 'o').replace('1', 'l')

    private fun similarity(first: String, second: String): Float {
        if (first == second) return 1f
        if (first.isEmpty() || second.isEmpty()) return 0f
        var previous = IntArray(second.length + 1) { it }
        first.indices.forEach { i ->
            val current = IntArray(second.length + 1)
            current[0] = i + 1
            second.indices.forEach { j ->
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + if (first[i] == second[j]) 0 else 1,
                )
            }
            previous = current
        }
        return 1f - previous[second.length].toFloat() / max(first.length, second.length)
    }

    companion object {
        private val PROTECTED = listOf("zlava", "medzisucet", "uhradu", "celkom", "dph", "karta")

        // Small language seed, not a merchant template. The persistent vocabulary
        // grows from reviewed items and high-confidence scans on the device.
        private val BOOTSTRAP_VOCABULARY = listOf(
            "Dojčenská voda",
            "Záloh. fľaša plast",
            "Smoothie jah-ban",
            "Šunková saláma",
            "Zmrazené jahody",
            "Gr. jogurt 2%, 1kg",
            "Morčacia šunka",
            "Cottage light",
            "Tvaroh odtučnený",
            "Šalát Rosso",
        )
    }
}
