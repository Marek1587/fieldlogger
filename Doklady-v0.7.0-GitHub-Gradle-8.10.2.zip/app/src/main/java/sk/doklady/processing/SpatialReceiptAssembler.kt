package sk.doklady.processing

import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.abs
import kotlin.math.max

internal data class SpatialAssembly(
    val lines: List<OcrLine>,
    val diagnostics: ParserDiagnostics,
)

/**
 * Reconstructs the two-dimensional receipt before the legacy linear parser sees it.
 * It is merchant independent: associations use geometry, line roles and arithmetic,
 * never a HORNBACH/OBI-specific template.
 */
internal class SpatialReceiptAssembler(
    private val classifier: ReceiptLineClassifier,
) {
    fun assemble(input: List<OcrLine>): SpatialAssembly {
        val lines = input.filter { it.text.isNotBlank() }
            .sortedWith(compareBy<OcrLine> { it.top }.thenBy { it.left })
        if (lines.size < 3) return SpatialAssembly(lines, diagnostics(0, 0, 0, false))
        val pageWidth = lines.maxOf { it.right }.coerceAtLeast(1)
        val pageHeight = lines.maxOf { it.bottom }.coerceAtLeast(1)
        val info = lines.mapIndexed { index, line ->
            LineInfo(
                index = index,
                line = line,
                prediction = classifier.classify(line, pageWidth, pageHeight),
                amounts = AMOUNT_REGEX.findAll(line.text).mapNotNull { GenericDocumentParser.parseCents(it.value) }.toList(),
                centerX = (line.left + line.right) / 2f / pageWidth,
                centerY = (line.top + line.bottom) / 2f / pageHeight,
            )
        }
        val seeds = buildItemSeeds(info)
        if (seeds.size < 2) {
            return SpatialAssembly(lines, diagnostics(0, seeds.size, seeds.count { it.corrected }, false))
        }

        val priceCandidates = info.filter { candidate ->
            candidate.amounts.size == 1 && isPriceOnly(candidate.line.text) &&
                candidate.prediction.role !in setOf(ReceiptLineRole.TAX, ReceiptLineRole.TOTAL_LABEL, ReceiptLineRole.PAYMENT) &&
                !normalized(candidate.line.text).contains("ZLAVA")
        }
        if (priceCandidates.size < seeds.size) {
            return SpatialAssembly(lines, diagnostics(0, seeds.size, seeds.count { it.corrected }, false))
        }
        val horizontalSeparation = median(priceCandidates.map { it.centerX }) - median(seeds.map { it.name.centerX })
        val summaryIndex = info.indexOfFirst { it.prediction.role in SUMMARY_ROLES }.takeIf { it >= 0 }
        val pricesAfterSummary = summaryIndex?.let { start -> priceCandidates.count { it.index > start } } ?: 0
        val detached = horizontalSeparation >= 0.13f || pricesAfterSummary >= max(2, seeds.size / 2)
        if (!detached) {
            return SpatialAssembly(lines, diagnostics(0, seeds.size, seeds.count { it.corrected }, false))
        }

        val assignments = assignPrices(seeds, priceCandidates)
        if (assignments.count { it != null } < max(2, (seeds.size * 0.60f).toInt())) {
            return SpatialAssembly(lines, diagnostics(assignments.count { it != null }, seeds.size, seeds.count { it.corrected }, false))
        }

        val rebuilt = mutableListOf<OcrLine>()
        val firstItemIndex = seeds.minOf { minOf(it.name.index, it.quantity.index) }
        rebuilt += info.take(firstItemIndex).map { it.line }
        seeds.forEachIndexed { index, seed ->
            if (seed.quantity.index == seed.name.index) {
                rebuilt += seed.name.line.copy(text = "${seed.correctedName} ${seed.quantityText}")
            } else {
                rebuilt += seed.name.line.copy(text = seed.correctedName)
                rebuilt += seed.quantity.line
            }
            seed.identifier?.let { rebuilt += it.line }
            assignments[index]?.let { price -> rebuilt += price.line.copy(text = formatCents(price.amounts.single())) }
        }

        val assignedIndices = assignments.mapNotNull { it?.index }.toSet()
        val itemSum = assignments.mapNotNull { it?.amounts?.singleOrNull() }.takeIf { it.size == seeds.size }?.sum()
        // Never manufacture a grand total from a partial reconstruction. Prefer a
        // number physically attached to a total/subtotal/payment label. Item math
        // is used only as an unlabelled fallback after every seed got a price.
        val labelledTotal = findLabelledGrandTotal(info, itemSum)
        val total = labelledTotal ?: itemSum?.takeIf { sum ->
            assignments.all { it != null } && info.any { sum in it.amounts }
        }
        val taxPair = total?.let { findTaxEquation(info, it, assignedIndices) }
        if (total != null) {
            rebuilt += syntheticLine("NA ÚHRADU EUR ${formatCents(total)}", pageWidth, pageHeight, 0.84f)
        } else {
            rebuilt += info.filter { it.prediction.role in setOf(ReceiptLineRole.TOTAL_LABEL, ReceiptLineRole.PAYMENT) }
                .map { it.line }
        }
        taxPair?.let { (net, vat) ->
            rebuilt += syntheticLine("Základ ${formatCents(net)}", pageWidth, pageHeight, 0.90f)
            rebuilt += syntheticLine("DPH ${formatCents(vat)}", pageWidth, pageHeight, 0.92f)
            rebuilt += syntheticLine("SPOLU ${formatCents(net)} ${formatCents(vat)}", pageWidth, pageHeight, 0.94f)
        }

        // Keep administrative/footer lines useful for document number and date, but
        // exclude detached monetary columns already reconstructed above.
        val retainedFooter = info.drop(firstItemIndex).filter { candidate ->
            candidate.index !in assignedIndices && candidate.amounts.isEmpty() &&
                candidate.prediction.role == ReceiptLineRole.OTHER &&
                normalized(candidate.line.text).let { value -> SAVINGS_WORDS.any(value::contains) }
        }.map { it.line }
        rebuilt += retainedFooter
        return SpatialAssembly(
            lines = rebuilt.distinctBy { "${normalized(it.text)}:${it.top}:${it.left}" },
            diagnostics = diagnostics(assignments.count { it != null }, seeds.size, seeds.count { it.corrected }, true),
        )
    }

    private fun buildItemSeeds(info: List<LineInfo>): List<ItemSeed> {
        val usedNames = mutableSetOf<Int>()
        return info.mapNotNull { quantity ->
            val match = QUANTITY_REGEX.find(quantity.line.text) ?: return@mapNotNull null
            if (quantity.prediction.role in SUMMARY_ROLES || isAdministrative(quantity.line.text)) return@mapNotNull null
            val embeddedName = cleanProductName(quantity.line.text)
            val name = if (embeddedName.count(Char::isLetter) >= 3) quantity else {
                info.asSequence().filter { it.index < quantity.index && it.index >= quantity.index - 4 }
                    .filter { it.index !in usedNames && isPotentialName(it) }
                    .maxWithOrNull(compareBy<LineInfo> { it.index }.thenBy { it.prediction.confidence })
                    ?: return@mapNotNull null
            }
            usedNames += name.index
            val identifier = info.firstOrNull { candidate ->
                candidate.index in (quantity.index + 1)..(quantity.index + 4) &&
                    candidate.prediction.role == ReceiptLineRole.ITEM_IDENTIFIER
            }
            val alternatives = (name.line.alternatives + name.line.text).distinct()
            val correctedName = chooseConsensusName(alternatives, cleanProductName(name.line.text))
            val quantityValue = match.groupValues[1].replace(',', '.').toBigDecimalOrNull()
            val unitPrice = AMOUNT_REGEX.findAll(quantity.line.text).mapNotNull {
                GenericDocumentParser.parseCents(it.value)
            }.lastOrNull()
            ItemSeed(
                name = name,
                quantity = quantity,
                quantityText = match.value,
                identifier = identifier,
                correctedName = correctedName,
                expectedTotal = if (quantityValue != null && unitPrice != null && containsMultiplication(quantity.line.text)) {
                    quantityValue.multiply(BigDecimal(unitPrice)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                } else null,
                corrected = normalized(correctedName) != normalized(cleanProductName(name.line.text)),
            )
        }.distinctBy { it.quantity.index }
    }

    private fun assignPrices(seeds: List<ItemSeed>, pool: List<LineInfo>): List<LineInfo?> {
        val assignments = MutableList<LineInfo?>(seeds.size) { null }
        val used = mutableSetOf<Int>()
        var cursor = 0
        seeds.forEachIndexed { seedIndex, seed ->
            val expected = seed.expectedTotal ?: return@forEachIndexed
            val matchIndex = (cursor until pool.size).firstOrNull { index ->
                index !in used && abs(pool[index].amounts.single() - expected) <= 2
            } ?: return@forEachIndexed
            assignments[seedIndex] = pool[matchIndex]
            used += matchIndex
            cursor = matchIndex + 1
        }

        // Unknown-price rows are filled only inside the boundaries established by
        // exact quantity × unit-price matches. This handles first/last rows without
        // accidentally consuming VAT base or grand-total values.
        assignments.indices.filter { assignments[it] == null }.forEach { seedIndex ->
            val previous = (seedIndex - 1 downTo 0).firstNotNullOfOrNull { index ->
                assignments[index]?.let(pool::indexOf)
            }
            val next = (seedIndex + 1 until assignments.size).firstNotNullOfOrNull { index ->
                assignments[index]?.let(pool::indexOf)
            }
            val candidates = when {
                previous != null && next != null -> (previous + 1 until next).toList()
                previous == null && next != null -> (0 until next).toList().asReversed()
                previous != null -> (previous + 1 until pool.size).toList()
                else -> pool.indices.toList()
            }
            val chosen = candidates.firstOrNull { index ->
                index !in used && pool[index].centerX >= 0.62f
            } ?: return@forEach
            assignments[seedIndex] = pool[chosen]
            used += chosen
        }
        return assignments
    }

    private fun findTaxEquation(info: List<LineInfo>, total: Long, excluded: Set<Int>): Pair<Long, Long>? {
        val occurrences = info.filter { it.index !in excluded }.flatMap { line -> line.amounts.map { line.index to it } }
        var best: Pair<Long, Long>? = null
        var bestScore = Int.MIN_VALUE
        occurrences.forEach { (leftIndex, net) ->
            occurrences.forEach { (rightIndex, vat) ->
                if (leftIndex == rightIndex || net <= 0 || vat <= 0 || net <= vat || abs(net + vat - total) > 2) return@forEach
                val leftText = normalized(info[leftIndex].line.text)
                val rightText = normalized(info[rightIndex].line.text)
                val score = (if ("ZAKLAD" in leftText || "NET" in leftText) 4 else 0) +
                    (if ("DPH" in rightText || "VAT" in rightText) 4 else 0) +
                    (if (leftIndex > info.size / 2 && rightIndex > info.size / 2) 2 else 0)
                if (score > bestScore) { best = net to vat; bestScore = score }
            }
        }
        return best
    }

    private fun findLabelledGrandTotal(info: List<LineInfo>, itemSum: Long?): Long? {
        val priorities = listOf("NA UHRADU", "NA URADU", "CELKOM", "TOTAL", "MEDZISUCET", "SUBTOTAL", "KARTA")
        val firstLabelIndex = info.indexOfFirst { candidate ->
            priorities.any { normalized(candidate.line.text).contains(it) }
        }
        if (firstLabelIndex >= 0) {
            val summaryAmounts = info.drop(firstLabelIndex)
                .flatMap { it.amounts }.filter { it > 0 }
            summaryAmounts.groupingBy { it }.eachCount().entries
                .filter { it.value >= 2 }
                .maxWithOrNull(compareBy<Map.Entry<Long, Int>> { it.value }.thenBy { it.key })
                ?.key?.let { return it }
            itemSum?.takeIf { it in summaryAmounts }?.let { return it }
        }
        priorities.forEach { label ->
            info.forEachIndexed { index, candidate ->
                if (!normalized(candidate.line.text).contains(label)) return@forEachIndexed
                candidate.amounts.lastOrNull { it > 0 }?.let { return it }
                // OCR frequently emits the right-hand price as its own line. Accept
                // only a close vertical neighbour and favour the right column.
                info.asSequence()
                    .filter { it.index > candidate.index && it.index <= candidate.index + 4 }
                    .filter { it.amounts.any { amount -> amount > 0 } }
                    .sortedWith(compareBy<LineInfo> { abs(it.centerY - candidate.centerY) }.thenByDescending { it.centerX })
                    .firstOrNull()
                    ?.amounts?.lastOrNull { it > 0 }
                    ?.let { return it }
            }
        }
        return null
    }

    private fun isPotentialName(info: LineInfo): Boolean {
        val text = cleanProductName(info.line.text)
        if (text.count(Char::isLetter) < 3 || isAdministrative(text)) return false
        return info.prediction.role in setOf(ReceiptLineRole.PRODUCT_NAME, ReceiptLineRole.OTHER, ReceiptLineRole.HEADER) &&
            info.prediction.role !in SUMMARY_ROLES
    }

    private fun chooseConsensusName(candidates: List<String>, fallback: String): String {
        val cleaned = candidates.map(::cleanProductName).filter { it.count(Char::isLetter) >= 3 }.distinct()
        if (cleaned.isEmpty()) return fallback
        return cleaned.maxByOrNull { candidate ->
            val normalizedCandidate = normalized(candidate)
            val agreement = cleaned.filter { it !== candidate }.sumOf { other ->
                similarity(normalizedCandidate, normalized(other)).toDouble()
            }
            agreement + candidate.count(Char::isLetter) * 0.015
        } ?: fallback
    }

    private fun cleanProductName(value: String): String = value
        .replace(QUANTITY_REGEX, " ")
        .replace(AMOUNT_REGEX, " ")
        .replace(Regex("(?i)\\b(EUR|CZK|USD)\\b|[€$]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim(' ', '-', '|', ':', '*', ',')

    private fun similarity(first: String, second: String): Float {
        if (first == second) return 1f
        if (first.isEmpty() || second.isEmpty()) return 0f
        var previous = IntArray(second.length + 1) { it }
        first.indices.forEach { i ->
            val current = IntArray(second.length + 1); current[0] = i + 1
            second.indices.forEach { j ->
                current[j + 1] = minOf(current[j] + 1, previous[j + 1] + 1, previous[j] + if (first[i] == second[j]) 0 else 1)
            }
            previous = current
        }
        return 1f - previous[second.length].toFloat() / max(first.length, second.length)
    }

    private fun isAdministrative(value: String): Boolean {
        val normalized = normalized(value)
        return ADMIN_WORDS.any(normalized::contains) || SUMMARY_WORDS.any(normalized::contains)
    }

    private fun containsMultiplication(value: String) = value.contains('x', true) || value.contains('×') || value.contains('*')
    private fun isPriceOnly(value: String) = AMOUNT_REGEX.findAll(value).count() == 1 && value.count(Char::isLetter) <= 3
    private fun normalized(value: String) = ReceiptLineFeatures.normalized(value)
    private fun formatCents(value: Long) = "%d,%02d".format(value / 100, abs(value % 100))
    private fun syntheticLine(text: String, width: Int, height: Int, y: Float) = OcrLine(
        text = text, left = (width * 0.08f).toInt(), top = (height * y).toInt(),
        right = (width * 0.94f).toInt(), bottom = (height * (y + 0.015f)).toInt(), confidence = 1f,
    )
    private fun median(values: List<Float>): Float = values.sorted().let { sorted ->
        if (sorted.isEmpty()) 0f else sorted[sorted.size / 2]
    }
    private fun diagnostics(associations: Int, estimated: Int, corrected: Int, spatial: Boolean) = ParserDiagnostics(
        strategy = if (spatial) "SPATIAL_CONSTRAINTS" else "LINEAR_GEOMETRY",
        modelName = classifier.modelName,
        aiEnabled = classifier.aiEnabled,
        spatialAssociations = associations,
        estimatedItemCount = estimated,
        correctedNames = corrected,
    )

    private data class LineInfo(
        val index: Int,
        val line: OcrLine,
        val prediction: LinePrediction,
        val amounts: List<Long>,
        val centerX: Float,
        val centerY: Float,
    )
    private data class ItemSeed(
        val name: LineInfo,
        val quantity: LineInfo,
        val quantityText: String,
        val identifier: LineInfo?,
        val correctedName: String,
        val expectedTotal: Long?,
        val corrected: Boolean,
    )

    companion object {
        private val AMOUNT_REGEX = Regex("(?<!\\d)[-+]?\\d{1,6}(?:[ .]\\d{3})*[,.]\\d{2}(?!\\d)")
        private val QUANTITY_REGEX = Regex("(?i)(\\d+(?:[,.]\\d+)?)\\s*(kus|ks|kg|g|l|m2|m²|m|bal\\.|bal|pc)\\b(?:\\s*[x×*])?")
        private val SUMMARY_ROLES = setOf(ReceiptLineRole.TOTAL_LABEL, ReceiptLineRole.TAX, ReceiptLineRole.PAYMENT)
        private val SUMMARY_WORDS = listOf("MEDZISUCET", "NA UHRADU", "K UHRADE", "CELKOM", "TOTAL", "KARTA", "DPH", "VAT", "ZAKLAD", "SPOLU")
        private val ADMIN_WORDS = listOf("ICO", "DIC", "IC DPH", "DATUM", "CAS", "BLOK", "DOKLAD", "PREVADZKA", "ADRESA", "S.R.O", "SRO", "EUR", "TEL", "WWW", "POKLAD")
        private val SAVINGS_WORDS = listOf("USETRIL", "USPORA", "USPOR", "SAVING")
    }
}
