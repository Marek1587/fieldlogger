package sk.doklady.processing

import sk.doklady.data.DocumentItemEntity
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.Normalizer
import kotlin.math.abs

data class OcrLine(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val confidence: Float? = null,
    val alternatives: List<String> = emptyList(),
    val supportingFrames: Int = 1,
)

data class ParserDiagnostics(
    val strategy: String = "LINEAR",
    val modelName: String = "none",
    val aiEnabled: Boolean = false,
    val spatialAssociations: Int = 0,
    val estimatedItemCount: Int = 0,
    val correctedNames: Int = 0,
)

data class ParsedDocument(
    val supplier: String?,
    val registrationId: String?,
    val documentNumber: String?,
    val purchaseDate: String?,
    val currency: String,
    val netTotalCents: Long?,
    val vatTotalCents: Long?,
    val grossTotalCents: Long?,
    val items: List<ParsedItem>,
    val diagnostics: ParserDiagnostics = ParserDiagnostics(),
)

data class ParsedItem(
    val originalText: String,
    val name: String,
    val productCode: String? = null,
    val ean: String? = null,
    val quantity: String? = null,
    val unit: String? = null,
    val unitPriceGrossCents: Long? = null,
    val totalGrossCents: Long? = null,
    val vatRate: String? = null,
    val confidence: Int,
)

interface DocumentParser { fun parse(lines: List<OcrLine>): ParsedDocument }

class GenericDocumentParser(
    private val lineClassifier: ReceiptLineClassifier = HeuristicReceiptLineClassifier,
) : DocumentParser {
    override fun parse(lines: List<OcrLine>): ParsedDocument {
        val assembly = SpatialReceiptAssembler(lineClassifier).assemble(lines)
        val clean = assembly.lines.map { it.text.trim() }.filter { it.isNotBlank() }
        val items = detectItems(clean)
        val itemSum = items.mapNotNull { it.totalGrossCents }.takeIf { it.isNotEmpty() }?.sum()
        val explicitTotal = findExplicitTotal(clean)
        // A value explicitly labelled as payable/subtotal is authoritative. The item
        // sum is a validation signal, never a replacement for a printed grand total:
        // OCR may have missed one or more item rows.
        val totalMatchingItems = itemSum?.takeIf { items.size >= 2 }?.let { sum ->
            allAmounts(clean).firstOrNull { occurrence ->
                occurrence.value > 0 && abs(occurrence.value - sum) <= TOTAL_TOLERANCE_CENTS
            }?.value
        }
        val total = explicitTotal ?: totalMatchingItems ?: findSafeBottomAmount(clean)
        val taxPair = findTaxSummaryPair(clean)
        val vat = taxPair?.second ?: findLabelledAmount(clean, listOf("dph", "vat"), preferLast = true)
        val net = taxPair?.first
            ?: findLabelledAmount(clean, listOf("základ", "bez dph", "netto", "net"), preferLast = false)
            ?: if (total != null && vat != null) total - vat else null

        return ParsedDocument(
            supplier = detectSupplier(clean),
            registrationId = findFirst(clean, REGISTRATION_REGEX)?.groupValues?.get(1)?.filter(Char::isDigit),
            documentNumber = clean.asSequence()
                .mapNotNull { findFirst(listOf(it), DOCUMENT_NUMBER_REGEX)?.groupValues?.get(1) }
                .firstOrNull(),
            purchaseDate = clean.asSequence().mapNotNull { DATE_REGEX.find(it)?.value }.firstOrNull()?.let(::normalizeDate),
            currency = when {
                clean.any { it.contains("CZK", true) || it.contains("Kč", true) } -> "CZK"
                clean.any { it.contains("USD", true) || it.contains('$') } -> "USD"
                else -> "EUR"
            },
            netTotalCents = net,
            vatTotalCents = vat,
            grossTotalCents = total,
            items = items,
            diagnostics = assembly.diagnostics,
        )
    }

    private fun detectSupplier(lines: List<String>): String? {
        val known = listOf("HORNBACH", "OBI", "BAUHAUS", "DEK", "STAVMAT", "LIDL", "KAUFLAND", "TESCO", "BILLA")
        known.firstOrNull { name -> lines.take(12).any { normalized(it).contains(name) } }?.let { return it }
        return lines.take(6).firstOrNull { line ->
            line.length in 3..80 && line.any(Char::isLetter) &&
                !line.contains(Regex("(?i)doklad|fakt[úu]ra|blo[cč]ek|receipt"))
        }
    }

    /**
     * Receipt rows are commonly split by OCR into name / quantity × unit price / row total.
     * This stateful scan keeps those lines together, includes deposits and discounts, and
     * never treats payment/tax/savings summaries as purchased products.
     */
    private fun detectItems(lines: List<String>): List<ParsedItem> {
        val result = mutableListOf<ParsedItem>()
        val consumed = BooleanArray(lines.size)
        var index = 0
        while (index < lines.size) {
            val line = lines[index]
            val normalizedLine = normalized(line)
            if (isDiscountLabel(normalizedLine)) {
                val amountIndex = ((index + 1)..minOf(lines.lastIndex, index + 2))
                    .firstOrNull { amounts(lines[it]).any { value -> value < 0 } }
                val discount = amountIndex?.let { amounts(lines[it]).firstOrNull { value -> value < 0 } }
                if (discount != null) {
                    result += ParsedItem(
                        originalText = listOf(line, lines[amountIndex]).joinToString("\n"),
                        name = "Zľava${result.lastOrNull()?.name?.let { " – $it" }.orEmpty()}",
                        quantity = "1",
                        unit = "KS",
                        totalGrossCents = discount,
                        confidence = 92,
                    )
                    consumed[index] = true
                    consumed[amountIndex] = true
                    index = amountIndex + 1
                    continue
                }
            }

            if (consumed[index] || !isPotentialProductName(line)) {
                index++
                continue
            }

            val windowEnd = minOf(lines.lastIndex, index + ITEM_LOOKAHEAD)
            val quantityCandidates = (index..windowEnd).filter { candidate ->
                !isSummaryLine(normalized(lines[candidate])) && QUANTITY_REGEX.containsMatchIn(lines[candidate])
            }
            // Prefer a purchased quantity with an explicit multiplication expression.
            // A package descriptor such as "jogurt 2%, 1kg" belongs to the name when
            // the following line says "3 ks x 1,89".
            val firstQuantityIndex = quantityCandidates.firstOrNull()
            val firstQuantityUnit = firstQuantityIndex?.let { candidate ->
                QUANTITY_REGEX.find(lines[candidate])?.groupValues?.getOrNull(2)?.uppercase()
            }
            val quantityIndex = if (
                firstQuantityIndex == index && firstQuantityUnit != null && firstQuantityUnit in PACKAGE_DESCRIPTOR_UNITS
            ) {
                quantityCandidates.firstOrNull { it > index && containsMultiplication(lines[it]) } ?: firstQuantityIndex
            } else firstQuantityIndex
            if (quantityIndex == null) {
                index++
                continue
            }

            val quantityLine = lines[quantityIndex]
            val quantityMatch = QUANTITY_REGEX.find(quantityLine)
            if (quantityMatch == null) {
                index++
                continue
            }
            val embeddedQuantityName = quantityLine.replace(QUANTITY_REGEX, " ")
                .replace(AMOUNT_REGEX, " ").count(Char::isLetter) >= 3
            val closerProductName = ((index + 1) until quantityIndex).any { isPotentialProductName(lines[it]) }
            if (quantityIndex != index && (embeddedQuantityName || closerProductName)) {
                index++
                continue
            }
            val quantity = quantityMatch.groupValues[1].replace(',', '.')
            val unit = quantityMatch.groupValues[2].uppercase().let { if (it == "KUS") "KS" else it }
            val quantityAmounts = amounts(quantityLine)
            val quantityPricingAmounts = amounts(quantityLine.substring(quantityMatch.range.last + 1))
            val nameAmounts = amounts(line)
            val followingAmountIndex = ((quantityIndex + 1)..minOf(lines.lastIndex, quantityIndex + 3))
                .firstOrNull { candidate ->
                    !isSummaryLine(normalized(lines[candidate])) &&
                        !QUANTITY_REGEX.containsMatchIn(lines[candidate]) &&
                        amounts(lines[candidate]).isNotEmpty()
                }
            val followingAmounts = followingAmountIndex?.let { amounts(lines[it]) }.orEmpty()

            val total = when {
                followingAmounts.isNotEmpty() -> followingAmounts.last()
                quantityPricingAmounts.size >= 2 -> quantityPricingAmounts.last()
                quantityPricingAmounts.size == 1 && quantity.toBigDecimalOrNull()?.compareTo(BigDecimal.ONE) == 0 -> quantityPricingAmounts.single()
                quantityIndex == index && nameAmounts.size >= 2 -> nameAmounts.last()
                quantityAmounts.size == 1 && quantity.toBigDecimalOrNull()?.compareTo(BigDecimal.ONE) == 0 -> quantityAmounts.single()
                nameAmounts.size == 1 -> nameAmounts.single()
                else -> null
            }
            if (total == null) {
                index++
                continue
            }

            val unitPrice = when {
                quantityPricingAmounts.isNotEmpty() -> quantityPricingAmounts.first()
                quantityIndex == index && nameAmounts.size >= 2 -> nameAmounts.first()
                quantity.toBigDecimalOrNull()?.compareTo(BigDecimal.ONE) == 0 -> total
                else -> null
            }
            val rawName = (if (quantityIndex == index) line.replace(QUANTITY_REGEX, " ") else line)
                .replace(AMOUNT_REGEX, " ")
                .replace(Regex("(?i)\\b(EUR|CZK|USD)\\b|[€$]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim(' ', '-', '|', ':', '*')
            if (rawName.count(Char::isLetter) < 3) {
                index++
                continue
            }

            val identifierEnd = followingAmountIndex ?: quantityIndex
            val identifierIndices = (index..identifierEnd).filter { extractEan(lines[it]) != null }
            val involved = (listOfNotNull(index, quantityIndex.takeIf { it != index }, followingAmountIndex) + identifierIndices)
                .distinct().sorted()
            involved.forEach { consumed[it] = true }
            result += ParsedItem(
                originalText = involved.joinToString("\n") { lines[it] },
                name = rawName,
                ean = involved.firstNotNullOfOrNull { extractEan(lines[it]) },
                quantity = quantity,
                unit = unit,
                unitPriceGrossCents = unitPrice,
                totalGrossCents = total,
                confidence = when {
                    unitPrice != null && followingAmounts.isNotEmpty() -> 94
                    unitPrice != null -> 86
                    else -> 78
                },
            )
            index = (involved.maxOrNull() ?: index) + 1
        }
        return result.distinctBy { item -> normalized(item.originalText) }
    }

    private fun findExplicitTotal(lines: List<String>): Long? {
        val priorities = listOf(
            listOf("NA UHRADU", "NA URADU", "K UHRADĚ", "K UHRADENIU"),
            listOf("CELKOM", "TOTAL"),
            listOf("MEDZISUCET", "MEDZISÚČET", "SUBTOTAL"),
            listOf("KARTA", "CARD"),
        )
        priorities.forEach { labels ->
            lines.forEachIndexed { index, line ->
                val normalizedLine = normalized(line)
                if (labels.none { normalizedLine.contains(normalized(it)) } || isSavingsLine(normalizedLine)) return@forEachIndexed
                amounts(line).lastOrNull { it > 0 }?.let { return it }
                for (offset in 1..3) {
                    val nearby = lines.getOrNull(index + offset) ?: break
                    val nearbyNormalized = normalized(nearby)
                    if (isSavingsLine(nearbyNormalized)) break
                    amounts(nearby).lastOrNull { it > 0 }?.let { return it }
                }
            }
        }
        return null
    }

    private fun findSafeBottomAmount(lines: List<String>): Long? = lines.indices.reversed().firstNotNullOfOrNull { index ->
        val normalizedLine = normalized(lines[index])
        if (isSavingsLine(normalizedLine) || normalizedLine.contains("ZLAVA")) null
        else amounts(lines[index]).lastOrNull { it > 0 }
    }

    private fun findTaxSummaryPair(lines: List<String>): Pair<Long, Long>? {
        for (index in lines.indices.reversed()) {
            if (!normalized(lines[index]).contains("SPOLU")) continue
            val values = (index..minOf(lines.lastIndex, index + 2)).flatMap { amounts(lines[it]) }
            if (values.size >= 2) return values[values.lastIndex - 1] to values.last()
        }
        return null
    }

    private fun findLabelledAmount(lines: List<String>, labels: List<String>, preferLast: Boolean): Long? =
        lines.asReversed().firstNotNullOfOrNull { line ->
            if (labels.any { normalized(line).contains(normalized(it)) }) {
                val values = amounts(line)
                if (preferLast) values.lastOrNull() else values.firstOrNull()
            } else null
        }

    private fun isPotentialProductName(line: String): Boolean {
        val value = normalized(line)
        if (line.count(Char::isLetter) < 3 || isSummaryLine(value) || isSavingsLine(value)) return false
        return ADMINISTRATIVE_WORDS.none(value::contains)
    }

    private fun isSummaryLine(value: String): Boolean = SUMMARY_WORDS.any(value::contains)
    private fun isSavingsLine(value: String): Boolean = SAVINGS_WORDS.any(value::contains)
    private fun isDiscountLabel(value: String): Boolean = value == "ZLAVA" || value.startsWith("ZLAVA ")
    private fun containsMultiplication(value: String): Boolean =
        value.contains('x', ignoreCase = true) || value.contains('×') || value.contains('*')
    private fun amounts(line: String): List<Long> = AMOUNT_REGEX.findAll(line).mapNotNull { parseCents(it.value) }.toList()
    private fun extractEan(line: String): String? {
        val value = normalized(line)
        if (value.contains("ICO") || value.contains("DIC") || value.contains("IC DPH")) return null
        return EAN_REGEX.find(line)?.value
    }
    private fun allAmounts(lines: List<String>): List<AmountOccurrence> = lines.flatMapIndexed { index, line ->
        amounts(line).map { AmountOccurrence(index, it) }
    }
    private fun findFirst(lines: List<String>, regex: Regex): MatchResult? = lines.firstNotNullOfOrNull(regex::find)
    private fun normalizeDate(value: String): String {
        val parts = value.split('.', '/', '-').mapNotNull(String::toIntOrNull)
        return if (parts.size == 3) {
            "%04d-%02d-%02d".format(if (parts[2] < 100) 2000 + parts[2] else parts[2], parts[1], parts[0])
        } else value
    }

    private data class AmountOccurrence(val lineIndex: Int, val value: Long)

    companion object {
        private const val ITEM_LOOKAHEAD = 4
        private val PACKAGE_DESCRIPTOR_UNITS = setOf("KG", "G", "L", "M", "M2", "M²")
        private const val TOTAL_TOLERANCE_CENTS = 2L
        private val AMOUNT_REGEX = Regex("(?<!\\d)[-+]?\\d{1,6}(?:[ .]\\d{3})*[,.]\\d{2}(?!\\d)")
        private val QUANTITY_REGEX = Regex("(?i)(\\d+(?:[,.]\\d+)?)\\s*(kus|ks|kg|g|l|m2|m²|m|bal\\.|bal|pc)\\b(?:\\s*[x×*])?")
        private val DATE_REGEX = Regex("\\b(?:0?[1-9]|[12]\\d|3[01])[./-](?:0?[1-9]|1[0-2])[./-](?:20)?\\d{2}\\b")
        private val REGISTRATION_REGEX = Regex("(?i)(?:IČO|ICO)\\s*[: ]\\s*(\\d{6,10})")
        private val DOCUMENT_NUMBER_REGEX = Regex("(?i)(?:č\\.?\\s*(?:dokladu|bloku)|doklad|blok|fakt[úu]ra|invoice)\\s*(?:č\\.?|no\\.?)?\\s*[:# ]\\s*([A-Z0-9][A-Z0-9/-]{3,})")
        private val EAN_REGEX = Regex("(?<!\\d)\\d{8,13}(?!\\d)")
        private val SUMMARY_WORDS = listOf(
            "MEDZISUCET", "NA UHRADU", "NA URADU", "K UHRAD", "CELKOM", "TOTAL", "SUBTOTAL",
            "KARTA", "CARD", "HOTOVOST", "ZAKLAD", "SADZBA", "DPH", "VAT", "SPOLU",
        )
        private val SAVINGS_WORDS = listOf("USETRIL", "USPORA", "USPOR", "SAVING")
        private val ADMINISTRATIVE_WORDS = listOf(
            "ICO", "DIC", "IC DPH", "DATUM", "CAS", "BLOK", "DOKLAD", "PREVADZKA", "ADRESA",
            "S.R.O", "SRO", "EUR", "TEL", "WWW", "POKLAD", "SA OPLATI",
        )

        fun parseCents(raw: String): Long? = runCatching {
            val compact = raw.replace(" ", "").filter { it.isDigit() || it in ".,-+" }
            val separator = maxOf(compact.lastIndexOf(','), compact.lastIndexOf('.'))
            val normalized = if (separator >= 0 && compact.length - separator - 1 == 2) {
                compact.substring(0, separator).replace(",", "").replace(".", "") + "." + compact.substring(separator + 1)
            } else compact.replace(",", "").replace(".", "")
            BigDecimal(normalized).setScale(2, RoundingMode.HALF_UP).movePointRight(2).longValueExact()
        }.getOrNull()

        internal fun normalized(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "").uppercase()
    }
}

data class ReceiptReconciliation(
    val itemSumCents: Long?,
    val totalCents: Long?,
    val differenceCents: Long?,
    val financiallyConsistent: Boolean,
    val semanticScore: Int,
)

object ReceiptReconciler {
    fun evaluate(parsed: ParsedDocument): ReceiptReconciliation {
        val totals = parsed.items.mapNotNull { it.totalGrossCents }
        val itemSum = totals.takeIf { it.isNotEmpty() }?.sum()
        val difference = if (itemSum != null && parsed.grossTotalCents != null) abs(itemSum - parsed.grossTotalCents) else null
        val consistent = parsed.items.size >= 2 && difference != null && difference <= 2
        var semanticScore = minOf(18, parsed.items.size * 2)
        if (parsed.grossTotalCents != null) semanticScore += 8 else semanticScore -= 15
        if (parsed.purchaseDate != null) semanticScore += 4
        if (!parsed.supplier.isNullOrBlank()) semanticScore += 4
        semanticScore += when {
            consistent -> 35
            difference == null -> -18
            difference <= 5 -> 20
            difference <= 20 -> 5
            else -> -minOf(35, 12 + (difference / 100).toInt())
        }
        return ReceiptReconciliation(itemSum, parsed.grossTotalCents, difference, consistent, semanticScore)
    }
}

fun ParsedItem.toEntity(documentId: String, position: Int) = DocumentItemEntity(
    documentId = documentId,
    position = position,
    originalText = originalText,
    productCode = productCode,
    ean = ean,
    name = name,
    quantity = quantity,
    unit = unit,
    unitPriceGrossCents = unitPriceGrossCents,
    totalGrossCents = totalGrossCents,
    vatRate = vatRate,
    confidence = confidence,
    nameConfidence = confidence,
    quantityConfidence = quantity?.let { (confidence + 4).coerceAtMost(99) },
    unitConfidence = unit?.let { (confidence + 4).coerceAtMost(99) },
    unitPriceConfidence = unitPriceGrossCents?.let { confidence },
    totalConfidence = totalGrossCents?.let { confidence },
)
