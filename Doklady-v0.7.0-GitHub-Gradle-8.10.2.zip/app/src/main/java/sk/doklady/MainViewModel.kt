package sk.doklady

import android.app.Application
import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentFrameEntity
import sk.doklady.data.DocumentItemEntity
import sk.doklady.data.DocumentStatus
import sk.doklady.data.CaptureMode
import sk.doklady.data.ImageSource
import sk.doklady.data.ProcessingLogEntity
import sk.doklady.storage.StoredImage
import sk.doklady.gallery.MediaAlbum
import sk.doklady.gallery.MediaPhoto
import sk.doklady.export.ExportData
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executor
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.capture.MultiFrameCaptureSnapshot

private val activeStatuses = setOf(
    DocumentStatus.CAPTURED, DocumentStatus.QUEUED, DocumentStatus.PREPROCESSING,
    DocumentStatus.OCR, DocumentStatus.PARSING, DocumentStatus.VALIDATING,
)
private val terminalStatuses = setOf(DocumentStatus.PROCESSED, DocumentStatus.REVIEW_REQUIRED, DocumentStatus.ERROR)

data class HomeUiState(
    val documents: List<DocumentEntity> = emptyList(),
    val importing: Boolean = false,
    val message: String? = null,
) {
    val queuedCount: Int get() = documents.count { it.status in setOf(DocumentStatus.CAPTURED, DocumentStatus.QUEUED) }
    val processingCount: Int get() = documents.count { it.status in activeStatuses }
    val processedCount: Int get() = documents.count { it.status == DocumentStatus.PROCESSED }
    val reviewCount: Int get() = documents.count { it.status == DocumentStatus.REVIEW_REQUIRED }
    val errorCount: Int get() = documents.count { it.status == DocumentStatus.ERROR }
    val currentDocument: DocumentEntity? get() = documents.firstOrNull {
        it.status in setOf(DocumentStatus.PREPROCESSING, DocumentStatus.OCR, DocumentStatus.PARSING, DocumentStatus.VALIDATING)
    }
    val activeBatch: List<DocumentEntity> get() {
        val id = currentDocument?.batchId
            ?: documents.firstOrNull { it.status in activeStatuses }?.batchId
            ?: return emptyList()
        return documents.filter { it.batchId == id }
    }
    val batchDone: Int get() = activeBatch.count { it.status in terminalStatuses }
    val batchPercent: Int get() = if (activeBatch.isEmpty()) 0 else activeBatch.sumOf { it.stageProgress } / activeBatch.size
}

data class DetailUiState(
    val document: DocumentEntity? = null,
    val items: List<DocumentItemEntity> = emptyList(),
)

data class DiagnosticsUiState(
    val documents: List<DocumentEntity> = emptyList(),
    val logs: List<ProcessingLogEntity> = emptyList(),
)

data class GalleryUiState(
    val albums: List<MediaAlbum> = emptyList(),
    val photos: List<MediaPhoto> = emptyList(),
    val currentAlbum: MediaAlbum? = null,
    val selected: Set<Uri> = emptySet(),
    val loading: Boolean = false,
    val error: String? = null,
)

enum class ExportPeriod { ALL, TODAY, MONTH }

data class ExportUiState(
    val period: ExportPeriod = ExportPeriod.ALL,
    val selectedSupplier: String? = null,
    val includeProcessed: Boolean = true,
    val includeReview: Boolean = true,
    val creating: Boolean = false,
    val createdFile: File? = null,
    val error: String? = null,
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as DokladyApplication
    private val dao = app.database.documents()
    private val transient = MutableStateFlow(TransientState())
    private val selectedDocumentId = MutableStateFlow<String?>(null)
    private val galleryMutable = MutableStateFlow(GalleryUiState())
    val galleryState: StateFlow<GalleryUiState> = galleryMutable
    private val exportMutable = MutableStateFlow(ExportUiState())
    val exportState: StateFlow<ExportUiState> = exportMutable

    val uiState: StateFlow<HomeUiState> = combine(dao.observeAll(), transient) { documents, state ->
        HomeUiState(documents, state.importing, state.message)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    val detailState: StateFlow<DetailUiState> = selectedDocumentId.flatMapLatest { id ->
        if (id == null) flowOf(DetailUiState())
        else combine(dao.observe(id), dao.observeItems(id)) { document, items -> DetailUiState(document, items) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DetailUiState())

    val diagnosticsState: StateFlow<DiagnosticsUiState> = combine(dao.observeAll(), dao.observeLogs()) { documents, logs ->
        DiagnosticsUiState(documents, logs)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DiagnosticsUiState())

    fun selectDocument(id: String?) { selectedDocumentId.value = id }

    fun loadAlbums() {
        viewModelScope.launch {
            galleryMutable.value = galleryMutable.value.copy(loading = true, currentAlbum = null, photos = emptyList(), error = null)
            runCatching { withContext(Dispatchers.IO) { app.mediaStore.loadAlbums() } }
                .onSuccess { galleryMutable.value = GalleryUiState(albums = it) }
                .onFailure { galleryMutable.value = GalleryUiState(error = it.message ?: "Galériu sa nepodarilo načítať.") }
        }
    }

    fun openAlbum(album: MediaAlbum) {
        viewModelScope.launch {
            galleryMutable.value = galleryMutable.value.copy(currentAlbum = album, loading = true, photos = emptyList())
            runCatching { withContext(Dispatchers.IO) { app.mediaStore.loadPhotos(album.bucketId) } }
                .onSuccess { galleryMutable.value = galleryMutable.value.copy(photos = it, loading = false) }
                .onFailure { galleryMutable.value = galleryMutable.value.copy(loading = false, error = it.message) }
        }
    }

    fun galleryBack(): Boolean {
        if (galleryMutable.value.currentAlbum == null) return false
        galleryMutable.value = galleryMutable.value.copy(currentAlbum = null, photos = emptyList())
        return true
    }

    fun togglePhoto(uri: Uri) {
        val selected = galleryMutable.value.selected.toMutableSet()
        if (!selected.add(uri)) selected.remove(uri)
        galleryMutable.value = galleryMutable.value.copy(selected = selected)
    }

    fun clearGallerySelection() {
        galleryMutable.value = galleryMutable.value.copy(selected = emptySet())
    }

    fun importGallerySelection(onFinished: () -> Unit) {
        val uris = galleryMutable.value.selected.toList()
        importGallery(uris) {
            clearGallerySelection()
            onFinished()
        }
    }

    fun setExportPeriod(period: ExportPeriod) { exportMutable.value = exportMutable.value.copy(period = period, createdFile = null) }
    fun setExportSupplier(supplier: String?) { exportMutable.value = exportMutable.value.copy(selectedSupplier = supplier, createdFile = null) }
    fun setIncludeProcessed(value: Boolean) { exportMutable.value = exportMutable.value.copy(includeProcessed = value, createdFile = null) }
    fun setIncludeReview(value: Boolean) { exportMutable.value = exportMutable.value.copy(includeReview = value, createdFile = null) }

    fun createExcel() {
        viewModelScope.launch {
            val options = exportMutable.value
            exportMutable.value = options.copy(creating = true, createdFile = null, error = null)
            runCatching {
                withContext(Dispatchers.IO) {
                    val allowed = buildSet {
                        if (options.includeProcessed) add(DocumentStatus.PROCESSED)
                        if (options.includeReview) add(DocumentStatus.REVIEW_REQUIRED)
                    }
                    val now = Date()
                    val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
                    val month = SimpleDateFormat("yyyy-MM", Locale.US).format(now)
                    val documents = dao.getAll().filter { document ->
                        document.status in allowed &&
                            (options.selectedSupplier == null || document.supplierName == options.selectedSupplier) &&
                            when (options.period) {
                                ExportPeriod.ALL -> true
                                ExportPeriod.TODAY -> (document.purchaseDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(document.createdAt))) == day
                                ExportPeriod.MONTH -> (document.purchaseDate ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(document.createdAt))).startsWith(month)
                            }
                    }
                    require(documents.isNotEmpty()) { "Pre zvolené filtre nie sú dostupné žiadne doklady." }
                    val ids = documents.map { it.id }.toSet()
                    app.xlsxExporter.create(ExportData(
                        documents = documents,
                        items = dao.getAllItems().filter { it.documentId in ids },
                        vat = dao.getAllVatSummaries().filter { it.documentId in ids },
                        suppliers = dao.getAllSuppliers().filter { supplier -> options.selectedSupplier == null || supplier.name == options.selectedSupplier },
                    ))
                }
            }.onSuccess { file ->
                exportMutable.value = exportMutable.value.copy(creating = false, createdFile = file)
                transient.value = TransientState(message = "Excel vytvorený: ${file.name}")
            }.onFailure { error ->
                exportMutable.value = exportMutable.value.copy(creating = false, error = error.message ?: "Export zlyhal.")
            }
        }
    }

    fun saveExportTo(uri: Uri) {
        val file = exportMutable.value.createdFile ?: return
        viewModelScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    getApplication<Application>().contentResolver.openOutputStream(uri, "w").use { output ->
                        requireNotNull(output) { "Cieľový súbor sa nepodarilo otvoriť." }
                        file.inputStream().use { it.copyTo(output) }
                    }
                }
            }.onSuccess { transient.value = TransientState(message = "Excel bol uložený.") }
                .onFailure { transient.value = TransientState(message = "Uloženie zlyhalo: ${it.message}") }
        }
    }

    fun importGallery(uris: List<Uri>, onFinished: (() -> Unit)? = null) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            transient.value = TransientState(importing = true)
            val batchId = UUID.randomUUID().toString()
            var imported = 0
            var failed = 0
            for (uri in uris) {
                val started = System.currentTimeMillis()
                try {
                    val stored = withContext(Dispatchers.IO) { app.storage.importFromGallery(uri) }
                    persist(stored, ImageSource.GALLERY, batchId, System.currentTimeMillis() - started)
                    imported++
                } catch (_: Throwable) {
                    failed++
                }
            }
            transient.value = TransientState(message = when {
                failed == 0 && imported == 1 -> "Fotografia bola zaradená na spracovanie."
                failed == 0 -> "$imported fotografií bolo zaradených na spracovanie."
                else -> "Importované: $imported, nepodarilo sa: $failed."
            })
            onFinished?.invoke()
        }
    }

    fun importScannedDocument(uri: Uri, onFinished: (() -> Unit)? = null) {
        viewModelScope.launch {
            transient.value = TransientState(importing = true)
            val started = System.currentTimeMillis()
            runCatching {
                val stored = withContext(Dispatchers.IO) { app.storage.importFromGallery(uri) }
                persist(
                    stored = stored,
                    source = ImageSource.CAMERA,
                    batchId = UUID.randomUUID().toString(),
                    importDuration = System.currentTimeMillis() - started,
                )
            }.onSuccess {
                transient.value = TransientState(message = "Naskenovaný doklad bol zaradený na spracovanie.")
            }.onFailure {
                transient.value = TransientState(message = "Naskenovaný obrázok sa nepodarilo uložiť: ${it.message}")
            }
            onFinished?.invoke()
        }
    }

    fun capture(
        imageCapture: ImageCapture,
        executor: Executor,
        snapshot: MultiFrameCaptureSnapshot,
        onFinished: () -> Unit,
    ) {
        val stored = app.storage.createCameraTarget()
        val options = ImageCapture.OutputFileOptions.Builder(stored.file).build()
        val started = System.currentTimeMillis()
        imageCapture.takePicture(options, executor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                viewModelScope.launch {
                    try {
                        persist(
                            stored = stored,
                            source = ImageSource.CAMERA,
                            batchId = UUID.randomUUID().toString(),
                            importDuration = System.currentTimeMillis() - started,
                            captureSnapshot = snapshot,
                        )
                        transient.value = TransientState(
                            message = "Doklad bol zachytený z ${snapshot.frameCount} frameov; " +
                                "OCR použije ${snapshot.selectedFrames.size} najlepších.",
                        )
                        onFinished()
                    } catch (_: Throwable) {
                        app.storage.discardCaptureFrames(snapshot)
                        transient.value = TransientState(message = "Fotografiu sa nepodarilo uložiť.")
                        onFinished()
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                app.storage.discard(stored)
                app.storage.discardCaptureFrames(snapshot)
                transient.value = TransientState(message = "Fotografovanie zlyhalo: ${exception.message}")
                onFinished()
            }
        })
    }

    fun retry(documentId: String) {
        viewModelScope.launch {
            runCatching { withContext(Dispatchers.IO) { app.scheduler.retry(documentId, dao) } }
                .onSuccess { transient.value = TransientState(message = "Doklad bol znovu zaradený.") }
                .onFailure { transient.value = TransientState(message = "Opätovné zaradenie zlyhalo: ${it.message}") }
        }
    }

    fun saveDocumentEdit(id: String, supplier: String, date: String, number: String, grossTotal: String) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.updateManualHeader(
                id = id,
                supplier = supplier.trim().ifBlank { null },
                purchaseDate = date.trim().ifBlank { null },
                documentNumber = number.trim().ifBlank { null },
                grossTotal = GenericDocumentParser.parseCents(grossTotal),
                now = System.currentTimeMillis(),
            )
            transient.value = TransientState(message = "Úpravy boli uložené.")
        }
    }

    fun saveItemName(itemId: Long, name: String) {
        val corrected = name.trim().replace(Regex("\\s+"), " ")
        if (corrected.length < 2) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.updateItemName(itemId, corrected)
            transient.value = TransientState(
                message = "Názov položky bol uložený. Pri rovnakom EAN sa použije aj nabudúce.",
            )
        }
    }

    fun dismissMessage() { transient.value = transient.value.copy(message = null) }

    private suspend fun persist(
        stored: StoredImage,
        source: ImageSource,
        batchId: String,
        importDuration: Long,
        captureSnapshot: MultiFrameCaptureSnapshot? = null,
    ) {
        val now = System.currentTimeMillis()
        var inserted = false
        try {
            withContext(Dispatchers.IO) {
                val savedFrames = captureSnapshot?.let { app.storage.persistCaptureFrames(stored.id, it) }.orEmpty()
                dao.insert(DocumentEntity(
                    id = stored.id,
                    status = DocumentStatus.CAPTURED,
                    imageSource = source,
                    originalImagePath = stored.file.absolutePath,
                    originalDisplayName = stored.displayName,
                    originalMimeType = stored.mimeType,
                    createdAt = now,
                    updatedAt = now,
                    batchId = batchId,
                    importDurationMs = importDuration,
                    captureMode = if (captureSnapshot != null) CaptureMode.MULTI_FRAME else CaptureMode.SINGLE_IMAGE,
                    frameCount = captureSnapshot?.frameCount ?: 0,
                    selectedFrameCount = savedFrames.size,
                    bestFrameScore = captureSnapshot?.bestFrameScore,
                    averageFrameScore = captureSnapshot?.averageFrameScore,
                    imageQualityConfidence = captureSnapshot?.averageFrameScore,
                ))
                inserted = true
                if (savedFrames.isNotEmpty()) {
                    dao.insertFrames(savedFrames.map { frame ->
                        DocumentFrameEntity(
                            id = "${stored.id}_${frame.sequence}",
                            documentId = stored.id,
                            sequence = frame.sequence,
                            capturedAt = frame.capturedAt,
                            filePath = frame.file.absolutePath,
                            qualityScore = frame.metrics.qualityScore,
                            sharpness = frame.metrics.sharpnessScore,
                            exposure = frame.metrics.exposureScore,
                            contrast = frame.metrics.contrastScore,
                            perspective = frame.metrics.perspectiveScore,
                            stability = frame.metrics.stabilityScore,
                            glare = frame.metrics.glareScore,
                            coverage = frame.metrics.documentCoverage,
                            clipping = frame.metrics.clippingScore,
                            selectedForOcr = true,
                        )
                    })
                }
                app.scheduler.enqueue(stored.id, dao)
            }
        } catch (error: Throwable) {
            if (inserted) {
                withContext(Dispatchers.IO) {
                    dao.markError(
                        id = stored.id,
                        stage = "ENQUEUE",
                        message = error.message ?: "WorkManager úlohu sa nepodarilo zaradiť.",
                        stackTrace = error.stackTraceToString().take(16_000),
                        totalDuration = 0,
                        now = System.currentTimeMillis(),
                    )
                }
            } else app.storage.discard(stored)
            throw error
        }
    }

    private data class TransientState(val importing: Boolean = false, val message: String? = null)
}

fun DocumentStatus.slovakLabel(): String = when (this) {
    DocumentStatus.CAPTURED, DocumentStatus.QUEUED -> "Čaká"
    DocumentStatus.PREPROCESSING -> "Príprava obrázka"
    DocumentStatus.OCR -> "Čítam text"
    DocumentStatus.PARSING -> "Rozpoznávam položky"
    DocumentStatus.VALIDATING -> "Kontrolujem"
    DocumentStatus.PROCESSED -> "Spracované"
    DocumentStatus.REVIEW_REQUIRED -> "Na kontrolu"
    DocumentStatus.ERROR -> "Chyba"
}
