package sk.doklady.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(document: DocumentEntity)

    @Query("""
        SELECT * FROM documents
        ORDER BY CASE status
            WHEN 'PREPROCESSING' THEN 0 WHEN 'OCR' THEN 0 WHEN 'PARSING' THEN 0 WHEN 'VALIDATING' THEN 0
            WHEN 'QUEUED' THEN 1 WHEN 'CAPTURED' THEN 1 ELSE 2 END,
            createdAt DESC
    """)
    fun observeAll(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    fun observe(id: String): Flow<DocumentEntity?>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun get(id: String): DocumentEntity?

    @Query("SELECT * FROM documents ORDER BY createdAt DESC")
    suspend fun getAll(): List<DocumentEntity>

    @Query("SELECT * FROM documents WHERE status IN ('CAPTURED','QUEUED','PREPROCESSING','OCR','PARSING','VALIDATING')")
    suspend fun getRecoverable(): List<DocumentEntity>

    @Query("UPDATE documents SET status = :status, updatedAt = :updatedAt, errorMessage = :error WHERE id = :id")
    suspend fun updateStatus(
        id: String,
        status: DocumentStatus,
        updatedAt: Long,
        error: String? = null,
    )

    @Query("""
        UPDATE documents SET status = :status, stageProgress = :progress, phaseStartedAt = :now,
        updatedAt = :now, errorStage = NULL, errorMessage = NULL, errorStackTrace = NULL
        WHERE id = :id
    """)
    suspend fun transition(id: String, status: DocumentStatus, progress: Int, now: Long)

    @Query("""
        UPDATE documents SET status = 'QUEUED', stageProgress = 0, workId = :workId,
        updatedAt = :now, errorStage = NULL, errorMessage = NULL, errorStackTrace = NULL
        WHERE id = :id
    """)
    suspend fun markQueued(id: String, workId: String, now: Long)

    @Query("UPDATE documents SET attemptCount = attemptCount + 1, updatedAt = :now WHERE id = :id")
    suspend fun incrementAttempt(id: String, now: Long)

    @Query("UPDATE documents SET processedImagePath = :path, preprocessingDurationMs = :duration, updatedAt = :now WHERE id = :id")
    suspend fun savePreprocessing(id: String, path: String, duration: Long, now: Long)

    @Query("""
        UPDATE documents SET rawOcrText = :rawText, ocrDurationMs = :duration,
        ocrStrategy = :strategy, ocrPassCount = :passCount, ocrQualityScore = :qualityScore,
        updatedAt = :now WHERE id = :id
    """)
    suspend fun saveOcr(
        id: String,
        rawText: String,
        duration: Long,
        strategy: String,
        passCount: Int,
        qualityScore: Int,
        now: Long,
    )

    @Query("""
        UPDATE documents SET supplierName = :supplier, supplierRegistrationId = :registrationId,
        documentNumber = :documentNumber, purchaseDate = :purchaseDate, currency = :currency,
        netTotalCents = :netTotal, vatTotalCents = :vatTotal, grossTotalCents = :grossTotal,
        itemCount = :itemCount, parsingDurationMs = :duration, updatedAt = :now WHERE id = :id
    """)
    suspend fun saveParsed(
        id: String,
        supplier: String?,
        registrationId: String?,
        documentNumber: String?,
        purchaseDate: String?,
        currency: String?,
        netTotal: Long?,
        vatTotal: Long?,
        grossTotal: Long?,
        itemCount: Int,
        duration: Long,
        now: Long,
    )

    @Query("""
        UPDATE documents SET status = :status, stageProgress = 100, confidence = :confidence,
        validationDurationMs = :validationDuration, totalDurationMs = :totalDuration,
        finishedAt = :now, updatedAt = :now WHERE id = :id
    """)
    suspend fun finish(
        id: String,
        status: DocumentStatus,
        confidence: Int,
        validationDuration: Long,
        totalDuration: Long,
        now: Long,
    )

    @Query("""
        UPDATE documents SET status = 'ERROR', stageProgress = 100, errorStage = :stage,
        errorMessage = :message, errorStackTrace = :stackTrace, totalDurationMs = :totalDuration,
        finishedAt = :now, updatedAt = :now WHERE id = :id
    """)
    suspend fun markError(
        id: String,
        stage: String,
        message: String,
        stackTrace: String,
        totalDuration: Long,
        now: Long,
    )

    @Query("UPDATE documents SET importDurationMs = :duration WHERE id = :id")
    suspend fun saveImportDuration(id: String, duration: Long)

    @Query("""
        UPDATE documents SET supplierName = :supplier, purchaseDate = :purchaseDate,
        documentNumber = :documentNumber, grossTotalCents = :grossTotal,
        updatedAt = :now WHERE id = :id
    """)
    suspend fun updateManualHeader(
        id: String,
        supplier: String?,
        purchaseDate: String?,
        documentNumber: String?,
        grossTotal: Long?,
        now: Long,
    )

    @Query("DELETE FROM document_items WHERE documentId = :documentId")
    suspend fun deleteItems(documentId: String)

    @Insert suspend fun insertItems(items: List<DocumentItemEntity>)

    @Query("SELECT * FROM document_items WHERE documentId = :documentId ORDER BY position")
    fun observeItems(documentId: String): Flow<List<DocumentItemEntity>>

    @Query("SELECT * FROM document_items ORDER BY documentId, position")
    suspend fun getAllItems(): List<DocumentItemEntity>

    @Query("SELECT name FROM document_items WHERE ean = :ean AND manualEdited = 1 ORDER BY id DESC LIMIT 1")
    suspend fun findManualProductName(ean: String): String?

    @Query("""
        SELECT DISTINCT name FROM document_items
        WHERE manualEdited = 1 OR (nameConfidence >= 94 AND length(name) >= 4)
        ORDER BY manualEdited DESC, id DESC LIMIT 500
    """)
    suspend fun getLocalProductVocabulary(): List<String>

    @Query("UPDATE document_items SET name = :name, manualEdited = 1, nameConfidence = 100 WHERE id = :itemId")
    suspend fun updateItemName(itemId: Long, name: String)

    @Query("DELETE FROM ocr_elements WHERE documentId = :documentId")
    suspend fun deleteOcrElements(documentId: String)

    @Insert suspend fun insertOcrElements(elements: List<OcrElementEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFrames(frames: List<DocumentFrameEntity>)

    @Query("SELECT * FROM document_frames WHERE documentId = :documentId AND selectedForOcr = 1 ORDER BY qualityScore DESC")
    suspend fun getSelectedFrames(documentId: String): List<DocumentFrameEntity>

    @Query("""
        UPDATE document_frames SET ocrText = :text, ocrConfidence = :confidence,
        ocrDurationMs = :duration WHERE id = :frameId
    """)
    suspend fun saveFrameOcr(frameId: String, text: String, confidence: Float?, duration: Long)

    @Query("""
        UPDATE documents SET imageQualityConfidence = :imageQuality,
        consensusConfidence = :consensus, ocrConsistencyConfidence = :ocrConsistency,
        parserConfidence = :parserConfidence, validationConfidence = :validationConfidence,
        finalConfidence = :finalConfidence, conflictingTokens = :conflictingTokens,
        secondPassUsed = :secondPassUsed, mathValidationResult = :mathResult,
        parserValidationResult = :parserResult, updatedAt = :now WHERE id = :id
    """)
    suspend fun saveConfidenceDiagnostics(
        id: String,
        imageQuality: Float?,
        consensus: Float?,
        ocrConsistency: Float?,
        parserConfidence: Float?,
        validationConfidence: Float?,
        finalConfidence: Float?,
        conflictingTokens: Int,
        secondPassUsed: Boolean,
        mathResult: String,
        parserResult: String,
        now: Long,
    )

    @Query("DELETE FROM vat_summaries WHERE documentId = :documentId")
    suspend fun deleteVatSummaries(documentId: String)

    @Insert suspend fun insertVatSummaries(rows: List<VatSummaryEntity>)

    @Query("SELECT * FROM vat_summaries ORDER BY documentId, rate")
    suspend fun getAllVatSummaries(): List<VatSummaryEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertSupplier(supplier: SupplierEntity)

    @Query("SELECT * FROM suppliers ORDER BY name")
    suspend fun getAllSuppliers(): List<SupplierEntity>

    @Insert suspend fun insertLog(log: ProcessingLogEntity): Long

    @Query("UPDATE processing_logs SET status = :status, endTime = :endTime, durationMs = :duration, errorMessage = :error WHERE id = :id")
    suspend fun finishLog(id: Long, status: String, endTime: Long, duration: Long, error: String? = null)

    @Query("SELECT * FROM processing_logs ORDER BY startTime DESC LIMIT :limit")
    fun observeLogs(limit: Int = 200): Flow<List<ProcessingLogEntity>>

    @Transaction
    suspend fun replaceOcr(documentId: String, elements: List<OcrElementEntity>) {
        deleteOcrElements(documentId)
        if (elements.isNotEmpty()) insertOcrElements(elements)
    }

    @Transaction
    suspend fun replaceItems(documentId: String, items: List<DocumentItemEntity>) {
        deleteItems(documentId)
        if (items.isNotEmpty()) insertItems(items)
    }
}
