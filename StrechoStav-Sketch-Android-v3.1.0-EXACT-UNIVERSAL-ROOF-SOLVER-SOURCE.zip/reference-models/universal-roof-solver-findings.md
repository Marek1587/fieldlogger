# Univerzálny strešný solver – extrakcia modelu a poznatkov

## Vytvorený kanonický model

L-polvalbová strecha bola prevedená z pevného generátora na face-based dátový model. Model obsahuje 14 spoločných uzlov, 19 explicitných hrán a 6 finálnych strešných plôch. Každá plocha má rovnicu `z = a*x + b*y + c` a odkazuje iba na stabilné ID uzlov. Maximálny reziduál rovín je 0.000005 mm.

Dôležité: názov `lHalfHip` zostal iba v `legacyInputSnapshot` a metadátach. Geometriu JSON-u určujú `nodes`, `edges`, `faces` a `constraints`.

## Preskúmané modely

- `ploche_atika_chrlic.php`
- `ploche_atika_vnutorne_vpuste.php`
- `ploche_atika_zlab_zvod.php`
- `sikma_polvalbova_L.php`
- `sikma_polvalbova_multi.php`
- `sikma_polvalbova_stn.php`
- `sikma_polvalbova_stn_valcovy_slider.php`
- `sikma_pultova.php`
- `sikma_sedlova.php`
- `sikma_sedlova_L.php`
- `sikma_sedlova_pultvikier.php`
- `sikma_stanova.php`
- `sikma_valbova.php`

Tri ploché modely sa líšia odvodnením; tri STN/slider sú varianty tej istej L-polvalbovej geometrie a UI. Spoločný skopírovaný rendering sa neposudzoval ako samostatný geometrický poznatok.

## Poznatky prenesené do univerzálneho jadra

1. **Pultová plocha:** flip je iba zmena smeru gradientu roviny. Nepotrebuje vlastný generátor typu strechy.
2. **Sedlová strecha:** hrebeň je spoločný prienik dvoch rovín. Rozdielne výšky odkvapov prirodzene posunú hrebeň.
3. **Valbová a stanová strecha:** stanová strecha je limitný stav, keď dĺžka hrebeňa klesne na nulu. Toto je topologická udalosť.
4. **Polvalba:** oba koncové rezy sú nezávislé constraints. Ich súčet nesmie zničiť hrebeň bez explicitnej zmeny topológie.
5. **L-pôdorys:** úžľabia a spojovacie nárožia majú vznikať prienikom susedných rovín nad spoločnou hranou.
6. **Vikier:** potrebuje sekundárny RoofComponent a otvor v hostiteľskej ploche. Schéma preto musí podporovať `Face.holes` alebo presné rozdelenie bez prekrytia.
7. **Plochá strecha:** vpust je spoločný nízky uzol viacerých spádových rovín; chrlič/žľab je nízka hrana. Ide o rovnaký face solver, iba s malým sklonom a inými constraints.
8. **Atika a zvislé steny:** nie sú RoofFace, pretože zvislú rovinu nemožno zapísať ako `z=a*x+b*y+c`. Patria do odvodenej shell/accessory vrstvy.

## Čo zo súčasných PHP modelov zachovať

- WebGL rendering a trianguláciu ako adapter nad face modelom.
- Kameru, overlay kót, hitboxy, pôdorys a rezy.
- Koliesko po doplnení snapshotu, Cancel, jedného Undo kroku a solve transaction.
- Výpočty plôch a dĺžok ako audit/reporting.

## Čo nepoužiť ako solver

Novšie súbory obsahujú objekt `SOLVER_FRAMEWORK`, ale ten iba klasifikuje preset, spočíta moduly, vykoná základnú kontrolu polygonov a následne volá `buildWorldLegacy()`. Nie je to constraint solver a nemá sa prenášať do nového kernelu ako geometrické jadro.

## Odporúčaný ďalší implementačný krok

Načítať kanonický JSON do malého nezávislého TypeScript/JavaScript kernelu, ktorý najprv overí referenčnú integritu a koplanaritu. Potom implementovať editáciu jedného `DimensionConstraint` cez KKT/null-space constrained least squares a validovaný line-search. Renderer má dostať iba odvodený triangulovaný snapshot.
