package sk.strechasketch.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@SuppressLint("SetTextI18n")
class MainActivity : Activity() {
    private lateinit var store: ProjectStore
    private var currentProject: RoofProject? = null
    private var editorView: RoofMapEditorView? = null
    private var editorStatus: TextView? = null
    private var editorMetrics: TextView? = null
    private var active3DView: Roof3DView? = null
    private var activeMapHost: FreeRoofMapHost? = null
    private var last3DGraphBeforeEdit: RoofGraph? = null
    private var screen = Screen.HOME
    private var pendingExport: ByteArray? = null
    private var pendingExportName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BRAND_DARK
        window.navigationBarColor = BRAND_DARK
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        store = ProjectStore(this)
        showHome()
    }

    override fun onPause() {
        active3DView?.onPause()
        activeMapHost?.onPause()
        currentProject?.let(store::save)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        active3DView?.onResume()
        activeMapHost?.onResume()
    }

    override fun onLowMemory() {
        activeMapHost?.onLowMemory()
        super.onLowMemory()
    }

    override fun onDestroy() {
        activeMapHost?.onDestroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.HOME -> super.onBackPressed()
            Screen.EDITOR -> showHome()
            Screen.THREE_D, Screen.SUMMARY, Screen.WORK_SCOPE, Screen.PDF -> currentProject?.let(::showEditor) ?: showHome()
        }
    }

    private fun showHome() {
        screen = Screen.HOME
        last3DGraphBeforeEdit = null
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        editorView = null
        val root = verticalRoot()
        root.addView(appBar("StrechoStav Sketch", null))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = rounded(Color.rgb(237, 248, 237), 0f, stroke = Color.rgb(200, 223, 202))
        }
        hero.addView(label("Strecha od mapy po 3D model", 23f, true, INK))
        hero.addView(label(
            "Vyhľadajte stavbu, importujte alebo obkreslite obrys, doplňte klampiarske prvky a exportujte technický nákres.",
            14f, false, MUTED
        ).apply { setPadding(0, dp(7), 0, dp(12)) })
        val heroActions = row()
        heroActions.addView(actionButton("Nový projekt", BRAND) { showNewProjectDialog() })
        heroActions.addView(actionButton("Import JSON", Color.rgb(56, 76, 88)) { openJsonImport() })
        hero.addView(heroActions)
        root.addView(hero)

        val title = label("Uložené projekty", 18f, true, INK).apply {
            setPadding(dp(18), dp(18), dp(18), dp(8))
        }
        root.addView(title)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(28))
        }
        val projects = store.list()
        if (projects.isEmpty()) {
            list.addView(label(
                "Zatiaľ nemáte žiadny projekt. Začnite tlačidlom „Nový projekt“.",
                16f, false, MUTED
            ).apply {
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(70), dp(24), dp(70))
            })
        } else {
            projects.forEach { list.addView(projectCard(it)) }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun projectCard(project: RoofProject): View {
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(Color.WHITE, 14f, stroke = Color.rgb(209, 220, 211))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(11)) }
            addView(label(project.name, 19f, true, INK))
            addView(label(
                buildString {
                    if (project.customer.isNotBlank()) append(project.customer).append(" • ")
                    append(project.address.ifBlank { "Bez adresy" })
                    append("\n")
                    append("${format1(totals.footprintAreaM2)} m² • ${quantityAudit.faces.size} plôch • predvolený sklon ${format1(project.slopeDeg)}°")
                    append(" • ")
                    append(SimpleDateFormat("d. M. yyyy HH:mm", Locale("sk", "SK")).format(Date(project.updatedAt)))
                },
                13f, false, MUTED
            ).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(row().apply {
                addView(actionButton("Otvoriť", BRAND) {
                    currentProject = project
                    showEditor(project)
                })
                addView(actionButton("3D", Color.rgb(164, 48, 35)) {
                    currentProject = project
                    show3D(project)
                })
                addView(actionButton("Kópia", Color.rgb(62, 83, 96)) {
                    store.duplicate(project)
                    showHome()
                })
                addView(actionButton("Odstrániť", Color.rgb(150, 50, 45)) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Odstrániť projekt?")
                        .setMessage(project.name)
                        .setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Odstrániť") { _, _ ->
                            store.delete(project.id)
                            showHome()
                        }.show()
                })
            })
        }
    }

    private fun showNewProjectDialog() {
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = edit("Názov projektu", "Strecha ${SimpleDateFormat("d.M.yyyy", Locale("sk", "SK")).format(Date())}")
        val customer = edit("Zákazník", "")
        val address = edit("Adresa alebo GPS", "")
        fields.addView(name)
        fields.addView(customer)
        fields.addView(address)
        AlertDialog.Builder(this)
            .setTitle("Nový projekt")
            .setView(fields)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Vytvoriť") { _, _ ->
                val project = RoofProject(
                    name = name.text.toString().trim().ifBlank { "Nová strecha" },
                    customer = customer.text.toString().trim(),
                    address = address.text.toString().trim()
                )
                store.save(project)
                currentProject = project
                showEditor(project)
            }.show()
    }

    private fun showEditor(project: RoofProject, workspaceTab: WorkspaceTab = WorkspaceTab.OUTLINE) {
        screen = Screen.EDITOR
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar(project.name) { showHome() })
        root.addView(workspaceNavigation(project, workspaceTab))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        val search = edit("Adresa alebo 49.123, 18.456", project.address).apply {
            setSingleLine()
            setPadding(dp(12), 0, dp(8), 0)
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f))
        searchRow.addView(compactButton("Nájsť") { resolveLocation(search.text.toString(), project) })
        searchRow.addView(compactButton("Budova") { importNearestBuilding(project) })
        searchRow.addView(compactButton("GPS") { useDeviceLocation() })
        if (workspaceTab == WorkspaceTab.OUTLINE) root.addView(searchRow)

        val settings = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(246, 248, 246))
        }
        val settingsRow = row().apply { setPadding(dp(8), dp(6), dp(8), dp(6)) }
        settingsRow.addView(label("Sklon °", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val slope = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(format1(project.slopeDeg))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(slope, LinearLayout.LayoutParams(dp(72), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        val shapeSpinner = Spinner(this)
        shapeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            RoofShape.entries.map { it.label }
        )
        shapeSpinner.setSelection(RoofShape.entries.indexOf(project.shape))
        settingsRow.addView(label("3D podľa plôch", 13f, true, BRAND).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(14), 0)
        }, LinearLayout.LayoutParams(dp(150), dp(44)))
        settingsRow.addView(label("Steny m", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val wallHeight = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(format1(project.wallHeightM))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(wallHeight, LinearLayout.LayoutParams(dp(76), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        settings.addView(settingsRow)
        if (workspaceTab == WorkspaceTab.OUTLINE) root.addView(settings)

        val tools = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(30, 62, 40))
        }
        val toolRow = row().apply { setPadding(dp(7), dp(5), dp(7), dp(5)) }
        tools.addView(toolRow)
        root.addView(tools)

        val mapFrame = FrameLayout(this)
        val mapHost = FreeRoofMapHost(this, project)
        activeMapHost = mapHost
        val map = mapHost.editor
        editorView = map
        map.setWorkspace(when (workspaceTab) {
            WorkspaceTab.OUTLINE -> EditorWorkspace.OUTLINE
            WorkspaceTab.INTERNAL -> EditorWorkspace.INTERNAL_LINES
            else -> EditorWorkspace.TYPOLOGY
        })
        mapFrame.addView(mapHost, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val zoomControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), dp(6), 0)
            addView(mapControlButton("+") { mapHost.zoomBy(1f) })
            addView(mapControlButton("−") { mapHost.zoomBy(-1f) })
            addView(mapControlButton("Celok") { mapHost.fitCurrent() })
            if (workspaceTab == WorkspaceTab.OUTLINE) addView(mapControlButton("Sever") { map.resetMapRotation() })
        }
        mapFrame.addView(
            zoomControls,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        )
        root.addView(mapFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun tool(text: String, click: () -> Unit) {
            toolRow.addView(actionButton(text, Color.rgb(49, 93, 60), click))
        }
        when (workspaceTab) {
            WorkspaceTab.OUTLINE -> {
                tool("ZBGIS ortofoto") { mapHost.setMapType("ZBGIS_ORTHO"); store.save(project) }
                tool("Podklad z PDF/JPG") {
                    if (project.underlayUri.isBlank()) openUnderlayImport()
                    else AlertDialog.Builder(this)
                        .setTitle("Podklad z PDF/JPG")
                        .setItems(arrayOf("Zobraziť ${project.underlayName}", "Vybrať iný podklad")) { _, which ->
                            if (which == 0) {
                                mapHost.showDocument(Uri.parse(project.underlayUri), project.underlayMime, project.underlayName, false)
                                store.save(project)
                            } else openUnderlayImport()
                        }.show()
                }
                tool("Obrys prstom") { map.setMode(EditorMode.DRAW_POLYGON) }
                tool("Pridať bod") { map.addMidpointToSelectedEdge() }
                tool("Editovať") { map.setMode(EditorMode.EDIT) }
            }
            WorkspaceTab.INTERNAL -> {
                tool("Pridať líniu") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.UNKNOWN) }
                tool("Editovať líniu") { map.setMode(EditorMode.EDIT_LINES) }
            }
            WorkspaceTab.TYPOLOGY -> {
                tool("Komín") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.CHIMNEY) }
                tool("Strešné okno") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.ROOF_WINDOW) }
                tool("Výlez") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.HATCH) }
                tool("Prestup") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.VENT) }
                tool("Vpusť") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.DRAIN) }
                tool("Zvod") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.DOWNSPOUT) }
                tool("Výšková kóta") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.HEIGHT_MARK) }
                tool("Značka sklonu") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.SLOPE_MARK) }
            }
            else -> Unit
        }

        editorStatus = label("Posúvajte mapu alebo vyhľadajte adresu.", 12f, false, MUTED).apply {
            setPadding(dp(10), dp(5), dp(10), dp(4))
            setBackgroundColor(Color.WHITE)
        }
        editorMetrics = label("", 12f, true, INK).apply {
            setPadding(dp(10), dp(3), dp(10), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(editorStatus)
        root.addView(editorMetrics)

        val actionRow = row().apply {
            setPadding(dp(4), dp(3), dp(4), dp(4))
            setBackgroundColor(Color.rgb(238, 243, 238))
        }
        when (workspaceTab) {
            WorkspaceTab.OUTLINE -> {
                actionRow.addView(editorToolButton("Uzavrieť", R.drawable.ic_action_close, BRAND) { map.finishPolygon() })
                actionRow.addView(editorToolButton("Skorigovať obrys", R.drawable.ic_action_solve, BRAND) {
                    showSolverPreviewDialog(map)
                })
                actionRow.addView(editorToolButton("Odstrániť bod", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelectedPoint()
                })
            }
            WorkspaceTab.INTERNAL -> {
                actionRow.addView(editorToolButton("Skorigovať línie", R.drawable.ic_action_solve, BRAND) {
                    showSolverPreviewDialog(map)
                })
                actionRow.addView(editorToolButton("Odstrániť", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelection()
                })
            }
            WorkspaceTab.TYPOLOGY -> {
                actionRow.addView(editorToolButton("Späť", R.drawable.ic_action_close, Color.rgb(67, 91, 105)) { map.undo() })
                actionRow.addView(editorToolButton("Odstrániť prvok", R.drawable.ic_action_delete_point, Color.rgb(151, 54, 46)) {
                    map.deleteSelection()
                })
            }
            else -> Unit
        }
        actionRow.addView(editorToolButton("Viac", R.drawable.ic_action_more, Color.rgb(67, 91, 105)) {
            val items = when (workspaceTab) {
                WorkspaceTab.OUTLINE -> arrayOf("Späť", "Znova", "Rozmer vybratej hrany", "Vyčistiť obrys", "Uložiť")
                WorkspaceTab.INTERNAL -> arrayOf(
                    "Späť", "Znova", "Pripojiť koniec k uzlu", "Odpojiť koniec",
                    "Rozdeliť líniu", "Odstrániť líniu", "Uložiť"
                )
                WorkspaceTab.TYPOLOGY -> arrayOf("Späť", "Znova", "Odstrániť technický prvok", "Uložiť")
                else -> emptyArray()
            }
            AlertDialog.Builder(this).setTitle("Nástroje").setItems(items) { _, which ->
                if (which == 0) map.undo()
                else if (which == 1) map.redo()
                else when (workspaceTab) {
                    WorkspaceTab.OUTLINE -> when (which) {
                        2 -> showEdgeLengthDialog(map, mapHost)
                        3 -> AlertDialog.Builder(this)
                            .setTitle("Vyčistiť celý nákres?")
                            .setNegativeButton("Zrušiť", null)
                            .setPositiveButton("Vyčistiť") { _, _ -> map.clearDrawing() }
                            .show()
                        4 -> {
                            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    WorkspaceTab.INTERNAL -> when (which) {
                        2 -> map.joinSelectedEndpointToNearest()
                        3 -> map.disconnectSelectedEndpoint()
                        4 -> map.splitSelectedLine()
                        5 -> map.deleteSelection()
                        6 -> {
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    WorkspaceTab.TYPOLOGY -> when (which) {
                        2 -> map.deleteSelection()
                        3 -> {
                            store.save(project)
                            toast("Projekt uložený.")
                        }
                    }
                    else -> Unit
                }
            }.show()
        })
        root.addView(actionRow)

        map.onProjectChanged = {
            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
            store.save(project)
            refreshEditorMetrics(project)
        }
        map.onBoundaryEdgeLongPressed = { edgeIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showEdgeSemanticDialog(map, project, boundaryIndex = edgeIndex)
        }
        map.onBoundaryDimensionLongPressed = {
            if (workspaceTab == WorkspaceTab.OUTLINE) showEdgeLengthDialog(map, mapHost)
        }
        map.onLineLongPressed = { lineIndex ->
            if (workspaceTab == WorkspaceTab.TYPOLOGY) showEdgeSemanticDialog(map, project, lineIndex = lineIndex)
        }
        map.onStatusChanged = { editorStatus?.text = it }
        mapHost.onStatusChanged = { editorStatus?.text = it }
        slope.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                project.slopeDeg = slope.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 75.0) ?: project.slopeDeg
                store.save(project)
                refreshEditorMetrics(project)
            }
        }
        wallHeight.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                project.wallHeightM = wallHeight.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.5, 100.0) ?: project.wallHeightM
                store.save(project)
            }
        }
        mapHost.onResume()
        shapeSpinner.onItemSelectedListener = simpleSelection {
            project.shape = RoofShape.entries[shapeSpinner.selectedItemPosition]
            store.save(project)
        }
        refreshEditorMetrics(project)
        setContentView(root)
    }

    private fun updateEditorSettings(project: RoofProject, slope: EditText, wallHeight: EditText, shape: Spinner) {
        project.slopeDeg = slope.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 75.0) ?: project.slopeDeg
        project.wallHeightM = wallHeight.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.5, 100.0) ?: project.wallHeightM
        project.shape = RoofShape.entries[shape.selectedItemPosition]
    }

    private fun refreshEditorMetrics(project: RoofProject) {
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        editorMetrics?.text = "Pôdorys ${format1(totals.footprintAreaM2)} m²  •  strecha ${format1(totals.roofAreaM2)} m²  •  obvod ${format1(totals.perimeterM)} m  •  ${project.polygon.size} bodov"
    }

    private fun resolveLocation(input: String, project: RoofProject) {
        val text = input.trim()
        if (text.isBlank()) {
            toast("Zadajte adresu alebo GPS súradnice.")
            return
        }
        parseCoordinates(text)?.let { point ->
            project.address = "${point.lat}, ${point.lon}"
            editorView?.setCenter(point)
            store.save(project)
            return
        }
        val loading = loadingDialog("Hľadám adresu…")
        GeoServices.geocode(text) { result ->
            loading.dismiss()
            result.onSuccess { place ->
                project.address = place.displayName
                editorView?.setCenter(place.point)
                store.save(project)
                editorStatus?.text = "Adresa nájdená: ${place.displayName}"
            }.onFailure { toast(it.message ?: "Adresu sa nepodarilo nájsť.") }
        }
    }

    private fun importNearestBuilding(project: RoofProject) {
        val center = GeoPoint(project.centerLat, project.centerLon)
        val loading = loadingDialog("Hľadám obrys budovy v OpenStreetMap…")
        GeoServices.nearestBuilding(center) { result ->
            loading.dismiss()
            result.onSuccess { building ->
                val details = buildString {
                    append("Plocha: ${format1(building.areaM2)} m²\n")
                    append("Vzdialenosť od stredu: ${format1(building.distanceM)} m\n")
                    append("OSM: ${building.buildingType} #${building.osmId}")
                    if (building.name.isNotBlank()) append("\n${building.name}")
                    if (project.polygon.isNotEmpty()) append("\n\nExistujúci nákres bude nahradený.")
                }
                AlertDialog.Builder(this)
                    .setTitle("Importovať najbližšiu budovu?")
                    .setMessage(details)
                    .setNegativeButton("Zrušiť", null)
                    .setPositiveButton("Importovať") { _, _ ->
                        editorView?.importPolygon(building.points)
                        store.save(project)
                    }.show()
            }.onFailure { toast(it.message ?: "Budova sa nenašla.") }
        }
    }

    private fun useDeviceLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }
        moveToLastLocation()
    }

    private fun moveToLastLocation() {
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { provider ->
                    runCatching {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        ) manager.getLastKnownLocation(provider) else null
                    }.getOrNull()
                }.maxByOrNull { it.time }
            if (location != null) {
                val point = GeoPoint(location.latitude, location.longitude)
                currentProject?.let {
                    it.address = "${point.lat}, ${point.lon}"
                    editorView?.setCenter(point, 20)
                    store.save(it)
                }
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Poloha nie je dostupná")
                    .setMessage("Zapnite polohu v telefóne alebo zadajte GPS súradnice ručne.")
                    .setNegativeButton("Zavrieť", null)
                    .setPositiveButton("Nastavenia") { _, _ ->
                        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }.show()
            }
        } catch (error: Exception) {
            toast(error.message ?: "Polohu sa nepodarilo načítať.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            moveToLastLocation()
        }
    }

    private fun show3D(project: RoofProject) {
        if (project.polygon.size < 3) {
            toast("Najprv vytvorte uzavretý obrys strechy.")
            return
        }
        val topology = project.roofGraph?.toTopology()
            ?: project.roofTopology
            ?: RoofTopologyMigration.fromLegacyProject(project)
        val solvedTopology = RoofTopologySolver.solve(topology).proposed
        val graph = RoofGraphFactory.fromTopology(solvedTopology, project.roofGraph)
        if (graph.faces.isEmpty()) {
            AlertDialog.Builder(this)
                .setTitle("Chýbajú uzavreté strešné plochy")
                .setMessage("V karte Vnútorné línie spojte hrany do uzavretých plôch. Typ strechy sa nevyberá – 3D vzniká priamo z FaceId.")
                .setNegativeButton("Zavrieť", null)
                .setPositiveButton("Zobraziť v nákrese") { _, _ ->
                    showEditor(project, WorkspaceTab.INTERNAL)
                }
                .show()
            return
        }
        val planeSolution = RoofPlaneSolver.solve(graph, project.wallHeightM, project.slopeDeg)
        if (planeSolution.hasBlockingIssues) {
            AlertDialog.Builder(this)
                .setTitle("3D model nemožno bezpečne vytvoriť")
                .setMessage(planeSolution.issues.filter { it.blocking }.joinToString("\n\n") { "• ${it.message}" })
                .setNegativeButton("Zavrieť", null)
                .setPositiveButton("Otvoriť typológiu") { _, _ -> showEditor(project, WorkspaceTab.TYPOLOGY) }
                .show()
            return
        }
        project.roofTopology = solvedTopology
        project.roofGraph = planeSolution.graph
        store.save(project)
        screen = Screen.THREE_D
        disposeActiveMap()
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("3D • ${project.name}") { showEditor(project) }.apply {
            addView(compactButton("Reset") { active3DView?.resetView() })
            if (last3DGraphBeforeEdit != null) addView(compactButton("Undo rozmer") {
                project.roofGraph = last3DGraphBeforeEdit
                project.roofTopology = last3DGraphBeforeEdit?.toTopology()
                last3DGraphBeforeEdit = null
                store.save(project)
                show3D(project)
            })
        })
        root.addView(workspaceNavigation(project, WorkspaceTab.MODEL_3D))
        val settings = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.WHITE)
        }
        settings.addView(label(
            "${planeSolution.graph.faces.size} plôch z RoofGraph  •  predvolený sklon ${format1(project.slopeDeg)}°  •  steny ${format1(project.wallHeightM)} m" +
                if (planeSolution.issues.isNotEmpty()) "  •  doplniť constraints: ${planeSolution.issues.size}" else "  •  model určený",
            13f, true, INK
        ))
        root.addView(settings)
        val view = Roof3DView(this)
        active3DView = view
        view.setProject(project)
        val modelFrame = FrameLayout(this).apply {
            addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val dimensions = HorizontalScrollView(this@MainActivity).apply {
                isHorizontalScrollBarEnabled = false
                setBackgroundColor(0xddffffff.toInt())
                addView(row().apply {
                    setPadding(dp(6), dp(5), dp(6), dp(5))
                    planeSolution.graph.edges.values.filter { it.boundary }.sortedBy { it.id }.forEach { edge ->
                        val a = planeSolution.graph.nodes.getValue(edge.startNodeId)
                        val b = planeSolution.graph.nodes.getValue(edge.endNodeId)
                        val lengthMm = kotlin.math.hypot(b.x - a.x, b.y - a.y) * 1000.0
                        addView(compactButton("${edge.id.take(10)}  ${String.format(Locale("sk", "SK"), "%,.0f", lengthMm)} mm") {
                            show3DEdgeLengthDialog(project, edge.id, view)
                        })
                    }
                })
            }
            addView(dimensions, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
            ))
        }
        root.addView(modelFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(label(
            "Orbit: jeden prst  •  zoom/pan: dva prsty  •  kóta: tlačidlo nad scénou  •  reset: dvojité ťuknutie",
            13f, false, MUTED
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(16))
            setBackgroundColor(Color.WHITE)
        })
        setContentView(root)
        view.onResume()
    }

    private fun showSummary(project: RoofProject) {
        screen = Screen.SUMMARY
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("Výkaz výmer") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.QUANTITIES))
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(30))
        }
        val quantityAudit = RoofQuantityEngine.calculate(project)
        val totals = quantityAudit.totals
        content.addView(sectionTitle(project.name))
        content.addView(infoCard(listOf(
            "Adresa" to project.address.ifBlank { "—" },
            "3D model" to "NODE → EDGE → FACE → roviny",
            "Predvolený sklon" to "${format1(project.slopeDeg)}°",
            "Výška stien" to "${format1(project.wallHeightM)} m",
            "Body obrysu" to project.polygon.size.toString()
        )))
        content.addView(sectionTitle("Výkaz výmer"))
        content.addView(infoCard(listOf(
            "Pôdorysná plocha" to "${format1(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${format1(totals.roofAreaM2)} m²",
            "Obvod" to "${format1(totals.perimeterM)} m",
            "Hrebeň" to "${format1(totals.ridgeM)} m",
            "Úžľabie" to "${format1(totals.valleyM)} m",
            "Nárožie" to "${format1(totals.hipM)} m",
            "Atika / pult / pri murive" to "${format1(totals.atticM)} / ${format1(totals.pultM)} / ${format1(totals.wallEndM)} m",
            "Odkvap / štít" to "${format1(totals.eaveM)} / ${format1(totals.gableM)} m",
            "Komíny / okná / výlezy" to "${totals.chimneys} / ${totals.roofWindows} / ${totals.hatches}",
            "Prestupy / vpuste / zvody" to "${totals.vents} / ${totals.drains} / ${totals.downspouts}",
            "Výšky / sklony" to "${totals.heightMarks} / ${totals.slopeMarks}"
        )))
        content.addView(sectionTitle("Audit plôch podľa FaceId"))
        content.addView(infoCard(quantityAudit.faces.map { face ->
            face.faceId to "${format1(face.area3DM2)} m²${if (face.underconstrained) " • doplniť sklon/výšku" else ""}"
        }.ifEmpty { listOf("—" to "Žiadna uzavretá plocha") }))
        content.addView(sectionTitle("Audit hrán podľa EdgeId"))
        content.addView(infoCard(quantityAudit.edges.map { edge ->
            "${edge.edgeId} • ${edge.semanticRole.toLegacy().label}" to "${format1(edge.length3DM)} m"
        }.ifEmpty { listOf("—" to "Žiadna hrana") }))
        content.addView(label(
            "Geometria a výmery z ortofotomapy sú orientačné. Pred výrobou alebo realizáciou ich overte meraním na stavbe.",
            12f, false, Color.rgb(81, 90, 85)
        ).apply {
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(Color.rgb(241, 245, 241), 10f, stroke = Color.rgb(194, 205, 195))
        })
        content.addView(sectionTitle("Export projektu"))
        content.addView(row().apply {
            addView(actionButton("PDF nákres", BRAND) {
                exportFile("${safeName(project.name)}.pdf", "application/pdf", Exporters.pdf(project))
            })
            addView(actionButton("SVG nákres", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.svg", "image/svg+xml", Exporters.svg(project))
            })
            addView(actionButton("JSON projekt", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.json", "application/json", Exporters.json(project))
            })
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showWorkScope(project: RoofProject) {
        screen = Screen.WORK_SCOPE
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("Rozsah prác") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.WORK_SCOPE))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
            addView(sectionTitle("Rozsah realizácie"))
            addView(label(
                "Položky sa počítajú lokálne z auditovaného výkazu. Jednotkové ceny zostávajú editovateľné a bez internetovej závislosti.",
                13f, false, MUTED
            ))
            WorkScopeEngine.resolve(project).forEach { resolved ->
                val selection = project.selectedWorkItems.getOrPut(resolved.item.code) {
                    SelectedWorkItem(resolved.item.code)
                }
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(9), dp(12), dp(9))
                    background = rounded(Color.WHITE, 10f, stroke = Color.rgb(205, 216, 207))
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { setMargins(0, dp(8), 0, 0) }
                    val selected = CheckBox(this@MainActivity).apply {
                        text = "${resolved.item.code} • ${resolved.item.label}"
                        isChecked = selection.selected
                        setTypeface(typeface, Typeface.BOLD)
                        setOnCheckedChangeListener { _, checked ->
                            selection.selected = checked
                            store.save(project)
                        }
                    }
                    addView(selected)
                    addView(label(
                        "Automatický zdroj ${resolved.item.quantitySource}: ${format1(resolved.automaticQuantity)} ${resolved.item.unit}" +
                            if (resolved.manualOverride) "  •  ručne: ${format1(resolved.quantity)}" else "",
                        12f, false, MUTED
                    ))
                    val fields = row().apply { gravity = Gravity.CENTER_VERTICAL }
                    val quantity = edit("Množstvo", format1(resolved.quantity)).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(0, dp(6), dp(5), 0) }
                    }
                    val price = edit("Cena / ${resolved.item.unit}", resolved.unitPrice?.let(::format1).orEmpty()).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(5), dp(6), 0, 0) }
                    }
                    fields.addView(quantity)
                    fields.addView(price)
                    addView(fields)
                    addView(label("Množstvo môžete prepísať; automatická hodnota zostáva vyššie auditovateľná.", 11f, false, MUTED))
                    quantity.setOnFocusChangeListener { _, hasFocus ->
                        if (!hasFocus) {
                            val entered = quantity.text.toString().replace(',', '.').toDoubleOrNull()
                            selection.manualQuantityOverride = entered?.takeUnless { kotlin.math.abs(it - resolved.automaticQuantity) < 0.0001 }
                            store.save(project)
                        }
                    }
                    price.setOnFocusChangeListener { _, hasFocus ->
                        if (!hasFocus) {
                            selection.unitPrice = price.text.toString().replace(',', '.').toDoubleOrNull()?.takeIf { it >= 0.0 }
                            store.save(project)
                        }
                    }
                })
            }
            val selectedTotals = WorkScopeEngine.resolve(project).filter { project.selectedWorkItems[it.item.code]?.selected == true }
            val knownTotal = selectedTotals.mapNotNull { it.totalPrice }.sum()
            addView(sectionTitle("Súčet"))
            addView(infoCard(listOf(
                "Vybrané položky" to selectedTotals.size.toString(),
                "Súčet zadaných cien" to "${format1(knownTotal)} €",
                "Položky bez ceny" to selectedTotals.count { it.unitPrice == null }.toString()
            )))
        }
        root.addView(ScrollView(this).apply { addView(content) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun showPdfTab(project: RoofProject) {
        screen = Screen.PDF
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("PDF dokumentácia") { showEditor(project) })
        root.addView(workspaceNavigation(project, WorkspaceTab.PDF))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(24))
            addView(sectionTitle("Offline technický výstup"))
            addView(infoCard(listOf(
                "Projekt" to project.name,
                "Pôdorys" to "z aktuálneho RoofGraph",
                "Výkaz výmer" to "z lokálneho 3D modelu",
                "Sieť" to "nie je potrebná"
            )))
            addView(actionButton("Vytvoriť a uložiť PDF", BRAND) {
                exportFile("${safeName(project.name)}.pdf", "application/pdf", Exporters.pdf(project))
            })
        }
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun exportFile(name: String, mime: String, bytes: ByteArray) {
        pendingExport = bytes
        pendingExportName = name
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun openJsonImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, REQUEST_IMPORT_JSON)
    }

    private fun openUnderlayImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_IMPORT_UNDERLAY)
    }

    private fun showSolverPreviewDialog(map: RoofMapEditorView) {
        val preview = map.prepareSolverPreview() ?: return
        val stats = preview.statistics
        val blockingIssues = preview.issues.count { it.severity == TopologyIssueSeverity.ERROR }
        val warnings = preview.issues.size - blockingIssues
        val message = buildString {
            append("Návrh sa najprv zobrazuje nad pôvodným nákresom. Projekt sa zmení až po potvrdení.\n\n")
            append("Zlúčené uzly: ${stats.mergedNodes}\n")
            append("Nové priesečníky: ${stats.createdIntersections}\n")
            append("Rozdelené hrany: ${stats.splitEdges}\n")
            append("Prichytené konce: ${stats.snappedFreeEnds}\n")
            append("Odstránené krátke/duplicitné hrany: ${stats.removedShortEdges + stats.removedDuplicateEdges}\n")
            append("Vyrovnané body obrysu: ${stats.regularizedBoundaryNodes}\n")
            append("Zarovnané nárožia/úžľabia na 45°: ${stats.alignedHipValleyNodes}\n")
            if (preview.isValid) {
                append("Stav: geometria je pripravená na použitie")
                if (warnings > 0) append(" ($warnings upozornení)")
            } else {
                append("Potrebné ručné doplnenie: $blockingIssues")
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Náhľad korekcie geometrie")
            .setMessage(message)
            .setNegativeButton("Zrušiť") { _, _ -> map.cancelSolverPreview() }
            .setNeutralButton("Ďalší problém", null)
            .setPositiveButton("Použiť opravy", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                map.focusNextSolverIssue() ?: toast("Solver nenašiel ďalší problém.")
            }
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).isEnabled = preview.issues.isNotEmpty()
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).apply {
                isEnabled = true
                setOnClickListener {
                    if (map.applySolverPreview()) {
                        currentProject?.let(store::save)
                        refreshEditorMetrics(map.project)
                        dialog.dismiss()
                    }
                }
            }
        }
        dialog.setOnCancelListener { map.cancelSolverPreview() }
        dialog.show()
    }

    private fun showAtticHeightDialog(map: RoofMapEditorView, project: RoofProject) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(format1(project.atticHeightM))
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Výška atiky nad strechou")
            .setMessage("Atika sa v 3D vytvorí ako zvislá stena. Zadajte jej výšku v metroch.")
            .setView(input)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Kresliť atiku") { _, _ ->
                project.atticHeightM = input.text.toString().replace(',', '.').toDoubleOrNull()
                    ?.coerceIn(0.1, 3.0) ?: 0.6
                store.save(project)
                map.setMode(EditorMode.ADD_LINE, lineType = LineType.ATTIC)
            }
            .show()
    }

    private fun showBoundaryEdgeTypeDialog(map: RoofMapEditorView, project: RoofProject, edgeIndex: Int) {
        val types = listOf(
            LineType.EAVE, LineType.GABLE, LineType.RAKE, LineType.LOW_EDGE,
            LineType.ELEVATED_LOW_EDGE, LineType.PULT, LineType.ATTIC,
            LineType.WALL_END, LineType.STEP, LineType.OPENING_BOUNDARY
        )
        val addPointLabel = "Pridať bod"
        val items = types.map { it.label } + addPointLabel
        AlertDialog.Builder(this)
            .setTitle("Obvodová hrana")
            .setItems(items.toTypedArray()) { _, position ->
                if (position == types.size) {
                    if (map.addBoundaryMidpoint(edgeIndex)) store.save(project)
                    return@setItems
                }
                val type = types[position]
                if (type == LineType.ATTIC) {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        setText(format1(project.atticHeightM))
                        selectAll()
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Výška atiky nad strechou")
                        .setView(input)
                        .setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Použiť") { _, _ ->
                            project.atticHeightM = input.text.toString().replace(',', '.').toDoubleOrNull()
                                ?.coerceIn(0.1, 3.0) ?: 0.6
                            map.setBoundaryEdgeType(edgeIndex, type)
                            store.save(project)
                        }.show()
                } else if (type == LineType.ELEVATED_LOW_EDGE) {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        setText(format1(project.wallHeightM + 1.0)); selectAll()
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Absolútna výška zvýšenej nízkej hrany")
                        .setMessage("Zadajte výšku v metroch. Hodnota je hard constraint pre oba koncové uzly.")
                        .setView(input).setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Použiť") { _, _ ->
                            val z = input.text.toString().replace(',', '.').toDoubleOrNull() ?: return@setPositiveButton
                            map.setBoundaryEdgeType(edgeIndex, type, z)
                            store.save(project)
                        }.show()
                } else {
                    map.setBoundaryEdgeType(edgeIndex, type)
                    store.save(project)
                }
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showEdgeSemanticDialog(
        map: RoofMapEditorView,
        project: RoofProject,
        boundaryIndex: Int? = null,
        lineIndex: Int? = null
    ) {
        val types = listOf(
            LineType.EAVE, LineType.GABLE, LineType.RAKE, LineType.LOW_EDGE, LineType.ELEVATED_LOW_EDGE,
            LineType.PULT, LineType.ATTIC, LineType.WALL_END, LineType.RIDGE, LineType.HIP,
            LineType.VALLEY, LineType.STEP, LineType.OPENING_BOUNDARY, LineType.UNKNOWN
        )
        AlertDialog.Builder(this)
            .setTitle("Technický význam hrany")
            .setMessage("Mení sa iba typ hrany. Poloha uzlov zostane zamknutá.")
            .setItems(types.map { it.label }.toTypedArray()) { _, position ->
                val type = types[position]
                if (type == LineType.ELEVATED_LOW_EDGE) {
                    val input = EditText(this).apply {
                        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                        setText(format1(project.wallHeightM + 1.0)); selectAll()
                    }
                    AlertDialog.Builder(this)
                        .setTitle("Absolútna výška zvýšenej nízkej hrany")
                        .setView(input).setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Použiť") { _, _ ->
                            val z = input.text.toString().replace(',', '.').toDoubleOrNull() ?: return@setPositiveButton
                            val changed = when {
                                boundaryIndex != null -> map.setBoundaryEdgeType(boundaryIndex, type, z)
                                lineIndex != null -> map.setLineType(lineIndex, type, z)
                                else -> false
                            }
                            if (changed) store.save(project)
                        }.show()
                    return@setItems
                }
                val changed = when {
                    boundaryIndex != null -> map.setBoundaryEdgeType(boundaryIndex, type)
                    lineIndex != null -> map.setLineType(lineIndex, type)
                    else -> false
                }
                if (changed) store.save(project)
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun showEdgeLengthDialog(map: RoofMapEditorView, mapHost: FreeRoofMapHost) {
        val current = map.selectedEdgeLengthM()
        if (current == null) {
            toast("Najprv zvoľte Editovať a klepnite na obvodovú hranu.")
            return
        }
        val lengthSteps = NumberPicker(this).apply {
            minValue = 1
            maxValue = 100_000
            value = (current * 1000.0 / 50.0).roundToInt().coerceIn(minValue, maxValue)
            wrapSelectorWheel = false
            setFormatter { step -> String.format(Locale("sk", "SK"), "%,d mm", step * 50) }
        }
        val calibration = CheckBox(this).apply {
            text = "Kalibrovať celý PDF/JPG podklad podľa tejto hrany"
            isChecked = mapHost.isDocumentMode()
            visibility = if (mapHost.isDocumentMode()) View.VISIBLE else View.GONE
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(label("Otočné koliesko mení dĺžku po presných 50 mm. Táto hodnota je tvrdé obmedzenie solvera:", 14f, false, MUTED))
            addView(row().apply {
                gravity = Gravity.CENTER
                addView(lengthSteps, LinearLayout.LayoutParams(dp(210), dp(150)))
            })
            addView(calibration)
        }
        AlertDialog.Builder(this)
            .setTitle("Rozmer vybranej hrany")
            .setMessage("Aktuálna dĺžka: ${String.format(Locale("sk", "SK"), "%,d", (current * 1000).roundToInt())} mm")
            .setView(content)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Použiť") { _, _ ->
                val target = lengthSteps.value * 0.05
                if (map.setSelectedEdgeLength(target, mapHost.isDocumentMode() && calibration.isChecked)) {
                    currentProject?.let(store::save)
                    refreshEditorMetrics(map.project)
                } else toast("Zadajte dĺžku aspoň 0,05 m.")
            }
            .show()
    }

    private fun show3DEdgeLengthDialog(project: RoofProject, edgeId: String, view: Roof3DView) {
        val before = project.roofGraph ?: return
        val edge = before.edges[edgeId] ?: return
        val a = before.nodes[edge.startNodeId] ?: return
        val b = before.nodes[edge.endNodeId] ?: return
        val currentM = kotlin.math.hypot(b.x - a.x, b.y - a.y)
        val picker = NumberPicker(this).apply {
            minValue = 1
            maxValue = 100_000
            value = (currentM * 1000.0 / 50.0).roundToInt().coerceIn(minValue, maxValue)
            wrapSelectorWheel = false
            setFormatter { step -> String.format(Locale("sk", "SK"), "%,d mm", step * 50) }
        }
        var preview = before
        var committed = false
        picker.setOnValueChangedListener { _, _, newValue ->
            ParametricEditSolver.setEdgeLength(
                before, edgeId, newValue * 0.05, project.wallHeightM, project.slopeDeg
            ).takeIf { it.applied }?.let { changed ->
                preview = changed.graph
                project.roofGraph = preview
                project.roofTopology = preview.toTopology()
                view.setProject(project)
            }
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("3D kóta • $edgeId")
            .setMessage("Krok 50 mm. Náhľad modelu sa mení priebežne; OK vytvorí jeden Undo krok.")
            .setView(picker)
            .setNegativeButton("Zrušiť") { _, _ ->
                project.roofGraph = before
                project.roofTopology = before.toTopology()
                view.setProject(project)
            }
            .setPositiveButton("OK") { _, _ ->
                committed = true
                last3DGraphBeforeEdit = before
                project.roofGraph = preview
                project.roofTopology = preview.toTopology()
                store.save(project)
                show3D(project)
            }
            .create()
        dialog.setOnCancelListener {
            if (!committed) {
                project.roofGraph = before
                project.roofTopology = before.toTopology()
                view.setProject(project)
            }
        }
        dialog.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQUEST_EXPORT -> {
                val bytes = pendingExport ?: return
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: error("Súbor sa nedá otvoriť na zápis.")
                }.onSuccess {
                    toast("Uložené: $pendingExportName")
                }.onFailure { toast(it.message ?: "Export zlyhal.") }
                pendingExport = null
            }
            REQUEST_IMPORT_JSON -> {
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Súbor sa nedá prečítať.")
                    val imported = ProjectJson.decode(text)
                    imported.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        name = "${imported.name} – import",
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                }.onSuccess { project ->
                    store.save(project)
                    currentProject = project
                    showEditor(project)
                }.onFailure { toast("Neplatný projekt: ${it.message}") }
            }
            REQUEST_IMPORT_UNDERLAY -> {
                val project = currentProject ?: return
                runCatching {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val mime = contentResolver.getType(uri).orEmpty()
                val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: uri.lastPathSegment.orEmpty().ifBlank { "Podklad" }
                project.underlayUri = uri.toString()
                project.underlayMime = mime
                project.underlayName = name
                activeMapHost?.showDocument(uri, mime, name, true)
                store.save(project)
                editorStatus?.text = "Načítavam podklad $name…"
            }
        }
    }

    private fun appBar(title: String, back: (() -> Unit)?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(8), dp(8), dp(8))
        setBackgroundColor(BRAND_DARK)
        if (back != null) addView(compactButton("‹ Späť", back))
        addView(label(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun verticalRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(PAPER)
        if (Build.VERSION.SDK_INT >= 30) {
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            requestApplyInsets()
        } else {
            fitsSystemWindows = true
        }
    }

    private fun disposeActiveMap() {
        activeMapHost?.onPause()
        activeMapHost?.onDestroy()
        activeMapHost = null
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(color, 9f)
        setPadding(dp(12), 0, dp(12), 0)
        minHeight = dp(42)
        minWidth = 0
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply {
            setMargins(0, 0, dp(7), 0)
        }
    }

    private fun editorToolButton(text: String, iconRes: Int, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 11f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setCompoundDrawablesWithIntrinsicBounds(0, iconRes, 0, 0)
        compoundDrawablePadding = dp(2)
        background = rounded(color, 8f, stroke = Color.rgb(104, 143, 113))
        setPadding(dp(3), dp(4), dp(3), dp(3))
        minWidth = dp(44)
        minHeight = dp(60)
        maxLines = 2
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(0, dp(64), 1f).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
    }

    private fun compactButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 12f
        background = rounded(Color.rgb(51, 103, 65), 8f, stroke = Color.rgb(117, 156, 126))
        setPadding(dp(9), 0, dp(9), 0)
        minWidth = 0
        minHeight = dp(38)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(0, 0, dp(6), 0)
        }
    }

    private fun workspaceNavigation(project: RoofProject, selected: WorkspaceTab): View =
        HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(236, 242, 237))
            addView(row().apply {
                setPadding(dp(6), dp(5), dp(6), dp(5))
                WorkspaceTab.entries.forEach { tab ->
                    addView(actionButton(
                        tab.label,
                        if (tab == selected) BRAND else Color.rgb(76, 96, 84)
                    ) {
                        when (tab) {
                            WorkspaceTab.OUTLINE, WorkspaceTab.INTERNAL, WorkspaceTab.TYPOLOGY -> showEditor(project, tab)
                            WorkspaceTab.MODEL_3D -> show3D(project)
                            WorkspaceTab.QUANTITIES -> showSummary(project)
                            WorkspaceTab.WORK_SCOPE -> showWorkScope(project)
                            WorkspaceTab.PDF -> showPdfTab(project)
                        }
                    })
                }
            })
        }

    private fun mapControlButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = if (text.length == 1) 20f else 10f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(Color.rgb(31, 89, 48), 8f, stroke = Color.WHITE)
        minWidth = 0
        minHeight = 0
        setPadding(dp(7), 0, dp(7), 0)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(54), dp(42)).apply {
            setMargins(0, 0, 0, dp(5))
        }
    }

    private fun label(text: String, size: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.12f)
    }

    private fun edit(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        textSize = 15f
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = rounded(Color.WHITE, 8f, stroke = Color.rgb(194, 205, 195))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            setMargins(0, 0, 0, dp(9))
        }
    }

    private fun sectionTitle(text: String) = label(text, 18f, true, INK).apply {
        setPadding(0, dp(12), 0, dp(8))
    }

    private fun infoCard(rows: List<Pair<String, String>>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(Color.WHITE, 12f, stroke = Color.rgb(211, 220, 212))
        rows.forEach { (key, value) ->
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
                setPadding(0, dp(7), 0, dp(7))
                addView(label(key, 13f, false, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.46f))
                addView(label(value, 13f, true, INK).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.54f))
            })
        }
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp.roundToInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun loadingDialog(message: String): AlertDialog = AlertDialog.Builder(this)
        .setView(label(message, 16f, true, INK).apply { setPadding(dp(28), dp(26), dp(28), dp(26)) })
        .setCancelable(false)
        .create()
        .also { it.show() }

    private fun simpleSelection(block: () -> Unit) =
        object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = block()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }

    private fun parseCoordinates(value: String): GeoPoint? {
        val match = Regex("""^\s*(-?\d{1,2}(?:[.,]\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:[.,]\d+)?)\s*$""").find(value)
            ?: return null
        val lat = match.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val lon = match.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return null
        return if (lat in -90.0..90.0 && lon in -180.0..180.0) GeoPoint(lat, lon) else null
    }

    private fun safeName(value: String) = value.trim()
        .replace(Regex("""[^\p{L}\p{N}._-]+"""), "_")
        .trim('_')
        .ifBlank { "strecha" }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun format1(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)

    private enum class Screen { HOME, EDITOR, THREE_D, SUMMARY, WORK_SCOPE, PDF }

    private enum class WorkspaceTab(val label: String) {
        OUTLINE("1 Obrys"),
        INTERNAL("2 Vnútorné línie"),
        TYPOLOGY("3 Typológia"),
        MODEL_3D("4 3D model"),
        QUANTITIES("5 Výkaz výmer"),
        WORK_SCOPE("6 Rozsah prác"),
        PDF("7 PDF")
    }

    companion object {
        private const val REQUEST_EXPORT = 4001
        private const val REQUEST_IMPORT_JSON = 4002
        private const val REQUEST_LOCATION = 4003
        private const val REQUEST_IMPORT_UNDERLAY = 4004
        private val BRAND = Color.rgb(35, 122, 53)
        private val BRAND_DARK = Color.rgb(22, 84, 38)
        private val INK = Color.rgb(23, 33, 43)
        private val MUTED = Color.rgb(91, 107, 99)
        private val PAPER = Color.rgb(244, 247, 244)
    }
}
