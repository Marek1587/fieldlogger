package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

data class FaceQuantityAudit(
    val faceId: String,
    val area3DM2: Double,
    val plane: RoofPlane,
    val underconstrained: Boolean
)

data class EdgeQuantityAudit(
    val edgeId: String,
    val semanticRole: EdgeSemantic,
    val boundary: Boolean,
    val length3DM: Double
)

data class RoofQuantityAudit(
    val graph: RoofGraph,
    val faces: List<FaceQuantityAudit>,
    val edges: List<EdgeQuantityAudit>,
    val totals: ProjectTotals,
    val solverIssues: List<RoofPlaneSolverIssue> = emptyList()
)

object RoofQuantityEngine {
    fun calculate(project: RoofProject): RoofQuantityAudit {
        val topology = project.roofGraph?.toTopology()
            ?: project.roofTopology
            ?: RoofTopologyMigration.fromLegacyProject(project)
        val planar = if (RoofTopologySolver.extractFaces(topology).isEmpty()) {
            RoofTopologySolver.solve(topology).proposed
        } else topology
        val baseGraph = RoofGraphFactory.fromTopology(planar, project.roofGraph)
        val solution = RoofPlaneSolver.solve(baseGraph, project.wallHeightM, project.slopeDeg)
        if (solution.hasBlockingIssues) {
            fun count(type: ObjectType) = project.objects.count { it.type == type }
            return RoofQuantityAudit(baseGraph, emptyList(), emptyList(), ProjectTotals(
                Geometry.areaM2(project.polygon), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                count(ObjectType.CHIMNEY), count(ObjectType.ROOF_WINDOW), count(ObjectType.HATCH), count(ObjectType.VENT),
                count(ObjectType.DRAIN), count(ObjectType.DOWNSPOUT), count(ObjectType.HEIGHT_MARK), count(ObjectType.SLOPE_MARK)
            ), solution.issues)
        }
        val solved = solution.graph
        fun ringArea(ids: List<String>): Double = abs(ids.mapNotNull(solved.nodes::get).let { nodes ->
            nodes.indices.sumOf { index ->
                val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            } / 2.0
        })
        fun netPlanArea(face: GraphFace): Double = (ringArea(face.orderedNodeIds) - face.holeNodeIdLoops.sumOf(::ringArea)).coerceAtLeast(0.0)
        val faces = solved.faces.values.sortedBy { it.id }.mapNotNull { face ->
            val plane = face.plane ?: return@mapNotNull null
            FaceQuantityAudit(
                face.id,
                netPlanArea(face) * sqrt(1.0 + plane.a * plane.a + plane.b * plane.b),
                plane,
                face.underconstrained
            )
        }
        val edges = solved.edges.values.sortedBy { it.id }.mapNotNull { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = solved.nodes[edge.endNodeId] ?: return@mapNotNull null
            EdgeQuantityAudit(
                edge.id,
                edge.semanticRole,
                edge.boundary,
                sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y) + (b.z - a.z) * (b.z - a.z))
            )
        }
        fun length(role: EdgeSemantic) = edges.filter { it.semanticRole == role }.sumOf { it.length3DM }
        fun count(type: ObjectType) = project.objects.count { it.type == type }
        val footprint = solved.faces.values.sumOf(::netPlanArea)
            .takeIf { it > 0.0 } ?: Geometry.areaM2(project.polygon)
        val totals = ProjectTotals(
            footprintAreaM2 = footprint,
            roofAreaM2 = faces.sumOf { it.area3DM2 },
            perimeterM = edges.filter { it.boundary }.sumOf { it.length3DM },
            ridgeM = length(EdgeSemantic.RIDGE),
            valleyM = length(EdgeSemantic.VALLEY),
            hipM = length(EdgeSemantic.HIP),
            atticM = length(EdgeSemantic.ATTIC),
            pultM = length(EdgeSemantic.PULT),
            wallEndM = length(EdgeSemantic.WALL_END),
            eaveM = length(EdgeSemantic.EAVE),
            gableM = length(EdgeSemantic.GABLE),
            chimneys = count(ObjectType.CHIMNEY),
            roofWindows = count(ObjectType.ROOF_WINDOW),
            hatches = count(ObjectType.HATCH),
            vents = count(ObjectType.VENT),
            drains = count(ObjectType.DRAIN),
            downspouts = count(ObjectType.DOWNSPOUT),
            heightMarks = count(ObjectType.HEIGHT_MARK),
            slopeMarks = count(ObjectType.SLOPE_MARK)
        )
        return RoofQuantityAudit(solved, faces, edges, totals, solution.issues)
    }
}
