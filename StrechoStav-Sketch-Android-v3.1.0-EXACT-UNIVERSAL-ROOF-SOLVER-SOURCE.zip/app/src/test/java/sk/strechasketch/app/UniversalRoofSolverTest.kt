package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.tan

class UniversalRoofSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun canonicalLHalfHipSolvesFourteenNodesNineteenEdgesAndSixPlanesExactly() {
        val graph = canonicalHalfHip()
        val solution = RoofPlaneSolver.solve(graph, 3.2, 40.0)

        assertFalse(solution.issues.joinToString { it.code }, solution.hasBlockingIssues)
        assertEquals(14, solution.graph.nodes.size)
        assertEquals(19, solution.graph.edges.size)
        assertEquals(6, solution.graph.faces.size)
        assertTrue(solution.maximumCoplanarityResidualM < 1e-8)
        assertEquals(7.059858303, solution.graph.nodes.getValue("N11").z, 1e-6)
        assertEquals(4.576123395, solution.graph.nodes.getValue("N07").z, 1e-6)
        assertTrue(RoofGraphValidator.validate(solution.graph).joinToString { it.code }, RoofGraphValidator.validate(solution.graph).isEmpty())
        solution.graph.faces.values.forEach { face ->
            val plane = face.plane!!
            face.orderedNodeIds.forEach { nodeId ->
                val node = solution.graph.nodes.getValue(nodeId)
                assertEquals(node.z, plane.zAt(node.x, node.y), 1e-8)
            }
        }
    }

    @Test
    fun downhillDirectionProducesHeightIncreaseInTheOppositeDirection() {
        val graph = rectangleWithOneLowEdge().let { base ->
            val face = base.faces.values.single()
            base.copy(faces = mapOf(face.id to face.copy(
                slopeConstraint = FaceSlopeConstraint(30.0, 0.0, -1.0)
            )))
        }
        val solution = RoofPlaneSolver.solve(graph, 3.0, 10.0)
        assertFalse(solution.hasBlockingIssues)
        assertEquals(3.0 + tan(Math.toRadians(30.0)) * 2.0, solution.graph.nodes.getValue("C").z, 1e-8)
    }

    @Test
    fun pointElevationConstrainsPlaneEvenWithoutNodeAtThatPoint() {
        val base = rectangleWithOneLowEdge(lowRole = EdgeSemantic.GABLE)
        val face = base.faces.values.single()
        val graph = base.copy(faces = mapOf(face.id to face.copy(
            slopeConstraint = FaceSlopeConstraint(0.0, 0.0, 1.0),
            elevationConstraints = listOf(ElevationConstraint(x = 0.75, y = 0.5, elevationZ = 5.25))
        )))
        val solution = RoofPlaneSolver.solve(graph, 3.0, 10.0)
        assertFalse(solution.hasBlockingIssues)
        solution.graph.nodes.values.forEach { assertEquals(5.25, it.z, 1e-9) }
    }

    @Test
    fun conflictingHardElevationsAreRejectedInsteadOfAveraged() {
        val base = rectangleWithOneLowEdge(lowRole = EdgeSemantic.GABLE)
        val face = base.faces.values.single()
        val graph = base.copy(faces = mapOf(face.id to face.copy(
            slopeConstraint = FaceSlopeConstraint(0.0, 0.0, 1.0),
            elevationConstraints = listOf(
                ElevationConstraint(nodeId = "A", elevationZ = 3.0),
                ElevationConstraint(nodeId = "A", elevationZ = 4.0)
            )
        )))
        val solution = RoofPlaneSolver.solve(graph, 3.0, 10.0)
        assertTrue(solution.hasBlockingIssues)
        assertTrue(solution.issues.any { it.code == "CONFLICTING_NODE_HEIGHT" })
        assertEquals(graph, solution.graph)
    }

    @Test
    fun schemaOneSlopeDirectionMigratesFromLegacyUphillToDownhill() {
        val json = JSONObject().apply {
            put("schema_version", 1)
            put("origin", JSONObject().put("lat", 49.0).put("lon", 18.0))
            put("nodes", JSONArray())
            put("edges", JSONArray())
            put("faces", JSONArray().put(JSONObject().apply {
                put("id", "F"); put("ordered_node_ids", JSONArray()); put("ordered_edge_ids", JSONArray())
                put("signed_area_m2", 1.0)
                put("slope_constraint", JSONObject().put("angle_deg", 20.0).put("direction_x", 0.0).put("direction_y", 1.0))
            }))
        }
        val decoded = RoofGraphJson.decode(json)
        assertEquals(-1.0, decoded.faces.getValue("F").slopeConstraint!!.directionY, 0.0)
        assertEquals(2, decoded.schemaVersion)
    }

    @Test
    fun ridgeCollapseIsAnExplicitTopologyEvent() {
        val graph = RoofGraph(
            origin, mapOf("A" to GraphNode("A", 0.0, 0.0), "B" to GraphNode("B", 0.001, 0.0)),
            mapOf("R" to GraphEdge("R", "A", "B", false, EdgeSemantic.RIDGE)), emptyMap()
        )
        assertTrue(RoofTopologyEventDetector.detect(graph).any { it.type == RoofTopologyEventType.RIDGE_COLLAPSE_TO_APEX })
    }

    @Test
    fun canonicalFaceModelIsImportedAsTheAuthoritativeGraph() {
        val nodes = JSONArray().apply {
            listOf("A" to (0.0 to 0.0), "B" to (4000.0 to 0.0), "C" to (4000.0 to 3000.0), "D" to (0.0 to 3000.0)).forEach { (id, xy) ->
                put(JSONObject().put("id", id).put("position", JSONObject()
                    .put("x", xy.first).put("y", xy.second).put("z", 3000.0)))
            }
        }
        val edges = JSONArray().apply {
            listOf("AB" to ("A" to "B"), "BC" to ("B" to "C"), "CD" to ("C" to "D"), "DA" to ("D" to "A")).forEach { (id, ends) ->
                put(JSONObject().put("id", id).put("nodes", JSONArray().put(ends.first).put(ends.second))
                    .put("boundary", true).put("role", if (id == "AB") "eave" else "rake")
                    .put("faces", JSONArray().put("F")))
            }
        }
        val root = JSONObject().apply {
            put("schema", "roof-face-model/1.0")
            put("metadata", JSONObject().put("id", "canonical-test").put("title", "Kanonická strecha"))
            put("coordinateSystem", JSONObject().put("units", "mm"))
            put("plan", JSONObject()
                .put("roofBoundaries", JSONArray().put(JSONObject().put("outerLoopNodeIds", JSONArray(listOf("A", "B", "C", "D")))))
                .put("wallFootprints", JSONArray().put(JSONObject().put("outerLoop", JSONArray()
                    .put(JSONArray().put(0).put(0)).put(JSONArray().put(4000).put(0))
                    .put(JSONArray().put(4000).put(3000)).put(JSONArray().put(0).put(3000))))))
            put("nodes", nodes); put("edges", edges)
            put("faces", JSONArray().put(JSONObject().put("id", "F")
                .put("outerLoop", JSONArray(listOf("A", "B", "C", "D")))))
            put("constraints", JSONArray().put(JSONObject().put("type", "SlopeConstraint")
                .put("faceId", "F").put("valueDeg", 20.0)
                .put("downhillDirectionXY", JSONArray().put(0.0).put(-1.0)).put("priority", "hard")))
        }

        val project = ProjectJson.decode(root.toString())
        assertEquals("canonical-test", project.id)
        assertEquals(4, project.roofGraph!!.nodes.size)
        assertEquals(4.0, project.roofGraph!!.nodes.getValue("B").x, 1e-9)
        assertEquals(4, project.polygon.size)
        assertEquals(4, project.wallFootprint.size)
    }

    @Test
    fun faceHoleIsBlockedUntilItHasAnExactNonOverlappingSubdivision() {
        val base = rectangleWithOneLowEdge()
        val face = base.faces.values.single()
        val graph = base.copy(faces = mapOf(face.id to face.copy(holeNodeIdLoops = listOf(listOf("A", "B", "C")))))

        val solution = RoofPlaneSolver.solve(graph, 3.0, 10.0)
        assertTrue(solution.hasBlockingIssues)
        assertTrue(solution.issues.any { it.code == "FACE_HOLE_REQUIRES_SUBDIVISION" })
    }

    private fun rectangleWithOneLowEdge(lowRole: EdgeSemantic = EdgeSemantic.EAVE): RoofGraph {
        val nodes = mapOf(
            "A" to GraphNode("A", 0.0, 0.0), "B" to GraphNode("B", 2.0, 0.0),
            "C" to GraphNode("C", 2.0, 2.0), "D" to GraphNode("D", 0.0, 2.0)
        )
        val edges = linkedMapOf(
            "AB" to GraphEdge("AB", "A", "B", true, lowRole, setOf("F")),
            "BC" to GraphEdge("BC", "B", "C", true, EdgeSemantic.GABLE, setOf("F")),
            "CD" to GraphEdge("CD", "C", "D", true, EdgeSemantic.GABLE, setOf("F")),
            "DA" to GraphEdge("DA", "D", "A", true, EdgeSemantic.GABLE, setOf("F"))
        )
        val face = GraphFace("F", listOf("A", "B", "C", "D"), edges.keys.toList(), 4.0)
        return RoofGraph(origin, nodes, edges, mapOf("F" to face))
    }

    private fun canonicalHalfHip(): RoofGraph {
        fun node(id: String, x: Double, y: Double, z: Double, locked: Boolean = false) =
            GraphNode(id, x, y, z, lockZ = locked)
        val nodes = listOf(
            node("N01", -0.6, -0.6, 3.2, true), node("N02", 10.6, -0.6, 3.2, true),
            node("N03", 10.6, 8.6, 3.2, true), node("N04", 7.6, 8.6, 3.2, true),
            node("N05", 7.6, 14.6, 3.2, true), node("N06", -0.6, 14.6, 3.2, true),
            node("N07", 1.04, 14.6, 4.576123395), node("N08", 5.96, 14.6, 4.576123395),
            node("N09", 3.5, 12.14, 6.640308488), node("N10", 3.5, 4.5, 6.640308488),
            node("N11", 4.0, 4.0, 7.059858303), node("N12", 10.6, 6.76, 4.743943321),
            node("N13", 7.84, 4.0, 7.059858303), node("N14", 10.6, 1.24, 4.743943321)
        ).associateBy { it.id }
        data class E(val id: String, val a: String, val b: String, val role: EdgeSemantic, val boundary: Boolean, val faces: Set<String>)
        val specs = listOf(
            E("E01","N11","N10",EdgeSemantic.HIP,false,setOf("F01","F04")), E("E02","N10","N09",EdgeSemantic.RIDGE,false,setOf("F01","F03")),
            E("E03","N09","N07",EdgeSemantic.HIP,false,setOf("F01","F02")), E("E04","N07","N06",EdgeSemantic.RAKE,true,setOf("F01")),
            E("E05","N06","N01",EdgeSemantic.EAVE,true,setOf("F01")), E("E06","N01","N11",EdgeSemantic.HIP,false,setOf("F01","F06")),
            E("E07","N09","N08",EdgeSemantic.HIP,false,setOf("F02","F03")), E("E08","N08","N07",EdgeSemantic.ELEVATED_LOW_EDGE,true,setOf("F02")),
            E("E09","N04","N05",EdgeSemantic.EAVE,true,setOf("F03")), E("E10","N05","N08",EdgeSemantic.RAKE,true,setOf("F03")),
            E("E11","N10","N04",EdgeSemantic.VALLEY,false,setOf("F03","F04")), E("E12","N11","N13",EdgeSemantic.RIDGE,false,setOf("F04","F06")),
            E("E13","N13","N12",EdgeSemantic.HIP,false,setOf("F04","F05")), E("E14","N12","N03",EdgeSemantic.RAKE,true,setOf("F04")),
            E("E15","N03","N04",EdgeSemantic.EAVE,true,setOf("F04")), E("E16","N13","N14",EdgeSemantic.HIP,false,setOf("F05","F06")),
            E("E17","N14","N12",EdgeSemantic.ELEVATED_LOW_EDGE,true,setOf("F05")), E("E18","N01","N02",EdgeSemantic.EAVE,true,setOf("F06")),
            E("E19","N02","N14",EdgeSemantic.RAKE,true,setOf("F06"))
        )
        val edges = specs.associate { spec -> spec.id to GraphEdge(
            spec.id, spec.a, spec.b, spec.boundary, spec.role, spec.faces,
            elevationZ = if (spec.id == "E08") 4.576123395 else if (spec.id == "E17") 4.743943321 else null
        ) }
        fun face(id: String, nodeIds: List<String>, edgeIds: List<String>, downhillX: Double, downhillY: Double): GraphFace {
            val area = abs(nodeIds.indices.sumOf { i ->
                val a = nodes.getValue(nodeIds[i]); val b = nodes.getValue(nodeIds[(i + 1) % nodeIds.size])
                a.x * b.y - b.x * a.y
            } / 2.0)
            return GraphFace(id, nodeIds, edgeIds, area, slopeConstraint = FaceSlopeConstraint(40.0, downhillX, downhillY))
        }
        val faces = listOf(
            face("F01", listOf("N11","N10","N09","N07","N06","N01"), listOf("E01","E02","E03","E04","E05","E06"), -1.0, 0.0),
            face("F02", listOf("N09","N08","N07"), listOf("E07","E08","E03"), 0.0, 1.0),
            face("F03", listOf("N04","N05","N08","N09","N10"), listOf("E09","E10","E07","E02","E11"), 1.0, 0.0),
            face("F04", listOf("N11","N13","N12","N03","N04","N10"), listOf("E12","E13","E14","E15","E11","E01"), 0.0, 1.0),
            face("F05", listOf("N13","N14","N12"), listOf("E16","E17","E13"), 1.0, 0.0),
            face("F06", listOf("N01","N02","N14","N13","N11"), listOf("E18","E19","E16","E12","E06"), 0.0, -1.0)
        ).associateBy { it.id }
        return RoofGraph(origin, nodes, edges, faces, components = mapOf("main" to RoofComponent("main", "Hlavná strecha", faceIds = faces.keys)))
    }
}
