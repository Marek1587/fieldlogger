# Zmeny

## 3.1.0

- `FaceSlopeConstraint` používa explicitný smer spádu; staré grafy sa migrujú bez zmeny geometrie,
- nový exact equality solver rieši spoločné Z uzlov a konštanty rovín deterministickou elimináciou,
- konflikt hard constraints sa blokuje namiesto priemerovania alebo tichého clamping-u,
- bodové výškové kóty s `x/y`, zvýšené nízke hrany a spoločné vpuste skutočne ovplyvňujú roviny,
- rozšírené typy hrán: rake, low edge, elevated low edge, step a opening boundary,
- `GraphFace` podporuje otvory, komponent a hostiteľskú plochu; pridané strešné komponenty a drain constraints,
- stenový pôdorys je oddelený od hranice strechy a staré projekty sa automaticky migrujú na schému 6,
- detektor topologických udalostí blokuje zánik hrebeňa, hrany alebo plochy bez explicitnej retopologizácie,
- validátor kontroluje incidenciu 1/2 plôch, orientáciu, koplanaritu 0,001 mm, Eulerov invariant a odkazy komponentov,
- nový 3D builder dopĺňa odvodené telesá komína, strešného okna, výlezu a prestupu,
- kanonický JSON adaptér a regresná L-polvalbová skúška overujú 14 uzlov, 19 hrán a 6 plôch.
- `ProjectJson` priamo importuje `roof-face-model/1.x` vrátane oddeleného stenového pôdorysu,
- plocha s otvorom bez presného neprekrývajúceho rozdelenia bezpečne zablokuje 3D a výkaz namiesto zakrytia otvoru.

## 3.0.0

- jediným zdrojom geometrickej pravdy je `RoofGraph` schémy 5 so stabilnými `NodeId`, `EdgeId` a `FaceId`,
- staré schema-4 projekty sa automaticky migrujú; legacy `polygon/lines/edgeTypes/RoofShape` zostávajú iba kompatibilným zrkadlom/metadátami,
- sedem oddelených pracovných kariet: Obrys, Vnútorné línie, Typológia, 3D model, Výkaz výmer, Rozsah prác a PDF,
- odstránené používateľské OSM vrstvy a trvalé tlačidlo Posun; ZBGIS dlaždice sa ukladajú trvalo po projektoch,
- podržanie voľného miesta 1 sekundu aktivuje iba dočasný posun; pinch zoomuje podklad aj celú topologickú geometriu,
- freehand počas ťahu kreslí iba plynulú stopu a finálny obrys vytvorí až po vyhladení na najviac 10 bodov,
- rozdelenie obvodovej hrany pracuje nad `EdgeId`; pohyb celej hrany zachová dĺžku a smer,
- obrys a vnútorné línie majú samostatné korekcie; vnútorné hrany vznikajú ako `UNKNOWN`,
- Typológia zamyká XY a mení iba `EdgeSemantic`; technické objekty poznajú `attachedFaceId`/`attachedEdgeId`,
- generický `RoofPlaneSolver` vytvára 3D iba z faces a rovníc `z = ax + by + c`, bez výberu presetu strechy,
- 3D kóty majú samostatné hitboxy, krok 50 mm, live preview a jeden Undo krok,
- výkaz používa skutočné 3D plochy a dĺžky s auditom podľa FaceId/EdgeId,
- lokálny WorkCatalog podporuje automatické množstvá, ručný override a editovateľné ceny bez servera,
- deterministický štvorstranový PDF obsahuje dva izometrické pohľady, pôdorys, audit výmer a rozpočet,
- rozšírené JVM regresné testy canonical grafu, migrácie, incidencií, sedlovej/valbovej/polvalbovej/L a kombinovanej plochej + šikmej siete.

## 2.6.0

- korekcia obrysu prenesená z PHP: dominantná os, rovnobežné strany, pravé uhly a povolené 45° hrany,
- nárožia a úžľabia sa zarovnávajú na presných 45° voči pripojeným odkvapovým hranám,
- pripojené vnútorné línie sa pri korekcii pohybujú so spoločnými topologickými uzlami,
- bezpečnú časť korekcie možno potvrdiť aj v rozpracovanom nákrese a zostávajúcu líniu potom ručne dopojiť,
- po výbere obvodovej alebo vnútornej línie možno upravovať iba jej dva konce,
- dlhé podržanie obvodovej hrany ponúka `Pridať bod` presne do jej stredu,
- odstránené horné tlačidlo `Bod` a tlačidlo `OSM terén`,
- staršie projekty s OSM terénom sa automaticky a bezpečne prepnú na OSM mapu,
- regresné testy rozdelenia hrany, odstránenia bodu, pravouhlosti, rovnobežnosti, 45° línií a čiastočných opráv.

## 2.5.0

- priame kontextové menu typu obvodovej hrany po dlhšom podržaní,
- odstránené skryté pretváranie pôdorysu pred topologickou korekciou,
- korektný solver polvalby s dvoma štítovými úsekmi, hrebeňom a dvoma nárožiami,
- automatické 3D rozlišuje odkvap od štítu, pultovej hrany, atiky a napojenia pri murive,
- zvýšený koniec hrebeňa na štíte už neklesne na výšku muriva,
- regresné testy pre tri plochy polvalby a výškovú väzbu hrebeňa na štíte,
- zrozumiteľnejší náhľad korekcie bez technického počítadla „Chyby“.

## 2.4.0

- spoločný posun, zoom a dvojprstová rotácia mapy, polygónu, línií a objektov,
- tlačidlo Sever na okamžité vynulovanie natočenia,
- vyhladenie voľnej ruky a limit najviac 10 významných bodov obrysu,
- magnetické prichytenie vnútorných línií k uzlom, vrcholom a hranám,
- výber editovateľného bodu dlhým podržaním, oranžové zvýraznenie a vibrácia,
- samostatné spodné tlačidlo Odstrániť bod,
- nastaviteľná výška atiky a skutočná zvislá atiková stena v 3D,
- JSON schéma 4 so spätným načítaním projektov bez rotácie a výšky atiky.

## 2.3.0

- stabilný dvojvrstvový renderer máp bez odkrývania prázdnych dlaždíc,
- päť úrovní digitálneho zoomu nad zdrojovým limitom ZBGIS/OSM,
- topologický graf uzlov a hrán so solverom priesečníkov, T-napojení, snapu a merge,
- nezáväzný vizuálny náhľad korekcie pred zápisom do projektu,
- režim editácie koncov vnútorných strešných línií,
- Undo aj Redo a transakčné prijatie solvera,
- validácia topológie pred 3D a triangulácia automatickej strechy po plochách,
- ear clipping pre konkávne ploché a pultové pôdorysy,
- JSON schéma 3 so spätnou migráciou starších projektov,
- kompaktná päťtlačidlová spodná lišta s vektorovými ikonami,
- regresné testy topológie, konkávneho pôdorysu a JSON migrácie.

## 2.2.0

- Google Maps SDK aj API kľúč boli úplne odstránené,
- bezplatná cestná vrstva OpenStreetMap a terénna vrstva OpenTopoMap,
- slovenské ortofoto cez verejnú WMS službu ZBGIS v EPSG:3857,
- automatické skladanie všetkých dlaždíc potrebných pre aktuálnu obrazovku a zoom,
- sedemdňová lokálna cache dlaždíc a povinné uvedenie zdroja dát,
- adresa sa naďalej mení na GPS cez Nominatim s cache a obmedzením požiadaviek,
- staré projekty s Google typmi máp sa automaticky prevedú na nové bezplatné vrstvy.

## 2.1.1

- zoom mapy a výkresu kolieskom pripojenej myši.

## 2.1.0

- opravená diagnostika prázdnej Google mapy spôsobenej chýbajúcim alebo nesprávne obmedzeným API kľúčom,
- GitHub build sa bez `MAPS_API_KEY` zastaví namiesto vytvorenia nefunkčnej mapovej zostavy,
- stabilný debug podpis a uvedený SHA-1 pre Android obmedzenie Google API kľúča,
- zoom mapy dvoma prstami aj tlačidlami `+`, `−` a `Celok`,
- import PDF/JPG/PNG/WebP ako kresliaceho podkladu,
- posun, zoom a uloženie transformácie výkresového podkladu,
- výber obvodovej hrany a nastavenie dĺžky číselnými kolieskami,
- kalibrácia celého výkresu podľa jednej známej dĺžky,
- dĺžky obvodových hrán sa zobrazujú priamo v editore.

## 2.0.0

- názov aplikácie zmenený na StrechoStav Sketch,
- Google ortofotomapa, hybridná mapa a terén namiesto OSM dlaždíc,
- samostatné tlačidlo `Bod`,
- bezpečné odsadenie obsahu od hornej a dolnej systémovej lišty Androidu,
- 3D model obsahuje steny pôdorysu s nastaviteľnou výškou od 3 m,
- automatický tvar strechy podľa hrebeňov, nároží a úžľabí v nákrese,
- podpora kombinovaných tvarov vrátane polvalby,
- z výkazu, SVG a PDF odstránená hydroizolácia, podklad a ceny,
- Google Maps API kľúč sa načítava zo `secrets.properties` alebo GitHub secretu.

## 1.0.0

- prvá natívna Android verzia,
- dotykový 2D editor strechy,
- technické línie a prvky,
- lokálne projekty, JSON, SVG, PDF a 3D náhľad,
- GitHub Actions workflow na zostavenie debug APK.
