package sk.strechasketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private data class PlanProjection(
    val localPolygon: List<LocalPoint>,
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val origin: GeoPoint,
    val angle: Double
) {
    fun local(point: GeoPoint): LocalPoint {
        val raw = Geometry.toLocal(point, origin)
        val c = cos(-angle)
        val s = sin(-angle)
        return LocalPoint(raw.x * c - raw.y * s, raw.x * s + raw.y * c)
    }
}

object Exporters {
    fun json(project: RoofProject): ByteArray =
        ProjectJson.encode(project).toByteArray(Charsets.UTF_8)

    fun svg(project: RoofProject): ByteArray {
        if (project.polygon.size < 3) {
            return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800"><rect width="100%" height="100%" fill="white"/><text x="50" y="70" font-family="Arial" font-size="28">Nákres nemá uzavretý obrys.</text></svg>"""
                .toByteArray(Charsets.UTF_8)
        }
        val plan = projection(project)
        val pageW = 1600.0
        val pageH = 1000.0
        val drawX = 70.0
        val drawY = 120.0
        val drawW = 950.0
        val drawH = 740.0
        val scale = min(drawW / max(1.0, plan.maxX - plan.minX), drawH / max(1.0, plan.maxY - plan.minY))
        fun screen(point: LocalPoint): LocalPoint = LocalPoint(
            drawX + (point.x - plan.minX) * scale,
            drawY + (plan.maxY - point.y) * scale
        )
        fun line(a: LocalPoint, b: LocalPoint, color: String = "#111", width: Double = 2.0, dash: String = "") =
            """<line x1="${n(a.x)}" y1="${n(a.y)}" x2="${n(b.x)}" y2="${n(b.y)}" stroke="$color" stroke-width="$width"${if (dash.isNotBlank()) " stroke-dasharray=\"$dash\"" else ""}/>"""
        fun text(x: Double, y: Double, value: String, size: Int = 16, anchor: String = "start", weight: String = "400") =
            """<text x="${n(x)}" y="${n(y)}" font-family="Arial,sans-serif" font-size="$size" text-anchor="$anchor" font-weight="$weight" fill="#111">${xml(value)}</text>"""
        val out = StringBuilder()
        out.append("""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000">""")
        out.append("""<rect width="1600" height="1000" fill="white"/><rect x="10" y="10" width="1580" height="980" fill="none" stroke="#111"/>""")
        out.append(text(35.0, 48.0, "NÁKRES STRECHY", 25, weight = "700"))
        out.append(text(35.0, 76.0, "Projekt: ${project.name}", 15))
        out.append(text(35.0, 99.0, "Adresa: ${project.address.ifBlank { "—" }}", 14))
        val polygon = plan.localPolygon.map(::screen)
        val path = polygon.mapIndexed { index, p -> "${if (index == 0) "M" else "L"} ${n(p.x)} ${n(p.y)}" }.joinToString(" ") + " Z"
        out.append("""<path d="$path" fill="#edf7ed" stroke="#111" stroke-width="3"/>""")
        project.polygon.indices.forEach { index ->
            val next = (index + 1) % project.polygon.size
            val a = polygon[index]
            val b = polygon[next]
            val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 - 8, "${(length * 1000).toInt()} mm", 12, "middle"))
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 + 9, (project.edgeTypes[index] ?: LineType.EAVE).label, 10, "middle"))
        }
        project.lines.forEach { roofLine ->
            val a = screen(plan.local(roofLine.start))
            val b = screen(plan.local(roofLine.end))
            val dash = if (roofLine.type == LineType.WALL_END) "10 7" else ""
            out.append(line(a, b, colorHex(roofLine.type.color), 2.2, dash))
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 - 7, roofLine.type.label, 12, "middle", "700"))
        }
        project.objects.forEach { item ->
            val p = screen(plan.local(item.center))
            when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH -> {
                    val w = max(12.0, item.widthMm / 1000.0 * scale)
                    val h = max(12.0, item.heightMm / 1000.0 * scale)
                    out.append("""<rect x="${n(p.x - w / 2)}" y="${n(p.y - h / 2)}" width="${n(w)}" height="${n(h)}" fill="none" stroke="#111" stroke-width="1.5"/>""")
                }
                ObjectType.VENT, ObjectType.DRAIN, ObjectType.DOWNSPOUT -> {
                    val r = max(5.0, item.diameterMm / 2000.0 * scale)
                    out.append("""<circle cx="${n(p.x)}" cy="${n(p.y)}" r="${n(r)}" fill="none" stroke="#111" stroke-width="1.5"/>""")
                }
                ObjectType.HEIGHT_MARK -> out.append("""<path d="M ${n(p.x - 10)} ${n(p.y)} H ${n(p.x + 10)} M ${n(p.x)} ${n(p.y - 10)} V ${n(p.y + 10)}" stroke="#111"/>""")
                ObjectType.SLOPE_MARK -> out.append("""<path d="M ${n(p.x - 14)} ${n(p.y + 10)} L ${n(p.x + 14)} ${n(p.y - 10)}" stroke="#111"/>""")
            }
            out.append(text(p.x, p.y - 12, item.type.label, 10, "middle"))
        }
        val totals = ProjectSummary.calculate(project)
        val boxX = 1090.0
        out.append("""<rect x="$boxX" y="105" width="440" height="720" fill="#fafafa" stroke="#111"/>""")
        var yy = 140.0
        val rows = listOf(
            "VÝKAZ VÝMER" to "",
            "Pôdorysná plocha" to "${f(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${f(totals.roofAreaM2)} m²",
            "Obvod" to "${f(totals.perimeterM)} m",
            "Hrebeň" to "${f(totals.ridgeM)} m",
            "Úžľabie" to "${f(totals.valleyM)} m",
            "Nárožie" to "${f(totals.hipM)} m",
            "Atika" to "${f(totals.atticM)} m",
            "Odkvap" to "${f(totals.eaveM)} m",
            "Štít" to "${f(totals.gableM)} m",
            "Komíny / okná / výlezy" to "${totals.chimneys} / ${totals.roofWindows} / ${totals.hatches}",
            "Prestupy / vpuste / zvody" to "${totals.vents} / ${totals.drains} / ${totals.downspouts}",
            "3D model" to "FaceId + roviny",
            "Predvolený sklon" to "${f(project.slopeDeg)}°",
            "Výška stien" to "${f(project.wallHeightM)} m"
        )
        rows.forEachIndexed { index, row ->
            if (row.first.isBlank()) {
                yy += 12
            } else {
                val bold = index == 0
                out.append(text(boxX + 18, yy, row.first, if (bold) 15 else 13, weight = if (bold) "700" else "400"))
                if (row.second.isNotBlank()) out.append(text(boxX + 420, yy, row.second, if (bold) 15 else 13, "end", if (bold) "700" else "400"))
                yy += 31
            }
        }
        out.append(text(35.0, 953.0, "Mierka je automatická. Rozmery pred realizáciou overte na stavbe.", 13))
        out.append("</svg>")
        return out.toString().toByteArray(Charsets.UTF_8)
    }

    fun pdf(project: RoofProject): ByteArray {
        val document = PdfDocument()
        val audit = RoofQuantityEngine.calculate(project)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1f
        }

        fun begin(number: Int, title: String): PdfDocument.Page {
            val page = document.startPage(PdfDocument.PageInfo.Builder(842, 595, number).create())
            page.canvas.drawColor(Color.WHITE)
            page.canvas.drawRect(10f, 10f, 832f, 585f, border)
            drawText(page.canvas, title, 24f, 34f, 15f, true)
            drawText(page.canvas, "StrechoStav Sketch • ${project.name}", 818f, 34f, 8f, alignRight = true)
            return page
        }

        begin(1, "PROJEKT A 3D TECHNICKÉ POHĽADY").also { page ->
            val canvas = page.canvas
            val date = SimpleDateFormat("d. M. yyyy", Locale("sk", "SK")).format(Date())
            drawText(canvas, "Projekt: ${project.name}", 26f, 58f, 10f, true)
            drawText(canvas, "Zákazník: ${project.customer.ifBlank { "—" }}", 26f, 75f, 9f)
            drawText(canvas, "Adresa: ${project.address.ifBlank { "—" }}", 26f, 91f, 9f)
            drawText(canvas, "Dátum: $date", 600f, 58f, 9f)
            drawPdfRoofBitmap(canvas, project, RectF(28f, 112f, 405f, 500f), RoofBitmapCamera(-35.0, 28.0))
            drawPdfRoofBitmap(canvas, project, RectF(437f, 112f, 814f, 500f), RoofBitmapCamera(145.0, 28.0))
            drawText(canvas, "Izometrický pohľad A", 216f, 520f, 9f, true, centered = true)
            drawText(canvas, "Izometrický pohľad B", 625f, 520f, 9f, true, centered = true)
            if (audit.faces.any { it.underconstrained }) {
                drawText(canvas, "Upozornenie: niektoré plochy potrebujú doplniť sklon alebo výškovú kótu.", 26f, 560f, 8f, true)
            }
            document.finishPage(page)
        }

        begin(2, "PÔDORYS STRECHY – TECHNICKÝ VÝKRES").also { page ->
            val canvas = page.canvas
            if (project.polygon.size >= 3) drawPdfPlan(canvas, project, RectF(38f, 58f, 804f, 530f))
            else drawText(canvas, "Nákres nemá uzavretý obrys.", 80f, 250f, 13f, true)
            drawText(canvas, "Kóty sú v mm. Výkres je generovaný z aktuálneho RoofGraph, nie zo snímky obrazovky.", 24f, 565f, 8f)
            document.finishPage(page)
        }

        begin(3, "VÝKAZ VÝMER – AUDIT PODĽA ID").also { page ->
            val canvas = page.canvas
            var y = 62f
            val totals = audit.totals
            listOf(
                "Pôdorysná plocha" to "${f(totals.footprintAreaM2)} m²",
                "Celková skutočná 3D plocha" to "${f(totals.roofAreaM2)} m²",
                "Obvod v 3D" to "${f(totals.perimeterM)} m",
                "Odkvapy / hrebene / nárožia / úžľabia" to "${f(totals.eaveM)} / ${f(totals.ridgeM)} / ${f(totals.hipM)} / ${f(totals.valleyM)} m"
            ).forEach { (name, value) ->
                drawText(canvas, name, 30f, y, 9f, true)
                drawText(canvas, value, 812f, y, 9f, true, alignRight = true)
                y += 17f
            }
            y += 8f
            drawText(canvas, "FaceId", 30f, y, 8f, true)
            drawText(canvas, "Plocha 3D", 410f, y, 8f, true, alignRight = true)
            drawText(canvas, "Stav", 430f, y, 8f, true)
            y += 14f
            audit.faces.take(18).forEach { face ->
                drawText(canvas, face.faceId, 30f, y, 7f)
                drawText(canvas, "${f(face.area3DM2)} m²", 410f, y, 7f, alignRight = true)
                drawText(canvas, if (face.underconstrained) "doplniť constraint" else "určená", 430f, y, 7f)
                y += 13f
            }
            y += 8f
            drawText(canvas, "EdgeId", 30f, y, 8f, true)
            drawText(canvas, "Typ", 430f, y, 8f, true)
            drawText(canvas, "Dĺžka 3D", 812f, y, 8f, true, alignRight = true)
            y += 14f
            audit.edges.take(((565f - y) / 13f).toInt().coerceAtLeast(0)).forEach { edge ->
                drawText(canvas, edge.edgeId, 30f, y, 7f)
                drawText(canvas, edge.semanticRole.toLegacy().label, 430f, y, 7f)
                drawText(canvas, "${f(edge.length3DM)} m", 812f, y, 7f, alignRight = true)
                y += 13f
            }
            document.finishPage(page)
        }

        begin(4, "ROZSAH PRÁC A ROZPOČET").also { page ->
            val canvas = page.canvas
            var y = 64f
            drawText(canvas, "Položka", 28f, y, 8f, true)
            drawText(canvas, "MJ", 470f, y, 8f, true)
            drawText(canvas, "Množstvo", 570f, y, 8f, true, alignRight = true)
            drawText(canvas, "Jedn. cena", 680f, y, 8f, true, alignRight = true)
            drawText(canvas, "Cena", 812f, y, 8f, true, alignRight = true)
            y += 18f
            val selected = WorkScopeEngine.resolve(project).filter { project.selectedWorkItems[it.item.code]?.selected == true }
            selected.forEach { item ->
                drawText(canvas, "${item.item.code} • ${item.item.label}", 28f, y, 7.5f)
                drawText(canvas, item.item.unit, 470f, y, 7.5f)
                drawText(canvas, f(item.quantity), 570f, y, 7.5f, alignRight = true)
                drawText(canvas, item.unitPrice?.let { "${f(it)} €" } ?: "—", 680f, y, 7.5f, alignRight = true)
                drawText(canvas, item.totalPrice?.let { "${f(it)} €" } ?: "—", 812f, y, 7.5f, alignRight = true)
                y += 17f
            }
            if (selected.isEmpty()) drawText(canvas, "Nie je vybraná žiadna položka rozsahu prác.", 28f, y, 9f)
            val total = selected.mapNotNull { it.totalPrice }.sum()
            drawText(canvas, "SÚČET ZADANÝCH CIEN", 560f, 548f, 9f, true)
            drawText(canvas, "${f(total)} €", 812f, 548f, 10f, true, alignRight = true)
            drawText(canvas, "Položky bez jednotkovej ceny nie sú do súčtu zahrnuté.", 28f, 570f, 7f)
            document.finishPage(page)
        }
        return ByteArrayOutputStream().use { output ->
            document.writeTo(output)
            document.close()
            output.toByteArray()
        }
    }

    private fun drawPdfRoofBitmap(
        canvas: Canvas,
        project: RoofProject,
        bounds: RectF,
        camera: RoofBitmapCamera
    ) {
        val width = (bounds.width() * 2f).toInt().coerceIn(320, 1400)
        val height = (bounds.height() * 2f).toInt().coerceIn(320, 1400)
        val bitmap = RoofBitmapRenderer.render(project, width, height, camera, Color.WHITE)
        try {
            canvas.drawBitmap(
                bitmap, null, bounds,
                Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun drawPdfPlan(canvas: Canvas, project: RoofProject, bounds: RectF) {
        val plan = projection(project)
        val scale = min(
            bounds.width() / max(1.0, plan.maxX - plan.minX),
            bounds.height() / max(1.0, plan.maxY - plan.minY)
        ).toFloat() * 0.82f
        val offsetX = bounds.left + (bounds.width() - (plan.maxX - plan.minX).toFloat() * scale) / 2f
        val offsetY = bounds.top + (bounds.height() - (plan.maxY - plan.minY).toFloat() * scale) / 2f
        fun screen(point: LocalPoint) = android.graphics.PointF(
            offsetX + (point.x - plan.minX).toFloat() * scale,
            offsetY + (plan.maxY - point.y).toFloat() * scale
        )
        val points = plan.localPolygon.map(::screen)
        val path = Path().apply {
            moveTo(points.first().x, points.first().y)
            points.drop(1).forEach { lineTo(it.x, it.y) }
            close()
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.rgb(239, 248, 239)
        }
        canvas.drawPath(path, fill)
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 2f
        }
        canvas.drawPath(path, stroke)
        project.polygon.indices.forEach { index ->
            val next = (index + 1) % project.polygon.size
            val a = points[index]
            val b = points[next]
            val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
            drawText(canvas, "${(length * 1000).toInt()}", (a.x + b.x) / 2, (a.y + b.y) / 2 - 4, 7f, true, centered = true)
        }
        project.lines.forEach { line ->
            val a = screen(plan.local(line.start))
            val b = screen(plan.local(line.end))
            stroke.color = line.type.color
            stroke.strokeWidth = 1.8f
            canvas.drawLine(a.x, a.y, b.x, b.y, stroke)
            drawText(canvas, line.type.label, (a.x + b.x) / 2, (a.y + b.y) / 2 - 5, 7f, true, centered = true)
        }
        project.objects.forEach { item ->
            val point = screen(plan.local(item.center))
            stroke.color = Color.DKGRAY
            val size = 6f
            when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH ->
                    canvas.drawRect(point.x - size, point.y - size, point.x + size, point.y + size, stroke)
                else -> canvas.drawCircle(point.x, point.y, size, stroke)
            }
            drawText(canvas, item.type.label, point.x, point.y - 9, 6f, centered = true)
        }
    }

    private fun drawPdfSummary(canvas: Canvas, project: RoofProject, bounds: RectF) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 1f
        }
        canvas.drawRect(bounds, paint)
        val totals = ProjectSummary.calculate(project)
        var y = bounds.top + 22
        val rows = listOf(
            "VÝKAZ VÝMER" to "",
            "Pôdorys" to "${f(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${f(totals.roofAreaM2)} m²",
            "Obvod" to "${f(totals.perimeterM)} m",
            "Hrebeň" to "${f(totals.ridgeM)} m",
            "Úžľabie" to "${f(totals.valleyM)} m",
            "Nárožie" to "${f(totals.hipM)} m",
            "Atika" to "${f(totals.atticM)} m",
            "Odkvap" to "${f(totals.eaveM)} m",
            "Štít" to "${f(totals.gableM)} m",
            "Komíny / okná" to "${totals.chimneys} / ${totals.roofWindows}",
            "Prestupy / vpuste" to "${totals.vents} / ${totals.drains}",
            "Model / sklon" to "FaceId / ${f(project.slopeDeg)}°",
            "Výška stien" to "${f(project.wallHeightM)} m"
        )
        rows.forEachIndexed { index, (label, value) ->
            if (label.isBlank()) {
                y += 8
            } else {
                val bold = index == 0
                drawText(canvas, label, bounds.left + 10, y, if (bold) 10f else 8f, bold)
                if (value.isNotBlank()) {
                    drawText(canvas, value, bounds.right - 10, y, if (bold) 10f else 8f, bold, alignRight = true)
                }
                y += if (bold) 22 else 19
            }
        }
        drawText(canvas, "Výmera z mapy je orientačná.", bounds.left + 10, bounds.bottom - 24, 7f, true)
        drawText(canvas, "Rozmery overte meraním na stavbe.", bounds.left + 10, bounds.bottom - 12, 7f)
    }

    private fun projection(project: RoofProject): PlanProjection {
        val origin = Geometry.centroid(project.polygon)
        val raw = project.polygon.map { Geometry.toLocal(it, origin) }
        val longest = raw.indices.maxByOrNull { index ->
            val next = raw[(index + 1) % raw.size]
            hypot(next.x - raw[index].x, next.y - raw[index].y)
        } ?: 0
        val b = raw[(longest + 1) % raw.size]
        val angle = atan2(b.y - raw[longest].y, b.x - raw[longest].x)
        val c = cos(-angle)
        val s = sin(-angle)
        val rotated = raw.map { LocalPoint(it.x * c - it.y * s, it.x * s + it.y * c) }
        return PlanProjection(
            rotated,
            rotated.minOf { it.x },
            rotated.maxOf { it.x },
            rotated.minOf { it.y },
            rotated.maxOf { it.y },
            origin,
            angle
        )
    }

    private fun drawText(
        canvas: Canvas,
        value: String,
        x: Float,
        y: Float,
        size: Float,
        bold: Boolean = false,
        alignRight: Boolean = false,
        centered: Boolean = false
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(24, 31, 37)
            textSize = size
            typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            textAlign = when {
                centered -> Paint.Align.CENTER
                alignRight -> Paint.Align.RIGHT
                else -> Paint.Align.LEFT
            }
        }
        canvas.drawText(value, x, y, paint)
    }

    private fun xml(value: String) = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun colorHex(color: Int) = String.format("#%06X", 0xFFFFFF and color)
    private fun n(value: Double) = String.format(Locale.US, "%.1f", value)
    private fun f(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)
}
