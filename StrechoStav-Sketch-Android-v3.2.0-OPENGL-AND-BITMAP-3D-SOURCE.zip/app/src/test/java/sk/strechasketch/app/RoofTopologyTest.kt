package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class RoofTopologyTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    private fun rectangleProject(): RoofProject = RoofProject(
        polygon = mutableListOf(geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0))
    )

    private fun internalAngleProject(angleDeg: Double): RoofProject = rectangleProject().apply {
        val length = 3.0
        val radians = Math.toRadians(angleDeg)
        lines += RoofLine(
            type = LineType.UNKNOWN,
            start = geo(2.0, 2.0),
            end = geo(2.0 + kotlin.math.cos(radians) * length, 2.0 + kotlin.math.sin(radians) * length)
        )
    }

    @Test
    fun internalCorrectionSnapsFortyFourDegreesToFortyFiveWithoutMovingBoundary() {
        val input = RoofTopologyMigration.fromLegacyProject(internalAngleProject(44.0))
        val boundaryBefore = input.nodes.filter { it.type == TopologyNodeType.FOOTPRINT }.associate { it.id to (it.x to it.y) }
        val preview = RoofTopologySolver.solveInternal(input)
        val line = preview.proposed.edges.single { !it.boundary }
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val a = nodes.getValue(line.startNodeId)
        val b = nodes.getValue(line.endNodeId)
        val angle = Math.toDegrees(kotlin.math.atan2(b.y - a.y, b.x - a.x)).let { (it + 180.0) % 180.0 }
        assertEquals(45.0, angle, 1e-6)
        boundaryBefore.forEach { (id, xy) ->
            assertEquals(xy.first, nodes.getValue(id).x, 1e-9)
            assertEquals(xy.second, nodes.getValue(id).y, 1e-9)
        }
    }

    @Test
    fun internalCorrectionDoesNotAggressivelySnapThirtyFiveDegrees() {
        val input = RoofTopologyMigration.fromLegacyProject(internalAngleProject(35.0))
        val preview = RoofTopologySolver.solveInternal(input)
        val line = preview.proposed.edges.single { !it.boundary }
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val a = nodes.getValue(line.startNodeId)
        val b = nodes.getValue(line.endNodeId)
        val angle = Math.toDegrees(kotlin.math.atan2(b.y - a.y, b.x - a.x)).let { (it + 180.0) % 180.0 }
        assertEquals(35.0, angle, 0.05)
    }

    @Test
    fun crossingRoofLinesCreateSharedIntersection() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            lines += RoofLine(type = LineType.VALLEY, start = geo(6.0, 0.0), end = geo(6.0, 8.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.createdIntersections >= 1)
        assertTrue(preview.statistics.splitEdges >= 2)
        assertTrue(preview.faces.isNotEmpty())
        assertTrue(preview.isValid)
    }

    @Test
    fun nearCoincidentEndpointsAreMergedDeterministically() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(6.0, 4.0))
            lines += RoofLine(type = LineType.RIDGE, start = geo(6.02, 4.01), end = geo(12.0, 4.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.mergedNodes >= 1)
        assertTrue(preview.proposed.edges.none { it.startNodeId == it.endNodeId })
    }

    @Test
    fun legacyJsonMigratesWithoutLosingReportInputs() {
        val project = rectangleProject().apply {
            name = "Regresný projekt"
            slopeDeg = 31.5
            wallHeightM = 4.2
            mapRotationDeg = 37.0
            atticHeightM = 0.85
            objects += RoofObject(type = ObjectType.CHIMNEY, center = geo(3.0, 3.0))
        }
        val encoded = ProjectJson.encode(project)
        val decoded = ProjectJson.decode(encoded)
        assertEquals(project.name, decoded.name)
        assertEquals(project.slopeDeg, decoded.slopeDeg, 0.0001)
        assertEquals(project.wallHeightM, decoded.wallHeightM, 0.0001)
        assertEquals(project.mapRotationDeg, decoded.mapRotationDeg, 0.0001)
        assertEquals(project.atticHeightM, decoded.atticHeightM, 0.0001)
        assertEquals(1, decoded.objects.size)
        assertTrue(decoded.roofTopology != null)
    }

    @Test
    fun concaveFootprintProducesValidFace() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 4.0),
                geo(5.0, 4.0), geo(5.0, 9.0), geo(0.0, 9.0)
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.isValid)
        assertEquals(1, preview.faces.size)
    }

    @Test
    fun freehandOutlineIsSmoothedToAtMostTenPoints() {
        val noisyCircle = (0 until 80).map { index ->
            val angle = 2.0 * PI * index / 80.0
            val noise = if (index % 2 == 0) 0.18 else -0.18
            geo((5.0 + noise) * cos(angle), (5.0 + noise) * sin(angle))
        }
        val simplified = FreehandSimplifier.simplify(noisyCircle, minimumDistanceM = 0.05, maxPoints = 10)
        assertTrue(simplified.size in 3..10)
        assertTrue(Geometry.areaM2(simplified) > 50.0)
    }

    @Test
    fun halfHipWithTwoGableSegmentsCreatesThreeValidFaces() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 4.0),
                geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(5.0, 4.0), end = geo(12.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 0.0)),
                RoofLine(type = LineType.HIP, start = geo(5.0, 4.0), end = geo(0.0, 8.0))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.GABLE,
                3 to LineType.EAVE,
                4 to LineType.EAVE
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertEquals(3, preview.faces.size)
    }

    @Test
    fun internalCorrectionRepairsNearCornerSplitsAndProducesSafeHalfHipPlanes() {
        // Regression for the photographed 76 mm / 183 mm boundary fragments.
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(0.183, 0.0), geo(12.716, 0.0),
                geo(12.716, 6.10), geo(12.716, 12.236), geo(0.076, 12.236),
                geo(0.0, 12.236)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.183, 0.0), end = geo(6.20, 6.08)),
                RoofLine(type = LineType.HIP, start = geo(0.076, 12.236), end = geo(6.20, 6.08)),
                RoofLine(type = LineType.RIDGE, start = geo(6.20, 6.08), end = geo(12.716, 6.10))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE,
                2 to LineType.GABLE, 3 to LineType.GABLE,
                4 to LineType.EAVE, 5 to LineType.EAVE, 6 to LineType.EAVE
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val preview = RoofTopologySolver.solveInternal(RoofTopologyMigration.fromLegacyProject(project))
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertEquals(3, preview.faces.size)
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val boundaryLengths = preview.proposed.edges.filter { it.boundary }.map { edge ->
            val a = nodes.getValue(edge.startNodeId)
            val b = nodes.getValue(edge.endNodeId)
            kotlin.math.hypot(b.x - a.x, b.y - a.y)
        }
        assertEquals(5, boundaryLengths.size)
        assertTrue("Near-corner fragments must be removed", boundaryLengths.min() > 5.0)

        val graph = RoofGraphFactory.fromTopology(preview.proposed)
        val planes = RoofPlaneSolver.solve(graph, project.wallHeightM, project.slopeDeg)
        assertTrue(planes.issues.joinToString { it.code }, !planes.hasBlockingIssues)
        assertTrue(planes.maximumCoplanarityResidualM < 1e-8)
    }

    @Test
    fun gableBoundaryDoesNotPullRidgeEndpointDownToWallHeight() {
        val polygon = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(12.0, 0.0), LocalPoint(12.0, 4.0),
            LocalPoint(12.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val edgeTypes = mapOf(
            0 to LineType.EAVE,
            1 to LineType.GABLE,
            2 to LineType.GABLE,
            3 to LineType.EAVE,
            4 to LineType.EAVE
        )

        val centerDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(5.0, 4.0), polygon, edgeTypes)
        val gableRidgeDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 4.0), polygon, edgeTypes)
        val eaveDistance = Geometry.distanceToRoofBaseBoundary(LocalPoint(12.0, 0.0), polygon, edgeTypes)

        assertEquals(4.0, centerDistance, 0.0001)
        assertEquals(centerDistance, gableRidgeDistance, 0.0001)
        assertEquals(0.0, eaveDistance, 0.0001)
    }

    @Test
    fun noisyRectangleIsRegularizedToParallelOrthogonalSides() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.12, 0.16), geo(12.10, -0.11),
                geo(12.18, 8.13), geo(-0.09, 7.88)
            )
        )

        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertTrue(preview.statistics.regularizedBoundaryNodes > 0)

        val nodeById = preview.proposed.nodes.associateBy { it.id }
        val boundary = preview.proposed.edges.filter { it.boundary }.sortedBy { it.sourceId?.toIntOrNull() ?: 0 }
        val vectors = boundary.map { edge ->
            val a = requireNotNull(nodeById[edge.startNodeId])
            val b = requireNotNull(nodeById[edge.endNodeId])
            (b.x - a.x) to (b.y - a.y)
        }
        fun normalizedCross(first: Pair<Double, Double>, second: Pair<Double, Double>): Double =
            abs(first.first * second.second - first.second * second.first) /
                (kotlin.math.hypot(first.first, first.second) * kotlin.math.hypot(second.first, second.second))
        fun normalizedDot(first: Pair<Double, Double>, second: Pair<Double, Double>): Double =
            abs(first.first * second.first + first.second * second.second) /
                (kotlin.math.hypot(first.first, first.second) * kotlin.math.hypot(second.first, second.second))

        assertTrue("Opposite sides must be parallel", normalizedCross(vectors[0], vectors[2]) < 1e-6)
        assertTrue("Opposite sides must be parallel", normalizedCross(vectors[1], vectors[3]) < 1e-6)
        assertTrue("Adjacent sides must be perpendicular", normalizedDot(vectors[0], vectors[1]) < 1e-6)
    }

    @Test
    fun connectedHipLinesBecomeExactFortyFiveDegreesAndStayTopological() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.08, 0.10), geo(12.12, -0.07),
                geo(12.08, 8.09), geo(-0.11, 7.92)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(5.7, 4.15), end = geo(12.08, 4.02)),
                RoofLine(type = LineType.HIP, start = geo(5.7, 4.15), end = geo(-0.08, 0.10)),
                RoofLine(type = LineType.HIP, start = geo(5.7, 4.15), end = geo(-0.11, 7.92))
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.EAVE
            )
        )

        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue(preview.issues.joinToString { it.code }, preview.isValid)
        assertTrue(preview.statistics.alignedHipValleyNodes >= 1)
        val nodes = preview.proposed.nodes.associateBy { it.id }
        val boundaryNodeIds = preview.proposed.edges.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        preview.proposed.edges.filter { it.type == LineType.HIP && !it.boundary }.forEach { hip ->
            val anchorId = listOf(hip.startNodeId, hip.endNodeId).single { it in boundaryNodeIds }
            val mobileId = if (hip.startNodeId == anchorId) hip.endNodeId else hip.startNodeId
            val anchor = requireNotNull(nodes[anchorId])
            val mobile = requireNotNull(nodes[mobileId])
            val connectedEave = preview.proposed.edges.first {
                it.boundary && it.type == LineType.EAVE &&
                    (it.startNodeId == anchorId || it.endNodeId == anchorId)
            }
            val eaveOtherId = if (connectedEave.startNodeId == anchorId) connectedEave.endNodeId else connectedEave.startNodeId
            val eaveOther = requireNotNull(nodes[eaveOtherId])
            val hipAngle = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
            val eaveAngle = atan2(eaveOther.y - anchor.y, eaveOther.x - anchor.x)
            var difference = abs((hipAngle - eaveAngle) % PI)
            difference = minOf(difference, PI - difference)
            assertEquals(PI / 4.0, difference, 1e-6)
            assertTrue("HIP must share a real boundary node", hip.startNodeId == anchorId || hip.endNodeId == anchorId)
        }
    }

    @Test
    fun safeCorrectionsCanBeAppliedBeforeAnUnconnectedLineIsFinished() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(-0.1, 0.1), geo(10.1, -0.1),
                geo(10.0, 8.1), geo(0.1, 7.9)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(3.0, 4.0), end = geo(7.0, 4.1))
            )
        )
        val preview = RoofTopologySolver.solve(
            RoofTopologyMigration.fromProject(project),
            RoofSolverConfig(regularizeAngles = true)
        )
        assertTrue("A deliberately unfinished ridge must remain detectable", !preview.isValid)

        val strictCopy = ProjectJson.decode(ProjectJson.encode(project))
        assertTrue(!RoofTopologyMigration.applyToProject(strictCopy, preview.proposed).applied)

        val result = RoofTopologyMigration.applyToProject(
            project, preview.proposed, requireFullyValid = false
        )
        assertTrue(result.applied)
        assertEquals(4, project.polygon.size)
        assertEquals(1, project.lines.size)
    }
}
