package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Dedicated masonry solver for a roof projection/rizalit.
 *
 * A projection is accepted only when its three exposed footprint sides are described by
 * exactly the construction pattern used on site: one front EAVE and two return GABLE sides.
 * The roof plane is taken from the face incident to that front eave.  Consequently the two
 * return walls are cut by one continuous `z = a*x + b*y + c` plane and cannot be forced back
 * to the rectangular storey-height envelope by the generic wall solver.
 */
internal object ProjectionWallProfileSolver {
    internal data class Rule(
        val partId: String,
        val polygon: List<LocalPoint>,
        val roofPlane: RoofPlane,
        val frontEaveEdgeId: String,
        val sideGableEdgeIds: Set<String>
    ) {
        fun contains(point: LocalPoint): Boolean = containsInclusive(point, polygon)

        fun wallTopZ(point: LocalPoint, roofShellThicknessM: Double): Double =
            (roofPlane.zAt(point.x, point.y) - roofShellThicknessM)
                .coerceAtLeast(MINIMUM_PHYSICAL_WALL_TOP_M)
    }

    private data class SideMatch(
        val sideIndex: Int,
        val edge: GraphEdge,
        val distanceM: Double
    )

    private const val MINIMUM_PHYSICAL_WALL_TOP_M = 0.05
    /*
     * WallFootprintPart is classified on the masonry footprint while RoofGraph boundary
     * nodes describe the physical roof outline.  They are therefore intentionally not
     * coincident: the normal distance contains the roof overhang and the 100 mm plan-grid
     * correction.  A 180 mm limit rejected ordinary 250 mm overhangs (the field IFC from
     * v3.7.54 contains exact offsets 0.20 m and 0.30 m) and silently disabled this solver.
     *
     * Keep this below the distance to the attachment side of a normal projection.  The
     * angle and nearest-parallel-edge checks still make the EAVE + 2x GABLE signature
     * strict, while 450 mm covers the application's usual eave envelope plus grid error.
     */
    private const val SIDE_DISTANCE_TOLERANCE_M = 0.45
    /*
     * User-confirmed WallFootprint parts survive later bounded footprint correction.  The
     * saved semantic rectangle can consequently differ from the current masonry loop by
     * one 100 mm grid cell.  Treat that strip as part of the same projection; otherwise
     * only one of its three exposed wall segments receives the sloping roof profile.
     */
    private const val PART_CONTAINMENT_TOLERANCE_M = 0.12
    private const val ANGLE_TOLERANCE_DEG = 6.0
    private const val EPSILON_M = 1e-5

    fun rules(
        graph: RoofGraph,
        footprintContext: WallFootprintSolver.Context?
    ): List<Rule> {
        val context = footprintContext ?: return emptyList()
        return context.parts.asSequence()
            .filter { it.type == WallFootprintPartType.PROJECTION && it.polygon.size >= 3 }
            .mapNotNull { projectionRule(graph, it) }
            .sortedBy { it.partId }
            .toList()
    }

    fun ruleAt(rules: List<Rule>, point: LocalPoint): Rule? = rules.asSequence()
        .filter { it.contains(point) }
        .sortedBy { it.partId }
        .firstOrNull()

    private fun projectionRule(
        graph: RoofGraph,
        part: WallFootprintSolver.Context.LocalPart
    ): Rule? {
        val matches = part.polygon.indices.mapNotNull { sideIndex ->
            val a = part.polygon[sideIndex]
            val b = part.polygon[(sideIndex + 1) % part.polygon.size]
            bestBoundaryMatch(graph, sideIndex, a, b)
        }
        // Count physical footprint sides, not solver-created fragments of the same side.
        val eaveSides = matches.filter { it.edge.semanticRole == EdgeSemantic.EAVE }
            .distinctBy { it.sideIndex }
        val gableSides = matches.filter { it.edge.semanticRole == EdgeSemantic.GABLE }
            .distinctBy { it.sideIndex }
        if (eaveSides.size != 1 || gableSides.size != 2) return null

        val front = eaveSides.single().edge
        val supportFace = front.adjacentFaceIds.asSequence()
            .mapNotNull(graph.faces::get)
            .filter { it.plane != null }
            .sortedBy { it.id }
            .firstOrNull()
            ?: return null
        val plane = supportFace.plane ?: return null
        return Rule(
            partId = part.id,
            polygon = part.polygon,
            roofPlane = plane,
            frontEaveEdgeId = front.id,
            sideGableEdgeIds = gableSides.map { it.edge.id }.toSet()
        )
    }

    private fun bestBoundaryMatch(
        graph: RoofGraph,
        sideIndex: Int,
        sideA: LocalPoint,
        sideB: LocalPoint
    ): SideMatch? {
        val sideDx = sideB.x - sideA.x
        val sideDy = sideB.y - sideA.y
        val sideLength = hypot(sideDx, sideDy)
        if (sideLength <= EPSILON_M) return null
        val sideMid = LocalPoint((sideA.x + sideB.x) / 2.0, (sideA.y + sideB.y) / 2.0)
        val maximumSine = sin(Math.toRadians(ANGLE_TOLERANCE_DEG))
        return graph.edges.values.asSequence()
            .filter { it.boundary }
            .filter { it.semanticRole == EdgeSemantic.EAVE || it.semanticRole == EdgeSemantic.GABLE }
            .mapNotNull { edge ->
                val edgeA = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                val edgeB = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                val a = LocalPoint(edgeA.x, edgeA.y)
                val b = LocalPoint(edgeB.x, edgeB.y)
                val edgeDx = b.x - a.x
                val edgeDy = b.y - a.y
                val edgeLength = hypot(edgeDx, edgeDy)
                if (edgeLength <= EPSILON_M) return@mapNotNull null
                val sine = abs(sideDx * edgeDy - sideDy * edgeDx) / (sideLength * edgeLength)
                if (sine > maximumSine) return@mapNotNull null
                val edgeMid = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
                val distance = minOf(
                    Geometry.distanceToSegment(sideMid, a, b),
                    Geometry.distanceToSegment(edgeMid, sideA, sideB)
                )
                if (distance > SIDE_DISTANCE_TOLERANCE_M) return@mapNotNull null
                SideMatch(sideIndex, edge, distance)
            }
            .sortedWith(compareBy<SideMatch> { it.distanceM }.thenBy { it.edge.id })
            .firstOrNull()
    }

    private fun containsInclusive(point: LocalPoint, polygon: List<LocalPoint>): Boolean =
        Geometry.pointInPolygon(point, polygon) || polygon.indices.any { index ->
            Geometry.distanceToSegment(point, polygon[index], polygon[(index + 1) % polygon.size]) <=
                PART_CONTAINMENT_TOLERANCE_M
        }
}
