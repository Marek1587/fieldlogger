import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingProperties = Properties()
val signingPropertiesFile = rootProject.file("signing.properties")
if (signingPropertiesFile.exists()) {
    signingPropertiesFile.inputStream().use { signingProperties.load(it) }
}

val signingKeyFile = rootProject.file(
    signingProperties.getProperty("storeFile", "app/planner-update-key.jks")
)
val signingStorePassword = signingProperties.getProperty("storePassword", "")
val signingKeyAlias = signingProperties.getProperty("keyAlias", "")
val signingKeyPassword = signingProperties.getProperty("keyPassword", "")
val stableSigningReady = signingKeyFile.exists() &&
    signingStorePassword.isNotBlank() && signingKeyAlias.isNotBlank() && signingKeyPassword.isNotBlank()

if (!stableSigningReady) {
    logger.warn("Pôvodný podpis nie je nakonfigurovaný; debug APK použije štandardný Android debug podpis.")
}

android {
    namespace = "sk.strechostav.planner"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.planner"
        minSdk = 24
        targetSdk = 35
        versionCode = 12
        versionName = "2.1.0"

        val secrets = Properties()
        val secretsFile = rootProject.file("secrets.properties")
        if (secretsFile.exists()) {
            secretsFile.inputStream().use { secrets.load(it) }
        }
        manifestPlaceholders["MAPS_API_KEY"] = secrets.getProperty("MAPS_API_KEY", "")
    }

    signingConfigs {
        if (stableSigningReady) {
            create("stableUpdate") {
                storeFile = signingKeyFile
                storePassword = signingStorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            if (stableSigningReady) {
                signingConfig = signingConfigs.getByName("stableUpdate")
            }
            applicationIdSuffix = ""
        }
        release {
            if (stableSigningReady) {
                signingConfig = signingConfigs.getByName("stableUpdate")
            }
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
}
