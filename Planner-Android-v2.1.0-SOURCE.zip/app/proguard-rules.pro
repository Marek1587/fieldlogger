-keepclassmembers class sk.strechostav.planner.MainActivity {
    @android.webkit.JavascriptInterface <methods>;
}
