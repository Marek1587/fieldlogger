# Planner 2.1.0 — test report

## Reálny Android build

Overené lokálne rovnakým základným príkazom ako v GitHub Actions:

```text
gradle :app:assembleDebug --stacktrace
```

Prostredie: Microsoft OpenJDK 17, Gradle 8.10.2, Android SDK/compile SDK 35.

Výsledok: `BUILD SUCCESSFUL`, vytvorený `app/build/outputs/apk/debug/app-debug.apk`.

Overené APK metadata:

```text
applicationId: sk.strechostav.planner
versionCode: 12
versionName: 2.1.0
application label: Planner
targetSdkVersion: 35
APK Signature Scheme v2: verified
```

Finálny testovací APK bol podpísaný novým 4096-bitovým Planner RSA kľúčom. SHA-256 odtlačok podpisového certifikátu v APK sa presne zhoduje s certifikátom v `planner-update-key-private.jks`.

Ak `signing.properties` a nový Planner JKS nie sú dostupné, debug build použije štandardný Android debug podpis a nezlyhá. Ak sú dostupné všetky podpisové secrets, debug aj release použijú samostatný stabilný podpis Planneru s aliasom `planner-update`.

## Skutočná mobilná emulácia

Test nebol vykonaný iba zmenšením desktopového okna. Microsoft Edge/Chromium bol spustený pre každú mobilnú šírku so zapnutými parametrami:

- `isMobile: true`,
- `hasTouch: true`,
- Android mobile user-agent,
- device scale factor 3,
- samostatné hodnoty `viewport` aj `screen`.

Úspešne overené šírky:

```text
320, 360, 375, 390, 412, 430, 768 px
```

Na každej šírke prešlo všetkých osem workflow obrazoviek. Diagnostika overila:

```text
document.documentElement.scrollWidth <= window.innerWidth + 1
document.body.scrollWidth <= window.innerWidth + 1
offending elements = 0
```

Pri 390 px boli cez Chrome DevTools Protocol odoslané reálne touch udalosti. Prešlo:

- long-press drag overlay,
- presun tretej úlohy pred prvú,
- zachovanie poradia po reload,
- presun nezaradenej úlohy do sekcie,
- okamžitá zmena počtu nezaradených úloh.

Rovnaká kontrola všetkých obrazoviek prešla aj pri desktop šírke 1280 px.

## Automatické testy

Výsledok automatických testov: **15/15 úspešných**.

Node test suite zahŕňa aj kontrolu, že Gradle, Kotlin package a workflow nereferencujú `sk.latovanie.app` ani `latovanie-update-key.jks`.
