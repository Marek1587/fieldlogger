const test = require("node:test");
const assert = require("node:assert/strict");
const { readFileSync, existsSync } = require("node:fs");
const { join } = require("node:path");

const root = join(__dirname, "..");
const gradle = readFileSync(join(root, "app/build.gradle.kts"), "utf8");
const workflow = readFileSync(join(root, ".github/workflows/build-apk.yml"), "utf8");
const activity = readFileSync(join(root, "app/src/main/java/sk/strechostav/planner/MainActivity.kt"), "utf8");

test("Planner má samostatnú Android identitu bez referencie na balík Latovanie", () => {
  assert.match(gradle, /namespace = "sk\.strechostav\.planner"/);
  assert.match(gradle, /applicationId = "sk\.strechostav\.planner"/);
  assert.doesNotMatch(gradle, /sk\.latovanie\.app/);
  assert.match(activity, /^package sk\.strechostav\.planner/m);
  assert.equal(existsSync(join(root, "app/latovanie-update-key.jks")), false);
});

test("podpisová konfigurácia používa iba nový Planner názov a alias", () => {
  assert.match(gradle, /app\/planner-update-key\.jks/);
  assert.match(workflow, /app\/planner-update-key\.jks/);
  assert.doesNotMatch(workflow, /latovanie-update-key/);
  assert.match(readFileSync(join(root, "signing.properties.example"), "utf8"), /keyAlias=planner-update/);
});

test("nová samostatná verzia má zvýšené číslo", () => {
  assert.match(gradle, /versionCode = 12/);
  assert.match(gradle, /versionName = "2\.1\.0"/);
});
