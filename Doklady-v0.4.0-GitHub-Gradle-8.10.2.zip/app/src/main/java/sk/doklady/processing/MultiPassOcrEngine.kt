package sk.doklady.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Rect
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import sk.doklady.data.OcrElementEntity
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class OcrPassSummary(
    val name: String,
    val qualityScore: Int,
    val financiallyConsistent: Boolean,
    val itemSumCents: Long?,
    val totalCents: Long?,
    val differenceCents: Long?,
    val lineCount: Int,
    val characterCount: Int,
    val meanConfidence: Int,
    val durationMs: Long,
)

data class MultiPassOcrResult(
    val strategy: String,
    val rawText: String,
    val lines: List<OcrLine>,
    val elements: List<OcrElementEntity>,
    val qualityScore: Int,
    val financiallyConsistent: Boolean,
    val itemSumCents: Long?,
    val totalCents: Long?,
    val retryTriggered: Boolean,
    val passCount: Int,
    val passSummaries: List<OcrPassSummary>,
)

/**
 * Runs OCR over genuinely different image representations and, for long receipts,
 * over overlapping enlarged tiles. The selected result is the one with the best
 * receipt-oriented quality score; no synthetic OCR text is created.
 */
class MultiPassOcrEngine(private val context: Context) {
    fun recognize(documentId: String, bundle: PreprocessedBundle): MultiPassOcrResult {
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val candidates = mutableListOf<OcrCandidate>()
        try {
            bundle.variants.forEach { variant ->
                val started = System.currentTimeMillis()
                val text = Tasks.await(
                    recognizer.process(InputImage.fromFilePath(context, Uri.fromFile(variant.file))),
                )
                candidates += candidateFromText(
                    documentId = documentId,
                    name = variant.name,
                    text = text,
                    durationMs = System.currentTimeMillis() - started,
                )
            }

            zoomTileCandidate(documentId, bundle.primary, recognizer, REGULAR_TILES)?.let(candidates::add)
            // All normal passes have already run. If none is arithmetically coherent,
            // perform a genuinely higher-resolution retry using smaller overlapping tiles.
            if (candidates.none { it.reconciliation.financiallyConsistent }) {
                zoomTileCandidate(documentId, bundle.primary, recognizer, DETAIL_RETRY_TILES)?.let(candidates::add)
            }
        } finally {
            recognizer.close()
        }

        val valid = candidates.filter { it.rawText.isNotBlank() }
        require(valid.isNotEmpty()) { "OCR nerozpoznalo žiadny text ani v jednom obrazovom variante." }
        val selected = valid.maxWithOrNull(
            compareBy<OcrCandidate> { it.selectionScore }
                .thenBy { it.reconciliation.financiallyConsistent }
                .thenBy { it.meanConfidence }
                .thenBy { it.lines.size }
                .thenBy { it.rawText.length },
        ) ?: error("OCR nevytvorilo použiteľný výsledok.")

        return MultiPassOcrResult(
            strategy = selected.name,
            rawText = selected.rawText,
            lines = selected.lines,
            elements = selected.elements,
            qualityScore = combinedQuality(selected),
            financiallyConsistent = selected.reconciliation.financiallyConsistent,
            itemSumCents = selected.reconciliation.itemSumCents,
            totalCents = selected.reconciliation.totalCents,
            retryTriggered = candidates.any { it.name.startsWith("RETRY_") },
            passCount = candidates.sumOf { it.physicalPasses },
            passSummaries = candidates.map { candidate ->
                OcrPassSummary(
                    name = candidate.name,
                    qualityScore = candidate.score,
                    financiallyConsistent = candidate.reconciliation.financiallyConsistent,
                    itemSumCents = candidate.reconciliation.itemSumCents,
                    totalCents = candidate.reconciliation.totalCents,
                    differenceCents = candidate.reconciliation.differenceCents,
                    lineCount = candidate.lines.size,
                    characterCount = candidate.rawText.length,
                    meanConfidence = candidate.meanConfidence,
                    durationMs = candidate.durationMs,
                )
            },
        )
    }

    private fun candidateFromText(
        documentId: String,
        name: String,
        text: Text,
        durationMs: Long,
    ): OcrCandidate {
        val lines = mutableListOf<OcrLine>()
        val elements = mutableListOf<OcrElementEntity>()
        val confidences = mutableListOf<Float>()
        text.textBlocks.forEachIndexed { blockIndex, block ->
            block.lines.forEachIndexed { lineIndex, line ->
                line.boundingBox?.let { box ->
                    lines += OcrLine(line.text, box.left, box.top, box.right, box.bottom)
                }
                line.confidence?.let(confidences::add)
                line.elements.forEachIndexed { elementIndex, element ->
                    val box = element.boundingBox ?: return@forEachIndexed
                    element.confidence?.let(confidences::add)
                    elements += elementEntity(documentId, blockIndex, lineIndex, elementIndex, element.text, box, element.confidence)
                }
            }
        }
        val confidence = meanConfidence(confidences)
        return buildCandidate(
            name = name,
            rawText = text.text.orEmpty(),
            lines = lines,
            elements = elements,
            meanConfidence = confidence,
            durationMs = durationMs,
        )
    }

    private fun zoomTileCandidate(
        documentId: String,
        imageFile: java.io.File,
        recognizer: com.google.mlkit.vision.text.TextRecognizer,
        configuration: TileConfiguration,
    ): OcrCandidate? {
        val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath) ?: return null
        try {
            if (bitmap.height < bitmap.width * MIN_LONG_RECEIPT_RATIO) {
                return if (configuration.fullImageFallback) {
                    detailFullImageCandidate(documentId, bitmap, recognizer, configuration)
                } else null
            }
            val tileHeight = min(bitmap.height, (bitmap.width * configuration.heightRatio).roundToInt())
            if (tileHeight >= bitmap.height) {
                return if (configuration.fullImageFallback) {
                    detailFullImageCandidate(documentId, bitmap, recognizer, configuration)
                } else null
            }
            val step = max(1, (tileHeight * (1f - configuration.overlap)).roundToInt())
            val starts = buildTileStarts(bitmap.height, tileHeight, step, configuration.maxTiles)
            val collected = mutableListOf<TileLine>()
            var duration = 0L

            starts.forEachIndexed { tileIndex, startY ->
                val sourceTile = Bitmap.createBitmap(bitmap, 0, startY, bitmap.width, tileHeight)
                val zoomScale = (configuration.targetWidth.toFloat() / sourceTile.width)
                    .coerceIn(1f, configuration.maxUpscale)
                val inputTile = if (zoomScale > 1.02f) {
                    Bitmap.createScaledBitmap(
                        sourceTile,
                        (sourceTile.width * zoomScale).roundToInt(),
                        (sourceTile.height * zoomScale).roundToInt(),
                        true,
                    ).also { sourceTile.recycle() }
                } else sourceTile
                val started = System.currentTimeMillis()
                val result = try {
                    Tasks.await(recognizer.process(InputImage.fromBitmap(inputTile, 0)))
                } finally {
                    duration += System.currentTimeMillis() - started
                }
                collectTileLines(result, tileIndex, startY, zoomScale, collected)
                inputTile.recycle()
            }

            val merged = OcrLineMerger.merge(collected)
            if (merged.isEmpty()) return null
            val lines = merged.map { it.line }
            val rawText = lines.joinToString("\n") { it.text }
            val confidenceValues = merged.mapNotNull { it.confidence }
            val confidence = meanConfidence(confidenceValues)
            val elements = merged.flatMapIndexed { lineIndex, tileLine ->
                tileLine.elements.mapIndexed { elementIndex, element ->
                    elementEntity(
                        documentId = documentId,
                        blockIndex = tileLine.tileIndex,
                        lineIndex = lineIndex,
                        elementIndex = elementIndex,
                        value = element.text,
                        box = element.box,
                        confidence = element.confidence,
                    )
                }
            }
            return buildCandidate(
                name = "${configuration.name}_${starts.size}X",
                rawText = rawText,
                lines = lines,
                elements = elements,
                meanConfidence = confidence,
                durationMs = duration,
                physicalPasses = starts.size,
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun detailFullImageCandidate(
        documentId: String,
        bitmap: Bitmap,
        recognizer: com.google.mlkit.vision.text.TextRecognizer,
        configuration: TileConfiguration,
    ): OcrCandidate {
        val scale = (configuration.targetWidth.toFloat() / bitmap.width).coerceIn(1f, configuration.maxUpscale)
        val input = if (scale > 1.02f) {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).roundToInt(),
                (bitmap.height * scale).roundToInt(),
                true,
            )
        } else bitmap
        val started = System.currentTimeMillis()
        return try {
            val text = Tasks.await(recognizer.process(InputImage.fromBitmap(input, 0)))
            candidateFromText(
                documentId = documentId,
                name = "RETRY_DETAIL_FULL",
                text = text,
                durationMs = System.currentTimeMillis() - started,
            )
        } finally {
            if (input !== bitmap) input.recycle()
        }
    }

    private fun collectTileLines(
        text: Text,
        tileIndex: Int,
        startY: Int,
        zoomScale: Float,
        destination: MutableList<TileLine>,
    ) {
        text.textBlocks.forEach { block ->
            block.lines.forEach { line ->
                val lineBox = line.boundingBox ?: return@forEach
                val mappedLine = mapBox(lineBox, startY, zoomScale)
                val mappedElements = line.elements.mapNotNull { element ->
                    element.boundingBox?.let { box ->
                        TileElement(element.text, mapBox(box, startY, zoomScale), element.confidence)
                    }
                }
                destination += TileLine(
                    line = OcrLine(line.text, mappedLine.left, mappedLine.top, mappedLine.right, mappedLine.bottom),
                    confidence = line.confidence,
                    tileIndex = tileIndex,
                    elements = mappedElements,
                )
            }
        }
    }

    private fun mapBox(box: Rect, startY: Int, scale: Float): Rect = Rect(
        (box.left / scale).roundToInt(),
        startY + (box.top / scale).roundToInt(),
        (box.right / scale).roundToInt(),
        startY + (box.bottom / scale).roundToInt(),
    )

    private fun elementEntity(
        documentId: String,
        blockIndex: Int,
        lineIndex: Int,
        elementIndex: Int,
        value: String,
        box: Rect,
        confidence: Float?,
    ) = OcrElementEntity(
        documentId = documentId,
        blockIndex = blockIndex,
        lineIndex = lineIndex,
        elementIndex = elementIndex,
        text = value,
        left = box.left,
        top = box.top,
        right = box.right,
        bottom = box.bottom,
        confidence = confidence,
    )

    private fun buildTileStarts(height: Int, tileHeight: Int, step: Int, maxTiles: Int): List<Int> {
        val result = mutableListOf<Int>()
        var start = 0
        while (start + tileHeight < height && result.size < maxTiles - 1) {
            result += start
            start += step
        }
        val finalStart = height - tileHeight
        if (result.lastOrNull() != finalStart) result += finalStart
        return result.distinct()
    }

    private fun meanConfidence(values: List<Float>): Int = if (values.isEmpty()) 0 else
        (values.average() * 100).roundToInt().coerceIn(0, 100)

    private fun buildCandidate(
        name: String,
        rawText: String,
        lines: List<OcrLine>,
        elements: List<OcrElementEntity>,
        meanConfidence: Int,
        durationMs: Long,
        physicalPasses: Int = 1,
    ): OcrCandidate {
        val parsed = GenericDocumentParser().parse(lines)
        val reconciliation = ReceiptReconciler.evaluate(parsed)
        val visualScore = OcrQualityScorer.score(rawText, lines, meanConfidence)
        return OcrCandidate(
            name = name,
            rawText = rawText,
            lines = lines,
            elements = elements,
            score = visualScore,
            selectionScore = visualScore + reconciliation.semanticScore,
            reconciliation = reconciliation,
            meanConfidence = meanConfidence,
            durationMs = durationMs,
            physicalPasses = physicalPasses,
        )
    }

    private fun combinedQuality(candidate: OcrCandidate): Int {
        val financialQuality = when {
            candidate.reconciliation.financiallyConsistent -> 100
            candidate.reconciliation.differenceCents == null -> 20
            candidate.reconciliation.differenceCents <= 5 -> 85
            candidate.reconciliation.differenceCents <= 20 -> 65
            else -> 25
        }
        return (candidate.score * 0.65f + financialQuality * 0.35f).roundToInt().coerceIn(0, 100)
    }

    private data class OcrCandidate(
        val name: String,
        val rawText: String,
        val lines: List<OcrLine>,
        val elements: List<OcrElementEntity>,
        val score: Int,
        val selectionScore: Int,
        val reconciliation: ReceiptReconciliation,
        val meanConfidence: Int,
        val durationMs: Long,
        val physicalPasses: Int = 1,
    )

    private data class TileConfiguration(
        val name: String,
        val heightRatio: Float,
        val overlap: Float,
        val targetWidth: Int,
        val maxUpscale: Float,
        val maxTiles: Int,
        val fullImageFallback: Boolean = false,
    )

    companion object {
        private const val MIN_LONG_RECEIPT_RATIO = 1.55f
        private val REGULAR_TILES = TileConfiguration(
            name = "ZOOM_TILES",
            heightRatio = 1.35f,
            overlap = 0.18f,
            targetWidth = 2_200,
            maxUpscale = 1.45f,
            maxTiles = 8,
        )
        private val DETAIL_RETRY_TILES = TileConfiguration(
            name = "RETRY_DETAIL_TILES",
            heightRatio = 0.88f,
            overlap = 0.25f,
            targetWidth = 2_800,
            maxUpscale = 1.80f,
            maxTiles = 10,
            fullImageFallback = true,
        )
    }
}

internal data class TileElement(val text: String, val box: Rect, val confidence: Float?)

internal data class TileLine(
    val line: OcrLine,
    val confidence: Float?,
    val tileIndex: Int,
    val elements: List<TileElement>,
)

internal object OcrLineMerger {
    fun merge(lines: List<TileLine>): List<TileLine> {
        val sorted = lines.filter { it.line.text.isNotBlank() }
            .sortedWith(compareBy<TileLine> { it.line.top }.thenBy { it.line.left })
        val result = mutableListOf<TileLine>()
        sorted.forEach { candidate ->
            val duplicateIndex = result.indexOfFirst { existing -> isDuplicate(existing, candidate) }
            if (duplicateIndex < 0) {
                result += candidate
            } else if ((candidate.confidence ?: 0f) > (result[duplicateIndex].confidence ?: 0f)) {
                result[duplicateIndex] = candidate
            }
        }
        return result.sortedWith(compareBy<TileLine> { it.line.top }.thenBy { it.line.left })
    }

    private fun isDuplicate(first: TileLine, second: TileLine): Boolean {
        val a = normalize(first.line.text)
        val b = normalize(second.line.text)
        if (a.length < 3 || b.length < 3) return false
        val verticalTolerance = max(first.line.bottom - first.line.top, second.line.bottom - second.line.top) * 2
        if (abs(first.line.top - second.line.top) > max(12, verticalTolerance)) return false
        if (a == b) return true
        val longer = max(a.length, b.length)
        return 1f - levenshtein(a, b).toFloat() / longer >= 0.82f
    }

    private fun normalize(value: String): String = value.uppercase().filter(Char::isLetterOrDigit)

    private fun levenshtein(a: String, b: String): Int {
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + if (a[i] == b[j]) 0 else 1,
                )
            }
            previous = current
        }
        return previous[b.length]
    }
}

internal object OcrQualityScorer {
    private val amount = Regex("(?<!\\d)\\d{1,7}[,.]\\d{2}(?!\\d)")
    private val date = Regex("\\b\\d{1,2}[./-]\\d{1,2}[./-]\\d{2,4}\\b")
    private val receiptKeywords = listOf(
        "CELKOM", "SPOLU", "TOTAL", "SUMA", "UHRAD", "DPH", "VAT", "EUR", "DATUM", "DÁTUM", "ICO", "IČO",
    )

    fun score(rawText: String, lines: List<OcrLine>, meanConfidence: Int): Int {
        if (rawText.isBlank()) return 0
        val normalized = rawText.uppercase()
        val characterCount = rawText.count { !it.isWhitespace() }
        val usefulLines = lines.count { line -> line.text.count(Char::isLetterOrDigit) >= 3 }
        val oneCharacterLines = lines.count { it.text.trim().length <= 1 }
        val amounts = amount.findAll(rawText).count()
        val keywords = receiptKeywords.count(normalized::contains)
        val dates = date.findAll(rawText).count()
        val alphaNumericRatio = rawText.count(Char::isLetterOrDigit).toFloat() / max(1, characterCount)

        val score =
            min(20, characterCount / 35) +
                min(18, usefulLines) +
                min(18, amounts * 3) +
                min(16, keywords * 3) +
                min(5, dates * 5) +
                (meanConfidence * 0.18f).roundToInt() +
                (if (alphaNumericRatio >= 0.62f) 5 else 0) -
                min(10, oneCharacterLines * 2)
        return score.coerceIn(0, 100)
    }
}
