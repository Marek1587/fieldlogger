# Doklady

Natívna offline-first Android aplikácia v Kotlin/Jetpack Compose na evidenciu bločkov a faktúr.

## Spracovanie

Každá fotografia sa najprv skopíruje do interného úložiska. Room záznam prejde cez skutočné stavy:

`CAPTURED → QUEUED → PREPROCESSING → OCR → PARSING → VALIDATING → PROCESSED/REVIEW_REQUIRED/ERROR`

WorkManager používa jednu persistentnú unique work reťaz `document-processing-sequential-queue`. Jednotlivé doklady majú samostatný `DocumentProcessingWorker`, ale náročné OCR úlohy sa vykonávajú po jednom. Worker nemá network constraint a pokračuje aj bez otvoreného ViewModelu.

OCR používa bundled `com.google.mlkit:text-recognition`, teda model je súčasťou APK a základná pipeline nevyžaduje internet. Pred OCR sa konzervatívne nájde a vyreže plocha dokladu, úzky doklad sa zväčší a vytvoria sa varianty `ENHANCED_GRAY`, `COLOR_CROP` a `ADAPTIVE_BINARY`. Pri dlhých dokladoch sa pridajú prekrývajúce sa zoomované výrezy. Aplikácia vykoná reálne OCR nad každým variantom, odstráni duplicitné riadky výrezov a vyberie výsledok s najlepším skóre podľa čitateľnosti, cien a typických polí dokladu. Zvolená stratégia, počet priechodov a skóre sú uložené v Room a viditeľné v diagnostike.

Výber OCR výsledku obsahuje aj ekonomickú kontrolu: parser spočíta riadkové sumy vrátane zliav a záloh a hľadá rovnakú hodnotu pri `MEDZISÚČET`, `NA ÚHRADU`, `CELKOM` alebo `KARTA`. Texty o úspore sa nesmú použiť ako celková suma ani položka. Ak sa žiadny bežný OCR variant matematicky nezhoduje, automaticky sa spustí detailný retry s menšími a viac zväčšenými výrezmi. Nezhodný výsledok je označený `REVIEW_REQUIRED` a nemôže dostať vysokú confidence iba preto, že OCR našlo veľa textu.

Ukladajú sa RAW text, geometrické OCR elementy, parsované polia, položky, confidence, chybová fáza, stack trace a časy jednotlivých krokov.

## Galéria

Hlavné tlačidlo galérie otvára vlastný MediaStore albumový browser cez `BUCKET_ID` a `BUCKET_DISPLAY_NAME`. Podporuje multiselect. Systémový Photo Picker zostáva dostupný ako sekundárna voľba.

## Excel

Aplikácia generuje platný XLSX lokálne a bez Excelu. Obsahuje listy `DOKLADY`, `POLOŽKY`, `DPH` a `DODÁVATELIA`. Výsledok možno zdieľať cez FileProvider alebo uložiť cez Android Storage Access Framework.

## Zostavenie

Projekt vyžaduje JDK 17, Android SDK 35 a je zladený s Gradle 8.10.2.

```powershell
.\gradlew.bat testDebugUnitTest :app:assembleDebug lintDebug
```

Debug APK vznikne v `app/build/outputs/apk/debug/app-debug.apk`.

## Diagnostika

Tlačidlo **Diagnostika** na hlavnej obrazovke zobrazuje Work UUID, počet pokusov, stav, chybovú fázu, správu, stack trace a časy importu/preprocessingu/OCR/parsera/validácie. Recovery Worker kontroluje staré aktívne záznamy každých 15 minút a legacy záznamy `CAPTURED` po aktualizácii automaticky zaradí do fronty.
