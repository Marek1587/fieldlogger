# Univerzálny strešný solver 3.1

## Geometrická autorita

Jediným zdrojom 2D a 3D geometrie je `RoofGraph`: stabilné uzly, explicitné hrany, konečné plochy a constraints. Názov typu strechy je iba metadata. Každá nezvislá strešná plocha používa rovnicu:

`z = a*x + b*y + c`

Smer `FaceSlopeConstraint` je smer spádu. Gradient `(a,b)` preto smeruje opačne. Spoločný `NodeId` má v každej incidentnej ploche rovnakú výšku.

## Presné riešenie

Solver skladá incidencie Node–Face, uzamknuté výšky, výškové body, nízke hrany a vpuste do jednej sústavy presných lineárnych rovníc. Tvrdé podmienky sa nepribližujú veľkou váhou ani priemerom. Ak nemajú spoločné riešenie, 3D model a výkaz sa zablokujú s konkrétnou diagnostikou.

Tolerancia koplanarity je `1e-6 m` (0,001 mm). Validátor navyše kontroluje odkazy, orientáciu cyklov, incidenciu hrán, priesečníky, Eulerov invariant a topologické udalosti.

## Bezpečná inicializácia topológie

Samotný vonkajší obrys neurčuje, či má byť strecha sedlová, valbová, polvalbová, L-strecha alebo ich kombinácia. Aplikácia preto pri nejednoznačnom obryse nevymýšľa strechu podľa presetu. Vyžaduje explicitné vnútorné hrany alebo smer sklonu plôch. Zánik hrebeňa, hrany, plochy či polvalbového rezu je explicitná topologická udalosť a vyžaduje retopologizáciu.

## Otvory a sekundárne komponenty

Schéma pozná `Face.holeNodeIdLoops`, `RoofComponent` a `hostFaceId`. Kým otvor nie je rozdelený na presnú neprekrývajúcu sa sieť konečných plôch, solver bezpečne odmietne vytvoriť 3D model. Tým sa zabráni tomu, aby renderer otvor omylom prekryl strešnou plochou. Vikier sa modeluje ako sekundárny komponent pripojený k hostiteľskej ploche.

Komín, strešné okno, výlez a prestup sú odvodené 3D telesá nad príslušnou plochou. Zvislá atika a steny nie sú `RoofFace`, pretože ich nemožno zapísať vo forme `z=f(x,y)`; patria do odvodenej shell vrstvy.

## Ploché strechy a odvodnenie

Vpust je spoločný nízky bod viacerých spádových rovín. Chrlič alebo líniový žľab je nízka hrana. Používa sa rovnaký face solver ako pri šikmej streche, iba s malým sklonom a inými constraints.

## Kanonický import

`ProjectJson.decode` priamo rozpozná `roof-face-model/1.x`. Adaptér prevedie mm/cm/m na metre, zachová stabilné ID, načíta `downhillDirectionXY`, hrany, plochy, výšky, komponenty a oddelený stenový pôdorys. Staršie interné grafy sa migrujú na schému 2 a pôvodný uphill smer sa invertuje.

Referenčné súbory v adresári `reference-models/` dokumentujú L-polvalbovú sieť 14 uzlov, 19 hrán a 6 konečných plôch, knižnicu vzorov a analytické zistenia.

## Zachované invarianty pri editácii

- pevné XY a Z uzamknutia,
- zdieľané uzly a presné incidencie,
- tvrdé dĺžkové a rozmerové constraints,
- žiadne samopriečne alebo nulové hrany,
- žiadne tiché zmeny topológie,
- 3D model, výkaz a export používajú iba validovaný vyriešený snapshot.
