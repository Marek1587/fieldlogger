# Funkcie prenesené z dodaných PHP súborov

| PHP funkcia / pracovný postup | Android implementácia |
|---|---|
| adresa alebo GPS | vyhľadávací riadok, priame súradnice a poloha telefónu |
| mapový nákres | ZBGIS ortofoto alebo OpenStreetMap bez API kľúča |
| projektový výkres | import prvej strany PDF alebo JPG/PNG/WebP ako podklad |
| Overpass obrys budovy | tlačidlo `Budova`, výber najbližšieho validného polygonu |
| ručné obkreslenie polygonu | `Obrys prstom` |
| pridanie a presun vrcholov | `Bod` a `Editovať`; presná dĺžka hrany cez číselné kolieska |
| mierka výkresu | kalibrácia celého nákresu podľa jednej známej hrany |
| regularizácia geometrie | `Skorigovať`, smery 0° / 45° / 90° |
| hrebeň / úžľabie / nárožie | samostatné farebné nástroje a vstupy pre automatický 3D model |
| atika / pult / pri murive | vnútorné línie aj cyklický typ obvodovej hrany |
| komín / okno / výlez | obdĺžnikové prvky |
| prestup / vpusť | kruhové prvky |
| zvod / výška / sklon | bodové technické značky |
| výkaz výmer | samostatná obrazovka bez hydroizolácie, podkladu a cien |
| GPS a JSON model | lokálny projekt a JSON import/export |
| technický SVG / PDF | natívny výstup s rozmermi a čistým výkazom výmer |
| 3D klampiarsky náhľad | OpenGL ES 3, steny budovy, otočenie, zoom a reset |

Cenový a hydroizolačný kalkulátor z PHP nie je súčasťou tejto verzie podľa
zadania. Serverové funkcie PHP (archivácia ponúk, databáza, formuláre a
štatistiky) tiež nie sú prenesené; projekty sa ukladajú iba lokálne.
