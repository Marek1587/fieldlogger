# Technické poznámky 3.6.0

## Jediný model, dve vykresľovacie cesty

`RoofMeshBuilder` vytvára z validovaného `RoofGraph` rovnaké trojuholníky, materiály, logo roviny a technické kóty pre `GLSurfaceView` aj `RoofBitmapRenderer`. Statické PDF izometrie nevytvárajú EGL kontext a nesnímajú obrazovku.

## Pixelové rozmiestnenie kót

OpenGL projektor zachováva NDC hĺbku a barycentricky testuje stred nosnej hrany voči premietnutým trojuholníkom. `Roof3DDimensionOverlay` potom skúša viacero odstupov smerom od stredu modelu. Kandidát sa prijme iba ak je v obrazovke, neprekrýva existujúci štítok a jeho čiara nepretína už umiestnený štítok. Ak bezpečné miesto nie je, kóta sa v danom pohľade nevykreslí.

## Parametrický pravouhlý pôdorys

Pri presnosti 10° sa rozpoznajú dve dvojice rovnobežných protiľahlých strán a kolmé susedné strany. Každá dvojica zdieľa `dimensionId` a oba `EdgeId`. Zmena jednej kóty vykoná jednu transakciu:

1. vytvorí lokálnu ortonormálnu bázu,
2. nastaví obe protiľahlé strany na spoločný rozmer,
3. pravouhlo zoradí štyri obvodové uzly,
4. afinne prenesie vnútorné uzly,
5. zachová všetky incidencie, NodeId, EdgeId a FaceId,
6. uloží dve tvrdé milimetrové `EdgeLengthConstraint`.

Platná 2D transformácia sa nezahodí iba preto, že rozpracovaná strecha ešte nemá dostatok Z obmedzení. Výšky dorieši `Roof3DPreparation` po dokončení typológie.

## Steny, presah a sklon

Stenový mesh sa extruduje zo samostatného `wallFootprint` po `wallHeightM`. Uniformný presah vzniká priesečníkmi susedných dovnútra odsadených priamok. Príliš veľké alebo degenerované odsadenie sa odmietne. Sklon aktualizuje projektový predvolený uhol aj existujúce `FaceSlopeConstraint`, pričom XY topológia zostáva nedotknutá.

## Logo a materiály

Logo rovina sa vyberá na dvoch najväčších plochách. OpenGL ju kreslí transparentnou textúrou vytvorenou Kotlin/Canvas rendererom zo zdrojového SVG motívu. Statický renderer mapuje rovnakú bitmapu perspektívnou `Matrix.setPolyToPoly`. Antracitový materiál kombinuje pevnú modelovú zrnitosť a obmedzené osvetlenie približne do 20 %; materiál stien je explicitne svetlobéžový.

## Regresia

Zostavenie je prijateľné iba po `:app:testDebugUnitTest` a `:app:assembleDebug`. Testy kontrolujú topologickú identitu, dve zdieľané kóty pravouhlého pôdorysu, 90° susedné strany, rovnaké protiľahlé rozmery, tvrdé constraints, materiály a dve logo roviny.
