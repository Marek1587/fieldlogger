# Technické poznámky StrechoStav Sketch 2.4.0

## Spoločná transformácia zobrazenia

`RoofProject` uchováva `mapRotationDeg`. Raster mapy aj všetky projektované prvky
používajú rovnaký stred, zoom a rotáciu. Inverzná transformácia sa používa pri
dotyku, takže bod zostane pod prstom aj na otočenej mape. PDF/JPG podklad používa
rovnakú maticu. Pri rotácii renderer zväčší rozsah pripravovaných dlaždíc tak, aby
sa v rohoch obrazovky neobjavili prázdne plochy.

## Voľná ruka

Vzorky sa najprv filtrujú podľa minimálnej vzdialenosti, následne sa potlačí
vysokofrekvenčný šum váženým susedným priemerom. Uzavretý polygón sa potom
deterministicky zjednoduší Visvalingamovým kritériom plochy na najviac 10 vrcholov.
Algoritmus je čistá testovateľná funkcia `FreehandSimplifier.simplify`.

## Magnetické línie a výber bodu

Kandidát snapu môže byť vrchol obrysu, koniec existujúcej línie alebo kolmý priemet
na obvodovú či vnútornú hranu. Výber prebieha v obrazovkovej tolerancii 26 dp,
uložený výsledok je však GPS/modelová súradnica. Editovateľný uzol sa aktivuje po
480 ms podržaní, telefón zavibruje a bod sa zafarbí na oranžovo.

## Atika

Projekt uchováva `atticHeightM` s predvolenou hodnotou 0,6 m a rozsahom 0,1–3,0 m.
Obvodová aj vnútorná hrana typu `ATTIC` vytvára v 3D obojstrannú zvislú mesh stenu
od lokálnej strešnej výšky po hornú hranu atiky.

## Migrácia

JSON schéma 4 pridáva `map_rotation_deg` a `attic_height_m`. Staršie projekty sa
načítajú s rotáciou 0° a výškou atiky 0,6 m; ostatné polia a topologický graf sa
nemenia.
