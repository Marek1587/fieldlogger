# StrechoStav Sketch 3.7.2 – presné SVG logo a kóty základne

## Logo

`StrechoStavLogo.kt` obsahuje pôvodnú vektorovú geometriu dodaného súboru `logo.svg`:

- 11 vyplnených ciest s pravidlom `EVEN_ODD`,
- 1 cestu obrysu strechy a komína so šírkou ťahu 9 jednotiek,
- pôvodnú farbu `#99A2A6`,
- všetky písmená ako pôvodné Bézierove krivky bez závislosti od systémového fontu.

Rovnaká bitmapa sa používa ako OpenGL textúra a ako zdroj pre samostatný Kotlin renderer statických PDF pohľadov.

## Ochrana proti zrkadleniu

Logo quad sa do OpenGL VBO zapisuje v poradí `TL–TR–BR` a `TL–BR–BL`. Obe trojuholníkové časti preto majú normálu na lícnu stranu strechy. Fragment shader vykreslí iba `gl_FrontFacing`; pohľad zo zadnej strany nemôže zobraziť zrkadlový nápis.

## Pôdorysné kóty

Koncové body a vynášacie čiary rozmerov `PLAN_LENGTH` sú odvodené z `wallBottom`. Rozmer teda označuje základňu stavebného pôdorysu. Nezávisí od sklonu strechy, výšky steny ani presahu odkvapu.

## Regresné overenie

Testy kontrolujú:

- presne 12 ciest pôvodného SVG,
- kladnú orientáciu oboch logo quadov,
- umiestnenie všetkých koncov pôdorysných kót v minimálnej výške 3D mesh siete,
- zachovanie zdieľaných rozmerových väzieb protiľahlých strán.
