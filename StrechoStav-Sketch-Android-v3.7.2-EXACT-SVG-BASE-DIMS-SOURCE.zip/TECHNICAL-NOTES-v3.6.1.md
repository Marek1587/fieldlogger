# Technické poznámky 3.6.1 – plochá strecha a atika

## Výškový model plochej strechy

Plochá strecha je jedna topologická plocha s rovnicou `z = a*x + b*y + c`. Nepotrebuje umelý hrebeň ani vnútornú deliacu čiaru. Režim sa aktivuje explicitným `RoofShape.FLAT` alebo prítomnosťou obvodovej hrany `ATTIC`.

Atika nie je nízka hrana strešnej roviny. Ak je zadaný odkvap, najdlhší vhodný odkvap tvorí nízku podporu a vnútorná plocha stúpa smerom od neho podľa nastaveného sklonu. Pri celom obvode z atiky sa najnižší bod roviny ukotví na výšku steny a smer sa deterministicky odvodí od najdlhšej obvodovej hrany.

## Samostatná geometria atiky

Atika je odvodený 3D pás a nemení incidenciu `RoofGraph`. Každý úsek obsahuje:

- vonkajšiu zvislú plochu od hornej hrany steny,
- vnútornú plochu začínajúcu na spádovanej strešnej rovine,
- hornú vodorovnú korunu s konštantnou absolútnou výškou,
- koncové uzávery a technické hrany.

Horná výška je `max(z strešnej roviny na atikách) + atticHeightM`. Hodnota `atticHeightM` preto vyjadruje minimálnu výšku atiky nad najvyšším miestom pri obvode. Predvolená hodnota nového alebo migrovaného projektu bez údaja je 0,3 m.

## Parametrická kóta

Všetky atikové úseky zdieľajú jednu kótu `ATTIC_HEIGHT`. Projektor vyberie viditeľného kandidáta. Kliknutie otvorí `NumberPicker` v rozsahu 100–3000 mm s krokom 10 mm; živý náhľad používa ten istý `RoofMeshBuilder` a potvrdenie vytvorí jeden Undo krok.

## Regresia

Testy overujú neblokovaný solver, jednu strešnú plochu, nenulový gradient podľa nastaveného sklonu, odkvap na výške steny, rozdielne výšky uzlov spádovej roviny, vodorovnú maximálnu korunu mesh siete, kótu 300 mm, nenulový výkaz a explicitnú plochú strechu bez vnútorných línií.
