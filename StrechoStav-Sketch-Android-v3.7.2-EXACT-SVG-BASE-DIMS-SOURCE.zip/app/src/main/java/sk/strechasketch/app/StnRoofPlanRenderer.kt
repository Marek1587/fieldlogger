package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Monochrome technical roof-plan renderer based on the drawing conventions of STN 01 3420.
 *
 * The renderer is deliberately independent from the map/editor overlay. Editing colours remain
 * available in the field, while PDF/bitmap output uses deterministic technical line hierarchy,
 * external dimension chains and a compact title block.
 */
object StnRoofPlanRenderer {
    data class Options(
        val drawFrame: Boolean = false,
        val drawTitleBlock: Boolean = true,
        val pixelsPerInch: Float = 72f,
        val backgroundColor: Int = Color.WHITE
    )

    private data class Projection(
        val origin: GeoPoint,
        val angle: Double,
        val polygon: List<LocalPoint>,
        val minX: Double,
        val maxX: Double,
        val minY: Double,
        val maxY: Double
    ) {
        fun local(point: GeoPoint): LocalPoint {
            val raw = Geometry.toLocal(point, origin)
            val c = cos(-angle)
            val s = sin(-angle)
            return LocalPoint(raw.x * c - raw.y * s, raw.x * s + raw.y * c)
        }
    }

    private data class Mapper(
        val projection: Projection,
        val scale: Float,
        val centerX: Float,
        val centerY: Float
    ) {
        fun screen(point: LocalPoint): PointF = PointF(
            centerX + ((point.x - (projection.minX + projection.maxX) / 2.0) * scale).toFloat(),
            centerY - ((point.y - (projection.minY + projection.maxY) / 2.0) * scale).toFloat()
        )

        fun screen(point: GeoPoint): PointF = screen(projection.local(point))
    }

    private data class LineRow(val a: LocalPoint, val b: LocalPoint, val type: LineType, val id: String)

    fun render(
        project: RoofProject,
        width: Int,
        height: Int,
        options: Options = Options(drawFrame = true, pixelsPerInch = 96f)
    ): Bitmap {
        require(width in 128..4096 && height in 128..4096)
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
            draw(Canvas(bitmap), project, RectF(0f, 0f, width.toFloat(), height.toFloat()), options)
        }
    }

    fun draw(canvas: Canvas, project: RoofProject, bounds: RectF, options: Options = Options()) {
        canvas.save()
        canvas.clipRect(bounds)
        canvas.drawColor(options.backgroundColor)
        if (project.polygon.size < 3) {
            val message = paintText(bounds, 13f, bold = true).apply { textAlign = Paint.Align.CENTER }
            canvas.drawText("Nákres nemá uzavretý obrys.", bounds.centerX(), bounds.centerY(), message)
            canvas.restore()
            return
        }

        val unit = max(0.72f, min(bounds.width(), bounds.height()) / 620f)
        val projection = projection(project)
        val frameInset = if (options.drawFrame) 8f * unit else 0f
        val sheet = RectF(bounds).apply { inset(frameInset, frameInset) }
        val titleHeight = if (options.drawTitleBlock) 48f * unit else 0f
        val headerHeight = 28f * unit
        val dimensionMargin = 54f * unit
        val plot = RectF(
            sheet.left + dimensionMargin,
            sheet.top + headerHeight + dimensionMargin * 0.52f,
            sheet.right - dimensionMargin,
            sheet.bottom - titleHeight - dimensionMargin * 0.72f
        )

        val spanX = max(0.01, projection.maxX - projection.minX)
        val spanY = max(0.01, projection.maxY - projection.minY)
        val fitScale = min(plot.width() / spanX.toFloat(), plot.height() / spanY.toFloat())
        val denominator = standardScaleDenominator(fitScale, options.pixelsPerInch)
        val exactScale = options.pixelsPerInch * 39.3700787f / denominator
        val scale = min(fitScale, exactScale)
        val mapper = Mapper(projection, scale, plot.centerX(), plot.centerY())

        if (options.drawFrame) drawSheetFrame(canvas, sheet, unit)
        drawHeader(canvas, project, sheet, denominator, unit)
        drawRoofFaces(canvas, project, mapper, unit)
        drawWallFootprint(canvas, project, mapper, unit)
        drawRoofOutline(canvas, project, mapper, unit)
        drawInternalLines(canvas, project, mapper, unit)
        drawObjects(canvas, project, mapper, unit)
        drawBoundaryDimensions(canvas, project, mapper, projection, unit)
        drawOverallDimensions(canvas, mapper, projection, unit)
        if (options.drawTitleBlock) drawTitleBlock(canvas, project, sheet, denominator, unit)
        canvas.restore()
    }

    private fun projection(project: RoofProject): Projection {
        val origin = Geometry.centroid(project.polygon)
        val raw = project.polygon.map { Geometry.toLocal(it, origin) }
        val longest = raw.indices.maxByOrNull { index ->
            val next = raw[(index + 1) % raw.size]
            hypot(next.x - raw[index].x, next.y - raw[index].y)
        } ?: 0
        val next = raw[(longest + 1) % raw.size]
        val angle = atan2(next.y - raw[longest].y, next.x - raw[longest].x)
        val c = cos(-angle)
        val s = sin(-angle)
        val rotated = raw.map { LocalPoint(it.x * c - it.y * s, it.x * s + it.y * c) }
        return Projection(
            origin = origin,
            angle = angle,
            polygon = rotated,
            minX = rotated.minOf { it.x },
            maxX = rotated.maxOf { it.x },
            minY = rotated.minOf { it.y },
            maxY = rotated.maxOf { it.y }
        )
    }

    private fun standardScaleDenominator(fitPixelsPerMeter: Float, pixelsPerInch: Float): Float {
        val candidates = floatArrayOf(20f, 25f, 50f, 100f, 200f, 250f, 500f, 1000f)
        return candidates.firstOrNull { pixelsPerInch * 39.3700787f / it <= fitPixelsPerMeter } ?: 1000f
    }

    private fun drawHeader(canvas: Canvas, project: RoofProject, sheet: RectF, denominator: Float, unit: Float) {
        val title = paintText(sheet, 12f * unit, bold = true)
        canvas.drawText("PÔDORYS STRECHY", sheet.left + 12f * unit, sheet.top + 18f * unit, title)
        val meta = paintText(sheet, 7.2f * unit)
        canvas.drawText("M 1:${denominator.roundToInt()}  •  KÓTY V mm", sheet.left + 12f * unit, sheet.top + 29f * unit, meta)
        meta.textAlign = Paint.Align.RIGHT
        canvas.drawText(project.name, sheet.right - 12f * unit, sheet.top + 18f * unit, meta)
    }

    private fun drawRoofFaces(canvas: Canvas, project: RoofProject, mapper: Mapper, unit: Float) {
        val graph = project.roofGraph ?: return
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.rgb(249, 250, 250)
        }
        val fine = stroke(Color.rgb(140, 145, 148), 0.40f * unit)
        graph.faces.values.sortedBy { it.id }.forEachIndexed { index, face ->
            val points = face.orderedNodeIds.mapNotNull { graph.nodes[it] }.map { node ->
                mapper.screen(Geometry.toGeo(LocalPoint(node.x, node.y), graph.origin))
            }
            if (points.size < 3) return@forEachIndexed
            val path = path(points, close = true)
            fill.color = if (index % 2 == 0) Color.rgb(250, 250, 249) else Color.rgb(245, 246, 246)
            canvas.drawPath(path, fill)
            canvas.drawPath(path, fine)
        }
    }

    private fun drawWallFootprint(canvas: Canvas, project: RoofProject, mapper: Mapper, unit: Float) {
        if (project.wallFootprint.size < 3) return
        val points = project.wallFootprint.map(mapper::screen)
        val wall = stroke(Color.rgb(86, 91, 94), 0.60f * unit).apply {
            pathEffect = DashPathEffect(floatArrayOf(8f * unit, 3f * unit, 1.2f * unit, 3f * unit), 0f)
        }
        canvas.drawPath(path(points, close = true), wall)
    }

    private fun drawRoofOutline(canvas: Canvas, project: RoofProject, mapper: Mapper, unit: Float) {
        val points = project.polygon.map(mapper::screen)
        canvas.drawPath(path(points, close = true), stroke(Color.rgb(17, 20, 22), 2.15f * unit))
    }

    private fun graphLines(project: RoofProject, projection: Projection): List<LineRow> {
        val graph = project.roofGraph
        if (graph != null) {
            return graph.edges.values.asSequence().filter { !it.boundary }.mapNotNull { edge ->
                val a = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                val b = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                val aGeo = Geometry.toGeo(LocalPoint(a.x, a.y), graph.origin)
                val bGeo = Geometry.toGeo(LocalPoint(b.x, b.y), graph.origin)
                LineRow(projection.local(aGeo), projection.local(bGeo), edge.semanticRole.toLegacy(), edge.id)
            }.toList()
        }
        return project.lines.map { LineRow(projection.local(it.start), projection.local(it.end), it.type, it.id) }
    }

    private fun drawInternalLines(canvas: Canvas, project: RoofProject, mapper: Mapper, unit: Float) {
        graphLines(project, mapper.projection).forEach { row ->
            val a = mapper.screen(row.a)
            val b = mapper.screen(row.b)
            val paint = when (row.type) {
                LineType.RIDGE, LineType.HIP, LineType.PULT -> stroke(Color.rgb(17, 20, 22), 1.25f * unit)
                LineType.VALLEY -> stroke(Color.rgb(17, 20, 22), 1.05f * unit)
                LineType.STEP -> stroke(Color.BLACK, 1.65f * unit)
                LineType.OPENING_BOUNDARY, LineType.UNKNOWN -> stroke(Color.rgb(75, 80, 83), 0.75f * unit).apply {
                    pathEffect = DashPathEffect(floatArrayOf(5f * unit, 3f * unit), 0f)
                }
                else -> stroke(Color.rgb(45, 49, 52), 0.90f * unit)
            }
            canvas.drawLine(a.x, a.y, b.x, b.y, paint)
            if (hypot((b.x - a.x).toDouble(), (b.y - a.y).toDouble()) > 46f * unit) {
                drawLineLabel(canvas, row.type.label.uppercase(), a, b, unit)
            }
        }
    }

    private fun drawLineLabel(canvas: Canvas, text: String, a: PointF, b: PointF, unit: Float) {
        val angle = readableAngle(atan2((b.y - a.y).toDouble(), (b.x - a.x).toDouble())).toFloat()
        val x = (a.x + b.x) / 2f
        val y = (a.y + b.y) / 2f - 5f * unit
        val paint = paintText(RectF(), 6.4f * unit, bold = true).apply { textAlign = Paint.Align.CENTER }
        canvas.save()
        canvas.rotate(Math.toDegrees(angle.toDouble()).toFloat(), x, y)
        val width = paint.measureText(text) + 5f * unit
        canvas.drawRect(x - width / 2f, y - 6f * unit, x + width / 2f, y + 2.3f * unit, Paint().apply { color = Color.WHITE })
        canvas.drawText(text, x, y, paint)
        canvas.restore()
    }

    private fun drawObjects(canvas: Canvas, project: RoofProject, mapper: Mapper, unit: Float) {
        val outline = stroke(Color.rgb(20, 23, 25), 1.05f * unit)
        project.objects.forEach { item ->
            val center = mapper.screen(item.center)
            val physicalW = if (item.widthMm > 0) item.widthMm / 1000.0 * mapper.scale else 11.0 * unit
            val physicalH = if (item.heightMm > 0) item.heightMm / 1000.0 * mapper.scale else 11.0 * unit
            val w = max(8f * unit, physicalW.toFloat())
            val h = max(8f * unit, physicalH.toFloat())
            canvas.save()
            canvas.rotate((-item.rotationDeg).toFloat(), center.x, center.y)
            when (item.type) {
                ObjectType.CHIMNEY -> {
                    val rect = RectF(center.x - w / 2f, center.y - h / 2f, center.x + w / 2f, center.y + h / 2f)
                    canvas.drawRect(rect, outline)
                    val hatch = stroke(Color.rgb(90, 94, 96), 0.45f * unit)
                    canvas.drawLine(rect.left, rect.bottom, rect.right, rect.top, hatch)
                    canvas.drawLine(rect.left, rect.centerY(), rect.centerX(), rect.top, hatch)
                    canvas.drawLine(rect.centerX(), rect.bottom, rect.right, rect.centerY(), hatch)
                }
                ObjectType.ROOF_WINDOW, ObjectType.HATCH -> {
                    val rect = RectF(center.x - w / 2f, center.y - h / 2f, center.x + w / 2f, center.y + h / 2f)
                    canvas.drawRect(rect, outline)
                    canvas.drawLine(rect.left, rect.top, rect.right, rect.bottom, outline)
                    canvas.drawLine(rect.right, rect.top, rect.left, rect.bottom, outline)
                }
                ObjectType.VENT, ObjectType.DRAIN, ObjectType.DOWNSPOUT -> {
                    val radius = max(4f * unit, (item.diameterMm / 2000.0 * mapper.scale).toFloat())
                    canvas.drawCircle(center.x, center.y, radius, outline)
                    canvas.drawLine(center.x - radius * 1.5f, center.y, center.x + radius * 1.5f, center.y, outline)
                    canvas.drawLine(center.x, center.y - radius * 1.5f, center.x, center.y + radius * 1.5f, outline)
                }
                ObjectType.HEIGHT_MARK -> drawHeightMarker(canvas, center, item.value, unit)
                ObjectType.SLOPE_MARK -> drawSlopeArrow(canvas, center, item, unit)
            }
            canvas.restore()
        }
    }

    private fun drawHeightMarker(canvas: Canvas, center: PointF, value: Double, unit: Float) {
        val p = stroke(Color.BLACK, 0.75f * unit)
        val path = Path().apply {
            moveTo(center.x - 6f * unit, center.y)
            lineTo(center.x, center.y - 5f * unit)
            lineTo(center.x + 6f * unit, center.y)
        }
        canvas.drawPath(path, p)
        val text = String.format(java.util.Locale("sk", "SK"), "%+.3f", value).replace('.', ',')
        canvas.drawText(text, center.x + 9f * unit, center.y - 2f * unit, paintText(RectF(), 6.5f * unit))
    }

    private fun drawSlopeArrow(canvas: Canvas, center: PointF, item: RoofObject, unit: Float) {
        val length = 23f * unit
        val directionLength = hypot(item.directionX, item.directionY).coerceAtLeast(1e-6)
        val dx = (item.directionX / directionLength * length).toFloat()
        val dy = (-item.directionY / directionLength * length).toFloat()
        val a = PointF(center.x - dx / 2f, center.y - dy / 2f)
        val b = PointF(center.x + dx / 2f, center.y + dy / 2f)
        val paint = stroke(Color.BLACK, 0.85f * unit)
        canvas.drawLine(a.x, a.y, b.x, b.y, paint)
        drawArrowHead(canvas, b, PointF(dx, dy), 5f * unit, paint)
        val label = if (item.value != 0.0) String.format(java.util.Locale("sk", "SK"), "%.1f°", item.value) else "SKLON"
        canvas.drawText(label, center.x, center.y - 8f * unit, paintText(RectF(), 6.2f * unit).apply { textAlign = Paint.Align.CENTER })
    }

    private fun drawBoundaryDimensions(
        canvas: Canvas,
        project: RoofProject,
        mapper: Mapper,
        projection: Projection,
        unit: Float
    ) {
        val polygonCenter = PointF(
            project.polygon.map(mapper::screen).map { it.x }.average().toFloat(),
            project.polygon.map(mapper::screen).map { it.y }.average().toFloat()
        )
        projection.polygon.indices.forEach { index ->
            val next = (index + 1) % projection.polygon.size
            val a = mapper.screen(projection.polygon[index])
            val b = mapper.screen(projection.polygon[next])
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx.toDouble(), dy.toDouble()).toFloat()
            if (length < 18f * unit) return@forEach
            var nx = -dy / length
            var ny = dx / length
            val midX = (a.x + b.x) / 2f
            val midY = (a.y + b.y) / 2f
            if ((midX - polygonCenter.x) * nx + (midY - polygonCenter.y) * ny < 0f) {
                nx = -nx
                ny = -ny
            }
            val offset = 18f * unit
            val q1 = PointF(a.x + nx * offset, a.y + ny * offset)
            val q2 = PointF(b.x + nx * offset, b.y + ny * offset)
            val physical = hypot(
                projection.polygon[next].x - projection.polygon[index].x,
                projection.polygon[next].y - projection.polygon[index].y
            )
            drawDimension(canvas, a, b, q1, q2, formatMm(physical), unit)
        }
    }

    private fun drawOverallDimensions(canvas: Canvas, mapper: Mapper, projection: Projection, unit: Float) {
        val bottomLeft = mapper.screen(LocalPoint(projection.minX, projection.minY))
        val bottomRight = mapper.screen(LocalPoint(projection.maxX, projection.minY))
        val topLeft = mapper.screen(LocalPoint(projection.minX, projection.maxY))
        val xOffset = 39f * unit
        drawDimension(
            canvas, bottomLeft, bottomRight,
            PointF(bottomLeft.x, bottomLeft.y + xOffset),
            PointF(bottomRight.x, bottomRight.y + xOffset),
            formatMm(projection.maxX - projection.minX), unit, bold = true
        )
        val yOffset = 39f * unit
        drawDimension(
            canvas, bottomLeft, topLeft,
            PointF(bottomLeft.x - yOffset, bottomLeft.y),
            PointF(topLeft.x - yOffset, topLeft.y),
            formatMm(projection.maxY - projection.minY), unit, bold = true
        )
    }

    private fun drawDimension(
        canvas: Canvas,
        baseA: PointF,
        baseB: PointF,
        a: PointF,
        b: PointF,
        label: String,
        unit: Float,
        bold: Boolean = false
    ) {
        val helper = stroke(Color.rgb(86, 90, 92), 0.45f * unit)
        val dimension = stroke(Color.rgb(20, 23, 25), (if (bold) 0.72f else 0.55f) * unit)
        val dx = b.x - a.x
        val dy = b.y - a.y
        val length = hypot(dx.toDouble(), dy.toDouble()).toFloat().coerceAtLeast(1f)
        val nx = -dy / length
        val ny = dx / length
        canvas.drawLine(baseA.x, baseA.y, a.x + nx * 4f * unit, a.y + ny * 4f * unit, helper)
        canvas.drawLine(baseB.x, baseB.y, b.x + nx * 4f * unit, b.y + ny * 4f * unit, helper)
        canvas.drawLine(a.x, a.y, b.x, b.y, dimension)
        drawDimensionTick(canvas, a, PointF(dx, dy), 8f * unit, dimension)
        drawDimensionTick(canvas, b, PointF(dx, dy), 8f * unit, dimension)

        val angle = readableAngle(atan2(dy.toDouble(), dx.toDouble()))
        val centerX = (a.x + b.x) / 2f
        val centerY = (a.y + b.y) / 2f
        val text = paintText(RectF(), (if (bold) 7.0f else 6.3f) * unit, bold).apply { textAlign = Paint.Align.CENTER }
        canvas.save()
        canvas.rotate(Math.toDegrees(angle).toFloat(), centerX, centerY)
        val width = text.measureText(label) + 5f * unit
        canvas.drawRect(centerX - width / 2f, centerY - 7f * unit, centerX + width / 2f, centerY + 2f * unit, Paint().apply { color = Color.WHITE })
        canvas.drawText(label, centerX, centerY - 0.8f * unit, text)
        canvas.restore()
    }

    private fun drawDimensionTick(canvas: Canvas, point: PointF, direction: PointF, length: Float, paint: Paint) {
        val l = hypot(direction.x.toDouble(), direction.y.toDouble()).toFloat().coerceAtLeast(1f)
        val dx = direction.x / l
        val dy = direction.y / l
        val c = 0.70710678f
        val rx = dx * c - dy * c
        val ry = dx * c + dy * c
        canvas.drawLine(point.x - rx * length / 2f, point.y - ry * length / 2f, point.x + rx * length / 2f, point.y + ry * length / 2f, paint)
    }

    private fun drawArrowHead(canvas: Canvas, point: PointF, direction: PointF, size: Float, paint: Paint) {
        val l = hypot(direction.x.toDouble(), direction.y.toDouble()).toFloat().coerceAtLeast(1f)
        val ux = direction.x / l
        val uy = direction.y / l
        canvas.drawLine(point.x, point.y, point.x - ux * size - uy * size * 0.45f, point.y - uy * size + ux * size * 0.45f, paint)
        canvas.drawLine(point.x, point.y, point.x - ux * size + uy * size * 0.45f, point.y - uy * size - ux * size * 0.45f, paint)
    }

    private fun drawTitleBlock(canvas: Canvas, project: RoofProject, sheet: RectF, denominator: Float, unit: Float) {
        val width = min(sheet.width() * 0.48f, 255f * unit)
        val height = 43f * unit
        val box = RectF(sheet.right - width, sheet.bottom - height, sheet.right, sheet.bottom)
        val thin = stroke(Color.BLACK, 0.65f * unit)
        canvas.drawRect(box, thin)
        val splitX = box.right - 62f * unit
        val splitY = box.top + 21f * unit
        canvas.drawLine(splitX, box.top, splitX, box.bottom, thin)
        canvas.drawLine(box.left, splitY, box.right, splitY, thin)
        canvas.drawText(project.name, box.left + 6f * unit, box.top + 13f * unit, paintText(box, 7.1f * unit, bold = true))
        canvas.drawText("STRECHOSTAV SKETCH", box.left + 6f * unit, box.top + 34f * unit, paintText(box, 5.8f * unit))
        val right = paintText(box, 6.1f * unit, bold = true).apply { textAlign = Paint.Align.CENTER }
        canvas.drawText("M 1:${denominator.roundToInt()}", (splitX + box.right) / 2f, box.top + 13f * unit, right)
        canvas.drawText("STN", (splitX + box.right) / 2f, box.top + 34f * unit, right)
    }

    private fun drawSheetFrame(canvas: Canvas, sheet: RectF, unit: Float) {
        val outer = stroke(Color.rgb(20, 23, 25), 0.85f * unit)
        val inner = RectF(sheet).apply { inset(6f * unit, 6f * unit) }
        canvas.drawRect(sheet, outer)
        canvas.drawRect(inner, stroke(Color.rgb(45, 49, 51), 0.50f * unit))
    }

    private fun path(points: List<PointF>, close: Boolean): Path = Path().apply {
        if (points.isNotEmpty()) {
            moveTo(points.first().x, points.first().y)
            points.drop(1).forEach { lineTo(it.x, it.y) }
            if (close) close()
        }
    }

    private fun stroke(color: Int, width: Float): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        this.color = color
        strokeWidth = width
        strokeCap = Paint.Cap.BUTT
        strokeJoin = Paint.Join.MITER
    }

    private fun paintText(bounds: RectF, size: Float, bold: Boolean = false): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(17, 20, 22)
        textSize = size
        typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
        textAlign = Paint.Align.LEFT
    }

    private fun readableAngle(input: Double): Double {
        var angle = input
        while (angle <= -PI) angle += 2.0 * PI
        while (angle > PI) angle -= 2.0 * PI
        if (abs(abs(angle) - PI / 2.0) < 1e-6) return -PI / 2.0
        if (angle > PI / 2.0) angle -= PI
        if (angle < -PI / 2.0) angle += PI
        return angle
    }

    private fun formatMm(meters: Double): String =
        (meters * 1000.0).roundToInt().toString().reversed().chunked(3).joinToString(" ").reversed()
}
