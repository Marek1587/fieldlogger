package sk.strechasketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Correction used exclusively by card 2 (internal roof lines).
 *
 * The operation is deliberately topology preserving: it never creates an edge
 * or a node and never splits an edge.  It may only move an existing internal
 * node or merge two already existing, nearby endpoints.  Boundary geometry is
 * immutable.  This makes the preview deterministic and prevents a correction
 * intended for drawing cleanup from silently redesigning the roof graph.
 */
object ConservativeInternalLineSolver {
    private data class DesiredPoint(val x: Double, val y: Double, val reason: String)

    fun solve(
        input: RoofTopology,
        angleToleranceDeg: Double = 10.0,
        maximumLengthChangeFraction: Double = 0.10,
        snapToleranceM: Double = 0.35
    ): RoofSolverPreview {
        val original = input.copy(
            origin = input.origin.copy(),
            nodes = input.nodes.map { it.copy() },
            edges = input.edges.map { it.copy() }
        )
        val nodes = input.nodes.associateBy { it.id }.toMutableMap()
        val edges = input.edges.associateBy { it.id }.toMutableMap()
        val boundaryNodeIds = input.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val originalPositions = input.nodes.associate { it.id to (it.x to it.y) }
        val originalLengths = input.edges.associate { edge ->
            val a = input.nodes.first { it.id == edge.startNodeId }
            val b = input.nodes.first { it.id == edge.endNodeId }
            edge.id to hypot(b.x - a.x, b.y - a.y)
        }
        val movements = mutableListOf<NodeMovement>()
        var mergedNodes = 0
        val alignedHipValley = mutableSetOf<String>()
        val alignedRidge = mutableSetOf<String>()

        fun incidentInternal(nodeId: String): List<TopologyEdge> = edges.values.filter {
            !it.boundary && (it.startNodeId == nodeId || it.endNodeId == nodeId)
        }

        fun movementLimit(nodeId: String): Double {
            val shortest = incidentInternal(nodeId).mapNotNull { originalLengths[it.id] }
                .filter { it > 1e-9 }.minOrNull() ?: return 0.0
            // Rotation around an edge midpoint preserves length although both
            // nodes travel. The actual edge-length bound is enforced below.
            return shortest * maximumLengthChangeFraction
        }

        fun mergeNearbyExistingEndpoints() {
            var changed: Boolean
            do {
                changed = false
                val candidateIds = (edges.values.asSequence().filterNot { it.boundary }
                    .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
                    .toList() + boundaryNodeIds).distinct().sorted()
                pairLoop@ for (i in candidateIds.indices) {
                    for (j in i + 1 until candidateIds.size) {
                        val idA = candidateIds[i]
                        val idB = candidateIds[j]
                        val a = nodes[idA] ?: continue
                        val b = nodes[idB] ?: continue
                        if (idA in boundaryNodeIds && idB in boundaryNodeIds) continue
                        if (edges.values.any {
                                !it.boundary && setOf(it.startNodeId, it.endNodeId) == setOf(idA, idB)
                            }) continue
                        val distance = hypot(b.x - a.x, b.y - a.y)
                        val allowed = minOf(
                            snapToleranceM,
                            movementLimit(idA) + movementLimit(idB)
                        )
                        if (allowed <= 0.0 || distance > allowed + 1e-9) continue

                        val targetId = when {
                            idA in boundaryNodeIds -> idA
                            idB in boundaryNodeIds -> idB
                            a.locked -> idA
                            b.locked -> idB
                            else -> minOf(idA, idB)
                        }
                        val sourceId = if (targetId == idA) idB else idA
                        val target = nodes.getValue(targetId)
                        val source = nodes.getValue(sourceId)
                        val merged = if (targetId in boundaryNodeIds || target.locked) target else target.copy(
                            x = (target.x + source.x) / 2.0,
                            y = (target.y + source.y) / 2.0
                        )
                        nodes[targetId] = merged
                        edges.keys.toList().forEach { edgeId ->
                            val edge = edges.getValue(edgeId)
                            edges[edgeId] = edge.copy(
                                startNodeId = if (edge.startNodeId == sourceId) targetId else edge.startNodeId,
                                endNodeId = if (edge.endNodeId == sourceId) targetId else edge.endNodeId
                            )
                        }
                        nodes.remove(sourceId)
                        movements += NodeMovement(
                            sourceId, targetId, source.x, source.y, merged.x, merged.y,
                            "MERGE_EXISTING_INTERNAL_ENDPOINTS"
                        )
                        mergedNodes++
                        changed = true
                        break@pairLoop
                    }
                }
            } while (changed)
        }

        mergeNearbyExistingEndpoints()

        repeat(6) {
            val desired = mutableMapOf<String, MutableList<DesiredPoint>>()
            val boundaryDirections = edges.values.filter { it.boundary }.mapNotNull { edge ->
                val a = nodes[edge.startNodeId] ?: return@mapNotNull null
                val b = nodes[edge.endNodeId] ?: return@mapNotNull null
                if (hypot(b.x - a.x, b.y - a.y) < 1e-9) null
                else Triple(edge, atan2(b.y - a.y, b.x - a.x), edge.type == LineType.EAVE)
            }

            edges.values.sortedBy { it.id }.filterNot { it.boundary }.forEach { edge ->
                val a = nodes[edge.startNodeId] ?: return@forEach
                val b = nodes[edge.endNodeId] ?: return@forEach
                val length = hypot(b.x - a.x, b.y - a.y)
                if (length < 1e-9) return@forEach
                val raw = atan2(b.y - a.y, b.x - a.x)
                when (edge.type) {
                    LineType.RIDGE -> {
                        val target = boundaryDirections.minByOrNull { angularDistance(raw, it.second) }?.second
                            ?: return@forEach
                        if (Math.toDegrees(angularDistance(raw, target)) > angleToleranceDeg + 1e-9) return@forEach
                        var dx = cos(target)
                        var dy = sin(target)
                        if (dx * (b.x - a.x) + dy * (b.y - a.y) < 0.0) { dx = -dx; dy = -dy }
                        val midX = (a.x + b.x) / 2.0
                        val midY = (a.y + b.y) / 2.0
                        if (a.id !in boundaryNodeIds && !a.locked) desired.getOrPut(a.id) { mutableListOf() } +=
                            DesiredPoint(midX - dx * length / 2.0, midY - dy * length / 2.0, "RIDGE_PARALLEL_TO_BOUNDARY")
                        if (b.id !in boundaryNodeIds && !b.locked) desired.getOrPut(b.id) { mutableListOf() } +=
                            DesiredPoint(midX + dx * length / 2.0, midY + dy * length / 2.0, "RIDGE_PARALLEL_TO_BOUNDARY")
                        alignedRidge += edge.id
                    }

                    LineType.HIP, LineType.VALLEY -> {
                        val anchor: TopologyNode
                        val mobile: TopologyNode
                        if (a.id in boundaryNodeIds && b.id !in boundaryNodeIds) {
                            anchor = a; mobile = b
                        } else if (b.id in boundaryNodeIds && a.id !in boundaryNodeIds) {
                            anchor = b; mobile = a
                        } else return@forEach
                        if (mobile.locked) return@forEach
                        val supports = boundaryDirections.filter { (support, _, _) ->
                            support.startNodeId == anchor.id || support.endNodeId == anchor.id
                        }.let { incident ->
                            val eaves = incident.filter { it.third }
                            if (eaves.isNotEmpty()) eaves else incident
                        }
                        val candidates = supports.flatMap { (_, direction, _) ->
                            listOf(direction + PI / 4.0, direction - PI / 4.0)
                        }
                        val mobileRaw = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
                        val target = candidates.minByOrNull { angularDistance(mobileRaw, it) } ?: return@forEach
                        if (Math.toDegrees(angularDistance(mobileRaw, target)) > angleToleranceDeg + 1e-9) return@forEach
                        var dx = cos(target)
                        var dy = sin(target)
                        if (dx * (mobile.x - anchor.x) + dy * (mobile.y - anchor.y) < 0.0) { dx = -dx; dy = -dy }
                        desired.getOrPut(mobile.id) { mutableListOf() } += DesiredPoint(
                            anchor.x + dx * length,
                            anchor.y + dy * length,
                            "${edge.type.name}_45_DEGREES_TO_BOUNDARY"
                        )
                        alignedHipValley += edge.id
                    }

                    else -> Unit
                }
            }

            var movedAny = false
            desired.toSortedMap().forEach { (nodeId, targets) ->
                val node = nodes[nodeId] ?: return@forEach
                if (nodeId in boundaryNodeIds || node.locked || targets.isEmpty()) return@forEach
                val wantedX = targets.map { it.x }.average()
                val wantedY = targets.map { it.y }.average()
                val dx = wantedX - node.x
                val dy = wantedY - node.y
                val distance = hypot(dx, dy)
                val original = originalPositions[nodeId] ?: (node.x to node.y)
                val maxFromOriginal = movementLimit(nodeId)
                if (distance < 1e-8 || maxFromOriginal <= 0.0) return@forEach
                var nextX = wantedX
                var nextY = wantedY
                val fromOriginalX = nextX - original.first
                val fromOriginalY = nextY - original.second
                val fromOriginalDistance = hypot(fromOriginalX, fromOriginalY)
                if (fromOriginalDistance > maxFromOriginal) {
                    nextX = original.first + fromOriginalX / fromOriginalDistance * maxFromOriginal
                    nextY = original.second + fromOriginalY / fromOriginalDistance * maxFromOriginal
                }
                if (hypot(nextX - node.x, nextY - node.y) > 1e-8) {
                    nodes[nodeId] = node.copy(x = nextX, y = nextY)
                    movedAny = true
                }
            }
            if (!movedAny) return@repeat
        }

        mergeNearbyExistingEndpoints()

        // Enforce the contractual ±10% edge-length envelope after all shared
        // junction compromises. No topology or IDs are changed here.
        repeat(4) {
            edges.values.sortedBy { it.id }.filterNot { it.boundary }.forEach { edge ->
                val originalLength = originalLengths[edge.id]?.takeIf { it > 1e-9 } ?: return@forEach
                val a = nodes[edge.startNodeId] ?: return@forEach
                val b = nodes[edge.endNodeId] ?: return@forEach
                val currentLength = hypot(b.x - a.x, b.y - a.y)
                if (currentLength < 1e-9) return@forEach
                val boundedLength = currentLength.coerceIn(
                    originalLength * (1.0 - maximumLengthChangeFraction),
                    originalLength * (1.0 + maximumLengthChangeFraction)
                )
                if (abs(currentLength - boundedLength) < 1e-9) return@forEach
                val ux = (b.x - a.x) / currentLength
                val uy = (b.y - a.y) / currentLength
                val aFixed = a.id in boundaryNodeIds || a.locked
                val bFixed = b.id in boundaryNodeIds || b.locked
                when {
                    aFixed && !bFixed -> nodes[b.id] = b.copy(x = a.x + ux * boundedLength, y = a.y + uy * boundedLength)
                    bFixed && !aFixed -> nodes[a.id] = a.copy(x = b.x - ux * boundedLength, y = b.y - uy * boundedLength)
                    !aFixed && !bFixed -> {
                        val midX = (a.x + b.x) / 2.0
                        val midY = (a.y + b.y) / 2.0
                        nodes[a.id] = a.copy(x = midX - ux * boundedLength / 2.0, y = midY - uy * boundedLength / 2.0)
                        nodes[b.id] = b.copy(x = midX + ux * boundedLength / 2.0, y = midY + uy * boundedLength / 2.0)
                    }
                }
            }
        }

        val normalizedNodes = nodes.values.sortedBy { it.id }.map { node ->
            val degree = edges.values.count { it.startNodeId == node.id || it.endNodeId == node.id }
            when {
                node.id in boundaryNodeIds -> node.copy(type = TopologyNodeType.FOOTPRINT)
                degree > 1 -> node.copy(type = TopologyNodeType.JUNCTION)
                else -> node.copy(type = TopologyNodeType.LINE_ENDPOINT)
            }
        }
        normalizedNodes.forEach { finalNode ->
            val originalNode = input.nodes.firstOrNull { it.id == finalNode.id } ?: return@forEach
            if (hypot(finalNode.x - originalNode.x, finalNode.y - originalNode.y) > 1e-8) {
                movements += NodeMovement(
                    finalNode.id, finalNode.id,
                    originalNode.x, originalNode.y, finalNode.x, finalNode.y,
                    "LIMITED_INTERNAL_GEOMETRY_CORRECTION"
                )
            }
        }
        val proposed = input.copy(
            nodes = normalizedNodes,
            edges = input.edges.mapNotNull { edges[it.id] }
        )
        return RoofSolverPreview(
            original = original,
            proposed = proposed,
            statistics = RoofSolverStatistics(
                mergedNodes = mergedNodes,
                createdIntersections = 0,
                splitEdges = 0,
                snappedFreeEnds = mergedNodes,
                removedShortEdges = 0,
                removedDuplicateEdges = 0,
                regularizedBoundaryNodes = 0,
                alignedHipValleyNodes = alignedHipValley.size,
                alignedRidgeNodes = alignedRidge.size
            ),
            movements = movements.distinctBy { listOf(it.sourceNodeId, it.targetNodeId, it.toX, it.toY, it.reason) },
            issues = RoofTopologySolver.validate(proposed),
            faces = RoofTopologySolver.extractFaces(proposed)
        )
    }

    private fun angularDistance(a: Double, b: Double): Double {
        var delta = abs(a - b) % PI
        if (delta > PI / 2.0) delta = PI - delta
        return abs(delta)
    }
}
