package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject

/** Adapter for roof-solver canonical JSON. Internal coordinates are always metres. */
object CanonicalRoofJson {
    fun decode(value: JSONObject, origin: GeoPoint = GeoPoint(49.0663, 18.9236)): RoofGraph {
        val units = value.optJSONObject("coordinateSystem")?.optString("units", "mm") ?: "mm"
        val scale = when (units.lowercase()) {
            "mm" -> 0.001
            "cm" -> 0.01
            "m" -> 1.0
            else -> error("Nepodporovaná jednotka kanonického modelu: $units")
        }
        val lockedHeights = linkedMapOf<String, Double>()
        value.optJSONArray("constraints")?.forEachObject { constraint ->
            if (constraint.optString("type") == "HeightConstraint" && constraint.optString("priority").startsWith("hard")) {
                lockedHeights[constraint.getString("nodeId")] = constraint.getDouble("value") * scale
            }
        }
        val nodes = linkedMapOf<String, GraphNode>()
        value.getJSONArray("nodes").forEachObject { item ->
            val id = item.getString("id")
            val p = item.getJSONObject("position")
            val locks = item.optJSONObject("locks")
            nodes[id] = GraphNode(
                id, p.getDouble("x") * scale, p.getDouble("y") * scale,
                lockedHeights[id] ?: p.optDouble("z", 0.0) * scale,
                locks?.optBoolean("x") ?: false, locks?.optBoolean("y") ?: false,
                (locks?.optBoolean("z") ?: false) || id in lockedHeights
            )
        }
        val facesJson = value.getJSONArray("faces")
        val faceIds = mutableSetOf<String>()
        facesJson.forEachObject { faceIds += it.getString("id") }
        val edges = linkedMapOf<String, GraphEdge>()
        value.getJSONArray("edges").forEachObject { item ->
            val id = item.getString("id")
            val ends = item.getJSONArray("nodes")
            val role = role(item.optString("role"))
            val start = ends.getString(0); val end = ends.getString(1)
            val elevation = if (role == EdgeSemantic.ELEVATED_LOW_EDGE) {
                listOfNotNull(nodes[start]?.z, nodes[end]?.z).average()
            } else null
            edges[id] = GraphEdge(
                id, start, end, item.optBoolean("boundary"), role,
                strings(item.optJSONArray("faces")).filter { it in faceIds }.toSet(),
                note = item.optString("role"), elevationZ = elevation
            )
        }
        val constraintsByFace = mutableMapOf<String, FaceSlopeConstraint>()
        value.optJSONArray("constraints")?.forEachObject { constraint ->
            if (constraint.optString("type") == "SlopeConstraint") {
                val direction = constraint.optJSONArray("downhillDirectionXY") ?: JSONArray().put(0.0).put(1.0)
                constraintsByFace[constraint.getString("faceId")] = FaceSlopeConstraint(
                    constraint.getDouble("valueDeg"), direction.getDouble(0), direction.getDouble(1),
                    constraint.optString("priority").startsWith("hard")
                )
            }
        }
        val faces = linkedMapOf<String, GraphFace>()
        facesJson.forEachObject { item ->
            val id = item.getString("id")
            val loop = strings(item.getJSONArray("outerLoop"))
            val edgeLoop = loop.indices.mapNotNull { index ->
                val a = loop[index]; val b = loop[(index + 1) % loop.size]
                edges.values.firstOrNull {
                    (it.startNodeId == a && it.endNodeId == b) || (it.startNodeId == b && it.endNodeId == a)
                }?.id
            }
            require(edgeLoop.size == loop.size) { "Plocha $id nemá úplný hranový okruh." }
            val holes = mutableListOf<List<String>>()
            item.optJSONArray("holes")?.let { array -> repeat(array.length()) { holes += strings(array.getJSONArray(it)) } }
            val planeJson = item.optJSONObject("plane")
            val plane = planeJson?.let { RoofPlane(it.getDouble("a"), it.getDouble("b"), it.getDouble("c") * scale) }
            val area = signedArea(loop.map { nodes.getValue(it) })
            faces[id] = GraphFace(
                id, loop, edgeLoop, area, plane, constraintsByFace[id], underconstrained = false,
                holeNodeIdLoops = holes, componentId = "main"
            )
        }
        val edgeLengths = linkedMapOf<String, EdgeLengthConstraint>()
        value.optJSONArray("constraints")?.forEachObject { constraint ->
            if (constraint.optString("type") == "EdgeLengthConstraint") {
                val edgeId = constraint.getString("edgeId")
                val edge = edges.getValue(edgeId)
                val id = constraint.getString("id")
                edgeLengths[id] = EdgeLengthConstraint(
                    id, edgeId, constraint.getDouble("value") * scale * 1000.0,
                    edge.startNodeId, constraint.optString("priority").startsWith("hard")
                )
            }
        }
        return RoofGraph(
            origin, nodes, edges, faces, schemaVersion = 2, edgeLengthConstraints = edgeLengths,
            components = mapOf("main" to RoofComponent("main", "Hlavná strecha", faceIds = faces.keys))
        )
    }

    private fun role(value: String): EdgeSemantic = when (value.lowercase()) {
        "eave" -> EdgeSemantic.EAVE
        "rake" -> EdgeSemantic.RAKE
        "ridge" -> EdgeSemantic.RIDGE
        "hip" -> EdgeSemantic.HIP
        "valley" -> EdgeSemantic.VALLEY
        "half-hip-low-edge", "elevated-low-edge" -> EdgeSemantic.ELEVATED_LOW_EDGE
        "low-edge" -> EdgeSemantic.LOW_EDGE
        "step" -> EdgeSemantic.STEP
        "opening-boundary" -> EdgeSemantic.OPENING_BOUNDARY
        else -> EdgeSemantic.UNKNOWN
    }

    private fun signedArea(nodes: List<GraphNode>): Double = nodes.indices.sumOf { index ->
        val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    private fun strings(array: JSONArray?): List<String> = buildList {
        if (array != null) repeat(array.length()) { add(array.getString(it)) }
    }

    private inline fun JSONArray.forEachObject(block: (JSONObject) -> Unit) {
        repeat(length()) { block(getJSONObject(it)) }
    }
}
