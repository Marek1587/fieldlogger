package sk.strechasketch.app

import android.content.Context
import org.json.JSONArray

class ProjectStore(context: Context) {
    private val preferences = context.getSharedPreferences("strechasketch_projects", Context.MODE_PRIVATE)

    fun list(): MutableList<RoofProject> {
        val source = preferences.getString(KEY_PROJECTS, "[]") ?: "[]"
        return try {
            val array = JSONArray(source)
            MutableList(array.length()) { index ->
                ProjectJson.decode(array.getString(index))
            }.sortedByDescending { it.updatedAt }.toMutableList()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun save(project: RoofProject) {
        project.updatedAt = System.currentTimeMillis()
        val projects = list()
        val index = projects.indexOfFirst { it.id == project.id }
        if (index >= 0) projects[index] = project else projects.add(0, project)
        write(projects)
        preferences.edit().putString(KEY_LAST_PROJECT, project.id).apply()
    }

    fun delete(projectId: String) {
        write(list().filterNot { it.id == projectId })
    }

    fun duplicate(source: RoofProject): RoofProject {
        val copy = ProjectJson.decode(ProjectJson.encode(source)).copy(
            id = java.util.UUID.randomUUID().toString(),
            name = "${source.name} – kópia",
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis()
        )
        save(copy)
        return copy
    }

    fun lastOrFirst(): RoofProject? {
        val projects = list()
        val last = preferences.getString(KEY_LAST_PROJECT, null)
        return projects.firstOrNull { it.id == last } ?: projects.firstOrNull()
    }

    private fun write(projects: List<RoofProject>) {
        val array = JSONArray()
        projects.forEach { array.put(ProjectJson.encode(it)) }
        preferences.edit().putString(KEY_PROJECTS, array.toString()).apply()
    }

    companion object {
        private const val KEY_PROJECTS = "projects"
        private const val KEY_LAST_PROJECT = "last_project"
    }
}
