package sk.strechasketch.app

/** Pure boundary edits shared by the touch editor and JVM tests. */
object BoundaryEdgeOperations {
    data class SplitResult(
        val polygon: MutableList<GeoPoint>,
        val edgeTypes: MutableMap<Int, LineType>,
        val insertedVertexIndex: Int
    )

    data class RemoveResult(
        val polygon: MutableList<GeoPoint>,
        val edgeTypes: MutableMap<Int, LineType>
    )

    fun splitAtMidpoint(
        polygon: List<GeoPoint>,
        edgeTypes: Map<Int, LineType>,
        edgeIndex: Int
    ): SplitResult? {
        if (polygon.size < 3 || edgeIndex !in polygon.indices) return null

        val start = polygon[edgeIndex]
        val end = polygon[(edgeIndex + 1) % polygon.size]
        val endLocal = Geometry.toLocal(end, start)
        if (kotlin.math.hypot(endLocal.x, endLocal.y) < 0.001) return null

        val midpoint = Geometry.toGeo(LocalPoint(endLocal.x / 2.0, endLocal.y / 2.0), start)
        val insertedIndex = edgeIndex + 1
        val updatedPolygon = polygon.map(GeoPoint::copy).toMutableList().apply {
            add(insertedIndex, midpoint)
        }

        val updatedTypes = mutableMapOf<Int, LineType>()
        edgeTypes.forEach { (oldIndex, type) ->
            if (oldIndex in polygon.indices) {
                updatedTypes[if (oldIndex <= edgeIndex) oldIndex else oldIndex + 1] = type
            }
        }
        val splitType = edgeTypes[edgeIndex] ?: LineType.EAVE
        updatedTypes[edgeIndex] = splitType
        updatedTypes[insertedIndex] = splitType

        return SplitResult(updatedPolygon, updatedTypes, insertedIndex)
    }

    /** Removes one vertex while preserving every unaffected boundary-edge type. */
    fun removeVertex(
        polygon: List<GeoPoint>,
        edgeTypes: Map<Int, LineType>,
        vertexIndex: Int
    ): RemoveResult? {
        if (polygon.size <= 3 || vertexIndex !in polygon.indices) return null
        val oldIndices = polygon.indices.filter { it != vertexIndex }
        val updatedPolygon = oldIndices.map { polygon[it].copy() }.toMutableList()
        val updatedTypes = mutableMapOf<Int, LineType>()
        updatedPolygon.indices.forEach { newEdgeIndex ->
            val oldStart = oldIndices[newEdgeIndex]
            val oldEnd = oldIndices[(newEdgeIndex + 1) % oldIndices.size]
            val oldSuccessor = (oldStart + 1) % polygon.size
            val sourceEdge = if (oldSuccessor == oldEnd) {
                oldStart
            } else {
                // The new edge bridges across the removed point. Prefer the edge
                // entering that point; this keeps a deliberately assigned type.
                oldStart
            }
            updatedTypes[newEdgeIndex] = edgeTypes[sourceEdge] ?: LineType.EAVE
        }
        return RemoveResult(updatedPolygon, updatedTypes)
    }
}
