package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

enum class RoofTopologyEventType {
    RIDGE_COLLAPSE_TO_APEX,
    EDGE_COLLAPSE,
    FACE_COLLAPSE,
    HALF_HIP_REACHES_RIDGE,
    OPENING_COLLAPSE
}

data class RoofTopologyEvent(
    val type: RoofTopologyEventType,
    val message: String,
    val edgeIds: Set<String> = emptySet(),
    val faceIds: Set<String> = emptySet(),
    val requiresExplicitRetopology: Boolean = true
)

/** Detects events that must never be hidden by parameter clamping. */
object RoofTopologyEventDetector {
    fun detect(graph: RoofGraph, minimumEdgeLengthM: Double = 0.01, minimumFaceAreaM2: Double = 0.01): List<RoofTopologyEvent> = buildList {
        graph.edges.values.sortedBy { it.id }.forEach { edge ->
            val a = graph.nodes[edge.startNodeId] ?: return@forEach
            val b = graph.nodes[edge.endNodeId] ?: return@forEach
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= minimumEdgeLengthM) add(RoofTopologyEvent(
                if (edge.semanticRole == EdgeSemantic.RIDGE) RoofTopologyEventType.RIDGE_COLLAPSE_TO_APEX else RoofTopologyEventType.EDGE_COLLAPSE,
                if (edge.semanticRole == EdgeSemantic.RIDGE) "Hrebeň zaniká a musí sa explicitne zmeniť na vrchol." else "Hrana ${edge.id} zaniká.",
                edgeIds = setOf(edge.id)
            ))
        }
        graph.faces.values.sortedBy { it.id }.filter { abs(it.signedAreaM2) <= minimumFaceAreaM2 }.forEach { face ->
            add(RoofTopologyEvent(RoofTopologyEventType.FACE_COLLAPSE, "Plocha ${face.id} zaniká.", faceIds = setOf(face.id)))
        }
        graph.edges.values.filter { it.semanticRole == EdgeSemantic.ELEVATED_LOW_EDGE }.forEach { low ->
            val adjacent = low.adjacentFaceIds.flatMap { graph.faces[it]?.orderedEdgeIds.orEmpty() }
                .mapNotNull(graph.edges::get).filter { it.semanticRole == EdgeSemantic.RIDGE }
            if (adjacent.any { ridge ->
                    val a = graph.nodes[ridge.startNodeId] ?: return@any false
                    val b = graph.nodes[ridge.endNodeId] ?: return@any false
                    hypot(b.x - a.x, b.y - a.y) <= minimumEdgeLengthM
                }) add(RoofTopologyEvent(
                RoofTopologyEventType.HALF_HIP_REACHES_RIDGE,
                "Polvalbový rez dosiahol koniec dostupného hrebeňa.",
                edgeIds = setOf(low.id) + adjacent.map { it.id }
            ))
        }
        graph.faces.values.filter { it.holeNodeIdLoops.any { loop -> loop.size < 3 } }.forEach { face ->
            add(RoofTopologyEvent(RoofTopologyEventType.OPENING_COLLAPSE, "Otvor v ploche ${face.id} zaniká.", faceIds = setOf(face.id)))
        }
    }
}
