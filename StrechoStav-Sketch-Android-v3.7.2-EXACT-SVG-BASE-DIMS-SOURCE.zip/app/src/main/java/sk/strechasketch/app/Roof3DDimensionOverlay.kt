package sk.strechasketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.hypot

/** Clickable screen-space dimensions projected from the current OpenGL camera. */
class Roof3DDimensionOverlay(context: Context) : View(context) {
    var source: Roof3DView? = null
    internal var onDimensionClick: ((ProjectedRoofDimension) -> Unit)? = null
    private val hitBoxes = linkedMapOf<String, Pair<ProjectedRoofDimension, RectF>>()
    private var pressedDimensionId: String? = null
    private val density = resources.displayMetrics.density.coerceAtLeast(1f)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(31, 108, 52)
        strokeWidth = 1.5f * density
        style = Paint.Style.STROKE
    }
    private val witnessPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 84, 91, 87)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 58, 37)
        textSize = 12f * density
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private val labelBackground = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(238, 255, 253, 246)
        style = Paint.Style.FILL
    }
    private val labelBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 122, 53)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }

    init {
        isClickable = true
        contentDescription = "Klikateľné parametrické kóty trojrozmerného modelu"
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hitBoxes.clear()
        val occupied = mutableListOf<RectF>()
        val occupiedLines = mutableListOf<Pair<android.graphics.PointF, android.graphics.PointF>>()
        fun lineIntersectsRect(a: android.graphics.PointF, b: android.graphics.PointF, box: RectF): Boolean {
            if (box.contains(a.x, a.y) || box.contains(b.x, b.y)) return true
            fun intersects(
                p1: android.graphics.PointF, p2: android.graphics.PointF,
                p3: android.graphics.PointF, p4: android.graphics.PointF
            ): Boolean {
                fun cross(u: android.graphics.PointF, v: android.graphics.PointF, w: android.graphics.PointF) =
                    (v.x - u.x) * (w.y - u.y) - (v.y - u.y) * (w.x - u.x)
                val c1 = cross(p1, p2, p3)
                val c2 = cross(p1, p2, p4)
                val c3 = cross(p3, p4, p1)
                val c4 = cross(p3, p4, p2)
                if (c1 * c2 > 0f || c3 * c4 > 0f) return false
                val epsilon = 0.5f
                return maxOf(minOf(p1.x, p2.x), minOf(p3.x, p4.x)) <=
                    minOf(maxOf(p1.x, p2.x), maxOf(p3.x, p4.x)) + epsilon &&
                    maxOf(minOf(p1.y, p2.y), minOf(p3.y, p4.y)) <=
                    minOf(maxOf(p1.y, p2.y), maxOf(p3.y, p4.y)) + epsilon
            }
            val tl = android.graphics.PointF(box.left, box.top)
            val tr = android.graphics.PointF(box.right, box.top)
            val br = android.graphics.PointF(box.right, box.bottom)
            val bl = android.graphics.PointF(box.left, box.bottom)
            return intersects(a, b, tl, tr) || intersects(a, b, tr, br) ||
                intersects(a, b, br, bl) || intersects(a, b, bl, tl)
        }
        source?.projectedDimensions()
            ?.sortedWith(compareBy<ProjectedRoofDimension> {
                when (it.kind) {
                    RoofDimensionKind.WALL_HEIGHT -> 0
                    RoofDimensionKind.ATTIC_HEIGHT -> 1
                    RoofDimensionKind.SLOPE -> 2
                    RoofDimensionKind.OVERHANG -> 3
                    RoofDimensionKind.PLAN_LENGTH -> 4
                }
            }.thenByDescending {
                hypot(it.witnessEnd.x - it.witnessStart.x, it.witnessEnd.y - it.witnessStart.y)
            })
            ?.forEach { dimension ->
            val witnessA = dimension.witnessStart
            val witnessB = dimension.witnessEnd
            val edgeDx = witnessB.x - witnessA.x
            val edgeDy = witnessB.y - witnessA.y
            val edgeLength = hypot(edgeDx, edgeDy).coerceAtLeast(1f)
            var nx = -edgeDy / edgeLength
            var ny = edgeDx / edgeLength
            val witnessMidX = (witnessA.x + witnessB.x) / 2f
            val witnessMidY = (witnessA.y + witnessB.y) / 2f
            if (nx * (witnessMidX - dimension.modelCenter.x) + ny * (witnessMidY - dimension.modelCenter.y) < 0f) {
                nx = -nx; ny = -ny
            }
            val text = when (dimension.kind) {
                RoofDimensionKind.PLAN_LENGTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.WALL_HEIGHT -> String.format(Locale("sk", "SK"), "H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_HEIGHT -> String.format(Locale("sk", "SK"), "Atika  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.OVERHANG -> String.format(Locale("sk", "SK"), "Presah  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SLOPE -> String.format(Locale("sk", "SK"), "\u2220  %.1f\u00B0", dimension.lengthM)
            }
            val paddingX = 8f * density
            val halfWidth = labelPaint.measureText(text) / 2f + paddingX
            val halfHeight = 14f * density
            var chosen: Triple<android.graphics.PointF, android.graphics.PointF, RectF>? = null
            for (level in 0..5) {
                val offset = (24f + level * 30f) * density
                val a = android.graphics.PointF(witnessA.x + nx * offset, witnessA.y + ny * offset)
                val b = android.graphics.PointF(witnessB.x + nx * offset, witnessB.y + ny * offset)
                val centerX = (a.x + b.x) / 2f
                val centerY = (a.y + b.y) / 2f
                val box = RectF(centerX - halfWidth, centerY - halfHeight, centerX + halfWidth, centerY + halfHeight)
                val inside = box.left >= 3f * density && box.right <= width - 3f * density &&
                    box.top >= 3f * density && box.bottom <= height - 3f * density
                val crossesLabel = occupied.any { existing ->
                    lineIntersectsRect(a, b, existing) || RectF.intersects(existing, box)
                }
                val coversLine = occupiedLines.any { (lineA, lineB) -> lineIntersectsRect(lineA, lineB, box) }
                if (inside && !crossesLabel && !coversLine) {
                    chosen = Triple(a, b, box)
                    break
                }
            }
            val (a, b, box) = chosen ?: return@forEach
            if ((a.x < -100f && b.x < -100f) || (a.x > width + 100f && b.x > width + 100f) ||
                (a.y < -100f && b.y < -100f) || (a.y > height + 100f && b.y > height + 100f)
            ) return@forEach
            canvas.drawLine(witnessA.x, witnessA.y, a.x, a.y, witnessPaint)
            canvas.drawLine(witnessB.x, witnessB.y, b.x, b.y, witnessPaint)
            canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1f)
            val tickNx = -dy / length
            val tickNy = dx / length
            val tick = 5f * density
            canvas.drawLine(a.x - tickNx * tick, a.y - tickNy * tick, a.x + tickNx * tick, a.y + tickNy * tick, linePaint)
            canvas.drawLine(b.x - tickNx * tick, b.y - tickNy * tick, b.x + tickNx * tick, b.y + tickNy * tick, linePaint)

            val centerX = (a.x + b.x) / 2f
            val centerY = (a.y + b.y) / 2f
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBackground)
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBorder)
            val baseline = centerY - (labelPaint.ascent() + labelPaint.descent()) / 2f
            canvas.drawText(text, centerX, baseline, labelPaint)
            val hit = RectF(box).apply { inset(-5f * density, -5f * density) }
            hitBoxes[dimension.dimensionId] = dimension to hit
            occupied += RectF(hit)
            occupiedLines += a to b
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedDimensionId = hitBoxes.entries.lastOrNull { it.value.second.contains(event.x, event.y) }?.key
                return pressedDimensionId != null
            }
            MotionEvent.ACTION_UP -> {
                val dimensionId = pressedDimensionId
                pressedDimensionId = null
                val hit = dimensionId?.let(hitBoxes::get)
                if (hit != null && hit.second.contains(event.x, event.y)) {
                    performClick()
                    onDimensionClick?.invoke(hit.first)
                    return true
                }
            }
            MotionEvent.ACTION_CANCEL -> pressedDimensionId = null
        }
        return pressedDimensionId != null
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
