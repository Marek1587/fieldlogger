package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.tan

data class RoofPlaneSolverIssue(
    val code: String,
    val message: String,
    val faceId: String? = null,
    val residualM: Double = 0.0,
    val blocking: Boolean = false
)

data class RoofPlaneSolution(
    val graph: RoofGraph,
    val issues: List<RoofPlaneSolverIssue>,
    val maximumCoplanarityResidualM: Double
) {
    val hasBlockingIssues: Boolean get() = issues.any { it.blocking }
}

/**
 * Deterministic, preset-free Z solver.
 *
 * XY and incidence are immutable.  Face/node incidence, locked elevations,
 * explicit point elevations, drains and low supports are assembled as exact
 * linear equalities.  The reduced system is solved by deterministic RREF;
 * incompatible hard constraints are reported and never approximated by large
 * soft weights.  Free variables stay at the transaction-start value.
 */
object RoofPlaneSolver {
    private val wallLowRoles = setOf(
        EdgeSemantic.EAVE, EdgeSemantic.PULT,
        EdgeSemantic.WALL_END, EdgeSemantic.LOW_EDGE
    )
    private val allLowRoles = wallLowRoles + EdgeSemantic.ELEVATED_LOW_EDGE
    private const val equationTolerance = 1e-10
    private const val residualToleranceM = 1e-6 // 0.001 mm

    private data class Gradient(val a: Double, val b: Double, val underconstrained: Boolean)
    private data class Equation(
        val coefficients: Map<Int, Double>,
        val rhs: Double,
        val weight: Double = 1.0
    )
    private data class ExactResult(val values: DoubleArray?, val inconsistent: Boolean)

    @Suppress("UNUSED_PARAMETER")
    fun solve(
        input: RoofGraph,
        wallHeightM: Double,
        defaultSlopeDeg: Double,
        iterations: Int = 120,
        allowApproximation: Boolean = false,
        flatRoofMode: Boolean = false
    ): RoofPlaneSolution {
        if (input.faces.isEmpty()) return RoofPlaneSolution(
            input,
            listOf(RoofPlaneSolverIssue("NO_FACES", "Topologická sieť neobsahuje uzavretú strešnú plochu.", blocking = true)),
            0.0
        )

        val facesWithHoles = input.faces.values.filter { it.holeNodeIdLoops.isNotEmpty() }
        if (facesWithHoles.isNotEmpty()) return RoofPlaneSolution(
            input,
            facesWithHoles.map { face ->
                RoofPlaneSolverIssue(
                    "FACE_HOLE_REQUIRES_SUBDIVISION",
                    "Otvor v ploche ${face.id} musí byť pred výpočtom rozdelený na neprekrývajúce sa strešné plochy. Neúplný 3D model sa nevytvoril.",
                    face.id,
                    blocking = true
                )
            },
            0.0
        )

        val issues = mutableListOf<RoofPlaneSolverIssue>()
        val wallHeight = wallHeightM.coerceIn(0.5, 100.0)
        val resolvedFlatRoofMode = flatRoofMode || (
            input.faces.size == 1 && input.edges.values.any {
                it.boundary && it.semanticRole == EdgeSemantic.ATTIC
            }
        )
        val flatBoundarySupportId = if (resolvedFlatRoofMode) {
            input.edges.values.filter { edge ->
                edge.boundary && edge.semanticRole in allLowRoles
            }.maxByOrNull { edge ->
                val a = input.nodes[edge.startNodeId] ?: return@maxByOrNull 0.0
                val b = input.nodes[edge.endNodeId] ?: return@maxByOrNull 0.0
                hypot(b.x - a.x, b.y - a.y)
            }?.id
        } else null
        val nodeIds = input.nodes.keys.sorted()
        val faceIds = input.faces.keys.sorted()
        val nodeIndex = nodeIds.withIndex().associate { it.value to it.index }
        val faceIndex = faceIds.withIndex().associate { it.value to nodeIds.size + it.index }

        val gradients = faceIds.associateWith { faceId ->
            val face = input.faces.getValue(faceId)
            val explicit = face.slopeConstraint
            if (explicit != null) {
                val length = hypot(explicit.directionX, explicit.directionY)
                if (length < 1e-12) {
                    issues += RoofPlaneSolverIssue(
                        "INVALID_SLOPE_DIRECTION", "Smer spádu plochy má nulovú dĺžku.", faceId, blocking = explicit.hard
                    )
                    Gradient(0.0, 0.0, true)
                } else {
                    val magnitude = tan(Math.toRadians(explicit.angleDeg.coerceIn(0.0, 75.0)))
                    // Constraint stores DOWNHILL. The gradient of z points uphill.
                    Gradient(-magnitude * explicit.directionX / length, -magnitude * explicit.directionY / length, false)
                }
            } else inferGradient(input, face, defaultSlopeDeg, resolvedFlatRoofMode, issues)
        }

        if (issues.any { it.blocking }) return RoofPlaneSolution(input, issues, 0.0)

        val equations = mutableListOf<Equation>()
        faceIds.forEach { faceId ->
            val face = input.faces.getValue(faceId)
            val gradient = gradients.getValue(faceId)
            face.orderedNodeIds.forEach { nodeId ->
                val node = input.nodes[nodeId] ?: return@forEach
                equations += Equation(
                    mapOf(nodeIndex.getValue(nodeId) to 1.0, faceIndex.getValue(faceId) to -1.0),
                    gradient.a * node.x + gradient.b * node.y
                )
            }
        }

        val hardNodeElevations = linkedMapOf<String, MutableList<Double>>()
        input.nodes.values.filter { it.lockZ }.forEach { hardNodeElevations.getOrPut(it.id) { mutableListOf() } += it.z }
        input.faces.values.forEach { face ->
            val gradient = gradients.getValue(face.id)
            face.elevationConstraints.filter { it.hard }.forEach { constraint ->
                constraint.nodeId?.takeIf(input.nodes::containsKey)?.let {
                    hardNodeElevations.getOrPut(it) { mutableListOf() } += constraint.elevationZ
                } ?: if (constraint.x != null && constraint.y != null) {
                    equations += Equation(
                        mapOf(faceIndex.getValue(face.id) to 1.0),
                        constraint.elevationZ - gradient.a * constraint.x - gradient.b * constraint.y
                    )
                } else Unit
            }
        }
        input.edges.values.filter {
            it.semanticRole in allLowRoles &&
                (it.boundary || it.semanticRole in setOf(EdgeSemantic.LOW_EDGE, EdgeSemantic.ELEVATED_LOW_EDGE)) &&
                (!resolvedFlatRoofMode || !it.boundary || it.id == flatBoundarySupportId)
        }.forEach { edge ->
            val elevation = when (edge.semanticRole) {
                EdgeSemantic.ELEVATED_LOW_EDGE -> edge.elevationZ
                else -> edge.elevationZ ?: wallHeight
            }
            if (elevation == null) {
                issues += RoofPlaneSolverIssue(
                    "MISSING_LOW_EDGE_HEIGHT", "Zvýšená nízka hrana ${edge.id} nemá zadanú absolútnu výšku.", blocking = true
                )
            } else {
                hardNodeElevations.getOrPut(edge.startNodeId) { mutableListOf() } += elevation
                hardNodeElevations.getOrPut(edge.endNodeId) { mutableListOf() } += elevation
            }
        }
        input.drainPointConstraints.values.filter { it.hard }.forEach { drain ->
            drain.nodeId?.takeIf(input.nodes::containsKey)?.let {
                hardNodeElevations.getOrPut(it) { mutableListOf() } += drain.elevationZ
            }
            if (drain.x != null && drain.y != null) drain.faceIds.sorted().forEach faceLoop@{ faceId ->
                val gradient = gradients[faceId] ?: return@faceLoop
                equations += Equation(
                    mapOf(faceIndex.getValue(faceId) to 1.0),
                    drain.elevationZ - gradient.a * drain.x - gradient.b * drain.y
                )
            }
        }
        // An all-parapet flat roof has no eave support by definition. Anchor only its lowest
        // boundary point to the wall datum; the inner plane may then slope while the parapet is
        // rendered independently with a horizontal top. ATTIC itself is deliberately not a low edge.
        if (input.faces.size == 1) {
            val face = input.faces.values.single()
            val faceEdges = face.orderedEdgeIds.mapNotNull(input.edges::get)
            val isFlatRoof = resolvedFlatRoofMode || faceEdges.any { it.boundary && it.semanticRole == EdgeSemantic.ATTIC }
            val hasNodeAnchor = face.orderedNodeIds.any(hardNodeElevations::containsKey)
            val hasFaceElevation = face.elevationConstraints.any { it.hard } ||
                input.drainPointConstraints.values.any { it.hard && face.id in it.faceIds }
            if (isFlatRoof && !hasNodeAnchor && !hasFaceElevation) {
                val gradient = gradients.getValue(face.id)
                face.orderedNodeIds.mapNotNull(input.nodes::get)
                    .minByOrNull { gradient.a * it.x + gradient.b * it.y }
                    ?.let { lowest ->
                        hardNodeElevations.getOrPut(lowest.id) { mutableListOf() } += wallHeight
                    }
            }
        }
        hardNodeElevations.forEach { (nodeId, values) ->
            val first = values.first()
            if (values.any { abs(it - first) > residualToleranceM }) {
                issues += RoofPlaneSolverIssue(
                    "CONFLICTING_NODE_HEIGHT", "Uzol $nodeId má viac nekompatibilných pevných výšok.",
                    residualM = values.maxOf { abs(it - first) }, blocking = !allowApproximation
                )
                if (allowApproximation) nodeIndex[nodeId]?.let {
                    equations += Equation(mapOf(it to 1.0), values.average(), weight = 1000.0)
                }
            } else nodeIndex[nodeId]?.let {
                equations += Equation(mapOf(it to 1.0), first, weight = 1000.0)
            }
        }
        if (issues.any { it.blocking }) return RoofPlaneSolution(input, issues, 0.0)

        val initial = DoubleArray(nodeIds.size + faceIds.size)
        nodeIds.forEach { id -> initial[nodeIndex.getValue(id)] = input.nodes.getValue(id).z.takeIf(Double::isFinite) ?: wallHeight }
        faceIds.forEach { id ->
            val face = input.faces.getValue(id)
            val gradient = gradients.getValue(id)
            initial[faceIndex.getValue(id)] = face.plane?.c ?: face.orderedNodeIds.mapNotNull(input.nodes::get)
                .map { (it.z.takeIf(Double::isFinite) ?: wallHeight) - gradient.a * it.x - gradient.b * it.y }
                .average()
        }
        val exact = solveExact(equations, initial)
        if ((exact.inconsistent || exact.values == null) && !allowApproximation) {
            issues += RoofPlaneSolverIssue(
                "HARD_CONSTRAINT_CONFLICT",
                "Pevné výšky, sklony a incidencie plôch nemajú spoločné riešenie. Model nebol aproximovaný.",
                blocking = true
            )
            return RoofPlaneSolution(input, issues, 0.0)
        }

        val values = exact.values ?: solveLeastSquares(equations, initial).also {
            issues += RoofPlaneSolverIssue(
                "APPROXIMATED_HARD_CONSTRAINTS",
                "Terenny nacrt nema presne spolocne riesenie; 3D pouzilo deterministicky kompromis bez zmeny incidencie hran.",
                blocking = false
            )
        }
        val solvedNodes = input.nodes.mapValues { (id, node) -> node.copy(z = values[nodeIndex.getValue(id)]) }
        var maximumResidual = 0.0
        val solvedFaces = input.faces.mapValues { (id, face) ->
            val gradient = gradients.getValue(id)
            val plane = RoofPlane(gradient.a, gradient.b, values[faceIndex.getValue(id)])
            val residual = face.orderedNodeIds.maxOfOrNull { nodeId ->
                val node = solvedNodes.getValue(nodeId)
                abs(node.z - plane.zAt(node.x, node.y))
            } ?: 0.0
            maximumResidual = max(maximumResidual, residual)
            if (gradient.underconstrained) issues += RoofPlaneSolverIssue(
                "FACE_WITHOUT_SLOPE", "Plocha nemá sklon ani jednoznačnú nízku hranu; zostala vodorovná.", id
            )
            if (residual > residualToleranceM) issues += RoofPlaneSolverIssue(
                "PLANE_RESIDUAL", "Uzly plochy neležia na jej rovine v požadovanej tolerancii.",
                id, residual, blocking = !allowApproximation
            )
            face.copy(plane = plane, underconstrained = gradient.underconstrained || residual > residualToleranceM)
        }
        return RoofPlaneSolution(input.copy(nodes = solvedNodes, faces = solvedFaces), issues, maximumResidual)
    }

    /**
     * Rendering and quantity mode for measured sketches. Exact [solve] remains
     * the audit authority. Shared node heights are optimized together, keeping
     * the generated mesh watertight even when the input is slightly imperfect.
     */
    fun solveForRendering(
        input: RoofGraph,
        wallHeightM: Double,
        defaultSlopeDeg: Double,
        flatRoofMode: Boolean = false
    ): RoofPlaneSolution = solve(
        input = input,
        wallHeightM = wallHeightM,
        defaultSlopeDeg = defaultSlopeDeg,
        allowApproximation = true,
        flatRoofMode = flatRoofMode
    )

    private fun inferGradient(
        graph: RoofGraph,
        face: GraphFace,
        defaultSlopeDeg: Double,
        flatRoofMode: Boolean,
        issues: MutableList<RoofPlaneSolverIssue>
    ): Gradient {
        val lowEdges = face.orderedEdgeIds.mapNotNull(graph.edges::get)
            .filter {
                it.semanticRole in allLowRoles && (it.boundary || it.semanticRole in setOf(EdgeSemantic.LOW_EDGE, EdgeSemantic.ELEVATED_LOW_EDGE))
            }
        val atticEdges = face.orderedEdgeIds.mapNotNull(graph.edges::get)
            .filter { it.boundary && it.semanticRole == EdgeSemantic.ATTIC }
        val flatRoof = graph.faces.size == 1 && (flatRoofMode || atticEdges.isNotEmpty())
        if (graph.faces.size == 1 && lowEdges.size > 1 && !flatRoof) {
            issues += RoofPlaneSolverIssue(
                "AUTO_TOPOLOGY_REQUIRED",
                "Samotný obrys s viacerými nízkymi hranami neurčuje strešné plochy. Doplňte hrebeň/nárožia/úžľabia alebo explicitný sklon plochy.",
                face.id,
                blocking = true
            )
            return Gradient(0.0, 0.0, true)
        }
        // For a flat roof, one eave defines the discharge side. With an all-parapet perimeter,
        // the longest parapet is a deterministic directional reference, not a fixed low support.
        val low = (lowEdges.ifEmpty { if (flatRoof) atticEdges else emptyList() })
            .maxByOrNull { edge ->
                val a = graph.nodes[edge.startNodeId] ?: return@maxByOrNull 0.0
                val b = graph.nodes[edge.endNodeId] ?: return@maxByOrNull 0.0
                hypot(b.x - a.x, b.y - a.y)
            }
        if (low == null) return Gradient(0.0, 0.0, true)
        val start = graph.nodes.getValue(low.startNodeId)
        val end = graph.nodes.getValue(low.endNodeId)
        val centroidX = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { it.x }.average()
        val centroidY = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { it.y }.average()
        val dx = end.x - start.x
        val dy = end.y - start.y
        val length = hypot(dx, dy)
        if (length < 1e-12) {
            issues += RoofPlaneSolverIssue("ZERO_LOW_EDGE", "Nízka hrana plochy má nulovú dĺžku.", face.id, blocking = true)
            return Gradient(0.0, 0.0, true)
        }
        var uphillX = -dy / length
        var uphillY = dx / length
        val midX = (start.x + end.x) / 2.0
        val midY = (start.y + end.y) / 2.0
        if (uphillX * (centroidX - midX) + uphillY * (centroidY - midY) < 0.0) {
            uphillX = -uphillX
            uphillY = -uphillY
        }
        val magnitude = tan(Math.toRadians(defaultSlopeDeg.coerceIn(0.0, 75.0)))
        return Gradient(uphillX * magnitude, uphillY * magnitude, false)
    }

    /** Exact RREF solve. Non-pivot variables keep their transaction-start values. */
    private fun solveExact(equations: List<Equation>, initial: DoubleArray): ExactResult {
        if (equations.isEmpty()) return ExactResult(initial.copyOf(), false)
        val variableCount = initial.size
        val matrix = Array(equations.size) { row ->
            DoubleArray(variableCount + 1).also { values ->
                equations[row].coefficients.forEach { (column, coefficient) -> values[column] = coefficient }
                values[variableCount] = equations[row].rhs
            }
        }
        val pivotRows = linkedMapOf<Int, Int>()
        var row = 0
        for (column in 0 until variableCount) {
            val pivot = (row until matrix.size).maxByOrNull { abs(matrix[it][column]) } ?: break
            if (abs(matrix[pivot][column]) <= equationTolerance) continue
            val swap = matrix[row]; matrix[row] = matrix[pivot]; matrix[pivot] = swap
            val divisor = matrix[row][column]
            for (c in column..variableCount) matrix[row][c] /= divisor
            for (r in matrix.indices) if (r != row) {
                val factor = matrix[r][column]
                if (abs(factor) > equationTolerance) for (c in column..variableCount) matrix[r][c] -= factor * matrix[row][c]
            }
            pivotRows[column] = row
            row++
            if (row == matrix.size) break
        }
        matrix.forEach { values ->
            val empty = (0 until variableCount).all { abs(values[it]) <= equationTolerance }
            if (empty && abs(values[variableCount]) > residualToleranceM) return ExactResult(null, true)
        }
        val result = initial.copyOf()
        pivotRows.entries.reversed().forEach { (column, pivotRow) ->
            var value = matrix[pivotRow][variableCount]
            for (c in 0 until variableCount) if (c != column) value -= matrix[pivotRow][c] * result[c]
            result[column] = value
        }
        if (result.any { !it.isFinite() }) return ExactResult(null, true)
        return ExactResult(result, false)
    }

    /** Weighted normal-equation solve with a tiny prior to the current model. */
    private fun solveLeastSquares(equations: List<Equation>, initial: DoubleArray): DoubleArray {
        val count = initial.size
        val normal = Array(count) { DoubleArray(count + 1) }
        equations.forEach { equation ->
            val weight = equation.weight.coerceAtLeast(1e-9)
            equation.coefficients.forEach { (row, rowCoefficient) ->
                equation.coefficients.forEach { (column, columnCoefficient) ->
                    normal[row][column] += weight * rowCoefficient * columnCoefficient
                }
                normal[row][count] += weight * rowCoefficient * equation.rhs
            }
        }
        val prior = 1e-8
        for (index in 0 until count) {
            normal[index][index] += prior
            normal[index][count] += prior * initial[index]
        }
        for (column in 0 until count) {
            val pivot = (column until count).maxByOrNull { abs(normal[it][column]) } ?: continue
            if (abs(normal[pivot][column]) <= equationTolerance) continue
            val swap = normal[column]
            normal[column] = normal[pivot]
            normal[pivot] = swap
            val divisor = normal[column][column]
            for (c in column..count) normal[column][c] /= divisor
            for (row in 0 until count) if (row != column) {
                val factor = normal[row][column]
                if (abs(factor) > equationTolerance) {
                    for (c in column..count) normal[row][c] -= factor * normal[column][c]
                }
            }
        }
        return DoubleArray(count) { index ->
            normal[index][count].takeIf(Double::isFinite) ?: initial[index]
        }
    }
}
