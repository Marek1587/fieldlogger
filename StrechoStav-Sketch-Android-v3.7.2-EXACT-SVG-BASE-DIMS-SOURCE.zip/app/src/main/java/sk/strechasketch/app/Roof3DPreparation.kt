package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

data class Roof3DPreparationResult(
    val topology: RoofTopology,
    val graph: RoofGraph,
    val planeSolution: RoofPlaneSolution,
    val topologyWasAdjusted: Boolean,
    val planeWasApproximated: Boolean
)

/** Single preparation path shared by live 3D, bitmap/PDF and quantities. */
object Roof3DPreparation {
    private fun faceCoverage(topology: RoofTopology): Double {
        val ordered = RoofTopologyMigration.orderedBoundary(topology)?.first ?: return 0.0
        val nodes = topology.nodes.associateBy { it.id }
        val boundary = ordered.mapNotNull(nodes::get)
        if (boundary.size < 3) return 0.0
        val boundaryArea = abs(boundary.indices.sumOf { index ->
            val a = boundary[index]
            val b = boundary[(index + 1) % boundary.size]
            a.x * b.y - b.x * a.y
        } / 2.0)
        if (boundaryArea <= 1e-9) return 0.0
        return RoofTopologySolver.extractFaces(topology).sumOf { abs(it.signedAreaM2) } / boundaryArea
    }

    fun prepare(project: RoofProject): Roof3DPreparationResult {
        val base = project.roofGraph?.toTopology()
            ?: project.roofTopology
            ?: RoofTopologyMigration.fromLegacyProject(project)

        // First perform the same bounded, topology-preserving cleanup offered
        // by card 2. This may merge existing near-coincident endpoints but can
        // never add a node or an edge.
        val conservative = RoofTopologySolver.solveInternal(base).proposed
        var prepared = conservative

        // An empty OR only partly subdivided footprint may use the derived topology-building
        // pass. Merely finding one or two closed cycles is not sufficient for an L/K roof: all
        // bounded faces together must cover the whole building footprint. This pass changes the
        // derived 3D topology only and caps XY movement at 10% of the measured edge scale.
        val conservativeCoverage = faceCoverage(prepared)
        if (conservativeCoverage < 0.995) {
            val nodeById = prepared.nodes.associateBy { it.id }
            val lengths = prepared.edges.mapNotNull { edge ->
                val a = nodeById[edge.startNodeId] ?: return@mapNotNull null
                val b = nodeById[edge.endNodeId] ?: return@mapNotNull null
                hypot(b.x - a.x, b.y - a.y).takeIf { it > 1e-6 }
            }.sorted()
            val referenceLength = lengths.getOrNull(lengths.size / 2) ?: 1.0
            val rebuilt = RoofTopologySolver.solve(
                prepared,
                RoofSolverConfig(
                    regularizeAngles = true,
                    maximumRegularizationDisplacementM = (referenceLength * 0.10).coerceIn(0.05, 4.0)
                )
            ).proposed
            val rebuiltCoverage = faceCoverage(rebuilt)
            if (rebuiltCoverage > conservativeCoverage + 1e-6) prepared = rebuilt
        }

        val graph = RoofGraphFactory.fromTopology(prepared, project.roofGraph)
        val flatRoofMode = project.shape == RoofShape.FLAT || graph.edges.values.any {
            it.boundary && it.semanticRole == EdgeSemantic.ATTIC
        }
        val exact = RoofPlaneSolver.solve(
            graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
        )
        val planes = if (exact.hasBlockingIssues) {
            RoofPlaneSolver.solveForRendering(
                graph, project.wallHeightM, project.slopeDeg, flatRoofMode = flatRoofMode
            )
        } else exact
        return Roof3DPreparationResult(
            topology = prepared,
            graph = planes.graph,
            planeSolution = planes,
            topologyWasAdjusted = prepared != base,
            planeWasApproximated = planes.issues.any { it.code == "APPROXIMATED_HARD_CONSTRAINTS" }
        )
    }
}
