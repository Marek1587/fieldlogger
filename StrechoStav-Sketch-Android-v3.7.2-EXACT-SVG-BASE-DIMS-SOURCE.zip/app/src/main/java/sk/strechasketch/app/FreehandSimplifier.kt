package sk.strechasketch.app

import kotlin.math.abs

/** Pure, deterministic freehand-to-polygon conversion used by the editor and tests. */
object FreehandSimplifier {
    fun simplify(points: List<GeoPoint>, minimumDistanceM: Double, maxPoints: Int = 10): MutableList<GeoPoint> {
        if (points.size < 3) return points.map { it.copy() }.toMutableList()
        val filtered = mutableListOf(points.first().copy())
        points.drop(1).forEach { point ->
            if (Geometry.distanceM(filtered.last(), point) >= minimumDistanceM) filtered += point.copy()
        }
        if (filtered.size > 3 && Geometry.distanceM(filtered.first(), filtered.last()) < minimumDistanceM * 1.5) {
            filtered.removeAt(filtered.lastIndex)
        }
        if (filtered.size <= 3) return filtered

        val origin = Geometry.centroid(filtered)
        val raw = filtered.map { Geometry.toLocal(it, origin) }
        val smoothed = raw.indices.map { index ->
            val previous = raw[(index - 1 + raw.size) % raw.size]
            val current = raw[index]
            val next = raw[(index + 1) % raw.size]
            LocalPoint(
                current.x * 0.60 + previous.x * 0.20 + next.x * 0.20,
                current.y * 0.60 + previous.y * 0.20 + next.y * 0.20
            )
        }.toMutableList()

        val limit = maxPoints.coerceAtLeast(3)
        while (smoothed.size > limit) {
            val removeIndex = smoothed.indices.minBy { index ->
                val a = smoothed[(index - 1 + smoothed.size) % smoothed.size]
                val b = smoothed[index]
                val c = smoothed[(index + 1) % smoothed.size]
                abs((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x))
            }
            smoothed.removeAt(removeIndex)
        }
        return smoothed.map { Geometry.toGeo(it, origin) }.toMutableList()
    }
}
