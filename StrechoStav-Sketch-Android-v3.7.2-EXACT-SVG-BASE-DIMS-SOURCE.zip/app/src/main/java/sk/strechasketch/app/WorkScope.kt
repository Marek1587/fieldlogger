package sk.strechasketch.app

enum class QuantitySource {
    ROOF_AREA, FOOTPRINT_AREA, EAVE_LENGTH, RIDGE_LENGTH, VALLEY_LENGTH, HIP_LENGTH,
    ATTIC_LENGTH, CHIMNEY_COUNT, ROOF_WINDOW_COUNT, MANUAL
}

data class WorkItem(
    val code: String,
    val label: String,
    val unit: String,
    val quantitySource: QuantitySource
)

data class SelectedWorkItem(
    val code: String,
    var selected: Boolean = false,
    var unitPrice: Double? = null,
    var manualQuantityOverride: Double? = null
)

data class ResolvedWorkItem(
    val item: WorkItem,
    val automaticQuantity: Double,
    val quantity: Double,
    val unitPrice: Double?,
    val totalPrice: Double?,
    val manualOverride: Boolean
)

object WorkCatalog {
    val items = listOf(
        WorkItem("ROOF_COVERING", "Montáž strešnej krytiny", "m²", QuantitySource.ROOF_AREA),
        WorkItem("ROOF_DISMANTLE", "Demontáž existujúcej krytiny", "m²", QuantitySource.ROOF_AREA),
        WorkItem("EAVE_FLASHING", "Odkvapové oplechovanie", "m", QuantitySource.EAVE_LENGTH),
        WorkItem("RIDGE_DETAIL", "Hrebeňový detail", "m", QuantitySource.RIDGE_LENGTH),
        WorkItem("VALLEY_DETAIL", "Úžľabie", "m", QuantitySource.VALLEY_LENGTH),
        WorkItem("HIP_DETAIL", "Nárožie", "m", QuantitySource.HIP_LENGTH),
        WorkItem("ATTIC_FLASHING", "Oplechovanie atiky", "m", QuantitySource.ATTIC_LENGTH),
        WorkItem("CHIMNEY_FLASHING", "Oplechovanie komína", "ks", QuantitySource.CHIMNEY_COUNT),
        WorkItem("ROOF_WINDOW", "Montáž strešného okna", "ks", QuantitySource.ROOF_WINDOW_COUNT),
        WorkItem("MANUAL", "Vlastná položka", "MJ", QuantitySource.MANUAL)
    )
}

object WorkScopeEngine {
    fun resolve(project: RoofProject): List<ResolvedWorkItem> {
        val totals = RoofQuantityEngine.calculate(project).totals
        return WorkCatalog.items.map { item ->
            val selection = project.selectedWorkItems[item.code] ?: SelectedWorkItem(item.code)
            val automatic = when (item.quantitySource) {
                QuantitySource.ROOF_AREA -> totals.roofAreaM2
                QuantitySource.FOOTPRINT_AREA -> totals.footprintAreaM2
                QuantitySource.EAVE_LENGTH -> totals.eaveM
                QuantitySource.RIDGE_LENGTH -> totals.ridgeM
                QuantitySource.VALLEY_LENGTH -> totals.valleyM
                QuantitySource.HIP_LENGTH -> totals.hipM
                QuantitySource.ATTIC_LENGTH -> totals.atticM
                QuantitySource.CHIMNEY_COUNT -> totals.chimneys.toDouble()
                QuantitySource.ROOF_WINDOW_COUNT -> totals.roofWindows.toDouble()
                QuantitySource.MANUAL -> 0.0
            }
            val quantity = selection.manualQuantityOverride ?: automatic
            ResolvedWorkItem(
                item, automatic, quantity, selection.unitPrice,
                selection.unitPrice?.let { it * quantity }, selection.manualQuantityOverride != null
            )
        }
    }
}
