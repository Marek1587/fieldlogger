package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

data class ParametricEditResult(
    val applied: Boolean,
    val graph: RoofGraph,
    val issues: List<String> = emptyList()
)

object TopologyValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = RoofGraphValidator.validate(graph)

    fun sameIncidence(before: RoofGraph, after: RoofGraph): Boolean =
        before.nodes.keys == after.nodes.keys &&
            before.edges.keys == after.edges.keys &&
            before.faces.keys == after.faces.keys &&
            before.edges.all { (id, edge) ->
                after.edges[id]?.let { it.startNodeId == edge.startNodeId && it.endNodeId == edge.endNodeId } == true
            } &&
            before.faces.all { (id, face) ->
                after.faces[id]?.let {
                    it.orderedNodeIds == face.orderedNodeIds && it.orderedEdgeIds == face.orderedEdgeIds
                } == true
            }
}

object PlanConstraintSolver {
    fun setEdgeLength(graph: RoofGraph, edgeId: String, targetLengthM: Double): ParametricEditResult {
        val candidate = RoofGraphOperations.setEdgeLength(graph, edgeId, targetLengthM)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutým uzlom."))
        if (!TopologyValidator.sameIncidence(graph, candidate)) {
            return ParametricEditResult(false, graph, listOf("Parametrická zmena by zmenila topológiu."))
        }
        val issues = TopologyValidator.validate(candidate)
        if (issues.any { it.code in setOf("NON_FINITE_NODE", "ZERO_EDGE", "BROKEN_FACE_REFERENCE") }) {
            return ParametricEditResult(false, graph, issues.map { it.message })
        }
        val events = RoofTopologyEventDetector.detect(candidate)
        if (events.any { it.requiresExplicitRetopology }) {
            return ParametricEditResult(false, graph, events.map { it.message })
        }
        val hardConflicts = validateHardPlanConstraints(candidate)
        if (hardConflicts.isNotEmpty()) return ParametricEditResult(false, graph, hardConflicts)
        return ParametricEditResult(true, candidate)
    }

    fun setDimension(graph: RoofGraph, dimensionId: String, targetDistanceM: Double): ParametricEditResult {
        if (targetDistanceM !in 0.05..5000.0) return ParametricEditResult(false, graph, listOf("Rozmer je mimo povoleného rozsahu."))
        val constraint = graph.dimensions[dimensionId]
            ?: return ParametricEditResult(false, graph, listOf("Rozmer neexistuje."))
        val edgeA = graph.edges[constraint.supportAEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Prvá podpora rozmeru neexistuje."))
        val edgeB = graph.edges[constraint.supportBEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Druhá podpora rozmeru neexistuje."))
        val length = hypot(constraint.directionX, constraint.directionY)
        if (length < 1e-12) return ParametricEditResult(false, graph, listOf("Rozmer nemá platný smer."))
        val dx = constraint.directionX / length; val dy = constraint.directionY / length
        fun midpoint(edge: GraphEdge): Pair<Double, Double> {
            val a = graph.nodes.getValue(edge.startNodeId); val b = graph.nodes.getValue(edge.endNodeId)
            return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
        }
        val a = midpoint(edgeA); val b = midpoint(edgeB)
        val current = (b.first - a.first) * dx + (b.second - a.second) * dy
        val movingB = constraint.fixedSupportEdgeId != edgeB.id
        val movingEdge = if (movingB) edgeB else edgeA
        val delta = if (movingB) targetDistanceM - current else current - targetDistanceM
        val movingNodes = constraint.movingNodeIds.ifEmpty { setOf(movingEdge.startNodeId, movingEdge.endNodeId) }
        val positions = movingNodes.associateWith { id ->
            val node = graph.nodes[id] ?: return ParametricEditResult(false, graph, listOf("Pohyblivý uzol rozmeru neexistuje."))
            node.x + dx * delta to node.y + dy * delta
        }
        val moved = RoofGraphOperations.moveNodes(graph, positions)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutými uzlami."))
        val updated = moved.copy(dimensions = moved.dimensions + (dimensionId to constraint.copy(valueMm = targetDistanceM * 1000.0)))
        if (!TopologyValidator.sameIncidence(graph, updated)) return ParametricEditResult(false, graph, listOf("Zmena vyžaduje explicitnú zmenu topológie."))
        val conflicts = validateHardPlanConstraints(updated)
        if (conflicts.isNotEmpty()) return ParametricEditResult(false, graph, conflicts)
        return ParametricEditResult(true, updated)
    }

    private fun validateHardPlanConstraints(graph: RoofGraph): List<String> = buildList {
        graph.edgeLengthConstraints.values.filter { it.hard }.forEach { constraint ->
            val edge = graph.edges[constraint.edgeId] ?: return@forEach
            val a = graph.nodes[edge.startNodeId] ?: return@forEach
            val b = graph.nodes[edge.endNodeId] ?: return@forEach
            if (abs(hypot(b.x - a.x, b.y - a.y) - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer hrany ${edge.id} nie je splnený s presnosťou 0,5 mm.")
            }
        }
        graph.dimensions.values.filter { it.hard }.forEach { constraint ->
            val edgeA = graph.edges[constraint.supportAEdgeId] ?: return@forEach
            val edgeB = graph.edges[constraint.supportBEdgeId] ?: return@forEach
            val directionLength = hypot(constraint.directionX, constraint.directionY)
            if (directionLength < 1e-12) return@forEach
            fun midpoint(edge: GraphEdge): Pair<Double, Double> {
                val a = graph.nodes[edge.startNodeId] ?: return 0.0 to 0.0
                val b = graph.nodes[edge.endNodeId] ?: return 0.0 to 0.0
                return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
            }
            val a = midpoint(edgeA); val b = midpoint(edgeB)
            val measured = ((b.first - a.first) * constraint.directionX + (b.second - a.second) * constraint.directionY) / directionLength
            if (abs(measured - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer ${constraint.id} medzi podporami nie je splnený s presnosťou 0,5 mm.")
            }
        }
    }
}

object ParametricEditSolver {
    fun setBoundaryDimension(
        graph: RoofGraph,
        linkedEdgeIds: List<String>,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double
    ): ParametricEditResult {
        if (linkedEdgeIds.size != 2) {
            val edgeId = linkedEdgeIds.firstOrNull()
                ?: return ParametricEditResult(false, graph, listOf("Kóta nemá priradenú hranu."))
            return setEdgeLength(graph, edgeId, targetLengthM, wallHeightM, defaultSlopeDeg)
        }
        val boundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())
            ?: return ParametricEditResult(false, graph, listOf("Obvod netvorí uzavretý cyklus."))
        if (boundary.second.size != 4 || !boundary.second.map { it.id }.containsAll(linkedEdgeIds)) {
            return setEdgeLength(graph, linkedEdgeIds.first(), targetLengthM, wallHeightM, defaultSlopeDeg)
        }
        val edge = graph.edges[linkedEdgeIds.first()]
            ?: return ParametricEditResult(false, graph, listOf("Hrana spoločnej kóty neexistuje."))
        val edgeA = graph.nodes[edge.startNodeId] ?: return ParametricEditResult(false, graph)
        val edgeB = graph.nodes[edge.endNodeId] ?: return ParametricEditResult(false, graph)
        val directionLength = hypot(edgeB.x - edgeA.x, edgeB.y - edgeA.y)
        if (directionLength < 1e-9) return ParametricEditResult(false, graph, listOf("Smer kóty je nulový."))
        val ux = (edgeB.x - edgeA.x) / directionLength
        val uy = (edgeB.y - edgeA.y) / directionLength
        val vx = -uy
        val vy = ux
        val boundaryNodes = boundary.first.mapNotNull(graph.nodes::get)
        val centerX = boundaryNodes.map { it.x }.average()
        val centerY = boundaryNodes.map { it.y }.average()
        fun along(node: GraphNode) = (node.x - centerX) * ux + (node.y - centerY) * uy
        fun across(node: GraphNode) = (node.x - centerX) * vx + (node.y - centerY) * vy
        val minAlong = boundaryNodes.minOf(::along)
        val maxAlong = boundaryNodes.maxOf(::along)
        val minAcross = boundaryNodes.minOf(::across)
        val maxAcross = boundaryNodes.maxOf(::across)
        val oldWidth = (maxAlong - minAlong).coerceAtLeast(1e-6)
        val oldHeight = (maxAcross - minAcross).coerceAtLeast(1e-6)
        val positions = graph.nodes.mapValues { (_, node) ->
            val oldAlong = along(node)
            val oldAcross = across(node)
            val newAlong = oldAlong / oldWidth * targetLengthM
            val newAcross = oldAcross / oldHeight * oldHeight
            centerX + ux * newAlong + vx * newAcross to centerY + uy * newAlong + vy * newAcross
        }.toMutableMap()
        // Four-sided symmetric footprints become an exact orthogonal rectangle.
        boundaryNodes.forEach { node ->
            val newAlong = if (along(node) < 0.0) -targetLengthM / 2.0 else targetLengthM / 2.0
            val newAcross = if (across(node) < 0.0) -oldHeight / 2.0 else oldHeight / 2.0
            positions[node.id] = centerX + ux * newAlong + vx * newAcross to
                centerY + uy * newAlong + vy * newAcross
        }
        val moved = RoofGraphOperations.moveNodes(graph, positions)
            ?: return ParametricEditResult(false, graph, listOf("Kolmá úprava je v konflikte so zamknutým uzlom."))
        if (!TopologyValidator.sameIncidence(graph, moved)) {
            return ParametricEditResult(false, graph, listOf("Spoločná kóta by zmenila topológiu."))
        }
        val withoutOld = moved.edgeLengthConstraints.filterValues { it.edgeId !in linkedEdgeIds }.toMutableMap()
        linkedEdgeIds.forEach { id ->
            val changedEdge = moved.edges[id] ?: return@forEach
            withoutOld["edge-length-$id"] = EdgeLengthConstraint(
                id = "edge-length-$id",
                edgeId = id,
                valueMm = targetLengthM * 1000.0,
                fixedNodeId = changedEdge.startNodeId
            )
        }
        val constrained = moved.copy(edgeLengthConstraints = withoutOld)
        val roof = RoofPlaneSolver.solveForRendering(constrained, wallHeightM, defaultSlopeDeg)
        // A valid 2D parametric edit must not be discarded only because an unfinished roof has
        // not yet received enough ridge/hip constraints for Z. Preserve the orthogonal plan and
        // let the dedicated 3D preparation complete heights once topology is available.
        if (roof.hasBlockingIssues) return ParametricEditResult(
            true, constrained, roof.issues.map { it.message }
        )
        return ParametricEditResult(true, roof.graph, roof.issues.map { it.message })
    }

    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double
    ): ParametricEditResult {
        val plan = PlanConstraintSolver.setEdgeLength(graph, edgeId, targetLengthM)
        if (!plan.applied) return plan
        val roof = RoofPlaneSolver.solveForRendering(plan.graph, wallHeightM, defaultSlopeDeg)
        if (roof.hasBlockingIssues) {
            val hardGeometryConflicts = roof.issues.filter { it.blocking && it.code != "AUTO_TOPOLOGY_REQUIRED" }
            if (hardGeometryConflicts.isNotEmpty()) {
                return ParametricEditResult(false, graph, hardGeometryConflicts.map { it.message })
            }
            return ParametricEditResult(true, plan.graph, roof.issues.map { it.message })
        }
        if (!TopologyValidator.sameIncidence(graph, roof.graph)) {
            return ParametricEditResult(false, graph, listOf("RoofPlaneSolver zmenil topologickú incidenciu."))
        }
        return ParametricEditResult(true, roof.graph, roof.issues.map { it.message })
    }
}
