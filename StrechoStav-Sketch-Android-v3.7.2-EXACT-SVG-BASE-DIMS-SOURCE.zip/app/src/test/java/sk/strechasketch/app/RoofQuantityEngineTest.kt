package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos

class RoofQuantityEngineTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun roofAreaIsSumOfActualThreeDimensionalFaceAreas() {
        val graph = gableGraph()
        val project = projectFor(graph, 30.0)
        val audit = RoofQuantityEngine.calculate(project)
        val expected = 60.0 / cos(Math.toRadians(30.0))

        assertEquals(expected, audit.totals.roofAreaM2, 1e-5)
        assertEquals(audit.faces.sumOf { it.area3DM2 }, audit.totals.roofAreaM2, 1e-10)
        assertEquals(10.0, audit.totals.ridgeM, 1e-8)
        assertTrue(audit.faces.all { !it.underconstrained })
    }

    @Test
    fun workScopeKeepsAutomaticQuantityVisibleBehindManualOverride() {
        val project = projectFor(gableGraph(), 30.0)
        project.selectedWorkItems["ROOF_COVERING"] = SelectedWorkItem(
            code = "ROOF_COVERING", selected = true, unitPrice = 12.5, manualQuantityOverride = 75.0
        )
        val item = WorkScopeEngine.resolve(project).single { it.item.code == "ROOF_COVERING" }
        assertTrue(item.automaticQuantity > 69.0)
        assertEquals(75.0, item.quantity, 0.0)
        assertEquals(937.5, item.totalPrice!!, 1e-9)
        assertTrue(item.manualOverride)
    }

    private fun projectFor(graph: RoofGraph, slope: Double): RoofProject {
        val boundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())!!
        return RoofProject(
            polygon = boundary.first.map { id ->
                val n = graph.nodes.getValue(id)
                Geometry.toGeo(LocalPoint(n.x, n.y), graph.origin)
            }.toMutableList(),
            slopeDeg = slope,
            wallHeightM = 3.0,
            roofGraph = graph,
            roofTopology = graph.toTopology()
        )
    }

    private fun gableGraph(): RoofGraph {
        fun n(id: String, x: Double, y: Double) = TopologyNode(id, x, y, TopologyNodeType.FOOTPRINT)
        fun e(id: String, a: String, b: String, type: LineType, boundary: Boolean) =
            TopologyEdge(id, a, b, type, boundary = boundary)
        return RoofGraphFactory.fromTopology(RoofTopology(
            origin,
            listOf(n("A", 0.0, 0.0), n("B", 10.0, 0.0), n("R", 10.0, 3.0), n("C", 10.0, 6.0), n("D", 0.0, 6.0), n("L", 0.0, 3.0)),
            listOf(
                e("AB", "A", "B", LineType.EAVE, true), e("BR", "B", "R", LineType.GABLE, true),
                e("RC", "R", "C", LineType.GABLE, true), e("CD", "C", "D", LineType.EAVE, true),
                e("DL", "D", "L", LineType.GABLE, true), e("LA", "L", "A", LineType.GABLE, true),
                e("RIDGE", "L", "R", LineType.RIDGE, false)
            )
        ))
    }
}
