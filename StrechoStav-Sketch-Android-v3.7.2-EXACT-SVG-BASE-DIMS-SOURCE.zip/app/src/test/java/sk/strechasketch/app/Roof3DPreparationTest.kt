package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.tan

class Roof3DPreparationTest {
    private val origin = GeoPoint(49.0, 18.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    @Test
    fun imperfectHipAndRidgeDrawingStillProduces3DMeshAndQuantities() {
        val lowerJunction = geo(6.18, 5.55)
        val upperJunction = geo(5.84, 12.62)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 18.0), geo(0.0, 18.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.RIDGE, start = lowerJunction.copy(), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(0.0, 18.0), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 18.0), end = upperJunction.copy())
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val quantities = RoofQuantityEngine.calculate(project)
        val mesh = RoofMeshBuilder.build(project)

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.code }, !prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.graph.nodes.values.all { it.z.isFinite() })
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
        assertTrue(quantities.totals.perimeterM > 0.0)
        assertTrue(mesh.triangles.isNotEmpty())
        assertTrue(mesh.edges.isNotEmpty())
        assertEquals(mesh.triangles.size / 3, mesh.materials.size)
        assertTrue(mesh.materials.any { it == 1f })
        assertTrue(mesh.materials.any { it == 0f })
        assertEquals(2, mesh.logoFaceCount)
        assertEquals(2, mesh.logoQuads.size)
        assertTrue(mesh.logoQuads.all { it.faceId in prepared.graph.faces })
        assertTrue(mesh.logoQuads.all { quad ->
            val abX = quad.topRight.x - quad.topLeft.x
            val abZ = quad.topRight.z - quad.topLeft.z
            val acX = quad.bottomRight.x - quad.topLeft.x
            val acZ = quad.bottomRight.z - quad.topLeft.z
            abZ * acX - abX * acZ > 0f
        })
        assertEquals(12, StrechoStavLogo.originalSvgPathCount)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        assertEquals(4, planDimensions.size)
        assertEquals(2, planDimensions.map { it.dimensionId }.toSet().size)
        assertTrue(planDimensions.all { it.linkedEdgeIds.size == 2 })
        val modelBaseY = mesh.triangles.indices.filter { it % 3 == 1 }.minOf { mesh.triangles[it] }
        assertTrue(planDimensions.all { abs(it.witnessStart.y - modelBaseY) < 1e-5f })
        assertTrue(planDimensions.all { abs(it.witnessEnd.y - modelBaseY) < 1e-5f })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.WALL_HEIGHT })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.OVERHANG })
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.SLOPE })
    }

    @Test
    fun staleRectangularWallFootprintCannotReplaceSixCornerBuildingPlan() {
        val lPolygon = mutableListOf(
            geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 4.0),
            geo(14.0, 4.0), geo(14.0, 10.0), geo(0.0, 10.0)
        )
        val project = RoofProject(
            polygon = lPolygon,
            wallFootprint = mutableListOf(
                geo(0.0, 0.0), geo(14.0, 0.0), geo(14.0, 10.0), geo(0.0, 10.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }

        assertTrue(mesh.triangles.isNotEmpty())
        assertEquals(6, planDimensions.size)
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
    }

    @Test
    fun planDimensionsMeasureWallFootprintAndOverhangIsOneSharedParameter() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            wallFootprint = mutableListOf(
                geo(0.5, 0.5), geo(11.5, 0.5), geo(11.5, 7.5), geo(0.5, 7.5)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planValues = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
            .map { it.lengthM }.toSet()
        val overhangs = mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }

        assertTrue(planValues.any { abs(it - 11.0) < 1e-3 })
        assertTrue(planValues.any { abs(it - 7.0) < 1e-3 })
        assertEquals(1, overhangs.map { it.dimensionId }.toSet().size)
        assertTrue(overhangs.all { abs(it.lengthM - 0.5) < 1e-3 })
    }

    @Test
    fun flatRoofWithThreeParapetsAndOneEaveBuildsSlopedDeckAndLevelParapet() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(13.0, 0.0), geo(13.0, 10.0), geo(0.0, 10.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.ATTIC,
                1 to LineType.ATTIC,
                2 to LineType.EAVE,
                3 to LineType.ATTIC
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0,
            atticHeightM = 0.3
        )

        val prepared = Roof3DPreparation.prepare(project)
        val mesh = RoofMeshBuilder.build(project)
        val quantities = RoofQuantityEngine.calculate(project)

        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(2.0)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        val eave = prepared.graph.edges.values.single { it.semanticRole == EdgeSemantic.EAVE }
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.startNodeId).z, 1e-6)
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.endNodeId).z, 1e-6)
        assertTrue(prepared.graph.nodes.values.map { it.z }.distinct().size > 1)
        assertTrue(mesh.triangles.isNotEmpty())
        val atticDimension = mesh.dimensions.first { it.kind == RoofDimensionKind.ATTIC_HEIGHT }
        assertEquals(0.3, atticDimension.lengthM, 1e-9)
        val vertexHeights = mesh.triangles.indices.filter { it % 3 == 1 }.map { mesh.triangles[it] }
        val maximum = vertexHeights.max()
        assertTrue(vertexHeights.count { abs(it - maximum) < 1e-5f } >= 6)
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
    }

    @Test
    fun explicitFlatShapeNeedsNoRidgeOrInternalLine() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(9.0, 0.0), geo(9.0, 7.0), geo(0.0, 7.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE, 2 to LineType.EAVE, 3 to LineType.EAVE
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 1.5,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(1.5)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        assertTrue(RoofMeshBuilder.build(project).triangles.isNotEmpty())
    }
}
