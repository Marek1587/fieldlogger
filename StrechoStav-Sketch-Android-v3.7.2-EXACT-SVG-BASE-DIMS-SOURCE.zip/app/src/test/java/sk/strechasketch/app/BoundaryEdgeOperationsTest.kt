package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BoundaryEdgeOperationsTest {
    private val origin = GeoPoint(49.0, 18.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    @Test
    fun splitMiddleEdgePreservesTypesAndShiftsFollowingMappings() {
        val polygon = listOf(geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 8.0), geo(0.0, 8.0))
        val result = BoundaryEdgeOperations.splitAtMidpoint(
            polygon,
            mapOf(0 to LineType.GABLE, 1 to LineType.ATTIC, 2 to LineType.PULT, 3 to LineType.WALL_END),
            1
        )

        assertNotNull(result)
        result!!
        assertEquals(5, result.polygon.size)
        assertEquals(2, result.insertedVertexIndex)
        assertEquals(LineType.ATTIC, result.edgeTypes[1])
        assertEquals(LineType.ATTIC, result.edgeTypes[2])
        assertEquals(LineType.PULT, result.edgeTypes[3])
        assertEquals(LineType.WALL_END, result.edgeTypes[4])
        assertEquals(4.0, Geometry.distanceM(polygon[1], result.polygon[2]), 0.01)
        assertEquals(4.0, Geometry.distanceM(result.polygon[2], polygon[2]), 0.01)
    }

    @Test
    fun splitClosingEdgeAppendsVertexAndPreservesClosingTypeTwice() {
        val polygon = listOf(geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 6.0), geo(0.0, 6.0))
        val result = BoundaryEdgeOperations.splitAtMidpoint(
            polygon,
            mapOf(0 to LineType.GABLE, 3 to LineType.EAVE),
            3
        )!!

        assertEquals(4, result.insertedVertexIndex)
        assertEquals(LineType.EAVE, result.edgeTypes[3])
        assertEquals(LineType.EAVE, result.edgeTypes[4])
        assertTrue(Geometry.distanceM(polygon[3], result.polygon[4]) > 2.9)
        assertEquals(3.0, Geometry.distanceM(polygon[3], result.polygon[4]), 0.01)
    }

    @Test
    fun removeVertexPreservesUnaffectedBoundaryTypes() {
        val polygon = listOf(
            geo(0.0, 0.0), geo(5.0, 0.0), geo(10.0, 0.0),
            geo(10.0, 8.0), geo(0.0, 8.0)
        )
        val result = BoundaryEdgeOperations.removeVertex(
            polygon,
            mapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE, 2 to LineType.GABLE,
                3 to LineType.PULT, 4 to LineType.WALL_END
            ),
            1
        )!!

        assertEquals(4, result.polygon.size)
        assertEquals(LineType.EAVE, result.edgeTypes[0])
        assertEquals(LineType.GABLE, result.edgeTypes[1])
        assertEquals(LineType.PULT, result.edgeTypes[2])
        assertEquals(LineType.WALL_END, result.edgeTypes[3])
    }
}
