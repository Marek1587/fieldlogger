package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class RoofPlaneSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun graph(nodes: List<TopologyNode>, edges: List<TopologyEdge>) =
        RoofGraphFactory.fromTopology(RoofTopology(origin, nodes, edges))

    @Test
    fun gableNetworkCreatesTwoPlanesWithoutRoofShapePreset() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 10.0, 0.0), node("R", 10.0, 3.0),
            node("C", 10.0, 6.0), node("D", 0.0, 6.0), node("L", 0.0, 3.0)
        )
        val edges = listOf(
            edge("AB", "A", "B", LineType.EAVE, true),
            edge("BR", "B", "R", LineType.GABLE, true),
            edge("RC", "R", "C", LineType.GABLE, true),
            edge("CD", "C", "D", LineType.EAVE, true),
            edge("DL", "D", "L", LineType.GABLE, true),
            edge("LA", "L", "A", LineType.GABLE, true),
            edge("RIDGE", "L", "R", LineType.RIDGE, false)
        )
        val solution = RoofPlaneSolver.solve(graph(nodes, edges), 3.0, 30.0)

        assertEquals(2, solution.graph.faces.size)
        assertEquals(solution.graph.nodes.getValue("L").z, solution.graph.nodes.getValue("R").z, 1e-8)
        assertTrue(solution.graph.nodes.getValue("L").z > 3.0)
        assertCoplanar(solution.graph)
    }

    @Test
    fun hipNetworkCreatesFourFacesSharingOneApexNode() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 8.0, 0.0), node("C", 8.0, 8.0),
            node("D", 0.0, 8.0), node("O", 4.0, 4.0, boundary = false)
        )
        val edges = listOf(
            edge("AB", "A", "B", LineType.EAVE, true), edge("BC", "B", "C", LineType.EAVE, true),
            edge("CD", "C", "D", LineType.EAVE, true), edge("DA", "D", "A", LineType.EAVE, true),
            edge("AO", "A", "O", LineType.HIP, false), edge("BO", "B", "O", LineType.HIP, false),
            edge("CO", "C", "O", LineType.HIP, false), edge("DO", "D", "O", LineType.HIP, false)
        )
        val solution = RoofPlaneSolver.solve(graph(nodes, edges), 3.0, 25.0)

        assertEquals(4, solution.graph.faces.size)
        assertEquals(4, solution.graph.faces.values.count { "O" in it.orderedNodeIds })
        assertTrue(solution.graph.nodes.getValue("O").z > 3.0)
        assertCoplanar(solution.graph)
    }

    @Test
    fun measuredOffCenterHipUsesWatertightRenderingApproximation() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 8.0, 0.0), node("C", 8.0, 8.0),
            node("D", 0.0, 8.0), node("O", 4.8, 3.5, boundary = false)
        )
        val edges = listOf(
            edge("AB", "A", "B", LineType.EAVE, true), edge("BC", "B", "C", LineType.EAVE, true),
            edge("CD", "C", "D", LineType.EAVE, true), edge("DA", "D", "A", LineType.EAVE, true),
            edge("AO", "A", "O", LineType.HIP, false), edge("BO", "B", "O", LineType.HIP, false),
            edge("CO", "C", "O", LineType.HIP, false), edge("DO", "D", "O", LineType.HIP, false)
        )
        val input = graph(nodes, edges)
        val exact = RoofPlaneSolver.solve(input, 3.0, 25.0)
        val rendering = RoofPlaneSolver.solveForRendering(input, 3.0, 25.0)

        assertTrue(exact.hasBlockingIssues)
        assertTrue(rendering.issues.joinToString { it.code }, !rendering.hasBlockingIssues)
        assertTrue(rendering.issues.any { it.code == "APPROXIMATED_HARD_CONSTRAINTS" })
        assertTrue(rendering.graph.nodes.values.all { it.z.isFinite() })
        assertEquals(input.edges.keys, rendering.graph.edges.keys)
    }

    @Test
    fun explicitSlopeConstraintOverridesProjectFallback() {
        val base = graph(
            listOf(node("A", 0.0, 0.0), node("B", 10.0, 0.0), node("C", 10.0, 5.0), node("D", 0.0, 5.0)),
            listOf(
                edge("AB", "A", "B", LineType.EAVE, true), edge("BC", "B", "C", LineType.GABLE, true),
                edge("CD", "C", "D", LineType.GABLE, true), edge("DA", "D", "A", LineType.GABLE, true)
            )
        )
        val face = base.faces.values.single()
        val constrained = base.copy(faces = base.faces + (face.id to face.copy(
            slopeConstraint = FaceSlopeConstraint(0.0, 0.0, 1.0)
        )))
        val solution = RoofPlaneSolver.solve(constrained, 3.0, 40.0)
        assertEquals(0.0, solution.graph.faces.getValue(face.id).plane!!.a, 1e-12)
        assertEquals(0.0, solution.graph.faces.getValue(face.id).plane!!.b, 1e-12)
        assertCoplanar(solution.graph)
    }

    @Test
    fun halfHipTopologyCreatesThreeFacesWithoutHalfHipPreset() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 10.0, 0.0), node("R", 10.0, 3.0),
            node("C", 10.0, 6.0), node("D", 0.0, 6.0), node("O", 3.0, 3.0, boundary = false)
        )
        val edges = listOf(
            edge("AB", "A", "B", LineType.EAVE, true), edge("BR", "B", "R", LineType.GABLE, true),
            edge("RC", "R", "C", LineType.GABLE, true), edge("CD", "C", "D", LineType.EAVE, true),
            edge("DA", "D", "A", LineType.EAVE, true), edge("OR", "O", "R", LineType.RIDGE, false),
            edge("AO", "A", "O", LineType.HIP, false), edge("DO", "D", "O", LineType.HIP, false)
        )
        val solution = RoofPlaneSolver.solve(graph(nodes, edges), 3.0, 22.0)
        assertEquals(3, solution.graph.faces.size)
        assertCoplanar(solution.graph)
    }

    @Test
    fun concaveLNetworkCreatesSixConnectedFacesFromGraphOnly() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 8.0, 0.0), node("C", 8.0, 4.0),
            node("D", 4.0, 4.0), node("E", 4.0, 8.0), node("F", 0.0, 8.0),
            node("O", 2.0, 2.0, boundary = false)
        )
        val boundary = listOf("A", "B", "C", "D", "E", "F")
        val edges = mutableListOf<TopologyEdge>()
        boundary.indices.forEach { i ->
            edges += edge("B$i", boundary[i], boundary[(i + 1) % boundary.size], LineType.EAVE, true)
            edges += edge("I$i", boundary[i], "O", LineType.HIP, false)
        }
        val solution = RoofPlaneSolver.solve(graph(nodes, edges), 3.0, 15.0)
        assertEquals(6, solution.graph.faces.size)
        assertEquals(6, solution.graph.faces.values.count { "O" in it.orderedNodeIds })
        assertTrue(solution.graph.nodes.keys.size == 7)
    }

    @Test
    fun flatAndPitchedFacesCoexistInOneConnectedGraph() {
        val nodes = listOf(
            node("A", 0.0, 0.0), node("B", 10.0, 0.0), node("R", 10.0, 3.0),
            node("C", 10.0, 6.0), node("D", 0.0, 6.0), node("L", 0.0, 3.0)
        )
        val base = graph(nodes, listOf(
            edge("AB", "A", "B", LineType.EAVE, true), edge("BR", "B", "R", LineType.GABLE, true),
            edge("RC", "R", "C", LineType.GABLE, true), edge("CD", "C", "D", LineType.GABLE, true),
            edge("DL", "D", "L", LineType.GABLE, true), edge("LA", "L", "A", LineType.GABLE, true),
            edge("LR", "L", "R", LineType.WALL_END, false)
        ))
        val topFace = base.faces.values.maxBy { face ->
            face.orderedNodeIds.map { base.nodes.getValue(it).y }.average()
        }
        val interfaceHeight = 3.0 + kotlin.math.tan(Math.toRadians(30.0)) * 3.0
        val constrained = base.copy(faces = base.faces + (topFace.id to topFace.copy(
            slopeConstraint = FaceSlopeConstraint(0.0, 0.0, 1.0),
            elevationConstraints = listOf(
                ElevationConstraint(nodeId = "L", elevationZ = interfaceHeight),
                ElevationConstraint(nodeId = "R", elevationZ = interfaceHeight)
            )
        )))
        val solution = RoofPlaneSolver.solve(constrained, 3.0, 30.0)
        assertEquals(2, solution.graph.faces.size)
        assertEquals(0.0, solution.graph.faces.getValue(topFace.id).plane!!.a, 1e-12)
        assertEquals(0.0, solution.graph.faces.getValue(topFace.id).plane!!.b, 1e-12)
        assertCoplanar(solution.graph)
    }

    private fun assertCoplanar(graph: RoofGraph) {
        graph.faces.values.forEach { face ->
            val plane = face.plane ?: error("Missing plane ${face.id}")
            face.orderedNodeIds.forEach { nodeId ->
                val node = graph.nodes.getValue(nodeId)
                assertTrue("${face.id}/$nodeId residual", abs(node.z - plane.zAt(node.x, node.y)) < 1e-5)
            }
        }
    }

    private fun node(id: String, x: Double, y: Double, boundary: Boolean = true) = TopologyNode(
        id, x, y, if (boundary) TopologyNodeType.FOOTPRINT else TopologyNodeType.JUNCTION
    )

    private fun edge(id: String, a: String, b: String, type: LineType, boundary: Boolean) =
        TopologyEdge(id, a, b, type, boundary = boundary)
}
