# Technické poznámky 3.7.1 - hĺbkový raster pre PDF

## Príčina chyby

Pôvodný statický renderer zoradil celé trojuholníky podľa priemernej hĺbky a potom cez hotový obraz nakreslil všetky technické hrany. Pri navzájom sa prekrývajúcich stenách a strešných plochách neexistuje jedno správne poradie celých trojuholníkov. Zadné hrany sa navyše kreslili bez testu viditeľnosti, takže výsledok pôsobil ako transparentný drôtený model.

## Softvérový Z-buffer

`SoftwareDepthRasterizer` obsahuje farebný raster a `FloatArray` hĺbok s jednou hodnotou pre každý pixel. Perspektívna projekcia odovzdáva `1 / cameraW`, ktoré sa lineárne interpoluje v obrazovkovom priestore. Väčšia hodnota znamená bližší fragment.

Každý strešný alebo stenový trojuholník rasterizuje ohraničujúci obdĺžnik a barycentrické súradnice stredov pixelov. Farba sa zapíše iba vtedy, keď je fragment bližšie než dovtedy uložená plocha. Výsledok preto nezávisí od poradia trojuholníkov a zostáva správny aj pri konkávnom L/T/K pôdoryse.

## Hrany a logo

Technická hrana interpoluje rovnakú inverznú hĺbku a používa iba malý bias proti numerickému kmitaniu na vlastnej ploche. Hrana za bližšou stenou alebo strechou sa zahodí pixel po pixeli.

Logo sa perspektívne vykreslí do transparentnej pomocnej bitmapy. Jeho dva trojuholníky následne kompozitujú iba fragmenty, ktoré prejdú Z-testom. Logo preto nepresvitne cez prednú strešnú plochu.

Kótovacie štítky zostávajú samostatnou technickou anotáciou po dokončení 3D rastra. Samotný model, materiály a konštrukčné hrany sú však plne hĺbkovo testované.

## Výkon a regresia

PDF používa obrázky najviac 1400 x 1400 pixelov. Raster preto drží približne 7,8 MB pre farby a 7,8 MB pre hĺbku, čo je vhodné aj pre bežný mobilný telefón. Sada 53 testov zahŕňa plochy odovzdané v nesprávnom poradí aj čiaru ukrytú za nepriehľadnou stenou.
