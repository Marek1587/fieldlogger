# Technické poznámky 3.7.0 – pôdorys stien a úplnosť L/K strechy

## Dva obrysy, dve úlohy

Hranica `RoofGraph` opisuje odkvap alebo vonkajšiu hranicu strechy. `wallFootprint` opisuje pôdorys nosných obvodových stien. Pôdorysné dĺžkové kóty sa preto vytvárajú na hornej hrane stien a presah je samostatná kolmá vzdialenosť medzi oboma obrysmi.

Uložený `wallFootprint` sa použije iba vtedy, ak má rovnaký počet vrcholov ako aktuálna hranica, primeranú plochu a všetky body ležia v strešnom polygóne alebo na jeho hranici. Následne sa cyklus otočí a posunie tak, aby jeho segmenty deterministicky zodpovedali obvodovým `EdgeId`. Pri nezhode sa bezpečne použije aktuálna hranica bez presahu; používateľ môže následne nastaviť jedno uniformné odsadenie.

## Jedna kóta presahu

Všetky geometrické umiestnenia presahu majú spoločné `dimensionId = roof-overhang` a spoločnú mediánovú hodnotu. Projekcia vyberie iba viditeľného kandidáta. Kliknutie preto vždy mení jeden projektový parameter cez konštantné polygonálne odsadenie, vrátane miernych L/T/H/K tvarov.

## Audit úplnosti plôch

`Roof3DPreparation` porovnáva súčet plôch extrahovaných buniek s plochou celej usporiadanej hranice. Konzervatívne uzatvorenie iba časti pôdorysu nie je úspech. Pri pokrytí menšom než 99,5 % sa spustí odvodený topologický priechod s maximálnym posunom 10 % referenčnej dĺžky. Výsledok sa prijme iba vtedy, keď plošné pokrytie reálne zlepší.

## Orientácia plôch a loga

Každý strešný trojuholník je pri tvorbe mesh siete preorientovaný normálou nahor. Logo používa kanonický smer najdlhšej hrany, takže opačný smer topologického cyklu už nevytvorí zrkadlový nápis. OpenGL aj statický Kotlin renderer naďalej používajú rovnaké štyri body loga.

## Regresia

Sada 51 testov zahŕňa šesťbodový konkávny pôdorys so zastaraným štvorbodovým `wallFootprint`, pôdorysné rozmery 11 × 7 m odvodené zo stien v streche 12 × 8 m a jediný spoločný presah 0,5 m.
