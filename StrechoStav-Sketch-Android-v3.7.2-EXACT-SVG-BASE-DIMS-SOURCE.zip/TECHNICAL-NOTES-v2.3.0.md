# Technické poznámky StrechoStav Sketch 2.3.0

## Odstránené príčiny problémov

Blikanie ortofotomapy spôsobovalo priebežné prekresľovanie neúplnej sady dlaždíc
a zmiešanie rastra s geometriou. Renderer teraz používa aktívnu a pripravovanú
vrstvu. Nová vrstva sa odkryje až po dosiahnutí prahu pripravenosti a stará zostane
pod ňou až do úplného načítania. Požiadavky sú deduplikované a tie, ktoré už nie sú
potrebné, sa zrušia.

Nespojené hrebene, úžľabia a nárožia spôsoboval pôvodný model nezávislých úsečiek.
Projekt má preto paralelný topologický graf stabilných uzlov a hrán. Legacy polia
`polygon` a `lines` zostali zachované pre výkaz a spätnú kompatibilitu.

Chybné 3D konkávnych pôdorysov spôsobovala globálna Delaunay triangulácia filtrovaná
iba ťažiskom a triangle fan. Automatický režim teraz používa plochy extrahované z
topologického grafu; ploché a pultové plochy používajú deterministický ear clipping.

## Migrácia dát

- Nový export: `schema = strechostav-sketch-project-3`, `schema_version = 3`.
- Nové pole `roof_topology` obsahuje lokálny počiatok, uzly, hrany, typy a zámky.
- Starší JSON bez topológie sa načíta bez prepisu súboru a graf sa odvodí v pamäti.
- Potvrdenie solvera synchronizuje graf späť do existujúcich `polygon`, `edgeTypes`
  a `lines`, takže výkaz a staršie výpočty ostávajú funkčné.

## Tolerancie solvera

- zlúčenie uzlov: 0,05 m,
- prichytenie voľného konca: 0,35 m,
- minimálna dĺžka hrany: 0,01 m,
- výber bodu v editore: 22 dp; táto obrazovková tolerancia nemení modelovú presnosť.

Solver je deterministický: merge, priesečníky, snap, opakované rozdelenie,
odstránenie krátkych a duplicitných hrán, normalizácia, validácia a extrakcia plôch.

## Overenie

Jednotkové testy pokrývajú kríženie hrebeňa s úžľabím, zlúčenie blízkych koncov,
konkávny L-pôdorys a JSON regresiu vstupov výkazu. GitHub Actions najprv spustí
`testDebugUnitTest` a APK vytvorí iba po ich úspechu.

## Zostávajúce obmedzenia

Ide o presný 2D/topologický základ, nie certifikovaný geodetický alebo statický
výpočet. IFC, SketchUp a fotogrametrický export zatiaľ nie sú súčasťou verzie 2.3.0.
Automatická výška zložitých strešných plôch je geometrická aproximácia podľa sklonu
a označených línií; pred výrobou treba rozmery a výšky overiť na stavbe. Zámky sú
uložené v topologickom JSON, no samostatné používateľské UI na zamykanie bude
doplnené v ďalšej verzii.
