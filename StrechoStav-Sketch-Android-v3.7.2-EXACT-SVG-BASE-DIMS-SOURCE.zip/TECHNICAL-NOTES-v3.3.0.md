# StrechoStav Sketch 3.3.0 – technické výkresy a 3D vizuál

## STN renderer pôdorysu

`StnRoofPlanRenderer` je samostatný deterministický Canvas renderer. Pracuje priamo s uloženým
`RoofProject` a s kanonickým `RoofGraph`; nevytvára výkres zo snímky obrazovky.

Použité kresliace zásady:

- biely papier a čiernobiela technická grafika,
- hrubá plná čiara pre dokončený obrys strechy,
- stredne hrubé plné čiary pre hrebene, nárožia, úžľabia a pultové hrany,
- tenké čiary pre kóty, vynášacie čiary, značky a vnútorné členenie plôch,
- bodkočiarkovaný obrys muriva pod strechou,
- kóty mimo geometrie, 45-stupňové koncové značky a hodnoty v milimetroch,
- natočenie kótovacích textov do čitateľného intervalu,
- automatická voľba štandardnej mierky a kompaktný titulný blok,
- samostatné značky pre komín, strešné okno, výlez, prestup, výškovú kótu a smer sklonu.

Renderer sa používa v PDF. SVG export má rovnakú monochromatickú hierarchiu a bodkočiarkovaný
obrys muriva. Farebné sémantické čiary zostávajú iba v interaktívnom editore, kde sú dôležité
pre bezpečné dotykové ovládanie.

Ide o implementáciu vizuálnych kresliacich zásad z dodaného podkladu STN 01 3420. Samotná
aplikácia tým nenahrádza autorizovanú projektovú dokumentáciu ani úplnú kontrolu všetkých
požiadaviek príslušných noriem pre konkrétnu stavbu.

## Zjednotený 3D vizuál

- Interaktívny model zostáva v `GLSurfaceView` a OpenGL ES 3.0.
- GLSL shadery zostávajú ako textové konštanty priamo v Kotlin súbore.
- Strecha používa antracitový minerálny charakter, jemný procedurálny detail a výraznejšie
  oddelenie sklonov jednotlivých plôch.
- Steny sú neutrálne svetlé a všetky konštrukčné hrany majú ostrý tmavý technický obrys.
- Statický `RoofBitmapRenderer` používaný v zozname a PDF má rovnakú paletu a svetelnú logiku,
  ale nevyžaduje otvorenie OpenGL obrazovky.

## Geometrická bezpečnosť

Táto verzia nemení solver, uzly, hrany, `FaceId`, rovnice rovín `z = a*x + b*y + c`, výpočet
3D plôch, dĺžok ani výkaz výmer. Mení sa iba prezentačná vrstva.

## Overenie

- `:app:compileDebugKotlin` – úspešné,
- `:app:testDebugUnitTest` – 42 testov, 0 zlyhaní,
- `:app:assembleDebug` – úspešné.
