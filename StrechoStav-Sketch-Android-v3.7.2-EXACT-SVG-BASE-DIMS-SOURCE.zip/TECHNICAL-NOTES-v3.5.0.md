# Technické poznámky 3.5.0

## Materiály a svetlo

`RoofMesh.materials` nesie samostatný materiálový príznak pre každý vrchol. GLSL shader
preto nerozoznáva strechu a stenu podľa normály po transformácii. Antracit používa
pevnú materiálovú mikrovariáciu a rotačný svetelný koeficient 0,97–1,03; ich spoločný
rozsah zostáva menší než 10 %. Mikrovariácia číta pôvodnú pozíciu vrcholu, takže pri
otáčaní nepláva. Steny používajú samostatnú svetlobéžovú paletu.

## Firemné označenie

`RoofMeshBuilder` zoradí plochy podľa pôdorysnej plochy a na dve najväčšie pridá
vektorový nápis `STRECHOSTAV`. Logo pozostáva z čiar ukotvených do roviny plochy
a mierne zdvihnutých proti z-fightingu. OpenGL používa samostatný VBO; statický
Kotlin renderer číta rovnaké `logoEdges`.

## Interaktívne kóty

Každá obvodová `EdgeId` vytvára `RoofDimension3D` s kótovacou a vynášacou čiarou.
`Roof3DRenderer` premieta body tou istou MVP maticou ako mesh. `Roof3DDimensionOverlay`
kreslí štítky a uchováva iba ich dotykové obdĺžniky; dotyk mimo nich prepustí do
`GLSurfaceView`. Kliknutie otvorí `NumberPicker` s krokom 50 mm. Živý náhľad volá
`ParametricEditSolver.setEdgeLength`, znovu rieši výšky a zachováva množiny NodeId,
EdgeId a FaceId. Potvrdenie vytvorí jeden Undo krok, zrušenie obnoví pôvodný graf.
