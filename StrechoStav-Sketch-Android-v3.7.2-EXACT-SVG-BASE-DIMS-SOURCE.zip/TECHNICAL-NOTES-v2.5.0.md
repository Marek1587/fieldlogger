# Technické poznámky StrechoStav Sketch 2.5.0

## Polvalba a obvodové hrany

Automatický 3D model používa samostatné topologické plochy. Pre polvalbu s
hrebeňom napojeným na štít a dvoma nárožiami solver deterministicky vytvorí tri
plochy. Výška automatickej strechy sa počíta od hrán typu `EAVE`. Hrany `GABLE`,
`PULT`, `ATTIC` a `WALL_END` neznižujú zvýšený koniec hrebeňa na výšku muriva.
Ak starší projekt nemá žiadnu odkvapovú hranu, zachová sa kompatibilný výpočet
od všetkých obvodových hrán.

Typ obvodovej hrany možno nastaviť priamo dlhým podržaním. Zmena prechádza cez
editorovú transakciu, invaliduje uloženú topológiu a následne sa prejaví v 2D,
solveri, 3D modeli aj vo výkaze.

## Korekcia geometrie

Predchádzajúca príprava solvera pravouhlila obrys bez rovnakej transformácie
vnútorných čiar. To mohlo odpojiť konce hrebeňov a nároží od hranice. Verzia
2.5.0 zachováva používateľský pôdorys a solver upravuje iba topologické spojenia,
priesečníky, krátke hrany a duplicity. Skutočne neuzavretá geometria zostáva
blokovaná pred 3D, ale bežná platná polvalba už nevyžaduje ručné obchádzanie.

## Regresné overenie

- polvalba vytvorí presne tri platné uzavreté plochy,
- bod hrebeňa na štíte má rovnakú výškovú vzdialenosť od odkvapu ako vnútorný
  bod hrebeňa,
- bod na odkvape zostáva na nulovej relatívnej výške,
- staré projekty bez explicitných typov hrán používajú kompatibilný fallback.
