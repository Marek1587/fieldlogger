# Technické poznámky 3.4.0

## Korekcia na karte 2

`ConservativeInternalLineSolver` je oddelený od všeobecného `RoofTopologySolver.solve`.
Zachováva množinu `EdgeId`, nikdy nevytvára `NodeId`, nedelí priesečníky a nepohybuje
uzlami obrysu. Povolené je iba deterministické zlúčenie existujúcich blízkych koncov
a pohyb vnútorných uzlov. Hrebeň sa koriguje len pri odchýlke najviac 10° od smeru
obvodu. Nárožie a úžľabie sa korigujú na ±45° voči incidentnej obvodovej hrane.
Po korekcii sa každá vnútorná hrana kontroluje proti pôvodnej dĺžke v intervale
90–110 %.

## Robustná príprava 3D

`Roof3DPreparation` je jediná vstupná cesta pre živé 3D, statický bitmapový renderer,
PDF a výkaz. Najprv použije konzervatívne spojenie existujúcich uzlov. Všeobecný
topologický pass sa spustí iba vtedy, keď graf nemá žiadnu uzavretú plochu, pričom
limit XY korekcie sa odvodí ako 10 % mierky hrán.

`RoofPlaneSolver.solve` zostáva presným auditným RREF solverom. Nový
`solveForRendering` sa použije iba po zlyhaní presného systému. Rieši spoločné výšky
uzlov a konštanty rovín váženou metódou najmenších štvorcov s deterministickým
Tikhonovovým priorom. Pevné nízke výšky majú vyššiu váhu, všetky incidentné plochy
však stále zdieľajú jedinú hodnotu `Node.z`, takže mesh je vodotesný. Aproximácia
je zapísaná ako neblokujúci problém `APPROXIMATED_HARD_CONSTRAINTS`.

## Kompatibilita

Dátová schéma JSON sa nemení. Staré projekty sa načítajú bez migrácie. Presný audit
si zachováva pôvodné blokujúce správanie; robustný režim je obmedzený na odvodený
3D model, výkaz, bitmapu/PDF a parametrickú editáciu rozmerov.
