# Technické poznámky StrechoStav Sketch 2.6.0

## Geometrická korekcia podľa PHP

Funkcia `Skorigovať` používa rovnaký princíp ako `regularizePolygonLocal` v
`ai_strecha.php`. Najdlhšia obvodová hrana určí dominantnú os. Každá obvodová
hrana dostane smer z množiny dominantná os, kolmica alebo ±45°. Korekčná priamka
prechádza pôvodným stredom hrany a nový roh je priesečníkom dvoch susedných
priamok. Posun jedného bodu je obmedzený na 4 m a výsledok sa odmietne pri
samopretínaní alebo neprimeranej zmene plochy.

Najskôr sa zlúčia a prichytia spoločné uzly. Preto sa pri pohybe opraveného rohu
presunú aj konce strešných línií, ktoré sú na tento uzol pripojené. Nárožia pri
konvexných rohoch a úžľabia pri konkávnych rohoch sa následne riešia ako presné
45° väzby voči pripojenej odkvapovej hrane. Spoločný vnútorný uzol viacerých
diagonál sa rieši jedným deterministickým priesečníkom.

Uhlová korekcia sa vykonáva iba cez používateľskú akciu `Skorigovať`. Bežná
validácia pred 3D nesmie potichu meniť obrys, aby zostali steny a strešné plochy
v rovnakej geometrii.

Ak je vonkajší obrys uzavretý, používateľ môže potvrdiť bezpečne vykonané opravy
aj vtedy, keď jedna rozpracovaná vnútorná línia ešte nevytvára uzavretú plochu.
Neplatná výsledná topológia sa neuloží ako hotový 3D graf a 3D zostáva blokované,
kým používateľ zostávajúcu líniu nedopojí.

## Výber a úprava hrán

Výber obvodovej hrany uchováva index hrany a povoľuje hit-test iba jej dvoch
koncových vrcholov. Výber vnútornej línie analogicky povoľuje iba jej `START` a
`END`. Ostatné obvodové body sú pri aktívnej hrane vizuálne stlmené.

Kontextová operácia `Pridať bod` vloží geodetický stred segmentu, posunie indexy
nasledujúcich typov hrán a priradí pôvodný typ obom novým segmentom. Operácia je
jeden Undo krok. Odstránenie bodu zachová typy všetkých neovplyvnených hrán.

## Mapová kompatibilita

OpenTopoMap/OSM terén už nie je používateľská voľba. Hodnoty `OSM_TERRAIN` a
`TERRAIN` zo starších JSON projektov sa pri otvorení mapy normalizujú na `OSM`.
