package sk.strechostav.roofmeasure.math

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class MathTest {
    @Test
    fun rigidTransformRoundTrip() {
        val transform = RigidTransform3(translation = Vector3(3.0, -2.0, 7.0))
        val point = Vector3(1.0, 2.0, 3.0)
        assertTrue(transform.inverse().transformPoint(transform.transformPoint(point)).isNear(point, 1e-12))
    }

    @Test
    fun matrixInverse() {
        val matrix = Matrix3.diagonal(2.0, 4.0, 5.0)
        val result = matrix.inverse() * Vector3(2.0, 8.0, 15.0)
        assertEquals(Vector3(1.0, 2.0, 3.0), result)
    }
}
