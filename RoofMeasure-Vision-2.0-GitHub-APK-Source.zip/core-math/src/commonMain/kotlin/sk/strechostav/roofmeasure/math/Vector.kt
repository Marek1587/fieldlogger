package sk.strechostav.roofmeasure.math

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

private const val EPSILON = 1e-12

data class Vector2(val x: Double, val y: Double) {
    operator fun plus(other: Vector2) = Vector2(x + other.x, y + other.y)
    operator fun minus(other: Vector2) = Vector2(x - other.x, y - other.y)
    operator fun times(scale: Double) = Vector2(x * scale, y * scale)
    operator fun div(scale: Double) = Vector2(x / scale, y / scale)
    fun dot(other: Vector2): Double = x * other.x + y * other.y
    fun cross(other: Vector2): Double = x * other.y - y * other.x
    fun squaredNorm(): Double = dot(this)
    fun norm(): Double = sqrt(squaredNorm())
    fun distanceTo(other: Vector2): Double = (this - other).norm()
    fun normalized(): Vector2 {
        val n = norm()
        require(n > EPSILON) { "Cannot normalize a zero-length Vector2" }
        return this / n
    }

    fun isFinite(): Boolean = x.isFinite() && y.isFinite()
}

data class Vector3(val x: Double, val y: Double, val z: Double) {
    operator fun plus(other: Vector3) = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun minus(other: Vector3) = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun unaryMinus() = Vector3(-x, -y, -z)
    operator fun times(scale: Double) = Vector3(x * scale, y * scale, z * scale)
    operator fun div(scale: Double) = Vector3(x / scale, y / scale, z / scale)
    fun dot(other: Vector3): Double = x * other.x + y * other.y + z * other.z
    fun cross(other: Vector3): Vector3 = Vector3(
        y * other.z - z * other.y,
        z * other.x - x * other.z,
        x * other.y - y * other.x,
    )

    fun squaredNorm(): Double = dot(this)
    fun norm(): Double = sqrt(squaredNorm())
    fun distanceTo(other: Vector3): Double = (this - other).norm()
    fun normalized(): Vector3 {
        val n = norm()
        require(n > EPSILON) { "Cannot normalize a zero-length Vector3" }
        return this / n
    }

    fun angleTo(other: Vector3): Double {
        val denominator = norm() * other.norm()
        require(denominator > EPSILON) { "Angle is undefined for a zero-length vector" }
        return acos((dot(other) / denominator).coerceIn(-1.0, 1.0))
    }

    fun isNear(other: Vector3, tolerance: Double): Boolean = distanceTo(other) <= tolerance
    fun isFinite(): Boolean = x.isFinite() && y.isFinite() && z.isFinite()

    companion object {
        val ZERO = Vector3(0.0, 0.0, 0.0)
        val X = Vector3(1.0, 0.0, 0.0)
        val Y = Vector3(0.0, 1.0, 0.0)
        val Z = Vector3(0.0, 0.0, 1.0)
    }
}

fun Double.nearlyEquals(other: Double, tolerance: Double = 1e-9): Boolean =
    abs(this - other) <= tolerance
