package sk.strechostav.roofmeasure.math

import kotlin.math.abs

data class Matrix3(
    val m00: Double, val m01: Double, val m02: Double,
    val m10: Double, val m11: Double, val m12: Double,
    val m20: Double, val m21: Double, val m22: Double,
) {
    operator fun times(v: Vector3) = Vector3(
        m00 * v.x + m01 * v.y + m02 * v.z,
        m10 * v.x + m11 * v.y + m12 * v.z,
        m20 * v.x + m21 * v.y + m22 * v.z,
    )

    operator fun times(other: Matrix3) = Matrix3(
        row(0).dot(other.column(0)), row(0).dot(other.column(1)), row(0).dot(other.column(2)),
        row(1).dot(other.column(0)), row(1).dot(other.column(1)), row(1).dot(other.column(2)),
        row(2).dot(other.column(0)), row(2).dot(other.column(1)), row(2).dot(other.column(2)),
    )

    fun transpose() = Matrix3(m00, m10, m20, m01, m11, m21, m02, m12, m22)

    fun determinant(): Double =
        m00 * (m11 * m22 - m12 * m21) -
            m01 * (m10 * m22 - m12 * m20) +
            m02 * (m10 * m21 - m11 * m20)

    fun inverse(): Matrix3 {
        val determinant = determinant()
        require(abs(determinant) > 1e-12) { "Matrix is singular" }
        val inverseDeterminant = 1.0 / determinant
        return Matrix3(
            (m11 * m22 - m12 * m21) * inverseDeterminant,
            (m02 * m21 - m01 * m22) * inverseDeterminant,
            (m01 * m12 - m02 * m11) * inverseDeterminant,
            (m12 * m20 - m10 * m22) * inverseDeterminant,
            (m00 * m22 - m02 * m20) * inverseDeterminant,
            (m02 * m10 - m00 * m12) * inverseDeterminant,
            (m10 * m21 - m11 * m20) * inverseDeterminant,
            (m01 * m20 - m00 * m21) * inverseDeterminant,
            (m00 * m11 - m01 * m10) * inverseDeterminant,
        )
    }

    fun row(index: Int): Vector3 = when (index) {
        0 -> Vector3(m00, m01, m02)
        1 -> Vector3(m10, m11, m12)
        2 -> Vector3(m20, m21, m22)
        else -> error("Matrix row index must be 0..2")
    }

    fun column(index: Int): Vector3 = when (index) {
        0 -> Vector3(m00, m10, m20)
        1 -> Vector3(m01, m11, m21)
        2 -> Vector3(m02, m12, m22)
        else -> error("Matrix column index must be 0..2")
    }

    fun isFinite(): Boolean = (0..2).all { row(it).isFinite() }

    companion object {
        val IDENTITY = Matrix3(1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0)

        fun diagonal(x: Double, y: Double, z: Double) =
            Matrix3(x, 0.0, 0.0, 0.0, y, 0.0, 0.0, 0.0, z)

        fun fromColumns(x: Vector3, y: Vector3, z: Vector3) = Matrix3(
            x.x, y.x, z.x,
            x.y, y.y, z.y,
            x.z, y.z, z.z,
        )
    }
}

data class RigidTransform3(
    val rotation: Matrix3 = Matrix3.IDENTITY,
    val translation: Vector3 = Vector3.ZERO,
) {
    fun transformPoint(point: Vector3): Vector3 = rotation * point + translation
    fun transformDirection(direction: Vector3): Vector3 = rotation * direction
    fun inverse(): RigidTransform3 {
        val inverseRotation = rotation.transpose()
        return RigidTransform3(inverseRotation, -(inverseRotation * translation))
    }

    operator fun times(other: RigidTransform3) = RigidTransform3(
        rotation * other.rotation,
        transformPoint(other.translation),
    )
}

data class SimilarityTransform3(
    val scale: Double = 1.0,
    val rotation: Matrix3 = Matrix3.IDENTITY,
    val translation: Vector3 = Vector3.ZERO,
) {
    init { require(scale > 0.0 && scale.isFinite()) { "Scale must be positive and finite" } }

    fun transformPoint(point: Vector3): Vector3 = (rotation * point) * scale + translation
    fun transformDirection(direction: Vector3): Vector3 = rotation * direction
    fun inverse(): SimilarityTransform3 {
        val inverseRotation = rotation.transpose()
        val inverseScale = 1.0 / scale
        return SimilarityTransform3(inverseScale, inverseRotation, (inverseRotation * -translation) * inverseScale)
    }
}
