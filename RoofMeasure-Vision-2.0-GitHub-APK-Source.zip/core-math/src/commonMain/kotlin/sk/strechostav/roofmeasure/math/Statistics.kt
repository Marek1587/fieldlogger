package sk.strechostav.roofmeasure.math

import kotlin.math.abs
import kotlin.math.sqrt

object RobustStatistics {
    fun median(values: List<Double>): Double {
        require(values.isNotEmpty()) { "Median requires at least one value" }
        val sorted = values.sorted()
        val middle = sorted.size / 2
        return if (sorted.size % 2 == 1) sorted[middle] else (sorted[middle - 1] + sorted[middle]) / 2.0
    }

    fun medianAbsoluteDeviation(values: List<Double>): Double {
        val center = median(values)
        return median(values.map { abs(it - center) })
    }

    fun weightedMean(values: List<Double>, weights: List<Double>): Double {
        require(values.isNotEmpty() && values.size == weights.size)
        require(weights.all { it >= 0.0 && it.isFinite() })
        val sum = weights.sum()
        require(sum > 0.0)
        return values.indices.sumOf { values[it] * weights[it] } / sum
    }

    fun standardDeviation(values: List<Double>): Double {
        if (values.size < 2) return 0.0
        val mean = values.average()
        return sqrt(values.sumOf { (it - mean) * (it - mean) } / (values.size - 1))
    }
}

sealed interface RobustLoss {
    fun weight(normalizedResidual: Double): Double

    data class Huber(val delta: Double = 1.5) : RobustLoss {
        override fun weight(normalizedResidual: Double): Double {
            val absolute = abs(normalizedResidual)
            return if (absolute <= delta || absolute == 0.0) 1.0 else delta / absolute
        }
    }

    data class Cauchy(val scale: Double = 2.3849) : RobustLoss {
        override fun weight(normalizedResidual: Double): Double {
            val ratio = normalizedResidual / scale
            return 1.0 / (1.0 + ratio * ratio)
        }
    }
}
