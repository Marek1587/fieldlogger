package sk.strechostav.roofmeasure.teaching

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.math.Vector2

@Composable
fun LineTeachingOverlay(
    lines: List<TrackedStructuralLine>,
    pendingPolyline: List<Vector2>? = null,
    drawingEnabled: Boolean,
    onLineDrawn: (List<Vector2>) -> Unit,
    modifier: Modifier = Modifier,
) {
    var activePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    Canvas(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { canvasSize = it }
            .pointerInput(drawingEnabled, canvasSize) {
                if (!drawingEnabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { activePoints = listOf(it) },
                    onDrag = { change, _ ->
                        change.consume()
                        val last = activePoints.lastOrNull()
                        if (last == null || (change.position - last).getDistance() >= 4f) activePoints = activePoints + change.position
                    },
                    onDragEnd = {
                        if (activePoints.size >= 2 && canvasSize.width > 0 && canvasSize.height > 0) {
                            onLineDrawn(activePoints.map { Vector2(it.x.toDouble() / canvasSize.width, it.y.toDouble() / canvasSize.height) })
                        }
                        activePoints = emptyList()
                    },
                    onDragCancel = { activePoints = emptyList() },
                )
            },
    ) {
        lines.forEach { line ->
            val color = lineColor(line)
            val projected = line.currentProjection2D.map { Offset((it.x * size.width).toFloat(), (it.y * size.height).toFloat()) }
            if (projected.size >= 2) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(projected.first().x, projected.first().y)
                    projected.drop(1).forEach { lineTo(it.x, it.y) }
                }
                val dashed = line.lifecycle in setOf(LineLifecycle.CANDIDATE, LineLifecycle.LOST) || line.calibrationState == CalibrationState.RECOMMENDED
                drawPath(path, color, style = Stroke(width = 5f, cap = StrokeCap.Round, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(16f, 10f)) else null))
                drawCircle(color, 8f, projected.first())
                drawCircle(color, 8f, projected.last())
            }
        }
        if (activePoints.size >= 2) {
            val active = androidx.compose.ui.graphics.Path().apply {
                moveTo(activePoints.first().x, activePoints.first().y)
                activePoints.drop(1).forEach { lineTo(it.x, it.y) }
            }
            drawPath(active, Color(0xFFB36BFF), style = Stroke(width = 6f, cap = StrokeCap.Round))
        }
        pendingPolyline?.takeIf { it.size >= 2 }?.let { pending ->
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo((pending.first().x * size.width).toFloat(), (pending.first().y * size.height).toFloat())
                pending.drop(1).forEach { lineTo((it.x * size.width).toFloat(), (it.y * size.height).toFloat()) }
            }
            drawPath(path, Color(0xFFB36BFF), style = Stroke(width = 6f, cap = StrokeCap.Round))
        }
    }
}

@Composable
fun SemanticTypeSelector(
    selected: LineSemanticType,
    onSelected: (LineSemanticType) -> Unit,
    modifier: Modifier = Modifier,
) {
    val options = listOf(
        LineSemanticType.ROOF_OUTLINE,
        LineSemanticType.EAVE,
        LineSemanticType.RIDGE,
        LineSemanticType.HIP,
        LineSemanticType.VALLEY,
        LineSemanticType.CHIMNEY,
        LineSemanticType.ROOF_WINDOW,
        LineSemanticType.PARAPET,
        LineSemanticType.PENETRATION,
        LineSemanticType.AUXILIARY,
        LineSemanticType.UNKNOWN,
    )
    Row(
        modifier = modifier.background(Color(0xCC101614)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { type ->
            FilterChip(selected = type == selected, onClick = { onSelected(type) }, label = { Text(type.label()) })
        }
    }
}

fun LineSemanticType.label(): String = when (this) {
    LineSemanticType.ROOF_OUTLINE -> "Obrys"
    LineSemanticType.RIDGE -> "Hrebeň"
    LineSemanticType.EAVE -> "Odkvap"
    LineSemanticType.HIP -> "Nárožie"
    LineSemanticType.VALLEY -> "Úžľabie"
    LineSemanticType.CHIMNEY -> "Komín"
    LineSemanticType.ROOF_WINDOW -> "Strešné okno"
    LineSemanticType.GABLE_EDGE -> "Štít"
    LineSemanticType.PARAPET -> "Atika"
    LineSemanticType.PENETRATION -> "Prestup"
    LineSemanticType.BREAK_LINE -> "Lom"
    LineSemanticType.AUXILIARY -> "Pomocná"
    LineSemanticType.UNKNOWN -> "Neznáma"
}

private fun lineColor(line: TrackedStructuralLine): Color = when {
    line.lifecycle == LineLifecycle.CONFLICT -> Color(0xFFE53935)
    line.lifecycle == LineLifecycle.CANDIDATE -> Color(0xFFB0BEC5)
    line.calibrationState in setOf(CalibrationState.LASER_MEASURED, CalibrationState.REDUNDANTLY_VERIFIED, CalibrationState.LOCKED) -> Color(0xFF28C76F)
    line.calibrationState == CalibrationState.RECOMMENDED -> Color(0xFFFFA726)
    else -> Color(0xFF42A5F5)
}
