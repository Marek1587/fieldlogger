package sk.strechostav.roofmeasure.vision

import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.Timestamp
import sk.strechostav.roofmeasure.math.Vector2

data class VisionFrame(
    val id: EntityId,
    val width: Int,
    val height: Int,
    val grayscale: ByteArray,
    val timestamp: Timestamp,
) {
    init {
        require(width > 0 && height > 0)
        require(grayscale.size == width * height)
    }
}

data class LineCandidate(
    val id: EntityId,
    val start: Vector2,
    val end: Vector2,
    val gradientScore: Double,
    val continuityScore: Double,
    val temporalScore: Double,
    val semanticScore: Double,
    val depthScore: Double,
    val shadowProbability: Double,
    val combinedConfidence: Double,
    val suggestedType: LineSemanticType = LineSemanticType.UNKNOWN,
) {
    init {
        listOf(gradientScore, continuityScore, temporalScore, semanticScore, depthScore, shadowProbability, combinedConfidence)
            .forEach { require(it in 0.0..1.0) }
    }
}

data class FrameQuality(
    val sharpness: Double,
    val exposure: Double,
    val texture: Double,
    val trackingSuitable: Boolean,
    val userHint: String?,
)

interface LineCandidateDetector {
    suspend fun detect(frame: VisionFrame): List<LineCandidate>
}

interface VisionPipeline {
    suspend fun process(frame: VisionFrame): VisionResult
}

object VisionRuntime {
    @Volatile private var initialized: Boolean? = null
    @Synchronized fun initialize(): Boolean {
        initialized?.let { return it }
        return org.opencv.android.OpenCVLoader.initLocal().also { initialized = it }
    }
}

data class VisionResult(
    val frameId: EntityId,
    val quality: FrameQuality,
    val candidates: List<LineCandidate>,
    val processingMillis: Long,
)
