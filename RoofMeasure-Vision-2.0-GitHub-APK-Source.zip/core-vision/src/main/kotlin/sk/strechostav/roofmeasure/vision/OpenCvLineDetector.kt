package sk.strechostav.roofmeasure.vision

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.math.Vector2
import kotlin.math.hypot

class OpenCvLineCandidateDetector(
    private val cannyLow: Double = 60.0,
    private val cannyHigh: Double = 160.0,
    private val minimumLengthPixels: Double = 24.0,
) : LineCandidateDetector {
    override suspend fun detect(frame: VisionFrame): List<LineCandidate> = withContext(Dispatchers.Default) {
        val gray = Mat(frame.height, frame.width, CvType.CV_8UC1)
        val edges = Mat()
        val segments = Mat()
        try {
            gray.put(0, 0, frame.grayscale)
            Imgproc.Canny(gray, edges, cannyLow, cannyHigh, 3, true)
            Imgproc.createLineSegmentDetector(Imgproc.LSD_REFINE_STD).detect(edges, segments)
            buildList {
                repeat(segments.rows()) { row ->
                    val data = segments.get(row, 0) ?: return@repeat
                    if (data.size < 4) return@repeat
                    val start = Vector2(data[0], data[1])
                    val end = Vector2(data[2], data[3])
                    val length = hypot(end.x - start.x, end.y - start.y)
                    if (length < minimumLengthPixels) return@repeat
                    val normalizedLength = (length / hypot(frame.width.toDouble(), frame.height.toDouble())).coerceIn(0.0, 1.0)
                    val confidence = (0.55 + normalizedLength * 0.35).coerceIn(0.0, 1.0)
                    add(
                        LineCandidate(
                            id = EntityId("candidate:${frame.id.value}:$row"),
                            start = start,
                            end = end,
                            gradientScore = confidence,
                            continuityScore = normalizedLength,
                            temporalScore = 0.0,
                            semanticScore = 0.0,
                            depthScore = 0.0,
                            shadowProbability = 0.5,
                            combinedConfidence = confidence * 0.55,
                        ),
                    )
                }
            }
        } finally {
            gray.release()
            edges.release()
            segments.release()
        }
    }
}

class DefaultVisionPipeline(
    private val detector: LineCandidateDetector,
    private val clockMillis: () -> Long = System::currentTimeMillis,
) : VisionPipeline {
    override suspend fun process(frame: VisionFrame): VisionResult {
        val started = clockMillis()
        val candidates = detector.detect(frame)
        val texture = candidates.size.coerceAtMost(40) / 40.0
        val quality = FrameQuality(
            sharpness = texture,
            exposure = 1.0,
            texture = texture,
            trackingSuitable = candidates.size >= 3,
            userHint = if (candidates.size < 3) "Zmeňte uhol alebo pridajte dočasný kontrastný marker." else null,
        )
        return VisionResult(frame.id, quality, candidates, clockMillis() - started)
    }
}
