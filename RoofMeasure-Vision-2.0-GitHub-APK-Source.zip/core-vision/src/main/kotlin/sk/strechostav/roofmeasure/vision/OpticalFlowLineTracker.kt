package sk.strechostav.roofmeasure.vision

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.video.Video
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.math.Vector2

data class FlowTrackingResult(
    val projections: Map<EntityId, List<Vector2>>,
    val confidence: Map<EntityId, Double>,
)

class OpticalFlowLineTracker : AutoCloseable {
    private var previous: Mat? = null
    private var previousFrameId: EntityId? = null

    suspend fun track(frame: VisionFrame, normalizedProjections: Map<EntityId, List<Vector2>>): FlowTrackingResult =
        withContext(Dispatchers.Default) {
            val current = Mat(frame.height, frame.width, CvType.CV_8UC1)
            current.put(0, 0, frame.grayscale)
            val prior = previous
            if (prior == null || normalizedProjections.isEmpty()) {
                previous?.release()
                previous = current
                previousFrameId = frame.id
                return@withContext FlowTrackingResult(normalizedProjections, normalizedProjections.keys.associateWith { 1.0 })
            }

            val keys = mutableListOf<Pair<EntityId, Int>>()
            val inputPoints = mutableListOf<Point>()
            normalizedProjections.toSortedMap(compareBy(EntityId::value)).forEach { (id, points) ->
                points.forEachIndexed { index, point ->
                    keys += id to index
                    inputPoints += Point(point.x * frame.width, point.y * frame.height)
                }
            }
            val source = MatOfPoint2f(*inputPoints.toTypedArray())
            val destination = MatOfPoint2f()
            val status = MatOfByte()
            val error = MatOfFloat()
            try {
                Video.calcOpticalFlowPyrLK(
                    prior,
                    current,
                    source,
                    destination,
                    status,
                    error,
                    Size(21.0, 21.0),
                    3,
                )
                val output = destination.toArray()
                val statuses = status.toArray()
                val errors = error.toArray()
                val updated = normalizedProjections.mapValues { (_, points) -> points.toMutableList() }
                val confidenceSums = mutableMapOf<EntityId, Double>()
                val confidenceCounts = mutableMapOf<EntityId, Int>()
                keys.forEachIndexed { flatIndex, (id, pointIndex) ->
                    val valid = flatIndex < statuses.size && statuses[flatIndex].toInt() != 0 && flatIndex < output.size
                    if (valid) {
                        val point = output[flatIndex]
                        val normalized = Vector2(
                            (point.x / frame.width).coerceIn(0.0, 1.0),
                            (point.y / frame.height).coerceIn(0.0, 1.0),
                        )
                        updated[id]?.set(pointIndex, normalized)
                    }
                    val pointError = errors.getOrElse(flatIndex) { 100f }.toDouble()
                    val score = if (valid) (1.0 / (1.0 + pointError / 12.0)).coerceIn(0.0, 1.0) else 0.0
                    confidenceSums[id] = confidenceSums.getOrElse(id) { 0.0 } + score
                    confidenceCounts[id] = confidenceCounts.getOrElse(id) { 0 } + 1
                }
                previous?.release()
                previous = current
                previousFrameId = frame.id
                FlowTrackingResult(
                    updated.mapValues { it.value.toList() },
                    updated.keys.associateWith { confidenceSums.getOrElse(it) { 0.0 } / confidenceCounts.getOrElse(it) { 1 } },
                )
            } finally {
                source.release()
                destination.release()
                status.release()
                error.release()
                if (previous !== current) current.release()
            }
        }

    override fun close() { previous?.release(); previous = null; previousFrameId = null }
}
