package sk.strechostav.roofmeasure.vision

import kotlin.math.exp

data class CandidateFeatures(val values: DoubleArray) {
    init { require(values.isNotEmpty() && values.all(Double::isFinite)) }
}

class ProjectLineLearner(
    featureCount: Int,
    private val learningRate: Double = 0.08,
    private val regularization: Double = 0.001,
) {
    private val weights = DoubleArray(featureCount + 1)

    fun score(features: CandidateFeatures): Double {
        require(features.values.size + 1 == weights.size)
        var logit = weights[0]
        features.values.indices.forEach { logit += weights[it + 1] * features.values[it] }
        return 1.0 / (1.0 + exp(-logit.coerceIn(-30.0, 30.0)))
    }

    @Synchronized
    fun update(features: CandidateFeatures, positive: Boolean): Double {
        val prediction = score(features)
        val error = (if (positive) 1.0 else 0.0) - prediction
        weights[0] += learningRate * error
        features.values.indices.forEach { index ->
            weights[index + 1] += learningRate * (error * features.values[index] - regularization * weights[index + 1])
        }
        return score(features)
    }

    fun snapshot(): List<Double> = weights.toList()
}
