package sk.strechostav.roofmeasure.report

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel
import kotlin.math.roundToInt

@Composable
fun QuantitySummary(model: ParametricRoofModel, modifier: Modifier = Modifier) {
    Column(modifier.padding(16.dp)) {
        val area = model.quantities.totalRoofArea
        Text("Plocha strechy: ${"%.2f".format(area.valueSi)} m² ± ${(area.uncertainty.sigma * 1000).roundToInt()} mm ekv.")
        Text("Roviny: ${model.planes.size}, hrany: ${model.edges.size}, objekty: ${model.objects.size}")
        model.quantities.edgeLengths.forEach { (type, value) -> Text("${type.name}: ${"%.3f".format(value.valueSi)} m (${value.qualityClass})") }
    }
}
