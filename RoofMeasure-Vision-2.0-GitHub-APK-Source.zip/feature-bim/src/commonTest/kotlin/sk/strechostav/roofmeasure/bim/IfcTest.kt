package sk.strechostav.roofmeasure.bim

import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.QualityClass
import sk.strechostav.roofmeasure.domain.Quantity
import sk.strechostav.roofmeasure.domain.QuantityUnit
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StandardUncertainty
import sk.strechostav.roofmeasure.math.Vector3
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel
import sk.strechostav.roofmeasure.modeling.ParametricRoofPlane
import sk.strechostav.roofmeasure.modeling.QuantityTakeoff
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class IfcTest {
    @Test
    fun stableGuidIsIfcLengthAndAlphabet() {
        val first = IfcGuid.fromStableKey("project:plane:1")
        assertEquals(22, first.length)
        assertEquals(first, IfcGuid.fromStableKey("project:plane:1"))
        assertTrue(first.all { it.isLetterOrDigit() || it == '_' || it == '$' })
    }

    @Test
    fun generatedIfcPassesBasicReferenceValidation() {
        val step = Ifc4Exporter().export("roof", fixture()).bytes.decodeToString()
        val result = IfcBasicValidator.validate(step)
        assertTrue(result.valid, result.errors.joinToString())
        assertTrue("Pset_RoofMeasureQuality" in step)
    }

    private fun fixture(): ParametricRoofModel {
        val q = Quantity(4.0, QuantityUnit.SQUARE_METRE, StandardUncertainty(0.01), QualityClass.B, setOf(EntityId("source")), CalibrationState.LASER_MEASURED)
        val plane = ParametricRoofPlane(EntityId("p1"), "RoofPlane_R1", Vector3.Z, 0.0, listOf(Vector3.ZERO, Vector3(2.0, 0.0, 0.0), Vector3(2.0, 2.0, 0.0), Vector3(0.0, 2.0, 0.0)), emptyList(), q, q, q.copy(valueSi = 0.0, unit = QuantityUnit.RADIAN), emptySet())
        return ParametricRoofModel(EntityId("model"), EntityId("project"), RevisionId(1), "PROJECT_Z_UP_METRES", listOf(plane), emptyList(), emptyList(), QuantityTakeoff(q, q, emptyMap(), q.copy(valueSi = 0.0), emptyMap()))
    }
}
