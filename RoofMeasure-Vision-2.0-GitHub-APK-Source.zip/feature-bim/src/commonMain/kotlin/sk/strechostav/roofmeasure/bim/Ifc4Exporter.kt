package sk.strechostav.roofmeasure.bim

import sk.strechostav.roofmeasure.export.ExportArtifact
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel

class Ifc4Exporter {
    fun export(baseName: String, model: ParametricRoofModel): ExportArtifact {
        val writer = StepWriter()
        val origin = writer.add("IFCCARTESIANPOINT((0.,0.,0.))")
        val up = writer.add("IFCDIRECTION((0.,0.,1.))")
        val xAxis = writer.add("IFCDIRECTION((1.,0.,0.))")
        val placement3d = writer.add("IFCAXIS2PLACEMENT3D(#$origin,#$up,#$xAxis)")
        val worldPlacement = writer.add("IFCLOCALPLACEMENT(${'$'},#$placement3d)")
        val context = writer.add("IFCGEOMETRICREPRESENTATIONCONTEXT(${'$'},'Model',3,1.E-5,#$placement3d,${'$'})")
        val lengthUnit = writer.add("IFCSIUNIT(*,.LENGTHUNIT.,${'$'},.METRE.)")
        val areaUnit = writer.add("IFCSIUNIT(*,.AREAUNIT.,${'$'},.SQUARE_METRE.)")
        val angleUnit = writer.add("IFCSIUNIT(*,.PLANEANGLEUNIT.,${'$'},.RADIAN.)")
        val units = writer.add("IFCUNITASSIGNMENT((#$lengthUnit,#$areaUnit,#$angleUnit))")

        val project = writer.add("IFCPROJECT('${guid(model, "project")}',${'$'},'RoofMeasure Project',${'$'},${'$'},${'$'},${'$'},(#$context),#$units)")
        val site = writer.add("IFCSITE('${guid(model, "site")}',${'$'},'Site',${'$'},${'$'},#$worldPlacement,${'$'},${'$'},.ELEMENT.,${'$'},${'$'},${'$'},${'$'},${'$'})")
        val building = writer.add("IFCBUILDING('${guid(model, "building")}',${'$'},'Building',${'$'},${'$'},#$worldPlacement,${'$'},${'$'},.ELEMENT.,${'$'},${'$'},${'$'})")
        val storey = writer.add("IFCBUILDINGSTOREY('${guid(model, "storey")}',${'$'},'Roof level',${'$'},${'$'},#$worldPlacement,${'$'},${'$'},.ELEMENT.,0.)")
        val roof = writer.add("IFCROOF('${guid(model, "roof")}',${'$'},'Roof',${'$'},${'$'},#$worldPlacement,${'$'},'${escapeStep(model.id.value)}',.NOTDEFINED.)")
        writer.add("IFCRELAGGREGATES('${guid(model, "rel-project-site")}',${'$'},${'$'},${'$'},#$project,(#$site))")
        writer.add("IFCRELAGGREGATES('${guid(model, "rel-site-building")}',${'$'},${'$'},${'$'},#$site,(#$building))")
        writer.add("IFCRELAGGREGATES('${guid(model, "rel-building-storey")}',${'$'},${'$'},${'$'},#$building,(#$storey))")
        writer.add("IFCRELCONTAINEDINSPATIALSTRUCTURE('${guid(model, "rel-storey-roof")}',${'$'},${'$'},${'$'},(#$roof),#$storey)")

        val slabs = model.planes.mapIndexedNotNull { index, plane ->
            if (plane.boundary.size < 3 || plane.openings.isNotEmpty()) return@mapIndexedNotNull null
            val coordinateList = plane.boundary.joinToString(",") { "(${it.x.step()},${it.y.step()},${it.z.step()})" }
            val pointList = writer.add("IFCCARTESIANPOINTLIST3D(($coordinateList),${'$'})")
            val indices = plane.boundary.indices.joinToString(",") { (it + 1).toString() }
            val face = writer.add("IFCINDEXEDPOLYGONALFACE(($indices))")
            val faceSet = writer.add("IFCPOLYGONALFACESET(#$pointList,.F.,(#$face),${'$'})")
            val representation = writer.add("IFCSHAPEREPRESENTATION(#$context,'Body','Tessellation',(#$faceSet))")
            val productShape = writer.add("IFCPRODUCTDEFINITIONSHAPE(${ '$' },${ '$' },(#$representation))")
            val slab = writer.add(
                "IFCSLAB('${guid(model, "slab:${plane.id.value}")}',${'$'},'${escapeStep(plane.name)}',${'$'},${'$'},#$worldPlacement,#$productShape,'${escapeStep(plane.id.value)}',.ROOF.)",
            )
            val properties = listOf(
                writer.add("IFCPROPERTYSINGLEVALUE('Area',${'$'},IFCAREAMEASURE(${plane.area.valueSi.step()}),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('HorizontalArea',${'$'},IFCAREAMEASURE(${plane.horizontalArea.valueSi.step()}),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('Slope',${'$'},IFCPLANEANGLEMEASURE(${plane.slope.valueSi.step()}),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('UncertaintyMillimetres',${'$'},IFCLENGTHMEASURE(${(plane.area.uncertainty.sigma * 1000.0).step()}),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('QualityClass',${'$'},IFCLABEL('${plane.area.qualityClass.name}'),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('CalibrationState',${'$'},IFCLABEL('${plane.area.calibrationState.name}'),${'$'})"),
                writer.add("IFCPROPERTYSINGLEVALUE('ModelRevision',${'$'},IFCINTEGER(${model.revision.value}),${'$'})"),
            )
            val pset = writer.add("IFCPROPERTYSET('${guid(model, "pset:${plane.id.value}")}',${'$'},'Pset_RoofMeasureQuality',${'$'},(${properties.joinToString(",") { "#$it" }}))")
            writer.add("IFCRELDEFINESBYPROPERTIES('${guid(model, "rel-pset:${plane.id.value}")}',${'$'},${'$'},${'$'},(#$slab),#$pset)")
            index to slab
        }
        if (slabs.isNotEmpty()) {
            writer.add("IFCRELAGGREGATES('${guid(model, "rel-roof-slabs")}',${'$'},${'$'},${'$'},#$roof,(${slabs.joinToString(",") { "#${it.second}" }}))")
        }

        val warnings = buildList {
            if (model.planes.any { it.openings.isNotEmpty() }) add("MVP IFC export vynechal roviny s otvormi; IfcOpeningElement je špecifikovaný, ale constrained triangulácia ešte nie je zapojená.")
            if (model.objects.isNotEmpty()) add("MVP IFC export zatiaľ neprenáša objektové inštancie.")
        }
        return ExportArtifact("$baseName.ifc", "application/x-step", writer.render(model.id.value).encodeToByteArray(), warnings)
    }

    private fun guid(model: ParametricRoofModel, suffix: String): String = IfcGuid.fromStableKey("${model.projectId.value}:$suffix")
}

object IfcBasicValidator {
    data class Result(val valid: Boolean, val errors: List<String>)

    fun validate(step: String): Result {
        val errors = mutableListOf<String>()
        if (!step.startsWith("ISO-10303-21;")) errors += "Missing STEP header"
        if ("FILE_SCHEMA(('IFC4'));" !in step) errors += "Missing IFC4 schema"
        if (!step.trimEnd().endsWith("END-ISO-10303-21;")) errors += "Missing STEP footer"
        val defined = Regex("(?m)^#(\\d+)=").findAll(step).map { it.groupValues[1].toInt() }.toSet()
        Regex("#(\\d+)").findAll(step).map { it.groupValues[1].toInt() }.filter { it !in defined }.distinct().forEach { errors += "Undefined entity #$it" }
        if (defined.size != Regex("(?m)^#(\\d+)=").findAll(step).count()) errors += "Duplicate entity number"
        return Result(errors.isEmpty(), errors)
    }
}

private class StepWriter {
    private val entities = mutableListOf<String>()
    fun add(entity: String): Int { entities += entity; return entities.size }

    fun render(fileName: String): String = buildString {
        append("ISO-10303-21;\nHEADER;\n")
        append("FILE_DESCRIPTION(('ViewDefinition [ReferenceView_V1.2]'),'2;1');\n")
        append("FILE_NAME('").append(escapeStep(fileName)).append("','1970-01-01T00:00:00',('RoofMeasure Vision'),('StrechoStav'),'RoofMeasure Vision 2.0','RoofMeasure Vision 2.0','');\n")
        append("FILE_SCHEMA(('IFC4'));\nENDSEC;\nDATA;\n")
        entities.forEachIndexed { index, entity -> append('#').append(index + 1).append('=').append(entity).append(";\n") }
        append("ENDSEC;\nEND-ISO-10303-21;\n")
    }
}

private fun escapeStep(value: String): String = value.replace("'", "''")
private fun Double.step(): String { require(isFinite()); return if (this % 1.0 == 0.0) "${toLong()}." else toString() }
