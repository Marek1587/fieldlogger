package sk.strechostav.roofmeasure.bim

private const val IFC64 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$"

object IfcGuid {
    /** Produces a deterministic IFC-compatible 22 character identifier from a stable entity key. */
    fun fromStableKey(key: String): String {
        require(key.isNotBlank())
        val bytes = ByteArray(16)
        repeat(4) { lane ->
            var hash = 0x811c9dc5.toInt() xor (lane * 0x9e3779b9.toInt())
            key.forEachIndexed { index, character ->
                hash = hash xor (character.code + index * 31 + lane * 17)
                hash *= 0x01000193
                hash = hash.rotateLeft(5 + lane)
            }
            bytes[lane * 4] = (hash ushr 24).toByte()
            bytes[lane * 4 + 1] = (hash ushr 16).toByte()
            bytes[lane * 4 + 2] = (hash ushr 8).toByte()
            bytes[lane * 4 + 3] = hash.toByte()
        }
        return buildString(22) {
            repeat(22) { group ->
                var value = 0
                repeat(6) { bitInGroup ->
                    val paddedBit = group * 6 + bitInGroup
                    val dataBit = paddedBit - 4
                    val bit = if (dataBit !in 0..127) 0 else {
                        val byte = bytes[dataBit / 8].toInt() and 0xff
                        (byte ushr (7 - dataBit % 8)) and 1
                    }
                    value = (value shl 1) or bit
                }
                append(IFC64[value])
            }
        }
    }
}
