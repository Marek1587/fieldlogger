package sk.strechostav.roofmeasure.geometry

import sk.strechostav.roofmeasure.math.Vector2
import sk.strechostav.roofmeasure.math.Vector3
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNotNull
import kotlin.test.assertTrue
import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.LineSource
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine

class GeometryTest {
    @Test
    fun polygonAreaAndSlope() {
        val square = listOf(Vector3(0.0, 0.0, 0.0), Vector3(2.0, 0.0, 0.0), Vector3(2.0, 3.0, 0.0), Vector3(0.0, 3.0, 0.0))
        assertEquals(6.0, PolygonGeometry.area3(square), 1e-12)
        assertEquals(6.0, PolygonGeometry.horizontalProjectedArea(square), 1e-12)
    }

    @Test
    fun imagePlanesTriangulateToLine() {
        val first = CameraLineObservation3(Vector3.ZERO, Vector3(1.0, 0.0, 1.0), Vector3(1.0, 0.0, 2.0))
        val second = CameraLineObservation3(Vector3(0.0, 1.0, 0.0), Vector3(1.0, -1.0, 1.0), Vector3(1.0, -1.0, 2.0))
        val result = assertNotNull(LineTriangulator.triangulate(first, second))
        assertTrue(result.conditionScore > 0.1)
        assertTrue(result.line.distanceTo(Vector3(1.0, 0.0, 1.0)) < 1e-9)
    }

    @Test
    fun signedAreaUsesWinding() {
        assertEquals(1.0, PolygonGeometry.signedArea2(listOf(Vector2(0.0, 0.0), Vector2(1.0, 0.0), Vector2(1.0, 1.0), Vector2(0.0, 1.0))), 1e-12)
    }

    @Test
    fun fourSnappedEdgesCreateAValidLoop() {
        fun line(id: String, start: Vector3, end: Vector3) = TrackedStructuralLine(
            id = EntityId(id),
            semanticType = LineSemanticType.ROOF_OUTLINE,
            endpoints3D = start to end,
            confidence = 0.9,
            covariance = null,
            lifecycle = LineLifecycle.OPTIMIZED,
            observationIds = emptyList(),
            source = LineSource.USER_CONFIRMED,
            calibrationState = CalibrationState.LASER_MEASURED,
        )
        val graph = StructuralGraphBuilder(0.02).build(
            listOf(
                line("a", Vector3(0.0, 0.0, 0.0), Vector3(4.0, 0.0, 0.0)),
                line("b", Vector3(4.01, 0.0, 0.0), Vector3(4.0, 3.0, 0.0)),
                line("c", Vector3(4.0, 3.0, 0.0), Vector3(0.0, 3.0, 0.0)),
                line("d", Vector3(0.0, 3.0, 0.0), Vector3(0.0, 0.01, 0.0)),
            ),
            RevisionId(1),
        )
        assertEquals(1, graph.loops.size)
        assertTrue(StructuralGraphValidator.validate(graph).isValid)
    }
}
