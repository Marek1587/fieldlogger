package sk.strechostav.roofmeasure.geometry

import sk.strechostav.roofmeasure.domain.Covariance3
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LoopKind
import sk.strechostav.roofmeasure.domain.NodeType
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StructuralEdge
import sk.strechostav.roofmeasure.domain.StructuralLineGraph
import sk.strechostav.roofmeasure.domain.StructuralNode
import sk.strechostav.roofmeasure.domain.SurfaceLoop
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.math.Vector3

class StructuralGraphBuilder(private val snapToleranceMetres: Double = 0.03) {
    init { require(snapToleranceMetres > 0.0) }

    fun build(lines: Collection<TrackedStructuralLine>, revision: RevisionId): StructuralLineGraph {
        val metricLines = lines.filter { it.endpoints3D != null }.sortedBy { it.id.value }
        val clusters = mutableListOf<MutableList<Endpoint>>()
        metricLines.forEach { line ->
            val endpoints = requireNotNull(line.endpoints3D)
            addToCluster(clusters, Endpoint(line.id, false, endpoints.first))
            addToCluster(clusters, Endpoint(line.id, true, endpoints.second))
        }

        val nodes = clusters.mapIndexed { index, members ->
            val position = members.map(Endpoint::point).reduce(Vector3::plus) / members.size.toDouble()
            val id = EntityId("node:$index:${members.first().lineId.value}")
            id to StructuralNode(id, position, Covariance3.isotropic(snapToleranceMetres / 2.0), NodeType.CORNER, emptySet())
        }.toMap().toMutableMap()

        val endpointNodes = buildMap<Pair<EntityId, Boolean>, EntityId> {
            clusters.forEachIndexed { index, members -> members.forEach { put(it.lineId to it.end, nodes.keys.elementAt(index)) } }
        }

        val edges = metricLines.mapNotNull { line ->
            val start = endpointNodes[line.id to false] ?: return@mapNotNull null
            val end = endpointNodes[line.id to true] ?: return@mapNotNull null
            if (start == end) return@mapNotNull null
            val edgeId = EntityId("edge:${line.id.value}")
            edgeId to StructuralEdge(edgeId, start, end, line.semanticType, line.id, line.confidence)
        }.toMap()

        edges.values.forEach { edge ->
            nodes[edge.startNodeId] = requireNotNull(nodes[edge.startNodeId]).let { it.copy(incidentEdgeIds = it.incidentEdgeIds + edge.id) }
            nodes[edge.endNodeId] = requireNotNull(nodes[edge.endNodeId]).let { it.copy(incidentEdgeIds = it.incidentEdgeIds + edge.id) }
        }

        val loops = findDegreeTwoLoops(nodes, edges)
        return StructuralLineGraph(revision, nodes, edges, loops, emptyMap(), emptyMap(), emptyMap())
    }

    private fun addToCluster(clusters: MutableList<MutableList<Endpoint>>, endpoint: Endpoint) {
        val cluster = clusters.firstOrNull { members -> members.any { it.point.distanceTo(endpoint.point) <= snapToleranceMetres } }
        if (cluster == null) clusters += mutableListOf(endpoint) else cluster += endpoint
    }

    private fun findDegreeTwoLoops(
        nodes: Map<EntityId, StructuralNode>,
        edges: Map<EntityId, StructuralEdge>,
    ): Map<EntityId, SurfaceLoop> {
        val remaining = edges.keys.toMutableSet()
        val loops = mutableMapOf<EntityId, SurfaceLoop>()
        var loopIndex = 0
        while (remaining.isNotEmpty()) {
            val firstId = remaining.minBy(EntityId::value)
            val first = requireNotNull(edges[firstId])
            val componentNodes = mutableSetOf<EntityId>()
            val componentEdges = mutableSetOf<EntityId>()
            val queue = ArrayDeque<EntityId>()
            queue.add(first.startNodeId)
            while (queue.isNotEmpty()) {
                val nodeId = queue.removeFirst()
                if (!componentNodes.add(nodeId)) continue
                nodes[nodeId]?.incidentEdgeIds.orEmpty().forEach { edgeId ->
                    val edge = edges[edgeId] ?: return@forEach
                    componentEdges += edgeId
                    queue.add(if (edge.startNodeId == nodeId) edge.endNodeId else edge.startNodeId)
                }
            }
            remaining.removeAll(componentEdges)
            if (componentEdges.size >= 3 && componentNodes.size == componentEdges.size &&
                componentNodes.all { nodes[it]?.incidentEdgeIds?.count(componentEdges::contains) == 2 }
            ) {
                val id = EntityId("loop:${loopIndex++}:${componentEdges.minBy(EntityId::value).value}")
                loops[id] = SurfaceLoop(id, LoopKind.OUTER, orderCycle(componentEdges, nodes, edges))
            }
        }
        return loops
    }

    private fun orderCycle(
        componentEdges: Set<EntityId>,
        nodes: Map<EntityId, StructuralNode>,
        edges: Map<EntityId, StructuralEdge>,
    ): List<EntityId> {
        val first = componentEdges.minBy(EntityId::value)
        val result = mutableListOf(first)
        var currentNode = requireNotNull(edges[first]).endNodeId
        var previous = first
        while (result.size < componentEdges.size) {
            val next = nodes[currentNode]?.incidentEdgeIds
                ?.filter { it in componentEdges && it != previous }
                ?.minByOrNull(EntityId::value) ?: break
            result += next
            val edge = requireNotNull(edges[next])
            currentNode = if (edge.startNodeId == currentNode) edge.endNodeId else edge.startNodeId
            previous = next
        }
        return result
    }

    private data class Endpoint(val lineId: EntityId, val end: Boolean, val point: Vector3)
}
