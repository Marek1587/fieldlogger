package sk.strechostav.roofmeasure.geometry

import sk.strechostav.roofmeasure.math.Vector2
import sk.strechostav.roofmeasure.math.Vector3
import kotlin.math.abs
import kotlin.math.acos

object PolygonGeometry {
    fun signedArea2(points: List<Vector2>): Double {
        require(points.size >= 3)
        return points.indices.sumOf { index ->
            val next = points[(index + 1) % points.size]
            points[index].cross(next)
        } / 2.0
    }

    fun newellNormal(points: List<Vector3>): Vector3 {
        require(points.size >= 3)
        var x = 0.0
        var y = 0.0
        var z = 0.0
        points.indices.forEach { index ->
            val current = points[index]
            val next = points[(index + 1) % points.size]
            x += (current.y - next.y) * (current.z + next.z)
            y += (current.z - next.z) * (current.x + next.x)
            z += (current.x - next.x) * (current.y + next.y)
        }
        return Vector3(x, y, z).normalized()
    }

    fun area3(points: List<Vector3>): Double {
        require(points.size >= 3)
        val vectorArea = points.indices.fold(Vector3.ZERO) { accumulator, index ->
            accumulator + points[index].cross(points[(index + 1) % points.size])
        }
        return vectorArea.norm() * 0.5
    }

    fun horizontalProjectedArea(points: List<Vector3>): Double = abs(
        signedArea2(points.map { Vector2(it.x, it.y) }),
    )

    fun slopeRadians(normal: Vector3): Double {
        val upDot = abs(normal.normalized().dot(Vector3.Z)).coerceIn(0.0, 1.0)
        return acos(upDot)
    }

    fun isPlanar(points: List<Vector3>, toleranceMetres: Double): Boolean {
        if (points.size < 3) return false
        val plane = try { Plane3.fromPoints(points[0], points[1], points[2]) } catch (_: IllegalArgumentException) { return false }
        return points.all { abs(plane.signedDistance(it)) <= toleranceMetres }
    }
}
