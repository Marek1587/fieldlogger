package sk.strechostav.roofmeasure.geometry

import sk.strechostav.roofmeasure.math.Vector3
import kotlin.math.abs

data class Line3(val point: Vector3, val direction: Vector3) {
    val unitDirection: Vector3 = direction.normalized()
    fun pointAt(parameter: Double): Vector3 = point + unitDirection * parameter
    fun distanceTo(candidate: Vector3): Double = (candidate - point).cross(unitDirection).norm()
}

data class Segment3(val start: Vector3, val end: Vector3) {
    init { require(start != end) }
    val length: Double get() = start.distanceTo(end)
    val direction: Vector3 get() = (end - start).normalized()
    val midpoint: Vector3 get() = (start + end) * 0.5
}

data class Plane3(val normal: Vector3, val offset: Double) {
    init {
        require(abs(normal.norm() - 1.0) < 1e-6) { "Plane normal must be normalized" }
        require(offset.isFinite())
    }
    fun signedDistance(point: Vector3): Double = normal.dot(point) + offset
    fun project(point: Vector3): Vector3 = point - normal * signedDistance(point)

    fun intersect(other: Plane3, parallelTolerance: Double = 1e-9): Line3? {
        val direction = normal.cross(other.normal)
        val squared = direction.squaredNorm()
        if (squared <= parallelTolerance * parallelTolerance) return null
        val point = (normal * other.offset - other.normal * offset).cross(direction) / squared
        return Line3(point, direction)
    }

    companion object {
        fun fromNormalAndPoint(normal: Vector3, point: Vector3): Plane3 {
            val unit = normal.normalized()
            return Plane3(unit, -unit.dot(point))
        }

        fun fromPoints(a: Vector3, b: Vector3, c: Vector3): Plane3 {
            val normal = (b - a).cross(c - a)
            require(normal.norm() > 1e-10) { "Plane points are collinear" }
            return fromNormalAndPoint(normal, a)
        }

        fun fromNormalized(normal: Vector3, offset: Double): Plane3 {
            require(abs(normal.norm() - 1.0) < 1e-6)
            return Plane3(normal, offset)
        }
    }
}

data class CameraLineObservation3(
    val cameraCentre: Vector3,
    val firstRay: Vector3,
    val secondRay: Vector3,
) {
    fun interpretationPlane(): Plane3 {
        val normal = firstRay.cross(secondRay)
        require(normal.norm() > 1e-10) { "Image line rays are degenerate" }
        return Plane3.fromNormalAndPoint(normal, cameraCentre)
    }
}

object LineTriangulator {
    data class Result(val line: Line3, val intersectionAngleRadians: Double, val conditionScore: Double)

    fun triangulate(first: CameraLineObservation3, second: CameraLineObservation3): Result? {
        val firstPlane = first.interpretationPlane()
        val secondPlane = second.interpretationPlane()
        val line = firstPlane.intersect(secondPlane) ?: return null
        val sine = firstPlane.normal.cross(secondPlane.normal).norm().coerceIn(0.0, 1.0)
        val angle = kotlin.math.asin(sine)
        if (angle < 0.01) return null
        return Result(line, angle, sine)
    }
}
