package sk.strechostav.roofmeasure.geometry

import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LoopKind
import sk.strechostav.roofmeasure.domain.StructuralLineGraph

enum class GraphIssueSeverity { WARNING, ERROR }

data class GraphValidationIssue(
    val severity: GraphIssueSeverity,
    val code: String,
    val entityId: EntityId?,
    val message: String,
)

data class GraphValidationResult(val issues: List<GraphValidationIssue>) {
    val isValid: Boolean get() = issues.none { it.severity == GraphIssueSeverity.ERROR }
}

object StructuralGraphValidator {
    fun validate(graph: StructuralLineGraph): GraphValidationResult {
        val issues = mutableListOf<GraphValidationIssue>()
        graph.edges.values.forEach { edge ->
            if (edge.startNodeId !in graph.nodes || edge.endNodeId !in graph.nodes) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "EDGE_NODE_MISSING", edge.id, "Edge references a missing node")
            }
            if (graph.nodes[edge.startNodeId]?.incidentEdgeIds?.contains(edge.id) == false ||
                graph.nodes[edge.endNodeId]?.incidentEdgeIds?.contains(edge.id) == false
            ) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "INCIDENCE_ASYMMETRIC", edge.id, "Node incidence does not contain the edge")
            }
        }
        graph.loops.values.forEach { loop ->
            if (loop.orientedEdgeIds.any { it !in graph.edges }) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "LOOP_EDGE_MISSING", loop.id, "Loop references a missing edge")
            }
            if (!isClosed(loop.orientedEdgeIds, graph)) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "LOOP_NOT_CLOSED", loop.id, "Loop edges do not form one closed chain")
            }
            if (loop.kind == LoopKind.OPENING && loop.hostPlaneId == null) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "OPENING_WITHOUT_HOST", loop.id, "Opening loop has no host plane")
            }
        }
        graph.roofPlanes.values.forEach { plane ->
            if (plane.outerLoopId !in graph.loops) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "PLANE_LOOP_MISSING", plane.id, "Roof plane has no outer loop")
            }
            if (plane.openingLoopIds.any { it !in graph.loops }) {
                issues += GraphValidationIssue(GraphIssueSeverity.ERROR, "PLANE_OPENING_MISSING", plane.id, "Roof plane references a missing opening loop")
            }
        }
        return GraphValidationResult(issues)
    }

    private fun isClosed(edgeIds: List<EntityId>, graph: StructuralLineGraph): Boolean {
        if (edgeIds.size < 3) return false
        val degree = mutableMapOf<EntityId, Int>()
        edgeIds.mapNotNull(graph.edges::get).forEach { edge ->
            degree[edge.startNodeId] = degree.getOrElse(edge.startNodeId) { 0 } + 1
            degree[edge.endNodeId] = degree.getOrElse(edge.endNodeId) { 0 } + 1
        }
        return degree.size == edgeIds.size && degree.values.all { it == 2 }
    }
}
