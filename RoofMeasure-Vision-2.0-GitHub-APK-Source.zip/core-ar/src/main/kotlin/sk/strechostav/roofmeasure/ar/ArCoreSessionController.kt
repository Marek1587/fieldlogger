package sk.strechostav.roofmeasure.ar

import android.app.Activity
import android.content.Context
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import sk.strechostav.roofmeasure.math.Matrix3
import sk.strechostav.roofmeasure.math.RigidTransform3
import sk.strechostav.roofmeasure.math.Vector3

enum class ArAvailability { SUPPORTED, NEEDS_INSTALL, UNSUPPORTED, CHECKING }

class ArCoreSessionController(private val context: Context) : AutoCloseable {
    private var session: Session? = null
    private var installRequested = false

    fun availability(): ArAvailability {
        val availability = ArCoreApk.getInstance().checkAvailability(context)
        return when {
            availability.isSupported -> ArAvailability.SUPPORTED
            availability.isUnsupported -> ArAvailability.UNSUPPORTED
            availability.isTransient -> ArAvailability.CHECKING
            else -> ArAvailability.NEEDS_INSTALL
        }
    }

    fun resume(activity: Activity): Session? {
        if (session == null) {
            when (ArCoreApk.getInstance().requestInstall(activity, !installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> { installRequested = true; return null }
                ArCoreApk.InstallStatus.INSTALLED -> Unit
            }
            session = Session(activity).also { created ->
                val config = Config(created).apply {
                    updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                    if (created.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) depthMode = Config.DepthMode.AUTOMATIC
                }
                created.configure(config)
            }
        }
        session?.resume()
        return session
    }

    fun pause() { session?.pause() }
    override fun close() { session?.close(); session = null }
}

object ArPoseAdapter {
    fun toProjectTransform(pose: com.google.ar.core.Pose): RigidTransform3 {
        val qx = pose.qx().toDouble()
        val qy = pose.qy().toDouble()
        val qz = pose.qz().toDouble()
        val qw = pose.qw().toDouble()
        val rotation = Matrix3(
            1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw),
            2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw),
            2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy),
        )
        return RigidTransform3(rotation, Vector3(pose.tx().toDouble(), pose.ty().toDouble(), pose.tz().toDouble()))
    }
}
