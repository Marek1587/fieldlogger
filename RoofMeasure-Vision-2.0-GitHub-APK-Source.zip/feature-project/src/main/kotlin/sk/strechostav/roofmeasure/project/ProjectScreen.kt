package sk.strechostav.roofmeasure.project

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import sk.strechostav.roofmeasure.storage.ProjectEntity

@Composable
fun ProjectScreen(
    projects: List<ProjectEntity>,
    onCreate: (String) -> Unit,
    onOpen: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var name by remember { mutableStateOf("") }
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("RoofMeasure Vision 2.0", style = MaterialTheme.typography.headlineMedium)
        Text("Ukáž líniu. Prejdi kamerou objekt. Premeraj zvýraznené rozmery.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(name, { name = it }, Modifier.weight(1f), label = { Text("Názov projektu") }, singleLine = true)
            Button(onClick = { if (name.isNotBlank()) { onCreate(name.trim()); name = "" } }) { Text("Nový projekt") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects, key = ProjectEntity::id) { project ->
                Card(onClick = { onOpen(project.id) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(project.name, style = MaterialTheme.typography.titleMedium)
                        Text("Revízia ${project.revision} · ${project.sessionStage}")
                    }
                }
            }
        }
    }
}
