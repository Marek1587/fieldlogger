package sk.strechostav.roofmeasure.export

import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.QualityClass
import sk.strechostav.roofmeasure.domain.Quantity
import sk.strechostav.roofmeasure.domain.QuantityUnit
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StandardUncertainty
import sk.strechostav.roofmeasure.math.Vector3
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel
import sk.strechostav.roofmeasure.modeling.ParametricRoofPlane
import sk.strechostav.roofmeasure.modeling.QuantityTakeoff
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class ExportTest {
    @Test
    fun glbHasCorrectHeaderAndLength() {
        val bytes = GlbModelExporter().export("roof", fixture()).bytes
        assertEquals('g'.code, bytes[0].toInt())
        assertEquals('l'.code, bytes[1].toInt())
        assertEquals('T'.code, bytes[2].toInt())
        assertEquals('F'.code, bytes[3].toInt())
        val length = (bytes[8].toInt() and 0xff) or ((bytes[9].toInt() and 0xff) shl 8) or ((bytes[10].toInt() and 0xff) shl 16) or ((bytes[11].toInt() and 0xff) shl 24)
        assertEquals(bytes.size, length)
    }

    @Test
    fun daeDeclaresMetresAndZUp() {
        val dae = DaeModelExporter().export("roof", fixture()).bytes.decodeToString()
        assertTrue("meter=\"1\"" in dae)
        assertTrue("<up_axis>Z_UP</up_axis>" in dae)
    }

    private fun fixture(): ParametricRoofModel {
        val q = Quantity(4.0, QuantityUnit.SQUARE_METRE, StandardUncertainty(0.01), QualityClass.B, setOf(EntityId("source")), CalibrationState.LASER_MEASURED)
        val plane = ParametricRoofPlane(EntityId("p1"), "RoofPlane_R1", Vector3.Z, 0.0, listOf(Vector3.ZERO, Vector3(2.0, 0.0, 0.0), Vector3(2.0, 2.0, 0.0), Vector3(0.0, 2.0, 0.0)), emptyList(), q, q, q.copy(valueSi = 0.0, unit = QuantityUnit.RADIAN), emptySet())
        val takeoff = QuantityTakeoff(q, q, emptyMap(), q.copy(valueSi = 0.0), emptyMap())
        return ParametricRoofModel(EntityId("model"), EntityId("project"), RevisionId(1), "PROJECT_Z_UP_METRES", listOf(plane), emptyList(), emptyList(), takeoff)
    }
}
