package sk.strechostav.roofmeasure.export

import sk.strechostav.roofmeasure.math.Vector3
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel

class GlbModelExporter : ModelExporter {
    override val extension: String = "glb"

    override fun export(baseName: String, model: ParametricRoofModel): ExportArtifact {
        val exportable = model.planes.filter { it.boundary.size >= 3 && it.openings.isEmpty() }
        require(exportable.isNotEmpty()) { "GLB requires at least one plane without openings" }
        val binary = ByteWriter()
        val meshes = mutableListOf<MeshDescriptor>()
        exportable.forEach { plane ->
            binary.align4()
            val positionsOffset = binary.size
            plane.boundary.forEach { vertex ->
                binary.writeFloat(vertex.x.toFloat())
                binary.writeFloat(vertex.y.toFloat())
                binary.writeFloat(vertex.z.toFloat())
            }
            val positionLength = binary.size - positionsOffset
            binary.align4()
            val indicesOffset = binary.size
            val indices = (1 until plane.boundary.lastIndex).flatMap { listOf(0, it, it + 1) }
            indices.forEach(binary::writeInt)
            val indexLength = binary.size - indicesOffset
            meshes += MeshDescriptor(plane.name, plane.id.value, plane.boundary, indices.size, positionsOffset, positionLength, indicesOffset, indexLength)
        }
        binary.align4()
        val gltfJson = buildGltfJson(model, meshes, binary.size)
        val jsonBytes = gltfJson.encodeToByteArray().padTo4(0x20)
        val binaryBytes = binary.toByteArray().padTo4(0)
        val totalLength = 12 + 8 + jsonBytes.size + 8 + binaryBytes.size
        val glb = ByteWriter(totalLength)
        glb.writeInt(0x46546C67)
        glb.writeInt(2)
        glb.writeInt(totalLength)
        glb.writeInt(jsonBytes.size)
        glb.writeInt(0x4E4F534A)
        glb.writeBytes(jsonBytes)
        glb.writeInt(binaryBytes.size)
        glb.writeInt(0x004E4942)
        glb.writeBytes(binaryBytes)
        val warnings = if (model.planes.any { it.openings.isNotEmpty() }) listOf("Roviny s otvormi boli v MVP GLB vynechané.") else emptyList()
        return ExportArtifact("$baseName.$extension", "model/gltf-binary", glb.toByteArray(), warnings)
    }

    private fun buildGltfJson(model: ParametricRoofModel, meshes: List<MeshDescriptor>, byteLength: Int): String {
        var viewIndex = 0
        var accessorIndex = 0
        val meshJson = mutableListOf<String>()
        val viewJson = mutableListOf<String>()
        val accessorJson = mutableListOf<String>()
        meshes.forEach { mesh ->
            val positionView = viewIndex++
            val indexView = viewIndex++
            val positionAccessor = accessorIndex++
            val indexAccessor = accessorIndex++
            viewJson += "{\"buffer\":0,\"byteOffset\":${mesh.positionsOffset},\"byteLength\":${mesh.positionsLength},\"target\":34962}"
            viewJson += "{\"buffer\":0,\"byteOffset\":${mesh.indicesOffset},\"byteLength\":${mesh.indicesLength},\"target\":34963}"
            val min = Vector3(mesh.vertices.minOf { it.x }, mesh.vertices.minOf { it.y }, mesh.vertices.minOf { it.z })
            val max = Vector3(mesh.vertices.maxOf { it.x }, mesh.vertices.maxOf { it.y }, mesh.vertices.maxOf { it.z })
            accessorJson += "{\"bufferView\":$positionView,\"componentType\":5126,\"count\":${mesh.vertices.size},\"type\":\"VEC3\",\"min\":[${min.x},${min.y},${min.z}],\"max\":[${max.x},${max.y},${max.z}]}"
            accessorJson += "{\"bufferView\":$indexView,\"componentType\":5125,\"count\":${mesh.indexCount},\"type\":\"SCALAR\"}"
            meshJson += "{\"name\":\"${escapeJson(mesh.name)}\",\"extras\":{\"roofMeasureId\":\"${escapeJson(mesh.entityId)}\"},\"primitives\":[{\"attributes\":{\"POSITION\":$positionAccessor},\"indices\":$indexAccessor,\"material\":0}]}"
        }
        val nodes = meshes.indices.joinToString(",") { "{\"name\":\"${escapeJson(meshes[it].name)}\",\"mesh\":$it}" }
        return "{" +
            "\"asset\":{\"version\":\"2.0\",\"generator\":\"RoofMeasure Vision 2.0\"}," +
            "\"scene\":0,\"scenes\":[{\"name\":\"${escapeJson(model.id.value)}\",\"nodes\":[${meshes.indices.joinToString(",")}]}]," +
            "\"nodes\":[$nodes],\"meshes\":[${meshJson.joinToString(",")}]," +
            "\"materials\":[{\"name\":\"Roof\",\"pbrMetallicRoughness\":{\"baseColorFactor\":[0.12,0.55,0.35,1.0],\"metallicFactor\":0.0,\"roughnessFactor\":0.8}}]," +
            "\"buffers\":[{\"byteLength\":$byteLength}],\"bufferViews\":[${viewJson.joinToString(",")}],\"accessors\":[${accessorJson.joinToString(",")}]" +
            "}"
    }

    private data class MeshDescriptor(
        val name: String,
        val entityId: String,
        val vertices: List<Vector3>,
        val indexCount: Int,
        val positionsOffset: Int,
        val positionsLength: Int,
        val indicesOffset: Int,
        val indicesLength: Int,
    )
}

private class ByteWriter(initialCapacity: Int = 256) {
    private var data = ByteArray(initialCapacity.coerceAtLeast(1))
    var size: Int = 0
        private set

    fun writeInt(value: Int) {
        ensure(4)
        data[size++] = (value and 0xff).toByte()
        data[size++] = ((value ushr 8) and 0xff).toByte()
        data[size++] = ((value ushr 16) and 0xff).toByte()
        data[size++] = ((value ushr 24) and 0xff).toByte()
    }

    fun writeFloat(value: Float) = writeInt(value.toBits())
    fun writeBytes(bytes: ByteArray) { ensure(bytes.size); bytes.copyInto(data, size); size += bytes.size }
    fun align4() { while (size % 4 != 0) writeByte(0) }
    fun toByteArray(): ByteArray = data.copyOf(size)

    private fun writeByte(value: Int) { ensure(1); data[size++] = value.toByte() }
    private fun ensure(additional: Int) {
        if (size + additional <= data.size) return
        data = data.copyOf((data.size * 2).coerceAtLeast(size + additional))
    }
}

private fun ByteArray.padTo4(padding: Int): ByteArray {
    val newSize = (size + 3) / 4 * 4
    if (newSize == size) return this
    return copyOf(newSize).also { result -> for (index in size until newSize) result[index] = padding.toByte() }
}
