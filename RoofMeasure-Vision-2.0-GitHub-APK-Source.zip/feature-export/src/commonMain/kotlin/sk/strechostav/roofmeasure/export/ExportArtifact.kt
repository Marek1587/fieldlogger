package sk.strechostav.roofmeasure.export

data class ExportArtifact(
    val fileName: String,
    val mediaType: String,
    val bytes: ByteArray,
    val warnings: List<String> = emptyList(),
) {
    init {
        require(fileName.isNotBlank())
        require(mediaType.isNotBlank())
        require(bytes.isNotEmpty())
    }

    override fun equals(other: Any?): Boolean = other is ExportArtifact &&
        fileName == other.fileName && mediaType == other.mediaType && bytes.contentEquals(other.bytes) && warnings == other.warnings

    override fun hashCode(): Int = 31 * (31 * fileName.hashCode() + mediaType.hashCode()) + bytes.contentHashCode()
}

interface ModelExporter {
    val extension: String
    fun export(baseName: String, model: sk.strechostav.roofmeasure.modeling.ParametricRoofModel): ExportArtifact
}

internal fun escapeJson(value: String): String = buildString {
    value.forEach { character ->
        when (character) {
            '"' -> append("\\\"")
            '\\' -> append("\\\\")
            '\n' -> append("\\n")
            '\r' -> append("\\r")
            '\t' -> append("\\t")
            else -> append(character)
        }
    }
}

internal fun escapeXml(value: String): String = value
    .replace("&", "&amp;")
    .replace("<", "&lt;")
    .replace(">", "&gt;")
    .replace("\"", "&quot;")
    .replace("'", "&apos;")

internal fun Double.jsonNumber(): String {
    require(isFinite())
    return toString()
}
