package sk.strechostav.roofmeasure.export

import sk.strechostav.roofmeasure.domain.Quantity
import sk.strechostav.roofmeasure.math.Vector3
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel

class JsonModelExporter : ModelExporter {
    override val extension: String = "json"

    override fun export(baseName: String, model: ParametricRoofModel): ExportArtifact {
        val json = buildString {
            append("{\n  \"schema\":\"roofmeasure.model.v2\",")
            append("\n  \"modelId\":\"").append(escapeJson(model.id.value)).append("\",")
            append("\n  \"projectId\":\"").append(escapeJson(model.projectId.value)).append("\",")
            append("\n  \"revision\":").append(model.revision.value).append(',')
            append("\n  \"coordinateFrame\":\"").append(model.coordinateFrame).append("\",")
            append("\n  \"planes\":[")
            model.planes.forEachIndexed { index, plane ->
                if (index > 0) append(',')
                append("{\"id\":\"").append(escapeJson(plane.id.value)).append("\",")
                append("\"normal\":").append(vector(plane.normal)).append(',')
                append("\"offsetMetres\":").append(plane.offsetMetres.jsonNumber()).append(',')
                append("\"boundary\":[").append(plane.boundary.joinToString(",", transform = ::vector)).append("],")
                append("\"openings\":[")
                plane.openings.forEachIndexed { openingIndex, opening ->
                    if (openingIndex > 0) append(',')
                    append('[').append(opening.joinToString(",", transform = ::vector)).append(']')
                }
                append("],\"area\":").append(quantity(plane.area)).append(',')
                append("\"horizontalArea\":").append(quantity(plane.horizontalArea)).append(',')
                append("\"slope\":").append(quantity(plane.slope)).append('}')
            }
            append("],\n  \"edges\":[")
            model.edges.forEachIndexed { index, edge ->
                if (index > 0) append(',')
                append("{\"id\":\"").append(escapeJson(edge.id.value)).append("\",")
                append("\"lineId\":\"").append(escapeJson(edge.lineId.value)).append("\",")
                append("\"type\":\"").append(edge.semanticType.name).append("\",")
                append("\"start\":").append(vector(edge.start)).append(',')
                append("\"end\":").append(vector(edge.end)).append(',')
                append("\"length\":").append(quantity(edge.length)).append('}')
            }
            append("],\n  \"objects\":[")
            model.objects.forEachIndexed { index, objectModel ->
                if (index > 0) append(',')
                append("{\"id\":\"").append(escapeJson(objectModel.id.value)).append("\",\"type\":\"")
                    .append(objectModel.type).append("\",\"hostPlaneId\":")
                    .append(objectModel.hostPlaneId?.let { "\"${escapeJson(it.value)}\"" } ?: "null").append('}')
            }
            append("],\n  \"quantities\":{")
            append("\"totalRoofArea\":").append(quantity(model.quantities.totalRoofArea)).append(',')
            append("\"totalHorizontalArea\":").append(quantity(model.quantities.totalHorizontalArea)).append(',')
            append("\"openingArea\":").append(quantity(model.quantities.openingArea)).append("}\n}")
        }
        return ExportArtifact("$baseName.$extension", "application/json", json.encodeToByteArray())
    }

    private fun vector(vector: Vector3): String =
        "[${vector.x.jsonNumber()},${vector.y.jsonNumber()},${vector.z.jsonNumber()}]"

    private fun quantity(quantity: Quantity): String = buildString {
        append("{\"valueSi\":").append(quantity.valueSi.jsonNumber())
        append(",\"unit\":\"").append(quantity.unit.name).append('"')
        append(",\"sigma\":").append(quantity.uncertainty.sigma.jsonNumber())
        append(",\"qualityClass\":\"").append(quantity.qualityClass.name).append('"')
        append(",\"calibrationState\":\"").append(quantity.calibrationState.name).append("\"}")
    }
}
