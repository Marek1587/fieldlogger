package sk.strechostav.roofmeasure.export

import sk.strechostav.roofmeasure.modeling.ParametricRoofModel

class DaeModelExporter : ModelExporter {
    override val extension: String = "dae"

    override fun export(baseName: String, model: ParametricRoofModel): ExportArtifact {
        val warnings = if (model.planes.any { it.openings.isNotEmpty() }) {
            listOf("MVP DAE triangulátor neexportuje plochu s otvorom; dotknutá rovina je vynechaná, aby otvor nebol omylom vyplnený.")
        } else emptyList()
        val exportable = model.planes.filter { it.boundary.size >= 3 && it.openings.isEmpty() }
        val xml = buildString {
            append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
            append("<COLLADA xmlns=\"http://www.collada.org/2005/11/COLLADASchema\" version=\"1.4.1\">\n")
            append("<asset><contributor><authoring_tool>RoofMeasure Vision 2.0</authoring_tool></contributor>")
            append("<unit name=\"meter\" meter=\"1\"/><up_axis>Z_UP</up_axis></asset>\n")
            append("<library_effects><effect id=\"roof-effect\"><profile_COMMON><technique sid=\"common\"><lambert>")
            append("<diffuse><color>0.12 0.55 0.35 1</color></diffuse></lambert></technique></profile_COMMON></effect></library_effects>\n")
            append("<library_materials><material id=\"roof-material\" name=\"Roof\"><instance_effect url=\"#roof-effect\"/></material></library_materials>\n")
            append("<library_geometries>\n")
            exportable.forEachIndexed { planeIndex, plane ->
                val id = "plane-$planeIndex"
                val positions = plane.boundary.joinToString(" ") { "${it.x} ${it.y} ${it.z}" }
                val triangles = (1 until plane.boundary.lastIndex).flatMap { listOf(0, it, it + 1) }.joinToString(" ")
                append("<geometry id=\"$id-geometry\" name=\"").append(escapeXml(plane.name)).append("\"><mesh>")
                append("<source id=\"$id-positions\"><float_array id=\"$id-positions-array\" count=\"")
                    .append(plane.boundary.size * 3).append("\">").append(positions).append("</float_array>")
                append("<technique_common><accessor source=\"#$id-positions-array\" count=\"").append(plane.boundary.size)
                    .append("\" stride=\"3\"><param name=\"X\" type=\"float\"/><param name=\"Y\" type=\"float\"/><param name=\"Z\" type=\"float\"/></accessor></technique_common></source>")
                append("<vertices id=\"$id-vertices\"><input semantic=\"POSITION\" source=\"#$id-positions\"/></vertices>")
                append("<triangles material=\"roof-material-symbol\" count=\"").append((plane.boundary.size - 2).coerceAtLeast(0))
                    .append("\"><input semantic=\"VERTEX\" source=\"#$id-vertices\" offset=\"0\"/><p>").append(triangles).append("</p></triangles>")
                append("</mesh></geometry>\n")
            }
            append("</library_geometries>\n<library_visual_scenes><visual_scene id=\"Scene\" name=\"RoofMeasure_")
                .append(model.revision.value).append("\">")
            exportable.forEachIndexed { planeIndex, plane ->
                append("<node id=\"plane-$planeIndex-node\" name=\"").append(escapeXml(plane.name)).append("\" type=\"NODE\">")
                append("<instance_geometry url=\"#plane-$planeIndex-geometry\"><bind_material><technique_common>")
                append("<instance_material symbol=\"roof-material-symbol\" target=\"#roof-material\"/>")
                append("</technique_common></bind_material></instance_geometry></node>")
            }
            append("</visual_scene></library_visual_scenes><scene><instance_visual_scene url=\"#Scene\"/></scene></COLLADA>")
        }
        return ExportArtifact("$baseName.$extension", "model/vnd.collada+xml", xml.encodeToByteArray(), warnings)
    }
}
