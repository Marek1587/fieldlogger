# IFC4 Export Specification

## Profil

Export je STEP Physical File podľa IFC4, lokálne súradnice, SI jednotky a stabilné IFC GUID odvodené z projektového namespace UUID + entity UUID. Exportér je deterministický pre rovnakú revíziu.

## Hierarchia

- `IfcProject`
- `IfcSite`
- `IfcBuilding`
- `IfcBuildingStorey`
- `IfcRoof`
- strešné roviny ako `IfcSlab` s `ROOF` predefined type, agregované/združené podľa validačného profilu;
- otvory ako `IfcOpeningElement` + `IfcRelVoidsElement`;
- okná/svetlíky ako `IfcWindow` tam, kde sémantika sedí;
- komín a atypické prvky ako najvhodnejšia štandardná entita alebo `IfcBuildingElementProxy` s explicitným ObjectType.

## Geometria

Preferované reprezentácie sú polygonálne extrúzie/BRep alebo triangulated face set podľa typu entity a schopností cieľových validátorov. Lokálne placementy minimalizujú veľké súradnice. Otvory sú skutočné void vzťahy, nie iba vizuálne povrchy.

## Vlastnosti

`Pset_RoofMeasureQuality`:

- `SemanticType`
- `MeasuredLength`
- `SlopeDegrees`
- `Area`
- `UncertaintyMillimetres`
- `QualityClass`
- `DataSource`
- `LaserConstraintCount`
- `CalibrationState`
- `ObservationCount`
- `ModelRevision`

Auditné detaily sa prikladajú ako externý JSON manifest; IFC nesmie obsahovať osobné/obrazové dáta bez voľby používateľa.

## Jednotky a orientácia

`IfcUnitAssignment` deklaruje metre, štvorcové metre, radiány/stupne podľa property typu. Exportný model je pravotočivý; face winding a normals sa kontrolujú. Všetky placement matice musia byť ortonormálne v tolerancii.

## GUID

Mapovanie UUID→IfcGloballyUniqueId používa štandardnú 22-znakovú kompresiu a je testované round-tripom. Zmena geometrie tej istej entity GUID nemení; nová sémantická entita dostane nový GUID.

## Validácia

1. syntaktický parse nezávislou IFC knižnicou;
2. schema/entity/attribute validácia;
3. kontrola hierarchie a vzťahov;
4. jednotky a placements;
5. manifold/orientácia tam, kde sa deklaruje uzavretý objem;
6. import smoke test vo validátore a dvoch cieľových BIM nástrojoch;
7. porovnanie plôch/dĺžok s doménovým modelom.

## Degradácia

Ak objekt nemožno korektne mapovať, použije sa proxy s úplným property setom a upozornením v manifeste. Export sa nesmie tváriť validne, ak parser alebo povinné invarianty zlyhajú.
