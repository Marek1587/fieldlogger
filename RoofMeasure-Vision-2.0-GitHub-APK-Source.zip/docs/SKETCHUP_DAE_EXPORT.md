# SketchUp / DAE Export

## Cieľ

DAE je hlavná otvorená cesta do SketchUp bez proprietárneho SKP writeru. Model má byť v reálnej mierke, čitateľne zoskupený a založený na parametrických plochách.

## Scéna

- root node: projekt/revízia;
- group pre každú strešnú rovinu;
- samostatné komponenty pre komín, okno, vikier a prestup;
- voliteľná skupina významových hrán;
- voliteľná textúrovaná referenčná vrstva.

Názvy sú stabilné a bezpečné: `RoofPlane_R3`, `Chimney_C1`, `RoofWindow_W1`.

## Geometria

Rovina sa trianguluje constrained algoritmom s otvormi, ale zachová sa zoznam pôvodných boundary edges v `extra` manifeste. Zdieľané topologické vrcholy majú identické súradnice. Nepoužíva sa decimovaný fotogrametrický mesh pre technický export.

## Jednotky a osi

COLLADA `asset/unit meter="1"`; `up_axis` je explicitne `Z_UP`. Exportér obsahuje jednu dokumentovanú transformáciu do cieľového systému a test cube 1 m v integračnom fixture.

## Materiály a textúry

Technický režim používa jednoduché materiály podľa typu. Textúrovaný režim kopíruje obrázky do relatívneho balíka, používa prenositeľné URI a UV bez absolútnych ciest. Chýbajúca textúra neporuší technickú geometriu.

## Hrany

Konštrukčné línie sa exportujú ako samostatná line geometry alebo companion JSON podľa podpory importéra. Hrany otvorov a hranice rovín sú vždy prítomné v triangulácii a pomenovanom manifeste.

## SKP stratégia

Priamy SKP export sa implementuje iba cez licenčne vhodné oficiálne SDK v samostatnom desktop/cloud konvertore. Mobilná aplikácia vždy ponúkne DAE/GLB a zreteľne uvedie, že konverzia nemení technické jednotky.

## GLB/OBJ

GLB používa pomenované nodes, PBR materiály, metre a custom `extras` pre semantic ID/quality. OBJ má MTL a samostatné groups; jednotky a metadata sú v manifeste, pretože OBJ ich štandardne nevyjadruje.

## Validácia

- XML schema/well-formed kontrola;
- žiadne neplatné indexy, NaN ani degenerované trojuholníky;
- bounding box a referenčné dĺžky súhlasia do numerickej tolerancie;
- všetky otvory zostávajú prázdne;
- import do aktuálne podporovanej verzie SketchUp a vizuálna kontrola skupín;
- round-trip quantity comparison.
