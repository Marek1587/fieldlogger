# Uncertainty Model

## Zásada

Neistota je súčasť dátového modelu, nie dodatočný farebný efekt. Rozlišujeme náhodnú neistotu, systematické riziko, kvalitu pozorovateľnosti a sémantickú neistotu.

## Reprezentácie

- bod: 3×3 covariance v projektovom frame;
- línia: covariance minimálnych line parametrov plus koncových intervalov;
- rovina: covariance normály/offsetu;
- skalárna veličina: štandardná neistota a interval;
- hypotéza triedy: kalibrovaná distribúcia pravdepodobnosti;
- systematické riziká: explicitné flags, nie falošné Gaussian sigma.

## Triedy A–E

| Trieda | Minimálna interpretácia |
|---|---|
| A | viacnásobne nezávisle laserovo overené, bez významného konfliktu |
| B | laserovo kalibrované a geometricky pozorovateľné |
| C | kvalitná viacpohľadová obrazová rekonštrukcia |
| D | jedna/slabá hypotéza alebo odvodenie so silným priorom |
| E | konflikt, neoverené alebo nepozorovateľné |

Trieda nie je iba prah v milimetroch. Vyžaduje aj provenance a observačné podmienky.

## Propagácia

Pre dĺžky, sklon a jednoduché plochy sa používa prvý rád `Σ_y = J Σ_x Jᵀ`. Pri silnej nelinearite, blízkosti degenerácie alebo komplexných polygonoch sa použije deterministický Monte Carlo/unscented odhad. Korelácie medzi zdieľanými vrcholmi sa nesmú ignorovať.

## Kalibrácia

Predikované intervaly sa na validačnom datasete porovnávajú so survey ground truth. Sleduje sa coverage 68/95 %, reliability diagram a chyba podľa zariadenia, vzdialenosti, povrchu a typu geometrie. Nekalibrovaný model nesmie zobrazovať presné ±mm.

## UI mapa

Farba je kombinovaná so štýlom:

- A/B zelená plná;
- C modrá plná;
- D oranžová prerušovaná;
- E červená alebo sivá podľa konfliktu/nepozorovania.

Detail vysvetlí dominantný zdroj: málo paralaxy, iba jeden pohľad, chýba mierka, konflikt merania alebo neistý koniec.

## Konzervatívne pravidlá

- výsledná veličina nepreberá lepšiu triedu než kritické vstupy bez nezávislej väzby;
- systematický flag môže znížiť triedu bez zmeny sigma;
- rejected/outlier meranie nezlepšuje triedu;
- zaokrúhlenie displeja sa riadi neistotou;
- export nesie raw SI hodnotu aj prezentovaný interval.

## Audit

Každá zmena neistoty odkazuje na solver revíziu, observation IDs a calibration profile. Používateľský override je viditeľný a nemení vypočítanú covariance; pridáva samostatný status.
