# Structural Line Graph

## Model

Graf je kanonická topológia technického modelu. Obsahuje uzly, orientované polhrany, sémantické hrany, slučky plôch, otvory, roviny a objektové inštancie. Geometria a topológia majú oddelené verzie, aby optimalizácia súradníc nemenila identitu.

## Entity

- `StructuralNode`: UUID, 3D poloha/covariance, typ junctionu, incidentné hrany;
- `StructuralEdge`: UUID, dva uzly, 3D krivka, semantic type, observations;
- `HalfEdge`: orientácia, next/prev/twin, loop ID;
- `SurfaceLoop`: vonkajší okruh alebo otvor, orientácia, validita;
- `RoofPlane`: nosná rovina, slučky, susedia, slope/aspect;
- `ObjectInstance`: typ, host plane, obrys, extrúzia/parametre.

## Invarianty

1. Potvrdená hrana má dva uzly; dočasný otvorený kandidát môže mať virtuálny koniec.
2. Každá half-edge patrí najviac jednej slučke a má zhodnú geometriu s twin.
3. Vonkajšia slučka je jednoduchá a orientovaná proti smeru hodinových ručičiek v lokálnej báze roviny; otvory opačne.
4. Otvor leží v host slučke a nepretína iný otvor.
5. Snap tolerancia sa odvodzuje z covariance, nie z pevného počtu pixelov.

## Tvorba grafu

1. Normalizovať a zlúčiť kolineárne 3D line hypotheses.
2. Nájsť blízke konce a priesečníky s uncertainty gatingom.
3. Vytvoriť návrhy junctionov; nejasné návrhy vyžiadajú potvrdenie.
4. Rozdeliť hrany v potvrdených priesečníkoch.
5. V rovinnej projekcii vyhľadať minimálne cykly/face walks.
6. Skórovať slučku podľa line confidence, rovinnosti, sémantiky a pokrytia.
7. Vytvoriť roviny a otvory iba po topologickej validácii.

## Sémantické pravidlá

- ridge/hip/valley typicky susedí s dvoma strešnými rovinami;
- eave/gable/parapet je typicky hraničná hrana jednej roviny;
- opening loop patrí jednej host plane;
- chimney/roof-window môže mať host opening a samostatnú objemovú inštanciu;
- pravidlá sú mäkké constraints, lebo rozostavané a atypické objekty existujú.

## Úpravy používateľa

Operácie `Connect`, `Split`, `Extend`, `CloseLoop`, `Detach`, `Reassign` sú príkazy s precondition, náhľadom, inverse command a auditom. Každá operácia spustí lokálnu validáciu a označí odvodené roviny ako stale.

## Konflikty

Konflikt vznikne pri geometricky nemožnom junctione, self-intersection, duplicitnej hrane, nezlučiteľnej sémantike alebo veľkom rezíduu. Graf konflikt zachová a publikuje návrhy; automatická oprava bez dôkazu sa nevykoná.

## Serializácia

Ukladajú sa stabilné ID, explicitné schema version, jednotky a referencie. Odvodené indexy/adjacency cache sa po načítaní prebudujú a validujú.

## Testovacie fixtures

Jednospádová, sedlová, valbová a L-strecha; komínový otvor; takmer dotýkajúce sa hrany; T/X junction; neisté konce; self-intersection a rollback každej manuálnej operácie.
