# RoofMeasure Vision 2.0 — Product Requirements

## Poslanie

RoofMeasure Vision 2.0 premieňa tri prirodzené činnosti — ukázanie línie, obídenie objektu kamerou a premeranie odporúčaného rozmeru — na auditovateľný parametrický model strechy alebo budovy. Primárnym výstupom nie je mesh, ale sémantická geometria s topológiou, neistotou a BIM exportom.

## Cieľové roly

- terénny pracovník: potrebuje jednoduchý režim a jednoznačné pokyny;
- geodet/BIM technik: potrebuje rezíduá, pôvod dát a možnosť opravy;
- projektant/rozpočtár: potrebuje čisté roviny, rozmery a výkaz výmer;
- správca tímu: potrebuje audit, verzie a reprodukovateľné exporty.

## Produktové zásady

1. Každé odvodené číslo nesie jednotku, neistotu, triedu kvality a pôvod.
2. Geometria nikdy nepredstiera presnosť, ktorú pozorovania nepodporujú.
3. Používateľské potvrdenie je signál, nie dôvod ignorovať 3D konflikt.
4. Laserové meranie je vážená väzba s neistotou, nie slepé nastavenie mierky.
5. Offline funkcie pokrývajú celý kritický terénny tok.
6. Surové dáta a audit sú nemenné; odvodený model je verzovaný.

## Rozsah MVP 2.0

- založenie, uloženie a znovuotvorenie projektu;
- CameraX náhľad a kreslenie jednej alebo viacerých polylínií;
- klasifikácia, potvrdenie, odmietnutie a vizuálne stavy línií;
- sledovanie bodov optickým tokom a stabilné ID;
- ARCore póza a triangulácia tam, kde ju zariadenie podporuje;
- uzavretá slučka, jednoduchá strešná rovina a 3D technický náhľad;
- manuálny rozmer a abstrakcia BLE meradla;
- globálna mierka, robustná optimalizácia vzdialenostných väzieb;
- lokálne JSON, GLB a DAE exporty;
- audit udalostí a základná neistota A–E.

## Plný rozsah

Plná verzia pridáva multimodálnu detekciu, lokálnu adaptáciu, graf línií a rovín, objekty/otvory, informačný plánovač meraní, lokálnu deformáciu, IFC4/OBJ/DXF/PDF/CSV, dense reconstruction, textúry a terénne validovanú presnosť.

## Mimo rozsahu prvej mobilnej verzie

- priame zapisovanie proprietárneho SKP; používa sa DAE/GLB alebo autorizovaný konvertor;
- bezpečnostné rozhodovanie o prístupe na strechu;
- garantovaná geodetická presnosť bez kalibrácie a kontrolných meraní;
- automatické rozhodnutie o statickej spôsobilosti;
- cloud ako povinná súčasť merania.

## Funkčné požiadavky

| ID | Požiadavka | Priorita | Akceptácia |
|---|---|---:|---|
| PR-01 | Vytvoriť projekt | P0 | projekt má UUID, čas, typ a lokálnu revíziu |
| PR-02 | Označiť a klasifikovať líniu | P0 | dotyk vytvorí polyline a auditnú udalosť |
| PR-03 | Sledovať líniu | P0 | línia má stabilné ID a projekciu v každom spracovanom frame |
| PR-04 | Vytvoriť 3D väzbu | P0 | minimálne dve geometricky vhodné pozorovania vytvoria 3D hypotézu |
| PR-05 | Vytvoriť topologickú slučku | P0 | graf rozpozná a používateľ potvrdí uzavretý obrys |
| PR-06 | Prijať rozmer | P0 | manuálny/BLE rozmer je priradený k dvom bodom alebo línii |
| PR-07 | Optimalizovať model | P0 | vznikne nová revízia s rezíduami a kovarianciou |
| PR-08 | Exportovať | P0 | JSON, GLB a DAE prejdú validačnými testami |
| PR-09 | Odporučiť ďalší krok | P1 | systém vysvetlí jednu najhodnotnejšiu akciu |
| PR-10 | Exportovať IFC4 | P1 | súbor má jednotky, hierarchiu, stabilné GUID a vlastnosti kvality |

## Nefunkčné požiadavky

- živý overlay: cieľ 30 FPS, minimálne 20 FPS na referenčnom zariadení;
- rozpočet tracking pipeline: p95 do 35 ms pri adaptívnom rozlíšení;
- latencia potvrdenia rozmeru po optimalizáciu MVP: p95 do 500 ms;
- projekt musí prežiť pád procesu bez straty potvrdených udalostí;
- export rovnakej revízie musí byť deterministický;
- žiadna sieťová závislosť v kritickom toku;
- osobné a obrazové dáta sú lokálne šifrovateľné a exportované iba vedomou akciou;
- prístupnosť: minimálna dotyková plocha 48 dp, nepoužívať iba farbu.

## Metriky úspechu

- medián času po prvý kalibrovaný obrys pod 8 minút;
- aspoň 90 % relácií bez straty dát alebo neobnoviteľného stavu;
- používateľ v jednoduchom režime vykoná tok bez expertných nastavení;
- hlavné laserovo kalibrované hrany spĺňajú deklarovaný interval v aspoň 95 % validačných prípadov;
- nulový počet nevalidných exportov v referenčnom regresnom datasete.

## Release gate

Release vyžaduje automatické testy, meranie výkonu, BLE test s fyzickým zariadením, validačné importy v najmenej dvoch BIM/3D nástrojoch a podpísaný terénny protokol. „Funguje na emulátore“ nie je produkčný dôkaz.
