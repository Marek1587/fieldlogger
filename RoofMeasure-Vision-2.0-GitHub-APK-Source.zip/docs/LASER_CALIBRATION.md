# Laser Calibration and BLE

## Rozsah

Vrstva meradla je oddelená od konkrétneho Bosch protokolu. Doména prijíma iba overené `MeasurementSample` s hodnotou SI, neistotou, timestampom, device ID, raw payload hashom a stavom potvrdenia.

## Integrácia Bosch GLM 120 C

Produkčná implementácia musí používať verejne/licenčne dovolenú dokumentáciu alebo oficiálne SDK/protokol. UUID charakteristík a payload formát sa nesmú hádať. Bez overeného protokolu adaptér funguje v diagnostickom režime: discovery, bonding, service inventory a uloženie redigovaného raw záznamu bez interpretácie.

## BLE stavový automat

`Unsupported → PermissionRequired → BluetoothOff → Scanning → DeviceFound → Connecting → Discovering → Ready → Measuring → ValueReceived → Confirming`

Chybové vetvy: timeout, disconnect, protocol mismatch, invalid checksum, stale value a user cancel. Reconnect má ohraničený exponential backoff a nikdy nepriradí starý sample k novému cieľu.

## Mapovanie merania

1. Používateľ vyberie geometrickú väzbu A–B.
2. Vytvorí sa jednorazový `MeasurementIntent` s UUID a časovým oknom.
3. BLE sample sa uloží ako nepriradený.
4. UI zobrazí hodnotu, jednotku, cieľ a zdroj.
5. Potvrdenie vytvorí `DistanceConstraint`; zrušenie sample nemaže.

## Neistota

Základ vychádza z dokumentovanej špecifikácie zariadenia a podmienok. Pridáva sa neistota mapovania cieľa, držania, odrazu a prípadného offsetu držiaka. „Presné/orientačné“ sú predvoľby covariance, nie iba popis.

## Držiak telefón–laser

Pevný držiak vyžaduje kalibráciu extrinsics `T_camera_laser`, verziu profilu, zariadenie a teplotu/čas. Bez nej sa laserová dĺžka používa ako skalárna vzdialenosť, nie ako smerový lúč. Kalibrácia sa validuje redundantným cieľom.

## Ručný vstup

Vyžaduje explicitnú jednotku, rozsahovú kontrolu, potvrdenie cieľa a defaultne väčšiu neistotu. Parser nepoužíva locale-ambiguous hodnoty bez potvrdenia.

## Konflikty

Robustný solver môže znížiť váhu outlieru, ale meranie sa automaticky nemaže. UI zobrazí rezíduum v mm a sigma, ponúkne zopakovať, skontrolovať cieľ alebo označiť orientačné.

## Bezpečnosť a dáta

Android runtime permissions sa žiadajú až pri funkcii. Device identifiers sa lokálne pseudonymizujú. Raw BLE diagnostika sa exportuje iba so súhlasom a bez susedných zariadení.

## Testovanie

Fake transport pokrýva scan/connect/disconnect/stale/duplicate/out-of-order. Hardware matrix zahŕňa podporované Android verzie, najmenej dva telefóny, tri vzdialenosti, rôzne povrchy a reconnect počas merania.
