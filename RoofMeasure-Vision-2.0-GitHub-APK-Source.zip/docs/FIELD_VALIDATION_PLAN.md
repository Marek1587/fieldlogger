# Field Validation Plan

## Cieľ

Overiť nielen priemernú chybu, ale aj kalibráciu deklarovanej neistoty, robustnosť workflow a hranice použiteľnosti v reálnych podmienkach.

## Ground truth

Referenčný model vytvorí kvalifikovaný geodet kombináciou totálnej stanice/validovaného skenera a kontrolných dĺžok. Každý ground-truth bod/rovina má vlastnú neistotu a nezávislý kontrolný protokol.

## Vzorka

Minimálne:

- 30 objektov pre pilot, 100 pre release claim;
- sedlové, valbové, pultové, členité a ploché strechy;
- plech, škridla, fólia, asfalt, vegetačné/odrazivé povrchy;
- komíny, okná, vikiere, atiky a prestupy;
- slnko, oblačno, tieň, ráno/večer, primeraný vietor;
- low/mid/high Android zariadenia a viac operátorov.

## Protokol

1. Bez znalosti ground truth používateľ vykoná štandardný jednoduchý tok.
2. Zaznamená sa čas, počet krokov, zásahov a neúspešných pokusov.
3. Uloží sa zamknutá modelová revízia a exporty.
4. Až potom sa spáruje s ground truth.
5. Nezávislý analytik vyhodnotí chyby a coverage intervalov.

## Metriky geometrie

- absolútna/relatívna chyba hlavných a vedľajších hrán;
- chyba sklonu, roviny, plochy a horizontálnej projekcie;
- junction/topology precision a recall;
- otvory/objekty: detection a dimension error;
- similarity-aligned vizuálny model vs laserovo kalibrovaný model;
- 95 % interval coverage podľa triedy A–E.

## UX a prevádzka

Čas po prvý obrys/model/export, počet potvrdení, opakované merania, prerušenia trackingu, BLE reconnect, pády, tepelný limit, skóre porozumenia pokynom a subjektívna záťaž.

## Bezpečnostné pravidlá

Validácia nevyžaduje vstup na strechu, pohyb do vozovky ani mierenie lasera na ľudí/vozidlá. Bezpečnostný pozorovateľ môže pokus ukončiť. Počas nepriaznivých podmienok sa záznam označí alebo odloží.

## Analýza

Reportuje sa distribúcia a worst-case segmenty, nie iba priemer. Predregistrujú sa exclusion pravidlá. Zlyhania sa triedia na používateľské, senzorové, algoritmické a protokolové; neúspešný scan je výsledok, nie vyradená vzorka.

## Deklarácia presnosti

Marketingový/produktový claim vznikne až z dolnej hranice výkonu na relevantnej populácii a obsahuje podmienky: zariadenie, typ kalibrácie, rozsah vzdialenosti a kvalitu. Pri nedostatku dôkazov UI používa konzervatívny opis bez ±mm.
