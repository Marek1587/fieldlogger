# Implementation Roadmap

## Prístup

Roadmap je založená na vertikálnych, demonštrovateľných rezoch. Každá fáza končí dátovým fixture, testami, telemetriou a rozhodnutím pokračovať. Produkčné označenie je dovolené až po hardvérovej a terénnej validácii.

## Fáza 0 — Foundations (2–3 týždne)

Modulárny build, CI, code style, doménové typy, jednotky/rámce, event store, projektová serializácia, fake kamera/BLE a referenčné fixtures. Gate: deterministické core testy a obnova projektu.

## Fáza 1 — Jedna línia (3–4 týždne)

CameraX, Compose overlay, kreslenie, patch/flow tracking, stav kvality, audit. Gate: stabilné ID a p95 live latency na device matrix.

## Fáza 2 — Viac línií a učenie (3–4 týždne)

Klasifikácia, návrhy, pozitívne/negatívne príklady, vizuálne stavy. Gate: precision@3 a UX test bez expertných nastavení.

## Fáza 3 — AR a 3D línie (4–6 týždňov)

ARCore adapter, frames, keyframes, line triangulation, relokalizácia. Gate: syntetická/terénna reprojection a failure honesty.

## Fáza 4 — Topológia a roviny (4–6 týždňov)

Half-edge graph, junction proposals, slučky, plane hypotheses, edit commands. Gate: fixture strechy bez porušenia invariantov.

## Fáza 5 — Laser (3–5 týždňov)

BLE abstraction, potvrdený Bosch protokol/SDK, diagnostic mode, manual input, measurement intent. Gate: hardware matrix a žiadne zlé priradenie stale sample.

## Fáza 6 — Solver a neistota (5–8 týždňov)

Sim3 scale, distance/plane/topology constraints, robustné straty, covariance a konflikty. Gate: synthetic recovery, outlier test, platformová deterministickosť.

## Fáza 7 — Parametrický model a planner (4–6 týždňov)

Roof planes/objects, quantities, information-gain planner a next-action engine. Gate: meranie vyberané lepšie než baseline a správne stop pravidlo.

## Fáza 8 — Exporty (4–6 týždňov)

JSON/CSV/GLB/OBJ/DAE/DXF, potom IFC4 a PDF. Gate: nezávislé parsre, SketchUp/BIM importy a quantity round-trip.

## Fáza 9 — Produkčné spevnenie (6–10 týždňov)

Process death, šifrovanie, migrácie, výkon, thermal/battery, accessibility, observability, SBOM, beta distribúcia. Gate: P0 release gates.

## Fáza 10 — Terénna validácia (priebežne, release 8–12 týždňov)

Pilot 30 a release dataset 100 objektov, kalibrácia neistoty, incident workflow a podporované zariadenia. Gate: podpísaný validačný report.

## Tímy a vlastníctvo

- Mobile: app, kamera, UI, lifecycle, storage;
- Vision/SLAM: candidates, tracking, keyframes, AR integrácia;
- Geometry: graph, solver, uncertainty, model;
- BIM/Export: formáty a validátory;
- Hardware: BLE/protokol/kalibrácia;
- QA/DevOps: fixtures, CI, device lab, field protocol.

## Riziká s rozhodovacími bodmi

- Bosch protokol/licencia: potvrdiť pred produkčným adaptérom;
- natívny vs Kotlin solver: benchmark vo fáze 3, zachovať C ABI/KMP hranicu;
- modely segmentácie: licencia, veľkosť, NPU pokrytie a offline kvalita;
- ARCore device variability: explicitný support matrix a 2D degraded mode;
- IFC interoperabilita: validovať priebežne, nie až na konci.

## Definícia „hotové“

Kód, testy, dokumentácia, auditná schéma, výkonové čísla, bezpečnostná kontrola a terénne dôkazy. Samotná implementovaná trieda alebo demo nie je dokončená produktová funkcia.
