# Implementation Status

Stav je viazaný na build `0.1.0-mvp`. „Implementované“ znamená, že kód je zapojený a zostavený; neznamená terénnu certifikáciu.

| Oblasť | Stav | Dôkaz / hranica |
|---|---|---|
| Projekty a obnova | Implementované MVP | Room schéma v1, metadata, línie, merania, audit |
| CameraX | Implementované MVP | live preview, Y-plane frame, backpressure |
| Kreslenie/klasifikácia | Implementované MVP | normalized polyline, 11 typov, vizuálne stavy |
| Line candidates | Implementované jadro | OpenCV Canny + LSD; semantic/depth fusion rozhranie čaká na model |
| Tracking | Implementované MVP | pyramídový LK koncových/polyline bodov, confidence/lost stav |
| Interactive learner | Implementované jadro | online regularizovaná logistická aktualizácia; UI negatívnych tried je ďalší rez |
| AR/SLAM | Čiastočné | ARCore optional lifecycle, pose/depth config; factor graph a relokalizácia nie sú hotové |
| 3D graf/topológia | Implementované MVP | snap, uzly/hrany, degree-2 slučky, invariant validator |
| Plane/model | Implementované MVP | planárna slučka, plocha, projekcia, sklon, quantities |
| Bosch GLM 120 C | Diagnostika | scan/connect/service inventory; žiadne hádané proprietary payloady |
| Manuálny rozmer | Implementované | jednotka, rozsah, kalibrácia mierky |
| Solver | Implementované MVP | robustná globálna mierka; plný sparse BA a lokálna deformácia čakajú |
| Measurement planner | Implementované MVP | information/condition/semantic/access ranking a stop stav |
| JSON | Implementované | schema-tagged auditovateľný technický model |
| GLB | Implementované MVP | validná GLB 2.0 binárna štruktúra, pomenované meshes/extras |
| DAE | Implementované MVP | metre, Z_UP, skupiny a materiál |
| IFC4 | Implementované MVP | hierarchia, IfcRoof/IfcSlab, stable GUID, quality pset, basic validator |
| Otvory a objekty | Doménový model | plná constrained triangulácia/export nie je hotová |
| Filament 3D náhľad | Neimplementované | aktuálne je quantity/model summary a GLB výstup |
| Dense reconstruction/textúry | Neimplementované | voliteľná neskoršia offline/cloud fáza |
| Terénna presnosť | Nevalidované | bez deklarácie ±mm do ukončenia field validation |

## Overenie v repozitári

- Gradle wrapper 8.13, JDK 17, AGP 8.11.2, compile/target SDK 36;
- desktop testy: matematika, triangulácia, uzavretý graf, solver/outlier, planner, model, GLB/DAE, IFC;
- Android `:app:assembleDebug` prešiel vrátane Hilt, Room KSP, Compose, CameraX, ARCore, OpenCV a BLE;
- Room schema export: `core-storage/schemas/.../1.json`.

## Najbližšie produkčné gates

1. oficiálny Bosch protokol/SDK a hardware-in-loop test;
2. AR keyframes, multi-view line triangulation a factor graph;
3. constrained triangulácia s otvormi a plné IFC objektové mapovanie;
4. device/emulator UI testy, process-death obnova a performance benchmark;
5. pilotný terénny dataset a kalibrácia uncertainty coverage.
