# Vision Pipeline

## Cieľ

Pipeline priebežne premieňa kalibrované snímky a pózy na časovo stabilné kandidátne línie, pozorovania a 3D hypotézy. Žiadny jednotlivý vizuálny signál nerozhoduje o stavebnej hrane.

## Tok dát

`Frame → Calibration → Features/Edges → Segmentation → Candidate fusion → Tracking → Pose → Triangulation → Merge → Graph → Planes → Solver update`

## Vstupy

- YUV kamera, timestamp, rolling-shutter/exposure metadata;
- intrinsics a distortion model pre aktuálny stream;
- ARCore pose s kvalitou a prípadnou depth mapou;
- používateľské pozitívne/negatívne anotácie;
- keyframe cache a lokálny projektový adaptér.

## Tri úrovne rozlíšenia

| Úroveň | Použitie | Typický cieľ |
|---|---|---|
| Live | flow, hrany, overlay | 640–960 px dlhšia strana |
| Keyframe | deskriptory, triangulácia, segmentácia | 1440–2160 px |
| Final | textúry/dense offline | natívne rozlíšenie |

Regulátor používa frontu snímok, p95 latenciu, teplotný stav a pohyb. Staré live snímky sa zahadzujú; keyframes a auditné snímky nie.

## Detekčné vetvy

1. **Gradientová vetva:** Scharr/Canny, non-maximum suppression, LSD/EDLines.
2. **Bodová vetva:** ORB/AKAZE alebo voliteľný SuperPoint, LK flow, descriptor matching.
3. **Sémantická vetva:** on-device model strecha/obloha/fasáda/otvor/prekážka/tieň.
4. **Hĺbková vetva:** AR depth alebo monokulárna relatívna hĺbka, normály a diskontinuity.
5. **Interaktívna vetva:** vzdialenosť od ťahu, vzhľad susedných plôch a explicitný typ.

## Fusion skóre

Kandidát dostane kalibrované logit skóre z vlastností: gradient, dĺžka, kontinuita, podpora segmentácie, flow stabilita, epipolárna konzistencia, depth/normal skok, rovinný kontext a podobnosť s používateľskými príkladmi. Skóre sa mení na pravdepodobnosť až po projektovej kalibrácii.

Tieňový penalizátor používa fotometrickú zmenu, chýbajúcu hĺbkovú/rovinnú podporu, nekonzistentný posun pri zmene pohľadu a sémantický tieňový kanál. Nemá absolútne veto: hrana môže byť súčasne zatienená.

## Tracking

- body na a pri línii sa sledujú pyramídovým LK;
- póza predikuje projekciu existujúcej 3D línie;
- robustný fit porovná predikciu s live kandidátmi;
- association používa gating podľa uhla, vzdialenosti, deskriptora a topológie;
- Kalman/factor-graph stav nesie geometriu a kovarianciu;
- strata podpory mení stav na `LOST`, nie na novú falošnú polohu.

## Keyframe politika

Keyframe vznikne pri dostatočnej translácii/paralaxe, zmene orientácie, novom pokrytí alebo slabej neistote dôležitého objektu. Rozmazané, preexponované alebo duplicitné snímky sa nepoužijú na geometriu, môžu však zostať v diagnostike.

## 3D inicializácia

Pozorovania sa pretínajú ako 3D lúče alebo interpretované roviny obrazu. Inicializácia vyžaduje minimálnu paralaxu a kladnú hĺbku. RANSAC odstráni zlé asociácie. Stav línie sa povýši na 3D až po kontrole reprojekčnej chyby vo viacerých keyframes.

## Rozhrania

Pipeline publikuje nemenné udalosti: `FrameQuality`, `LineCandidateBatch`, `LineObservation`, `PoseObservation`, `DepthObservation`, `TrackingState` a `KeyframeStored`. Doménová vrstva nikdy nedostáva OpenCV/ARCore typy.

## Výkon a deterministickosť

Každá vetva má deadline a môže byť preskočená. Spracovanie má deterministické seed hodnoty viazané na frame ID. Diagnostika zaznamenáva verziu modelu, nastavenia a čas každej etapy.

## Minimálne testy

- syntetické projekcie známych 3D línií;
- tieň pohybujúci sa po rovine nesmie vytvoriť stabilnú 3D hranu;
- skutočná hrana pri expozícii musí zostať asociovaná;
- strata a relokalizácia zachová stabilné ID;
- benchmark fronty pri 20/30 FPS a tepelnom obmedzení.
