# Parametric Roof Model

## Úloha

Parametrický model je zdroj technickej pravdy pre rozmery, plochy, BIM a čisté exporty. Surový mesh je referenčná vizuálna vrstva a nikdy tajne nemení parametrické hodnoty.

## Hierarchia

`Building → Roof → RoofPlane[] → Boundary/Opening[]` a samostatné `RoofObject[]`. Hrany sú zdieľané cez stabilné graph ID, nie duplikované koordináty.

## Strešná rovina

Obsahuje ID, lokálnu ortonormálnu bázu, plane equation, outer loop, hole loops, typ, material, slope, aspect, area, adjacency, uncertainty a provenance. Plocha sa počíta z 2D polygónu v báze roviny, nie zo surového triangulovaného meshu.

## Hrany

`EAVE`, `RIDGE`, `HIP`, `VALLEY`, `GABLE`, `PARAPET`, `BREAK`, `OPENING_EDGE`, `AUXILIARY`, `UNKNOWN`. Dĺžka má neistotu propagovanú z covariance koncov/parametrov.

## Objekty

- komín: host plane, opening loop, pôdorys/obrys, výška, prípadne cap;
- strešné okno/svetlík: opening, frame, sklon z host plane, rozmery;
- vikier: host opening + vlastné roviny;
- prestup/potrubie/stožiar: profil, os, výška;
- PV panel: orientovaný obdĺžnik/pole nad host plane.

## Odvodené veličiny

Každá hodnota je `Quantity(valueSI, displayUnit, uncertainty, qualityClass, sources, calibrationState)`. Výkaz obsahuje skutočnú plochu, horizontálnu projekciu, všetky typy hrán, otvory a obvody objektov.

## Invarianty

- stabilné UUID pre nezmenenú sémantickú entitu;
- metre ako interná jednotka;
- pravotočivý súradnicový systém;
- konzistentné orientácie slučiek a normál von z objektu;
- hostované otvory ležia v rovine a v hranici hosta;
- žiadna odvodená hodnota bez provenance.

## Aktualizácia

Graph-to-model builder je deterministická čistá transformácia. Pri novej revízii zachová ID podľa graph referencií, prepočíta len zasiahnuté entity a vytvorí diff. Ručné materiály/názvy sa prenesú, pokiaľ ich host entita stále existuje.

## Mesh derivácia

Technický mesh vzniká constrained triangulation každého polygonu s otvormi. Zváranie vrcholov používa topologické ID. Prezentačný mesh môže mať textúry a vyššie detaily, ale exportný manifest označí pôvod.

## Presnosť

Neistota plochy a sklonu sa určuje Jacobian propagáciou alebo Monte Carlo vzorkovaním pri nelineárnych/komplexných slučkách. Trieda celej roviny nesmie byť lepšia než jej kritická neoverená hranica.
