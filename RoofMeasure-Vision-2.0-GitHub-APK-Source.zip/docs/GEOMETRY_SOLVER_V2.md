# Geometry Solver V2

## Architektúra

Solver je platformovo nezávislá knižnica s deterministickým jadrom. Mobilná verzia rieši prírastkové lokálne okno; finálny režim rieši celý constraint graph. Doména mu odovzdáva immutable snapshot a dostáva novú revíziu, rezíduá, covariance aproximáciu a diagnostiku.

## Premenné

- pózy keyframes `SE(3)`;
- 3D body a junctiony;
- 3D line Plücker/minimal parametre a orezané konce;
- roviny (normála + offset v minimálnej parametrizácii);
- globálna `Sim(3)` mierka/alignment;
- lokálne parametrické rozmery objektov;
- voliteľné extrinsics kamery a lasera.

## Reziduálne bloky

- reprojekcia bodu a vzdialenosť obrazového bodu od premietnutej línie;
- point-on-line, endpoint/junction coincidence;
- point/line-on-plane a plane normal fit;
- laserová vzdialenosť;
- parallel, perpendicular, coplanar, polygon closure;
- sémantické mäkké väzby hrebeňa/odkvapu/otvoru;
- priory mierky, pózy a kalibrácie.

Celková energia je vážený súčet blokov. Každý blok whiteningom používa vlastnú covariance a robustnú stratu (Huber/Cauchy/Tukey podľa typu). Váhy sa nezdvojujú so sigma.

## Optimalizačný postup

1. Validovať graph, jednotky a gauge freedom.
2. Inicializovať scale/pose a potom geometriu.
3. Riešiť Levenberg–Marquardt/Gauss–Newton s blokovou sparse štruktúrou.
4. Po každej iterácii kontrolovať konečnosť, pokles cost a topology barriers.
5. Znovu odhadnúť robustné váhy a identifikovať outliers.
6. Vypočítať marginal covariance alebo konzervatívnu aproximáciu.
7. Commit iba pri validných invariantoch; inak vrátiť diagnostiku bez mutácie.

## Gauge a pozorovateľnosť

Monokulárny model má voľnú mierku a globálnu transformáciu. Solver explicitne fixuje projektový frame a reportuje rank deficiency. Prvé absolútne meranie odomkne scale, nie absolútnu polohu. Planner používa rovnaký linearizovaný systém.

## Lokálna deformácia

Po scale alignment sa môžu meniť junctiony, roviny a parametrické rozmery, pričom topology constraints zachovajú incidenciu a slučky. Deformácia nie je voľný warp meshu. Každá zmena má regularizačný prior odvodený z vizuálnej covariance.

## Topologické bariéry

Solver nesmie prehodiť orientáciu plochy, vytvoriť self-intersection ani záporný rozmer. Taký krok sa odmietne alebo zmenší. Zmena topológie patrí samostatnému návrhovému procesu.

## Výstup

`SolverResult` obsahuje status, iterations, initial/final cost, condition estimate, optimized variables, residual per constraint, normalized residual, robust weight, covariance summaries a zoznam konfliktov.

## Numerika

Všetko interne v metroch a radiánoch, `Double`, normalizované smerové vektory, kontrola NaN/Inf a škálovanie parametrov. Deterministické poradie premenných a constraints je súčasťou testov.

## Testy

- analytické vs finite-difference Jacobiany;
- similarity recovery zo syntetických dát;
- scale z jednej a viacerých vzdialeností;
- outlier s robustnou stratou;
- slabo podmienený graf a správna diagnostika;
- zachovanie slučky/roviny po lokálnej optimalizácii;
- golden výsledky na rôznych platformách s toleranciou.
