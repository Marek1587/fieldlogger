# Používateľský workflow

## Informačná architektúra

Hlavná navigácia obsahuje Projekty, Meranie, Model, Výkaz a Export. Počas aktívneho merania sa používateľ nepresúva cez formuláre; aplikácia vždy zobrazí jednu odporúčanú akciu.

## Primárny tok

1. **Nový projekt** — používateľ zadá názov a zvolí Strecha.
2. **Kontrola zariadenia** — kamera, úložisko, AR schopnosti a voliteľný laser.
3. **Úvodný pohľad** — aplikácia posúdi expozíciu, pohyb, textúru a pokrytie.
4. **Učenie ukázaním** — používateľ označí odkvap, hrebeň alebo obrys.
5. **Skenovanie** — overlay drží potvrdené línie a ponúka kandidátov.
6. **Topológia** — aplikácia navrhne spojenia, slučky, roviny a objekty.
7. **Kalibrácia** — plánovač vyberie jedno dostupné meranie s najvyšším prínosom.
8. **Kontrola** — používateľ vidí 3D model, mapu neistoty a konflikty.
9. **Výstupy** — zvolí technický, fotorealistický alebo kombinovaný balík.

## Jednoduchý režim

Kamerová obrazovka obsahuje živý obraz, jednu vetu, kvalitu modelu a päť akcií: označiť, potvrdiť, odmietnuť, zmerať, dokončiť. Dlhým stlačením línie sa otvorí iba jej názov, rozmer, kvalita a opravy.

### Stavy relácie

`Setup → Teach → Scan → ResolveTopology → Calibrate → Review → Complete`

Prechod vpred nastane až po splnení merateľných podmienok. Používateľ sa môže bezpečne vrátiť; zmena vytvorí novú revíziu a nemaže audit.

### Jazyk pokynov

- jedna činnosť na vetu;
- pomenovať viditeľný cieľ („zadná hrana komína“), nie algoritmus;
- uviesť dôvod, ak sa žiada meranie;
- uviesť výsledok a zmenu neistoty po meraní;
- pri nedostatku dát povedať, čo chýba, nie iba „nízka kvalita“.

Príklad: „Prejdite približne dva metre doprava. Zadnú hranu okna zatiaľ vidíme iba spredu.“

## Expertný režim

Pridáva vrstvy trajektórie, keyframes, sparse/dense cloud, graf, roviny, kovariancie, rezíduá a váhy. Úpravy sú transakčné: návrh → náhľad dopadu → potvrdenie → audit.

## Kreslenie a výber

- ťah: voľná polyline, po pustení prichytená na najpravdepodobnejšiu hranu;
- dva kliky: presný segment s lupou pri koncových bodoch;
- uzavretý ťah: obrys objektu;
- klik na kandidáta: výber, druhý klik potvrdenie;
- „Toto nie je hrana/tieň/spoj“: negatívny lokálny príklad.

Prichytenie nikdy nemení používateľský ťah bez zobrazenia pôvodnej polohy a možnosti vrátiť zmenu.

## Laserový tok

1. Zvýrazniť cieľové konce A a B.
2. Zobraziť dostupnosť a bezpečný slovný pokyn.
3. Prijať BLE hodnotu alebo ručný vstup s jednotkou.
4. Nechať používateľa potvrdiť mapovanie na A–B.
5. Optimalizovať v novej revízii.
6. Ukázať výsledok, rezíduum a zmenu kvality.

Konfliktné meranie sa neaplikuje potichu. Používateľ môže zopakovať meranie, znížiť jeho dôveru alebo ho vyradiť; pôvod ostáva v audite.

## Obnova a chybové stavy

- strata trackingu: overlay zamrzne a zosivie; neaktualizuje sa falošnou projekciou;
- tepelný limit: zníži sa rozlíšenie a frekvencia dense krokov;
- prerušenie BLE: rozmer ostane v stave čaká, relácia kamery pokračuje;
- pád: obnoví sa posledný potvrdený event a rozpracovaný ťah sa zahodí;
- málo textúry: konkrétny návrh na uhol, širší pohyb, marker alebo laser.

## Ukončenie

Dokončenie je povolené aj s neistotou, ale obrazovka uvedie neuzavreté časti a zakáže tvrdenie o presnosti. Export nesie rovnaké varovania a manifest kvality.
