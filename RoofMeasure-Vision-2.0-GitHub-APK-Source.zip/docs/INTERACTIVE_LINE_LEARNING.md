# Interactive Line Learning

## Úloha

Lokálny adaptér zoraďuje kandidátne línie podľa konkrétnej strechy bez tréningu veľkého modelu. Jeho výsledok je projektovo izolovaný, verzovaný a zahoditeľný; potvrdená geometria sa naň nespolieha ako na jediný dôkaz.

## Tréningový príklad

Príklad obsahuje normalizovaný patch, polyline, typ, pozitívny/negatívny štítok, deskriptory oboch susedných plôch, smer, hrúbku, čas, frame a kvalitu pózy. Surový patch zostáva auditovateľný; do online adaptéra vstupujú odvodené znaky.

## Znaky

- LAB/HSV histogram a rozdiel strán línie;
- gradientový profil kolmo na líniu;
- lokálny binary/learned descriptor;
- orientácia a normalizovaná dĺžka;
- kontinuita a junction kontext;
- sémantické pravdepodobnosti plôch;
- depth/normal diskontinuita;
- časová a viacpohľadová podpora.

## Online model

MVP používa štandardizované znaky, prototypy tried a regularizovanú online logistickú regresiu. Aktualizácia je malá, deterministická a vykoná sa iba po explicitnom potvrdení. Plná verzia môže použiť malý embedding head s few-shot prototypmi.

Skóre kandidáta je zmes:

`S = α·S_visual + β·S_project + γ·S_3D + δ·S_temporal + ε·S_semantic`

Váhy sú kalibrované a ohraničené tak, aby projektový model neprebil chýbajúcu 3D konzistenciu.

## Negatívna spätná väzba

- `NOT_EDGE`: zníži podobné vizuálne kandidáty;
- `SHADOW`: zvýši tieňový prototyp a vyžaduje silnejšiu 3D podporu;
- `MATERIAL_JOINT`: zachová kandidáta pre vizuálnu vrstvu, nie pre geometriu;
- `IGNORE_SIMILAR`: aplikuje dočasný projektový filter s náhľadom dosahu.

Ignorovanie má horný limit a nikdy neskryje už potvrdenú líniu alebo vysoký depth/normal skok bez upozornenia.

## Ochrana pred driftom

- oddelené prototypy podľa sémantického typu;
- časový decay iba pre ranking, nie pre uložené príklady;
- minimálna diverzita príkladov pred širokou generalizáciou;
- spätné vyhodnotenie na stabilnom projektovom validačnom buffri;
- rollback adaptéra pri poklese presnosti;
- limit jednej aktualizácie na jednu používateľskú udalosť.

## UX väzba

Používateľ vidí zmenu len ako lepšie zoradené sivé kandidáty a krátke oznámenie. Žiadna aktualizácia nesmie automaticky potvrdiť geometriu. Pri nízkej istote sa zobrazia najviac tri návrhy naraz.

## Perzistencia a súkromie

Model sa ukladá spolu s feature-schema verziou, checksumom a projektovým ID. Medzi projektmi sa neprenášajú obrazové príklady bez výslovného opt-in anonymizovaného datasetu.

## Metriky

- precision@3 potvrdených kandidátov;
- počet akcií po prvú správnu automatickú hranu;
- false-hide rate po `IGNORE_SIMILAR`;
- zmena ECE/Brier kalibrácie;
- čas online aktualizácie a spotreba pamäte.
