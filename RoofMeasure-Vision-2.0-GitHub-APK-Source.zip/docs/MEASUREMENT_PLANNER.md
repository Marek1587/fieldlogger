# Measurement Planner

## Cieľ

Plánovač odporučí najmenší počet bezpečne dostupných meraní, ktoré najviac znížia neistotu technicky významných veličín. Neoptimalizuje iba priemernú chybu bodov.

## Kandidát

Kandidát merania obsahuje typ (dĺžka hrany, vzdialenosť bodov, výška, uhlopriečka), cieľové entity, predpokladanú neistotu senzora, dostupnosť, bezpečnostný flag, čas vykonania a slovný pokyn.

## Utility

`U(m) = wI·ΔInformation + wC·ΔCondition + wQ·ΔQuantityRisk + wR·ConflictPower − wA·AccessCost − wD·Redundancy − wS·SafetyRisk`

- information: log-det alebo trace pokles kovariancie cieľových parametrov;
- condition: zlepšenie condition number/observability;
- quantity risk: dopad na plochy a dĺžky pre výkaz;
- conflict power: schopnosť rozlíšiť konkurenčné hypotézy;
- access: odhad dosahu, viditeľnosti a používateľské potvrdenie;
- redundancy: korelácia s existujúcimi meraniami;
- safety: neprípustný kandidát má veto.

## Proces

1. Získať aktuálny linearizovaný constraint graph a covariance aproximáciu.
2. Vygenerovať iba fyzicky a sémanticky zmysluplné kandidáty.
3. Odfiltrovať uzamknuté, nedostupné a bezpečnostne nevhodné ciele.
4. Simulovať Jacobian a covariance update bez zmeny modelu.
5. Zoradiť, diverzifikovať a vybrať najlepšie vysvetliteľný kandidát.
6. Zastaviť, ak očakávaný prínos klesne pod prah viazaný na cieľ presnosti.

## Prvá mierka

Pri monokulárnej rekonštrukcii má prioritu dlhá, dobre rekonštruovaná a dostupná hrana. Nevyberá sa krátky detail, aj keď má vysokú relatívnu neistotu. Druhé meranie má kontrolovať deformáciu/smer, nie iba zopakovať rovnakú škálu.

## Lokálne ciele

Po určení mierky planner váži výšky, sklony, otvory a hrany s veľkým dopadom na výkaz. Pre komín typicky navrhne šírku obrysu a výšku nad host plane; pre úžľabie konce alebo dĺžku podľa pozorovateľnosti.

## Vysvetlenie

Odporúčanie obsahuje cieľ, dôvod, odhad zlepšenia a alternatívu. Napríklad: „Premerajte odkvap E12. Určí celkovú mierku a zníži neistotu hlavných hrán približne z 86 na 19 mm.“ Čísla sa zobrazia iba z vypočítanej simulácie.

## Stop pravidlá

- všetky kritické veličiny spĺňajú cieľ;
- najlepší bezpečný kandidát má zanedbateľný prínos;
- graf je nepozorovateľný spôsobom, ktorý laserová dĺžka nevyrieši — vyžiada sa nový pohľad;
- konflikt vyžaduje zopakovanie existujúceho merania.

## Testy

Scale-free graf, slabo podmienený obdĺžnik, chybná uhlopriečka, komín bez výšky, nedostupná hrana a redundancia. Poradie kandidátov musí byť deterministické pri rovnakom stave.
