# Line Tracking and SLAM

## Súradnicové rámce

- `C_t`: kamera v čase t;
- `A`: lokálny AR session frame;
- `P`: stabilný projektový frame;
- `M`: parametrický modelový frame;
- `E`: voliteľný exportný/georeferenčný frame.

Transformácie majú explicitný smer a typ `SE3`/`Sim3`; body nikdy nie sú holé `Vector3` bez rámca na hraniciach modulov. Pri relokalizácii sa mení transformácia `A→P`, nie identita objektov.

## Stav sledovanej línie

Línia obsahuje stabilné UUID, sémantiku, 3D parametre, 2D pozorovania, covariance, lifecycle, zdroj, susedné roviny a auditnú revíziu. Lifecycle:

`CANDIDATE → TAUGHT/CONFIRMED → TRACKED_2D → INITIALIZED_3D → OPTIMIZED → CALIBRATED`, s bočnými stavmi `OCCLUDED`, `LOST`, `CONFLICT` a `REJECTED`.

## 2D model

Polyline sa vzorkuje adaptívne podľa zakrivenia. Pre priamu stavebnú hranu sa drží latentný nekonečný obrazový line model a orezaný interval. Koncové body môžu byť menej stabilné než samotná priamka, preto majú oddelenú neistotu.

## Predikcia a korekcia

1. Ak existuje 3D línia, premietne sa cez aktuálnu pózu a intrinsics.
2. Inak sa použije flow bodov a robustná afinná/homografická lokálna transformácia.
3. V gating pásme sa vyhľadajú gradientové segmenty.
4. M-estimator upraví line parameter a koncové body.
5. Zlyhanie testov iba zvýši neistotu; nevytvorí sa tichý jump.

## SLAM integrácia

ARCore poskytuje realtime pose/depth a relokalizáciu. Vlastná vision vrstva uchováva line observations a keyframe feature associations. Factor graph spája pózy, body, línie, roviny a merania; mobilný live solver používa lokálne okno, finálny solver celý projekt.

## Triangulácia línie

Každé obrazové pozorovanie priamky definuje rovinu prechádzajúcu centrom kamery. Dve alebo viac neparalelných interpretovaných rovín určujú 3D priamku. Orezané konce vznikajú z pozorovaných intervalov, susedných junctionov a rovín. Degenerácia sa deteguje z uhla rovín a condition number.

## Occlusion a opätovné nájdenie

Zakrytá línia ostáva predikovaná, ale kreslí sa tlmene a neprijíma obrazové korekcie. Relokalizácia používa keyframe place recognition, sémantiku, topologické okolie a reprojekčný test. Rovnaké vzory falcov sa nerozlišujú iba deskriptorom.

## Kvalita

Tracking confidence kombinuje pose quality, flow inlier ratio, reprojekčnú chybu, počet keyframes, paralaxu a topologickú konzistenciu. UI používa diskretizovaný stav; expert vidí metriky a covariance.

## Failure gates

- príliš rýchly/rozmazaný pohyb: nepridávať kľúčové pozorovanie;
- čistá rotácia: nesľubovať trianguláciu;
- slabá paralaxa: zachovať 2D hypotézu;
- relokalizačný skok: pozastaviť korekcie a potvrdiť konzistenciu grafu;
- AR nedostupné: povoliť 2D MVP a označiť 3D ako nedostupné.

## Testy

Syntetické kamery, opakované textúry, dočasné zakrytie, návrat po prerušení aplikácie, relokalizačný posun, rolling-shutter pohyb a porovnanie so známou geometriou.
