# Test Plan V2

## Stratégia

Testovacia pyramída kombinuje čisté unit testy, property-based geometriu, integračné fixtures, inštrumentované Android testy, hardware-in-loop, exportné validátory a terénnu validáciu. Každý nájdený terénny problém vytvorí anonymizovaný regresný fixture, ak je to právne možné.

## Unit testy

- vektory, matice, transformácie, intersect/fit/triangulation;
- grafové invarianty a edit commands;
- robustné straty, rezíduá, scale solver a covariance;
- quantity výpočty a propagácia neistoty;
- online learner scoring/update/rollback;
- planner ranking a stop pravidlá;
- serializácia a schema migrácie;
- GUID, JSON, GLB/DAE/IFC writer primitives.

## Property a fuzz

Náhodné rigid/similarity transformácie musia zachovať incidenciu a pomery. Polygon operácie sa testujú na orientáciu, degenerácie a NaN. Parsre ručného vstupu, BLE payloadu a projektového súboru dostanú fuzz limity času/pamäte.

## Vision/SLAM fixtures

- syntetická renderovaná strecha s ground-truth kamerami;
- reálna sekvencia s tieňmi, odleskom, slabou textúrou a occlusion;
- opakované falce a symetrické línie;
- relokalizácia po prerušení;
- kontrola stable ID, precision/recall, reprojection a latency.

## Android

- Compose semantics a navigačné toky;
- permissions denied/granted later;
- process death + Room restore;
- rotácia/background/thermal throttling;
- CameraX analyzer backpressure;
- ARCore unsupported/degraded;
- accessibility a screenshot golden testy.

## BLE

Fake peripheral scenáre, potom Bosch hardware: discovery, pair, connect, receive, duplicate, stale, disconnect, reconnect, nízka batéria a protokolová nekompatibilita. Každé meranie sa kontroluje proti kalibrovanému etalónu.

## Exporty

Každý golden model sa exportuje do všetkých formátov, parse-ne nezávislou knižnicou a porovná topológiu, bounding box, jednotky, plochy a ID. DAE sa importuje v SketchUp, IFC minimálne v dvoch nezávislých nástrojoch.

## Výkon

Makrobenchmark štart, live pipeline FPS/p95, solver čas, pamäť, batéria a termálne správanie na low/mid/high referenčnom zariadení. Dataset a verzia modelu sú fixované.

## Bezpečnosť/súkromie

Kontrola runtime permissions, šifrovania lokálneho projektu, export intentov, path traversal v balíkoch, citlivých logov, dependency/SBOM a obnovy po poškodenom súbore.

## Release gates

- všetky P0 testy zelené;
- žiadny otvorený blocker/critical;
- deterministické core golden testy;
- validačné exporty bez chýb;
- BLE hardware protokol podpísaný;
- field accuracy coverage spĺňa deklaráciu;
- crash-free a ANR ciele na pilotnej skupine.
