package sk.strechostav.roofmeasure.domain

import sk.strechostav.roofmeasure.math.Vector3

enum class NodeType { ENDPOINT, CORNER, INTERSECTION, BREAK_POINT, VIRTUAL }
enum class LoopKind { OUTER, OPENING }
enum class RoofObjectType { CHIMNEY, ROOF_WINDOW, DORMER, SKYLIGHT, PARAPET, PENETRATION, VENT_PIPE, ANTENNA_MAST, PV_PANEL }

data class StructuralNode(
    val id: EntityId,
    val position: Vector3,
    val covariance: Covariance3,
    val type: NodeType,
    val incidentEdgeIds: Set<EntityId>,
)

data class StructuralEdge(
    val id: EntityId,
    val startNodeId: EntityId,
    val endNodeId: EntityId,
    val semanticType: LineSemanticType,
    val lineId: EntityId,
    val confidence: Double,
) {
    init {
        require(startNodeId != endNodeId)
        require(confidence in 0.0..1.0)
    }
}

data class SurfaceLoop(
    val id: EntityId,
    val kind: LoopKind,
    val orientedEdgeIds: List<EntityId>,
    val hostPlaneId: EntityId? = null,
) {
    init { require(orientedEdgeIds.size >= 3) }
}

data class RoofPlane(
    val id: EntityId,
    val normal: Vector3,
    val offsetMetres: Double,
    val outerLoopId: EntityId,
    val openingLoopIds: Set<EntityId>,
    val adjacentPlaneIds: Set<EntityId>,
    val covariance: Covariance3,
    val semanticType: String = "ROOF_PLANE",
) {
    init {
        require(normal.isFinite() && normal.norm() > 0.0)
        require(offsetMetres.isFinite())
    }
}

data class Opening(
    val id: EntityId,
    val loopId: EntityId,
    val hostPlaneId: EntityId,
    val objectId: EntityId?,
)

data class ObjectInstance(
    val id: EntityId,
    val type: RoofObjectType,
    val hostPlaneId: EntityId?,
    val boundaryLoopId: EntityId?,
    val dimensions: Map<String, Quantity>,
    val confidence: Double,
) {
    init { require(confidence in 0.0..1.0) }
}

data class StructuralLineGraph(
    val revision: RevisionId,
    val nodes: Map<EntityId, StructuralNode>,
    val edges: Map<EntityId, StructuralEdge>,
    val loops: Map<EntityId, SurfaceLoop>,
    val openings: Map<EntityId, Opening>,
    val roofPlanes: Map<EntityId, RoofPlane>,
    val objects: Map<EntityId, ObjectInstance>,
) {
    companion object {
        val EMPTY = StructuralLineGraph(RevisionId(0), emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap(), emptyMap())
    }
}
