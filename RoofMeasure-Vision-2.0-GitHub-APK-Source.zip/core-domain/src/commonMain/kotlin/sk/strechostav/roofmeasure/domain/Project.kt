package sk.strechostav.roofmeasure.domain

import kotlinx.coroutines.flow.Flow

enum class ProjectType { ROOF, BUILDING }
enum class SessionStage { SETUP, TEACH, SCAN, RESOLVE_TOPOLOGY, CALIBRATE, REVIEW, COMPLETE }

data class ProjectMetadata(
    val id: EntityId,
    val name: String,
    val type: ProjectType,
    val createdAt: Timestamp,
    val updatedAt: Timestamp,
    val revision: RevisionId,
) {
    init { require(name.isNotBlank()) }
}

data class ProjectSnapshot(
    val metadata: ProjectMetadata,
    val sessionStage: SessionStage,
    val lines: Map<EntityId, TrackedStructuralLine>,
    val observations: Map<EntityId, LineObservation>,
    val graph: StructuralLineGraph,
    val measurements: Map<EntityId, MeasurementSample>,
    val constraints: Map<EntityId, DistanceConstraint>,
    val lastSolverRevision: RevisionId?,
)

sealed interface AuditEvent {
    val id: EntityId
    val projectId: EntityId
    val timestamp: Timestamp

    data class ProjectCreated(
        override val id: EntityId,
        override val projectId: EntityId,
        override val timestamp: Timestamp,
        val name: String,
    ) : AuditEvent

    data class LineAnnotated(
        override val id: EntityId,
        override val projectId: EntityId,
        override val timestamp: Timestamp,
        val lineId: EntityId,
        val semanticType: LineSemanticType,
        val positive: Boolean,
    ) : AuditEvent

    data class MeasurementAssigned(
        override val id: EntityId,
        override val projectId: EntityId,
        override val timestamp: Timestamp,
        val constraintId: EntityId,
        val sampleId: EntityId,
    ) : AuditEvent

    data class SolverCommitted(
        override val id: EntityId,
        override val projectId: EntityId,
        override val timestamp: Timestamp,
        val fromRevision: RevisionId,
        val toRevision: RevisionId,
        val finalCost: Double,
    ) : AuditEvent

    data class ManualTopologyEdit(
        override val id: EntityId,
        override val projectId: EntityId,
        override val timestamp: Timestamp,
        val operation: String,
        val affectedIds: Set<EntityId>,
    ) : AuditEvent
}

interface ProjectRepository {
    fun observeProjects(): Flow<List<ProjectMetadata>>
    fun observeProject(id: EntityId): Flow<ProjectSnapshot?>
    suspend fun create(metadata: ProjectMetadata): ProjectSnapshot
    suspend fun transact(projectId: EntityId, expectedRevision: RevisionId, events: List<AuditEvent>): ProjectSnapshot
}

interface AuditRepository {
    fun observe(projectId: EntityId): Flow<List<AuditEvent>>
    suspend fun append(event: AuditEvent)
}
