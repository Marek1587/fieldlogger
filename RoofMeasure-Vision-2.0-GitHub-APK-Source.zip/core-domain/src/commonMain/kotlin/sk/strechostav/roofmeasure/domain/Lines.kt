package sk.strechostav.roofmeasure.domain

import sk.strechostav.roofmeasure.math.Vector2
import sk.strechostav.roofmeasure.math.Vector3

enum class LineSemanticType {
    ROOF_OUTLINE,
    RIDGE,
    EAVE,
    HIP,
    VALLEY,
    CHIMNEY,
    ROOF_WINDOW,
    GABLE_EDGE,
    PARAPET,
    PENETRATION,
    BREAK_LINE,
    AUXILIARY,
    UNKNOWN,
}

enum class LineSource { USER_DRAWN, USER_CONFIRMED, AUTOMATIC, IMPORTED, DERIVED }

enum class LineLifecycle {
    CANDIDATE,
    TAUGHT,
    CONFIRMED,
    TRACKED_2D,
    INITIALIZED_3D,
    OPTIMIZED,
    CALIBRATED,
    OCCLUDED,
    LOST,
    CONFLICT,
    REJECTED,
}

enum class RejectionReason { NOT_EDGE, SHADOW, MATERIAL_JOINT, TEXTURE, TEMPORARY_OBJECT, IGNORE_SIMILAR }

data class LineObservation(
    val id: EntityId,
    val frameId: EntityId,
    val timestamp: Timestamp,
    val projection: List<Vector2>,
    val confidence: Double,
    val poseQuality: Double,
) {
    init {
        require(projection.size >= 2)
        require(projection.all(Vector2::isFinite))
        require(confidence in 0.0..1.0 && poseQuality in 0.0..1.0)
    }
}

data class TrackedStructuralLine(
    val id: EntityId,
    val semanticType: LineSemanticType,
    val endpoints3D: Pair<Vector3, Vector3>? = null,
    val polyline3D: List<Vector3> = emptyList(),
    val currentProjection2D: List<Vector2> = emptyList(),
    val confidence: Double,
    val covariance: Covariance3?,
    val lifecycle: LineLifecycle,
    val observationIds: List<EntityId>,
    val source: LineSource,
    val calibrationState: CalibrationState,
    val connectedLineIds: Set<EntityId> = emptySet(),
    val adjacentPlaneIds: Set<EntityId> = emptySet(),
    val rejectionReason: RejectionReason? = null,
) {
    init {
        require(confidence in 0.0..1.0)
        require(endpoints3D == null || endpoints3D.first != endpoints3D.second)
        require(lifecycle == LineLifecycle.REJECTED || rejectionReason == null)
    }

    val observationCount: Int get() = observationIds.size
    val hasMetricGeometry: Boolean get() = endpoints3D != null
}

data class UserLineExample(
    val id: EntityId,
    val frameId: EntityId,
    val patchReference: String,
    val polyline: List<Vector2>,
    val semanticType: LineSemanticType,
    val positiveExample: Boolean,
    val adjacentSurfaceDescriptors: List<SurfaceDescriptor>,
    val timestamp: Timestamp,
) {
    init { require(polyline.size >= 2) }
}

data class SurfaceDescriptor(
    val meanLab: List<Double>,
    val gradientMean: Double,
    val semanticProbabilities: Map<String, Double>,
) {
    init {
        require(meanLab.size == 3)
        require(semanticProbabilities.values.all { it in 0.0..1.0 })
    }
}
