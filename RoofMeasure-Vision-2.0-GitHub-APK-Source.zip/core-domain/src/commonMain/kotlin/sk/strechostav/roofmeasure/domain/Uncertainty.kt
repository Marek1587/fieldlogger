package sk.strechostav.roofmeasure.domain

import sk.strechostav.roofmeasure.math.Matrix3
import kotlin.math.sqrt

enum class QualityClass { A, B, C, D, E }

enum class CalibrationState {
    UNMEASURED,
    VISUALLY_ESTIMATED,
    RECOMMENDED,
    WAITING_FOR_LASER,
    LASER_MEASURED,
    REDUNDANTLY_VERIFIED,
    CONFLICTING,
    LOCKED,
}

data class StandardUncertainty(
    val sigma: Double,
    val systematicFlags: Set<String> = emptySet(),
) {
    init { require(sigma >= 0.0 && sigma.isFinite()) { "Sigma must be finite and non-negative" } }
    fun interval95(): ClosedFloatingPointRange<Double> = -1.96 * sigma..1.96 * sigma
}

data class Covariance3(val matrix: Matrix3) {
    init {
        require(matrix.isFinite())
        require(matrix.m00 >= 0.0 && matrix.m11 >= 0.0 && matrix.m22 >= 0.0)
    }

    val radialSigma: Double get() = sqrt(matrix.m00 + matrix.m11 + matrix.m22)

    companion object {
        fun isotropic(sigma: Double): Covariance3 {
            require(sigma >= 0.0)
            return Covariance3(Matrix3.diagonal(sigma * sigma, sigma * sigma, sigma * sigma))
        }
    }
}

data class Quantity(
    val valueSi: Double,
    val unit: QuantityUnit,
    val uncertainty: StandardUncertainty,
    val qualityClass: QualityClass,
    val sourceIds: Set<EntityId>,
    val calibrationState: CalibrationState,
) {
    init { require(valueSi.isFinite()) }
}

enum class QuantityUnit { METRE, SQUARE_METRE, RADIAN, DIMENSIONLESS }
