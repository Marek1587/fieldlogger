package sk.strechostav.roofmeasure.domain

data class EntityId(val value: String) : Comparable<EntityId> {
    init { require(value.isNotBlank()) { "Entity ID must not be blank" } }
    override fun compareTo(other: EntityId): Int = value.compareTo(other.value)
    override fun toString(): String = value
}

data class RevisionId(val value: Long) : Comparable<RevisionId> {
    init { require(value >= 0) }
    override fun compareTo(other: RevisionId): Int = value.compareTo(other.value)
}

enum class CoordinateFrame { CAMERA, AR_SESSION, PROJECT, MODEL, EXPORT }

data class Timestamp(val epochMillis: Long) : Comparable<Timestamp> {
    override fun compareTo(other: Timestamp): Int = epochMillis.compareTo(other.epochMillis)
}
