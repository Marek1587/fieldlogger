package sk.strechostav.roofmeasure.domain

enum class MeasurementSource { BOSCH_GLM_120_C, MANUAL, IMPORTED, VISUAL_ESTIMATE }
enum class MeasurementStatus { UNASSIGNED, WAITING, RECEIVED, CONFIRMED, REJECTED, CONFLICTING, LOCKED }
enum class MeasurementPrecision { PRECISE, ORIENTATIVE }

data class MeasurementIntent(
    val id: EntityId,
    val projectId: EntityId,
    val startNodeId: EntityId,
    val endNodeId: EntityId,
    val targetLineId: EntityId?,
    val createdAt: Timestamp,
    val expiresAt: Timestamp,
) {
    init {
        require(startNodeId != endNodeId)
        require(expiresAt > createdAt)
    }
}

data class MeasurementSample(
    val id: EntityId,
    val valueMetres: Double,
    val uncertainty: StandardUncertainty,
    val source: MeasurementSource,
    val deviceId: String?,
    val rawPayloadHash: String?,
    val capturedAt: Timestamp,
    val precision: MeasurementPrecision,
) {
    init { require(valueMetres > 0.0 && valueMetres.isFinite()) }
}

data class DistanceConstraint(
    val id: EntityId,
    val intentId: EntityId,
    val sampleId: EntityId,
    val startNodeId: EntityId,
    val endNodeId: EntityId,
    val measuredMetres: Double,
    val sigmaMetres: Double,
    val status: MeasurementStatus,
) {
    init {
        require(startNodeId != endNodeId)
        require(measuredMetres > 0.0)
        require(sigmaMetres > 0.0)
    }
}
