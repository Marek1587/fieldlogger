package sk.strechostav.roofmeasure.modeling

import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.geometry.PolygonGeometry
import sk.strechostav.roofmeasure.math.Vector3
import kotlin.test.Test
import kotlin.test.assertEquals

class ModelTest {
    @Test
    fun slopedRectangleHasExpectedTrueAndProjectedArea() {
        val points = listOf(
            Vector3(0.0, 0.0, 0.0),
            Vector3(4.0, 0.0, 0.0),
            Vector3(4.0, 3.0, 3.0),
            Vector3(0.0, 3.0, 3.0),
        )
        assertEquals(12.0, PolygonGeometry.horizontalProjectedArea(points), 1e-12)
        assertEquals(4.0 * kotlin.math.sqrt(18.0), PolygonGeometry.area3(points), 1e-12)
        assertEquals("x", EntityId("x").value)
    }
}
