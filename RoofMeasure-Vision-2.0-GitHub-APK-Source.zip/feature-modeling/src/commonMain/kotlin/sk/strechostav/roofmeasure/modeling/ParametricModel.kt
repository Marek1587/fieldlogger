package sk.strechostav.roofmeasure.modeling

import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.ObjectInstance
import sk.strechostav.roofmeasure.domain.QualityClass
import sk.strechostav.roofmeasure.domain.Quantity
import sk.strechostav.roofmeasure.domain.QuantityUnit
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StandardUncertainty
import sk.strechostav.roofmeasure.domain.StructuralLineGraph
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.geometry.Plane3
import sk.strechostav.roofmeasure.geometry.PolygonGeometry
import sk.strechostav.roofmeasure.math.Vector3
import kotlin.math.sqrt

data class ParametricRoofModel(
    val id: EntityId,
    val projectId: EntityId,
    val revision: RevisionId,
    val coordinateFrame: String,
    val planes: List<ParametricRoofPlane>,
    val edges: List<ParametricRoofEdge>,
    val objects: List<ParametricRoofObject>,
    val quantities: QuantityTakeoff,
)

data class ParametricRoofPlane(
    val id: EntityId,
    val name: String,
    val normal: Vector3,
    val offsetMetres: Double,
    val boundary: List<Vector3>,
    val openings: List<List<Vector3>>,
    val area: Quantity,
    val horizontalArea: Quantity,
    val slope: Quantity,
    val adjacentPlaneIds: Set<EntityId>,
)

data class ParametricRoofEdge(
    val id: EntityId,
    val lineId: EntityId,
    val semanticType: LineSemanticType,
    val start: Vector3,
    val end: Vector3,
    val length: Quantity,
)

data class ParametricRoofObject(
    val id: EntityId,
    val type: String,
    val hostPlaneId: EntityId?,
    val dimensions: Map<String, Quantity>,
)

data class QuantityTakeoff(
    val totalRoofArea: Quantity,
    val totalHorizontalArea: Quantity,
    val edgeLengths: Map<LineSemanticType, Quantity>,
    val openingArea: Quantity,
    val objectCounts: Map<String, Int>,
)

class ParametricRoofModelBuilder {
    fun build(projectId: EntityId, graph: StructuralLineGraph, lines: Map<EntityId, TrackedStructuralLine>): ParametricRoofModel {
        val edges = graph.edges.values.sortedBy { it.id.value }.mapNotNull { edge ->
            val start = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
            val end = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
            val source = lines[edge.lineId]
            val sigma = sqrt(start.covariance.radialSigma * start.covariance.radialSigma + end.covariance.radialSigma * end.covariance.radialSigma)
            ParametricRoofEdge(
                edge.id,
                edge.lineId,
                edge.semanticType,
                start.position,
                end.position,
                Quantity(
                    start.position.distanceTo(end.position),
                    QuantityUnit.METRE,
                    StandardUncertainty(sigma),
                    quality(source),
                    setOf(edge.lineId),
                    source?.calibrationState ?: CalibrationState.VISUALLY_ESTIMATED,
                ),
            )
        }

        val planes = graph.roofPlanes.values.sortedBy { it.id.value }.mapNotNull { roofPlane ->
            val outer = graph.loops[roofPlane.outerLoopId] ?: return@mapNotNull null
            val boundary = orderedVertices(outer.orientedEdgeIds, graph)
            if (boundary.size < 3) return@mapNotNull null
            val openings = roofPlane.openingLoopIds.mapNotNull { id -> graph.loops[id]?.let { orderedVertices(it.orientedEdgeIds, graph) } }
            createPlane(roofPlane.id, roofPlane.adjacentPlaneIds, boundary, openings, edges)
        }.ifEmpty {
            graph.loops.values.filter { it.kind.name == "OUTER" }.sortedBy { it.id.value }.mapNotNull { loop ->
                val boundary = orderedVertices(loop.orientedEdgeIds, graph)
                if (boundary.size < 3 || !PolygonGeometry.isPlanar(boundary, 0.05)) null
                else createPlane(EntityId("plane:${loop.id.value}"), emptySet(), boundary, emptyList(), edges)
            }
        }

        val objects = graph.objects.values.sortedBy(ObjectInstance::id).map {
            ParametricRoofObject(it.id, it.type.name, it.hostPlaneId, it.dimensions)
        }
        val takeoff = buildTakeoff(planes, edges, objects)
        return ParametricRoofModel(
            id = EntityId("model:${projectId.value}:${graph.revision.value}"),
            projectId = projectId,
            revision = graph.revision,
            coordinateFrame = "PROJECT_Z_UP_METRES",
            planes = planes,
            edges = edges,
            objects = objects,
            quantities = takeoff,
        )
    }

    private fun createPlane(
        id: EntityId,
        adjacent: Set<EntityId>,
        boundary: List<Vector3>,
        openings: List<List<Vector3>>,
        edges: List<ParametricRoofEdge>,
    ): ParametricRoofPlane {
        val normal = PolygonGeometry.newellNormal(boundary).let { if (it.z < 0.0) -it else it }
        val plane = Plane3.fromNormalAndPoint(normal, boundary.first())
        val rawArea = PolygonGeometry.area3(boundary)
        val rawHorizontal = PolygonGeometry.horizontalProjectedArea(boundary)
        val openingArea = openings.sumOf(PolygonGeometry::area3)
        val openingHorizontal = openings.sumOf(PolygonGeometry::horizontalProjectedArea)
        val perimeter = boundary.indices.sumOf { boundary[it].distanceTo(boundary[(it + 1) % boundary.size]) }
        val meanVertexSigma = edges.map { it.length.uncertainty.sigma }.average().takeIf(Double::isFinite) ?: 0.05
        val areaSigma = (perimeter * meanVertexSigma).coerceAtLeast(0.001)
        val sources = edges.map(ParametricRoofEdge::lineId).toSet()
        val classForPlane = edges.map { it.length.qualityClass }.maxByOrNull(QualityClass::ordinal) ?: QualityClass.E
        val calibration = edges.map { it.length.calibrationState }.let { states ->
            when {
                states.any { it == CalibrationState.CONFLICTING } -> CalibrationState.CONFLICTING
                states.any { it == CalibrationState.LASER_MEASURED || it == CalibrationState.REDUNDANTLY_VERIFIED } -> CalibrationState.LASER_MEASURED
                else -> CalibrationState.VISUALLY_ESTIMATED
            }
        }
        return ParametricRoofPlane(
            id = id,
            name = "RoofPlane_${id.value}",
            normal = normal,
            offsetMetres = plane.offset,
            boundary = boundary,
            openings = openings,
            area = Quantity((rawArea - openingArea).coerceAtLeast(0.0), QuantityUnit.SQUARE_METRE, StandardUncertainty(areaSigma), classForPlane, sources, calibration),
            horizontalArea = Quantity((rawHorizontal - openingHorizontal).coerceAtLeast(0.0), QuantityUnit.SQUARE_METRE, StandardUncertainty(areaSigma), classForPlane, sources, calibration),
            slope = Quantity(PolygonGeometry.slopeRadians(normal), QuantityUnit.RADIAN, StandardUncertainty(meanVertexSigma / perimeter.coerceAtLeast(0.1)), classForPlane, sources, calibration),
            adjacentPlaneIds = adjacent,
        )
    }

    private fun orderedVertices(edgeIds: List<EntityId>, graph: StructuralLineGraph): List<Vector3> {
        if (edgeIds.isEmpty()) return emptyList()
        val remaining = edgeIds.mapNotNull(graph.edges::get).toMutableList()
        if (remaining.isEmpty()) return emptyList()
        val first = remaining.removeAt(0)
        val nodeIds = mutableListOf(first.startNodeId, first.endNodeId)
        while (remaining.isNotEmpty()) {
            val tail = nodeIds.last()
            val index = remaining.indexOfFirst { it.startNodeId == tail || it.endNodeId == tail }
            if (index < 0) break
            val edge = remaining.removeAt(index)
            nodeIds += if (edge.startNodeId == tail) edge.endNodeId else edge.startNodeId
        }
        if (nodeIds.lastOrNull() == nodeIds.firstOrNull()) nodeIds.removeAt(nodeIds.lastIndex)
        return nodeIds.mapNotNull { graph.nodes[it]?.position }
    }

    private fun buildTakeoff(
        planes: List<ParametricRoofPlane>,
        edges: List<ParametricRoofEdge>,
        objects: List<ParametricRoofObject>,
    ): QuantityTakeoff {
        fun sumQuantities(values: List<Quantity>, unit: QuantityUnit): Quantity {
            val sigma = sqrt(values.sumOf { it.uncertainty.sigma * it.uncertainty.sigma })
            val worst = values.maxByOrNull { it.qualityClass.ordinal }?.qualityClass ?: QualityClass.E
            val state = if (values.any { it.calibrationState == CalibrationState.LASER_MEASURED || it.calibrationState == CalibrationState.REDUNDANTLY_VERIFIED }) CalibrationState.LASER_MEASURED else CalibrationState.VISUALLY_ESTIMATED
            return Quantity(values.sumOf(Quantity::valueSi), unit, StandardUncertainty(sigma), worst, values.flatMap(Quantity::sourceIds).toSet(), state)
        }
        val bySemantic = edges.groupBy(ParametricRoofEdge::semanticType).mapValues { (_, values) -> sumQuantities(values.map(ParametricRoofEdge::length), QuantityUnit.METRE) }
        val openingAreas = planes.flatMap { plane -> plane.openings.map { opening ->
            Quantity(PolygonGeometry.area3(opening), QuantityUnit.SQUARE_METRE, StandardUncertainty(plane.area.uncertainty.sigma), plane.area.qualityClass, plane.area.sourceIds, plane.area.calibrationState)
        } }
        return QuantityTakeoff(
            totalRoofArea = sumQuantities(planes.map(ParametricRoofPlane::area), QuantityUnit.SQUARE_METRE),
            totalHorizontalArea = sumQuantities(planes.map(ParametricRoofPlane::horizontalArea), QuantityUnit.SQUARE_METRE),
            edgeLengths = bySemantic,
            openingArea = sumQuantities(openingAreas, QuantityUnit.SQUARE_METRE),
            objectCounts = objects.groupingBy(ParametricRoofObject::type).eachCount(),
        )
    }

    private fun quality(line: TrackedStructuralLine?): QualityClass = when {
        line == null || line.lifecycle.name in setOf("CONFLICT", "LOST", "REJECTED") -> QualityClass.E
        line.calibrationState == CalibrationState.REDUNDANTLY_VERIFIED -> QualityClass.A
        line.calibrationState in setOf(CalibrationState.LASER_MEASURED, CalibrationState.LOCKED) -> QualityClass.B
        line.observationCount >= 3 && line.endpoints3D != null -> QualityClass.C
        else -> QualityClass.D
    }
}
