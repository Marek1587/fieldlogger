import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.multiplatform)
    alias(libs.plugins.android.library)
}

kotlin {
    androidTarget { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }
    jvm("desktop")
    iosArm64()
    iosSimulatorArm64()
    sourceSets {
        commonMain.dependencies {
            api(project(":core-domain"))
            api(project(":core-geometry"))
        }
        commonTest.dependencies { implementation(kotlin("test")) }
    }
}

android {
    namespace = "sk.strechostav.roofmeasure.feature.modeling"
    compileSdk = 36
    defaultConfig { minSdk = 24 }
}
