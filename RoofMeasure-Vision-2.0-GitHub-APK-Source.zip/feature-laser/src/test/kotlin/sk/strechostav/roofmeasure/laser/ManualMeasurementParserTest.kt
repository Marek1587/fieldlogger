package sk.strechostav.roofmeasure.laser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ManualMeasurementParserTest {
    @Test
    fun parsesSlovakDecimalSeparatorAndUnit() {
        val result = ManualMeasurementParser.parse("8426,0", ManualUnit.MILLIMETRE)
        assertTrue(result is ManualMeasurementParseResult.Valid)
        assertEquals(8.426, (result as ManualMeasurementParseResult.Valid).metres, 1e-12)
    }

    @Test
    fun rejectsImplausibleRange() {
        assertTrue(ManualMeasurementParser.parse("2", ManualUnit.MILLIMETRE) is ManualMeasurementParseResult.Invalid)
    }
}
