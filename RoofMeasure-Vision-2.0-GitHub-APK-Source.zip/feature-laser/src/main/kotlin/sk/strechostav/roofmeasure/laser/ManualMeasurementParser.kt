package sk.strechostav.roofmeasure.laser

enum class ManualUnit(val metresPerUnit: Double) { MILLIMETRE(0.001), CENTIMETRE(0.01), METRE(1.0) }

sealed interface ManualMeasurementParseResult {
    data class Valid(val metres: Double) : ManualMeasurementParseResult
    data class Invalid(val message: String) : ManualMeasurementParseResult
}

object ManualMeasurementParser {
    fun parse(value: String, unit: ManualUnit): ManualMeasurementParseResult {
        val normalized = value.trim().replace(',', '.')
        val number = normalized.toDoubleOrNull() ?: return ManualMeasurementParseResult.Invalid("Zadajte číselnú hodnotu.")
        val metres = number * unit.metresPerUnit
        return if (metres in 0.01..300.0) ManualMeasurementParseResult.Valid(metres)
        else ManualMeasurementParseResult.Invalid("Rozmer musí byť medzi 10 mm a 300 m.")
    }
}
