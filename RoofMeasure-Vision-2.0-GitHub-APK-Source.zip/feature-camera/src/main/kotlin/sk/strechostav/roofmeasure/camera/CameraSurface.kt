package sk.strechostav.roofmeasure.camera

import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.Timestamp
import sk.strechostav.roofmeasure.vision.VisionFrame
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong

@Composable
fun CameraSurface(
    onFrame: (VisionFrame) -> Unit,
    modifier: Modifier = Modifier,
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    val counter = remember { AtomicLong(0) }
    var provider: ProcessCameraProvider? = remember { null }
    AndroidView(
        modifier = modifier,
        factory = { context ->
            PreviewView(context).also { previewView ->
                previewView.scaleType = PreviewView.ScaleType.FILL_CENTER
                val future = ProcessCameraProvider.getInstance(context)
                future.addListener({
                    provider = future.get()
                    val preview = Preview.Builder().build().also { it.surfaceProvider = previewView.surfaceProvider }
                    val analysis = ImageAnalysis.Builder()
                        .setTargetResolution(Size(960, 540))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    analysis.setAnalyzer(executor) { image ->
                        try { image.toVisionFrame(counter.incrementAndGet())?.let(onFrame) } finally { image.close() }
                    }
                    provider?.unbindAll()
                    provider?.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                }, ContextCompat.getMainExecutor(context))
            }
        },
    )
    DisposableEffect(lifecycleOwner) {
        onDispose { provider?.unbindAll(); executor.shutdown() }
    }
}

private fun ImageProxy.toVisionFrame(sequence: Long): VisionFrame? {
    val plane = planes.firstOrNull() ?: return null
    val buffer = plane.buffer.duplicate()
    buffer.rewind()
    val output = ByteArray(width * height)
    val row = ByteArray(plane.rowStride)
    for (y in 0 until height) {
        val readable = minOf(plane.rowStride, buffer.remaining())
        buffer.get(row, 0, readable)
        for (x in 0 until width) output[y * width + x] = row[x * plane.pixelStride]
    }
    return VisionFrame(EntityId("frame:$sequence:$imageInfo.timestamp"), width, height, output, Timestamp(imageInfo.timestamp / 1_000_000L))
}
