pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "RoofMeasureVision"

include(
    ":app",
    ":core-domain",
    ":core-math",
    ":core-geometry",
    ":core-vision",
    ":core-ar",
    ":core-ble",
    ":core-storage",
    ":feature-project",
    ":feature-camera",
    ":feature-line-teaching",
    ":feature-line-tracking",
    ":feature-laser",
    ":feature-solver",
    ":feature-modeling",
    ":feature-bim",
    ":feature-export",
    ":feature-report",
)
