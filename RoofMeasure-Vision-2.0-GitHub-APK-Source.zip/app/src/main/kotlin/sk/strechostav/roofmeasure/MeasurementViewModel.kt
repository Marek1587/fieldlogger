package sk.strechostav.roofmeasure

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.LineSource
import sk.strechostav.roofmeasure.domain.ProjectMetadata
import sk.strechostav.roofmeasure.domain.ProjectType
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.SessionStage
import sk.strechostav.roofmeasure.domain.Timestamp
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.export.AndroidExportService
import sk.strechostav.roofmeasure.geometry.StructuralGraphBuilder
import sk.strechostav.roofmeasure.math.Vector2
import sk.strechostav.roofmeasure.math.Vector3
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel
import sk.strechostav.roofmeasure.modeling.ParametricRoofModelBuilder
import sk.strechostav.roofmeasure.solver.MeasurementPlanner
import sk.strechostav.roofmeasure.solver.PlanningDecision
import sk.strechostav.roofmeasure.storage.ProjectLocalDataSource
import sk.strechostav.roofmeasure.storage.toDomain
import sk.strechostav.roofmeasure.tracking.LineTrackingCoordinator
import sk.strechostav.roofmeasure.vision.VisionFrame
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject

data class MeasurementUiState(
    val activeProjectId: EntityId? = null,
    val projectName: String = "",
    val lines: Map<EntityId, TrackedStructuralLine> = emptyMap(),
    val pendingPolyline: List<Vector2>? = null,
    val pendingSemantic: LineSemanticType = LineSemanticType.EAVE,
    val drawingEnabled: Boolean = true,
    val guidance: String = "Označte jednu obrysovú alebo odkvapovú hranu strechy.",
    val selectedMeasurementLineId: EntityId? = null,
    val model: ParametricRoofModel? = null,
    val showModelSummary: Boolean = false,
    val exportMessage: String? = null,
)

@HiltViewModel
class MeasurementViewModel @Inject constructor(
    private val storage: ProjectLocalDataSource,
    private val exportService: AndroidExportService,
) : ViewModel() {
    val projects = storage.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    private val mutableState = MutableStateFlow(MeasurementUiState())
    val state = mutableState.asStateFlow()
    private val tracking = LineTrackingCoordinator()
    private val processingFrame = AtomicBoolean(false)

    fun createProject(name: String) = viewModelScope.launch {
        val now = Timestamp(System.currentTimeMillis())
        val id = EntityId(UUID.randomUUID().toString())
        storage.create(ProjectMetadata(id, name, ProjectType.ROOF, now, now, RevisionId(0)))
        mutableState.value = MeasurementUiState(activeProjectId = id, projectName = name)
        storage.updateStage(id, SessionStage.TEACH, Timestamp(System.currentTimeMillis()))
    }

    fun openProject(id: String) = viewModelScope.launch {
        val stored = storage.observeProject(EntityId(id)).first() ?: return@launch
        mutableState.value = MeasurementUiState(
            activeProjectId = EntityId(id),
            projectName = stored.project.name,
            lines = stored.lines.associate { EntityId(it.id) to it.toDomain() },
            guidance = if (stored.lines.isEmpty()) "Označte prvú významnú hranu." else "Pokračujte pomalým pohybom kamery pozdĺž strechy.",
        )
    }

    fun closeProject() { mutableState.value = MeasurementUiState() }
    fun setDrawing(enabled: Boolean) = mutableState.update { it.copy(drawingEnabled = enabled) }
    fun setPendingSemantic(type: LineSemanticType) = mutableState.update { it.copy(pendingSemantic = type) }
    fun onLineDrawn(points: List<Vector2>) = mutableState.update { it.copy(pendingPolyline = simplify(points), drawingEnabled = false, guidance = "Aký typ línie ste označili?") }
    fun cancelPendingLine() = mutableState.update { it.copy(pendingPolyline = null, drawingEnabled = true, guidance = "Označte významnú konštrukčnú líniu.") }

    fun confirmPendingLine() {
        val snapshot = mutableState.value
        val projectId = snapshot.activeProjectId ?: return
        val polyline = snapshot.pendingPolyline ?: return
        val line = TrackedStructuralLine(
            id = EntityId(UUID.randomUUID().toString()),
            semanticType = snapshot.pendingSemantic,
            currentProjection2D = polyline,
            confidence = 0.85,
            covariance = null,
            lifecycle = LineLifecycle.CONFIRMED,
            observationIds = emptyList(),
            source = LineSource.USER_DRAWN,
            calibrationState = CalibrationState.VISUALLY_ESTIMATED,
        )
        mutableState.update {
            it.copy(
                lines = it.lines + (line.id to line),
                pendingPolyline = null,
                drawingEnabled = true,
                guidance = if (it.lines.isEmpty()) "Výborne. Označte hrebeň alebo ďalšiu obrysovú hranu." else "Pomaly pohybujte kamerou. Línie sa sledujú optickým tokom.",
            )
        }
        viewModelScope.launch { storage.saveLine(projectId, line, Timestamp(System.currentTimeMillis())) }
    }

    fun onFrame(frame: VisionFrame) {
        if (!processingFrame.compareAndSet(false, true)) return
        viewModelScope.launch {
            try {
                val current = mutableState.value.lines
                if (current.isNotEmpty()) {
                    val updated = tracking.update(frame, current)
                    mutableState.update { state -> state.copy(lines = updated) }
                }
            } finally { processingFrame.set(false) }
        }
    }

    fun requestMeasurement() {
        val candidate = mutableState.value.lines.values
            .firstOrNull { it.calibrationState !in setOf(CalibrationState.LASER_MEASURED, CalibrationState.REDUNDANTLY_VERIFIED, CalibrationState.LOCKED) }
        mutableState.update {
            it.copy(
                lines = if (candidate == null) it.lines else it.lines + (candidate.id to candidate.copy(calibrationState = CalibrationState.RECOMMENDED)),
                selectedMeasurementLineId = candidate?.id,
                guidance = if (candidate == null) "Najprv označte líniu." else "Premerajte zvýraznenú líniu a zadajte rozmer.",
            )
        }
    }

    fun cancelMeasurement() = mutableState.update { state ->
        val selected = state.selectedMeasurementLineId
        state.copy(
            lines = if (selected == null) state.lines else state.lines.mapValues { (id, line) ->
                if (id == selected && line.calibrationState == CalibrationState.RECOMMENDED) line.copy(calibrationState = CalibrationState.VISUALLY_ESTIMATED) else line
            },
            selectedMeasurementLineId = null,
        )
    }

    fun applyManualMeasurement(metres: Double) {
        val snapshot = mutableState.value
        val selectedId = snapshot.selectedMeasurementLineId ?: return
        val selected = snapshot.lines[selectedId] ?: return
        val selectedLength = selected.currentProjection2D.first().distanceTo(selected.currentProjection2D.last())
        if (selectedLength <= 1e-6) return
        val scale = metres / selectedLength
        val metricLines = snapshot.lines.mapValues { (id, line) ->
            val first = line.currentProjection2D.firstOrNull()
            val last = line.currentProjection2D.lastOrNull()
            if (first == null || last == null) line else line.copy(
                endpoints3D = Vector3(first.x * scale, (1.0 - first.y) * scale, 0.0) to Vector3(last.x * scale, (1.0 - last.y) * scale, 0.0),
                polyline3D = line.currentProjection2D.map { Vector3(it.x * scale, (1.0 - it.y) * scale, 0.0) },
                lifecycle = LineLifecycle.OPTIMIZED,
                calibrationState = if (id == selectedId) CalibrationState.LASER_MEASURED else CalibrationState.VISUALLY_ESTIMATED,
            )
        }
        val projectId = requireNotNull(snapshot.activeProjectId)
        val graph = StructuralGraphBuilder((metres * 0.02).coerceIn(0.03, 0.25)).build(metricLines.values, RevisionId(1))
        val model = ParametricRoofModelBuilder().build(projectId, graph, metricLines)
        val decision = MeasurementPlanner().plan(graph, metricLines, metricScaleKnown = true)
        val guidance = when (decision) {
            is PlanningDecision.Recommend -> "Mierka bola kalibrovaná. ${decision.candidate.instruction}"
            is PlanningDecision.NeedAnotherView -> "Mierka bola kalibrovaná. ${decision.reason}"
            is PlanningDecision.Sufficient -> decision.reason
        }
        mutableState.update { it.copy(lines = metricLines, selectedMeasurementLineId = null, model = model, guidance = guidance) }
        viewModelScope.launch {
            metricLines.values.forEach { storage.saveLine(projectId, it, Timestamp(System.currentTimeMillis())) }
            storage.updateStage(projectId, SessionStage.REVIEW, Timestamp(System.currentTimeMillis()))
        }
    }

    fun toggleModelSummary() = mutableState.update { it.copy(showModelSummary = !it.showModelSummary) }

    fun export() = viewModelScope.launch {
        val snapshot = mutableState.value
        val model = snapshot.model ?: run {
            mutableState.update { it.copy(exportMessage = "Najprv kalibrujte model rozmerom.") }
            return@launch
        }
        runCatching { exportService.export(snapshot.projectName, model) }
            .onSuccess { result -> mutableState.update { it.copy(exportMessage = "Exportované ${result.files.size} súbory do ${result.files.first().parent}") } }
            .onFailure { error -> mutableState.update { it.copy(exportMessage = "Export zlyhal: ${error.message}") } }
    }

    override fun onCleared() { tracking.close(); super.onCleared() }

    private fun simplify(points: List<Vector2>): List<Vector2> {
        if (points.size <= 2) return points
        val result = mutableListOf(points.first())
        points.drop(1).dropLast(1).forEach { if (it.distanceTo(result.last()) >= 0.012) result += it }
        result += points.last()
        return result
    }
}
