package sk.strechostav.roofmeasure

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import dagger.hilt.android.AndroidEntryPoint
import sk.strechostav.roofmeasure.camera.CameraSurface
import sk.strechostav.roofmeasure.laser.ManualMeasurementParseResult
import sk.strechostav.roofmeasure.laser.ManualMeasurementParser
import sk.strechostav.roofmeasure.laser.ManualUnit
import sk.strechostav.roofmeasure.project.ProjectScreen
import sk.strechostav.roofmeasure.report.QuantitySummary
import sk.strechostav.roofmeasure.teaching.LineTeachingOverlay
import sk.strechostav.roofmeasure.teaching.SemanticTypeSelector

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RoofMeasureTheme { RoofMeasureRoot() } }
    }
}

@Composable
private fun RoofMeasureRoot(viewModel: MeasurementViewModel = viewModel()) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val projects by viewModel.projects.collectAsStateWithLifecycle()
    if (state.activeProjectId == null) {
        ProjectScreen(projects, viewModel::createProject, viewModel::openProject)
    } else {
        PermissionAwareMeasurementScreen(
            state = state,
            onFrame = viewModel::onFrame,
            onLineDrawn = viewModel::onLineDrawn,
            onSemantic = viewModel::setPendingSemantic,
            onConfirmLine = viewModel::confirmPendingLine,
            onCancelLine = viewModel::cancelPendingLine,
            onDrawing = viewModel::setDrawing,
            onRequestMeasurement = viewModel::requestMeasurement,
            onApplyMeasurement = viewModel::applyManualMeasurement,
            onCancelMeasurement = viewModel::cancelMeasurement,
            onToggleModel = viewModel::toggleModelSummary,
            onExport = viewModel::export,
            onClose = viewModel::closeProject,
        )
    }
}

@Composable
private fun PermissionAwareMeasurementScreen(
    state: MeasurementUiState,
    onFrame: (sk.strechostav.roofmeasure.vision.VisionFrame) -> Unit,
    onLineDrawn: (List<sk.strechostav.roofmeasure.math.Vector2>) -> Unit,
    onSemantic: (sk.strechostav.roofmeasure.domain.LineSemanticType) -> Unit,
    onConfirmLine: () -> Unit,
    onCancelLine: () -> Unit,
    onDrawing: (Boolean) -> Unit,
    onRequestMeasurement: () -> Unit,
    onApplyMeasurement: (Double) -> Unit,
    onCancelMeasurement: () -> Unit,
    onToggleModel: () -> Unit,
    onExport: () -> Unit,
    onClose: () -> Unit,
) {
    val context = LocalContext.current
    var cameraGranted by remember { mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        cameraGranted = result[Manifest.permission.CAMERA] == true || ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    LaunchedEffect(Unit) {
        val permissions = buildList {
            add(Manifest.permission.CAMERA)
            if (Build.VERSION.SDK_INT >= 31) { add(Manifest.permission.BLUETOOTH_SCAN); add(Manifest.permission.BLUETOOTH_CONNECT) }
            else add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        launcher.launch(permissions.toTypedArray())
    }
    if (!cameraGranted) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Kamera je potrebná na označovanie a sledovanie línií.", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { launcher.launch(arrayOf(Manifest.permission.CAMERA)) }, modifier = Modifier.padding(top = 16.dp)) { Text("Povoliť kameru") }
            TextButton(onClick = onClose) { Text("Späť na projekty") }
        }
        return
    }
    MeasurementScreen(state, onFrame, onLineDrawn, onSemantic, onConfirmLine, onCancelLine, onDrawing, onRequestMeasurement, onApplyMeasurement, onCancelMeasurement, onToggleModel, onExport, onClose)
}

@Composable
private fun MeasurementScreen(
    state: MeasurementUiState,
    onFrame: (sk.strechostav.roofmeasure.vision.VisionFrame) -> Unit,
    onLineDrawn: (List<sk.strechostav.roofmeasure.math.Vector2>) -> Unit,
    onSemantic: (sk.strechostav.roofmeasure.domain.LineSemanticType) -> Unit,
    onConfirmLine: () -> Unit,
    onCancelLine: () -> Unit,
    onDrawing: (Boolean) -> Unit,
    onRequestMeasurement: () -> Unit,
    onApplyMeasurement: (Double) -> Unit,
    onCancelMeasurement: () -> Unit,
    onToggleModel: () -> Unit,
    onExport: () -> Unit,
    onClose: () -> Unit,
) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        CameraSurface(onFrame, Modifier.fillMaxSize())
        LineTeachingOverlay(state.lines.values.toList(), state.pendingPolyline, state.drawingEnabled, onLineDrawn)
        Surface(
            color = Color(0xE6111A17),
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(12.dp),
            shape = MaterialTheme.shapes.medium,
        ) {
            Column(Modifier.padding(12.dp)) {
                Text(state.projectName, color = Color(0xFF8BE6B0), style = MaterialTheme.typography.labelLarge)
                Text(state.guidance, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text("Línie: ${state.lines.size} · ${if (state.model == null) "bez mierky" else "model kalibrovaný"}", color = Color(0xFFB7C7C0))
            }
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
            if (state.pendingPolyline != null) {
                SemanticTypeSelector(state.pendingSemantic, onSemantic, Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().background(Color(0xE6111A17)).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onConfirmLine, modifier = Modifier.weight(1f)) { Text("Potvrdiť líniu") }
                    OutlinedButton(onClick = onCancelLine, modifier = Modifier.weight(1f)) { Text("Zrušiť") }
                }
            } else {
                Row(Modifier.fillMaxWidth().background(Color(0xE6111A17)).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(onClick = { onDrawing(!state.drawingEnabled) }, colors = ButtonDefaults.buttonColors(containerColor = if (state.drawingEnabled) Color(0xFF8E44AD) else Color(0xFF2A6E50))) { Text(if (state.drawingEnabled) "Kreslím" else "Označiť") }
                    Button(onClick = onRequestMeasurement, enabled = state.lines.isNotEmpty()) { Text("Zmerať") }
                    OutlinedButton(onClick = onToggleModel, enabled = state.model != null) { Text("Model") }
                    OutlinedButton(onClick = onExport, enabled = state.model != null) { Text("Export") }
                    TextButton(onClick = onClose) { Text("Projekty") }
                }
            }
            state.exportMessage?.let { Text(it, color = Color.White, modifier = Modifier.fillMaxWidth().background(Color(0xE62A493C)).padding(8.dp)) }
        }
        if (state.showModelSummary) state.model?.let { model ->
            Surface(Modifier.align(Alignment.Center).padding(24.dp), color = Color(0xF5FFFFFF), shape = MaterialTheme.shapes.large) {
                Column {
                    QuantitySummary(model)
                    TextButton(onClick = onToggleModel, modifier = Modifier.align(Alignment.End)) { Text("Zavrieť") }
                }
            }
        }
    }
    if (state.selectedMeasurementLineId != null) ManualMeasurementDialog(onApplyMeasurement, onCancelMeasurement)
}

@Composable
private fun ManualMeasurementDialog(onApply: (Double) -> Unit, onCancel: () -> Unit) {
    var value by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Laserové alebo ručné meranie") },
        text = {
            Column {
                Text("Zadajte dĺžku zvýraznenej hrany v milimetroch.")
                OutlinedTextField(value, { value = it; error = null }, label = { Text("Dĺžka (mm)") }, isError = error != null, supportingText = { error?.let { Text(it) } })
            }
        },
        confirmButton = {
            Button(onClick = {
                when (val result = ManualMeasurementParser.parse(value, ManualUnit.MILLIMETRE)) {
                    is ManualMeasurementParseResult.Valid -> onApply(result.metres)
                    is ManualMeasurementParseResult.Invalid -> error = result.message
                }
            }) { Text("Použiť rozmer") }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Zrušiť") } },
    )
}

@Composable
private fun RoofMeasureTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(primary = Color(0xFF52D58B), secondary = Color(0xFF63A4FF), background = Color(0xFF0B1511)),
        content = content,
    )
}
