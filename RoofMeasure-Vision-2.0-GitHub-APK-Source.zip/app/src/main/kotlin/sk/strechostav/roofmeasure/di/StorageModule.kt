package sk.strechostav.roofmeasure.di

import android.content.Context
import androidx.room.Room
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import sk.strechostav.roofmeasure.storage.ProjectLocalDataSource
import sk.strechostav.roofmeasure.storage.RoofMeasureDatabase
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object StorageModule {
    @Provides
    @Singleton
    fun database(@ApplicationContext context: Context): RoofMeasureDatabase = Room.databaseBuilder(
        context,
        RoofMeasureDatabase::class.java,
        "roofmeasure-v2.db",
    ).build()

    @Provides
    @Singleton
    fun projectLocalDataSource(database: RoofMeasureDatabase): ProjectLocalDataSource = ProjectLocalDataSource(database)
}
