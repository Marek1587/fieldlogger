package sk.strechostav.roofmeasure.export

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import sk.strechostav.roofmeasure.bim.Ifc4Exporter
import sk.strechostav.roofmeasure.modeling.ParametricRoofModel
import java.io.File
import javax.inject.Inject

data class ExportResult(val files: List<File>, val warnings: List<String>)

class AndroidExportService @Inject constructor(@param:ApplicationContext private val context: Context) {
    fun export(baseName: String, model: ParametricRoofModel): ExportResult {
        val safeName = baseName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "roof" }
        val directory = requireNotNull(context.getExternalFilesDir("exports")) { "External app storage is unavailable" }
        directory.mkdirs()
        val artifacts = listOf(
            JsonModelExporter().export(safeName, model),
            GlbModelExporter().export(safeName, model),
            DaeModelExporter().export(safeName, model),
            Ifc4Exporter().export(safeName, model),
        )
        val files = artifacts.map { artifact -> File(directory, artifact.fileName).also { it.writeBytes(artifact.bytes) } }
        return ExportResult(files, artifacts.flatMap { it.warnings })
    }
}
