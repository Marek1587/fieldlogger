package sk.strechostav.roofmeasure

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class RoofMeasureApplication : Application()
