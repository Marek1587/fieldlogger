plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace = "sk.strechostav.roofmeasure"
    compileSdk = 36

    defaultConfig {
        applicationId = "sk.strechostav.roofmeasure"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0-mvp"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures { compose = true; buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

hilt { enableAggregatingTask = true }

dependencies {
    implementation(project(":core-domain"))
    implementation(project(":core-math"))
    implementation(project(":core-geometry"))
    implementation(project(":core-storage"))
    implementation(project(":core-vision"))
    implementation(project(":feature-project"))
    implementation(project(":feature-camera"))
    implementation(project(":feature-line-teaching"))
    implementation(project(":feature-line-tracking"))
    implementation(project(":feature-laser"))
    implementation(project(":feature-solver"))
    implementation(project(":feature-modeling"))
    implementation(project(":feature-bim"))
    implementation(project(":feature-export"))
    implementation(project(":feature-report"))
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.room.runtime)
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    debugImplementation(libs.androidx.compose.ui.tooling)
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.test.junit)
    androidTestImplementation(libs.androidx.test.espresso)
}
