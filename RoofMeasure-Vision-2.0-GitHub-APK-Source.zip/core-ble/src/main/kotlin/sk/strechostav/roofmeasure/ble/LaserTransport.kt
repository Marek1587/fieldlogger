package sk.strechostav.roofmeasure.ble

import kotlinx.coroutines.flow.Flow
import sk.strechostav.roofmeasure.domain.MeasurementSample

data class BleLaserDevice(val address: String, val displayName: String, val rssi: Int)

sealed interface LaserConnectionState {
    data object Idle : LaserConnectionState
    data object Scanning : LaserConnectionState
    data class DeviceFound(val device: BleLaserDevice) : LaserConnectionState
    data class Connecting(val device: BleLaserDevice) : LaserConnectionState
    data class DiagnosticReady(val device: BleLaserDevice, val serviceUuids: List<String>) : LaserConnectionState
    data class ProtocolUnavailable(val reason: String) : LaserConnectionState
    data class Failed(val message: String) : LaserConnectionState
}

interface LaserTransport : AutoCloseable {
    val state: Flow<LaserConnectionState>
    val samples: Flow<MeasurementSample>
    fun startScan()
    fun stopScan()
    fun connect(device: BleLaserDevice)
    fun disconnect()
}
