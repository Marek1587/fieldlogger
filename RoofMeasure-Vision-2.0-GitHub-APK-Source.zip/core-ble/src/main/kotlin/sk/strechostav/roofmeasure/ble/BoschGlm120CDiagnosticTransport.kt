package sk.strechostav.roofmeasure.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import sk.strechostav.roofmeasure.domain.MeasurementSample

/**
 * Safe discovery adapter. It intentionally does not guess proprietary characteristic UUIDs or payload layouts.
 * A licensed/documented protocol adapter can be inserted behind [LaserTransport] without changing the domain.
 */
@SuppressLint("MissingPermission")
class BoschGlm120CDiagnosticTransport(context: Context) : LaserTransport {
    private val manager = context.getSystemService(BluetoothManager::class.java)
    private val scanner get() = manager.adapter?.bluetoothLeScanner
    private val appContext = context.applicationContext
    private val mutableState = MutableStateFlow<LaserConnectionState>(LaserConnectionState.Idle)
    private val mutableSamples = MutableSharedFlow<MeasurementSample>(extraBufferCapacity = 4)
    private var gatt: BluetoothGatt? = null

    override val state = mutableState.asStateFlow()
    override val samples = mutableSamples.asSharedFlow()

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val name = result.device.name ?: result.scanRecord?.deviceName ?: "BLE device"
            if (name.contains("GLM", ignoreCase = true) || name.contains("Bosch", ignoreCase = true)) {
                mutableState.value = LaserConnectionState.DeviceFound(BleLaserDevice(result.device.address, name, result.rssi))
            }
        }

        override fun onScanFailed(errorCode: Int) {
            mutableState.value = LaserConnectionState.Failed("BLE scan failed: $errorCode")
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                mutableState.value = LaserConnectionState.Failed("GATT status: $status")
                return
            }
            if (newState == android.bluetooth.BluetoothProfile.STATE_CONNECTED) gatt.discoverServices()
            else if (newState == android.bluetooth.BluetoothProfile.STATE_DISCONNECTED) mutableState.value = LaserConnectionState.Idle
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val current = (mutableState.value as? LaserConnectionState.Connecting)?.device
                ?: BleLaserDevice(gatt.device.address, gatt.device.name ?: "Bosch GLM", 0)
            if (status == BluetoothGatt.GATT_SUCCESS) {
                mutableState.value = LaserConnectionState.DiagnosticReady(current, gatt.services.map(BluetoothGattService::getUuid).map(Any::toString))
                mutableState.value = LaserConnectionState.ProtocolUnavailable("Bosch measurement protocol must be supplied from an official SDK or licensed specification.")
            } else mutableState.value = LaserConnectionState.Failed("Service discovery failed: $status")
        }
    }

    override fun startScan() {
        mutableState.value = LaserConnectionState.Scanning
        scanner?.startScan(scanCallback) ?: run { mutableState.value = LaserConnectionState.Failed("Bluetooth LE is unavailable") }
    }

    override fun stopScan() { scanner?.stopScan(scanCallback); if (mutableState.value is LaserConnectionState.Scanning) mutableState.value = LaserConnectionState.Idle }

    override fun connect(device: BleLaserDevice) {
        stopScan()
        val remote = manager.adapter?.getRemoteDevice(device.address) ?: run {
            mutableState.value = LaserConnectionState.Failed("Bluetooth adapter is unavailable")
            return
        }
        mutableState.value = LaserConnectionState.Connecting(device)
        gatt = remote.connectGatt(appContext, false, gattCallback, android.bluetooth.BluetoothDevice.TRANSPORT_LE)
    }

    override fun disconnect() { gatt?.disconnect(); gatt?.close(); gatt = null; mutableState.value = LaserConnectionState.Idle }
    override fun close() { stopScan(); disconnect() }
}
