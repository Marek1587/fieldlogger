# RoofMeasure Vision 2.0

Modulárna Android/Kotlin implementácia terénneho workflow „ukáž líniu → prejdi kamerou objekt → premeraj zvýraznený rozmer“. Repozitár obsahuje zostaviteľnú MVP aplikáciu, Kotlin Multiplatform geometrické jadro a všetkých 16 požadovaných návrhových dokumentov.

## Aktuálne funkčný vertikálny rez

- projekt v Room: založiť, uložiť línie, znovu otvoriť, auditovať zmeny;
- CameraX live preview s adaptívnym `KEEP_ONLY_LATEST` analyzérom;
- kreslenie a klasifikácia významových línií v Compose overlay;
- OpenCV LSD/Canny kandidáti a pyramídový Lucas–Kanade tracking;
- ARCore optional session/depth adapter a explicitné súradnicové rámce;
- snapnutie metrických línií do grafu, cyklus a parametrická strešná rovina;
- robustný scale solver s Huber stratou a odľahlými meraniami;
- informačný plánovač ďalšieho merania;
- ručný rozmer a bezpečný BLE diagnostický adaptér pre Bosch GLM 120 C;
- JSON, binárny GLB, DAE a IFC4 technický export;
- neistota A–E, zdroj a kalibračný stav vo výstupe.

## Build

Požiadavky: JDK 17, Android SDK 36 a Android Studio s podporou AGP 8.11.2.

```powershell
$env:JAVA_HOME='C:\path\to\jdk-17'
$env:ANDROID_HOME='C:\path\to\Android\Sdk'
.\gradlew.bat :app:assembleDebug
```

Core testy bez emulátora:

```powershell
.\gradlew.bat :core-math:desktopTest :core-geometry:desktopTest `
  :feature-solver:desktopTest :feature-modeling:desktopTest `
  :feature-export:desktopTest :feature-bim:desktopTest
```

## Moduly

`core-domain`, `core-math`, `core-geometry`, `feature-solver`, `feature-modeling`, `feature-bim` a `feature-export` sú KMP moduly pre Android, desktop a iOS. Android adaptéry sú izolované v `core-vision`, `core-ar`, `core-ble`, `core-storage` a feature moduloch. `app` iba skladá use-cases a DI.

## Dôležité hranice

Toto je overený MVP základ, nie terénne certifikovaný produkčný merač. Bosch payload sa neinterpretuje bez oficiálnej/licencovanej špecifikácie. DAE/GLB/IFC MVP zámerne vynechá rovinu s otvorom namiesto nesprávneho vyplnenia; constrained triangulácia a plné `IfcOpeningElement` mapovanie sú ďalší release gate. Deklarácia presnosti vyžaduje kalibračný dataset a plán z [FIELD_VALIDATION_PLAN.md](docs/FIELD_VALIDATION_PLAN.md).

Presný stav funkcií je v [IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md).
