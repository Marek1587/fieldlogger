package sk.strechostav.roofmeasure.storage

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "projects")
data class ProjectEntity(
    @androidx.room.PrimaryKey val id: String,
    val name: String,
    val type: String,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long,
    val revision: Long,
    val sessionStage: String,
)

@Entity(
    tableName = "structural_lines",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")],
)
data class StructuralLineEntity(
    val projectId: String,
    val id: String,
    val semanticType: String,
    val lifecycle: String,
    val source: String,
    val confidence: Double,
    val calibrationState: String,
    val projection2D: String,
    val endpoints3D: String?,
    val observationIds: String,
    val updatedAtEpochMillis: Long,
)

@Entity(
    tableName = "measurement_samples",
    primaryKeys = ["projectId", "id"],
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")],
)
data class MeasurementEntity(
    val projectId: String,
    val id: String,
    val valueMetres: Double,
    val sigmaMetres: Double,
    val source: String,
    val capturedAtEpochMillis: Long,
    val rawPayloadHash: String?,
)

@Entity(
    tableName = "audit_events",
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId"), Index(value = ["projectId", "timestampEpochMillis"])],
)
data class AuditEventEntity(
    @androidx.room.PrimaryKey val id: String,
    val projectId: String,
    val timestampEpochMillis: Long,
    val eventType: String,
    val payloadJson: String,
)
