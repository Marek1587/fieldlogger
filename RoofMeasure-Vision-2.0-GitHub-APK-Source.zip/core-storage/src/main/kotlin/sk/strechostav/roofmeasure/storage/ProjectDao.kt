package sk.strechostav.roofmeasure.storage

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

data class StoredProject(
    @androidx.room.Embedded val project: ProjectEntity,
    @androidx.room.Relation(parentColumn = "id", entityColumn = "projectId") val lines: List<StructuralLineEntity>,
    @androidx.room.Relation(parentColumn = "id", entityColumn = "projectId") val measurements: List<MeasurementEntity>,
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY updatedAtEpochMillis DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Transaction
    @Query("SELECT * FROM projects WHERE id = :projectId")
    fun observeProject(projectId: String): Flow<StoredProject?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertProject(project: ProjectEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLine(line: StructuralLineEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMeasurement(measurement: MeasurementEntity)

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun appendAudit(event: AuditEventEntity)

    @Query("UPDATE projects SET revision = revision + 1, updatedAtEpochMillis = :timestamp WHERE id = :projectId")
    suspend fun incrementRevision(projectId: String, timestamp: Long): Int

    @Query("UPDATE projects SET sessionStage = :stage, revision = revision + 1, updatedAtEpochMillis = :timestamp WHERE id = :projectId")
    suspend fun updateStage(projectId: String, stage: String, timestamp: Long): Int

    @Query("SELECT * FROM audit_events WHERE projectId = :projectId ORDER BY timestampEpochMillis, id")
    fun observeAudit(projectId: String): Flow<List<AuditEventEntity>>
}
