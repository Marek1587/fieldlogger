package sk.strechostav.roofmeasure.storage

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.ProjectMetadata
import sk.strechostav.roofmeasure.domain.ProjectType
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.SessionStage
import sk.strechostav.roofmeasure.domain.Timestamp
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.LineSource
import sk.strechostav.roofmeasure.math.Vector2
import sk.strechostav.roofmeasure.math.Vector3

class ProjectLocalDataSource(private val database: RoofMeasureDatabase) {
    private val dao = database.projectDao()

    fun observeProjects(): Flow<List<ProjectEntity>> = dao.observeProjects()
    fun observeProject(projectId: EntityId): Flow<StoredProject?> = dao.observeProject(projectId.value)
    fun observeAudit(projectId: EntityId): Flow<List<AuditEventEntity>> = dao.observeAudit(projectId.value)

    suspend fun create(metadata: ProjectMetadata) {
        database.withTransaction {
            dao.insertProject(
                ProjectEntity(
                    metadata.id.value,
                    metadata.name,
                    metadata.type.name,
                    metadata.createdAt.epochMillis,
                    metadata.updatedAt.epochMillis,
                    metadata.revision.value,
                    SessionStage.SETUP.name,
                ),
            )
            dao.appendAudit(
                AuditEventEntity(
                    "audit:create:${metadata.id.value}",
                    metadata.id.value,
                    metadata.createdAt.epochMillis,
                    "PROJECT_CREATED",
                    "{\"name\":\"${escape(metadata.name)}\"}",
                ),
            )
        }
    }

    suspend fun saveLine(projectId: EntityId, line: TrackedStructuralLine, timestamp: Timestamp) {
        database.withTransaction {
            dao.upsertLine(line.toEntity(projectId, timestamp))
            check(dao.incrementRevision(projectId.value, timestamp.epochMillis) == 1) { "Project does not exist" }
            dao.appendAudit(
                AuditEventEntity(
                    "audit:line:${line.id.value}:${timestamp.epochMillis}",
                    projectId.value,
                    timestamp.epochMillis,
                    "LINE_SAVED",
                    "{\"lineId\":\"${escape(line.id.value)}\",\"semanticType\":\"${line.semanticType.name}\"}",
                ),
            )
        }
    }

    suspend fun updateStage(projectId: EntityId, stage: SessionStage, timestamp: Timestamp) {
        database.withTransaction {
            check(dao.updateStage(projectId.value, stage.name, timestamp.epochMillis) == 1) { "Project does not exist" }
            dao.appendAudit(AuditEventEntity("audit:stage:${timestamp.epochMillis}", projectId.value, timestamp.epochMillis, "STAGE_CHANGED", "{\"stage\":\"${stage.name}\"}"))
        }
    }

    private fun TrackedStructuralLine.toEntity(projectId: EntityId, timestamp: Timestamp) = StructuralLineEntity(
        projectId = projectId.value,
        id = id.value,
        semanticType = semanticType.name,
        lifecycle = lifecycle.name,
        source = source.name,
        confidence = confidence,
        calibrationState = calibrationState.name,
        projection2D = currentProjection2D.joinToString(";") { "${it.x},${it.y}" },
        endpoints3D = endpoints3D?.let { "${it.first.x},${it.first.y},${it.first.z};${it.second.x},${it.second.y},${it.second.z}" },
        observationIds = observationIds.joinToString(",", transform = EntityId::value),
        updatedAtEpochMillis = timestamp.epochMillis,
    )

    private fun escape(value: String): String = value.replace("\\", "\\\\").replace("\"", "\\\"")
}

fun ProjectEntity.toDomain(): ProjectMetadata = ProjectMetadata(
    EntityId(id), name, ProjectType.valueOf(type), Timestamp(createdAtEpochMillis), Timestamp(updatedAtEpochMillis), RevisionId(revision),
)

fun StructuralLineEntity.toDomain(): TrackedStructuralLine {
    fun point2(value: String): Vector2? = value.split(',').takeIf { it.size == 2 }?.let { parts -> Vector2(parts[0].toDouble(), parts[1].toDouble()) }
    fun point3(value: String): Vector3? = value.split(',').takeIf { it.size == 3 }?.let { parts -> Vector3(parts[0].toDouble(), parts[1].toDouble(), parts[2].toDouble()) }
    val endpoints = endpoints3D?.split(';')?.takeIf { it.size == 2 }?.let { parts ->
        val first = point3(parts[0])
        val second = point3(parts[1])
        if (first != null && second != null) first to second else null
    }
    return TrackedStructuralLine(
        id = EntityId(id),
        semanticType = LineSemanticType.valueOf(semanticType),
        endpoints3D = endpoints,
        currentProjection2D = projection2D.split(';').mapNotNull(::point2),
        confidence = confidence,
        covariance = null,
        lifecycle = LineLifecycle.valueOf(lifecycle),
        observationIds = observationIds.split(',').filter(String::isNotBlank).map(::EntityId),
        source = LineSource.valueOf(source),
        calibrationState = CalibrationState.valueOf(calibrationState),
    )
}
