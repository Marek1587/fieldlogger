package sk.strechostav.roofmeasure.storage

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ProjectEntity::class, StructuralLineEntity::class, MeasurementEntity::class, AuditEventEntity::class],
    version = 1,
    exportSchema = true,
)
abstract class RoofMeasureDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}
