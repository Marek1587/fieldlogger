package sk.strechostav.roofmeasure.solver

import sk.strechostav.roofmeasure.domain.DistanceConstraint
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.MeasurementStatus
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StructuralLineGraph
import sk.strechostav.roofmeasure.math.RobustLoss
import sk.strechostav.roofmeasure.math.RobustStatistics
import kotlin.math.sqrt

enum class SolverStatus { CONVERGED, MAX_ITERATIONS, UNDERCONSTRAINED, INVALID_INPUT, DIVERGED }

data class ConstraintResidual(
    val constraintId: EntityId,
    val residualMetres: Double,
    val normalizedResidual: Double,
    val robustWeight: Double,
    val outlier: Boolean,
)

data class ScaleSolverResult(
    val status: SolverStatus,
    val scale: Double,
    val sigmaScale: Double,
    val initialCost: Double,
    val finalCost: Double,
    val iterations: Int,
    val residuals: List<ConstraintResidual>,
    val optimizedGraph: StructuralLineGraph,
    val revision: RevisionId,
)

class RobustScaleSolver(
    private val loss: RobustLoss = RobustLoss.Huber(1.5),
    private val maxIterations: Int = 20,
    private val convergenceTolerance: Double = 1e-10,
) {
    fun solve(graph: StructuralLineGraph, constraints: Collection<DistanceConstraint>): ScaleSolverResult {
        val usable = constraints
            .filter { it.status in setOf(MeasurementStatus.CONFIRMED, MeasurementStatus.LOCKED, MeasurementStatus.CONFLICTING) }
            .mapNotNull { constraint ->
                val start = graph.nodes[constraint.startNodeId]?.position ?: return@mapNotNull null
                val end = graph.nodes[constraint.endNodeId]?.position ?: return@mapNotNull null
                val visual = start.distanceTo(end)
                if (visual <= 1e-9 || constraint.measuredMetres <= 0.0 || constraint.sigmaMetres <= 0.0) null
                else Observation(constraint, visual)
            }

        if (usable.isEmpty()) return emptyResult(graph, SolverStatus.UNDERCONSTRAINED)
        var scale = RobustStatistics.median(usable.map { it.constraint.measuredMetres / it.visualMetres })
        if (!scale.isFinite() || scale <= 0.0) return emptyResult(graph, SolverStatus.INVALID_INPUT)
        val initialCost = cost(scale, usable)
        var iterations = 0
        var normal = 0.0
        while (iterations < maxIterations) {
            var numerator = 0.0
            var denominator = 0.0
            usable.forEach { observation ->
                val residual = scale * observation.visualMetres - observation.constraint.measuredMetres
                val normalized = residual / observation.constraint.sigmaMetres
                val robust = loss.weight(normalized)
                val inverseVariance = 1.0 / (observation.constraint.sigmaMetres * observation.constraint.sigmaMetres)
                numerator += robust * inverseVariance * observation.visualMetres * observation.constraint.measuredMetres
                denominator += robust * inverseVariance * observation.visualMetres * observation.visualMetres
            }
            normal = denominator
            if (denominator <= 1e-15) return emptyResult(graph, SolverStatus.UNDERCONSTRAINED)
            val next = numerator / denominator
            if (!next.isFinite() || next <= 0.0) return emptyResult(graph, SolverStatus.DIVERGED)
            iterations++
            if (kotlin.math.abs(next - scale) <= convergenceTolerance * (1.0 + scale)) {
                scale = next
                break
            }
            scale = next
        }

        val residuals = usable.map { observation ->
            val residual = scale * observation.visualMetres - observation.constraint.measuredMetres
            val normalized = residual / observation.constraint.sigmaMetres
            val weight = loss.weight(normalized)
            ConstraintResidual(observation.constraint.id, residual, normalized, weight, kotlin.math.abs(normalized) > 3.0)
        }
        val newRevision = RevisionId(graph.revision.value + 1)
        val scaledNodes = graph.nodes.mapValues { (_, node) ->
            node.copy(position = node.position * scale, covariance = node.covariance.copy(matrix = node.covariance.matrix.let { matrix ->
                val varianceScale = scale * scale
                sk.strechostav.roofmeasure.math.Matrix3(
                    matrix.m00 * varianceScale, matrix.m01 * varianceScale, matrix.m02 * varianceScale,
                    matrix.m10 * varianceScale, matrix.m11 * varianceScale, matrix.m12 * varianceScale,
                    matrix.m20 * varianceScale, matrix.m21 * varianceScale, matrix.m22 * varianceScale,
                )
            }))
        }
        val optimized = graph.copy(revision = newRevision, nodes = scaledNodes)
        val status = if (iterations < maxIterations) SolverStatus.CONVERGED else SolverStatus.MAX_ITERATIONS
        return ScaleSolverResult(
            status = status,
            scale = scale,
            sigmaScale = sqrt(1.0 / normal),
            initialCost = initialCost,
            finalCost = cost(scale, usable),
            iterations = iterations,
            residuals = residuals,
            optimizedGraph = optimized,
            revision = newRevision,
        )
    }

    private fun cost(scale: Double, observations: List<Observation>): Double = observations.sumOf { observation ->
        val normalized = (scale * observation.visualMetres - observation.constraint.measuredMetres) / observation.constraint.sigmaMetres
        val weight = loss.weight(normalized)
        weight * normalized * normalized
    }

    private fun emptyResult(graph: StructuralLineGraph, status: SolverStatus) = ScaleSolverResult(
        status, 1.0, Double.POSITIVE_INFINITY, 0.0, 0.0, 0, emptyList(), graph, graph.revision,
    )

    private data class Observation(val constraint: DistanceConstraint, val visualMetres: Double)
}
