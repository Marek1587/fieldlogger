package sk.strechostav.roofmeasure.solver

import sk.strechostav.roofmeasure.domain.CalibrationState
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.StructuralLineGraph
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import kotlin.math.ln

enum class MeasurementCandidateType { EDGE_LENGTH, POINT_DISTANCE, HEIGHT, DIAGONAL }

data class MeasurementCandidate(
    val id: EntityId,
    val type: MeasurementCandidateType,
    val startNodeId: EntityId,
    val endNodeId: EntityId,
    val targetLineId: EntityId?,
    val expectedInformationGain: Double,
    val conditionImprovement: Double,
    val quantityRiskReduction: Double,
    val accessCost: Double,
    val redundancy: Double,
    val safetyAllowed: Boolean,
    val utility: Double,
    val instruction: String,
)

sealed interface PlanningDecision {
    data class Recommend(val candidate: MeasurementCandidate, val alternatives: List<MeasurementCandidate>) : PlanningDecision
    data class NeedAnotherView(val reason: String) : PlanningDecision
    data class Sufficient(val reason: String) : PlanningDecision
}

class MeasurementPlanner(
    private val minimumUtility: Double = 0.20,
    private val assumedLaserSigmaMetres: Double = 0.002,
) {
    fun plan(
        graph: StructuralLineGraph,
        lines: Map<EntityId, TrackedStructuralLine>,
        metricScaleKnown: Boolean,
        inaccessibleEdgeIds: Set<EntityId> = emptySet(),
    ): PlanningDecision {
        if (graph.edges.isEmpty()) return PlanningDecision.NeedAnotherView("Nie je dostupná uzavretá geometria. Nasnímajte ďalšiu výraznú hranu.")
        val candidates = graph.edges.values.mapNotNull { edge ->
            val line = lines[edge.lineId]
            if (line?.calibrationState in setOf(CalibrationState.LOCKED, CalibrationState.REDUNDANTLY_VERIFIED)) return@mapNotNull null
            val start = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
            val end = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
            val length = start.position.distanceTo(end.position)
            if (length <= 0.05) return@mapNotNull null
            val accessible = edge.id !in inaccessibleEdgeIds
            val connectivity = (start.incidentEdgeIds.size + end.incidentEdgeIds.size).toDouble() / 4.0
            val visualSigma = (start.covariance.radialSigma + end.covariance.radialSigma).coerceAtLeast(0.003)
            val information = ln(1.0 + visualSigma * visualSigma / (assumedLaserSigmaMetres * assumedLaserSigmaMetres))
            val scaleBonus = if (!metricScaleKnown) length.coerceAtMost(10.0) / 10.0 else 0.0
            val semanticRisk = when (edge.semanticType) {
                LineSemanticType.EAVE, LineSemanticType.RIDGE, LineSemanticType.HIP, LineSemanticType.VALLEY -> 1.0
                LineSemanticType.CHIMNEY, LineSemanticType.ROOF_WINDOW -> 0.8
                else -> 0.4
            }
            val redundancy = if (line?.calibrationState == CalibrationState.LASER_MEASURED) 0.8 else 0.0
            val accessCost = if (accessible) 0.1 else 10.0
            val utility = 0.40 * information + 0.25 * (connectivity + scaleBonus) + 0.25 * semanticRisk - 0.20 * redundancy - accessCost
            val name = semanticName(edge.semanticType)
            MeasurementCandidate(
                id = EntityId("candidate:${edge.id.value}"),
                type = MeasurementCandidateType.EDGE_LENGTH,
                startNodeId = edge.startNodeId,
                endNodeId = edge.endNodeId,
                targetLineId = edge.lineId,
                expectedInformationGain = information,
                conditionImprovement = connectivity + scaleBonus,
                quantityRiskReduction = semanticRisk,
                accessCost = accessCost,
                redundancy = redundancy,
                safetyAllowed = accessible,
                utility = utility,
                instruction = if (!metricScaleKnown) {
                    "Pre určenie mierky premerajte $name ${edge.id.value}."
                } else {
                    "Pre zníženie neistoty premerajte $name ${edge.id.value}."
                },
            )
        }.filter(MeasurementCandidate::safetyAllowed).sortedWith(
            compareByDescending<MeasurementCandidate> { it.utility }.thenBy { it.id.value },
        )

        val best = candidates.firstOrNull() ?: return PlanningDecision.NeedAnotherView("Dostupné hrany nie je možné bezpečne zamerať. Zvoľte iný pohľad alebo ručný rozmer.")
        return if (best.utility < minimumUtility && metricScaleKnown) {
            PlanningDecision.Sufficient("Model je dostatočne kalibrovaný; ďalšie dostupné meranie má malý očakávaný prínos.")
        } else PlanningDecision.Recommend(best, candidates.drop(1).take(2))
    }

    private fun semanticName(type: LineSemanticType): String = when (type) {
        LineSemanticType.EAVE -> "odkvapovú hranu"
        LineSemanticType.RIDGE -> "hrebeň"
        LineSemanticType.HIP -> "nárožie"
        LineSemanticType.VALLEY -> "úžľabie"
        LineSemanticType.CHIMNEY -> "hranu komína"
        LineSemanticType.ROOF_WINDOW -> "hranu strešného okna"
        else -> "zvýraznenú hranu"
    }
}
