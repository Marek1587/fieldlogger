package sk.strechostav.roofmeasure.solver

import sk.strechostav.roofmeasure.domain.Covariance3
import sk.strechostav.roofmeasure.domain.DistanceConstraint
import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.MeasurementStatus
import sk.strechostav.roofmeasure.domain.NodeType
import sk.strechostav.roofmeasure.domain.RevisionId
import sk.strechostav.roofmeasure.domain.StructuralLineGraph
import sk.strechostav.roofmeasure.domain.StructuralNode
import sk.strechostav.roofmeasure.math.Vector3
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue
import sk.strechostav.roofmeasure.domain.LineSemanticType
import sk.strechostav.roofmeasure.domain.StructuralEdge
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.LineSource
import sk.strechostav.roofmeasure.domain.CalibrationState

class ScaleSolverTest {
    @Test
    fun recoversScaleAndSuppressesOutlier() {
        val a = EntityId("a")
        val b = EntityId("b")
        val graph = StructuralLineGraph.EMPTY.copy(
            nodes = mapOf(
                a to StructuralNode(a, Vector3.ZERO, Covariance3.isotropic(0.05), NodeType.CORNER, emptySet()),
                b to StructuralNode(b, Vector3(2.0, 0.0, 0.0), Covariance3.isotropic(0.05), NodeType.CORNER, emptySet()),
            ),
        )
        val valid = constraint("valid", a, b, 3.0, 0.002)
        val outlier = constraint("outlier", a, b, 3.4, 0.002)
        val result = RobustScaleSolver().solve(graph, listOf(valid, valid.copy(id = EntityId("valid2")), outlier))
        assertEquals(SolverStatus.CONVERGED, result.status)
        assertTrue(result.scale in 1.49..1.53)
        assertTrue(result.residuals.first { it.constraintId.value == "outlier" }.outlier)
    }

    @Test
    fun plannerPrefersLongConnectedEaveForFirstScale() {
        val a = EntityId("a")
        val b = EntityId("b")
        val lineId = EntityId("eave-line")
        val edgeId = EntityId("eave-edge")
        val graph = StructuralLineGraph.EMPTY.copy(
            nodes = mapOf(
                a to StructuralNode(a, Vector3.ZERO, Covariance3.isotropic(0.08), NodeType.CORNER, setOf(edgeId)),
                b to StructuralNode(b, Vector3(8.0, 0.0, 0.0), Covariance3.isotropic(0.08), NodeType.CORNER, setOf(edgeId)),
            ),
            edges = mapOf(edgeId to StructuralEdge(edgeId, a, b, LineSemanticType.EAVE, lineId, 0.9)),
        )
        val lines = mapOf(lineId to TrackedStructuralLine(
            lineId, LineSemanticType.EAVE, Vector3.ZERO to Vector3(8.0, 0.0, 0.0), confidence = 0.9,
            covariance = Covariance3.isotropic(0.08), lifecycle = LineLifecycle.INITIALIZED_3D,
            observationIds = emptyList(), source = LineSource.USER_CONFIRMED, calibrationState = CalibrationState.VISUALLY_ESTIMATED,
        ))
        val decision = MeasurementPlanner().plan(graph, lines, metricScaleKnown = false)
        assertTrue(decision is PlanningDecision.Recommend)
        assertEquals(lineId, decision.candidate.targetLineId)
    }

    private fun constraint(id: String, a: EntityId, b: EntityId, metres: Double, sigma: Double) = DistanceConstraint(
        EntityId(id), EntityId("intent:$id"), EntityId("sample:$id"), a, b, metres, sigma, MeasurementStatus.CONFIRMED,
    )
}
