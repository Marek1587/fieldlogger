package sk.strechostav.roofmeasure.tracking

import sk.strechostav.roofmeasure.domain.EntityId
import sk.strechostav.roofmeasure.domain.LineLifecycle
import sk.strechostav.roofmeasure.domain.TrackedStructuralLine
import sk.strechostav.roofmeasure.vision.OpticalFlowLineTracker
import sk.strechostav.roofmeasure.vision.VisionFrame
import sk.strechostav.roofmeasure.vision.VisionRuntime

class LineTrackingCoordinator(private val tracker: OpticalFlowLineTracker = OpticalFlowLineTracker()) : AutoCloseable {
    private val runtimeReady = VisionRuntime.initialize()

    suspend fun update(frame: VisionFrame, lines: Map<EntityId, TrackedStructuralLine>): Map<EntityId, TrackedStructuralLine> {
        if (!runtimeReady) return lines
        val active = lines.filterValues { it.currentProjection2D.size >= 2 && it.lifecycle !in setOf(LineLifecycle.REJECTED, LineLifecycle.CONFLICT) }
        val result = tracker.track(frame, active.mapValues { it.value.currentProjection2D })
        return lines.mapValues { (id, line) ->
            val projection = result.projections[id] ?: return@mapValues line
            val confidence = result.confidence[id] ?: 0.0
            line.copy(
                currentProjection2D = projection,
                confidence = (line.confidence * 0.7 + confidence * 0.3).coerceIn(0.0, 1.0),
                lifecycle = if (confidence < 0.15) LineLifecycle.LOST else LineLifecycle.TRACKED_2D,
            )
        }
    }

    override fun close() = tracker.close()
}
