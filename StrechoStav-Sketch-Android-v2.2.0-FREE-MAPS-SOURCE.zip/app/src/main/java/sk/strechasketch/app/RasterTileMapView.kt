package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.LruCache
import android.view.View
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

@SuppressLint("ViewConstructor")
class RasterTileMapView(
    context: Context,
    private val project: RoofProject
) : View(context) {
    var onStatusChanged: ((String) -> Unit)? = null

    private val executor = Executors.newFixedThreadPool(4)
    private val memoryCache = object : LruCache<String, Bitmap>(32 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val inFlight = mutableSetOf<String>()
    private val cacheDir = File(context.cacheDir, "strechostav-map-tiles").apply { mkdirs() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val attributionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.DKGRAY
        textSize = 10f * resources.displayMetrics.scaledDensity
    }
    private var lastLoadedLayer = ""
    private var lastErrorAt = 0L

    init {
        setBackgroundColor(Color.rgb(238, 236, 226))
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0 || project.mapType == "DOCUMENT") return

        val layer = normalizedLayer()
        val zoom = project.zoom.coerceIn(3, if (layer == "OSM_TERRAIN") 17 else 21)
        val centerX = Geometry.worldX(project.centerLon, zoom)
        val centerY = Geometry.worldY(project.centerLat, zoom)
        val leftWorld = centerX - width / 2.0
        val topWorld = centerY - height / 2.0
        val firstX = floor(leftWorld / TILE_SIZE).toInt() - 1
        val lastX = floor((leftWorld + width) / TILE_SIZE).toInt() + 1
        val firstY = floor(topWorld / TILE_SIZE).toInt() - 1
        val lastY = floor((topWorld + height) / TILE_SIZE).toInt() + 1
        val tileCount = 1 shl zoom

        for (rawX in firstX..lastX) {
            val tileX = ((rawX % tileCount) + tileCount) % tileCount
            for (tileY in max(0, firstY)..min(tileCount - 1, lastY)) {
                val key = "$layer-$zoom-$tileX-$tileY"
                val left = (rawX * TILE_SIZE - leftWorld).toFloat()
                val top = (tileY * TILE_SIZE - topWorld).toFloat()
                val destination = RectF(left, top, left + TILE_SIZE, top + TILE_SIZE)
                val bitmap = memoryCache.get(key)
                if (bitmap != null && !bitmap.isRecycled) {
                    canvas.drawBitmap(bitmap, null, destination, paint)
                } else {
                    drawPlaceholder(canvas, destination)
                    requestTile(layer, zoom, tileX, tileY, key)
                }
            }
        }
        drawAttribution(canvas, layer)
    }

    fun clearMemoryCache() = memoryCache.evictAll()

    fun shutdown() {
        executor.shutdownNow()
        clearMemoryCache()
    }

    private fun requestTile(layer: String, zoom: Int, x: Int, y: Int, key: String) {
        synchronized(inFlight) {
            if (!inFlight.add(key)) return
        }
        executor.execute {
            try {
                val file = File(cacheDir, "$key.tile")
                val bitmap = if (file.isFile && System.currentTimeMillis() - file.lastModified() < CACHE_TTL_MS) {
                    BitmapFactory.decodeFile(file.absolutePath)
                } else {
                    download(tileUrl(layer, zoom, x, y), file)
                } ?: error("Server neposlal obrázkovú dlaždicu.")
                memoryCache.put(key, bitmap)
                post {
                    if (lastLoadedLayer != layer) {
                        lastLoadedLayer = layer
                        val name = when (layer) {
                            "ZBGIS_ORTHO" -> "ZBGIS ortofoto"
                            "OSM_TERRAIN" -> "OSM terén"
                            else -> "OpenStreetMap"
                        }
                        onStatusChanged?.invoke("$name je načítaná. Zoom ${project.zoom}; viditeľná plocha sa skladá z viacerých dlaždíc.")
                    }
                    invalidate()
                }
            } catch (error: Exception) {
                val now = System.currentTimeMillis()
                if (now - lastErrorAt > 8_000) {
                    lastErrorAt = now
                    post { onStatusChanged?.invoke("Mapový podklad sa nenačítal: ${error.message}") }
                }
            } finally {
                synchronized(inFlight) { inFlight.remove(key) }
            }
        }
    }

    private fun download(url: String, target: File): Bitmap? {
        val connection = URI(url).toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = 15_000
        connection.readTimeout = 30_000
        connection.requestMethod = "GET"
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("Accept", "image/png,image/jpeg,image/*")
        return try {
            val code = connection.responseCode
            require(code in 200..299) { "mapová služba odpovedala kódom $code" }
            val bytes = connection.inputStream.use { it.readBytes() }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                ?: error("neplatný formát dlaždice")
            runCatching { target.writeBytes(bytes) }
            bitmap
        } finally {
            connection.disconnect()
        }
    }

    private fun tileUrl(layer: String, zoom: Int, x: Int, y: Int): String = when (layer) {
        "OSM" -> "https://tile.openstreetmap.org/$zoom/$x/$y.png"
        "OSM_TERRAIN" -> "https://a.tile.opentopomap.org/$zoom/$x/$y.png"
        else -> zbgisWmsUrl(zoom, x, y)
    }

    private fun zbgisWmsUrl(zoom: Int, x: Int, y: Int): String {
        val world = 20_037_508.342789244
        val resolution = 2.0 * world / (TILE_SIZE * 2.0.pow(zoom.toDouble()))
        val minX = x * TILE_SIZE * resolution - world
        val maxX = (x + 1) * TILE_SIZE * resolution - world
        val maxY = world - y * TILE_SIZE * resolution
        val minY = world - (y + 1) * TILE_SIZE * resolution
        val bbox = String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", minX, minY, maxX, maxY)
        return "https://zbgisws.skgeodesy.sk/zbgis_ortofoto_wms/service.svc/get" +
            "?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&LAYERS=1&STYLES=" +
            "&CRS=EPSG:3857&BBOX=$bbox&WIDTH=512&HEIGHT=512&FORMAT=image/jpeg"
    }

    private fun normalizedLayer(): String = when (project.mapType.uppercase()) {
        "OSM" -> "OSM"
        "OSM_TERRAIN" -> "OSM_TERRAIN"
        else -> "ZBGIS_ORTHO"
    }

    private fun drawPlaceholder(canvas: Canvas, destination: RectF) {
        paint.color = Color.rgb(238, 236, 226)
        canvas.drawRect(destination, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = Color.rgb(220, 218, 208)
        canvas.drawRect(destination, paint)
        paint.style = Paint.Style.FILL
    }

    private fun drawAttribution(canvas: Canvas, layer: String) {
        val text = when (layer) {
            "ZBGIS_ORTHO" -> "Ortofoto © GKÚ Bratislava, CC BY 4.0"
            "OSM_TERRAIN" -> "© OpenStreetMap prispievatelia | štýl © OpenTopoMap"
            else -> "© OpenStreetMap prispievatelia"
        }
        val padding = 6f * resources.displayMetrics.density
        val textWidth = attributionPaint.measureText(text)
        val baseline = height - padding
        paint.color = 0xdfffffff.toInt()
        canvas.drawRect(0f, baseline - attributionPaint.textSize - padding, textWidth + padding * 2, height.toFloat(), paint)
        canvas.drawText(text, padding, baseline, attributionPaint)
    }

    companion object {
        private const val TILE_SIZE = 256
        private const val CACHE_TTL_MS = 7L * 24L * 60L * 60L * 1000L
        private const val USER_AGENT = "StrechoStav-Sketch-Android/2.2 (interactive roof drawing map)"
    }
}
