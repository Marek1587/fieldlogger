package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

data class GeoPoint(var lat: Double, var lon: Double)
data class LocalPoint(var x: Double, var y: Double)

enum class RoofShape(val label: String) {
    AUTO("Automaticky podľa čiar"),
    FLAT("Plochá"),
    GABLE("Sedlová"),
    HIP("Valbová / stanová"),
    SHED("Pultová");

    companion object {
        fun from(value: String?): RoofShape =
            entries.firstOrNull { it.name == value } ?: AUTO
    }
}

enum class LineType(val label: String, val color: Int) {
    RIDGE("Hrebeň", 0xffd52222.toInt()),
    VALLEY("Úžľabie", 0xff1f60d4.toInt()),
    HIP("Nárožie", 0xff8a2bb8.toInt()),
    ATTIC("Atika", 0xffd77a00.toInt()),
    PULT("Pultová hrana", 0xff795548.toInt()),
    WALL_END("Pri murive", 0xff666666.toInt()),
    EAVE("Odkvap", 0xff15924a.toInt()),
    GABLE("Štít", 0xff222222.toInt());

    companion object {
        fun from(value: String?): LineType =
            entries.firstOrNull { it.name == value } ?: RIDGE
    }
}

enum class ObjectType(val label: String) {
    CHIMNEY("Komín"),
    ROOF_WINDOW("Strešné okno"),
    HATCH("Výlez"),
    VENT("Prestup / vetranie"),
    DRAIN("Strešná vpusť"),
    DOWNSPOUT("Zvodová rúra"),
    HEIGHT_MARK("Výšková kóta"),
    SLOPE_MARK("Sklon");

    companion object {
        fun from(value: String?): ObjectType =
            entries.firstOrNull { it.name == value } ?: CHIMNEY
    }
}

data class RoofLine(
    val id: String = UUID.randomUUID().toString(),
    var type: LineType,
    var start: GeoPoint,
    var end: GeoPoint,
    var note: String = ""
)

data class RoofObject(
    val id: String = UUID.randomUUID().toString(),
    var type: ObjectType,
    var center: GeoPoint,
    var widthMm: Double = 0.0,
    var heightMm: Double = 0.0,
    var diameterMm: Double = 0.0,
    var value: Double = 0.0,
    var rotationDeg: Double = 0.0,
    var note: String = ""
)

data class RoofProject(
    val id: String = UUID.randomUUID().toString(),
    var name: String = "Nová strecha",
    var customer: String = "",
    var address: String = "",
    var centerLat: Double = 49.0663,
    var centerLon: Double = 18.9236,
    var zoom: Int = 19,
    var slopeDeg: Double = 10.0,
    var wallHeightM: Double = 3.0,
    var shape: RoofShape = RoofShape.AUTO,
    var mapType: String = "ZBGIS_ORTHO",
    var lastGoogleMapType: String = "ZBGIS_ORTHO",
    var underlayUri: String = "",
    var underlayMime: String = "",
    var underlayName: String = "",
    var underlayOriginLat: Double = 49.0663,
    var underlayOriginLon: Double = 18.9236,
    var underlayMetersPerPixel: Double = 0.01,
    var underlayZoom: Double = 1.0,
    var underlayCenterX: Double = -1.0,
    var underlayCenterY: Double = -1.0,
    var polygon: MutableList<GeoPoint> = mutableListOf(),
    var lines: MutableList<RoofLine> = mutableListOf(),
    var objects: MutableList<RoofObject> = mutableListOf(),
    var edgeTypes: MutableMap<Int, LineType> = mutableMapOf(),
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis()
)

object ProjectJson {
    fun encode(project: RoofProject): String = JSONObject().apply {
        put("schema", "strechostav-sketch-project-2")
        put("id", project.id)
        put("name", project.name)
        put("customer", project.customer)
        put("address", project.address)
        put("center_lat", project.centerLat)
        put("center_lon", project.centerLon)
        put("zoom", project.zoom)
        put("slope_deg", project.slopeDeg)
        put("wall_height_m", project.wallHeightM)
        put("roof_shape", project.shape.name)
        put("map_type", project.mapType)
        put("last_google_map_type", project.lastGoogleMapType)
        put("underlay_uri", project.underlayUri)
        put("underlay_mime", project.underlayMime)
        put("underlay_name", project.underlayName)
        put("underlay_origin_lat", project.underlayOriginLat)
        put("underlay_origin_lon", project.underlayOriginLon)
        put("underlay_meters_per_pixel", project.underlayMetersPerPixel)
        put("underlay_zoom", project.underlayZoom)
        put("underlay_center_x", project.underlayCenterX)
        put("underlay_center_y", project.underlayCenterY)
        put("created_at", project.createdAt)
        put("updated_at", project.updatedAt)
        put("polygon", JSONArray().also { array ->
            project.polygon.forEach { array.put(pointJson(it)) }
        })
        put("lines", JSONArray().also { array ->
            project.lines.forEach { line ->
                array.put(JSONObject().apply {
                    put("id", line.id)
                    put("type", line.type.name)
                    put("start", pointJson(line.start))
                    put("end", pointJson(line.end))
                    put("note", line.note)
                })
            }
        })
        put("objects", JSONArray().also { array ->
            project.objects.forEach { item ->
                array.put(JSONObject().apply {
                    put("id", item.id)
                    put("type", item.type.name)
                    put("center", pointJson(item.center))
                    put("width_mm", item.widthMm)
                    put("height_mm", item.heightMm)
                    put("diameter_mm", item.diameterMm)
                    put("value", item.value)
                    put("rotation_deg", item.rotationDeg)
                    put("note", item.note)
                })
            }
        })
        put("edge_types", JSONObject().also { edges ->
            project.edgeTypes.forEach { (index, type) -> edges.put(index.toString(), type.name) }
        })
        put("summary", ProjectSummary.calculate(project).toJson())
    }.toString(2)

    fun decode(text: String): RoofProject {
        val root = JSONObject(text)
        val project = RoofProject(
            id = root.optString("id").ifBlank { UUID.randomUUID().toString() },
            name = root.optString("name", "Strecha"),
            customer = root.optString("customer"),
            address = root.optString("address"),
            centerLat = root.optDouble("center_lat", 49.0663),
            centerLon = root.optDouble("center_lon", 18.9236),
            zoom = root.optInt("zoom", 19).coerceIn(3, 21),
            slopeDeg = root.optDouble("slope_deg", 10.0).coerceIn(0.0, 75.0),
            wallHeightM = root.optDouble("wall_height_m", 3.0).coerceIn(0.5, 100.0),
            shape = RoofShape.from(root.optString("roof_shape")),
            mapType = root.optString("map_type", "ZBGIS_ORTHO").let {
                when (it.uppercase()) {
                    "SATELLITE", "HYBRID" -> "ZBGIS_ORTHO"
                    "NORMAL" -> "OSM"
                    "TERRAIN" -> "OSM_TERRAIN"
                    else -> it
                }
            },
            lastGoogleMapType = root.optString("last_google_map_type", root.optString("map_type", "ZBGIS_ORTHO")).let {
                when (it.uppercase()) {
                    "DOCUMENT", "SATELLITE", "HYBRID" -> "ZBGIS_ORTHO"
                    "NORMAL" -> "OSM"
                    "TERRAIN" -> "OSM_TERRAIN"
                    else -> it
                }
            },
            underlayUri = root.optString("underlay_uri"),
            underlayMime = root.optString("underlay_mime"),
            underlayName = root.optString("underlay_name"),
            underlayOriginLat = root.optDouble("underlay_origin_lat", root.optDouble("center_lat", 49.0663)),
            underlayOriginLon = root.optDouble("underlay_origin_lon", root.optDouble("center_lon", 18.9236)),
            underlayMetersPerPixel = root.optDouble("underlay_meters_per_pixel", 0.01).coerceIn(0.00001, 1000.0),
            underlayZoom = root.optDouble("underlay_zoom", 1.0).coerceIn(0.05, 100.0),
            underlayCenterX = root.optDouble("underlay_center_x", -1.0),
            underlayCenterY = root.optDouble("underlay_center_y", -1.0),
            createdAt = root.optLong("created_at", System.currentTimeMillis()),
            updatedAt = root.optLong("updated_at", System.currentTimeMillis())
        )
        val polygon = root.optJSONArray("polygon") ?: JSONArray()
        repeat(polygon.length()) { index ->
            project.polygon += point(polygon.getJSONObject(index))
        }
        val lines = root.optJSONArray("lines") ?: JSONArray()
        repeat(lines.length()) { index ->
            val item = lines.getJSONObject(index)
            project.lines += RoofLine(
                id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = LineType.from(item.optString("type")),
                start = point(item.getJSONObject("start")),
                end = point(item.getJSONObject("end")),
                note = item.optString("note")
            )
        }
        val objects = root.optJSONArray("objects") ?: JSONArray()
        repeat(objects.length()) { index ->
            val item = objects.getJSONObject(index)
            project.objects += RoofObject(
                id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                type = ObjectType.from(item.optString("type")),
                center = point(item.getJSONObject("center")),
                widthMm = item.optDouble("width_mm"),
                heightMm = item.optDouble("height_mm"),
                diameterMm = item.optDouble("diameter_mm"),
                value = item.optDouble("value"),
                rotationDeg = item.optDouble("rotation_deg"),
                note = item.optString("note")
            )
        }
        val edges = root.optJSONObject("edge_types")
        edges?.keys()?.forEach { key ->
            key.toIntOrNull()?.let { project.edgeTypes[it] = LineType.from(edges.optString(key)) }
        }
        return project
    }

    private fun pointJson(point: GeoPoint) =
        JSONObject().put("lat", point.lat).put("lon", point.lon)

    private fun point(value: JSONObject) =
        GeoPoint(value.optDouble("lat"), value.optDouble("lon", value.optDouble("lng")))
}

data class ProjectTotals(
    val footprintAreaM2: Double,
    val roofAreaM2: Double,
    val perimeterM: Double,
    val ridgeM: Double,
    val valleyM: Double,
    val hipM: Double,
    val atticM: Double,
    val pultM: Double,
    val wallEndM: Double,
    val eaveM: Double,
    val gableM: Double,
    val chimneys: Int,
    val roofWindows: Int,
    val hatches: Int,
    val vents: Int,
    val drains: Int,
    val downspouts: Int,
    val heightMarks: Int,
    val slopeMarks: Int
) {
    fun toJson() = JSONObject().apply {
        put("footprint_area_m2", footprintAreaM2)
        put("roof_area_m2", roofAreaM2)
        put("perimeter_m", perimeterM)
        put("ridge_m", ridgeM)
        put("valley_m", valleyM)
        put("hip_m", hipM)
        put("attic_m", atticM)
        put("pult_m", pultM)
        put("wall_end_m", wallEndM)
        put("eave_m", eaveM)
        put("gable_m", gableM)
        put("chimneys", chimneys)
        put("roof_windows", roofWindows)
        put("hatches", hatches)
        put("vents", vents)
        put("drains", drains)
        put("downspouts", downspouts)
        put("height_marks", heightMarks)
        put("slope_marks", slopeMarks)
    }
}

object ProjectSummary {
    fun calculate(project: RoofProject): ProjectTotals {
        val footprint = Geometry.areaM2(project.polygon)
        val slopeFactor = if (project.slopeDeg in 0.01..75.0) {
            1.0 / cos(Math.toRadians(project.slopeDeg))
        } else 1.0
        var ridge = 0.0
        var valley = 0.0
        var hip = 0.0
        var attic = 0.0
        var pult = 0.0
        var wall = 0.0
        var eave = 0.0
        var gable = 0.0
        project.lines.forEach { line ->
            val plan = Geometry.distanceM(line.start, line.end)
            val actual = if (line.type in listOf(LineType.VALLEY, LineType.HIP)) {
                plan * slopeFactor
            } else plan
            when (line.type) {
                LineType.RIDGE -> ridge += actual
                LineType.VALLEY -> valley += actual
                LineType.HIP -> hip += actual
                LineType.ATTIC -> attic += actual
                LineType.PULT -> pult += actual
                LineType.WALL_END -> wall += actual
                LineType.EAVE -> eave += actual
                LineType.GABLE -> gable += actual
            }
        }
        project.polygon.indices.forEach { index ->
            val next = (index + 1) % project.polygon.size
            val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
            when (project.edgeTypes[index] ?: LineType.EAVE) {
                LineType.ATTIC -> attic += length
                LineType.GABLE -> gable += length
                LineType.PULT -> pult += length
                LineType.WALL_END -> wall += length
                else -> eave += length
            }
        }
        fun count(type: ObjectType) = project.objects.count { it.type == type }
        return ProjectTotals(
            footprintAreaM2 = footprint,
            roofAreaM2 = footprint * slopeFactor,
            perimeterM = Geometry.perimeterM(project.polygon),
            ridgeM = ridge,
            valleyM = valley,
            hipM = hip,
            atticM = attic,
            pultM = pult,
            wallEndM = wall,
            eaveM = eave,
            gableM = gable,
            chimneys = count(ObjectType.CHIMNEY),
            roofWindows = count(ObjectType.ROOF_WINDOW),
            hatches = count(ObjectType.HATCH),
            vents = count(ObjectType.VENT),
            drains = count(ObjectType.DRAIN),
            downspouts = count(ObjectType.DOWNSPOUT),
            heightMarks = count(ObjectType.HEIGHT_MARK),
            slopeMarks = count(ObjectType.SLOPE_MARK)
        )
    }
}

object Geometry {
    private const val EARTH_R = 6_378_137.0

    fun centroid(points: List<GeoPoint>): GeoPoint {
        if (points.isEmpty()) return GeoPoint(49.0663, 18.9236)
        return GeoPoint(points.sumOf { it.lat } / points.size, points.sumOf { it.lon } / points.size)
    }

    fun toLocal(point: GeoPoint, origin: GeoPoint): LocalPoint {
        val x = Math.toRadians(point.lon - origin.lon) * EARTH_R * cos(Math.toRadians(origin.lat))
        val y = Math.toRadians(point.lat - origin.lat) * EARTH_R
        return LocalPoint(x, y)
    }

    fun toGeo(point: LocalPoint, origin: GeoPoint): GeoPoint {
        val lat = origin.lat + Math.toDegrees(point.y / EARTH_R)
        val lon = origin.lon + Math.toDegrees(point.x / (EARTH_R * cos(Math.toRadians(origin.lat))))
        return GeoPoint(lat, lon)
    }

    fun areaM2(points: List<GeoPoint>): Double {
        if (points.size < 3) return 0.0
        val origin = centroid(points)
        val local = points.map { toLocal(it, origin) }
        var sum = 0.0
        local.indices.forEach { index ->
            val next = (index + 1) % local.size
            sum += local[index].x * local[next].y - local[next].x * local[index].y
        }
        return abs(sum) / 2.0
    }

    fun perimeterM(points: List<GeoPoint>): Double {
        if (points.size < 2) return 0.0
        return points.indices.sumOf { index ->
            distanceM(points[index], points[(index + 1) % points.size])
        }
    }

    fun distanceM(a: GeoPoint, b: GeoPoint): Double {
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val value = sin(dLat / 2).pow(2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2).pow(2)
        return 6_371_008.8 * 2.0 * atan2(sqrt(value), sqrt(max(0.0, 1.0 - value)))
    }

    fun pointInPolygon(point: LocalPoint, polygon: List<LocalPoint>): Boolean {
        var inside = false
        if (polygon.size < 3) return false
        var previous = polygon.lastIndex
        polygon.indices.forEach { current ->
            val a = polygon[current]
            val b = polygon[previous]
            if ((a.y > point.y) != (b.y > point.y) &&
                point.x < (b.x - a.x) * (point.y - a.y) / ((b.y - a.y).takeIf { abs(it) > 1e-9 } ?: 1e-9) + a.x
            ) inside = !inside
            previous = current
        }
        return inside
    }

    fun distanceToSegment(point: LocalPoint, a: LocalPoint, b: LocalPoint): Double {
        val dx = b.x - a.x
        val dy = b.y - a.y
        if (abs(dx) + abs(dy) < 1e-9) return hypot(point.x - a.x, point.y - a.y)
        val t = (((point.x - a.x) * dx + (point.y - a.y) * dy) / (dx * dx + dy * dy))
            .coerceIn(0.0, 1.0)
        return hypot(point.x - (a.x + t * dx), point.y - (a.y + t * dy))
    }

    fun nearestDistanceToPolygon(point: GeoPoint, polygon: List<GeoPoint>): Double {
        if (polygon.size < 2) return Double.MAX_VALUE
        val local = polygon.map { toLocal(it, point) }
        if (pointInPolygon(LocalPoint(0.0, 0.0), local)) return 0.0
        return local.indices.minOf { index ->
            distanceToSegment(LocalPoint(0.0, 0.0), local[index], local[(index + 1) % local.size])
        }
    }

    fun regularize(points: List<GeoPoint>): MutableList<GeoPoint> {
        if (points.size < 3) return points.map { it.copy() }.toMutableList()
        val origin = centroid(points)
        val local = points.map { toLocal(it, origin) }
        val longest = local.indices.maxByOrNull { index ->
            val next = (index + 1) % local.size
            hypot(local[next].x - local[index].x, local[next].y - local[index].y)
        } ?: 0
        val nextLongest = (longest + 1) % local.size
        val base = atan2(
            local[nextLongest].y - local[longest].y,
            local[nextLongest].x - local[longest].x
        )
        val corrected = mutableListOf(local.first().copy())
        for (index in 0 until local.lastIndex) {
            val a = local[index]
            val b = local[index + 1]
            val length = hypot(b.x - a.x, b.y - a.y)
            val raw = atan2(b.y - a.y, b.x - a.x)
            val snapped = base + (kotlin.math.round((raw - base) / (PI / 4.0)) * (PI / 4.0))
            corrected += LocalPoint(
                corrected.last().x + cos(snapped) * length,
                corrected.last().y + sin(snapped) * length
            )
        }
        val closingRaw = local.first()
        val closingFrom = local.last()
        val closingLength = hypot(closingRaw.x - closingFrom.x, closingRaw.y - closingFrom.y)
        val closingAngleRaw = atan2(closingRaw.y - closingFrom.y, closingRaw.x - closingFrom.x)
        val closingAngle = base + (kotlin.math.round((closingAngleRaw - base) / (PI / 4.0)) * (PI / 4.0))
        val projectedEnd = LocalPoint(
            corrected.last().x + cos(closingAngle) * closingLength,
            corrected.last().y + sin(closingAngle) * closingLength
        )
        val errorX = projectedEnd.x - corrected.first().x
        val errorY = projectedEnd.y - corrected.first().y
        corrected.indices.forEach { index ->
            val share = index.toDouble() / corrected.size
            corrected[index].x -= errorX * share
            corrected[index].y -= errorY * share
        }
        return corrected.map { toGeo(it, origin) }.toMutableList()
    }

    fun worldX(lon: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        return (lon + 180.0) / 360.0 * scale
    }

    fun worldY(lat: Double, zoom: Int): Double {
        val safe = lat.coerceIn(-85.05112878, 85.05112878)
        val sinLat = sin(Math.toRadians(safe))
        val scale = 256.0 * (1 shl zoom)
        return (0.5 - ln((1 + sinLat) / (1 - sinLat)) / (4 * PI)) * scale
    }

    fun lonFromWorld(x: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        return x / scale * 360.0 - 180.0
    }

    fun latFromWorld(y: Double, zoom: Int): Double {
        val scale = 256.0 * (1 shl zoom)
        val n = PI - 2.0 * PI * y / scale
        return Math.toDegrees(atan2(0.5 * (kotlin.math.exp(n) - kotlin.math.exp(-n)), 1.0))
    }

    fun metersPerPixel(lat: Double, zoom: Int): Double =
        156543.03392 * cos(Math.toRadians(lat)) / (1 shl zoom)
}
