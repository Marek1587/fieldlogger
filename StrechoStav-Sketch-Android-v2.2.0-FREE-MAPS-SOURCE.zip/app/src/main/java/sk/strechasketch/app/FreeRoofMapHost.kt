package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.roundToInt

@SuppressLint("ViewConstructor")
class FreeRoofMapHost(
    context: Context,
    val project: RoofProject
) : FrameLayout(context) {
    val editor = RoofMapEditorView(context, project)
    var onStatusChanged: ((String) -> Unit)? = null

    private val tileView = RasterTileMapView(context, project)
    private val documentView = DocumentUnderlayView(context, project)
    private var documentMode = project.mapType == "DOCUMENT" && project.underlayUri.isNotBlank()
    private var zoomRemainder = 0f

    init {
        if (!documentMode) normalizeMapType(project.mapType)
        addView(tileView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(documentView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(editor, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        editor.onModeChanged = { updateGestureMode() }
        editor.onCameraRequested = { _, _ -> tileView.invalidate() }
        editor.onFitRequested = { points ->
            if (documentMode) documentView.fitDocument()
            else {
                editor.fitToPolygonLocally(points)
                tileView.invalidate()
            }
        }
        editor.onZoomRequested = ::zoomBy
        editor.onViewportChanged = { tileView.invalidate() }

        tileView.onStatusChanged = { onStatusChanged?.invoke(it) }
        documentView.onTransformChanged = { editor.invalidate() }
        documentView.onLoadStatus = { result ->
            result.onSuccess { onStatusChanged?.invoke(it) }
                .onFailure { onStatusChanged?.invoke("Výkres sa nepodarilo načítať: ${it.message}") }
        }

        if (documentMode) {
            showDocument(Uri.parse(project.underlayUri), project.underlayMime, project.underlayName, false)
        } else {
            showFreeMap(project.mapType)
        }
    }

    fun setMapType(type: String) = showFreeMap(type)

    fun showDocument(uri: Uri, mime: String, name: String, resetTransform: Boolean = true) {
        if (resetTransform || project.underlayUri != uri.toString()) {
            project.underlayOriginLat = project.centerLat
            project.underlayOriginLon = project.centerLon
            project.underlayCenterX = -1.0
            project.underlayCenterY = -1.0
            project.underlayZoom = 1.0
            project.underlayMetersPerPixel = 0.01
        }
        project.underlayUri = uri.toString()
        project.underlayMime = mime
        project.underlayName = name
        project.mapType = "DOCUMENT"
        documentMode = true
        editor.projectPointToScreen = documentView::projectToScreen
        editor.screenPointToProject = documentView::screenToProject
        updateVisibility()
        updateGestureMode()
        documentView.load(uri)
        editor.invalidate()
    }

    fun removeDocument() {
        project.underlayUri = ""
        project.underlayMime = ""
        project.underlayName = ""
        project.underlayCenterX = -1.0
        project.underlayCenterY = -1.0
        documentView.clearBitmap()
        showFreeMap(project.lastGoogleMapType)
    }

    fun isDocumentMode(): Boolean = documentMode

    fun zoomBy(steps: Float) {
        if (documentMode) {
            documentView.zoomBy(steps)
            return
        }
        zoomRemainder += steps
        val whole = when {
            abs(zoomRemainder) >= 0.75f -> zoomRemainder.roundToInt()
            else -> 0
        }
        if (whole == 0) return
        zoomRemainder -= whole
        val maxZoom = if (project.mapType == "OSM_TERRAIN") 17 else 21
        project.zoom = (project.zoom + whole).coerceIn(3, maxZoom)
        tileView.invalidate()
        editor.invalidate()
        onStatusChanged?.invoke("Priblíženie ${project.zoom}. Dlaždice sa automaticky doplnia.")
    }

    fun fitCurrent() {
        if (documentMode) documentView.fitDocument()
        else if (project.polygon.isNotEmpty()) editor.fitToPolygonLocally(project.polygon)
        tileView.invalidate()
        editor.invalidate()
    }

    fun onCreate(state: Bundle?) = Unit
    fun onResume() {
        tileView.invalidate()
    }
    fun onPause() = Unit
    fun onDestroy() {
        documentView.clearBitmap()
        tileView.shutdown()
    }
    fun onLowMemory() = tileView.clearMemoryCache()

    private fun showFreeMap(type: String) {
        val normalized = normalizeMapType(type)
        project.mapType = normalized
        project.lastGoogleMapType = normalized
        if (normalized == "OSM_TERRAIN") project.zoom = project.zoom.coerceAtMost(17)
        documentMode = false
        editor.projectPointToScreen = null
        editor.screenPointToProject = null
        updateVisibility()
        updateGestureMode()
        tileView.invalidate()
        editor.invalidate()
        val label = when (normalized) {
            "ZBGIS_ORTHO" -> "ZBGIS ortofoto"
            "OSM_TERRAIN" -> "OSM terén"
            else -> "OpenStreetMap"
        }
        onStatusChanged?.invoke("Načítavam $label. Posun jedným prstom, zoom dvoma prstami alebo +/−.")
    }

    private fun normalizeMapType(type: String): String = when (type.uppercase()) {
        "OSM", "NORMAL" -> "OSM"
        "OSM_TERRAIN", "TERRAIN" -> "OSM_TERRAIN"
        else -> "ZBGIS_ORTHO"
    }

    private fun updateGestureMode() {
        documentView.isEnabled = documentMode && editor.mode == EditorMode.PAN
    }

    private fun updateVisibility() {
        tileView.visibility = if (documentMode) View.GONE else View.VISIBLE
        documentView.visibility = if (documentMode) View.VISIBLE else View.GONE
    }
}
