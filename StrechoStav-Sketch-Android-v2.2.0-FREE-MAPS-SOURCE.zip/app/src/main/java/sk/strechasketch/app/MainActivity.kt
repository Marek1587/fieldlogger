package sk.strechasketch.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

@SuppressLint("SetTextI18n")
class MainActivity : Activity() {
    private lateinit var store: ProjectStore
    private var currentProject: RoofProject? = null
    private var editorView: RoofMapEditorView? = null
    private var editorStatus: TextView? = null
    private var editorMetrics: TextView? = null
    private var active3DView: Roof3DView? = null
    private var activeMapHost: FreeRoofMapHost? = null
    private var screen = Screen.HOME
    private var pendingExport: ByteArray? = null
    private var pendingExportName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BRAND_DARK
        window.navigationBarColor = BRAND_DARK
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false)
        store = ProjectStore(this)
        showHome()
    }

    override fun onPause() {
        active3DView?.onPause()
        activeMapHost?.onPause()
        currentProject?.let(store::save)
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        active3DView?.onResume()
        activeMapHost?.onResume()
    }

    override fun onLowMemory() {
        activeMapHost?.onLowMemory()
        super.onLowMemory()
    }

    override fun onDestroy() {
        activeMapHost?.onDestroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when (screen) {
            Screen.HOME -> super.onBackPressed()
            Screen.EDITOR -> showHome()
            Screen.THREE_D, Screen.SUMMARY -> currentProject?.let(::showEditor) ?: showHome()
        }
    }

    private fun showHome() {
        screen = Screen.HOME
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        editorView = null
        val root = verticalRoot()
        root.addView(appBar("StrechoStav Sketch", null))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            background = rounded(Color.rgb(237, 248, 237), 0f, stroke = Color.rgb(200, 223, 202))
        }
        hero.addView(label("Strecha od mapy po 3D model", 23f, true, INK))
        hero.addView(label(
            "Vyhľadajte stavbu, importujte alebo obkreslite obrys, doplňte klampiarske prvky a exportujte technický nákres.",
            14f, false, MUTED
        ).apply { setPadding(0, dp(7), 0, dp(12)) })
        val heroActions = row()
        heroActions.addView(actionButton("Nový projekt", BRAND) { showNewProjectDialog() })
        heroActions.addView(actionButton("Import JSON", Color.rgb(56, 76, 88)) { openJsonImport() })
        hero.addView(heroActions)
        root.addView(hero)

        val title = label("Uložené projekty", 18f, true, INK).apply {
            setPadding(dp(18), dp(18), dp(18), dp(8))
        }
        root.addView(title)
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(28))
        }
        val projects = store.list()
        if (projects.isEmpty()) {
            list.addView(label(
                "Zatiaľ nemáte žiadny projekt. Začnite tlačidlom „Nový projekt“.",
                16f, false, MUTED
            ).apply {
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(70), dp(24), dp(70))
            })
        } else {
            projects.forEach { list.addView(projectCard(it)) }
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun projectCard(project: RoofProject): View {
        val totals = ProjectSummary.calculate(project)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(Color.WHITE, 14f, stroke = Color.rgb(209, 220, 211))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, dp(11)) }
            addView(label(project.name, 19f, true, INK))
            addView(label(
                buildString {
                    if (project.customer.isNotBlank()) append(project.customer).append(" • ")
                    append(project.address.ifBlank { "Bez adresy" })
                    append("\n")
                    append("${format1(totals.footprintAreaM2)} m² • ${project.shape.label} • ${format1(project.slopeDeg)}°")
                    append(" • ")
                    append(SimpleDateFormat("d. M. yyyy HH:mm", Locale("sk", "SK")).format(Date(project.updatedAt)))
                },
                13f, false, MUTED
            ).apply { setPadding(0, dp(5), 0, dp(10)) })
            addView(row().apply {
                addView(actionButton("Otvoriť", BRAND) {
                    currentProject = project
                    showEditor(project)
                })
                addView(actionButton("3D", Color.rgb(164, 48, 35)) {
                    currentProject = project
                    show3D(project)
                })
                addView(actionButton("Kópia", Color.rgb(62, 83, 96)) {
                    store.duplicate(project)
                    showHome()
                })
                addView(actionButton("Odstrániť", Color.rgb(150, 50, 45)) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Odstrániť projekt?")
                        .setMessage(project.name)
                        .setNegativeButton("Zrušiť", null)
                        .setPositiveButton("Odstrániť") { _, _ ->
                            store.delete(project.id)
                            showHome()
                        }.show()
                })
            })
        }
    }

    private fun showNewProjectDialog() {
        val fields = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = edit("Názov projektu", "Strecha ${SimpleDateFormat("d.M.yyyy", Locale("sk", "SK")).format(Date())}")
        val customer = edit("Zákazník", "")
        val address = edit("Adresa alebo GPS", "")
        fields.addView(name)
        fields.addView(customer)
        fields.addView(address)
        AlertDialog.Builder(this)
            .setTitle("Nový projekt")
            .setView(fields)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Vytvoriť") { _, _ ->
                val project = RoofProject(
                    name = name.text.toString().trim().ifBlank { "Nová strecha" },
                    customer = customer.text.toString().trim(),
                    address = address.text.toString().trim()
                )
                store.save(project)
                currentProject = project
                showEditor(project)
            }.show()
    }

    private fun showEditor(project: RoofProject) {
        screen = Screen.EDITOR
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar(project.name) { showHome() }.apply {
            addView(compactButton("3D") { show3D(project) })
            addView(compactButton("Výkaz") { showSummary(project) })
        })

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(7), dp(8), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        val search = edit("Adresa alebo 49.123, 18.456", project.address).apply {
            setSingleLine()
            setPadding(dp(12), 0, dp(8), 0)
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(46), 1f))
        searchRow.addView(compactButton("Nájsť") { resolveLocation(search.text.toString(), project) })
        searchRow.addView(compactButton("Budova") { importNearestBuilding(project) })
        searchRow.addView(compactButton("GPS") { useDeviceLocation() })
        root.addView(searchRow)

        val settings = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(246, 248, 246))
        }
        val settingsRow = row().apply { setPadding(dp(8), dp(6), dp(8), dp(6)) }
        settingsRow.addView(label("Sklon °", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val slope = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(format1(project.slopeDeg))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(slope, LinearLayout.LayoutParams(dp(72), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        val shapeSpinner = Spinner(this)
        shapeSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            RoofShape.entries.map { it.label }
        )
        shapeSpinner.setSelection(RoofShape.entries.indexOf(project.shape))
        settingsRow.addView(shapeSpinner, LinearLayout.LayoutParams(dp(170), dp(44)))
        settingsRow.addView(label("Steny m", 13f, true, INK).apply { gravity = Gravity.CENTER_VERTICAL })
        val wallHeight = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(format1(project.wallHeightM))
            gravity = Gravity.CENTER
            background = rounded(Color.WHITE, 8f, stroke = Color.rgb(190, 205, 191))
        }
        settingsRow.addView(wallHeight, LinearLayout.LayoutParams(dp(76), dp(42)).apply { setMargins(dp(5), 0, dp(10), 0) })
        settings.addView(settingsRow)
        root.addView(settings)

        val tools = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(30, 62, 40))
        }
        val toolRow = row().apply { setPadding(dp(7), dp(5), dp(7), dp(5)) }
        tools.addView(toolRow)
        root.addView(tools)

        val mapFrame = FrameLayout(this)
        val mapHost = FreeRoofMapHost(this, project)
        activeMapHost = mapHost
        val map = mapHost.editor
        editorView = map
        mapFrame.addView(mapHost, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val zoomControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), dp(6), 0)
            addView(mapControlButton("+") { mapHost.zoomBy(1f) })
            addView(mapControlButton("−") { mapHost.zoomBy(-1f) })
            addView(mapControlButton("Celok") { mapHost.fitCurrent() })
        }
        mapFrame.addView(
            zoomControls,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        )
        root.addView(mapFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun tool(text: String, click: () -> Unit) {
            toolRow.addView(actionButton(text, Color.rgb(49, 93, 60), click))
        }
        tool("ZBGIS ortofoto") { mapHost.setMapType("ZBGIS_ORTHO"); store.save(project) }
        tool("OSM mapa") { mapHost.setMapType("OSM"); store.save(project) }
        tool("OSM terén") { mapHost.setMapType("OSM_TERRAIN"); store.save(project) }
        tool("PDF/JPG") {
            if (project.underlayUri.isBlank()) openUnderlayImport()
            else {
                mapHost.showDocument(Uri.parse(project.underlayUri), project.underlayMime, project.underlayName, false)
                store.save(project)
            }
        }
        tool("Nový podklad") { openUnderlayImport() }
        tool("Posun") { map.setMode(EditorMode.PAN) }
        tool("Obrys prstom") { map.setMode(EditorMode.DRAW_POLYGON) }
        tool("Bod") { map.setMode(EditorMode.ADD_VERTEX) }
        tool("Editovať") { map.setMode(EditorMode.EDIT) }
        tool("Hrebeň") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.RIDGE) }
        tool("Úžľabie") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.VALLEY) }
        tool("Nárožie") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.HIP) }
        tool("Atika") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.ATTIC) }
        tool("Pult") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.PULT) }
        tool("Pri murive") { map.setMode(EditorMode.ADD_LINE, lineType = LineType.WALL_END) }
        tool("Komín") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.CHIMNEY) }
        tool("Okno") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.ROOF_WINDOW) }
        tool("Výlez") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.HATCH) }
        tool("Prestup") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.VENT) }
        tool("Vpusť") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.DRAIN) }
        tool("Zvod") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.DOWNSPOUT) }
        tool("Výška") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.HEIGHT_MARK) }
        tool("Sklon") { map.setMode(EditorMode.ADD_OBJECT, objectType = ObjectType.SLOPE_MARK) }

        editorStatus = label("Posúvajte mapu alebo vyhľadajte adresu.", 12f, false, MUTED).apply {
            setPadding(dp(10), dp(5), dp(10), dp(4))
            setBackgroundColor(Color.WHITE)
        }
        editorMetrics = label("", 12f, true, INK).apply {
            setPadding(dp(10), dp(3), dp(10), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        root.addView(editorStatus)
        root.addView(editorMetrics)

        val actions = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.rgb(238, 243, 238))
        }
        val actionRow = row().apply { setPadding(dp(7), dp(6), dp(7), dp(7)) }
        actionRow.addView(actionButton("Uzavrieť", BRAND) { map.finishPolygon() })
        actionRow.addView(actionButton("Skorigovať", BRAND) { map.correctGeometry() })
        actionRow.addView(actionButton("Typ hrany", Color.rgb(67, 91, 105)) { map.cycleSelectedEdgeType() })
        actionRow.addView(actionButton("Rozmer hrany", Color.rgb(67, 91, 105)) {
            showEdgeLengthDialog(map, mapHost)
        })
        actionRow.addView(actionButton("Späť úpravu", Color.rgb(67, 91, 105)) { map.undo() })
        actionRow.addView(actionButton("Odstrániť prvok", Color.rgb(151, 54, 46)) { map.deleteSelection() })
        actionRow.addView(actionButton("Vyčistiť", Color.rgb(151, 54, 46)) {
            AlertDialog.Builder(this)
                .setTitle("Vyčistiť celý nákres?")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Vyčistiť") { _, _ -> map.clearDrawing() }
                .show()
        })
        actionRow.addView(actionButton("Uložiť", BRAND) {
            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
            store.save(project)
            toast("Projekt uložený.")
        })
        actions.addView(actionRow)
        root.addView(actions)

        map.onProjectChanged = {
            updateEditorSettings(project, slope, wallHeight, shapeSpinner)
            store.save(project)
            refreshEditorMetrics(project)
        }
        map.onStatusChanged = { editorStatus?.text = it }
        mapHost.onStatusChanged = { editorStatus?.text = it }
        slope.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                project.slopeDeg = slope.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 75.0) ?: project.slopeDeg
                store.save(project)
                refreshEditorMetrics(project)
            }
        }
        wallHeight.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                project.wallHeightM = wallHeight.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.5, 100.0) ?: project.wallHeightM
                store.save(project)
            }
        }
        mapHost.onResume()
        shapeSpinner.onItemSelectedListener = simpleSelection {
            project.shape = RoofShape.entries[shapeSpinner.selectedItemPosition]
            store.save(project)
        }
        refreshEditorMetrics(project)
        setContentView(root)
    }

    private fun updateEditorSettings(project: RoofProject, slope: EditText, wallHeight: EditText, shape: Spinner) {
        project.slopeDeg = slope.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.0, 75.0) ?: project.slopeDeg
        project.wallHeightM = wallHeight.text.toString().replace(',', '.').toDoubleOrNull()?.coerceIn(0.5, 100.0) ?: project.wallHeightM
        project.shape = RoofShape.entries[shape.selectedItemPosition]
    }

    private fun refreshEditorMetrics(project: RoofProject) {
        val totals = ProjectSummary.calculate(project)
        editorMetrics?.text = "Pôdorys ${format1(totals.footprintAreaM2)} m²  •  strecha ${format1(totals.roofAreaM2)} m²  •  obvod ${format1(totals.perimeterM)} m  •  ${project.polygon.size} bodov"
    }

    private fun resolveLocation(input: String, project: RoofProject) {
        val text = input.trim()
        if (text.isBlank()) {
            toast("Zadajte adresu alebo GPS súradnice.")
            return
        }
        parseCoordinates(text)?.let { point ->
            project.address = "${point.lat}, ${point.lon}"
            editorView?.setCenter(point)
            store.save(project)
            return
        }
        val loading = loadingDialog("Hľadám adresu…")
        GeoServices.geocode(text) { result ->
            loading.dismiss()
            result.onSuccess { place ->
                project.address = place.displayName
                editorView?.setCenter(place.point)
                store.save(project)
                editorStatus?.text = "Adresa nájdená: ${place.displayName}"
            }.onFailure { toast(it.message ?: "Adresu sa nepodarilo nájsť.") }
        }
    }

    private fun importNearestBuilding(project: RoofProject) {
        val center = GeoPoint(project.centerLat, project.centerLon)
        val loading = loadingDialog("Hľadám obrys budovy v OpenStreetMap…")
        GeoServices.nearestBuilding(center) { result ->
            loading.dismiss()
            result.onSuccess { building ->
                val details = buildString {
                    append("Plocha: ${format1(building.areaM2)} m²\n")
                    append("Vzdialenosť od stredu: ${format1(building.distanceM)} m\n")
                    append("OSM: ${building.buildingType} #${building.osmId}")
                    if (building.name.isNotBlank()) append("\n${building.name}")
                    if (project.polygon.isNotEmpty()) append("\n\nExistujúci nákres bude nahradený.")
                }
                AlertDialog.Builder(this)
                    .setTitle("Importovať najbližšiu budovu?")
                    .setMessage(details)
                    .setNegativeButton("Zrušiť", null)
                    .setPositiveButton("Importovať") { _, _ ->
                        editorView?.importPolygon(building.points)
                        store.save(project)
                    }.show()
            }.onFailure { toast(it.message ?: "Budova sa nenašla.") }
        }
    }

    private fun useDeviceLocation() {
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }
        moveToLastLocation()
    }

    private fun moveToLastLocation() {
        try {
            val manager = getSystemService(LOCATION_SERVICE) as LocationManager
            val location = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { provider ->
                    runCatching {
                        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        ) manager.getLastKnownLocation(provider) else null
                    }.getOrNull()
                }.maxByOrNull { it.time }
            if (location != null) {
                val point = GeoPoint(location.latitude, location.longitude)
                currentProject?.let {
                    it.address = "${point.lat}, ${point.lon}"
                    editorView?.setCenter(point, 20)
                    store.save(it)
                }
            } else {
                AlertDialog.Builder(this)
                    .setTitle("Poloha nie je dostupná")
                    .setMessage("Zapnite polohu v telefóne alebo zadajte GPS súradnice ručne.")
                    .setNegativeButton("Zavrieť", null)
                    .setPositiveButton("Nastavenia") { _, _ ->
                        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }.show()
            }
        } catch (error: Exception) {
            toast(error.message ?: "Polohu sa nepodarilo načítať.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_LOCATION && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            moveToLastLocation()
        }
    }

    private fun show3D(project: RoofProject) {
        if (project.polygon.size < 3) {
            toast("Najprv vytvorte uzavretý obrys strechy.")
            return
        }
        screen = Screen.THREE_D
        disposeActiveMap()
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("3D • ${project.name}") { showEditor(project) }.apply {
            addView(compactButton("Reset") { active3DView?.resetView() })
            addView(compactButton("Výkaz") { showSummary(project) })
        })
        val settings = row().apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            setBackgroundColor(Color.WHITE)
        }
        settings.addView(label("Tvar:", 13f, true, INK))
        val shape = Spinner(this)
        shape.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, RoofShape.entries.map { it.label })
        shape.setSelection(RoofShape.entries.indexOf(project.shape))
        settings.addView(shape, LinearLayout.LayoutParams(dp(190), dp(44)))
        settings.addView(label("Sklon ${format1(project.slopeDeg)}°  •  steny ${format1(project.wallHeightM)} m", 13f, true, INK))
        root.addView(settings)
        val view = Roof3DView(this)
        active3DView = view
        view.setProject(project)
        root.addView(view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(label(
            "Otočenie: jeden prst  •  priblíženie: dva prsty  •  reset: dvojité ťuknutie",
            13f, false, MUTED
        ).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(16))
            setBackgroundColor(Color.WHITE)
        })
        shape.onItemSelectedListener = simpleSelection {
            project.shape = RoofShape.entries[shape.selectedItemPosition]
            store.save(project)
            view.setProject(project)
        }
        setContentView(root)
        view.onResume()
    }

    private fun showSummary(project: RoofProject) {
        screen = Screen.SUMMARY
        disposeActiveMap()
        active3DView?.onPause()
        active3DView = null
        currentProject = project
        val root = verticalRoot()
        root.addView(appBar("Výkaz výmer") { showEditor(project) }.apply {
            addView(compactButton("3D") { show3D(project) })
        })
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(30))
        }
        val totals = ProjectSummary.calculate(project)
        content.addView(sectionTitle(project.name))
        content.addView(infoCard(listOf(
            "Adresa" to project.address.ifBlank { "—" },
            "3D režim strechy" to project.shape.label,
            "Sklon" to "${format1(project.slopeDeg)}°",
            "Výška stien" to "${format1(project.wallHeightM)} m",
            "Body obrysu" to project.polygon.size.toString()
        )))
        content.addView(sectionTitle("Výkaz výmer"))
        content.addView(infoCard(listOf(
            "Pôdorysná plocha" to "${format1(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${format1(totals.roofAreaM2)} m²",
            "Obvod" to "${format1(totals.perimeterM)} m",
            "Hrebeň" to "${format1(totals.ridgeM)} m",
            "Úžľabie" to "${format1(totals.valleyM)} m",
            "Nárožie" to "${format1(totals.hipM)} m",
            "Atika / pult / pri murive" to "${format1(totals.atticM)} / ${format1(totals.pultM)} / ${format1(totals.wallEndM)} m",
            "Odkvap / štít" to "${format1(totals.eaveM)} / ${format1(totals.gableM)} m",
            "Komíny / okná / výlezy" to "${totals.chimneys} / ${totals.roofWindows} / ${totals.hatches}",
            "Prestupy / vpuste / zvody" to "${totals.vents} / ${totals.drains} / ${totals.downspouts}",
            "Výšky / sklony" to "${totals.heightMarks} / ${totals.slopeMarks}"
        )))
        content.addView(label(
            "Geometria a výmery z ortofotomapy sú orientačné. Pred výrobou alebo realizáciou ich overte meraním na stavbe.",
            12f, false, Color.rgb(81, 90, 85)
        ).apply {
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(Color.rgb(241, 245, 241), 10f, stroke = Color.rgb(194, 205, 195))
        })
        content.addView(sectionTitle("Export projektu"))
        content.addView(row().apply {
            addView(actionButton("PDF nákres", BRAND) {
                exportFile("${safeName(project.name)}.pdf", "application/pdf", Exporters.pdf(project))
            })
            addView(actionButton("SVG nákres", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.svg", "image/svg+xml", Exporters.svg(project))
            })
            addView(actionButton("JSON projekt", Color.rgb(64, 84, 96)) {
                exportFile("${safeName(project.name)}.json", "application/json", Exporters.json(project))
            })
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun exportFile(name: String, mime: String, bytes: ByteArray) {
        pendingExport = bytes
        pendingExportName = name
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    private fun openJsonImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
        }
        startActivityForResult(intent, REQUEST_IMPORT_JSON)
    }

    private fun openUnderlayImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "image/jpeg", "image/png", "image/webp"))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, REQUEST_IMPORT_UNDERLAY)
    }

    private fun showEdgeLengthDialog(map: RoofMapEditorView, mapHost: FreeRoofMapHost) {
        val current = map.selectedEdgeLengthM()
        if (current == null) {
            toast("Najprv zvoľte Editovať a klepnite na obvodovú hranu.")
            return
        }
        val metres = NumberPicker(this).apply {
            minValue = 0
            maxValue = 4999
            value = current.toInt().coerceIn(minValue, maxValue)
            wrapSelectorWheel = false
        }
        val centimetres = NumberPicker(this).apply {
            minValue = 0
            maxValue = 99
            value = ((current - current.toInt()) * 100).roundToInt().coerceIn(0, 99)
            setFormatter { "%02d".format(it) }
        }
        val calibration = CheckBox(this).apply {
            text = "Kalibrovať celý PDF/JPG podklad podľa tejto hrany"
            isChecked = mapHost.isDocumentMode()
            visibility = if (mapHost.isDocumentMode()) View.VISIBLE else View.GONE
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(label("Nastavte metre a centimetre kolieskami:", 14f, false, MUTED))
            addView(row().apply {
                gravity = Gravity.CENTER
                addView(metres)
                addView(label("m", 17f, true, INK).apply { setPadding(dp(6), 0, dp(16), 0) })
                addView(centimetres)
                addView(label("cm", 17f, true, INK).apply { setPadding(dp(6), 0, 0, 0) })
            })
            addView(calibration)
        }
        AlertDialog.Builder(this)
            .setTitle("Rozmer vybranej hrany")
            .setMessage("Aktuálna dĺžka: ${format1(current)} m")
            .setView(content)
            .setNegativeButton("Zrušiť", null)
            .setPositiveButton("Použiť") { _, _ ->
                val target = metres.value + centimetres.value / 100.0
                if (map.setSelectedEdgeLength(target, mapHost.isDocumentMode() && calibration.isChecked)) {
                    currentProject?.let(store::save)
                    refreshEditorMetrics(map.project)
                } else toast("Zadajte dĺžku aspoň 0,05 m.")
            }
            .show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQUEST_EXPORT -> {
                val bytes = pendingExport ?: return
                runCatching {
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: error("Súbor sa nedá otvoriť na zápis.")
                }.onSuccess {
                    toast("Uložené: $pendingExportName")
                }.onFailure { toast(it.message ?: "Export zlyhal.") }
                pendingExport = null
            }
            REQUEST_IMPORT_JSON -> {
                runCatching {
                    val text = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: error("Súbor sa nedá prečítať.")
                    val imported = ProjectJson.decode(text)
                    imported.copy(
                        id = java.util.UUID.randomUUID().toString(),
                        name = "${imported.name} – import",
                        createdAt = System.currentTimeMillis(),
                        updatedAt = System.currentTimeMillis()
                    )
                }.onSuccess { project ->
                    store.save(project)
                    currentProject = project
                    showEditor(project)
                }.onFailure { toast("Neplatný projekt: ${it.message}") }
            }
            REQUEST_IMPORT_UNDERLAY -> {
                val project = currentProject ?: return
                runCatching {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val mime = contentResolver.getType(uri).orEmpty()
                val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) cursor.getString(0) else null
                } ?: uri.lastPathSegment.orEmpty().ifBlank { "Podklad" }
                project.underlayUri = uri.toString()
                project.underlayMime = mime
                project.underlayName = name
                activeMapHost?.showDocument(uri, mime, name, true)
                store.save(project)
                editorStatus?.text = "Načítavam podklad $name…"
            }
        }
    }

    private fun appBar(title: String, back: (() -> Unit)?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(10), dp(8), dp(8), dp(8))
        setBackgroundColor(BRAND_DARK)
        if (back != null) addView(compactButton("‹ Späť", back))
        addView(label(title, 20f, true, Color.WHITE), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    private fun verticalRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(PAPER)
        if (Build.VERSION.SDK_INT >= 30) {
            setOnApplyWindowInsetsListener { view, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                view.setPadding(0, bars.top, 0, bars.bottom)
                insets
            }
            requestApplyInsets()
        } else {
            fitsSystemWindows = true
        }
    }

    private fun disposeActiveMap() {
        activeMapHost?.onPause()
        activeMapHost?.onDestroy()
        activeMapHost = null
    }

    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun actionButton(text: String, color: Int, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 13f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(color, 9f)
        setPadding(dp(12), 0, dp(12), 0)
        minHeight = dp(42)
        minWidth = 0
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply {
            setMargins(0, 0, dp(7), 0)
        }
    }

    private fun compactButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 12f
        background = rounded(Color.rgb(51, 103, 65), 8f, stroke = Color.rgb(117, 156, 126))
        setPadding(dp(9), 0, dp(9), 0)
        minWidth = 0
        minHeight = dp(38)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)).apply {
            setMargins(0, 0, dp(6), 0)
        }
    }

    private fun mapControlButton(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = if (text.length == 1) 20f else 10f
        setTypeface(typeface, Typeface.BOLD)
        background = rounded(Color.rgb(31, 89, 48), 8f, stroke = Color.WHITE)
        minWidth = 0
        minHeight = 0
        setPadding(dp(7), 0, dp(7), 0)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(54), dp(42)).apply {
            setMargins(0, 0, 0, dp(5))
        }
    }

    private fun label(text: String, size: Float, bold: Boolean, color: Int) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.12f)
    }

    private fun edit(hint: String, value: String) = EditText(this).apply {
        this.hint = hint
        setText(value)
        textSize = 15f
        setPadding(dp(10), dp(7), dp(10), dp(7))
        background = rounded(Color.WHITE, 8f, stroke = Color.rgb(194, 205, 195))
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
            setMargins(0, 0, 0, dp(9))
        }
    }

    private fun sectionTitle(text: String) = label(text, 18f, true, INK).apply {
        setPadding(0, dp(12), 0, dp(8))
    }

    private fun infoCard(rows: List<Pair<String, String>>) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(Color.WHITE, 12f, stroke = Color.rgb(211, 220, 212))
        rows.forEach { (key, value) ->
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
                setPadding(0, dp(7), 0, dp(7))
                addView(label(key, 13f, false, MUTED), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.46f))
                addView(label(value, 13f, true, INK).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.54f))
            })
        }
    }

    private fun rounded(fill: Int, radiusDp: Float, stroke: Int? = null) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = dp(radiusDp.roundToInt()).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun loadingDialog(message: String): AlertDialog = AlertDialog.Builder(this)
        .setView(label(message, 16f, true, INK).apply { setPadding(dp(28), dp(26), dp(28), dp(26)) })
        .setCancelable(false)
        .create()
        .also { it.show() }

    private fun simpleSelection(block: () -> Unit) =
        object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) = block()
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }

    private fun parseCoordinates(value: String): GeoPoint? {
        val match = Regex("""^\s*(-?\d{1,2}(?:[.,]\d+)?)\s*[,;\s]\s*(-?\d{1,3}(?:[.,]\d+)?)\s*$""").find(value)
            ?: return null
        val lat = match.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val lon = match.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return null
        return if (lat in -90.0..90.0 && lon in -180.0..180.0) GeoPoint(lat, lon) else null
    }

    private fun safeName(value: String) = value.trim()
        .replace(Regex("""[^\p{L}\p{N}._-]+"""), "_")
        .trim('_')
        .ifBlank { "strecha" }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun dp(value: Int) = (value * resources.displayMetrics.density).roundToInt()
    private fun format1(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)

    private enum class Screen { HOME, EDITOR, THREE_D, SUMMARY }

    companion object {
        private const val REQUEST_EXPORT = 4001
        private const val REQUEST_IMPORT_JSON = 4002
        private const val REQUEST_LOCATION = 4003
        private const val REQUEST_IMPORT_UNDERLAY = 4004
        private val BRAND = Color.rgb(35, 122, 53)
        private val BRAND_DARK = Color.rgb(22, 84, 38)
        private val INK = Color.rgb(23, 33, 43)
        private val MUTED = Color.rgb(91, 107, 99)
        private val PAPER = Color.rgb(244, 247, 244)
    }
}
