package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofWallProfileSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun `recess walls follow continuous roof underside instead of constant wall height`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 3.0),
            GraphNode("b", 10.0, 0.0, 3.0),
            GraphNode("c", 10.0, 8.0, 6.2),
            GraphNode("d", 0.0, 8.0, 6.2)
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                GraphEdge("ab", "a", "b", true, EdgeSemantic.EAVE, setOf("face")),
                GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
                GraphEdge("cd", "c", "d", true, EdgeSemantic.RIDGE, setOf("face")),
                GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
            ).associateBy { it.id },
            faces = mapOf(
                "face" to GraphFace(
                    "face", listOf("a", "b", "c", "d"),
                    listOf("ab", "bc", "cd", "da"), 80.0,
                    plane = RoofPlane(0.0, 0.4, 3.0)
                )
            )
        )
        val recessedWall = listOf(
            LocalPoint(1.0, 1.0), LocalPoint(9.0, 1.0),
            LocalPoint(9.0, 7.0), LocalPoint(1.0, 7.0),
            LocalPoint(1.0, 5.0), LocalPoint(3.0, 5.0),
            LocalPoint(3.0, 3.0), LocalPoint(1.0, 3.0)
        )

        val solution = RoofWallProfileSolver.solve(graph, recessedWall, 3.0)
        val recessSide = solution.segments.single { it.index == 5 }.samples

        assertEquals(4.82, recessSide.first().node.z, 1e-9)
        assertEquals(4.02, recessSide.last().node.z, 1e-9)
        assertTrue(solution.raisedSegmentCount >= 3)
    }

    @Test
    fun `ridge crossing adds one apex support without splitting the physical wall`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("m0", 5.0, 0.0),
            GraphNode("b", 10.0, 0.0), GraphNode("c", 10.0, 8.0),
            GraphNode("m1", 5.0, 8.0), GraphNode("d", 0.0, 8.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("am0", "a", "m0", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("m0b", "m0", "b", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("right")),
            GraphEdge("cm1", "c", "m1", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("m1d", "m1", "d", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("left")),
            GraphEdge("ridge", "m0", "m1", false, EdgeSemantic.RIDGE, setOf("left", "right"))
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin, nodes, edges,
            faces = mapOf(
                "left" to GraphFace(
                    "left", listOf("a", "m0", "m1", "d"),
                    listOf("am0", "ridge", "m1d", "da"), 40.0,
                    plane = RoofPlane(0.5, 0.0, 3.0)
                ),
                "right" to GraphFace(
                    "right", listOf("m0", "b", "c", "m1"),
                    listOf("m0b", "bc", "cm1", "ridge"), 40.0,
                    plane = RoofPlane(-0.5, 0.0, 8.0)
                )
            )
        )

        val result = RoofWallProfileSolver.solve(
            graph,
            listOf(LocalPoint(1.0, 4.0), LocalPoint(9.0, 4.0), LocalPoint(9.0, 5.0), LocalPoint(1.0, 5.0)),
            3.0
        )
        val crossing = result.segments.first().samples

        assertEquals(3, crossing.size)
        assertEquals(0.5, crossing[1].t, 1e-9)
        assertEquals(5.32, crossing[1].node.z, 1e-9)
    }
}
