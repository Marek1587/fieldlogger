package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Camera for deterministic CPU-rendered previews. No OpenGL context is used. */
data class RoofBitmapCamera(
    val yawDeg: Double = -35.0,
    val pitchDeg: Double = 28.0,
    val distance: Double = 4.8,
    val paddingFraction: Double = 0.09,
    /** Ignore the presentation board when fitting the camera; the board may be cropped. */
    val fitStructureOnly: Boolean = false
)

/**
 * Standalone static 3D renderer for lists, exports and PDF documents.
 *
 * It consumes the same validated [RoofMesh] snapshot as the interactive
 * OpenGL view, but projects and shades it entirely through Kotlin + Canvas.
 * Therefore it works without creating, opening or capturing a GLSurfaceView.
 */
object RoofBitmapRenderer {
    private data class Projected(
        val x: Double,
        val y: Double,
        val depth: Double,
        val inverseDepth: Float
    )
    private data class DrawTriangle(
        val a: Projected,
        val b: Projected,
        val c: Projected,
        val color: Int
    )

    fun render(
        project: RoofProject,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera = RoofBitmapCamera(),
        backgroundColor: Int = Color.rgb(246, 247, 247),
        showDimensions: Boolean = true
    ): Bitmap {
        require(width in 64..4096 && height in 64..4096) { "Neplatná veľkosť statického 3D obrázka." }
        return renderMesh(RoofMeshBuilder.build(project), width, height, camera, backgroundColor, showDimensions)
    }

    internal fun renderMesh(
        mesh: RoofMesh,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera,
        backgroundColor: Int,
        showDimensions: Boolean = true
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(backgroundColor)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(155, 160, 163)
            strokeWidth = max(0.9f, min(width, height) / 520f)
        }
        if (mesh.triangles.isEmpty()) {
            val message = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(78, 91, 82)
                textAlign = Paint.Align.CENTER
                textSize = min(width, height) * 0.045f
            }
            canvas.drawText("3D model nie je dostupný", width / 2f, height / 2f, message)
            canvas.drawRect(0.5f, 0.5f, width - 0.5f, height - 0.5f, frame)
            return bitmap
        }

        val yaw = Math.toRadians(camera.yawDeg)
        val pitch = Math.toRadians(camera.pitchDeg)
        fun rotate(x: Double, y: Double, z: Double): Triple<Double, Double, Double> {
            val yawX = x * cos(yaw) + z * sin(yaw)
            val yawZ = -x * sin(yaw) + z * cos(yaw)
            val pitchY = y * cos(pitch) - yawZ * sin(pitch)
            val pitchZ = y * sin(pitch) + yawZ * cos(pitch)
            return Triple(yawX, pitchY, pitchZ)
        }
        fun project(x: Double, y: Double, z: Double): Projected {
            val rotated = rotate(x, y, z)
            val cameraW = (camera.distance - rotated.third).coerceAtLeast(0.35)
            val perspective = camera.distance / cameraW
            return Projected(
                rotated.first * perspective,
                -rotated.second * perspective,
                rotated.third,
                (1.0 / cameraW).toFloat()
            )
        }

        val projectedVertices = mutableListOf<Projected>()
        var offset = 0
        while (offset + 2 < mesh.triangles.size) {
            projectedVertices += project(
                mesh.triangles[offset].toDouble(),
                mesh.triangles[offset + 1].toDouble(),
                mesh.triangles[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.edges.size) {
            projectedVertices += project(
                mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.internalEdges.size) {
            projectedVertices += project(
                mesh.internalEdges[offset].toDouble(),
                mesh.internalEdges[offset + 1].toDouble(),
                mesh.internalEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.wallEdges.size) {
            projectedVertices += project(
                mesh.wallEdges[offset].toDouble(),
                mesh.wallEdges[offset + 1].toDouble(),
                mesh.wallEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.padEdges.size) {
            projectedVertices += project(
                mesh.padEdges[offset].toDouble(), mesh.padEdges[offset + 1].toDouble(), mesh.padEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.logoEdges.size) {
            projectedVertices += project(
                mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        mesh.logoQuads.forEach { quad ->
            listOf(quad.topLeft, quad.topRight, quad.bottomRight, quad.bottomLeft).forEach { point ->
                projectedVertices += project(point.x.toDouble(), point.y.toDouble(), point.z.toDouble())
            }
        }
        val fitVertices = if (camera.fitStructureOnly) {
            buildList {
                var triangleOffset = 0
                while (triangleOffset + 2 < mesh.triangles.size) {
                    val materialIndex = triangleOffset / 3
                    val material = mesh.materials.getOrElse(materialIndex) { 0f }
                    // Material 2 is the presentation board. Walls, roof, parapets and
                    // technical objects remain part of the protected structure envelope.
                    if (material < 1.5f) {
                        add(project(
                            mesh.triangles[triangleOffset].toDouble(),
                            mesh.triangles[triangleOffset + 1].toDouble(),
                            mesh.triangles[triangleOffset + 2].toDouble()
                        ))
                    }
                    triangleOffset += 3
                }
            }.ifEmpty { projectedVertices }
        } else projectedVertices
        val minX = fitVertices.minOf { it.x }
        val maxX = fitVertices.maxOf { it.x }
        val minY = fitVertices.minOf { it.y }
        val maxY = fitVertices.maxOf { it.y }
        val padding = min(width, height) * camera.paddingFraction.coerceIn(0.02, 0.25)
        val availableWidth = (width - 2.0 * padding).coerceAtLeast(1.0)
        val availableHeight = (height - 2.0 * padding).coerceAtLeast(1.0)
        val scale = min(availableWidth / max(1e-6, maxX - minX), availableHeight / max(1e-6, maxY - minY))
        fun sx(point: Projected) = (width / 2.0 + (point.x - (minX + maxX) / 2.0) * scale).toFloat()
        fun sy(point: Projected) = (height / 2.0 + (point.y - (minY + maxY) / 2.0) * scale).toFloat()
        fun depthVertex(point: Projected) = DepthVertex(sx(point), sy(point), point.inverseDepth)

        // Same model-fixed 14:00 south-west sun as the OpenGL renderer. Rotating both the
        // model normal and the light preserves the physical illumination while the camera
        // moves to another corner for a PDF view.
        val lightLength = sqrt(0.59 * 0.59 + 0.64 * 0.64 + 0.49 * 0.49)
        val modelLight = Triple(-0.59 / lightLength, 0.64 / lightLength, 0.49 / lightLength)
        val light = rotate(modelLight.first, modelLight.second, modelLight.third)
        val up = rotate(0.0, 1.0, 0.0)
        val triangles = mutableListOf<DrawTriangle>()
        var vertexOffset = 0
        while (vertexOffset + 8 < mesh.triangles.size) {
            val a = project(mesh.triangles[vertexOffset].toDouble(), mesh.triangles[vertexOffset + 1].toDouble(), mesh.triangles[vertexOffset + 2].toDouble())
            val b = project(mesh.triangles[vertexOffset + 3].toDouble(), mesh.triangles[vertexOffset + 4].toDouble(), mesh.triangles[vertexOffset + 5].toDouble())
            val c = project(mesh.triangles[vertexOffset + 6].toDouble(), mesh.triangles[vertexOffset + 7].toDouble(), mesh.triangles[vertexOffset + 8].toDouble())
            val nx = mesh.normals.getOrElse(vertexOffset) { 0f }.toDouble()
            val ny = mesh.normals.getOrElse(vertexOffset + 1) { 1f }.toDouble()
            val nz = mesh.normals.getOrElse(vertexOffset + 2) { 0f }.toDouble()
            val normal = rotate(nx, ny, nz)
            val nDotSun = normal.first * light.first + normal.second * light.second + normal.third * light.third
            val diffuse = max(0.0, nDotSun)
            val wrappedDiffuse = max(0.0, (nDotSun + 0.18) / 1.18)
            val skyFacing = (
                (normal.first * up.first + normal.second * up.second + normal.third * up.third) * 0.5 + 0.5
            ).coerceIn(0.0, 1.0)
            val hemisphere = 0.34 + (0.56 - 0.34) * skyFacing
            val illumination = hemisphere + diffuse * 0.43 + wrappedDiffuse * 0.07
            val center = rotate(
                (mesh.triangles[vertexOffset] + mesh.triangles[vertexOffset + 3] + mesh.triangles[vertexOffset + 6]) / 3.0,
                (mesh.triangles[vertexOffset + 1] + mesh.triangles[vertexOffset + 4] + mesh.triangles[vertexOffset + 7]) / 3.0,
                (mesh.triangles[vertexOffset + 2] + mesh.triangles[vertexOffset + 5] + mesh.triangles[vertexOffset + 8]) / 3.0
            )
            val viewX = -center.first
            val viewY = -center.second
            val viewZ = camera.distance - center.third
            val viewLength = sqrt(viewX * viewX + viewY * viewY + viewZ * viewZ).coerceAtLeast(1e-9)
            val halfX = light.first + viewX / viewLength
            val halfY = light.second + viewY / viewLength
            val halfZ = light.third + viewZ / viewLength
            val halfLength = sqrt(halfX * halfX + halfY * halfY + halfZ * halfZ).coerceAtLeast(1e-9)
            val specular = max(
                0.0,
                normal.first * halfX / halfLength + normal.second * halfY / halfLength + normal.third * halfZ / halfLength
            ).let { if (nDotSun >= 0.0) Math.pow(it, 38.0) else 0.0 }
            val material = mesh.materials.getOrElse(vertexOffset / 3) { if (abs(ny) >= 0.42) 1f else 0f }
            val roof = material >= 0.5f && material < 1.5f
            val pad = material >= 1.5f && material < 2.5f
            val selected = material >= 2.5f && material < 3.5f
            val frame = material >= 3.5f && material < 4.5f
            val glass = material >= 4.5f && material < 5.5f
            val soffit = material >= 5.5f && material < 6.5f
            val mineral = abs(sin((a.x + b.x * 1.71 + c.x * 0.63) * 18.7 + (a.y + b.y + c.y) * 11.3))
            val base = if (roof) {
                val materialVariation = 0.97 + mineral * 0.060
                intArrayOf(
                    (40 * materialVariation).toInt(),
                    (46 * materialVariation).toInt(),
                    (50 * materialVariation).toInt()
                )
            } else if (pad) {
                intArrayOf(248, 249, 249)
            } else if (selected) {
                intArrayOf(210, 20, 14)
            } else if (frame) {
                intArrayOf(42, 47, 50)
            } else if (glass) {
                intArrayOf(79, 140, 156)
            } else if (soffit) {
                intArrayOf(176, 181, 184)
            } else {
                intArrayOf(223, 226, 228)
            }
            val shade = if (roof) {
                (0.82 + illumination * 0.23 + specular * 0.035).coerceIn(0.86, 1.06)
            } else if (pad) {
                (0.76 + illumination * 0.24).coerceIn(0.80, 1.0)
            } else if (selected) {
                0.98
            } else if (frame) {
                (0.78 + illumination * 0.22).coerceIn(0.76, 1.02)
            } else if (glass) {
                (0.72 + illumination * 0.24 + specular * 0.16).coerceIn(0.72, 1.08)
            } else if (soffit) {
                (0.60 + illumination * 0.38 + specular * 0.015).coerceIn(0.68, 0.98)
            } else {
                (0.64 + illumination * 0.40 + specular * 0.018).coerceIn(0.72, 1.04)
            }
            val materialSpecular = when {
                glass -> specular * 0.12
                roof -> specular * 0.03
                else -> specular * 0.012
            }
            val color = Color.rgb(
                (base[0] * shade + 255.0 * materialSpecular).toInt().coerceIn(0, 255),
                (base[1] * shade + 255.0 * materialSpecular).toInt().coerceIn(0, 255),
                (base[2] * shade + 255.0 * materialSpecular).toInt().coerceIn(0, 255)
            )
            triangles += DrawTriangle(a, b, c, color)
            vertexOffset += 9
        }
        val raster = SoftwareDepthRasterizer(width, height, backgroundColor)
        // Surfaces are fully opaque and tested fragment by fragment. No triangle stroke is drawn:
        // triangulation diagonals are an implementation detail, not a visible wall/roof edge.
        triangles.forEach { triangle ->
            raster.fillTriangle(
                depthVertex(triangle.a), depthVertex(triangle.b), depthVertex(triangle.c), triangle.color
            )
        }

        val edgeWidth = max(1.0f, min(width, height) / 430f)
        val edgeColor = Color.rgb(19, 23, 25)
        offset = 0
        while (offset + 5 < mesh.edges.size) {
            val a = project(mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble())
            val b = project(mesh.edges[offset + 3].toDouble(), mesh.edges[offset + 4].toDouble(), mesh.edges[offset + 5].toDouble())
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), edgeColor, edgeWidth, depthBias = 0f)
            offset += 6
        }
        // Roof seams are intentionally subordinate to the silhouette in PDF/isometric views.
        val internalEdgeWidth = max(0.7f, min(width, height) / 700f)
        val internalEdgeColor = Color.rgb(151, 156, 158)
        offset = 0
        while (offset + 5 < mesh.internalEdges.size) {
            val a = project(
                mesh.internalEdges[offset].toDouble(), mesh.internalEdges[offset + 1].toDouble(),
                mesh.internalEdges[offset + 2].toDouble()
            )
            val b = project(
                mesh.internalEdges[offset + 3].toDouble(), mesh.internalEdges[offset + 4].toDouble(),
                mesh.internalEdges[offset + 5].toDouble()
            )
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), internalEdgeColor, internalEdgeWidth, depthBias = 0f)
            offset += 6
        }
        // Facades expose no triangulation, split-node or corner seams. Only the true
        // footprint outline remains, and even that is deliberately very light.
        val wallEdgeWidth = max(0.55f, min(width, height) / 900f)
        val wallEdgeColor = Color.rgb(190, 194, 196)
        offset = 0
        while (offset + 5 < mesh.wallEdges.size) {
            val a = project(
                mesh.wallEdges[offset].toDouble(), mesh.wallEdges[offset + 1].toDouble(),
                mesh.wallEdges[offset + 2].toDouble()
            )
            val b = project(
                mesh.wallEdges[offset + 3].toDouble(), mesh.wallEdges[offset + 4].toDouble(),
                mesh.wallEdges[offset + 5].toDouble()
            )
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), wallEdgeColor, wallEdgeWidth, depthBias = 0f)
            offset += 6
        }
        val padEdgeWidth = max(0.65f, min(width, height) / 760f)
        val padEdgeColor = Color.rgb(154, 159, 161)
        offset = 0
        while (offset + 5 < mesh.padEdges.size) {
            val a = project(mesh.padEdges[offset].toDouble(), mesh.padEdges[offset + 1].toDouble(), mesh.padEdges[offset + 2].toDouble())
            val b = project(mesh.padEdges[offset + 3].toDouble(), mesh.padEdges[offset + 4].toDouble(), mesh.padEdges[offset + 5].toDouble())
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), padEdgeColor, padEdgeWidth, 0.0008f)
            offset += 6
        }
        val logoEdgeWidth = max(1.2f, min(width, height) / 320f)
        val logoEdgeColor = Color.rgb(226, 212, 178)
        offset = 0
        while (offset + 5 < mesh.logoEdges.size) {
            val a = project(mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble())
            val b = project(mesh.logoEdges[offset + 3].toDouble(), mesh.logoEdges[offset + 4].toDouble(), mesh.logoEdges[offset + 5].toDouble())
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), logoEdgeColor, logoEdgeWidth, 0.0012f)
            offset += 6
        }
        fun logoVisibilityAndArea(quad: RoofLogoQuad): Pair<Boolean, Double> {
            val corners = listOf(quad.topLeft, quad.topRight, quad.bottomRight, quad.bottomLeft)
                .map { point -> project(point.x.toDouble(), point.y.toDouble(), point.z.toDouble()) }
            val center = Projected(
                corners.map { it.x }.average(),
                corners.map { it.y }.average(),
                corners.map { it.depth }.average(),
                corners.map { it.inverseDepth.toDouble() }.average().toFloat()
            )
            val screenCenter = depthVertex(center)
            val centerX = screenCenter.x.roundToInt()
            val centerY = screenCenter.y.roundToInt()
            val visible = centerX in 0 until width && centerY in 0 until height &&
                raster.isCovered(screenCenter.x, screenCenter.y) &&
                screenCenter.inverseDepth + 0.0025f >= raster.depthAt(centerX, centerY)
            val screen = corners.map { sx(it).toDouble() to sy(it).toDouble() }
            val area = abs(screen.indices.sumOf { index ->
                val a = screen[index]
                val b = screen[(index + 1) % screen.size]
                a.first * b.second - b.first * a.second
            }) / 2.0
            return visible to area
        }
        val candidateLogos = mesh.logoCandidates.ifEmpty { mesh.logoQuads }
        val visiblePrimary = mesh.logoQuads.filter { logoVisibilityAndArea(it).first }
        val logosForView = if (visiblePrimary.isNotEmpty()) {
            visiblePrimary
        } else {
            val evaluated = candidateLogos.asSequence()
                .map { it to logoVisibilityAndArea(it) }
                .toList()
            val best = evaluated.filter { it.second.first }.maxByOrNull { it.second.second }
                ?: evaluated.maxByOrNull { it.second.second }
            best?.let { listOf(it.first) }.orEmpty()
        }
        if (logosForView.isNotEmpty()) {
            val logo = StrechoStavLogo.bitmap(1024, 470)
            val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 245 }
            val source = StrechoStavLogo.roofSurfaceSourceCorners(logo.width, logo.height)
            val logoLayer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val logoCanvas = Canvas(logoLayer)
            val layerPixels = IntArray(width * height)
            logosForView.forEach { quad ->
                logoLayer.eraseColor(Color.TRANSPARENT)
                val tl = project(quad.topLeft.x.toDouble(), quad.topLeft.y.toDouble(), quad.topLeft.z.toDouble())
                val tr = project(quad.topRight.x.toDouble(), quad.topRight.y.toDouble(), quad.topRight.z.toDouble())
                val br = project(quad.bottomRight.x.toDouble(), quad.bottomRight.y.toDouble(), quad.bottomRight.z.toDouble())
                val bl = project(quad.bottomLeft.x.toDouble(), quad.bottomLeft.y.toDouble(), quad.bottomLeft.z.toDouble())
                val destination = floatArrayOf(
                    sx(tl), sy(tl), sx(tr), sy(tr), sx(br), sy(br), sx(bl), sy(bl)
                )
                val matrix = Matrix()
                if (matrix.setPolyToPoly(source, 0, destination, 0, 4)) {
                    logoCanvas.drawBitmap(logo, matrix, logoPaint)
                    logoLayer.getPixels(layerPixels, 0, width, 0, 0, width, height)
                    raster.compositeLayerTriangle(
                        depthVertex(tl), depthVertex(tr), depthVertex(br), layerPixels
                    )
                    raster.compositeLayerTriangle(
                        depthVertex(tl), depthVertex(br), depthVertex(bl), layerPixels
                    )
                }
            }
            logoLayer.recycle()
            logo.recycle()
        }

        bitmap.setPixels(raster.pixels, 0, width, 0, 0, width, height)

        // Technical annotations are optional. PDF presentation views deliberately omit them,
        // while the catalogue and interactive snapshots keep the same semantic dimensions.
        if (showDimensions) {
        val dimensionLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 108, 52)
            style = Paint.Style.STROKE
            strokeWidth = max(1.0f, min(width, height) / 520f)
        }
        val dimensionText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 58, 37)
            textAlign = Paint.Align.CENTER
            textSize = max(11f, min(width, height) * 0.025f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        }
        val dimensionBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(242, 255, 253, 246)
            style = Paint.Style.FILL
        }
        val occupied = mutableListOf<RectF>()
        val modelCenterX = width / 2f
        val modelCenterY = height / 2f
        val dimensionCandidates = RoofDimensionPlacement.stablePlanCandidates(mesh.dimensions)
            .groupBy { it.dimensionId }.map { (_, candidates) ->
            candidates.maxBy { dimension ->
                val a = project(dimension.witnessStart.x.toDouble(), dimension.witnessStart.y.toDouble(), dimension.witnessStart.z.toDouble())
                val b = project(dimension.witnessEnd.x.toDouble(), dimension.witnessEnd.y.toDouble(), dimension.witnessEnd.z.toDouble())
                (a.depth + b.depth) / 2.0
            }
        }.sortedWith(compareBy<RoofDimension3D> {
            when (it.kind) {
                RoofDimensionKind.WALL_HEIGHT -> 0
                RoofDimensionKind.ATTIC_HEIGHT -> 1
                RoofDimensionKind.ATTIC_WIDTH -> 1
                RoofDimensionKind.CHIMNEY_HEIGHT -> 2
                RoofDimensionKind.CHIMNEY_WIDTH, RoofDimensionKind.CHIMNEY_LENGTH -> 3
                RoofDimensionKind.ROOF_WINDOW_WIDTH, RoofDimensionKind.ROOF_WINDOW_LENGTH -> 4
                RoofDimensionKind.HATCH_WIDTH, RoofDimensionKind.HATCH_LENGTH -> 4
                RoofDimensionKind.VENT_DIAMETER -> 4
                RoofDimensionKind.SLOPE -> 5
                RoofDimensionKind.OVERHANG -> 6
                RoofDimensionKind.PLAN_LENGTH -> 7
            }
        })
        dimensionCandidates.forEach { dimension ->
            val projectedWitnessA = project(
                dimension.witnessStart.x.toDouble(), dimension.witnessStart.y.toDouble(), dimension.witnessStart.z.toDouble()
            )
            val projectedWitnessB = project(
                dimension.witnessEnd.x.toDouble(), dimension.witnessEnd.y.toDouble(), dimension.witnessEnd.z.toDouble()
            )
            val projectedA = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) project(
                dimension.start.x.toDouble(), dimension.start.y.toDouble(), dimension.start.z.toDouble()
            ) else projectedWitnessA
            val projectedB = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) project(
                dimension.end.x.toDouble(), dimension.end.y.toDouble(), dimension.end.z.toDouble()
            ) else projectedWitnessB
            val witnessAx = sx(projectedWitnessA); val witnessAy = sy(projectedWitnessA)
            val witnessBx = sx(projectedWitnessB); val witnessBy = sy(projectedWitnessB)
            val ax = sx(projectedA); val ay = sy(projectedA)
            val bx = sx(projectedB); val by = sy(projectedB)
            val edgeLength = hypot(bx - ax, by - ay).coerceAtLeast(1f)
            var nx = -(by - ay) / edgeLength
            var ny = (bx - ax) / edgeLength
            val midX = (ax + bx) / 2f
            val midY = (ay + by) / 2f
            fun score(sign: Float): Int {
                var result = 0
                floatArrayOf(18f, 34f, 56f, 82f).forEach { distance ->
                    floatArrayOf(0.18f, 0.5f, 0.82f).forEach { t ->
                        if (raster.isCovered(
                                ax + (bx - ax) * t + nx * sign * distance,
                                ay + (by - ay) * t + ny * sign * distance
                            )) result++
                    }
                }
                return result
            }
            val positiveScore = score(1f)
            val negativeScore = score(-1f)
            if (negativeScore < positiveScore ||
                (negativeScore == positiveScore && nx * (midX - modelCenterX) + ny * (midY - modelCenterY) < 0f)
            ) {
                nx = -nx; ny = -ny
            }
            val drawWitnessLines = minOf(positiveScore, negativeScore) == 0
            val text = when (dimension.kind) {
                RoofDimensionKind.PLAN_LENGTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.WALL_HEIGHT -> String.format(Locale("sk", "SK"), "H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_HEIGHT -> String.format(Locale("sk", "SK"), "Atika  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_WIDTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.OVERHANG -> String.format(Locale("sk", "SK"), "Presah  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SLOPE -> String.format(Locale("sk", "SK"), "\u2220  %.1f\u00B0", dimension.lengthM)
                RoofDimensionKind.CHIMNEY_WIDTH -> String.format(Locale("sk", "SK"), "Komín Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_LENGTH -> String.format(Locale("sk", "SK"), "Komín D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_HEIGHT -> String.format(Locale("sk", "SK"), "Komín H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_WIDTH -> String.format(Locale("sk", "SK"), "Okno Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_LENGTH -> String.format(Locale("sk", "SK"), "Okno D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.HATCH_WIDTH -> String.format(Locale("sk", "SK"), "Výlez Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.HATCH_LENGTH -> String.format(Locale("sk", "SK"), "Výlez D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.VENT_DIAMETER -> String.format(Locale("sk", "SK"), "Ø  %,.0f mm", dimension.lengthM * 1000.0)
            }
            val halfWidth = dimensionText.measureText(text) / 2f + min(width, height) * 0.014f
            val halfHeight = dimensionText.textSize * 0.85f
            var placement: Triple<Pair<Float, Float>, Pair<Float, Float>, RectF>? = null
            if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) {
                val box = RectF(
                    (ax + bx) / 2f - halfWidth, (ay + by) / 2f - halfHeight,
                    (ax + bx) / 2f + halfWidth, (ay + by) / 2f + halfHeight
                )
                placement = Triple(ax to ay, bx to by, box)
            } else for (level in 0..4) {
                val distance = min(width, height) * (0.035f + level * 0.042f)
                val start = (ax + nx * distance) to (ay + ny * distance)
                val end = (bx + nx * distance) to (by + ny * distance)
                val cx = (start.first + end.first) / 2f
                val cy = (start.second + end.second) / 2f
                val box = RectF(cx - halfWidth, cy - halfHeight, cx + halfWidth, cy + halfHeight)
                if (box.left >= 3f && box.top >= 3f && box.right <= width - 3f && box.bottom <= height - 3f &&
                    occupied.none { RectF.intersects(it, box) }
                ) {
                    placement = Triple(start, end, box)
                    break
                }
            }
            val selected = placement ?: return@forEach
            if (drawWitnessLines) {
                canvas.drawLine(witnessAx, witnessAy, selected.first.first, selected.first.second, dimensionLine)
                canvas.drawLine(witnessBx, witnessBy, selected.second.first, selected.second.second, dimensionLine)
            }
            canvas.drawLine(
                selected.first.first, selected.first.second,
                selected.second.first, selected.second.second,
                dimensionLine
            )
            canvas.drawRoundRect(selected.third, 6f, 6f, dimensionBox)
            canvas.drawRoundRect(selected.third, 6f, 6f, dimensionLine)
            val baseline = selected.third.centerY() - (dimensionText.ascent() + dimensionText.descent()) / 2f
            canvas.drawText(text, selected.third.centerX(), baseline, dimensionText)
            occupied += RectF(selected.third)
        }
        }
        canvas.drawRect(RectF(0.5f, 0.5f, width - 0.5f, height - 0.5f), frame)
        return bitmap
    }
}
