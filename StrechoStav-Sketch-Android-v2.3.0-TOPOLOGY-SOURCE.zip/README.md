# StrechoStav Sketch pre Android 2.3.0

Natívna Android aplikácia v Kotline na vyhľadanie stavby, kreslenie strechy nad
mapovým podkladom, výpočet výmer a vytvorenie 3D modelu strechy so stenami.

## Bezplatné mapové podklady

- **ZBGIS ortofoto** – kvalitná Ortofotomozaika SR z verejnej WMS služby GKÚ Bratislava.
- **OSM mapa** – cestná mapa OpenStreetMap.
- **OSM terén** – topografické zobrazenie OpenTopoMap založené na dátach OSM.
- **PDF/JPG** – vlastný projektový výkres alebo obrázok ako podklad.

Google Maps SDK, Google Cloud, fakturácia aj API kľúč sú úplne odstránené.

ZBGIS vrstva používa WMS 1.3.0, vrstvu `1` a súradnicový systém `EPSG:3857`.
Aplikácia prepočíta aktuálny GPS stred a zoom na BBOX každej viditeľnej dlaždice,
stiahne všetky potrebné dlaždice a bez švov ich spojí. Pri väčšej budove alebo
vzdialenejšom zoome sa automaticky načíta väčšia plocha. WMS obrázky sa žiadajú
vo veľkosti 512 × 512 px a vykresľujú ako 256 px dlaždice pre ostré zobrazenie.

## Vyhľadanie a kreslenie

- Ručné vyhľadanie adresy cez Nominatim prevedie adresu na GPS súradnice.
- Vyhľadávanie je obmedzené na najviac jednu požiadavku za sekundu a výsledky sa cachujú.
- Najbližší obrys budovy možno importovať z OpenStreetMap cez Overpass API.
- Mapu možno posúvať, približovať dvoma prstami, kolieskom myši alebo tlačidlami `+`/`−`.
- `Celok` automaticky nastaví stred a zoom tak, aby bol viditeľný celý obrys.
- Strechu možno obkresliť ťahom, bod po bode alebo upraviť presunutím vrcholov.
- Podporované sú hrebene, úžľabia, nárožia, atiky, pultové hrany a napojenia pri murive.
- PDF/JPG podklad možno kalibrovať podľa známej dĺžky hrany.

Raster je vykreslený v samostatnej vrstve pod geometriou. Pri posune a zoome sa
stará kompletná vrstva ponechá viditeľná, kým je nová vrstva pripravená. ZBGIS
podporuje päť digitálnych úrovní nad maximálnym zdrojovým zoomom; vtedy sa nemení
zdrojová dlaždica, iba presné zväčšenie zobrazenia.

## Topologický editor

- Režim `Línie` zobrazuje a umožňuje presúvať oba konce každej strešnej línie.
- Konce sa pri pustení prichytávajú k blízkym uzlom a vrcholom obrysu.
- `Skorigovať` najprv zobrazí návrh zelenou, pohyby bodov a chyby; projekt sa zmení až po potvrdení.
- Solver zlučuje blízke uzly, vytvára priesečníky, rozdeľuje hrany, rieši T-napojenia a kontroluje voľné konce.
- Undo aj Redo uchovávajú celé transakcie vrátane prijatia návrhu solvera.
- JSON schéma 3 uchováva topologický graf; staré projekty sa pri načítaní migrujú v pamäti.

## 3D model a výkaz

3D model vychádza z nakresleného pôdorysu a siete strešných čiar. Podporuje
kombinované strechy a polvalby. Steny majú základnú výšku 3 m, ktorú možno zvýšiť.
Výkaz obsahuje geometrické výmery a klampiarske hrany bez hydroizolácie, podkladu a cien.

Pred vytvorením 3D sa topológia validuje. Neplatný nákres zostane v 2D a aplikácia
vysvetlí chybu. Automatický povrch sa trianguluje po samostatných uzavretých
strešných plochách; ploché a pultové konkávne pôdorysy používajú ear clipping.

## Zostavenie

Projekt nepotrebuje žiadny secret ani API kľúč:

```text
gradle :app:testDebugUnitTest :app:assembleDebug
```

Pribalený GitHub Actions workflow používa Java 17 a Gradle 8.10.2. Výsledné APK
je `app/build/outputs/apk/debug/app-debug.apk`.

## Internet, cache a licencie

Mapy a nové vyhľadávania vyžadujú internet. Viditeľné dlaždice sa ukladajú do
lokálnej cache na sedem dní; aplikácia nesťahuje oblasti na pozadí ani nevytvára
offline mapové balíky.

- OpenStreetMap: © OpenStreetMap prispievatelia, ODbL.
- OpenTopoMap: mapové dáta © OpenStreetMap prispievatelia, štýl © OpenTopoMap.
- Ortofotomozaika: © GKÚ Bratislava, CC BY 4.0.

Mapové výmery sú orientačné. Pred výrobou alebo realizáciou ich treba overiť meraním na stavbe.
