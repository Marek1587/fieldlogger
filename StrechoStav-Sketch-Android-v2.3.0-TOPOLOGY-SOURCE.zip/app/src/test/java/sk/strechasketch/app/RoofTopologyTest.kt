package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofTopologyTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    private fun rectangleProject(): RoofProject = RoofProject(
        polygon = mutableListOf(geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0))
    )

    @Test
    fun crossingRoofLinesCreateSharedIntersection() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            lines += RoofLine(type = LineType.VALLEY, start = geo(6.0, 0.0), end = geo(6.0, 8.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.createdIntersections >= 1)
        assertTrue(preview.statistics.splitEdges >= 2)
        assertTrue(preview.faces.isNotEmpty())
        assertTrue(preview.isValid)
    }

    @Test
    fun nearCoincidentEndpointsAreMergedDeterministically() {
        val project = rectangleProject().apply {
            lines += RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(6.0, 4.0))
            lines += RoofLine(type = LineType.RIDGE, start = geo(6.02, 4.01), end = geo(12.0, 4.0))
        }
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.statistics.mergedNodes >= 1)
        assertTrue(preview.proposed.edges.none { it.startNodeId == it.endNodeId })
    }

    @Test
    fun legacyJsonMigratesWithoutLosingReportInputs() {
        val project = rectangleProject().apply {
            name = "Regresný projekt"
            slopeDeg = 31.5
            wallHeightM = 4.2
            objects += RoofObject(type = ObjectType.CHIMNEY, center = geo(3.0, 3.0))
        }
        val encoded = ProjectJson.encode(project)
        val decoded = ProjectJson.decode(encoded)
        assertEquals(project.name, decoded.name)
        assertEquals(project.slopeDeg, decoded.slopeDeg, 0.0001)
        assertEquals(project.wallHeightM, decoded.wallHeightM, 0.0001)
        assertEquals(1, decoded.objects.size)
        assertTrue(decoded.roofTopology != null)
    }

    @Test
    fun concaveFootprintProducesValidFace() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 4.0),
                geo(5.0, 4.0), geo(5.0, 9.0), geo(0.0, 9.0)
            )
        )
        val preview = RoofTopologySolver.solve(RoofTopologyMigration.fromProject(project))
        assertTrue(preview.isValid)
        assertEquals(1, preview.faces.size)
    }
}
