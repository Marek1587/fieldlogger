package sk.strechasketch.app

import android.content.Context
import android.graphics.PointF
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

class Roof3DView(context: Context) : GLSurfaceView(context) {
    private val roofRenderer = Roof3DRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f
    var onCameraChanged: (() -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                roofRenderer.zoom = (roofRenderer.zoom * detector.scaleFactor).coerceIn(0.45f, 3.2f)
                requestRender()
                onCameraChanged?.invoke()
                return true
            }
        }
    )
    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        setPreserveEGLContextOnPause(true)
        setRenderer(roofRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        contentDescription = "Interaktívny trojrozmerný model strechy"
    }

    fun setProject(project: RoofProject) {
        roofRenderer.setProject(project)
        requestRender()
        onCameraChanged?.invoke()
    }

    fun resetView() {
        roofRenderer.resetView()
        requestRender()
        onCameraChanged?.invoke()
    }

    internal fun projectedDimensions(): List<ProjectedRoofDimension> =
        roofRenderer.projectDimensions(width.coerceAtLeast(1), height.coerceAtLeast(1))

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) {
                lastMidX = (event.getX(0) + event.getX(1)) / 2f
                lastMidY = (event.getY(0) + event.getY(1)) / 2f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val midX = (event.getX(0) + event.getX(1)) / 2f
                    val midY = (event.getY(0) + event.getY(1)) / 2f
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.panX += (midX - lastMidX) / density * 0.008f
                    roofRenderer.panY -= (midY - lastMidY) / density * 0.008f
                    lastMidX = midX
                    lastMidY = midY
                    requestRender()
                    onCameraChanged?.invoke()
                } else if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.yawDegrees += (event.x - lastX) / density * 0.62f
                    roofRenderer.pitchDegrees = (
                        roofRenderer.pitchDegrees + (event.y - lastY) / density * 0.62f
                    ).coerceIn(-82f, 82f)
                    requestRender()
                    onCameraChanged?.invoke()
                }
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

internal data class RoofVec3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(other: RoofVec3) = RoofVec3(x - other.x, y - other.y, z - other.z)
}

internal data class RoofMesh(
    val triangles: FloatArray,
    val normals: FloatArray,
    val edges: FloatArray,
    /** One value per triangle vertex: 1 = roof, 0 = wall/object. */
    val materials: FloatArray = FloatArray(0),
    val logoEdges: FloatArray = FloatArray(0),
    val logoQuads: List<RoofLogoQuad> = emptyList(),
    val dimensions: List<RoofDimension3D> = emptyList(),
    val logoFaceCount: Int = 0
)

internal data class RoofLogoQuad(
    val faceId: String,
    val topLeft: RoofVec3,
    val topRight: RoofVec3,
    val bottomRight: RoofVec3,
    val bottomLeft: RoofVec3
)

internal enum class RoofDimensionKind { PLAN_LENGTH, WALL_HEIGHT, ATTIC_HEIGHT, OVERHANG, SLOPE }

internal data class RoofDimension3D(
    val dimensionId: String,
    val edgeId: String,
    val linkedEdgeIds: List<String> = listOf(edgeId),
    val kind: RoofDimensionKind = RoofDimensionKind.PLAN_LENGTH,
    val start: RoofVec3,
    val end: RoofVec3,
    val witnessStart: RoofVec3,
    val witnessEnd: RoofVec3,
    val lengthM: Double
)

internal data class ProjectedRoofDimension(
    val dimensionId: String,
    val edgeId: String,
    val linkedEdgeIds: List<String>,
    val kind: RoofDimensionKind,
    val start: PointF,
    val end: PointF,
    val witnessStart: PointF,
    val witnessEnd: PointF,
    val lengthM: Double,
    val modelCenter: PointF
)

internal object RoofMeshBuilder {
    private data class HeightPoint(val p: LocalPoint, val h: Double)
    private data class Triangle(val a: Int, val b: Int, val c: Int)
    private data class Edge(val a: Int, val b: Int) {
        fun normalized() = if (a < b) this else Edge(b, a)
    }

    fun build(project: RoofProject): RoofMesh = buildFromGraph(project)

    private fun signedArea(points: List<LocalPoint>): Double = points.indices.sumOf { index ->
        val a = points[index]
        val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    private fun isCompatibleWallLoop(walls: List<LocalPoint>, roof: List<LocalPoint>): Boolean {
        if (walls.size != roof.size || walls.size < 3) return false
        val roofArea = abs(signedArea(roof))
        val wallArea = abs(signedArea(walls))
        if (roofArea <= 1e-6 || wallArea !in roofArea * 0.04..roofArea * 1.04) return false
        return walls.all { point ->
            Geometry.pointInPolygon(point, roof) || roof.indices.any { index ->
                Geometry.distanceToSegment(point, roof[index], roof[(index + 1) % roof.size]) < 1e-5
            }
        }
    }

    /** Aligns the saved polygon start and winding to the ordered roof boundary. */
    private fun alignLoopToBoundary(walls: List<LocalPoint>, roof: List<LocalPoint>): List<LocalPoint> {
        fun score(candidate: List<LocalPoint>): Double = candidate.indices.sumOf { index ->
            val dx = candidate[index].x - roof[index].x
            val dy = candidate[index].y - roof[index].y
            dx * dx + dy * dy
        }
        val orientations = listOf(walls, walls.reversed())
        return orientations.flatMap { loop ->
            loop.indices.map { shift -> List(loop.size) { index -> loop[(index + shift) % loop.size] } }
        }.minByOrNull(::score) ?: walls
    }

    private fun buildFromGraph(project: RoofProject): RoofMesh {
        if (project.polygon.size < 3) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val solution = Roof3DPreparation.prepare(project).planeSolution
        if (solution.hasBlockingIssues) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val solved = solution.graph
        if (solved.faces.isEmpty()) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))

        val minX = solved.nodes.values.minOf { it.x }
        val maxX = solved.nodes.values.maxOf { it.x }
        val minY = solved.nodes.values.minOf { it.y }
        val maxY = solved.nodes.values.maxOf { it.y }
        val minZ = 0.0
        val maxZ = solved.nodes.values.maxOf { it.z }.coerceAtLeast(project.wallHeightM)
        val span = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
        val normalization = (2.2 / max(span, maxZ - minZ)).toFloat()
        val centerX = (minX + maxX) / 2.0
        val centerY = (minY + maxY) / 2.0
        val centerZ = (minZ + maxZ) / 2.0
        fun point(node: GraphNode, zOffset: Double = 0.0) = RoofVec3(
            ((node.x - centerX) * normalization).toFloat(),
            ((node.z + zOffset - centerZ) * normalization).toFloat(),
            ((node.y - centerY) * normalization).toFloat()
        )
        fun ground(node: GraphNode) = RoofVec3(
            ((node.x - centerX) * normalization).toFloat(),
            ((-centerZ) * normalization).toFloat(),
            ((node.y - centerY) * normalization).toFloat()
        )

        val positions = arrayListOf<Float>()
        val normals = arrayListOf<Float>()
        val materials = arrayListOf<Float>()
        val edges = arrayListOf<Float>()
        val logoEdges = arrayListOf<Float>()
        val logoQuads = arrayListOf<RoofLogoQuad>()
        val dimensions = arrayListOf<RoofDimension3D>()
        solved.faces.values.sortedBy { it.id }.forEach { face ->
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            val local2D = nodes.map { LocalPoint(it.x, it.y) }
            earClip(local2D).forEach { triangle ->
                addTriangle(
                    positions, normals, materials,
                    point(nodes[triangle.a]), point(nodes[triangle.b]), point(nodes[triangle.c]),
                    material = 1f
                )
            }
        }
        solved.edges.values.sortedBy { it.id }.forEach { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@forEach
            val b = solved.nodes[edge.endNodeId] ?: return@forEach
            addLine(edges, point(a, span * 0.002), point(b, span * 0.002))
        }
        val orderedBoundary = RoofTopologyMigration.orderedBoundary(solved.toTopology())
        val boundaryLoop = orderedBoundary?.first
            ?.mapNotNull(solved.nodes::get)
            ?.map { LocalPoint(it.x, it.y) }
            .orEmpty()
        val boundaryEdges = orderedBoundary?.second.orEmpty()

        // A saved wall footprint is only valid while it still describes the same polygonal
        // topology as the roof boundary. This prevents an old rectangle from being extruded
        // below a later L/T/K-shaped roof. Rotation/reversal is aligned deterministically so
        // wall segment i continues to correspond to boundary edge i.
        val savedWallLoop = project.wallFootprint
            .takeIf { it.size == boundaryLoop.size && it.size >= 3 }
            ?.map { Geometry.toLocal(it, solved.origin) }
        val wallLoop = savedWallLoop
            ?.takeIf { isCompatibleWallLoop(it, boundaryLoop) }
            ?.let { alignLoopToBoundary(it, boundaryLoop) }
            ?: boundaryLoop
        val displayDimensions = arrayListOf<RoofDimension3D>()
        if (wallLoop.size >= 3) {
            val wallTop = wallLoop.mapIndexed { index, local ->
                point(GraphNode("wall-top-$index", local.x, local.y, project.wallHeightM))
            }
            val wallBottom = wallLoop.mapIndexed { index, local ->
                ground(GraphNode("wall-bottom-$index", local.x, local.y, 0.0))
            }
            wallLoop.indices.forEach { index ->
                val next = (index + 1) % wallLoop.size
                addTriangle(positions, normals, materials, wallTop[index], wallBottom[next], wallTop[next], material = 0f)
                addTriangle(positions, normals, materials, wallTop[index], wallBottom[index], wallBottom[next], material = 0f)
                addLine(edges, wallBottom[index], wallBottom[next])
                addLine(edges, wallBottom[index], wallTop[index])
                addLine(edges, wallTop[index], wallTop[next])
            }

            // Plan dimensions belong to the building footprint and lie on the foundation/base
            // line, not on the roof eaves or on the upper wall edge.
            // Their edge IDs remain linked to the corresponding roof boundary constraints,
            // allowing the existing parametric editor to keep working.
            val rawPlanDimensions = wallLoop.indices.mapNotNull { index ->
                val edge = boundaryEdges.getOrNull(index) ?: return@mapNotNull null
                val baseA = wallBottom[index]
                val baseB = wallBottom[(index + 1) % wallBottom.size]
                val edgeX = baseB.x - baseA.x
                val edgeZ = baseB.z - baseA.z
                val edgeLength = hypot(edgeX, edgeZ).coerceAtLeast(0.0001f)
                var outwardX = -edgeZ / edgeLength
                var outwardZ = edgeX / edgeLength
                val midX = (baseA.x + baseB.x) / 2f
                val midZ = (baseA.z + baseB.z) / 2f
                if (outwardX * midX + outwardZ * midZ < 0f) {
                    outwardX = -outwardX
                    outwardZ = -outwardZ
                }
                val offset = 0.105f
                val lift = 0.006f
                RoofDimension3D(
                    dimensionId = "edge-${edge.id}",
                    edgeId = edge.id,
                    start = RoofVec3(baseA.x + outwardX * offset, baseA.y + lift, baseA.z + outwardZ * offset),
                    end = RoofVec3(baseB.x + outwardX * offset, baseB.y + lift, baseB.z + outwardZ * offset),
                    witnessStart = baseA,
                    witnessEnd = baseB,
                    lengthM = hypot(
                        wallLoop[(index + 1) % wallLoop.size].x - wallLoop[index].x,
                        wallLoop[(index + 1) % wallLoop.size].y - wallLoop[index].y
                    )
                )
            }
            displayDimensions += collapseSymmetricBoundaryDimensions(solved, rawPlanDimensions)

            // Several candidates share one ID. Projection keeps the visible candidate, so the
            // height dimension moves naturally to the visible facade as the user orbits the model.
            wallLoop.indices.forEach { index ->
                val top = wallTop[index]
                val bottom = wallBottom[index]
                displayDimensions += RoofDimension3D(
                    dimensionId = "wall-height",
                    edgeId = "wall-height-$index",
                    linkedEdgeIds = emptyList(),
                    kind = RoofDimensionKind.WALL_HEIGHT,
                    start = bottom,
                    end = top,
                    witnessStart = bottom,
                    witnessEnd = top,
                    lengthM = project.wallHeightM
                )
            }

            fun nearestPointOnWall(point: LocalPoint): LocalPoint {
                var best = wallLoop.first()
                var bestDistance = Double.POSITIVE_INFINITY
                wallLoop.indices.forEach { index ->
                    val a = wallLoop[index]
                    val b = wallLoop[(index + 1) % wallLoop.size]
                    val dx = b.x - a.x
                    val dy = b.y - a.y
                    val denominator = dx * dx + dy * dy
                    val t = if (denominator <= 1e-12) 0.0 else
                        (((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator).coerceIn(0.0, 1.0)
                    val candidate = LocalPoint(a.x + dx * t, a.y + dy * t)
                    val distance = hypot(candidate.x - point.x, candidate.y - point.y)
                    if (distance < bestDistance) {
                        bestDistance = distance
                        best = candidate
                    }
                }
                return best
            }
            val overhangCandidates = boundaryEdges.mapIndexedNotNull { index, edge ->
                val roofA = solved.nodes[edge.startNodeId]
                val roofB = solved.nodes[edge.endNodeId]
                if (roofA != null && roofB != null) {
                    val roofMid = LocalPoint((roofA.x + roofB.x) / 2.0, (roofA.y + roofB.y) / 2.0)
                    val wallPoint = nearestPointOnWall(roofMid)
                    val overhang = hypot(roofMid.x - wallPoint.x, roofMid.y - wallPoint.y)
                    val displayWallPoint = if (overhang > 0.001) wallPoint else {
                        val cx = boundaryLoop.map { it.x }.average()
                        val cy = boundaryLoop.map { it.y }.average()
                        val dx = cx - roofMid.x
                        val dy = cy - roofMid.y
                        val length = hypot(dx, dy).coerceAtLeast(1e-9)
                        LocalPoint(roofMid.x + dx / length * span * 0.035, roofMid.y + dy / length * span * 0.035)
                    }
                    val roof3D = point(GraphNode("overhang-roof-$index", roofMid.x, roofMid.y, project.wallHeightM))
                    val wall3D = point(GraphNode("overhang-wall-$index", displayWallPoint.x, displayWallPoint.y, project.wallHeightM))
                    RoofDimension3D(
                        dimensionId = "roof-overhang",
                        edgeId = edge.id,
                        linkedEdgeIds = boundaryEdges.map { it.id },
                        kind = RoofDimensionKind.OVERHANG,
                        start = wall3D,
                        end = roof3D,
                        witnessStart = wall3D,
                        witnessEnd = roof3D,
                        lengthM = overhang
                    )
                } else null
            }
            // A uniform offset is one project parameter. Several geometric candidates share
            // one ID and the projection layer selects the clearest visible placement.
            val representativeOverhang = overhangCandidates.map { it.lengthM }.sorted().let { values ->
                when {
                    values.isEmpty() -> 0.0
                    values.size % 2 == 1 -> values[values.size / 2]
                    else -> (values[values.size / 2 - 1] + values[values.size / 2]) / 2.0
                }
            }
            displayDimensions += overhangCandidates.map { it.copy(lengthM = representativeOverhang) }
        }

        // A degree-mark dimension is anchored to the two largest planes. It is not forced into the
        // foreground; the depth test selects the visible mark and the overlay finds free pixels.
        solved.faces.values.sortedByDescending { face ->
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            abs(nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            })
        }.take(2).forEachIndexed { index, face ->
            val plane = face.plane ?: return@forEachIndexed
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            if (nodes.size < 3) return@forEachIndexed
            val cx = nodes.map { it.x }.average()
            val cy = nodes.map { it.y }.average()
            val longest = nodes.indices.map { nodeIndex ->
                val a = nodes[nodeIndex]
                val b = nodes[(nodeIndex + 1) % nodes.size]
                Triple(b.x - a.x, b.y - a.y, hypot(b.x - a.x, b.y - a.y))
            }.maxByOrNull { it.third } ?: return@forEachIndexed
            val half = minOf(longest.third * 0.12, span * 0.09).coerceAtLeast(span * 0.025)
            val ux = longest.first / longest.third.coerceAtLeast(1e-9)
            val uy = longest.second / longest.third.coerceAtLeast(1e-9)
            fun slopePoint(sign: Double): RoofVec3 {
                val x = cx + ux * half * sign
                val y = cy + uy * half * sign
                return point(GraphNode("slope-$index-$sign", x, y, plane.zAt(x, y)), span * 0.004)
            }
            val a = slopePoint(-1.0)
            val b = slopePoint(1.0)
            displayDimensions += RoofDimension3D(
                dimensionId = "roof-slope",
                edgeId = "roof-slope-$index",
                linkedEdgeIds = emptyList(),
                kind = RoofDimensionKind.SLOPE,
                start = a,
                end = b,
                witnessStart = a,
                witnessEnd = b,
                lengthM = project.slopeDeg
            )
        }
        val atticEdges = solved.edges.values.filter { it.semanticRole == EdgeSemantic.ATTIC && it.boundary }
        val atticHeight = project.atticHeightM.coerceIn(0.1, 3.0)
        val atticTopZ = atticEdges.flatMap { edge ->
            listOfNotNull(solved.nodes[edge.startNodeId], solved.nodes[edge.endNodeId])
        }.maxOfOrNull { it.z }?.plus(atticHeight)
        atticEdges.forEach { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@forEach
            val b = solved.nodes[edge.endNodeId] ?: return@forEach
            val topZ = atticTopZ ?: return@forEach
            val face = edge.adjacentFaceIds.firstNotNullOfOrNull(solved.faces::get)
                ?: solved.faces.values.firstOrNull { edge.id in it.orderedEdgeIds }
            val faceNodes = face?.orderedNodeIds?.mapNotNull(solved.nodes::get).orEmpty()
            val centroidX = faceNodes.map { it.x }.average().takeIf(Double::isFinite) ?: (a.x + b.x) / 2.0
            val centroidY = faceNodes.map { it.y }.average().takeIf(Double::isFinite) ?: (a.y + b.y) / 2.0
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            var inwardX = -dy / length
            var inwardY = dx / length
            val midX = (a.x + b.x) / 2.0
            val midY = (a.y + b.y) / 2.0
            if (inwardX * (centroidX - midX) + inwardY * (centroidY - midY) < 0.0) {
                inwardX = -inwardX
                inwardY = -inwardY
            }
            val thickness = minOf(0.18, span * 0.04).coerceAtLeast(0.06)
            val innerAX = a.x + inwardX * thickness
            val innerAY = a.y + inwardY * thickness
            val innerBX = b.x + inwardX * thickness
            val innerBY = b.y + inwardY * thickness
            val plane = face?.plane
            val outerBottomA = point(GraphNode("attic-outer-a-${edge.id}", a.x, a.y, project.wallHeightM))
            val outerBottomB = point(GraphNode("attic-outer-b-${edge.id}", b.x, b.y, project.wallHeightM))
            val innerBottomA = point(GraphNode(
                "attic-inner-a-${edge.id}", innerAX, innerAY, plane?.zAt(innerAX, innerAY) ?: a.z
            ))
            val innerBottomB = point(GraphNode(
                "attic-inner-b-${edge.id}", innerBX, innerBY, plane?.zAt(innerBX, innerBY) ?: b.z
            ))
            val outerTopA = point(GraphNode("attic-top-oa-${edge.id}", a.x, a.y, topZ))
            val outerTopB = point(GraphNode("attic-top-ob-${edge.id}", b.x, b.y, topZ))
            val innerTopA = point(GraphNode("attic-top-ia-${edge.id}", innerAX, innerAY, topZ))
            val innerTopB = point(GraphNode("attic-top-ib-${edge.id}", innerBX, innerBY, topZ))

            // Exterior, interior and horizontal crown make the parapet a real solid band.
            addTriangle(positions, normals, materials, outerBottomA, outerBottomB, outerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerBottomA, outerTopB, outerTopA, material = 0f)
            addTriangle(positions, normals, materials, innerBottomB, innerBottomA, innerTopA, material = 0f)
            addTriangle(positions, normals, materials, innerBottomB, innerTopA, innerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerTopA, outerTopB, innerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerTopA, innerTopB, innerTopA, material = 0f)
            addTriangle(positions, normals, materials, outerBottomA, outerTopA, innerTopA, material = 0f)
            addTriangle(positions, normals, materials, outerBottomA, innerTopA, innerBottomA, material = 0f)
            addTriangle(positions, normals, materials, outerBottomB, innerBottomB, innerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerBottomB, innerTopB, outerTopB, material = 0f)
            addLine(edges, outerTopA, outerTopB)
            addLine(edges, innerTopA, innerTopB)
            addLine(edges, outerTopA, innerTopA)
            addLine(edges, outerTopB, innerTopB)

            val dimensionBottom = point(GraphNode(
                "attic-dimension-bottom-${edge.id}", midX, midY, topZ - atticHeight
            ))
            val dimensionTop = point(GraphNode(
                "attic-dimension-top-${edge.id}", midX, midY, topZ
            ))
            displayDimensions += RoofDimension3D(
                dimensionId = "attic-height",
                edgeId = edge.id,
                linkedEdgeIds = atticEdges.map { it.id },
                kind = RoofDimensionKind.ATTIC_HEIGHT,
                start = dimensionBottom,
                end = dimensionTop,
                witnessStart = dimensionBottom,
                witnessEnd = dimensionTop,
                lengthM = atticHeight
            )
        }
        // Technical objects are a derived shell layer. They never own or duplicate roof topology.
        project.objects.filter { it.type in setOf(
            ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH, ObjectType.VENT
        ) }.forEach { item ->
            val local = Geometry.toLocal(item.center, solved.origin)
            val face = item.attachedFaceId?.let(solved.faces::get) ?: solved.faces.values.firstOrNull { candidate ->
                val outer = candidate.orderedNodeIds.mapNotNull(solved.nodes::get).map { LocalPoint(it.x, it.y) }
                val insideOuter = outer.size >= 3 && Geometry.pointInPolygon(local, outer)
                val insideHole = candidate.holeNodeIdLoops.any { loop ->
                    val hole = loop.mapNotNull(solved.nodes::get).map { LocalPoint(it.x, it.y) }
                    hole.size >= 3 && Geometry.pointInPolygon(local, hole)
                }
                insideOuter && !insideHole
            } ?: return@forEach
            val plane = face.plane ?: return@forEach
            val width = when (item.type) {
                ObjectType.VENT -> item.diameterMm
                else -> item.widthMm
            }.coerceAtLeast(100.0) / 1000.0
            val depth = when (item.type) {
                ObjectType.VENT -> item.diameterMm
                else -> item.heightMm
            }.coerceAtLeast(100.0) / 1000.0
            val shellHeight = when (item.type) {
                ObjectType.CHIMNEY -> (item.value.takeIf { it > 0.0 } ?: 0.8).coerceIn(0.2, 8.0)
                ObjectType.HATCH -> 0.18
                ObjectType.VENT -> 0.35
                else -> 0.045
            }
            val angle = Math.toRadians(item.rotationDeg)
            val cos = kotlin.math.cos(angle); val sin = kotlin.math.sin(angle)
            fun corner(dx: Double, dy: Double, top: Boolean): RoofVec3 {
                val x = local.x + dx * cos - dy * sin
                val y = local.y + dx * sin + dy * cos
                return point(GraphNode("object", x, y, plane.zAt(x, y) + if (top) shellHeight else 0.012))
            }
            val bottom = listOf(
                corner(-width / 2, -depth / 2, false), corner(width / 2, -depth / 2, false),
                corner(width / 2, depth / 2, false), corner(-width / 2, depth / 2, false)
            )
            val top = listOf(
                corner(-width / 2, -depth / 2, true), corner(width / 2, -depth / 2, true),
                corner(width / 2, depth / 2, true), corner(-width / 2, depth / 2, true)
            )
            addTriangle(positions, normals, materials, top[0], top[1], top[2], material = 0f)
            addTriangle(positions, normals, materials, top[0], top[2], top[3], material = 0f)
            repeat(4) { index ->
                val next = (index + 1) % 4
                addTriangle(positions, normals, materials, bottom[index], bottom[next], top[next], material = 0f)
                addTriangle(positions, normals, materials, bottom[index], top[next], top[index], material = 0f)
                addLine(edges, top[index], top[next])
            }
        }
        val logoFaceCount = addCompanyLogos(solved, span, ::point, logoQuads)
        return RoofMesh(
            positions.toFloatArray(), normals.toFloatArray(), edges.toFloatArray(),
            materials.toFloatArray(), logoEdges.toFloatArray(), logoQuads, displayDimensions, logoFaceCount
        )
    }

    /** Deterministic ear clipping for a simple face; unlike triangle fans it is safe for concave polygons. */
    private fun earClip(polygon: List<LocalPoint>): List<Triangle> {
        if (polygon.size < 3) return emptyList()
        fun cross2(a: LocalPoint, b: LocalPoint, c: LocalPoint) =
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        val signedArea = polygon.indices.sumOf { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            a.x * b.y - b.x * a.y
        }
        val indices = if (signedArea >= 0.0) polygon.indices.toMutableList()
        else polygon.indices.reversed().toMutableList()
        fun inside(p: LocalPoint, a: LocalPoint, b: LocalPoint, c: LocalPoint): Boolean {
            val ab = cross2(a, b, p)
            val bc = cross2(b, c, p)
            val ca = cross2(c, a, p)
            return ab >= -1e-8 && bc >= -1e-8 && ca >= -1e-8
        }
        val result = mutableListOf<Triangle>()
        var guard = 0
        while (indices.size > 3 && guard++ < polygon.size * polygon.size) {
            var clipped = false
            for (position in indices.indices) {
                val previous = indices[(position - 1 + indices.size) % indices.size]
                val current = indices[position]
                val next = indices[(position + 1) % indices.size]
                val a = polygon[previous]
                val b = polygon[current]
                val c = polygon[next]
                if (cross2(a, b, c) <= 1e-8) continue
                if (indices.any { candidate ->
                        candidate != previous && candidate != current && candidate != next &&
                            inside(polygon[candidate], a, b, c)
                    }
                ) continue
                result += Triangle(previous, current, next)
                indices.removeAt(position)
                clipped = true
                break
            }
            if (!clipped) return emptyList()
        }
        if (indices.size == 3 && abs(cross2(polygon[indices[0]], polygon[indices[1]], polygon[indices[2]])) > 1e-8) {
            result += Triangle(indices[0], indices[1], indices[2])
        }
        return result
    }

    private fun buildSurfaceSamples(
        polygon: List<LocalPoint>,
        lines: List<Triple<LineType, LocalPoint, LocalPoint>>,
        maxSpan: Double,
        wallHeight: Double,
        height: (LocalPoint) -> Double
    ): List<HeightPoint> {
        val spacing = (maxSpan / 11.0).coerceAtLeast(0.35)
        val points = mutableListOf<LocalPoint>()
        fun addUnique(point: LocalPoint) {
            if (points.none { hypot(it.x - point.x, it.y - point.y) < spacing * 0.08 }) points += point
        }
        polygon.indices.forEach { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(1, kotlin.math.ceil(length / spacing).toInt())
            for (step in 0 until count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        lines.forEach { (_, a, b) ->
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(2, kotlin.math.ceil(length / (spacing * 0.55)).toInt())
            for (step in 0..count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        val minX = polygon.minOf { it.x }
        val maxX = polygon.maxOf { it.x }
        val minY = polygon.minOf { it.y }
        val maxY = polygon.maxOf { it.y }
        var y = minY + spacing * 0.5
        while (y < maxY) {
            var x = minX + spacing * 0.5
            while (x < maxX) {
                val p = LocalPoint(x, y)
                if (Geometry.pointInPolygon(p, polygon)) addUnique(p)
                x += spacing
            }
            y += spacing
        }
        return points.map { HeightPoint(it, max(wallHeight, height(it))) }
    }

    private fun delaunay(points: List<LocalPoint>, polygon: List<LocalPoint>): List<Triangle> {
        if (points.size < 3) return emptyList()
        val all = points.toMutableList()
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val span = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
        val midX = (minX + maxX) / 2.0
        val midY = (minY + maxY) / 2.0
        val originalCount = all.size
        all += LocalPoint(midX - span * 20, midY - span * 10)
        all += LocalPoint(midX, midY + span * 20)
        all += LocalPoint(midX + span * 20, midY - span * 10)
        val triangles = mutableListOf(Triangle(originalCount, originalCount + 1, originalCount + 2))
        for (index in 0 until originalCount) {
            val bad = triangles.filter { circumcircleContains(all, it, all[index]) }
            val counts = linkedMapOf<Edge, Int>()
            bad.forEach { triangle ->
                listOf(Edge(triangle.a, triangle.b), Edge(triangle.b, triangle.c), Edge(triangle.c, triangle.a))
                    .map { it.normalized() }
                    .forEach { edge -> counts[edge] = (counts[edge] ?: 0) + 1 }
            }
            triangles.removeAll(bad.toSet())
            counts.filterValues { it == 1 }.keys.forEach { edge -> triangles += Triangle(edge.a, edge.b, index) }
        }
        return triangles.filter { triangle ->
            triangle.a < originalCount && triangle.b < originalCount && triangle.c < originalCount &&
                Geometry.pointInPolygon(
                    LocalPoint(
                        (all[triangle.a].x + all[triangle.b].x + all[triangle.c].x) / 3.0,
                        (all[triangle.a].y + all[triangle.b].y + all[triangle.c].y) / 3.0
                    ),
                    polygon
                )
        }
    }

    private fun circumcircleContains(points: List<LocalPoint>, triangle: Triangle, point: LocalPoint): Boolean {
        val a = points[triangle.a]
        val b = points[triangle.b]
        val c = points[triangle.c]
        val d = 2.0 * (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y))
        if (abs(d) < 1e-9) return false
        val a2 = a.x * a.x + a.y * a.y
        val b2 = b.x * b.x + b.y * b.y
        val c2 = c.x * c.x + c.y * c.y
        val ux = (a2 * (b.y - c.y) + b2 * (c.y - a.y) + c2 * (a.y - b.y)) / d
        val uy = (a2 * (c.x - b.x) + b2 * (a.x - c.x) + c2 * (b.x - a.x)) / d
        val radius2 = (ux - a.x) * (ux - a.x) + (uy - a.y) * (uy - a.y)
        val pointDistance2 = (ux - point.x) * (ux - point.x) + (uy - point.y) * (uy - point.y)
        return pointDistance2 <= radius2 + 1e-7
    }

    /** Two shared dimensions are sufficient for an orthogonal four-sided plan. */
    private fun collapseSymmetricBoundaryDimensions(
        graph: RoofGraph,
        raw: List<RoofDimension3D>
    ): List<RoofDimension3D> {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology())?.second ?: return raw
        if (ordered.size != 4) return raw
        val byId = raw.associateBy { it.edgeId }
        fun direction(edge: TopologyEdge): Double {
            val a = graph.nodes.getValue(edge.startNodeId)
            val b = graph.nodes.getValue(edge.endNodeId)
            return atan2(b.y - a.y, b.x - a.x)
        }
        fun angularDistance(a: Double, b: Double): Double {
            var delta = abs(a - b) % PI
            if (delta > PI / 2.0) delta = PI - delta
            return abs(delta)
        }
        val directions = ordered.map(::direction)
        val tolerance = Math.toRadians(10.0)
        val oppositeParallel = angularDistance(directions[0], directions[2]) <= tolerance &&
            angularDistance(directions[1], directions[3]) <= tolerance
        val adjacentOrthogonal = abs(angularDistance(directions[0], directions[1]) - PI / 2.0) <= tolerance
        if (!oppositeParallel || !adjacentOrthogonal) return raw
        val pairs = listOf(0 to 2, 1 to 3)
        return pairs.flatMap { (firstIndex, secondIndex) ->
            val first = byId[ordered[firstIndex].id] ?: return raw
            val second = byId[ordered[secondIndex].id] ?: return raw
            val relativeDifference = abs(first.lengthM - second.lengthM) /
                max(first.lengthM, second.lengthM).coerceAtLeast(1e-9)
            if (relativeDifference > 0.15) return raw
            val dimensionId = "paired-${first.edgeId}-${second.edgeId}"
            val linked = listOf(first.edgeId, second.edgeId)
            val sharedLength = (first.lengthM + second.lengthM) / 2.0
            listOf(
                first.copy(dimensionId = dimensionId, linkedEdgeIds = linked, lengthM = sharedLength),
                second.copy(dimensionId = dimensionId, linkedEdgeIds = linked, lengthM = sharedLength)
            )
        }.takeIf { it.size == 4 } ?: raw
    }

    /** Textured company-logo planes placed above the two largest roof faces. */
    private fun addCompanyLogos(
        graph: RoofGraph,
        span: Double,
        point: (GraphNode, Double) -> RoofVec3,
        output: MutableList<RoofLogoQuad>
    ): Int {
        fun area(face: GraphFace): Double {
            val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            if (nodes.size < 3) return 0.0
            return kotlin.math.abs(nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            } / 2.0)
        }
        var renderedFaces = 0
        graph.faces.values.sortedByDescending(::area).take(2).forEach { face ->
            val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            val plane = face.plane ?: return@forEach
            if (nodes.size < 3) return@forEach
            val longest = nodes.indices.map { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                Triple(a, b, hypot(b.x - a.x, b.y - a.y))
            }.maxByOrNull { it.third } ?: return@forEach
            if (longest.third < 1e-6) return@forEach
            var ux = (longest.second.x - longest.first.x) / longest.third
            var uy = (longest.second.y - longest.first.y) / longest.third
            // Edge IDs and face cycles may run in either direction. Canonicalising the logo
            // baseline prevents the bitmap/text from being placed as a mirror image when the
            // same physical face is reconstructed with reversed topology winding.
            if (ux < -1e-9 || (abs(ux) <= 1e-9 && uy < 0.0)) {
                ux = -ux
                uy = -uy
            }
            val vx = -uy
            val vy = ux
            val polygon = nodes.map { LocalPoint(it.x, it.y) }
            val signed = nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            }
            var center = if (abs(signed) > 1e-9) {
                LocalPoint(
                    nodes.indices.sumOf { index ->
                        val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                        (a.x + b.x) * (a.x * b.y - b.x * a.y)
                    } / (3.0 * signed),
                    nodes.indices.sumOf { index ->
                        val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                        (a.y + b.y) * (a.x * b.y - b.x * a.y)
                    } / (3.0 * signed)
                )
            } else LocalPoint(nodes.map { it.x }.average(), nodes.map { it.y }.average())
            if (!Geometry.pointInPolygon(center, polygon)) {
                val triangle = earClip(polygon).maxByOrNull { candidate ->
                    abs((polygon[candidate.b].x - polygon[candidate.a].x) * (polygon[candidate.c].y - polygon[candidate.a].y) -
                        (polygon[candidate.b].y - polygon[candidate.a].y) * (polygon[candidate.c].x - polygon[candidate.a].x))
                }
                if (triangle != null) center = LocalPoint(
                    (polygon[triangle.a].x + polygon[triangle.b].x + polygon[triangle.c].x) / 3.0,
                    (polygon[triangle.a].y + polygon[triangle.b].y + polygon[triangle.c].y) / 3.0
                )
            }
            val centerX = center.x
            val centerY = center.y
            val clearance = polygon.indices.minOf { index ->
                Geometry.distanceToSegment(center, polygon[index], polygon[(index + 1) % polygon.size])
            }.coerceAtLeast(longest.third * 0.02)
            val logoWidth = minOf(longest.third * 0.60, clearance * 3.0)
            val logoHeight = logoWidth * 0.46
            val zLift = span * 0.004
            fun logoPoint(along: Double, across: Double): RoofVec3 {
                val x = centerX + ux * along + vx * across
                val y = centerY + uy * along + vy * across
                return point(GraphNode("logo", x, y, plane.zAt(x, y)), zLift)
            }
            output += RoofLogoQuad(
                faceId = face.id,
                topLeft = logoPoint(-logoWidth / 2.0, logoHeight / 2.0),
                topRight = logoPoint(logoWidth / 2.0, logoHeight / 2.0),
                bottomRight = logoPoint(logoWidth / 2.0, -logoHeight / 2.0),
                bottomLeft = logoPoint(-logoWidth / 2.0, -logoHeight / 2.0)
            )
            renderedFaces++
        }
        return renderedFaces
    }

    private fun addTriangle(
        positions: MutableList<Float>,
        normals: MutableList<Float>,
        materials: MutableList<Float>,
        a: RoofVec3,
        b: RoofVec3,
        c: RoofVec3,
        material: Float
    ) {
        var normal = normalized(cross(b - a, c - a))
        if (normal.y < 0f) {
            normal = RoofVec3(-normal.x, -normal.y, -normal.z)
            addVertex(positions, a)
            addVertex(positions, c)
            addVertex(positions, b)
        } else {
            addVertex(positions, a)
            addVertex(positions, b)
            addVertex(positions, c)
        }
        repeat(3) { addVertex(normals, normal) }
        repeat(3) { materials += material }
    }

    private fun addLine(values: MutableList<Float>, a: RoofVec3, b: RoofVec3) {
        addVertex(values, a)
        addVertex(values, b)
    }

    private fun addVertex(values: MutableList<Float>, value: RoofVec3) {
        values += value.x
        values += value.y
        values += value.z
    }

    private fun cross(a: RoofVec3, b: RoofVec3) = RoofVec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )

    private fun normalized(value: RoofVec3): RoofVec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) RoofVec3(0f, 1f, 0f)
        else RoofVec3(value.x / length, value.y / length, value.z / length)
    }
}

private class Roof3DRenderer : GLSurfaceView.Renderer {
    private data class ProjectedPoint(val point: PointF, val depth: Float)
    @Volatile private var pendingMesh = RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
    @Volatile var yawDegrees = -34f
    @Volatile var pitchDegrees = 28f
    @Volatile var zoom = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f

    private var width = 1
    private var height = 1
    private var surfaceProgram = 0
    private var edgeProgram = 0
    private var logoProgram = 0
    private var logoTexture = 0
    private var triangleVbo = 0
    private var edgeVbo = 0
    private var logoVbo = 0
    private var triangleCount = 0
    private var edgeCount = 0
    private var logoCount = 0
    private var uploaded: RoofMesh? = null

    fun setProject(project: RoofProject) {
        pendingMesh = RoofMeshBuilder.build(project)
    }

    fun resetView() {
        yawDegrees = -34f
        pitchDegrees = 28f
        zoom = 1f
        panX = 0f
        panY = 0f
    }

    fun projectDimensions(viewWidth: Int, viewHeight: Int): List<ProjectedRoofDimension> {
        val mesh = pendingMesh
        if (mesh.dimensions.isEmpty()) return emptyList()
        val model = FloatArray(16)
        val mvp = buildMvp(model, viewWidth, viewHeight)
        fun project(point: RoofVec3): ProjectedPoint? {
            val source = floatArrayOf(point.x, point.y, point.z, 1f)
            val clip = FloatArray(4)
            Matrix.multiplyMV(clip, 0, mvp, 0, source, 0)
            val w = clip[3]
            if (!w.isFinite() || w <= 0.0001f) return null
            val ndcX = clip[0] / w
            val ndcY = clip[1] / w
            if (!ndcX.isFinite() || !ndcY.isFinite()) return null
            return ProjectedPoint(
                PointF(
                    (ndcX * 0.5f + 0.5f) * viewWidth,
                    (0.5f - ndcY * 0.5f) * viewHeight
                ),
                clip[2] / w
            )
        }
        val projectedTriangles = buildList {
            var offset = 0
            while (offset + 8 < mesh.triangles.size) {
                val a = project(RoofVec3(mesh.triangles[offset], mesh.triangles[offset + 1], mesh.triangles[offset + 2]))
                val b = project(RoofVec3(mesh.triangles[offset + 3], mesh.triangles[offset + 4], mesh.triangles[offset + 5]))
                val c = project(RoofVec3(mesh.triangles[offset + 6], mesh.triangles[offset + 7], mesh.triangles[offset + 8]))
                if (a != null && b != null && c != null) add(Triple(a, b, c))
                offset += 9
            }
        }
        fun triangleDepthAt(sample: PointF, triangle: Triple<ProjectedPoint, ProjectedPoint, ProjectedPoint>): Float? {
            val a = triangle.first; val b = triangle.second; val c = triangle.third
            val denominator = (b.point.y - c.point.y) * (a.point.x - c.point.x) +
                (c.point.x - b.point.x) * (a.point.y - c.point.y)
            if (abs(denominator) < 1e-5f) return null
            val wa = ((b.point.y - c.point.y) * (sample.x - c.point.x) +
                (c.point.x - b.point.x) * (sample.y - c.point.y)) / denominator
            val wb = ((c.point.y - a.point.y) * (sample.x - c.point.x) +
                (a.point.x - c.point.x) * (sample.y - c.point.y)) / denominator
            val wc = 1f - wa - wb
            if (wa < -0.002f || wb < -0.002f || wc < -0.002f) return null
            return wa * a.depth + wb * b.depth + wc * c.depth
        }
        fun isOccluded(sample: ProjectedPoint): Boolean = projectedTriangles.any { triangle ->
            val surfaceDepth = triangleDepthAt(sample.point, triangle) ?: return@any false
            surfaceDepth < sample.depth - 0.003f
        }
        val modelCenter = project(RoofVec3(0f, 0f, 0f))?.point ?: PointF(viewWidth / 2f, viewHeight / 2f)
        val visible = mesh.dimensions.mapNotNull { dimension ->
            val witnessStart = project(dimension.witnessStart) ?: return@mapNotNull null
            val witnessEnd = project(dimension.witnessEnd) ?: return@mapNotNull null
            val middle = project(RoofVec3(
                (dimension.witnessStart.x + dimension.witnessEnd.x) / 2f,
                (dimension.witnessStart.y + dimension.witnessEnd.y) / 2f,
                (dimension.witnessStart.z + dimension.witnessEnd.z) / 2f
            )) ?: return@mapNotNull null
            if (isOccluded(middle)) return@mapNotNull null
            ProjectedRoofDimension(
                dimensionId = dimension.dimensionId,
                edgeId = dimension.edgeId,
                linkedEdgeIds = dimension.linkedEdgeIds,
                kind = dimension.kind,
                start = project(dimension.start)?.point ?: return@mapNotNull null,
                end = project(dimension.end)?.point ?: return@mapNotNull null,
                witnessStart = witnessStart.point,
                witnessEnd = witnessEnd.point,
                lengthM = dimension.lengthM,
                modelCenter = modelCenter
            )
        }
        // Height and slope supply candidates on multiple faces. Keep the clearest visible one,
        // rather than drawing duplicate technical dimensions over one another.
        return visible.groupBy { it.dimensionId }.values.map { candidates ->
            candidates.maxBy { dimension ->
                hypot(
                    dimension.witnessEnd.x - dimension.witnessStart.x,
                    dimension.witnessEnd.y - dimension.witnessStart.y
                )
            }
        }
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.962f, 0.968f, 0.970f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        surfaceProgram = createProgram(SURFACE_VERTEX, SURFACE_FRAGMENT)
        edgeProgram = createProgram(EDGE_VERTEX, EDGE_FRAGMENT)
        logoProgram = createProgram(LOGO_VERTEX, LOGO_FRAGMENT)
        logoTexture = createLogoTexture()
        val buffers = IntArray(3)
        GLES30.glGenBuffers(3, buffers, 0)
        triangleVbo = buffers[0]
        edgeVbo = buffers[1]
        logoVbo = buffers[2]
        uploaded = null
    }

    override fun onSurfaceChanged(gl: GL10?, widthValue: Int, heightValue: Int) {
        width = max(1, widthValue)
        height = max(1, heightValue)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (triangleCount == 0) return
        val model = FloatArray(16)
        val mvp = buildMvp(model, width, height)
        drawSurfaces(model, mvp)
        drawEdges(mvp)
        drawLogos(mvp)
    }

    private fun buildMvp(model: FloatArray, viewWidth: Int, viewHeight: Int): FloatArray {
        val view = FloatArray(16)
        val projection = FloatArray(16)
        val viewProjection = FloatArray(16)
        val mvp = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, zoom, zoom, zoom)
        Matrix.translateM(model, 0, panX, panY, 0f)
        Matrix.setLookAtM(view, 0, 0f, 0.35f, 5.2f, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projection, 0, 34f, viewWidth.toFloat() / viewHeight.coerceAtLeast(1), 0.1f, 20f)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)
        return mvp
    }

    private fun uploadIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploaded) return
        val vertexCount = mesh.triangles.size / 3
        val interleaved = FloatArray(vertexCount * 7)
        var source = 0
        var target = 0
        while (source < mesh.triangles.size) {
            val vertexIndex = source / 3
            interleaved[target++] = mesh.triangles[source]
            interleaved[target++] = mesh.triangles[source + 1]
            interleaved[target++] = mesh.triangles[source + 2]
            interleaved[target++] = mesh.normals[source]
            interleaved[target++] = mesh.normals[source + 1]
            interleaved[target++] = mesh.normals[source + 2]
            interleaved[target++] = mesh.materials.getOrElse(vertexIndex) { 1f }
            source += 3
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, interleaved.size * 4, interleaved.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        triangleCount = mesh.triangles.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, mesh.edges.size * 4, mesh.edges.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        edgeCount = mesh.edges.size / 3
        val logoVertices = arrayListOf<Float>()
        fun logoVertex(point: RoofVec3, u: Float, v: Float) {
            logoVertices += point.x; logoVertices += point.y; logoVertices += point.z
            logoVertices += u; logoVertices += v
        }
        mesh.logoQuads.forEach { quad ->
            val leftU = StrechoStavLogo.roofSurfaceU(left = true)
            val rightU = StrechoStavLogo.roofSurfaceU(left = false)
            logoVertex(quad.topLeft, leftU, 0f)
            logoVertex(quad.topRight, rightU, 0f)
            logoVertex(quad.bottomRight, rightU, 1f)
            logoVertex(quad.topLeft, leftU, 0f)
            logoVertex(quad.bottomRight, rightU, 1f)
            logoVertex(quad.bottomLeft, leftU, 1f)
        }
        val logoArray = logoVertices.toFloatArray()
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, logoVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, logoArray.size * 4, logoArray.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        logoCount = logoArray.size / 5
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        uploaded = mesh
    }

    private fun drawSurfaces(model: FloatArray, mvp: FloatArray) {
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uModel"), 1, false, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uColor"), 0.145f, 0.166f, 0.178f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uLight"), -0.42f, 0.72f, 0.86f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        val material = GLES30.glGetAttribLocation(surfaceProgram, "aMaterial")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(normal)
        GLES30.glEnableVertexAttribArray(material)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 28, 0)
        GLES30.glVertexAttribPointer(normal, 3, GLES30.GL_FLOAT, false, 28, 12)
        GLES30.glVertexAttribPointer(material, 1, GLES30.GL_FLOAT, false, 28, 24)
        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, triangleCount)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(normal)
        GLES30.glDisableVertexAttribArray(material)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(edgeProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform4f(GLES30.glGetUniformLocation(edgeProgram, "uColor"), 0.055f, 0.065f, 0.070f, 0.98f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glLineWidth(1.5f)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeCount)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
    }

    private fun drawLogos(mvp: FloatArray) {
        if (logoCount == 0) return
        GLES30.glUseProgram(logoProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(logoProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, logoTexture)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(logoProgram, "uLogo"), 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, logoVbo)
        val position = GLES30.glGetAttribLocation(logoProgram, "aPosition")
        val uv = GLES30.glGetAttribLocation(logoProgram, "aUv")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(uv)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 20, 0)
        GLES30.glVertexAttribPointer(uv, 2, GLES30.GL_FLOAT, false, 20, 12)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, logoCount)
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(uv)
    }

    private fun createLogoTexture(): Int {
        val textures = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val bitmap = StrechoStavLogo.bitmap()
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()
        return textures[0]
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragment)
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL program: ${GLES30.glGetProgramInfoLog(program)}" }
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return program
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL shader: ${GLES30.glGetShaderInfoLog(shader)}" }
        return shader
    }

    private fun FloatArray.nativeBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(this@nativeBuffer)
            position(0)
        }

    companion object {
        private const val SURFACE_VERTEX = """
            #version 300 es
            uniform mat4 uModel;
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec3 aNormal;
            in float aMaterial;
            out vec3 vNormal;
            out vec3 vPosition;
            out float vRoofMix;
            void main() {
                vNormal = mat3(uModel) * aNormal;
                // Material grain is anchored to the model and must not shimmer
                // or change when the user rotates the camera.
                vPosition = aPosition;
                vRoofMix = aMaterial;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val SURFACE_FRAGMENT = """
            #version 300 es
            precision highp float;
            uniform vec3 uColor;
            uniform vec3 uLight;
            in vec3 vNormal;
            in vec3 vPosition;
            in float vRoofMix;
            out vec4 outColor;
            float hash31(vec3 p) {
                return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
            }
            void main() {
                vec3 normal = normalize(vNormal);
                if (!gl_FrontFacing) normal = -normal;
                vec3 keyLight = normalize(uLight);
                vec3 fillLight = normalize(vec3(0.55, -0.25, 0.48));
                float diffuse = max(dot(normal, keyLight), 0.0);
                float fill = max(dot(normal, fillLight), 0.0);
                float roofMix = clamp(vRoofMix, 0.0, 1.0);
                float mineral = hash31(floor(vPosition * 72.0));
                float fine = hash31(floor(vPosition * 215.0) + vec3(7.0, 3.0, 11.0));
                float materialVariation = 1.000 + (mineral - 0.5) * 0.040 + (fine - 0.5) * 0.020;
                vec3 roofColor = uColor * materialVariation;
                vec3 wallColor = vec3(0.910, 0.855, 0.745);
                // Material plus camera lighting stays within an approximately 20% anthracite range.
                float roofShade = clamp(0.960 + diffuse * 0.070 + fill * 0.010, 0.960, 1.040);
                float wallShade = clamp(0.82 + diffuse * 0.16 + fill * 0.04, 0.80, 1.0);
                vec3 baseColor = mix(wallColor, roofColor, roofMix);
                float shade = mix(wallShade, roofShade, roofMix);
                vec3 color = baseColor * shade;
                outColor = vec4(color, 1.0);
            }
        """
        private const val EDGE_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            void main() { gl_Position = uMvp * vec4(aPosition, 1.0); }
        """
        private const val EDGE_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform vec4 uColor;
            out vec4 outColor;
            void main() { outColor = uColor; }
        """
        private const val LOGO_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec2 aUv;
            out vec2 vUv;
            void main() {
                vUv = aUv;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val LOGO_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform sampler2D uLogo;
            in vec2 vUv;
            out vec4 outColor;
            void main() {
                // A roof logo has only a printable outer side. Rendering its back face would
                // show the lettering mirrored, like looking through transparent foil.
                if (!gl_FrontFacing) discard;
                vec4 logo = texture(uLogo, vUv);
                if (logo.a < 0.04) discard;
                outColor = logo;
            }
        """
    }
}
