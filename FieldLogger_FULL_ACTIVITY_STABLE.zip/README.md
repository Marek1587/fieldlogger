# FieldLogger FULL ACTIVITY STABLE

Stable version.

## Output

Primary:
- /storage/emulated/0/Download/field_logger/

Fallback if Android blocks public write:
- Android/data/sk.strechostav.fieldlogger/files/field_logger/

## Features

- manual field notes
- GPS
- camera + compressed photo
- share CSV
- background Usage Access foreground-app logging
- crash-resistant CSV writes
