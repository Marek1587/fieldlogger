plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.strechostav.fieldlogger"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.fieldlogger"
        minSdk = 26
        targetSdk = 28
        versionCode = 6
        versionName = "0.6-stable"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
