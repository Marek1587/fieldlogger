package sk.strechostav.fieldlogger

import android.content.Context
import android.location.Location
import android.os.Environment
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvStore {
    private val header = listOf(
        "timestamp",
        "event_type",
        "lat",
        "lon",
        "accuracy_m",
        "provider",
        "title",
        "note",
        "package_name",
        "app_name",
        "photo_path"
    )

    fun publicBaseDir(): File {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val d = File(downloads, "field_logger")
        d.mkdirs()
        return d
    }

    fun fallbackBaseDir(context: Context): File {
        val d = File(context.getExternalFilesDir(null), "field_logger")
        d.mkdirs()
        return d
    }

    fun baseDir(context: Context): File {
        return try {
            val d = publicBaseDir()
            val test = File(d, ".write_test")
            test.writeText("ok", Charsets.UTF_8)
            test.delete()
            d
        } catch (_: Exception) {
            fallbackBaseDir(context)
        }
    }

    fun photoDir(context: Context): File {
        val d = File(baseDir(context), "photos")
        d.mkdirs()
        return d
    }

    fun csvFile(context: Context): File {
        val f = File(baseDir(context), "field_activity_log.csv")
        if (!f.exists()) {
            f.writeText(header.joinToString(";") + "\\n", Charsets.UTF_8)
        }
        return f
    }

    fun now(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    }

    fun stamp(): String {
        return SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    }

    fun append(
        context: Context,
        eventType: String,
        title: String,
        note: String = "",
        location: Location? = null,
        packageName: String = "",
        appName: String = "",
        photoPath: String = ""
    ): Boolean {
        return try {
            val values = listOf(
                now(),
                eventType,
                location?.latitude?.toString() ?: "",
                location?.longitude?.toString() ?: "",
                location?.accuracy?.toString() ?: "",
                location?.provider ?: "",
                title,
                note,
                packageName,
                appName,
                photoPath
            )
            val row = values.joinToString(";") { csvEscape(it) }
            csvFile(context).appendText(row + "\\n", Charsets.UTF_8)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun csvEscape(value: String): String {
        val x = value.replace("\\n", " ").replace("\\r", " ").trim()
        val needsQuotes = x.contains(';') || x.contains('"')
        return if (needsQuotes) {
            val escaped = x.replace("\"", "\"\"")
            "\"" + escaped + "\""
        } else {
            x
        }
    }
}
