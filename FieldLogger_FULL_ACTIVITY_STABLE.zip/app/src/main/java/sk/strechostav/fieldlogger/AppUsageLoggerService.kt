package sk.strechostav.fieldlogger

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class AppUsageLoggerService : Service() {
    private val channelId = "field_logger_activity"
    private val notificationId = 5101
    private val handler = Handler(Looper.getMainLooper())
    private var lastPackage: String = ""
    private var lastWriteMillis: Long = 0L

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                pollForegroundApp()
            } catch (_: Exception) {
                // Nikdy nenecháme službu spadnúť pre jednu chybu čítania.
            }
            handler.postDelayed(this, 15_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startForeground(notificationId, buildNotification())
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        safeAppend("MOBILE_LOGGER_START", "Spustený mobilný activity logger", "Sleduje aktívnu aplikáciu cez Usage Access.")

        handler.removeCallbacks(pollRunnable)
        handler.postDelayed(pollRunnable, 1000L)

        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        safeAppend("MOBILE_LOGGER_STOP", "Zastavený mobilný activity logger", "Služba bola ukončená.")
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun safeAppend(eventType: String, title: String, note: String = "", pkg: String = "", appName: String = "") {
        try {
            CsvStore.append(
                context = this,
                eventType = eventType,
                title = title,
                note = note,
                location = bestLocation(),
                packageName = pkg,
                appName = appName
            )
        } catch (_: Exception) {}
    }

    private fun pollForegroundApp() {
        val pkg = currentForegroundPackage()
        if (pkg.isBlank()) return

        val now = System.currentTimeMillis()
        val shouldWrite = pkg != lastPackage || (now - lastWriteMillis) > 5 * 60 * 1000L
        if (!shouldWrite) return

        val appName = appLabel(pkg)

        safeAppend(
            eventType = "APP_FOREGROUND",
            title = "Aktívna aplikácia",
            pkg = pkg,
            appName = appName
        )

        lastPackage = pkg
        lastWriteMillis = now
    }

    private fun currentForegroundPackage(): String {
        return try {
            val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                now - 60_000L,
                now
            )
            if (stats.isNullOrEmpty()) "" else stats.maxByOrNull { it.lastTimeUsed }?.packageName ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun appLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        if (
            checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
        ) return null

        return try {
            lm.getProviders(true)
                .mapNotNull { provider ->
                    try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null }
                }
                .maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        return builder
            .setContentTitle("Field Logger beží")
            .setContentText("Logujem aktívnu aplikáciu do CSV.")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(channelId, "Field Logger Activity", NotificationManager.IMPORTANCE_LOW)
        channel.description = "Mobilný activity logger na pozadí."
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(channel)
    }
}
