const assert = require("node:assert/strict");
const test = require("node:test");
const Solver = require("../app/src/main/assets/geometry-solver.js");
const Drawing = require("../app/src/main/assets/technical-drawing.js");
const {TechnicalDrawingModel,TechnicalDrawingRenderer,DrawingStyle,EntityType}=Drawing;
const P=Drawing.geometry.p,render=model=>new TechnicalDrawingRenderer().render(model);

test("UHĽOVANIE A: predvolené rozmery vytvoria platný lichobežník",()=>{
  assert.equal(typeof Solver.GeometryConstraintSolver,"function");assert.equal(typeof Solver.ProportionalGeometryAdjuster,"function");assert.equal(typeof Solver.ConstraintOptimization,"function");
  const manager=new Solver.UserDimensionLockManager({l1:450000,l2:300000,d1:520000,d2:470000});assert.equal(manager.solve().ok,true);
});

test("UHĽOVANIE B: zmena 4500 na 9000 zachová lock a zdvojnásobí nezamknuté rozmery",()=>{
  const manager=new Solver.UserDimensionLockManager({l1:450000,l2:300000,d1:520000,d2:470000}),result=manager.edit("l1",900000,100);
  assert.equal(result.ok,true);assert.equal(result.values.l1,900000);assert.equal(result.states.l1.source,"user");assert.equal(result.states.l1.isUserLocked,true);assert.equal(result.values.l2,600000);assert.equal(result.values.d1,1040000);assert.equal(result.values.d2,940000);
});

test("UHĽOVANIE C: dve ručne zadané hodnoty ostanú presne zachované",()=>{
  const manager=new Solver.UserDimensionLockManager({l1:450000,l2:300000,d1:520000,d2:470000});manager.edit("l1",900000,100);const result=manager.edit("d1",700000,200);
  assert.equal(result.ok,true);assert.equal(result.values.l1,900000);assert.equal(result.values.d1,700000);assert.equal(result.states.l2.isUserLocked,false);assert.equal(result.states.d2.isUserLocked,false);
});

test("UHĽOVANIE D: tri ručné rozmery sa zachovajú a štvrtý sa optimalizuje",()=>{
  const manager=new Solver.UserDimensionLockManager({l1:450000,l2:300000,d1:520000,d2:470000});manager.edit("l1",900000,100);manager.edit("d1",700000,200);const result=manager.edit("l2",100000,300);
  assert.equal(result.ok,true);assert.equal(result.values.l1,900000);assert.equal(result.values.d1,700000);assert.equal(result.values.l2,100000);assert.equal(result.states.d2.source,"autoAdjusted");
});

test("UHĽOVANIE E: úplne zamknutá protirečivá sústava nič nemení a označí konflikty",()=>{
  const manager=new Solver.UserDimensionLockManager({l1:450000,l2:300000,d1:520000,d2:470000});manager.edit("l1",900000,100);manager.edit("d1",700000,200);manager.edit("l2",100000,300);const result=manager.edit("d2",100000,400);
  assert.equal(result.ok,false);assert.deepEqual(result.values,{l1:900000,l2:100000,d1:700000,d2:100000});assert.deepEqual(result.conflicts.sort(),["d1","d2","l1","l2"]);assert.match(result.errors[0],/geometricky odporujú/);
});

test("KOLMICA má presnú vertikálnu olovnicu aj po zmene vstupov a v exportnom SVG",()=>{
  for(const values of [{width:10000,angleDegrees:15},{width:18000,angleDegrees:42}]){const solved=Solver.solveSheetPerpendicular(values),model=Drawing.Adapters.slope(values,solved),plumb=model.entities.find(e=>e.type===EntityType.PlumbLine);assert.ok(plumb);assert.equal(plumb.plumbOrigin.x,plumb.plumbEnd.x);assert.ok(plumb.plumbOrigin.y>plumb.plumbEnd.y);assert.deepEqual(plumb.plumbDirection,{x:0,y:-1});const svg=render(model).svg;assert.match(svg,/id="centerline-layer"/);assert.match(svg,/td-plumb-line/);}
});

test("ZVODY a 3 KOLENÁ sú duté obrysy bez výplne so stredovou osou",()=>{
  const down=Solver.solveDownpipeOffset({x:72000,diameter:12000,insertion:5000,angleDegrees:72}),three=Solver.solveThreeElbowOffset({x:30000,diameter:12000,insertion:5000,alphaDegrees:10});
  for(const model of [Drawing.Adapters.downpipe(down),Drawing.Adapters.optimizer(three)]){const svg=render(model).svg;assert.match(svg,/td-pipe-assembly/);assert.ok((svg.match(/class="td-pipe-outline/g)||[]).length>=4);assert.match(svg,/td-center/);assert.doesNotMatch(svg,/fill\s*:\s*(black|#000)/i);assert.doesNotMatch(svg,/td-tube/);}
});

test("globálna typografia je čitateľná a SVG má oddelené vrstvy",()=>{
  assert.ok(DrawingStyle.dimensionFontSize>=22);assert.ok(DrawingStyle.noteFontSize>=18);assert.ok(DrawingStyle.angleFontSize>=DrawingStyle.dimensionFontSize);assert.ok(DrawingStyle.symbolFontSize>=DrawingStyle.dimensionFontSize);assert.ok(DrawingStyle.secondaryNoteFontSize>=14);
  const model=new TechnicalDrawingModel({viewport:{width:700,height:440}});model.geometry({points:[P(0,0),P(500,0)]});model.dimension({p1:P(0,0),p2:P(500,0),exactValue:500,displayValue:"500",semanticName:"test"});const svg=render(model).svg;for(const id of ["geometry-layer","centerline-layer","dimension-layer","annotation-layer"])assert.match(svg,new RegExp('id="'+id+'"'));
});
