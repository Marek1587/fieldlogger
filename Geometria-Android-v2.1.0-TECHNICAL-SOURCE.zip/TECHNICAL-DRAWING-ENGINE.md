# Technical drawing engine

Verzia 2.1 oddeľuje výpočtový stav a štyri kresliace vrstvy:

1. `geometry-solver.js` – presný výpočtový model v krokoch 0,01 mm,
2. `TechnicalDrawingModel` – sémantické objekty geometrie, kót, osí, odkazov a poznámok,
3. `DimensionLayoutEngine` – dráhy kót, odstraňovanie duplicít, textové obálky a detekcia kolízií,
4. `TechnicalDrawingRenderer` – spoločný responzívny SVG výstup pre všetky karty.

## Zámky rozmerov a záchrana geometrie

`UserDimensionLockManager` eviduje pri každom rozmere `value`, `source`, `isUserLocked` a `lastUserEditTimestamp`. Iba explicitná zmena používateľa vytvorí zámok. Pri neplatnom lichobežníku `ProportionalGeometryAdjuster` najprv škáluje nezamknuté rozmery pomerom poslednej zmeny a `solveRectangleSquaringConstrained` potom hľadá platnú geometriu s najmenšou váženou percentuálnou odchýlkou. Ručne uzamknuté hodnoty ostávajú presné.

## Referenčná geometria a potrubia

Olovnica modulu KOLMICA je sémantický objekt `PlumbLine` s presným počiatkom a zvislým smerom. Potrubné zostavy sa vykresľujú dvoma obrysovými hranami bez výplne; oblúky vychádzajú z osového polomeru a priemeru potrubia a stredová os má vlastný typ čiary.

SVG je členené na `geometry-layer`, `centerline-layer`, `dimension-layer` a `annotation-layer`. Veľkosti písma a pomery hrúbok čiar sú centrálne v `DrawingStyle`, aby boli rovnaké vo všetkých kartách aj pri exporte.

## Zasunutie v zostave troch kolien

Solver rozlišuje:

- `a`, `b`: dielenské rezné dĺžky vložených rúrok,
- `jointA`, `jointB`: skutočné osové vzdialenosti medzi tangentnými bodmi kolien po montáži.

Pre rúrku zasunutú o `I` na oboch koncoch platí:

`joint = cutLength - 2 × I`

Ak rúrka nie je potrebná a kolená sú spojené priamo, model používa prekrytie:

`joint = -I`

Takto sa zasunutie premieta do oboch súradníc X/Y a nie iba do textu reznej dĺžky. Model predpokladá, že deklarované zasunutie sa meria pozdĺž spoločnej osi hrdla. Pre výrobok s iným konštrukčným rozmerom stred–hrdlo treba použiť údaj konkrétneho výrobcu.

## Kresliace pravidlá

- rozmery sú v mm a jednotka sa vo výkrese deklaruje raz,
- dĺžkové kóty zobrazujú iba hodnotu,
- uhly používajú oblúk so šípkami a symbol `°`,
- priemer a polomer používajú `Ø` a `R`,
- obrys predmetu je minimálne dvojnásobne hrubší než kótovacie čiary,
- technický význam nie je závislý iba od farby,
- SVG používa nemennú hrúbku technických čiar pri responzívnom škálovaní.
