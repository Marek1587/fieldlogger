package sk.strechostav.pdfpodpisovac;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

final class SignatureDialog {
    interface Listener {
        void onSignatureReady(Bitmap bitmap);
    }

    private SignatureDialog() {
    }

    static void show(Context context, Listener listener) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                Ui.dp(context, 18),
                Ui.dp(context, 18),
                Ui.dp(context, 18),
                Ui.dp(context, 14)
        );
        root.setBackgroundColor(Color.WHITE);

        TextView title = Ui.text(context, "Podpíšte sa prstom", 21, Color.rgb(28, 36, 49));
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView help = Ui.text(
                context,
                "Podpis nakreslite do bieleho poľa. Sivá čiara je iba pomôcka a do PDF sa neuloží.",
                14,
                Color.rgb(80, 88, 102)
        );
        LinearLayout.LayoutParams helpParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        helpParams.topMargin = Ui.dp(context, 6);
        root.addView(help, helpParams);

        SignatureDrawView drawView = new SignatureDrawView(context);
        LinearLayout.LayoutParams drawParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(context, 260)
        );
        drawParams.topMargin = Ui.dp(context, 14);
        root.addView(drawView, drawParams);

        LinearLayout buttons = new LinearLayout(context);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END);

        Button clear = Ui.button(context, "Vymazať", false);
        Button cancel = Ui.button(context, "Zrušiť", false);
        Button use = Ui.button(context, "Použiť podpis", true);

        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        buttonParams.setMargins(Ui.dp(context, 6), Ui.dp(context, 14), 0, 0);
        buttons.addView(clear, buttonParams);
        buttons.addView(cancel, buttonParams);
        buttons.addView(use, buttonParams);
        root.addView(buttons);

        clear.setOnClickListener(view -> drawView.clearSignature());
        cancel.setOnClickListener(view -> dialog.dismiss());
        use.setOnClickListener(view -> {
            Bitmap bitmap = drawView.createTransparentSignature();
            if (bitmap == null) {
                Toast.makeText(context, "Najprv nakreslite podpis.", Toast.LENGTH_SHORT).show();
                return;
            }
            listener.onSignatureReady(bitmap);
            dialog.dismiss();
        });

        dialog.setContentView(root);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT
            );
            window.setGravity(Gravity.CENTER);
        }
    }
}
