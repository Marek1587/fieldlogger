# Latovanie 1.3.3

Kompletná offline Android aplikácia na náčrt strešných plôch, výpočet latovania,
optimalizáciu rezov zo 4 m lát a tvorbu dielenských výkresov.

## Hlavné funkcie

- obdĺžnik, lichobežník, trojuholník alebo voľne kreslený tvar,
- dotykové obvodové kóty s presným zadaním spoločným kolieskom po 5 mm,
- dotykové kóty každého rozostupu kontralát vrátane oboch okrajov,
- pridanie výhradne zvislej kontralaty pod latovaním ťuknutím na jej nové miesto a odobratie ťuknutím na existujúcu zvislú kontralatu; vodorovné rady latovania sa nemenia,
- koliesko bez minima a maxima, ktoré pri každej otáčke nepretržite pripočítava alebo odpočítava po 5 mm,
- nastaviteľný prierez, prvá lata a postupnosť modulov latovania,
- samostatný prvý rozostup a postupnosť ďalších rozostupov s opakovaním poslednej hodnoty,
- optimalizácia nových lát a opätovné použitie odrezkov,
- montážne tagy radov, kusovník a rezný plán,
- montážny register zoradený od hrebeňa v používateľom určenom smere spádu; zelená označuje diel z novej 4 m laty aj po skrátení a žltá iba diel použitý z odrezku,
- prácnosť latovania v titulnom bloku každého A4 výkresu podľa vzorca počet dielov × 0,10 + 2 NMH na prípravu a rozmeranie,
- pevné A4 výkresy 1240 × 1754 px nezávislé od šírky mobilu,
- tlač alebo uloženie všetkých výkresov do PDF cez samostatný A4 tlačový kontajner bez prázdnych úvodných strán,
- automatické lokálne uloženie rozpracovanej zákazky,
- bez internetu, účtu a servera.

## Zostavenie

Projekt vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2. Spustite:

```text
gradle :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

## Aktualizácie

Balík aplikácie je trvalo `sk.latovanie.app`. Všetky ďalšie verzie musia zvýšiť
`versionCode` a zostať podpísané súborom `app/latovanie-update-key.jks`.
Podrobnosti sú v `TRVALY-PODPIS-APK.txt`.
