package sk.strechasketch.app

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.abs
import kotlin.math.tan

/**
 * Invisible project-local construction grid.
 *
 * The grid is expressed in metres, never in screen pixels. Its origin and axis are persisted
 * in [RoofProject], therefore map zoom, map rotation and panning cannot move the lattice below
 * already created geometry. Only XY plan coordinates are quantized; solved elevations stay exact.
 */
object MetricPlanGrid {
    /** Confirmed masonry/outline geometry: dimensions are resolved in 50 mm increments. */
    const val STEP_M = 0.05
    /** Ridge, hip, valley and other non-boundary construction nodes use a finer 25 mm grid. */
    const val INTERNAL_STEP_M = 0.025
    private const val EPS = 1e-9

    fun ensureProjectFrame(project: RoofProject, candidates: List<GeoPoint> = emptyList()) {
        if (!project.geometryGridOriginLat.isFinite() || !project.geometryGridOriginLon.isFinite()) {
            val origin = project.roofGraph?.origin
                ?: project.roofTopology?.origin
                ?: candidates.firstOrNull()
                ?: project.polygon.firstOrNull()
                ?: project.lines.firstOrNull()?.start
                ?: GeoPoint(project.centerLat, project.centerLon)
            project.geometryGridOriginLat = origin.lat
            project.geometryGridOriginLon = origin.lon
        }
        if (!project.geometryGridRotationDeg.isFinite()) {
            val origin = projectOrigin(project)
            val source = when {
                candidates.size >= 2 -> candidates
                project.polygon.size >= 2 -> project.polygon
                else -> emptyList()
            }
            project.geometryGridRotationDeg = source.longestAxisDeg(origin)
                ?: project.roofGraph?.let(::axisDeg)
                ?: project.roofTopology?.let(::axisDeg)
                ?: 0.0
        }
        project.geometryGridRotationDeg = normalizeSquareAxis(project.geometryGridRotationDeg)
    }

    fun snap(project: RoofProject, point: GeoPoint, candidates: List<GeoPoint> = emptyList()): GeoPoint {
        ensureProjectFrame(project, candidates)
        val origin = projectOrigin(project)
        return Geometry.toGeo(
            snap(Geometry.toLocal(point, origin), project.geometryGridRotationDeg),
            origin
        )
    }

    fun snap(point: LocalPoint, rotationDeg: Double): LocalPoint {
        return snap(point, rotationDeg, STEP_M)
    }

    fun snapInternal(point: LocalPoint, rotationDeg: Double): LocalPoint {
        return snap(point, rotationDeg, INTERNAL_STEP_M)
    }

    fun snap(point: LocalPoint, rotationDeg: Double, stepM: Double): LocalPoint {
        require(stepM > 0.0 && stepM.isFinite())
        val angle = Math.toRadians(normalizeSquareAxis(rotationDeg))
        val c = cos(angle)
        val s = sin(angle)
        val u = point.x * c + point.y * s
        val v = -point.x * s + point.y * c
        val snappedU = quantize(u, stepM)
        val snappedV = quantize(v, stepM)
        return LocalPoint(
            x = clean(snappedU * c - snappedV * s),
            y = clean(snappedU * s + snappedV * c)
        )
    }

    fun snap(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return topology.copy(
            nodes = topology.nodes.map { node ->
                val point = snap(
                    LocalPoint(node.x, node.y), rotation,
                    if (node.id in boundaryNodeIds) STEP_M else INTERNAL_STEP_M
                )
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    fun snap(graph: RoofGraph): RoofGraph {
        val rotation = axisDeg(graph) ?: 0.0
        val boundaryNodeIds = graph.edges.values.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return graph.copy(
            nodes = graph.nodes.mapValues { (_, node) ->
                val point = snap(
                    LocalPoint(node.x, node.y), rotation,
                    if (node.id in boundaryNodeIds) STEP_M else INTERNAL_STEP_M
                )
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    /** Quantizes only internal nodes. The confirmed boundary is returned byte-for-byte unchanged. */
    fun snapInternal(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return topology.copy(
            nodes = topology.nodes.map { node ->
                if (node.id in boundaryNodeIds) node.copy()
                else snapInternal(LocalPoint(node.x, node.y), rotation).let { node.copy(x = it.x, y = it.y) }
            },
            edges = topology.edges.map { it.copy() },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    /**
     * Removes the tiny angular drift caused by independent 25 mm rounding.
     * Only non-boundary nodes may move. Ridges remain parallel to a grid axis and
     * hips/valleys remain on a 45 degree grid diagonal; the physical outline is immutable.
     */
    fun regularizeInternalDirections(
        topology: RoofTopology,
        angleToleranceDeg: Double = 10.0
    ): RoofTopology {
        val rotation = normalizeSquareAxis(axisDeg(topology) ?: 0.0)
        val angle = Math.toRadians(rotation)
        val c = cos(angle)
        val s = sin(angle)
        val boundaryIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val nodes = topology.nodes.associateBy { it.id }.toMutableMap()
        val tangent = tan(Math.toRadians(angleToleranceDeg.coerceIn(0.0, 44.0)))

        fun toGrid(node: TopologyNode): LocalPoint = LocalPoint(
            node.x * c + node.y * s,
            -node.x * s + node.y * c
        )
        fun fromGrid(id: String, point: LocalPoint): TopologyNode {
            val original = nodes.getValue(id)
            return original.copy(
                x = clean(point.x * c - point.y * s),
                y = clean(point.x * s + point.y * c)
            )
        }
        fun setCommonCoordinate(edge: TopologyEdge, horizontal: Boolean) {
            val a = nodes[edge.startNodeId] ?: return
            val b = nodes[edge.endNodeId] ?: return
            val ga = toGrid(a)
            val gb = toGrid(b)
            val aFixed = a.id in boundaryIds || a.locked
            val bFixed = b.id in boundaryIds || b.locked
            if (aFixed && bFixed) return
            val common = when {
                aFixed -> if (horizontal) ga.y else ga.x
                bFixed -> if (horizontal) gb.y else gb.x
                else -> quantize(if (horizontal) (ga.y + gb.y) / 2.0 else (ga.x + gb.x) / 2.0, INTERNAL_STEP_M)
            }
            if (!aFixed) nodes[a.id] = fromGrid(a.id, if (horizontal) ga.copy(y = common) else ga.copy(x = common))
            if (!bFixed) nodes[b.id] = fromGrid(b.id, if (horizontal) gb.copy(y = common) else gb.copy(x = common))
        }

        // Ridges first: they define the shared axis used by the roof-plane solver.
        topology.edges.filter { !it.boundary && it.type == LineType.RIDGE }.sortedBy { it.id }.forEach { edge ->
            val a = nodes[edge.startNodeId] ?: return@forEach
            val b = nodes[edge.endNodeId] ?: return@forEach
            val ga = toGrid(a)
            val gb = toGrid(b)
            val du = abs(gb.x - ga.x)
            val dv = abs(gb.y - ga.y)
            when {
                du > EPS && dv <= du * tangent + EPS -> setCommonCoordinate(edge, horizontal = true)
                dv > EPS && du <= dv * tangent + EPS -> setCommonCoordinate(edge, horizontal = false)
            }
        }

        // A boundary anchor lies on the 50 mm lattice, which is also an exact 25 mm point.
        // Moving the internal end by equal grid counts preserves a true plan angle of 45 degrees.
        topology.edges.filter {
            !it.boundary && it.type in setOf(LineType.HIP, LineType.VALLEY)
        }.sortedBy { it.id }.forEach { edge ->
            val a = nodes[edge.startNodeId] ?: return@forEach
            val b = nodes[edge.endNodeId] ?: return@forEach
            val anchor = when {
                a.id in boundaryIds && b.id !in boundaryIds -> a
                b.id in boundaryIds && a.id !in boundaryIds -> b
                else -> return@forEach
            }
            val mobile = if (anchor.id == a.id) b else a
            if (mobile.locked) return@forEach
            val ga = toGrid(anchor)
            val gm = toGrid(mobile)
            val du = gm.x - ga.x
            val dv = gm.y - ga.y
            val maximum = maxOf(abs(du), abs(dv))
            if (maximum <= EPS || abs(abs(du) - abs(dv)) > maximum * tangent + EPS) return@forEach
            val count = round(((abs(du) + abs(dv)) / 2.0) / INTERNAL_STEP_M).coerceAtLeast(1.0)
            val target = LocalPoint(
                ga.x + if (du < 0.0) -count * INTERNAL_STEP_M else count * INTERNAL_STEP_M,
                ga.y + if (dv < 0.0) -count * INTERNAL_STEP_M else count * INTERNAL_STEP_M
            )
            nodes[mobile.id] = fromGrid(mobile.id, target)
        }
        return topology.copy(nodes = topology.nodes.map { nodes[it.id] ?: it.copy() })
    }

    fun isOnGrid(point: LocalPoint, rotationDeg: Double, toleranceM: Double = 1e-7): Boolean {
        val snapped = snap(point, rotationDeg)
        return hypot(point.x - snapped.x, point.y - snapped.y) <= toleranceM
    }

    fun isOnInternalGrid(point: LocalPoint, rotationDeg: Double, toleranceM: Double = 1e-7): Boolean {
        val snapped = snapInternal(point, rotationDeg)
        return hypot(point.x - snapped.x, point.y - snapped.y) <= toleranceM
    }

    fun axisDeg(topology: RoofTopology): Double? {
        topology.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val nodes = topology.nodes.associateBy { it.id }
        return topology.edges.asSequence().filter { it.boundary }.mapNotNull { edge ->
            val a = nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = nodes[edge.endNodeId] ?: return@mapNotNull null
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    fun axisDeg(graph: RoofGraph): Double? {
        graph.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val topology = graph.toTopology()
        return axisDeg(topology)
    }

    private fun List<GeoPoint>.longestAxisDeg(origin: GeoPoint): Double? {
        if (size < 2) return null
        return indices.mapNotNull { index ->
            val a = Geometry.toLocal(this[index], origin)
            val b = Geometry.toLocal(this[(index + 1) % size], origin)
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    private fun projectOrigin(project: RoofProject) =
        GeoPoint(project.geometryGridOriginLat, project.geometryGridOriginLon)

    private fun quantize(value: Double, stepM: Double): Double = round(value / stepM) * stepM

    private fun clean(value: Double): Double = if (kotlin.math.abs(value) < EPS) 0.0 else value

    private fun normalizeSquareAxis(value: Double): Double {
        if (!value.isFinite()) return 0.0
        var normalized = value % 90.0
        if (normalized < 0.0) normalized += 90.0
        // 90 degrees describes the same square lattice as 0 degrees.
        if (kotlin.math.abs(normalized - 90.0) < 1e-10) normalized = 0.0
        return normalized
    }
}
