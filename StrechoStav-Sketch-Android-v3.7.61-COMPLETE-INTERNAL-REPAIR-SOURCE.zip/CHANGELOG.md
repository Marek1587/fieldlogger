# Zmeny

## 3.7.61

- tlačidlo `Skorigovať línie` už nekončí pri opravách označených ako nebezpečné; po jemnej korekcii vykoná úplnú topologickú fázu a odstráni všetky zostávajúce chyby vnútorných línií,
- kríženia a T-spoje sa rozdelia v spoločnom uzle, blízke konce sa magneticky spoja a krátke alebo duplicitné úseky sa odstránia,
- ak konflikt nemožno vyriešiť presunom alebo rozdelením bez poškodenia obrysu, posledná fáza deterministicky odstráni konfliktnú vnútornú líniu; obvodový polygón zostáva presne uzamknutý,
- celý návrh je pred potvrdením zobrazený v náhľade a aplikuje sa ako jedna vratná úprava,
- automatická príprava 3D zostáva konzervatívna, takže samotné otvorenie 3D potichu neodstráni rozpracované línie,
- pribudli regresné testy krížiacich sa hrebeňov a úžľabí, voľných koncov, odstránenia nevyriešiteľnej línie a nemennosti obvodu.

## 3.7.58

- všetky dĺžky v editore, obvod aj plocha používajú rovnakú lokálnu projekciu ako konštrukčná mriežka; potvrdený rozmer 7 000 mm sa preto už nezobrazí ako 6 992 mm,
- `Skorigovať obrys` ukladá obvodové body na 50 mm mriežku a zobrazené kóty zodpovedajú priamo súradniciam solvera,
- ak existujúca vnútorná línia skutočne pretne obvod alebo sa končí v strede jeho hrany, solver vytvorí jeden spoločný uzol a bezpečne rozdelí obvodovú hranu,
- nový spoločný uzol sa po potvrdení zachová aj v polygóne, `RoofTopology` a `RoofGraph`; synchronizátor ho už neprepíše starou nerozdelenou kópiou obrysu,
- karta obrysu nemení voľné vnútorné body, ktoré s obvodom nemajú incidenciu; ich 25 mm korekcia naďalej patrí výhradne karte vnútorných línií,
- pribudli regresné testy presných 50 mm násobkov, jednotnej metriky a trvalého odstránenia `UNSPLIT_INTERSECTION`.

## 3.7.57

- funkcia `Skorigovať obrys` je jediným vlastníkom fyzickej geometrie obvodového polygónu; potvrdený obrys sa ukladá na konštrukčnú mriežku 50 mm,
- funkcia `Skorigovať línie` už nesmie pridať, rozdeliť, odstrániť ani posunúť uzol obvodu a zachováva presne aj potvrdené strešné trakty a pôdorys muriva,
- uzly hrebeňov, nároží a úžľabí sa korigujú na samostatnej mriežke 25 mm; napojenia na obvod používa 3D iba ako odvodenú virtuálnu incidenciu bez zápisu do projektu,
- príprava 3D, PDF, výkazu a IFC je čisto čítacia a už nespúšťa skrytú korekciu, ktorá by menila používateľom potvrdený pôdorys,
- presah strechy nemení pôdorys ani profil muriva; zmena obvodu zostáva povolená iba vedomou úpravou kóty v parametrickom 3D modeli,
- pribudli regresné testy uzamknutia obvodu, zachovania sémantických oblastí a zákazu spätného zápisu odvodených 3D priesečníkov.

## 3.7.56

- potvrdenie funkcie `Skorigovať obrys` a `Skorigovať línie` je teraz jedna nedeliteľná projektová transakcia; rovnaká deformácia uzlov sa použije na obrys strechy, `RoofGraph`, pôdorys muriva, používateľom určené strešné trakty aj pripojené strešné prvky,
- po korekcii sa `WallFootprintSolver` okamžite prepočíta a jeho aktuálne oblasti sa uložia ešte pred uložením projektu alebo exportom IFC; export preto už nemôže kombinovať nové uzly strechy so starými súradnicami rizalitu,
- ak korekciu nie je možné bezpečne preniesť na všetky súradnicové reprezentácie, aplikácia ju zablokuje namiesto vytvorenia vnútorne nekonzistentného projektu,
- späť sa zaviedli prísne tolerancie stenového solvera; chyba z IFC sa už nezakrýva rozšírenou toleranciou 3D modelu,
- pribudol regresný test, ktorý po posune rizalitu kontroluje zhodu obrysu, pôdorysu muriva a používateľom označeného strešného traktu, a samostatný test odmieta aktivovať rizalitový stenový profil zo zastaraných IFC súradníc.

## 3.7.55

- oprava bola overená priamo na exporte `BIM.ifc` z terénneho projektu, nie iba na syntetickom pôdoryse,
- solver rizalitu už správne rozlišuje pôdorys muriva od fyzického okraja strechy; toleruje odsadenie vytvorené presahom strechy a preto nájde zostavu `1× odkvap + 2× štít` aj pri skutočnom presahu,
- používateľsky potvrdená oblasť rizalitu toleruje následnú korekciu pôdorysu v rámci jednej 100 mm konštrukčnej bunky, takže šikmý profil dostanú všetky tri exponované steny a nie iba jedna,
- horné hrany muriva rizalitu sa počítajú zo solved roviny strechy `z = a*x + b*y + c` po odpočítaní hrúbky plášťa a nevracajú sa na globálnu výšku podlažia,
- pribudol regresný test s presnými uzlami, hranami, rovinami a stenovým obrysom z dodaného IFC; kontroluje predný odkvap aj oba bočné štíty.

## 3.7.54

- pribudol samostatný `ProjectionWallProfileSolver` pre rizalit s presnou zostavou jedného čelného odkvapu a dvoch bočných štítov,
- solver si rovinu `z = a*x + b*y + c` preberá priamo zo strešnej plochy incidentnej k čelnému odkvapu; bočné murivo preto kopíruje sklon strechy a nevzniká obdĺžniková stena ani nadvihnutý strešný plášť,
- v potvrdenej zostave rizalitu je všeobecný stenový solver úplne obídený vrátane jeho minima výšky podlažia; pri inom význame hrán zostáva pôvodné bezpečné správanie nedotknuté,
- trapézový vikier používa dve bočné strešné plochy so sklonom 60°, lichobežníkové čelo a výšky prepočítané z aktuálneho sklonu a prienikov s hostiteľskou strechou,
- pultový, oblúkový a trapézový vikier majú predvolený sklon 10°, všetky strechy vikierov pevnú skladbu 150 mm a o 20 % svetlejší antracit,
- regresné testy kontrolujú aktivačnú zostavu rizalitu, vypnutie všeobecného solvera, aktualizáciu trapézového čela aj 150 mm strešnú skladbu vikiera.

## 3.7.53

- trapézový vikier sa skladá z hlavnej pultovej strešnej plochy a dvoch samostatných bočných plôch so skutočným sklonom 75°,
- bočný sklon sa počíta ako 3D sklon celej roviny; solver od neho odpočíta pozdĺžny gradient pultovej časti, takže výsledná bočná plocha má 75° aj pri šikmej pultovej streche,
- zadné konce pultovej plochy a vonkajšie konce bočných úžľabí vznikajú analytickým prienikom s hostiteľskou rovinou `z = a*x + b*y + c`,
- odstránili sa skrútené štvoruholníky, ktorých zadné body boli predtým násilne položené na jednej umelej čiare,
- čelná stena sleduje pultovú časť aj obe šikmé bočné časti a zachováva samostatne nastaviteľný presah vikiera,
- regresný test overuje tri strešné plochy, presný 75° sklon oboch bokov, planárnosť a všetky prieniky s hlavnou strechou.

## 3.7.52

- klasifikácia `Výstupok / rizalit` sa prenáša až do spoločného solvera horného profilu muriva,
- bočné steny rizalitu už nie sú natvrdo orezané globálnou výškou podlažia; ich horná hrana sa počíta priamo z podopierajúcej strešnej roviny `z = a*x + b*y + c` po odpočítaní hrúbky strešného plášťa,
- stena na styku s hlavným traktom plynulo prechádza do znižujúcej sa bočnej steny a vonkajšie čelo rizalitu sa uzavrie v skutočnej výške roviny,
- hlavný trakt, samostatné krídla a bežné obvodové steny si zachovávajú bezpečné minimum zadanej výšky stien; zníženie je povolené iba pre explicitne určený rizalit,
- rovnaký profil používa živý OpenGL model aj samostatný bitmapový/PDF renderer cez spoločný `RoofMesh`,
- pribudol regresný test rizalitu, ktorý overuje lineárny pokles oboch koncov bočnej steny aj nemenné správanie starších projektov bez významovej vrstvy.

## 3.7.51

- hlavný trakt sa už neurčuje z riadkového rozkladu citlivého na malé odsadenie fasády, ale ako najväčší plne obsadený obdĺžnik fyzického `WallFootprint`,
- až zvyšné obsadené bunky mimo hlavného jadra môžu byť výstupkom alebo samostatným krídlom; pásy užšie než 300 mm a zanedbateľné zvyšky sa nevydávajú za stavebnú časť,
- automatický výklenok musí byť obklopený pôdorysom muriva z najmenej troch strán a otvorený najviac na jednu stranu obálky; voľné pozadie a rohy mimo stavby sa už nešrafujú ako výklenky,
- dialóg po dlhom podržaní zobrazuje päť typov ako jediný obsah dialógu; odstránil sa konflikt Androidu medzi textovou správou a zoznamom, ktorý na niektorých zariadeniach ukázal iba tlačidlo Zrušiť,
- verzia automatického klasifikátora je súčasťou podpisu návrhu, preto sa chybný automatický návrh z 3.7.50 po otvorení prepočíta; ručné používateľské klasifikácie sa pritom zachovajú,
- pribudol regresný test, ktorý odlišuje obyčajný L-pôdorys od skutočného trojstranne uzavretého výklenku.

## 3.7.50

- za kartou `1 Obrys` pribudla karta `2 Strešné trakty`, ktorá automaticky rozkladá `WallFootprint` v trvalej projektovej mriežke 100 × 100 mm,
- automatický návrh rozlišuje hlavný strešný trakt, výstupok/rizalit, výklenok, samostatné krídlo a nadstavbu/vikier; každá časť má stabilné ID, šrafovaný obdĺžnik a názov priamo v nákrese,
- dlhé podržanie na obdĺžniku otvorí výber významu časti; ručne potvrdená klasifikácia sa uchová pri korekcii obrysu a pri ďalšom automatickom prepočte sa priradí k najbližšej zodpovedajúcej oblasti,
- tlačidlo `Automatický návrh` umožní vedome zahodiť ručné klasifikácie a vytvoriť návrh odznova; bežné otvorenie karty používateľské rozhodnutia neprepisuje,
- `RoofTopologySolver`, `RoofTractSymmetrySolver`, `GableTractSlopeSolver` a spoločná `Roof3DPreparation` používajú rovnaký kontext strešných traktov, takže výklenok ani vedľajšie krídlo neposúva os hlavného hrebeňa,
- schéma projektu bola rozšírená na verziu 10; staršie JSON projekty zostávajú importovateľné a nová významová vrstva sa zachová aj v IFC round-trip payload,
- pribudli regresné testy obdĺžnikového a L pôdorysu, detekcie výklenku, zachovania ručnej zmeny a JSON migrácie.

## 3.7.49

- spoločný hrebeň sa rieši ako spoločná výšková väzba, nie ako príkaz na rovnaký sklon oboch strešných plôch,
- pri nesymetrickom rozpone dostane predvolený sklon plocha s väčším kolmým rozponom; sklon protiľahlej plochy sa dopočíta z rovnakej výšky hrebeňa,
- automaticky odvodené sklony majú vlastný pôvod `AUTOMATIC_GABLE`, takže sa po zmene pôdorysných rozmerov znovu vypočítajú a nezostanú ako zastarané pevné hodnoty,
- staršie projekty bez uloženého pôvodu sklonu sa bezpečne migrujú cez `LEGACY` a pri ďalšej parametrickej zmene sa vrátia k fyzikálne kompatibilnej dvojici sklonov,
- každá strešná plocha má v 3D vlastnú kótu sklonu viazanú na `FaceId`; koliesko mení iba vybranú plochu a protiľahlú plochu prispôsobí spoločnému hrebeňu,
- parametrická zmena pôdorysnej kóty spúšťa korekciu sklonov ešte pred riešením rovín `z = a*x + b*y + c`, takže do uloženého grafu sa už nevracia aproximovaný model s rovnakými sklonmi,
- pribudli regresné testy pre nesymetrický trakt 7,7/3,6 m, zmenu riadiacej plochy a zachovanie pôvodu constraintu po JSON round-tripe.

## 3.7.48

- pribudla neviditeľná projektová konštrukčná mriežka s pevným krokom 100 × 100 mm; nejde o obrazovú ani pixelovú mriežku a jej poloha sa nemení pri zoome, posune alebo otočení mapy,
- rám mriežky sa pri založení obrysu zarovná s hlavnou osou stavby a jeho origin aj natočenie sa trvalo ukladajú do projektu, `RoofTopology` a `RoofGraph`,
- všetky konštrukčné uzly obrysu a vnútorných línií sa pri kreslení, presune, rozdelení hrany, magnetizácii, korekcii aj parametrickej zmene ukladajú iba do priesečníkov mriežky,
- korekčný solver používa uloženú os mriežky ako normatívny smer; nepresnosť jednej zameranej hrany preto už nedokáže po úprave otočiť celý súradnicový rám,
- rovnobežné a kolmé podperné línie sa riešia v spoločnom mriežkovom rámci, čím sa zachovávajú presné 90° rohy a rovnobežnosť protiľahlých strán,
- staršie projekty bez údajov mriežky sa migrujú automaticky pri prvom geometrickom zásahu; existujúci JSON zostáva importovateľný,
- pribudli regresné testy nezávislosti od mapového zoomu, natočenej mriežky, topologického solvera a grafových operácií.

## 3.7.47

- protiľahlé štítové kontakty jedného strešného traktu sa posudzujú ako jeden párovaný geometrický constraint, nie ako dva nezávislé body,
- malé rozdiely rozdelenia protiľahlých štítov sa zjednotia na presne rovnaký normalizovaný pomer; hrebeň preto zostane rovnobežný s odkvapmi a nevyosí sa pre odchýlku niekoľkých milimetrov,
- každá jednotlivá korekcia zostáva ohraničená na 300 mm, takže zámerne asymetrický alebo trojuholníkový pôdorys sa automaticky nepretvorí na inú stavbu,
- párová kontrola sa vykoná pred magnetickým zlúčením koncov vnútorných línií a používa ju karta `2 Vnútorné línie` aj spoločná príprava 3D/PDF/výkazu/IFC,
- nový `GableTractSlopeSolver` pri vyosenom hrebeni odvodí pre obe strešné plochy rozdielne kompatibilné sklony tak, aby mali spoločnú výšku hrebeňa; rovnaký sklon sa už nevynucuje na rozdielnych pôdorysných rozponoch,
- explicitne zadaný sklon jednej plochy sa zachová a solver z neho dopočíta chýbajúci sklon protiľahlej plochy,
- pribudli regresné testy rovnakého pomeru rozdelenia protiľahlých štítov, rovnobežnosti hrebeňa a spoločnej výšky hrebeňa pri rozdielnych sklonoch.

## 3.7.46

- pribudol samostatný ohraničený `RoofTractSymmetrySolver`, ktorý rozpozná fyzicky rovnú štítovú stranu rozdelenú kontaktom hrebeňa a vycentruje ju podľa skutočnej šírky strešného traktu,
- každá polovica štítovej strany sa môže zmeniť najviac o 300 mm; väčšia asymetria sa považuje za zámernú geometriu a solver ju ponechá bez zásahu,
- korekcia neposúva skutočné rohy ani hrany výklenkov, takže súvislá strešná rovina môže pokračovať ponad ustúpenú časť stavby bez deformácie pôdorysu muriva,
- kontaktný uzol obrysu a všetky už magneticky pripojené konce hrebeňa sa presunú ako jeden topologický uzol, čím nevznikne medzera ani zdvojený priesečník,
- rovnaká korekcia je súčasťou karty `1 Obrys` aj spoločnej prípravy `Roof3DPreparation`, preto ju zdieľa interaktívne 3D, PDF, výkaz a IFC,
- dialóg korekcie teraz samostatne uvádza počet hrebeňov vycentrovaných v strešnom trakte,
- pribudli regresné testy blízkej symetrie, zámerne asymetrickej geometrie a konkávneho výklenku pod súvislou strešnou rovinou.

## 3.7.45

- horný profil muriva vo výklenku už nestratí strešnú podporu iba preto, že odsadený pôdorys steny leží mimo 2D obrysu `GraphFace`,
- `RoofWallProfileSolver` v takej zóne deterministicky pokračuje najbližšou vyriešenou rovinou `z = a*x + b*y + c` až po spodný povrch strešného plášťa,
- pri rovnakej vzdialenosti viacerých plôch sa použije nižšia spodná rovina, aby na úžľabí nevznikla medzera alebo zvislá trhlina,
- strešný mesh sa výškovo neposúva; oprava dopĺňa chýbajúce murivo pod existujúcu antracitovú plochu a zachováva spoločný model pre OpenGL, náhľady aj PDF,
- pribudol regresný test konkávneho výklenku, v ktorom obe bočné steny presne sledujú sklon najbližšej strešnej roviny.

## 3.7.44

- potvrdenie parametrickej kóty už nevytvorí 3D pohľad v základnej polohe; orbit, náklon, priblíženie aj posun sa prenesú do prepočítaného modelu,
- stav kamery je oddelený od generovaného `RoofMesh`, takže sa zachová aj pri prepnutí medzi kartami 3D geometrie a 3D prvkov,
- naposledy potvrdená kóta sa podľa stabilného `dimensionId` na dve sekundy zvýrazní žltou farbou,
- zvýraznenie zahŕňa kótovaciu čiaru, vynášacie čiary, koncové značky aj štítok a po uplynutí času sa bez zásahu používateľa vráti do základného zeleného vzhľadu.

## 3.7.43

- novy `RoofWallProfileSolver` odvodi hornu hranu kazdeho useku muriva priamo z vyriesenych rovin `z = a*x + b*y + c`,
- steny ustupenych vyklenkov pod suvislou stresnou plochou uz nekoncia na jednej konstantnej vyske; podla plasta vznikne lichobeznikovy alebo stitovy profil,
- profil sa automaticky deli v prienikoch s hrebenom, narozim, uzlabim a hranicou plochy, ale na fasade nevytvara ziadne nove viditelne zvisle svy,
- vrch muriva konci na spodku 180 mm stresneho plasta, takze sive celne podbitie ostava suvisle a medzi stenou a strechou nevznika medzera,
- rovnaky `RoofMesh` profil pouziva interaktivny OpenGL model, nahlad projektu, staticky Kotlin renderer aj PDF,
- pribudli regresne testy ustupeneho vyklenku a steny pretinanej hrebenom.

## 3.7.42

- sedlovy a trojuholnikovy vikier sa uz neukoncuju umelou rovnou zadnou hranou; obe strešné roviny sa analyticky pretinaju s hostitelskou rovinou,
- povodne obdlznikove strešné pasy sa prienikom orezu na dva planarne lichobezniky a ich zadne hrany tvoria skutocne uzlabia,
- otvor v hlavnom strešnom plasti ma patbodovu topologiu: predna hrana, dve bocne uzlabia a zadny koniec hrebena,
- bocne steny sedloveho vikiera sa pri hostitelskej streche uzatvaraju trojuholnikmi bez bielych medzier a bez prestupovania cez plast,
- rovnaky plane-intersection solver pouziva valbovy vikier; predna valbova plocha je trojuholnik a dve bocne plochy su planarne lichobezniky,
- plocha otvoru, odratana plocha povodnej strechy, 3D model aj vykazy teraz pouzivaju rovnaky prienikovy obrys,
- pribudli regresne testy planarnosti, prienikov s hostitelskou rovinou, trojuholnikovych bocnych stien a patbodoveho otvoru.

## 3.7.41

- zadna hrana kazdeho vikiera je odvodena ako presny prienik s hostitelskou strešnou rovinou; vikier uz neplava nad plastom ani nim svojvolne neprechadza,
- trapezovy vikier ma samostatnu strednu plochu a dve skosene bocne stresne plochy, ktore sa stretavaju v spolocnych hranach bez prekrytia,
- sklon trapézoveho vikiera sa konstruuje od zadnych prienikov so strechou a zostava deterministicky viazany na hostitelsku rovinu,
- kazdy typ vikiera dostal nastavitelny `Presah od muriva` (predvolene 250 mm), dostupny v 3D cez rovnake otocne koliesko ako ostatne rozmery,
- presah vikiera sa zachovava v projektovom JSON, IFC vlastnostiach a v statickom aj interaktivnom 3D vykresleni,
- schema projektu bola posunuta na verziu 8 a pribudli regresne testy troch ploch trapezoveho vikiera, zadnych prienikov a presahu.

## 3.7.40

- za kartu Typologia pribudla samostatna karta `Vikiere a strojovne` s dlazdicami pre sedlovy, valbovy, pultovy, Napoleon, volske oko, trojuholnikovy, oblukovy a trapezovy vikier,
- doplnene su dlazdice `Strojovna vytahu`, `Sachta` a `Stresna terasa`; na tejto karte sa voli iba typ a poloha v hostitelskej strešnej ploche,
- rozmery, vyska, zapustenie a sklon sa nastavuju az v 3D rovnakym otocnym kolieskom ako ostatne parametricke koty,
- spolocny solver orientuje sirku prvku rovnobezne s odkvapom, vytvara stabilny otvor v hostitelskom `GraphFace` a odratava ho z plochy povodnej strechy,
- vikier pridava vlastne strešne a celne plochy; strojovna a sachta vytvaraju kvader s plochou strechou; terasa vytvara skutocny vykroj, zapustenu podlahu a bocne steny po uroven plasta,
- GLSurfaceView teraz orezava hostitelsku siet presne po otvoroch bez prekrytia terasy povodnou strechou,
- nove prvky a ich parametre su zachovane v JSON, IFC round-trip vlastnostiach, 2D vykrese, 3D, PDF/SVG a vo vykaze,
- doplnene regresne testy vsetkych typov vikierov, otvoru terasy, strojovne, sachty a JSON round-trip.

## 3.7.39

- predvoleny pozdlzny spad zlabov je presne 4 mm/m namiesto uhloveho nastavenia 1,5 stupna,
- maximalny rozstup zvodov zostava 12 m a minimalny odstup osi zvodu od oboch rohov zostava 0,8 m,
- odvodeny solver doplna systemove zlabove haky s rozstupom najviac 0,9 m a objimky zvisleho zvodu s rozstupom najviac 2 m,
- haky aj objimky sa vykresluju v interaktivnom aj statickom 3D modeli a ich pocty sa prenasaju do vykazu a JSON suhrnu,
- pravouhle napojenia zlabov sa topologicky rozlisuju na systemovy vnutorny a vonkajsi roh 90 stupnov a oba pocty su vo vykaze,
- doplnene regresne testy presneho spadu 4 mm/m, rozstupu hakov a objimok a klasifikacie vnutorneho/vonkajsieho rohu.

## 3.7.38

- susedne pododkvapove zlaby sa v spolocnom rohu spajaju jednym suvislym miterovym dielom bez medzery a bez prelozenia dvoch samostatnych zlabov; rovnaky spoj pouziva 3D, editor, SVG aj technicky PDF vykres,
- kazdy koniec zlabu aj spojeny roh je pevnym najvyssim bodom; pozdlzny spad 1,5 stupna zacina az za rohom a smeruje k zvodu,
- automaticky aj rucne vlozeny zvod musi byt najmenej 0,8 m od oboch koncov odkvapovej hrany,
- pri posuvani zvodu ho solver zastavi na hranici ochrannej zony 0,8 m, takze pouzivatel nemoze vytvorit nizky bod priamo v rohu,
- na odkvape kratsom ako 1,6 m sa zvod nevlozi, pretoze poziadavku 0,8 m od oboch rohov nie je mozne geometricky splnit.

## 3.7.37

- ulozene projekty s platnym vyriesenym 3D modelom maju v zozname na lavej strane automaticky generovany obrazkovy nahlad,
- nahlad pouziva rovnaky vyrieseny RoofGraph a Kotlin bitmapovy renderer ako PDF, ale je bez kot a technickych popisov,
- kamera prisposobuje mierku iba stavbe; zakladova doska moze byt orezana, aby strecha a steny co najviac vyplnili obrazok,
- generovanie nahladov prebieha mimo hlavneho UI vlakna a vysledky sa ukladaju do pamatovej cache,
- samostatne tlacidlo `3D` bolo zo zoznamu odstranene; interaktivny 3D model sa otvara kliknutim na jeho nahlad.

## 3.7.36

- pribudla samostatna karta `Zlaby a zvody` urcena na konfiguraciu dazdovej kanalizacie bez prekryvania kot a ovladacov geometrie strechy,
- dlhsie podrzanie zlabu v 3D zobrazi tlacidlo `Pridat zvod`; novy zvod sa vlozi presne na oznacene miesto zlabu,
- dlhsie podrzanie zvodu ho zvyrazni oranzovou farbou a umozni ho posuvat iba pozdlz prislusnej odkvapovej hrany,
- oznaceny zvod je mozne odstranit samostatnym tlacidlom; odstranenie automatickeho zvodu sa uklada ako trvale potlacenie, aby ho solver po opätovnom otvoreni nevratil,
- pre kazdy zvod je mozne zvolit ukoncenie `Koleno 72 stupnov` alebo `Zaustenie do trativodu`; pri trativode pokracuje rura rovno az po zakladovu dosku,
- rucne polohy, typy ukoncenia aj odstranene automaticke zvody sa ukladaju do projektu, JSON round-trip vrstvy a IFC vlastnosti.

## 3.7.35

- pod kazdou obvodovou hranou typu ODKVAP sa v editore, technickom PDF aj SVG vykresli pododkvapovy zlab ako pas siroky 120 mm, odsadeny 30 mm od odkvapovej hrany, bez samostatnej koty,
- novy RainwaterDrainageSolver vytvara zlaby iba na hranach EAVE; stity a atiky su z odvodenia vylucene,
- polkruhove 3D zlaby maju priemer 120 mm a pozdlzny spad 1,5 stupna smerom do automaticky navrhnutych zvodov,
- zvody sa odvodenym solverom rozmiestnuju s maximalnym rozostupom 12 m a vystupuje ich skutocny pocet aj vo vykaze,
- kazdy zvod je osadeny na najblizsiu stenu a so zlabom ho spaja dvojica 72-stupnovych kolien s medzirurou, ktorej dlzka sa prepocita podla aktualneho presahu,
- interaktivny OpenGL ES renderer aj staticky Kotlin/PDF renderer pouzivaju pre zlab, kolena a zvod samostatny kovovo-sivy material.

## 3.7.34

- technicky podorys pouziva rozlisene graficke znacky prvkov strechy podla tabulky 2 STN 01 3420: vetracie zariadenie, potrubny prestup, vytok do zvodu a stresnu vpust,
- stresne okna a vylezy maju hruby suvisly obrys a tenke suvisle uhlopriecky,
- hrebene, narozia, uzlabia a pultove priesecnice stresnych rovin maju jednotnu hrubu suvislu ciaru,
- pri automatickom natoceni vykresu podla najdlhsej strany sa doplna skutocny smer severu,
- hlavicka vykresu uvadza pouzitu vykresovu normu STN 01 3420.

## 3.7.33

- znacky sklonu v technickom podoryse a PDF su kreslene podla STN 01 3420 ako tenka sipka v smere spadu s hodnotou v stupnoch nad sipkou,
- oznacenie uz nepouziva ramcek ani slovny prefix; zachovava iba normovu ciselnu hodnotu a znak stupna,
- vyskove koty su zapisane v metroch na tri desatinne miesta bez znacky jednotky, s `+`, `-` alebo `±0,000` na referencnej urovni,
- hrany pouzivaju otvorenu 90-stupnovu sipku, vodorovne plochy plny bod a samostatne vyskove body krizik `X` s odkazovou ciarou.

## 3.7.32

- kaĹľdĂ˝ komĂ­n mĂˇ v 3D modeli aj v statickĂ˝ch PDF pohÄľadoch vodorovnĂş hornĂş platĹu hrubĂş 100 mm s presahom 50 mm na kaĹľdej strane,
- automatickĂˇ aj ruÄŤnĂˇ vĂ˝Ĺˇka komĂ­na zostĂˇva celkovou vĂ˝Ĺˇkou po hornĂ˝ povrch platne, takĹľe platĹa nemenĂ­ normovĂş svetlĂş vĂ˝Ĺˇku,
- technickĂ˝ 2D vĂ˝kres zobrazuje STN vĂ˝ĹˇkovĂş znaÄŤku na kaĹľdom komĂ­ne podÄľa skutoÄŤnej vyrieĹˇenej vĂ˝Ĺˇky,
- automatickĂ© vĂ˝ĹˇkovĂ© znaÄŤky sa presunuli zo ĹĄaĹľĂ­sk plĂ´ch na hrebene, odkvapy a hornĂ© hrany atĂ­k,
- v ĹĄaĹľisku streĹˇnej plochy zostĂˇva iba znaÄŤka smeru a hodnoty sklonu.

## 3.7.31

- interaktívny OpenGL ES 3.0 renderer používa modelovo ukotvené smerové slnko z juhozápadu zodpovedajúce architektonickému pohľadu približne o 14:00,
- shader kombinuje hemisférické okolité svetlo, mäkký prechod tieňa, difúznu zložku a jemný materiálový odlesk bez prekročenia tlmeného rozsahu antracitovej strechy,
- svetlo sa pri orbitálnom otáčaní kamery neotáča spolu s pozorovateľom, ale zostáva stabilné voči geografickým osiam modelu,
- podbitie a celý spojitý plášť presahu majú samostatný sivý materiál, ktorý je mierne tmavší než svetlosivé steny,
- statický Kotlin renderer používaný pre PDF a náhľady má rovnaký slnečný smer, materiál podbitia a zodpovedajúce tieňovanie.

## 3.7.30

- počas presúvania 3D prvku sa skryjú všetky bežné geometrické a rozmerové kóty, aby zostal čistý pracovný priestor,
- referenčný najbližší roh sa zvolí pri dotyku a zostáva nemenný až do ukončenia presunu,
- dočasné červené súradnicové kóty X/Y sú skutočné priestorové úsečky ležiace v rovine priradenej strešnej plochy a otáčajú sa spolu s modelom,
- technický 2D/PDF pôdorys obsahuje pre komíny, strešné okná, výlezy a prestupy ďalší vonkajší rad polohových kót X/Y,
- polohové kóty v 2D používanú ten istý najbližší fyzický roh a solver ich umiestňuje mimo polygonu aj pri konkávnych pôdorysoch.

## 3.7.29

- prvá PDF strana `Situácia osadenia stavby` používa vždy ZBGIS ortofoto na zdrojovom zoome 20 bez ohľadu na aktuálny zoom editora,
- výrez zostáva deterministicky centrovaný podľa obrysu stavby a zachováva celý polygon aj šrafovanie,
- päta situačnej strany uvádza použitý mapový zoom pre jednoduchú kontrolu exportu.

## 3.7.28

- každá vyriešená strešná plocha má v technickom 2D pôdoryse automatickú značku `SPÁD` s hodnotou sklonu v stupňoch,
- smer šípky sa počíta z gradientu roviny `z = a*x + b*y + c` a vždy ukazuje nadol po spáde konkrétnej plochy,
- značka spádu je odsadená od výškovej značky v ťažisku, aby oba údaje zostali čitateľné,
- ručne vložené legacy značky sklonu a výšky sa v PDF neduplikujú; výkres používa automatické značky zo solved grafu,
- statický Kotlin renderer kreslí strešné a vnútorné hrany bez kladného hĺbkového biasu, takže takmer koplanárne línie za stenou nepresvitajú,
- OpenGL renderer nepoužíva polygon offset na plochách; strešné línie za fasádou sa skrývajú skutočným depth testom a zostáva iba jemný fyzický obrys steny,
- pribudli regresné testy uhla a smeru spádu aj skrytia takmer koplanárnej strešnej línie za stenou.

## 3.7.27

- technický 2D pôdorys v PDF používa priamo vyriešený `RoofGraph` spoločný s 3D modelom a výkazom,
- hrany typu `ATTIC` sa zobrazujú ako skutočný pás atiky s projektovou šírkou, súvislými rohovými napojeniami, popisom a jednou kótou šírky,
- komín má v pôdoryse samostatnú kótu dĺžky a šírky v jeho lokálnom natočení,
- každá vyriešená strešná plocha dostáva automatickú výškovú značku v geometrickom ťažisku; výška sa vyhodnocuje z roviny `z = a*x + b*y + c`,
- automatické výškové značky nahrádzajú neúplné ručne vložené značky v PDF a používajú biele pozadie pre čitateľnosť,
- pribudli regresné testy súvislosti rohov atiky, výšky v ťažisku a výpočtu ťažiska plochy s otvorom.

## 3.7.26

- prvou stranou PDF je nová `Situácia osadenia stavby` s rovnakým ZBGIS ortofoto podkladom, aký používa editor,
- mapa sa skladá z dlaždíc trvalo uložených v cache konkrétneho projektu a export preto nevykonáva blokujúce sieťové požiadavky,
- výrez sa deterministicky vypočíta z celého obrysu stavby a nemení sa pri posunutí mapy v editore,
- obrys je vyznačený polopriehľadnou zelenou výplňou, diagonálnym šrafovaním a čitateľným obvodom bez kót, uzlov, vnútorných línií a technických popisov,
- PDF súbor sa ukladá s názvom `Situacia-osadenia-stavby-<projekt>.pdf`, ostatné technické, auditné a rozpočtové strany sa bezpečne posunuli za novú titulnú situáciu,
- pribudli regresné testy úplnosti, stability a veľkorozmerového fitovania mapového výrezu.

## 3.7.25

- rozpočtová časť PDF používa vizuálnu hierarchiu dodaného ponukového rozpočtu: zelený zaoblený rám, firemnú hlavičku, zelenú hlavičku tabuľky, tučné hlavné položky a samostatné orámované riadky špecifikácií,
- hlavička preberá názov zákazky, objednávateľa, miesto stavby a stabilný kód priamo z projektu; neznáme projektové údaje sa zobrazia ako pomlčka,
- položky majú stabilné stavebno-technologické poradie nezávislé od poradia výberu používateľom,
- dlhé názvy a špecifikácie sa zalamujú a rozpočet sa automaticky rozdelí na ďalšie A4 strany bez odrezania položiek,
- súhrn rozlišuje cenu bez DPH, DPH a cenu spolu s DPH; sadzba DPH je predvolene 23 % a na karte Rozsah prác sa upravuje rovnakým kolieskom ako ostatné čísla,
- sadzba DPH sa ukladá v projektovom JSON a staršie projekty ju bezpečne doplnia na 23 %,
- pribudli regresné testy poradia, DPH a spätnej kompatibility projektového JSON; všetkých 99 testov prešlo bez chyby.

## 3.7.24

- koliesko výšky komína má priamo nad kruhom nové tlačidlo `AUTO – výška podľa solvera`,
- AUTO zruší aj skôr uloženú ručnú výšku, znovu vypočíta hodnotu z aktuálnej vyriešenej plochy a až po úspešnom výpočte odstráni príznak `chimneyHeightManual`,
- automatický režim je dostupný pri úprave komína z 2D typológie aj priamo z kóty v karte `5 3D prvky`,
- po opätovnom zapnutí AUTO sa výška komína pri ďalšom presúvaní znovu priebežne riadi solverom,
- dvojprstový pan 3D modelu používa priamu manipuláciu: model sa posúva rovnakým smerom ako stred dvojice prstov,
- golden IFC fixture zapisuje aktuálnu aplikačnú verziu 3.7.24,
- pribudol regresný test ručná výška → AUTO; všetkých 96 testov prešlo bez chyby.

## 3.7.23

- karta 8 dostala export `Generovať IFC BIM model` cez systémový Android dialóg na uloženie `.ifc`,
- export používa jediný snapshot z `Roof3DPreparation`, rovnaký vyriešený `RoofGraph` a rovnaké množstvá ako 3D, PDF a výkaz,
- vznikla oddelená BIM vrstva `RoofBimSnapshot -> StrechoStavBimModel -> Ifc43Model -> IfcStepWriter`, bez väzby na Android UI alebo OpenGL mesh,
- STEP hlavička deklaruje `IFC4X3_ADD2`; model obsahuje `IfcProject`, `IfcSite`, `IfcBuilding`, `IfcBuildingStorey`, `IfcRoof` a samostatný `IfcSlab` pre každý `GraphFace`,
- strešné plochy používajú presné XYZ zo solved grafu, `IfcPolygonalFaceSet` a pri otvoroch `IfcIndexedPolygonalFaceWithVoids`,
- pridané sú štandardné `Qto_RoofBaseQuantities`, `Qto_SlabBaseQuantities` a vlastné property sety `StrechoStav_*`,
- celý kanonický projektový JSON sa ukladá v deterministických UTF-8 chunkoch s SHA-256 pre bezstratový budúci round-trip,
- všetky `IfcRoot` objekty majú stabilný deterministický 22-znakový IFC GUID a STEP entity sa radia stabilne,
- komín sa mapuje na `IfcChimney`, strešné okno na `IfcWindow` s otvorom/väzbou a ostatné objekty bezpečne na `IfcBuildingElementProxy`,
- interný validator kontroluje STEP sekcie, schému, konečné čísla, GUID, duplicity, dangling referencie a úplnosť `GraphFace -> IfcSlab`,
- pribudol golden IFC fixture a 9 nových IFC testov; všetkých 95 testov prešlo bez chyby.

## 3.7.22

- nový `RoofOpeningPlacementSolver` umiestňuje hornú hranu strešného okna alebo výlezu presne 2 100 mm nad úroveň podlahy,
- úroveň podlahy sa v aktuálnom LOD100 modeli odvodzuje od hornej úrovne stien `wallHeightM`,
- poloha sa rieši priamo na rovine hostiteľskej plochy `z = a*x + b*y + c`, nie dodatočným posunutím obrazu,
- zadaná dĺžka okna/výlezu sa chápe ako skutočná dĺžka po šikmine a solver ju rozkladá na pôdorysnú a výškovú zložku,
- pri otvorení 3D modelu sa existujúce okná a výlezy automaticky premiestnia do správnej výšky, ak sa celý prvok zmestí na svoju plochu,
- 3D potiahnutie okna alebo výlezu sa premieta iba do smeru rovnobežného s odkvapom; pohyb nahor/nadol pozdĺž krokvy je zablokovaný,
- pri zmene dĺžky kolieskom sa stred prvku prepočíta tak, aby horná hrana naďalej zostala vo výške 2 100 mm,
- šírka okna zostáva rovnobežná s odkvapom a jeho dĺžka smeruje presne po spáde vyriešenej plochy,
- strešné okno aj výlez majú nový LOD100 shell: súvislý vyvýšený rám a mierne zapustenú sklenenú plochu bez výrobných detailov,
- OpenGL aj samostatný Kotlin bitmapový renderer/PDF rozlišujú materiál tmavého rámu a modrosivého skla,
- všetkých 86 geometrických a regresných testov prešlo bez chyby.

## 3.7.21

- pri posúvaní komína v karte `5 3D prvky` sa jeho výška automaticky prepočíta z roviny konkrétnej strešnej plochy `z = a*x + b*y + c`,
- do vodorovnej vzdialenosti 2 m od najbližšieho relevantného hrebeňa končí komín 650 mm nad výškou hrebeňa,
- vo väčšej vzdialenosti sa použije ochranná priamka klesajúca od hrebeňa pod uhlom 10° a bezpečnostné zvýšenie 650 mm,
- strecha so sklonom menším ako 20° používa rovnobežnú ochrannú rovinu 1 000 mm nad miestnou strešnou plochou,
- plochá/atiková strecha bez hrebeňa používa vrch atiky + 1 000 mm; pultová alebo iba odkvapová strecha používa najvyššiu vyriešenú obvodovú kótu + 1 000 mm,
- vzdialenosť sa meria od osi komína k najbližšiemu bodu úseku hrebeňa v pôdoryse, nie iba k jeho stredu,
- pri prechode komína na inú strešnú plochu sa spolu s FaceId okamžite aktualizuje aj automatická výška,
- výška zadaná používateľom kolieskom sa označí ako ručná a ďalší presun ju už neprepíše,
- príznak automatickej/ručnej výšky sa ukladá do JSON; staršie nenulové výšky sa pri migrácii chránia ako ručné,
- maximálny rozsah ručne zadanej aj vykreslenej výšky komína sa zvýšil na 20 000 mm,
- všetkých 82 geometrických a regresných testov prešlo bez chyby.

## 3.7.20

- pôvodná 3D karta je rozdelená na `4 3D geometria` a `5 3D prvky`; výkaz, rozsah prác a PDF sa posunuli na karty 6 až 8,
- karta 3D geometrie zobrazuje a upravuje iba pôdorysné rozmery, výšku stien, atiku, presah a sklon,
- karta 3D prvkov zobrazuje iba rozmery komínov, strešných okien, výlezov a prestupov a povoľuje ich presúvanie,
- komín má zvislé boky a vodorovný vrch rovnobežný so základovou doskou aj na šikmej strešnej ploche,
- počas presúvania sa celý 3D prvok vykreslí načerveno pomocou samostatného OpenGL materiálu,
- dočasné červené kóty X/Y ukazujú vzdialenosť prvku od najbližšieho fyzického rohu strechy,
- osi dočasných kót sa odvodzujú od dvoch strán pri danom rohu, preto fungujú aj pri natočenom pôdoryse,
- prvok sa naďalej môže pohybovať iba po platnej uzavretej strešnej ploche a po prechode na inú plochu sa aktualizuje jeho FaceId,
- PDF a statické bitmapy používajú rovnaký vodorovne ukončený komín, ale nikdy nezobrazujú dočasné červené zvýraznenie,
- všetkých 75 geometrických a regresných testov prešlo bez chyby.

## 3.7.19

- horizontálny pás siedmich pracovných kariet si pri prepínaní obrazoviek pamätá poslednú polohu a už neskáče na prvú kartu,
- pri obnove obrazovky sa zachovaná poloha bezpečne obmedzí na aktuálnu šírku pásu a aktívna karta zostane vo viditeľnej časti,
- aktuálna karta má výraznú zelenú výplň, žltý dvojpixelový rám a mierne vyvýšenie,
- rovnaký stavový vzhľad používajú aktívne nástroje editora, napríklad Obrys prstom, Editovať, Pridať líniu a Editovať líniu,
- na karte Typológia sa samostatne zvýrazní práve aktívny prvok: komín, strešné okno, výlez, prestup, vpusť, zvod, výšková kóta alebo značka sklonu,
- ZBGIS ortofoto a podklad PDF/JPG ukazujú svoj skutočný aktívny stav,
- stav tlačidiel je napojený na editor a mapový host, takže sa obnoví aj po zmene režimu mimo samotného tlačidla,
- všetkých 71 geometrických a regresných testov zostáva súčasťou zostavenia.

## 3.7.18

- nový `ParametricRoofPlanRegularizer` sa spúšťa po každej zmene pôdorysnej kóty v 2D aj 3D editore,
- nárožia a úžľabia sú tvrdé pôdorysné podmienky ±45° voči odkvapu pripojenému k ich obvodovej kotve,
- spoločný uzol viacerých diagonál sa počíta ako deterministický priesečník ich 45° podporných priamok,
- konce hrebeňov používajú vyriešené spoločné uzly, preto sa hrebeň môže posunúť a zmeniť dĺžku bez rozpojenia strešných plôch,
- staré tvrdé dĺžky dotknutých nároží, úžľabí a hrebeňov sa zosúladia s nadradenou 45° geometriou,
- RoofGraph, 3D model, PDF a výkaz používajú tú istú skorigovanú XY geometriu,
- všetkých 71 geometrických a regresných testov prešlo bez chyby.

## 3.7.17

- nový `PlanDimensionPlacementSolver` určuje vonkajšiu stranu hrany podľa orientácie celého uzavretého polygónu,
- obvodové kóty konkávnych L/T/H pôdorysov sa presúvajú na vonkajšiu podpornú priamku za najvzdialenejší bod celého obrysu,
- poloha kóty sa už neurčuje voči ťažisku, ktoré pri konkávnych pôdorysoch mohlo ležať na nesprávnej strane hrany,
- kótovacia čiara sa vzorkuje po celej dĺžke a regresné testy overujú obe orientácie poradia bodov,
- všetkých 69 geometrických a regresných testov prešlo bez chyby.

## 3.7.16

- štyri rohové 3D pohľady v PDF sa rámujú podľa obálky domu a strechy, nie podľa väčšej prezentačnej dosky,
- model využíva takmer celý dostupný biely rám s ochranným okrajom iba 2,5 %,
- doska sa naďalej vykresľuje, ale podľa natočenia sa môže pri okraji zámerne orezať,
- automatické rámovanie sa počíta osobitne pre každý zo štyroch smerov kamery,
- technický pôdorys, interaktívny 3D model a statický náhľad rozsahu prác zostali bez zmeny mierky.

## 3.7.15

- presah odkvapov a štítov sa vytvára ako jeden miterovaný obal so spoločnými rohovými uzlami,
- valbové rohy už neskladajú dva prekrývajúce sa obdĺžnikové pásy a nezostáva v nich trojuholníková medzera,
- body 200 mm podhľadu aj napojenia pri murive sú zdieľané susednými plochami a majú totožné XYZ súradnice,
- hrebeňový bod na štíte sa premietne na odsadenú štítovú stenu a vytvorí súvislý vrchol muriva aj podkladu presahu,
- jedna kóta presahu platí pre odkvapy aj štíty; atikové hrany zostávajú bez presahu,
- staršie projekty uložené s odsadením iba na odkvapoch sa pri 3D vykreslení automaticky geometricky dorovnajú,
- offset solver toleruje krátke segmenty vytvorené priesečníkom hrebeňa alebo zalomením L/T/H pôdorysu,
- 67 geometrických a regresných testov prešlo bez chyby.

## 3.7.14

- opravené priradenie vybratej 2D hrany podľa jej skutočných koncov namiesto nestabilného poradia uzlov,
- chybové hlásenie rozmeru teraz uvádza skutočnú príčinu odmietnutia,
- pôdorysná kóta mení vybranú a najdlhšiu rovnobežnú protiľahlú stenu v jednej transakcii,
- L/T/H obrysy zachovávajú pravé uhly; kratšie paralelné segmenty sa bez potreby nemenia,
- 3D zmena synchronizuje RoofGraph, obrys strechy, pôdorys muriva aj polohu technických prvkov,
- existujúci odkvapový presah sa pri zmene rozmeru zachováva ako konštantné odsadenie,
- Undo rozmeru obnovuje aj pôvodný obrys a murivo.

## 3.7.13

- Nový `RoofOverhangSolver` vytvára presah iba na hranách s technickým významom `EAVE`; atiky, štíty a ostatné obvodové hrany sa do presahu ani do spoločnej kóty nezapočítajú.
- Jedna parametrická kóta presahu posúva všetky odkvapové podporné priamky rovnakou hodnotou. Priesečníky susedných priamok zachovávajú rohy obdĺžnikov aj zalomenia L/T/H pôdorysov.
- 3D presah má podľa referenčného STN/PHP modelu samostatné čelo, prvých 200 mm vodorovného podhľadu a následný šikmý podhľad kopírujúci vyriešenú rovinu krokvy až po murivo.
- Pri šikmom podhľade sa spojenie s murivom uzavrie bez otvorenej medzery a bez pridania viditeľného triangulačného švu na stenu.
- Regresné testy pokrývajú kombináciu troch atík s jedným odkvapom aj jedinej atiky s piatimi odkvapmi.

## 3.7.12

- Murivo štítovej steny sa vypĺňa od výšky rímsy až po skutočný profil strešných rovín.
- Solverom vložený bod, v ktorom hrebeň končí na štíte, už nerozdelí fyzickú stenu ani na nej nevytvorí zvislú čiaru; deliaci bod vznikne iba vtedy, keď je súčasťou reálneho obrysu.
- Triangulácia stien je úplne skrytá. Samostatná vrstva `wallEdges` obsahuje iba spodné hrany skutočných segmentov obrysu a kreslí sa najtenšou bledosivou čiarou.
- Statický Kotlin/PDF renderer vyberá logo podľa aktuálnej kamery. Ak dve hlavné logá nie sú v danom rohovom pohľade viditeľné, doplní logo na najväčšiu viditeľnú strešnú plochu.
- Rovnaké nepriehľadné plochy, hĺbkový test a skryté stenové švy používa interaktívne 3D aj všetky štyri PDF pohľady.

## 3.7.11

- Všetky štyri strany PDF používajú formát ISO A4 na výšku (`595 × 842 pt`).
- Úvodná strana obsahuje štyri izometrické 3D pohľady po 90°, teda jeden z každého rohu prezentačnej dosky.
- Každý PDF 3D pohľad sa renderuje samostatne približne v kvalite 432 DPI a po vložení sa okamžite uvoľní z pamäte.
- Vnútorné strešné švy sú oddelené od obvodových hrán a v 3D výstupoch sa kreslia jemnou bledosivou farbou.
- Technický 2D pôdorys zostáva vektorový a bol preusporiadaný na plochu A4 portrétu.

## 3.7.10

- Logové štvoruholníky majú po oprave severnej osi explicitné vonkajšie poradie trojuholníkov; OpenGL už nevníma pohľadovú stranu loga ako vnútornú stranu strechy.
- UV súradnice OpenGL a zdrojové rohy statického Kotlin/PDF renderera používajú pôvodné, horizontálne neprevrátené SVG.
- Spodná hrana loga zostáva orientovaná po spáde ku odkvapu, pričom čitateľnosť textu je nezávislá od poradia vrcholov plochy.
- Strešné okná, výlezy a prestupy zostávajú na vonkajšej strane roviny `FaceId`; ich vrchné plochy používajú vonkajšie normály.

## 3.7.9

- Opravená orientácia mapového severu v 3D bez zásahu do správneho 2D pôdorysu; 3D model už nie je zrkadlový voči ortofotomape.
- Prevod lokálnych osí do OpenGL je rigidný a zachováva pravé uhly stien aj pri otočenom pôdoryse.
- Prezentačná doska sa automaticky zarovná s najdlhšou stranou objektu a má jemný dvojitý obvodový rám podľa referenčného PHP modelu.
- PDF izometrické pohľady používajú tenký rám dosky a sú bez kót, aby zostal 3D model čistý a čitateľný.
- Strešné okno a výlez sa natáčajú šírkou rovnobežne s odkvapom a ich plocha kopíruje rovinu príslušnej strešnej plochy.
- Okno, výlez a prestup možno v interaktívnom 3D potiahnuť po strešných plochách; poloha zostáva viazaná na konkrétny `FaceId`.
- Výlez má parametrickú šírku a dĺžku, prestup parametrický priemer; všetky hodnoty sa nastavujú rovnakým rozmerovým kolieskom.
- Regresná sada obsahuje 60 úspešných geometrických a renderovacích testov.

## 3.7.8

- Pôdorysné kóty sú pevne ukotvené v 3D priestore na prezentačnej doske; pri otáčaní modelu sa už neposúvajú v pixeloch.
- Pri spoločnej kóte rovnobežných protiľahlých stien sa raz deterministicky vyberie fyzická strana dosky a kamera ju už neprepína na opačnú stranu.
- Ak sa pevná kóta dostane za nepriehľadný model, môže sa skryť hĺbkovým testom namiesto toho, aby preskočila na inú polohu.
- Rovnaké pravidlo pevného umiestnenia používa interaktívny OpenGL pohľad aj statický Kotlin renderer pre PDF.
- Regresná sada obsahuje 59 úspešných geometrických a renderovacích testov.

## 3.7.7

- Prezentačná doska pod domom sa počíta z úplných hraníc vyriešenej strechy podľa pravidiel zo `sikma_polvalbova_stn.php`.
- Pôdorysné kóty majú skutočnú 3D polohu na hornej ploche dosky a kolmé vynášacie čiary k spodnej hrane stien.
- Prepojená sieť hrebeňov, nároží a úžľabí sa rieši spoločne aj pri rozdielnych šírkach L-krídel, bez pridávania uzlov alebo hrán.
- Spodok loga je na každej ploche orientovaný po spáde smerom k odkvapu.
- Šírka komína sa automaticky natáča rovnobežne s lokálnym odkvapom.
- Regresná sada bola rozšírená na 58 geometrických a renderovacích testov.

## 3.7.6

- Pod domom sa generuje samostatná prezentačná základová platňa podľa referenčného HTML renderera.
- Rozmery platne sa automaticky odvodia z aktuálneho pôdorysu: presah je najmenej 1,2 m alebo 18 % väčšieho rozmeru objektu a hrúbka najmenej 120 mm alebo 1,4 % väčšieho rozmeru.
- Platňa je súčasťou OpenGL aj statického Kotlin renderera pre PDF, ale nevstupuje do výkazu strechy.
- Steny používajú modernejšiu svetlosivú farbu a platňa jemný samostatný materiál bez rušivého obvodového prekreslenia.

## 3.7.5

- Nadväzujúce atiky používajú v spoločnom rohu jediný miterový vnútorný bod, takže medzi úsekmi nevzniká medzera ani prekrývajúca sa koncová stena.
- Koncové steny atiky sa vytvárajú iba na skutočne voľných koncoch súvislého pásu.
- Šírka atiky je uložený parametrický rozmer projektu a dá sa meniť priamo kliknutím na kótu v 3D modeli.
- Staršie projekty bez uloženej šírky atiky sa bezpečne načítajú s predvolenou hodnotou 250 mm.

## 3.7.3

- Opravená zostávajúca vodorovná zrkadlovosť firemného loga. OpenGL a statický PDF renderer používajú jednu explicitnú transformáciu SVG textúry, takže zobrazenie je zhodné v oboch výstupoch.
- Kontrola pripravenosti 3D topológie už nepovažuje samotný uzavretý obvod za hotovú strechu, ak nakreslené hrebene, nárožia alebo úžľabia zostali voľnými mostmi v jednej ploche.
- Každá vnútorná konštrukčná hrana musí patriť dvom rôznym strešným plochám. Ak podmienka nie je splnená, príprava 3D automaticky spustí magnetické spojenie koncov a rozdelenie obvodových hrán.
- Bežný šesťbodový L-pôdorys s dvoma štítmi, dvoma hrebeňmi, nárožím a úžľabím vytvára štyri uzavreté plochy, 3D mesh a výmeru.
- Pribudli regresné testy pre L-strechu a spoločnú orientáciu loga v OpenGL/PDF.

## 3.7.2

- Logo v interaktívnom 3D modeli aj statických PDF pohľadoch používa všetkých 12 pôvodných Bézierových ciest z dodaného `logo.svg`; nepoužíva náhradné písmo ani ručne aproximovaný obrys.
- Textúrový štvoruholník loga má opravené čelné vinutie. OpenGL navyše zahadzuje zadnú stranu loga, takže nápis nemožno vidieť zrkadlovo cez strešnú plochu.
- Pôdorysné kóty sa kotvia na spodnú hranu stien (`wallBottom`), teda na základňu budovy, nie na odkvap ani na hornú hranu steny.
- Regresné testy kontrolujú počet pôvodných SVG ciest, orientáciu oboch logo plôch a výšku všetkých pôdorysných kót voči základni modelu.

## 3.7.1

- Statický Kotlin renderer pre PDF už nepoužíva priemerné triedenie trojuholníkov maliarskym algoritmom. Nový `SoftwareDepthRasterizer` udržiava hĺbku každého pixelu.
- Strešné a stenové plochy sú v PDF plne nepriehľadné. Bližší fragment vyhrá nezávisle od poradia trojuholníkov.
- Hrany stien, hrebeňov a ostatnej technickej geometrie prechádzajú rovnakým hĺbkovým testom. Čiary zakryté strechou alebo prednou stenou sa nevykreslia.
- Odstránilo sa obkresľovanie jednotlivých triangulačných trojuholníkov, ktoré vytváralo falošné vnútorné diagonály stien.
- Aj bitmapové logo sa najprv perspektívne transformuje do samostatnej vrstvy a následne sa kompozituje iba cez viditeľné pixely jeho strešnej plochy.
- Regresné testy overujú poradie prekrývajúcich sa plôch a potlačenie zadnej hrany za nepriehľadnou stenou.

## 3.7.0

- Pôdorysné 3D kóty sa odvodzujú z obrysu stien budovy, nie z odkvapových hrán strechy.
- Uniformný presah je jedna spoločná projektová kóta; renderer iba vyberá jej najčitateľnejšie umiestnenie podľa kamery.
- Uložený obrys stien sa pred extrúziou validuje voči počtu vrcholov, ploche a polohe aktuálneho strešného obrysu. Starý obdĺžnik preto nemôže nahradiť nový L/T/K pôdorys.
- Import nového polygonu zahodí nekompatibilný starý `wallFootprint`; šesť zalomení pôdorysu vytvorí šesť zodpovedajúcich stenových úsekov.
- 3D príprava kontroluje plošné pokrytie celej hranice. Dve náhodne uzavreté plochy už nie sú považované za hotovú topológiu L/K strechy, ak zvyšok pôdorysu zostáva otvorený.
- Orientácia loga je kanonická bez ohľadu na smer cyklu plochy a jeho strecha s komínom bola proporčne spresnená podľa dodaného loga.
- Pribudli regresné testy pre šesťbodový konkávny pôdorys, zastaraný obdĺžnik stien, kóty stien a jedinú spoločnú kótu presahu.

## 3.6.1

- Explicitná plochá strecha už nepotrebuje hrebeň, nárožia, úžľabia ani vnútorné línie; uzavretý obrys vytvorí jednu strešnú plochu.
- Obvod s kombináciou atiky a odkvapu sa vyhodnotí ako vnútorná spádová rovina smerujúca k odkvapu. Pri celom obvode z atiky sa smer deterministicky odvodí od najdlhšej hrany.
- Atika už nie je chybnou nízkou hranou výškového solvera, takže neblokuje nastavený sklon vnútornej plochy.
- Nová atika má predvolenú výšku 300 mm. Staršie projekty s uloženou výškou si zachovajú vlastnú hodnotu.
- 3D atika je plný pás s vonkajšou stenou, vnútornou stenou, koncami a vodorovnou hornou korunou; jej vrch sa pri spádovaní vnútornej plochy nenakláňa.
- Kóta `Atika 300 mm` je súčasťou interaktívneho OpenGL modelu aj statických PDF izometrií. Kliknutie otvorí koliesko s krokom 10 mm a spoločným Undo.
- Regresia pokrýva plochú strechu s tromi atikami a jedným odkvapom aj plochý obrys so štyrmi odkvapovými hranami bez vnútorných línií.

## 3.6.0

- Kóty sa už nekreslia za každú cenu pred modelom: OpenGL projekcia testuje hĺbku voči trojuholníkom a obrazovková vrstva hľadá voľné pixely bez kolízie štítkov a kótovacích čiar.
- Protiľahlé strany pravouhlého štvoruholníka tvoria dve spoločné kóty. Viditeľný kandidát sa mení s kamerou; geometricky sa obe strany upravia naraz.
- Spoločná kóta ortogonalizuje štvorstranný pôdorys, zachová incidencie a ID a parametricky transformuje aj vnútorné uzly. L/T/H obrysy sa nezjednodušujú.
- Steny sa generujú zo samostatného `wallFootprint`, nie zvislým spustením hranice strechy. Presah je preto skutočná 3D geometria.
- Pridané sú klikateľné kóty výšky stien, kolmého presahu a sklonu. Kolieska poskytujú živý náhľad a spoločný Undo krok.
- Uniformný presah používa konštantné polygonálne odsadenie, ktoré zachováva zalomenia miernych L/T/H pôdorysov.
- Namiesto bodkovaného textu sa renderuje skutočné logo StrechoStav s obrysom strechy a komínom. Rovnaké logo používa OpenGL textúra aj samostatný Kotlin/Canvas renderer pre PDF.
- Antracitové plochy majú kontrolovaný odtieňový rozsah približne do 20 %, steny zostávajú svetlobéžové.
- Statické izometrie v PDF dostali rovnaké technické kóty a kolízne rozmiestnenie bez potreby otvorenia 3D obrazovky.
- Regresné testy kontrolujú dve zdieľané rozmery, ortogonalitu, rovnakú dĺžku protiľahlých strán, zachovanie incidencie a dve logo plochy.

## 3.5.0

- Strecha má explicitný antracitový materiál a steny samostatný svetlobéžový materiál; klasifikácia už nezávisí od natočenej normály.
- Pri otáčaní sa jas antracitovej strechy mení iba jemne, v celkovom rozsahu menšom než 10 %; materiálová kresba je ukotvená v modeli a nebliká.
- Statický Kotlin/Canvas renderer používa rovnaké materiálové rozdelenie a farebnú disciplínu ako OpenGL pohľad.
- Na dve najväčšie strešné plochy sa automaticky pridáva vektorový firemný nápis `STRECHOSTAV`; otáča sa s geometriou a zobrazuje sa aj v PDF renderi.
- Obvodové kóty sú vykreslené priamo nad 3D modelom vrátane vynášacích čiar, koncových značiek a hodnoty v milimetroch.
- Kóty sledujú orbit, zoom aj pan. Kliknutie na štítok otvorí koliesko s krokom 50 mm a poskytuje živý náhľad parametrickej zmeny.
- Dotyk mimo kóty zostáva odovzdaný `GLSurfaceView`, takže nová vrstva neblokuje ovládanie modelu.
- Mesh regresia kontroluje oddelené materiály, dve označené plochy a jednu kótu pre každú obvodovú hranu.

## 3.4.0

- Karta 2 používa nový konzervatívny solver: nevytvára body, línie ani priesečníky a nedelí existujúce hrany.
- Obrys je počas korekcie vnútorných línií nemenný; solver môže iba zlúčiť už existujúce blízke konce.
- Hrebene sa jemne dorovnávajú rovnobežne s najbližším smerom obvodu iba v tolerancii 10°.
- Nárožia a úžľabia sa dorovnávajú na 45° voči incidentnej obvodovej hrane; dĺžka každej vnútornej hrany zostáva v rozsahu ±10 %.
- Dialóg korekcie výslovne potvrdzuje nulový počet nových bodov/línií a zobrazuje limity zásahu.
- Spoločná `Roof3DPreparation` pripravuje rovnaký graf pre interaktívne OpenGL 3D, statické bitmapy/PDF aj výkaz.
- Presný rovinný solver zostáva auditným režimom. Ak terénny nákres nemá úplne presné riešenie, renderovací režim vypočíta deterministický spoločný kompromis výšok bez zmeny incidencie a bez prasklín mesh siete.
- Parametrické úpravy kót používajú rovnaký robustný výškový režim; neideálna typológia už sama osebe nevynuluje výkaz.
- Regresné testy pokrývajú zachovanie topológie na karte 2, 10°/45° korekcie a nepresnú valbovú strechu so štyrmi plochami, nenulovým výkazom a 3D mesh sieťou.

## 3.3.1

- Opravený prázdny dialóg „Technický význam hrany“ na karte 3 Typológia. Príčinou bola
  nekompatibilná kombinácia správy a zoznamu v Android `AlertDialog`.
- Dlhé podržanie obvodovej alebo vnútornej línie teraz zobrazí všetkých 14 technických typov
  a označí aktuálne nastavený typ.
- Výber okamžite aktualizuje príslušnú hranu v kanonickom `RoofGraph`; XY poloha uzlov sa nemení.
- Voľba Atika otvorí zadanie výšky atiky a voľba Zvýšená nízka hrana zadanie absolútnej výšky.
- Pri neplatnom alebo odpojenom EdgeId aplikácia používateľa upozorní namiesto tichého zlyhania.

## 3.3.0

- Nový samostatný renderer pôdorysu podľa kresliacich zásad STN 01 3420.
- Monochromatická hierarchia čiar: hrubý obrys strechy, stredné prieniky plôch, tenké kóty a pomocné čiary.
- Kóty obvodových hrán aj celkových rozmerov sa kreslia mimo geometrie, s 45° koncovými značkami a rozmermi v milimetroch.
- Presná automatická voľba štandardnej mierky a titulný blok v PDF výkrese.
- SVG export používa rovnaký čiernobiely technický charakter a bodkočiarkovaný obrys muriva.
- Interaktívne OpenGL ES 3.0 3D aj statické bitmapové 3D používajú zjednotenú antracitovú strechu, neutrálne steny, výraznejšie plošné tieňovanie a ostré technické hrany.
- Vizualizačné zmeny nemenia RoofGraph, rovnice strešných rovín, výpočet plôch ani výkaz výmer.

## 3.2.0

- interaktívne 3D zostáva samostatným `GLSurfaceView` rendererom nad OpenGL ES 3.0,
- surface a edge GLSL shadery `#version 300 es` sú uložené ako textové konštanty priamo v Kotlin súbore,
- nový `RoofBitmapRenderer` vykresľuje rovnaký validovaný mesh do `Bitmap` iba cez Kotlin a Android Canvas,
- bitmapový renderer má vlastnú kameru, perspektívu, painterovo triedenie, tieňovanie stien/strechy a technické hrany,
- zoznam rozsahu prác zobrazuje statický 3D náhľad bez vytvorenia OpenGL obrazovky,
- PDF vkladá dve samostatne renderované bitmapové izometrie a nevyžaduje otvorenie 3D obrazovky ani screenshot.

## 3.1.1

- magnetizácia konca vnútornej línie uprednostní blízky vrchol polygónu pred projekciou na susednú obvodovú hranu,
- korekcia odstráni staršie chybné kolineárne úseky 76/183 mm a nárožie prepojí priamo so skutočným rohom,
- spoločný uzol nároží/úžľabí sa v karte Vnútorné línie rieši na presných 45° bez pohybu fyzického obrysu,
- koniec hrebeňa sa môže bezpečne posunúť po rovnej štítovej hrane, aby hrebeň zostal rovnobežný a roviny mali spoločnú výšku,
- regresný polvalbový príklad kontroluje päť obvodových úsekov, tri plochy a neblokovaný presný 3D výpočet.

## 3.1.0

- `FaceSlopeConstraint` používa explicitný smer spádu; staré grafy sa migrujú bez zmeny geometrie,
- nový exact equality solver rieši spoločné Z uzlov a konštanty rovín deterministickou elimináciou,
- konflikt hard constraints sa blokuje namiesto priemerovania alebo tichého clamping-u,
- bodové výškové kóty s `x/y`, zvýšené nízke hrany a spoločné vpuste skutočne ovplyvňujú roviny,
- rozšírené typy hrán: rake, low edge, elevated low edge, step a opening boundary,
- `GraphFace` podporuje otvory, komponent a hostiteľskú plochu; pridané strešné komponenty a drain constraints,
- stenový pôdorys je oddelený od hranice strechy a staré projekty sa automaticky migrujú na schému 6,
- detektor topologických udalostí blokuje zánik hrebeňa, hrany alebo plochy bez explicitnej retopologizácie,
- validátor kontroluje incidenciu 1/2 plôch, orientáciu, koplanaritu 0,001 mm, Eulerov invariant a odkazy komponentov,
- nový 3D builder dopĺňa odvodené telesá komína, strešného okna, výlezu a prestupu,
- kanonický JSON adaptér a regresná L-polvalbová skúška overujú 14 uzlov, 19 hrán a 6 plôch.
- `ProjectJson` priamo importuje `roof-face-model/1.x` vrátane oddeleného stenového pôdorysu,
- plocha s otvorom bez presného neprekrývajúceho rozdelenia bezpečne zablokuje 3D a výkaz namiesto zakrytia otvoru.

## 3.0.0

- jediným zdrojom geometrickej pravdy je `RoofGraph` schémy 5 so stabilnými `NodeId`, `EdgeId` a `FaceId`,
- staré schema-4 projekty sa automaticky migrujú; legacy `polygon/lines/edgeTypes/RoofShape` zostávajú iba kompatibilným zrkadlom/metadátami,
- sedem oddelených pracovných kariet: Obrys, Vnútorné línie, Typológia, 3D model, Výkaz výmer, Rozsah prác a PDF,
- odstránené používateľské OSM vrstvy a trvalé tlačidlo Posun; ZBGIS dlaždice sa ukladajú trvalo po projektoch,
- podržanie voľného miesta 1 sekundu aktivuje iba dočasný posun; pinch zoomuje podklad aj celú topologickú geometriu,
- freehand počas ťahu kreslí iba plynulú stopu a finálny obrys vytvorí až po vyhladení na najviac 10 bodov,
- rozdelenie obvodovej hrany pracuje nad `EdgeId`; pohyb celej hrany zachová dĺžku a smer,
- obrys a vnútorné línie majú samostatné korekcie; vnútorné hrany vznikajú ako `UNKNOWN`,
- Typológia zamyká XY a mení iba `EdgeSemantic`; technické objekty poznajú `attachedFaceId`/`attachedEdgeId`,
- generický `RoofPlaneSolver` vytvára 3D iba z faces a rovníc `z = ax + by + c`, bez výberu presetu strechy,
- 3D kóty majú samostatné hitboxy, krok 50 mm, live preview a jeden Undo krok,
- výkaz používa skutočné 3D plochy a dĺžky s auditom podľa FaceId/EdgeId,
- lokálny WorkCatalog podporuje automatické množstvá, ručný override a editovateľné ceny bez servera,
- deterministický štvorstranový PDF obsahuje dva izometrické pohľady, pôdorys, audit výmer a rozpočet,
- rozšírené JVM regresné testy canonical grafu, migrácie, incidencií, sedlovej/valbovej/polvalbovej/L a kombinovanej plochej + šikmej siete.

## 2.6.0

- korekcia obrysu prenesená z PHP: dominantná os, rovnobežné strany, pravé uhly a povolené 45° hrany,
- nárožia a úžľabia sa zarovnávajú na presných 45° voči pripojeným odkvapovým hranám,
- pripojené vnútorné línie sa pri korekcii pohybujú so spoločnými topologickými uzlami,
- bezpečnú časť korekcie možno potvrdiť aj v rozpracovanom nákrese a zostávajúcu líniu potom ručne dopojiť,
- po výbere obvodovej alebo vnútornej línie možno upravovať iba jej dva konce,
- dlhé podržanie obvodovej hrany ponúka `Pridať bod` presne do jej stredu,
- odstránené horné tlačidlo `Bod` a tlačidlo `OSM terén`,
- staršie projekty s OSM terénom sa automaticky a bezpečne prepnú na OSM mapu,
- regresné testy rozdelenia hrany, odstránenia bodu, pravouhlosti, rovnobežnosti, 45° línií a čiastočných opráv.

## 2.5.0

- priame kontextové menu typu obvodovej hrany po dlhšom podržaní,
- odstránené skryté pretváranie pôdorysu pred topologickou korekciou,
- korektný solver polvalby s dvoma štítovými úsekmi, hrebeňom a dvoma nárožiami,
- automatické 3D rozlišuje odkvap od štítu, pultovej hrany, atiky a napojenia pri murive,
- zvýšený koniec hrebeňa na štíte už neklesne na výšku muriva,
- regresné testy pre tri plochy polvalby a výškovú väzbu hrebeňa na štíte,
- zrozumiteľnejší náhľad korekcie bez technického počítadla „Chyby“.

## 2.4.0

- spoločný posun, zoom a dvojprstová rotácia mapy, polygónu, línií a objektov,
- tlačidlo Sever na okamžité vynulovanie natočenia,
- vyhladenie voľnej ruky a limit najviac 10 významných bodov obrysu,
- magnetické prichytenie vnútorných línií k uzlom, vrcholom a hranám,
- výber editovateľného bodu dlhým podržaním, oranžové zvýraznenie a vibrácia,
- samostatné spodné tlačidlo Odstrániť bod,
- nastaviteľná výška atiky a skutočná zvislá atiková stena v 3D,
- JSON schéma 4 so spätným načítaním projektov bez rotácie a výšky atiky.

## 2.3.0

- stabilný dvojvrstvový renderer máp bez odkrývania prázdnych dlaždíc,
- päť úrovní digitálneho zoomu nad zdrojovým limitom ZBGIS/OSM,
- topologický graf uzlov a hrán so solverom priesečníkov, T-napojení, snapu a merge,
- nezáväzný vizuálny náhľad korekcie pred zápisom do projektu,
- režim editácie koncov vnútorných strešných línií,
- Undo aj Redo a transakčné prijatie solvera,
- validácia topológie pred 3D a triangulácia automatickej strechy po plochách,
- ear clipping pre konkávne ploché a pultové pôdorysy,
- JSON schéma 3 so spätnou migráciou starších projektov,
- kompaktná päťtlačidlová spodná lišta s vektorovými ikonami,
- regresné testy topológie, konkávneho pôdorysu a JSON migrácie.

## 2.2.0

- Google Maps SDK aj API kľúč boli úplne odstránené,
- bezplatná cestná vrstva OpenStreetMap a terénna vrstva OpenTopoMap,
- slovenské ortofoto cez verejnú WMS službu ZBGIS v EPSG:3857,
- automatické skladanie všetkých dlaždíc potrebných pre aktuálnu obrazovku a zoom,
- sedemdňová lokálna cache dlaždíc a povinné uvedenie zdroja dát,
- adresa sa naďalej mení na GPS cez Nominatim s cache a obmedzením požiadaviek,
- staré projekty s Google typmi máp sa automaticky prevedú na nové bezplatné vrstvy.

## 2.1.1

- zoom mapy a výkresu kolieskom pripojenej myši.

## 2.1.0

- opravená diagnostika prázdnej Google mapy spôsobenej chýbajúcim alebo nesprávne obmedzeným API kľúčom,
- GitHub build sa bez `MAPS_API_KEY` zastaví namiesto vytvorenia nefunkčnej mapovej zostavy,
- stabilný debug podpis a uvedený SHA-1 pre Android obmedzenie Google API kľúča,
- zoom mapy dvoma prstami aj tlačidlami `+`, `−` a `Celok`,
- import PDF/JPG/PNG/WebP ako kresliaceho podkladu,
- posun, zoom a uloženie transformácie výkresového podkladu,
- výber obvodovej hrany a nastavenie dĺžky číselnými kolieskami,
- kalibrácia celého výkresu podľa jednej známej dĺžky,
- dĺžky obvodových hrán sa zobrazujú priamo v editore.

## 2.0.0

- názov aplikácie zmenený na StrechoStav Sketch,
- Google ortofotomapa, hybridná mapa a terén namiesto OSM dlaždíc,
- samostatné tlačidlo `Bod`,
- bezpečné odsadenie obsahu od hornej a dolnej systémovej lišty Androidu,
- 3D model obsahuje steny pôdorysu s nastaviteľnou výškou od 3 m,
- automatický tvar strechy podľa hrebeňov, nároží a úžľabí v nákrese,
- podpora kombinovaných tvarov vrátane polvalby,
- z výkazu, SVG a PDF odstránená hydroizolácia, podklad a ceny,
- Google Maps API kľúč sa načítava zo `secrets.properties` alebo GitHub secretu.

## 1.0.0

- prvá natívna Android verzia,
- dotykový 2D editor strechy,
- technické línie a prvky,
- lokálne projekty, JSON, SVG, PDF a 3D náhľad,
- GitHub Actions workflow na zostavenie debug APK.
# 3.7.4

- Základové kóty sa ukladajú na spodnú hranu stien a ich pomocné čiary smerujú kolmo mimo viditeľnej siluety modelu.
- Pomocné a hranové čiary skryté za nepriehľadnou strechou alebo stenou sa už nekreslia cez plochy.
- Atika má výškovú kótu; komín má šírku, dĺžku a výšku; strešné okno má šírku a dĺžku.
- Rozmery komínov a okien možno meniť z karty Typológia aj priamo kliknutím na 3D kótu.
- Všetky numerické nastavenia používajú jednotné kruhové koliesko podľa STN PHP predlohy (15° na jeden krok, haptická odozva a oneskorené potvrdenie OK).
- Statický Kotlin/PDF renderer používa rovnaké technické kóty a potláča pomocné čiary prechádzajúce cez model.
# 3.7.59

- Spodný obal strechy nad výklenkom používa jednu fyzickú obálku odvodenú z rovín `z = a*x + b*y + c`.
- V konkávnom rohu sa už nepriemerujú dve strešné roviny; skladba, čelné podbitie a podhľad sledujú nižšiu platnú plochu.
- Žľab sleduje vyriešenú strešnú rovinu a jeho horný okraj je 30 mm pod hranou strechy, takže nepláva v skladbe.
# 3.7.60

- Parametrická zmena rozmeru rešpektuje pevnú hierarchiu strešných traktov: hlavný trakt, samostatné krídlo, výstupok a výklenok.
- Úprava výstupku už nesmie posunúť uzly, hrany ani vnútorné línie hlavného traktu; nižšia časť sa prispôsobuje vyššej priorite.
- Protiľahlá hrana sa pri zmene kóty hľadá prednostne v rovnakej sémantickej oblasti WallFootprint.
- Steny výstupku pri mierne odsadenom murive preberajú hornú hranu z tej istej roviny strechy `z = a*x + b*y + c`.
- Pridané regresné testy hierarchie traktov, nemennosti hlavného traktu a strešného profilu odsadených stien výstupku.
