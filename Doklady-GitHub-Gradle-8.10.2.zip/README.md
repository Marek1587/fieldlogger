# Doklady

Natívna offline-first Android aplikácia v Kotlin/Jetpack Compose na evidenciu dokladov.

## Aktuálny vertikálny modul M1

- CameraX náhľad a snímanie fotografie
- systémový Android Photo Picker pre výber jednej alebo viacerých existujúcich fotografií
- bez oprávnenia na čítanie celej galérie
- bezpečné kopírovanie originálov do interného úložiska aplikácie
- Room evidencia prijatých dokladov
- spoľahlivé zaradenie každého dokladu do unikátnej WorkManager úlohy
- jednoduchá Compose domovská obrazovka a stav frontu

## Zostavenie

Projekt vyžaduje JDK 17, Android SDK 35 a je zladený s Gradle 8.10.2.

```powershell
.\gradlew.bat testDebugUnitTest assembleDebug
```

Debug APK vznikne v `app/build/outputs/apk/debug/app-debug.apk`.

Ďalšie moduly budú rozširovať existujúci work chain o predspracovanie obrazu, OCR, parsovanie a validáciu bez zmeny vstupného toku z fotoaparátu alebo galérie.
