package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Test
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentStatus
import sk.doklady.data.ImageSource

class HomeUiStateTest {
    @Test
    fun `camera and gallery inputs share the same processing queue`() {
        val state = HomeUiState(
            documents = listOf(
                document("camera", ImageSource.CAMERA, DocumentStatus.CAPTURED),
                document("gallery", ImageSource.GALLERY, DocumentStatus.OCR),
                document("done", ImageSource.GALLERY, DocumentStatus.PROCESSED),
                document("review", ImageSource.CAMERA, DocumentStatus.REVIEW_REQUIRED),
            ),
        )

        assertEquals(2, state.processingCount)
        assertEquals(1, state.processedCount)
        assertEquals(1, state.reviewCount)
    }

    private fun document(
        id: String,
        source: ImageSource,
        status: DocumentStatus,
    ) = DocumentEntity(
        id = id,
        status = status,
        imageSource = source,
        originalImagePath = "C:/$id.jpg",
        originalDisplayName = "$id.jpg",
        originalMimeType = "image/jpeg",
        createdAt = 1L,
        updatedAt = 1L,
    )
}
