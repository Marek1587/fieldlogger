package sk.doklady

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import sk.doklady.ui.CameraScanner

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = MaterialTheme.colorScheme.copy(
                    primary = Color(0xFF1E5B45),
                    secondary = Color(0xFFE5A11A),
                    background = Color(0xFFF6F7F2),
                    surface = Color(0xFFF6F7F2),
                ),
            ) {
                DokladyApp(viewModel)
            }
        }
    }
}

@Composable
private fun DokladyApp(viewModel: MainViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var showCamera by remember { mutableStateOf(false) }
    var cameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                viewModel.getApplication(),
                Manifest.permission.CAMERA,
            ) == PackageManager.PERMISSION_GRANTED,
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted ->
        cameraPermission = granted
        if (granted) showCamera = true
    }
    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(50),
    ) { uris -> viewModel.importGallery(uris) }

    LaunchedEffect(state.message) {
        state.message?.let {
            snackbar.showSnackbar(it)
            viewModel.dismissMessage()
        }
    }

    if (showCamera && cameraPermission) {
        CameraScanner(
            onBack = { showCamera = false },
            onCapture = { imageCapture, executor ->
                viewModel.capture(imageCapture, executor) { showCamera = false }
            },
        )
        return
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        HomeScreen(
            state = state,
            modifier = Modifier.padding(padding),
            onCamera = {
                if (cameraPermission) showCamera = true
                else permissionLauncher.launch(Manifest.permission.CAMERA)
            },
            onGallery = {
                galleryLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly),
                )
            },
        )
    }
}

@Composable
private fun HomeScreen(
    state: HomeUiState,
    modifier: Modifier = Modifier,
    onCamera: () -> Unit,
    onGallery: () -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 20.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Doklady", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text(
            "Odfoťte alebo vyberte existujúcu fotografiu. Spracovanie pokračuje na pozadí.",
            color = Color(0xFF52605A),
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = onCamera,
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(18.dp),
        ) {
            Text("ODFOTIŤ DOKLAD", fontWeight = FontWeight.Bold)
        }
        Button(
            onClick = onGallery,
            enabled = !state.importing,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2E9E5), contentColor = Color(0xFF153E30)),
            shape = RoundedCornerShape(18.dp),
        ) {
            if (state.importing) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
            } else {
                Text("VYBRAŤ Z GALÉRIE", fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Spracúva sa", state.processingCount, Modifier.weight(1f))
            StatCard("Spracované", state.processedCount, Modifier.weight(1f))
            StatCard("Na kontrolu", state.reviewCount, Modifier.weight(1f))
        }
        if (state.documents.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("Zatiaľ tu nie sú žiadne doklady.", color = Color(0xFF69766F))
            }
        } else {
            Text("Posledné doklady", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            state.documents.take(5).forEach { document ->
                Surface(shape = RoundedCornerShape(14.dp), tonalElevation = 1.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Column {
                            Text(document.originalDisplayName ?: "Fotografia z fotoaparátu")
                            Text(
                                if (document.imageSource.name == "GALLERY") "Galéria" else "Fotoaparát",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF69766F),
                            )
                        }
                        Text(document.status.name, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(16.dp), color = Color.White) {
        Column(Modifier.padding(12.dp)) {
            Text(value.toString(), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = Color(0xFF69766F))
        }
    }
}
