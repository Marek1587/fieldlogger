package sk.doklady.storage

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class StoredImage(
    val id: String,
    val file: File,
    val displayName: String?,
    val mimeType: String,
)

class DocumentStorage(private val context: Context) {
    private val originalsDir: File
        get() = File(context.filesDir, "documents/original").apply { mkdirs() }

    fun createCameraTarget(): StoredImage {
        val id = UUID.randomUUID().toString()
        return StoredImage(
            id = id,
            file = File(originalsDir, "${id}_original.jpg"),
            displayName = null,
            mimeType = "image/jpeg",
        )
    }

    fun importFromGallery(uri: Uri): StoredImage {
        val resolver = context.contentResolver
        val id = UUID.randomUUID().toString()
        val mimeType = resolver.getType(uri) ?: "image/jpeg"
        val extension = when (mimeType.lowercase()) {
            "image/png" -> "png"
            "image/webp" -> "webp"
            "image/heic", "image/heif" -> "heic"
            else -> "jpg"
        }
        val target = File(originalsDir, "${id}_original.$extension")
        val displayName = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }

        try {
            resolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Fotografiu sa nepodarilo otvoriť." }
                FileOutputStream(target).use { output -> input.copyTo(output) }
            }
            require(target.length() > 0L) { "Vybraná fotografia je prázdna." }
        } catch (error: Throwable) {
            target.delete()
            throw error
        }

        return StoredImage(id, target, displayName, mimeType)
    }

    fun discard(image: StoredImage) {
        image.file.delete()
    }
}
