package sk.doklady.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DocumentDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(document: DocumentEntity)

    @Query("SELECT * FROM documents ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<DocumentEntity>>

    @Query("SELECT * FROM documents WHERE id = :id")
    suspend fun get(id: String): DocumentEntity?

    @Query("UPDATE documents SET status = :status, updatedAt = :updatedAt, errorMessage = :error WHERE id = :id")
    suspend fun updateStatus(
        id: String,
        status: DocumentStatus,
        updatedAt: Long,
        error: String? = null,
    )
}
