package sk.doklady.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class DocumentStatus {
    CAPTURED,
    PREPROCESSING,
    OCR,
    PARSING,
    VALIDATING,
    PROCESSED,
    REVIEW_REQUIRED,
    ERROR,
}

enum class ImageSource { CAMERA, GALLERY }

@Entity(tableName = "documents")
data class DocumentEntity(
    @PrimaryKey val id: String,
    val status: DocumentStatus,
    val imageSource: ImageSource,
    val originalImagePath: String,
    val originalDisplayName: String?,
    val originalMimeType: String,
    val createdAt: Long,
    val updatedAt: Long,
    val errorMessage: String? = null,
)
