package sk.doklady

import android.app.Application
import sk.doklady.data.AppDatabase
import sk.doklady.storage.DocumentStorage
import sk.doklady.work.DocumentWorkScheduler

class DokladyApplication : Application() {
    val database by lazy { AppDatabase.create(this) }
    val storage by lazy { DocumentStorage(this) }
    val scheduler by lazy { DocumentWorkScheduler(this) }
}
