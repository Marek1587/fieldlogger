package sk.doklady

import android.app.Application
import android.net.Uri
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import sk.doklady.data.DocumentEntity
import sk.doklady.data.DocumentStatus
import sk.doklady.data.ImageSource
import sk.doklady.storage.StoredImage
import java.util.concurrent.Executor

data class HomeUiState(
    val documents: List<DocumentEntity> = emptyList(),
    val importing: Boolean = false,
    val message: String? = null,
) {
    val processingCount: Int get() = documents.count {
        it.status in setOf(
            DocumentStatus.CAPTURED,
            DocumentStatus.PREPROCESSING,
            DocumentStatus.OCR,
            DocumentStatus.PARSING,
            DocumentStatus.VALIDATING,
        )
    }
    val processedCount: Int get() = documents.count { it.status == DocumentStatus.PROCESSED }
    val reviewCount: Int get() = documents.count { it.status == DocumentStatus.REVIEW_REQUIRED }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as DokladyApplication
    private val transient = MutableStateFlow(TransientState())

    val uiState: StateFlow<HomeUiState> = combine(
        app.database.documents().observeAll(),
        transient,
    ) { documents, state ->
        HomeUiState(documents, state.importing, state.message)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    fun importGallery(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            transient.value = TransientState(importing = true)
            var imported = 0
            var failed = 0
            for (uri in uris) {
                try {
                    val stored = withContext(Dispatchers.IO) { app.storage.importFromGallery(uri) }
                    persist(stored, ImageSource.GALLERY)
                    imported++
                } catch (_: Throwable) {
                    failed++
                }
            }
            transient.value = TransientState(
                message = when {
                    failed == 0 && imported == 1 -> "Fotografia bola zaradená na spracovanie."
                    failed == 0 -> "$imported fotografií bolo zaradených na spracovanie."
                    else -> "Importované: $imported, nepodarilo sa: $failed."
                },
            )
        }
    }

    fun capture(
        imageCapture: ImageCapture,
        executor: Executor,
        onFinished: () -> Unit,
    ) {
        val stored = app.storage.createCameraTarget()
        val options = ImageCapture.OutputFileOptions.Builder(stored.file).build()
        imageCapture.takePicture(
            options,
            executor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    viewModelScope.launch {
                        try {
                            persist(stored, ImageSource.CAMERA)
                            transient.value = TransientState(message = "Doklad bol zaradený na spracovanie.")
                            onFinished()
                        } catch (_: Throwable) {
                            app.storage.discard(stored)
                            transient.value = TransientState(message = "Fotografiu sa nepodarilo uložiť.")
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    app.storage.discard(stored)
                    transient.value = TransientState(message = "Fotografovanie zlyhalo: ${exception.message}")
                }
            },
        )
    }

    fun dismissMessage() {
        transient.value = transient.value.copy(message = null)
    }

    private suspend fun persist(stored: StoredImage, source: ImageSource) {
        val now = System.currentTimeMillis()
        try {
            withContext(Dispatchers.IO) {
                app.database.documents().insert(
                    DocumentEntity(
                        id = stored.id,
                        status = DocumentStatus.CAPTURED,
                        imageSource = source,
                        originalImagePath = stored.file.absolutePath,
                        originalDisplayName = stored.displayName,
                        originalMimeType = stored.mimeType,
                        createdAt = now,
                        updatedAt = now,
                    ),
                )
            }
            app.scheduler.enqueue(stored.id)
        } catch (error: Throwable) {
            app.storage.discard(stored)
            throw error
        }
    }

    private data class TransientState(
        val importing: Boolean = false,
        val message: String? = null,
    )
}
