package sk.doklady.work

import android.content.Context
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

class DocumentWorkScheduler(context: Context) {
    private val workManager = WorkManager.getInstance(context.applicationContext)

    fun enqueue(documentId: String) {
        val request = OneTimeWorkRequestBuilder<IntakeWorker>()
            .setInputData(Data.Builder().putString(IntakeWorker.DOCUMENT_ID, documentId).build())
            .addTag("document:$documentId")
            .build()
        workManager.enqueueUniqueWork(
            "document:$documentId:intake",
            ExistingWorkPolicy.KEEP,
            request,
        )
    }
}
