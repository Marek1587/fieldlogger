package sk.doklady.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import sk.doklady.DokladyApplication
import sk.doklady.data.DocumentStatus
import java.io.File

class IntakeWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString(DOCUMENT_ID) ?: return Result.failure()
        val dao = (applicationContext as DokladyApplication).database.documents()
        val document = dao.get(id) ?: return Result.failure()
        if (!File(document.originalImagePath).let { it.isFile && it.length() > 0L }) {
            dao.updateStatus(id, DocumentStatus.ERROR, System.currentTimeMillis(), "Originálny obrázok chýba.")
            return Result.failure()
        }

        // M1 intake boundary. M2 will append preprocessing to this unique work chain.
        return Result.success()
    }

    companion object { const val DOCUMENT_ID = "document_id" }
}
