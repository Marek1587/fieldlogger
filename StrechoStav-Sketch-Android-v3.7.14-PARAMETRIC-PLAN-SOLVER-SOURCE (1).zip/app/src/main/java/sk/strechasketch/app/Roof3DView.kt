package sk.strechasketch.app

import android.content.Context
import android.graphics.PointF
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.sqrt

class Roof3DView(context: Context) : GLSurfaceView(context) {
    private val roofRenderer = Roof3DRenderer()
    private var lastX = 0f
    private var lastY = 0f
    private var lastMidX = 0f
    private var lastMidY = 0f
    var onCameraChanged: (() -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                roofRenderer.zoom = (roofRenderer.zoom * detector.scaleFactor).coerceIn(0.45f, 3.2f)
                requestRender()
                onCameraChanged?.invoke()
                return true
            }
        }
    )
    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        setPreserveEGLContextOnPause(true)
        setRenderer(roofRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        contentDescription = "Interaktívny trojrozmerný model strechy"
    }

    fun setProject(project: RoofProject) {
        roofRenderer.setProject(project)
        requestRender()
        onCameraChanged?.invoke()
    }

    fun resetView() {
        roofRenderer.resetView()
        requestRender()
        onCameraChanged?.invoke()
    }

    internal fun projectedDimensions(): List<ProjectedRoofDimension> =
        roofRenderer.projectDimensions(width.coerceAtLeast(1), height.coerceAtLeast(1))

    internal fun projectedObjects(): List<ProjectedRoofObject> =
        roofRenderer.projectObjects(width.coerceAtLeast(1), height.coerceAtLeast(1))

    internal fun objectDragDelta(objectId: String, dxPixels: Float, dyPixels: Float): LocalPoint? =
        roofRenderer.objectDragDelta(
            objectId, dxPixels, dyPixels, width.coerceAtLeast(1), height.coerceAtLeast(1)
        )

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> if (event.pointerCount >= 2) {
                lastMidX = (event.getX(0) + event.getX(1)) / 2f
                lastMidY = (event.getY(0) + event.getY(1)) / 2f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2) {
                    val midX = (event.getX(0) + event.getX(1)) / 2f
                    val midY = (event.getY(0) + event.getY(1)) / 2f
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.panX += (midX - lastMidX) / density * 0.008f
                    roofRenderer.panY -= (midY - lastMidY) / density * 0.008f
                    lastMidX = midX
                    lastMidY = midY
                    requestRender()
                    onCameraChanged?.invoke()
                } else if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    val density = resources.displayMetrics.density.coerceAtLeast(1f)
                    roofRenderer.yawDegrees += (event.x - lastX) / density * 0.62f
                    roofRenderer.pitchDegrees = (
                        roofRenderer.pitchDegrees + (event.y - lastY) / density * 0.62f
                    ).coerceIn(-82f, 82f)
                    requestRender()
                    onCameraChanged?.invoke()
                }
                lastX = event.x
                lastY = event.y
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}

internal data class RoofVec3(val x: Float, val y: Float, val z: Float) {
    operator fun minus(other: RoofVec3) = RoofVec3(x - other.x, y - other.y, z - other.z)
}

internal data class RoofMesh(
    val triangles: FloatArray,
    val normals: FloatArray,
    val edges: FloatArray,
    /** Ridge/hip/valley and other non-boundary roof seams, styled separately. */
    val internalEdges: FloatArray = FloatArray(0),
    /** Only physical wall-footprint outlines; wall triangulation seams never enter this buffer. */
    val wallEdges: FloatArray = FloatArray(0),
    /** Fine presentation-board frame, rendered independently from technical model edges. */
    val padEdges: FloatArray = FloatArray(0),
    /** One value per triangle vertex: 0 = wall/object, 1 = roof, 2 = presentation pad. */
    val materials: FloatArray = FloatArray(0),
    val logoEdges: FloatArray = FloatArray(0),
    val logoQuads: List<RoofLogoQuad> = emptyList(),
    /** Logo positions on every eligible face, used by the camera-aware PDF fallback. */
    val logoCandidates: List<RoofLogoQuad> = logoQuads,
    val dimensions: List<RoofDimension3D> = emptyList(),
    val objectAnchors: List<RoofObjectAnchor3D> = emptyList(),
    val logoFaceCount: Int = 0,
    /** Number of semantic EAVE shell sections; ATTIC/GABLE edges never contribute. */
    val overhangSectionCount: Int = 0
)

internal data class RoofObjectAnchor3D(
    val objectId: String,
    val type: ObjectType,
    val center: RoofVec3,
    val localX: Double,
    val localY: Double,
    val planeA: Double,
    val planeB: Double,
    val normalization: Float,
    /** Unit normal of the exterior roof side in model coordinates. */
    val outerNormal: RoofVec3
)

internal data class ProjectedRoofObject(
    val objectId: String,
    val type: ObjectType,
    val point: PointF,
    val depth: Float
)

internal data class RoofLogoQuad(
    val faceId: String,
    val topLeft: RoofVec3,
    val topRight: RoofVec3,
    val bottomRight: RoofVec3,
    val bottomLeft: RoofVec3
)

internal enum class RoofDimensionKind {
    PLAN_LENGTH, WALL_HEIGHT, ATTIC_HEIGHT, ATTIC_WIDTH, OVERHANG, SLOPE,
    CHIMNEY_WIDTH, CHIMNEY_LENGTH, CHIMNEY_HEIGHT,
    ROOF_WINDOW_WIDTH, ROOF_WINDOW_LENGTH,
    HATCH_WIDTH, HATCH_LENGTH, VENT_DIAMETER
}

internal data class RoofDimension3D(
    val dimensionId: String,
    val edgeId: String,
    val linkedEdgeIds: List<String> = listOf(edgeId),
    val kind: RoofDimensionKind = RoofDimensionKind.PLAN_LENGTH,
    val start: RoofVec3,
    val end: RoofVec3,
    val witnessStart: RoofVec3,
    val witnessEnd: RoofVec3,
    val lengthM: Double
)

internal data class ProjectedRoofDimension(
    val dimensionId: String,
    val edgeId: String,
    val linkedEdgeIds: List<String>,
    val kind: RoofDimensionKind,
    val start: PointF,
    val end: PointF,
    val witnessStart: PointF,
    val witnessEnd: PointF,
    val lengthM: Double,
    val modelCenter: PointF,
    /** Screen-space direction selected on the empty side of the rendered silhouette. */
    val outwardNormal: PointF,
    /** False when both possible extension-line directions would cross a visible surface. */
    val drawWitnessLines: Boolean
)

/** Presentation policy separated from geometry editing: paired plan dimensions keep one
 * deterministic physical side instead of jumping to whichever side faces the camera. */
internal object RoofDimensionPlacement {
    fun stablePlanCandidates(dimensions: List<RoofDimension3D>): List<RoofDimension3D> =
        dimensions.groupBy { it.dimensionId }.values.flatMap { candidates ->
            if (candidates.all { it.kind == RoofDimensionKind.PLAN_LENGTH }) {
                listOf(candidates.minWith(compareBy<RoofDimension3D> { it.edgeId }
                    .thenBy { it.start.x }.thenBy { it.start.z }))
            } else candidates
        }
}

internal object RoofMeshBuilder {
    private data class PresentationPad(
        val corners: List<LocalPoint>,
        val topZ: Double,
        val bottomZ: Double,
        val margin: Double
    )

    private data class HeightPoint(val p: LocalPoint, val h: Double)
    private data class Triangle(val a: Int, val b: Int, val c: Int)
    private data class Edge(val a: Int, val b: Int) {
        fun normalized() = if (a < b) this else Edge(b, a)
    }

    fun build(project: RoofProject): RoofMesh = buildFromGraph(project)

    private fun signedArea(points: List<LocalPoint>): Double = points.indices.sumOf { index ->
        val a = points[index]
        val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    private fun isCompatibleWallLoop(walls: List<LocalPoint>, roof: List<LocalPoint>): Boolean {
        if (walls.size != roof.size || walls.size < 3) return false
        val roofArea = abs(signedArea(roof))
        val wallArea = abs(signedArea(walls))
        if (roofArea <= 1e-6 || wallArea !in roofArea * 0.04..roofArea * 1.04) return false
        return walls.all { point ->
            Geometry.pointInPolygon(point, roof) || roof.indices.any { index ->
                Geometry.distanceToSegment(point, roof[index], roof[(index + 1) % roof.size]) < 1e-5
            }
        }
    }

    /** Aligns the saved polygon start and winding to the ordered roof boundary. */
    private fun alignLoopToBoundary(walls: List<LocalPoint>, roof: List<LocalPoint>): List<LocalPoint> {
        fun score(candidate: List<LocalPoint>): Double = candidate.indices.sumOf { index ->
            val dx = candidate[index].x - roof[index].x
            val dy = candidate[index].y - roof[index].y
            dx * dx + dy * dy
        }
        val orientations = listOf(walls, walls.reversed())
        return orientations.flatMap { loop ->
            loop.indices.map { shift -> List(loop.size) { index -> loop[(index + shift) % loop.size] } }
        }.minByOrNull(::score) ?: walls
    }

    private fun buildFromGraph(project: RoofProject): RoofMesh {
        if (project.polygon.size < 3) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val solution = Roof3DPreparation.prepare(project).planeSolution
        if (solution.hasBlockingIssues) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        val solved = solution.graph
        if (solved.faces.isEmpty()) return RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))

        val minX = solved.nodes.values.minOf { it.x }
        val maxX = solved.nodes.values.maxOf { it.x }
        val minY = solved.nodes.values.minOf { it.y }
        val maxY = solved.nodes.values.maxOf { it.y }
        val minZ = 0.0
        val maxZ = solved.nodes.values.maxOf { it.z }.coerceAtLeast(project.wallHeightM)
        val span = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
        val normalization = (2.2 / max(span, maxZ - minZ)).toFloat()
        val centerX = (minX + maxX) / 2.0
        val centerY = (minY + maxY) / 2.0
        val centerZ = (minZ + maxZ) / 2.0
        fun point(node: GraphNode, zOffset: Double = 0.0) = RoofVec3(
            ((node.x - centerX) * normalization).toFloat(),
            ((node.z + zOffset - centerZ) * normalization).toFloat(),
            (-(node.y - centerY) * normalization).toFloat()
        )
        fun ground(node: GraphNode) = RoofVec3(
            ((node.x - centerX) * normalization).toFloat(),
            ((-centerZ) * normalization).toFloat(),
            (-(node.y - centerY) * normalization).toFloat()
        )

        val positions = arrayListOf<Float>()
        val normals = arrayListOf<Float>()
        val materials = arrayListOf<Float>()
        val edges = arrayListOf<Float>()
        val internalEdges = arrayListOf<Float>()
        val wallEdges = arrayListOf<Float>()
        val padEdges = arrayListOf<Float>()
        val logoEdges = arrayListOf<Float>()
        val logoQuads = arrayListOf<RoofLogoQuad>()
        val dimensions = arrayListOf<RoofDimension3D>()
        val objectAnchors = arrayListOf<RoofObjectAnchor3D>()
        solved.faces.values.sortedBy { it.id }.forEach { face ->
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            val local2D = nodes.map { LocalPoint(it.x, it.y) }
            earClip(local2D).forEach { triangle ->
                addTriangle(
                    positions, normals, materials,
                    point(nodes[triangle.a]), point(nodes[triangle.b]), point(nodes[triangle.c]),
                    material = 1f
                )
            }
        }
        solved.edges.values.sortedBy { it.id }.forEach { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@forEach
            val b = solved.nodes[edge.endNodeId] ?: return@forEach
            addLine(
                if (edge.boundary) edges else internalEdges,
                point(a, span * 0.002), point(b, span * 0.002)
            )
        }
        val orderedBoundary = RoofTopologyMigration.orderedBoundary(solved.toTopology())
        val boundaryLoop = orderedBoundary?.first
            ?.mapNotNull(solved.nodes::get)
            ?.map { LocalPoint(it.x, it.y) }
            .orEmpty()
        val boundaryEdges = orderedBoundary?.second.orEmpty()

        // The solved RoofGraph may split a gable boundary where a ridge reaches it. That split
        // is necessary for roof faces, but it is not a physical break in the masonry wall.
        // Walls therefore follow the actual saved/project outline, never the solver's split loop.
        val physicalRoofLoop = project.polygon.map { Geometry.toLocal(it, solved.origin) }
        val savedWallLoop = project.wallFootprint
            .takeIf { it.size == physicalRoofLoop.size && it.size >= 3 }
            ?.map { Geometry.toLocal(it, solved.origin) }
        val wallLoop = savedWallLoop
            ?.takeIf { isCompatibleWallLoop(it, physicalRoofLoop) }
            ?: physicalRoofLoop
        val displayDimensions = arrayListOf<RoofDimension3D>()
        val overhangSolution = RoofOverhangSolver.solve(solved, wallLoop)

        val presentationPad = boundaryLoop.takeIf { it.size >= 3 }?.let {
            // Same proportional rules as sikma_polvalbova_stn.php. Bounds come from the
            // solved roof shell (not a stale saved rectangle), therefore unequal L wings,
            // overhangs and later parametric edits always receive a correctly sized board.
            val largestSpan = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
            val margin = max(1.2, largestSpan * 0.18)
            val thickness = max(0.12, largestSpan * 0.014)
            val longest = it.indices.maxBy { index ->
                val a = it[index]
                val b = it[(index + 1) % it.size]
                hypot(b.x - a.x, b.y - a.y)
            }
            val longestA = it[longest]
            val longestB = it[(longest + 1) % it.size]
            val longestLength = hypot(longestB.x - longestA.x, longestB.y - longestA.y).coerceAtLeast(1e-9)
            var ux = (longestB.x - longestA.x) / longestLength
            var uy = (longestB.y - longestA.y) / longestLength
            // Canonical sign makes the board stable even if polygon winding is reversed.
            if (ux < -1e-9 || (abs(ux) <= 1e-9 && uy < 0.0)) { ux = -ux; uy = -uy }
            val vx = -uy
            val vy = ux
            val projectedU = it.map { point -> point.x * ux + point.y * uy }
            val projectedV = it.map { point -> point.x * vx + point.y * vy }
            val minU = projectedU.min() - margin
            val maxU = projectedU.max() + margin
            val minV = projectedV.min() - margin
            val maxV = projectedV.max() + margin
            fun framedPoint(u: Double, v: Double) = LocalPoint(ux * u + vx * v, uy * u + vy * v)
            PresentationPad(
                corners = listOf(
                    framedPoint(minU, minV), framedPoint(maxU, minV),
                    framedPoint(maxU, maxV), framedPoint(minU, maxV)
                ),
                topZ = -0.08,
                bottomZ = -0.08 - thickness,
                margin = margin
            )
        }

        // Presentation pad from the reference HTML renderer. Its dimensions are derived from
        // the current object bounds, so a small house and an L/T/H footprint receive the same
        // proportional margin. The pad is display-only and never enters roof quantities.
        presentationPad?.let { pad ->
            fun padPoint(id: String, local: LocalPoint, z: Double) = point(GraphNode(id, local.x, local.y, z))
            val top = pad.corners.mapIndexed { index, local -> padPoint("pad-top-$index", local, pad.topZ) }
            val bottom = pad.corners.mapIndexed { index, local -> padPoint("pad-bottom-$index", local, pad.bottomZ) }
            addTriangle(positions, normals, materials, top[0], top[1], top[2], material = 2f)
            addTriangle(positions, normals, materials, top[0], top[2], top[3], material = 2f)
            repeat(4) { index ->
                val next = (index + 1) % 4
                addTriangle(positions, normals, materials, top[index], bottom[next], top[next], material = 2f)
                addTriangle(positions, normals, materials, top[index], bottom[index], bottom[next], material = 2f)
                // The PHP board has a fine perimeter line. Without it the nearly-white top
                // disappears against the scene background, especially in a top view.
                addLine(padEdges, bottom[index], bottom[next])
            }
            // The reference PHP renderer uses two very fine inset frame lines on the board.
            val sideA = hypot(top[1].x - top[0].x, top[1].z - top[0].z)
            val sideB = hypot(top[2].x - top[1].x, top[2].z - top[1].z)
            val shortSide = minOf(sideA, sideB)
            listOf(shortSide * 0.006f, shortSide * 0.015f).forEach { inset ->
                val frame = top.indices.map { index ->
                    val next = top[(index + 1) % top.size]
                    val previous = top[(index - 1 + top.size) % top.size]
                    val current = top[index]
                    val nextLength = hypot(next.x - current.x, next.z - current.z).coerceAtLeast(1e-6f)
                    val previousLength = hypot(previous.x - current.x, previous.z - current.z).coerceAtLeast(1e-6f)
                    RoofVec3(
                        current.x + (next.x - current.x) / nextLength * inset + (previous.x - current.x) / previousLength * inset,
                        current.y + 0.0025f,
                        current.z + (next.z - current.z) / nextLength * inset + (previous.z - current.z) / previousLength * inset
                    )
                }
                frame.indices.forEach { index -> addLine(padEdges, frame[index], frame[(index + 1) % frame.size]) }
            }
        }

        // Physical overhang shell from the STN reference: fascia, a 200 mm horizontal
        // soffit and (when the overhang is deeper) the sloping rafter underside to the wall.
        // RoofOverhangSolver has already filtered the topology to semantic EAVE edges.
        overhangSolution.sections.forEach { section ->
            val topA = point(section.outerTopA)
            val topB = point(section.outerTopB)
            val outerA = point(section.outerBottomA)
            val outerB = point(section.outerBottomB)
            val flatA = point(section.flatInnerA)
            val flatB = point(section.flatInnerB)
            val innerA = point(section.wallInnerA)
            val innerB = point(section.wallInnerB)

            // Vertical eave/fascia band.
            addTriangle(positions, normals, materials, topA, outerB, topB, material = 0f)
            addTriangle(positions, normals, materials, topA, outerA, outerB, material = 0f)
            // First 200 mm is deliberately horizontal, matching the PHP/STN model.
            addTriangle(positions, normals, materials, outerA, flatB, flatA, material = 0f)
            addTriangle(positions, normals, materials, outerA, outerB, flatB, material = 0f)
            // The remaining underside follows the solved roof plane/rafter slope.
            if (section.overhangM - section.flatDepthM > 1e-5) {
                addTriangle(positions, normals, materials, flatA, innerB, innerA, material = 0f)
                addTriangle(positions, normals, materials, flatA, flatB, innerB, material = 0f)
            }
            // Close the shell against the masonry whenever the rafter underside reaches
            // above the nominal wall-height line. This prevents a daylight gap under a
            // pitched overhang without adding a visible triangulation seam to wallEdges.
            val wallA = point(section.wallInnerA.copy(z = project.wallHeightM))
            val wallB = point(section.wallInnerB.copy(z = project.wallHeightM))
            if (section.wallInnerA.z > project.wallHeightM + 1e-5 ||
                section.wallInnerB.z > project.wallHeightM + 1e-5
            ) {
                addTriangle(positions, normals, materials, wallA, wallB, innerB, material = 0f)
                addTriangle(positions, normals, materials, wallA, innerB, innerA, material = 0f)
            }
        }
        if (wallLoop.size >= 3) {
            val wallTop = wallLoop.mapIndexed { index, local ->
                point(GraphNode("wall-top-$index", local.x, local.y, project.wallHeightM))
            }
            val wallBottom = wallLoop.mapIndexed { index, local ->
                ground(GraphNode("wall-bottom-$index", local.x, local.y, 0.0))
            }
            val solvedBoundaryNodeIds = solved.edges.values.asSequence()
                .filter { it.boundary }
                .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
                .toSet()
            wallLoop.indices.forEach { index ->
                val next = (index + 1) % wallLoop.size
                val localA = wallLoop[index]
                val localB = wallLoop[next]
                val dx = localB.x - localA.x
                val dy = localB.y - localA.y
                val lengthSquared = dx * dx + dy * dy
                val isGable = wallLoop.size == project.polygon.size &&
                    (project.edgeTypes[index] ?: LineType.EAVE) == LineType.GABLE
                val samples = mutableListOf(
                    0.0 to GraphNode("wall-profile-$index-a", localA.x, localA.y, project.wallHeightM),
                    1.0 to GraphNode("wall-profile-$index-b", localB.x, localB.y, project.wallHeightM)
                )
                if (isGable && lengthSquared > 1e-10) {
                    val tolerance = max(0.002, span * 1e-5)
                    solvedBoundaryNodeIds.mapNotNull(solved.nodes::get).forEach { node ->
                        val t = ((node.x - localA.x) * dx + (node.y - localA.y) * dy) / lengthSquared
                        if (t in -1e-6..1.000001 &&
                            Geometry.distanceToSegment(LocalPoint(node.x, node.y), localA, localB) <= tolerance
                        ) {
                            samples += t.coerceIn(0.0, 1.0) to node.copy(z = max(project.wallHeightM, node.z))
                        }
                    }
                }
                val profile = mutableListOf<Pair<Double, GraphNode>>()
                samples.sortedBy { it.first }.forEach { sample ->
                    val previous = profile.lastOrNull()
                    if (previous != null && abs(previous.first - sample.first) <= 1e-6) {
                        if (sample.second.z > previous.second.z) profile[profile.lastIndex] = sample
                    } else profile += sample
                }
                profile.zipWithNext().forEach { (from, to) ->
                    val topA = point(from.second)
                    val topB = point(to.second)
                    val bottomA = ground(from.second)
                    val bottomB = ground(to.second)
                    addTriangle(positions, normals, materials, topA, bottomB, topB, material = 0f)
                    addTriangle(positions, normals, materials, topA, bottomA, bottomB, material = 0f)
                }
                // One line per real footprint segment. Solver-created ridge incidence points do
                // not create vertical seams or split marks on the facade.
                addLine(wallEdges, wallBottom[index], wallBottom[next])
            }

            // Plan dimensions belong to the building footprint and lie on the foundation/base
            // line, not on the roof eaves or on the upper wall edge.
            // Their edge IDs remain linked to the corresponding roof boundary constraints,
            // allowing the existing parametric editor to keep working.
            val rawPlanDimensions = wallLoop.indices.mapNotNull { index ->
                // orderedBoundary can start at a different cyclic vertex than the legacy list.
                // Always prefer the actual edge at this canonical position; a fabricated index
                // can silently resize another wall after loading or correcting a project.
                val edgeId = if (boundaryEdges.size == wallLoop.size) {
                    boundaryEdges[index].id
                } else {
                    "footprint-edge-${index.toString().padStart(4, '0')}"
                        .takeIf(solved.edges::containsKey)
                        ?: boundaryEdges.getOrNull(index)?.id
                        ?: return@mapNotNull null
                }
                val baseA = wallBottom[index]
                val baseB = wallBottom[(index + 1) % wallBottom.size]
                val edgeX = baseB.x - baseA.x
                val edgeZ = baseB.z - baseA.z
                val edgeLength = hypot(edgeX, edgeZ).coerceAtLeast(0.0001f)
                var outwardX = -edgeZ / edgeLength
                var outwardZ = edgeX / edgeLength
                val midX = (baseA.x + baseB.x) / 2f
                val midZ = (baseA.z + baseB.z) / 2f
                if (outwardX * midX + outwardZ * midZ < 0f) {
                    outwardX = -outwardX
                    outwardZ = -outwardZ
                }
                // Place the actual dimension line on the board, while extension lines still
                // start at the building footprint. The board margin is the safe drawing zone.
                val offset = ((presentationPad?.margin ?: 0.55) * normalization * 0.58)
                    .toFloat().coerceAtLeast(0.105f)
                val lift = 0.006f
                val padTopY = presentationPad?.let {
                    point(GraphNode("pad-dimension", 0.0, 0.0, it.topZ)).y
                } ?: baseA.y
                RoofDimension3D(
                    dimensionId = "edge-$edgeId",
                    edgeId = edgeId,
                    start = RoofVec3(baseA.x + outwardX * offset, padTopY + lift, baseA.z + outwardZ * offset),
                    end = RoofVec3(baseB.x + outwardX * offset, padTopY + lift, baseB.z + outwardZ * offset),
                    witnessStart = baseA,
                    witnessEnd = baseB,
                    lengthM = hypot(
                        wallLoop[(index + 1) % wallLoop.size].x - wallLoop[index].x,
                        wallLoop[(index + 1) % wallLoop.size].y - wallLoop[index].y
                    )
                )
            }
            displayDimensions += collapseSymmetricBoundaryDimensions(solved, rawPlanDimensions)

            // Several candidates share one ID. Projection keeps the visible candidate, so the
            // height dimension moves naturally to the visible facade as the user orbits the model.
            wallLoop.indices.forEach { index ->
                val top = wallTop[index]
                val bottom = wallBottom[index]
                displayDimensions += RoofDimension3D(
                    dimensionId = "wall-height",
                    edgeId = "wall-height-$index",
                    linkedEdgeIds = emptyList(),
                    kind = RoofDimensionKind.WALL_HEIGHT,
                    start = bottom,
                    end = top,
                    witnessStart = bottom,
                    witnessEnd = top,
                    lengthM = project.wallHeightM
                )
            }

            fun nearestPointOnWall(point: LocalPoint): LocalPoint {
                var best = wallLoop.first()
                var bestDistance = Double.POSITIVE_INFINITY
                wallLoop.indices.forEach { index ->
                    val a = wallLoop[index]
                    val b = wallLoop[(index + 1) % wallLoop.size]
                    val dx = b.x - a.x
                    val dy = b.y - a.y
                    val denominator = dx * dx + dy * dy
                    val t = if (denominator <= 1e-12) 0.0 else
                        (((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator).coerceIn(0.0, 1.0)
                    val candidate = LocalPoint(a.x + dx * t, a.y + dy * t)
                    val distance = hypot(candidate.x - point.x, candidate.y - point.y)
                    if (distance < bestDistance) {
                        bestDistance = distance
                        best = candidate
                    }
                }
                return best
            }
            val eaveEdges = boundaryEdges.filter { solved.edges[it.id]?.semanticRole == EdgeSemantic.EAVE }
            val eaveEdgeIds = eaveEdges.map { it.id }
            val overhangCandidates = eaveEdges.mapIndexedNotNull { index, edge ->
                val roofA = solved.nodes[edge.startNodeId]
                val roofB = solved.nodes[edge.endNodeId]
                if (roofA != null && roofB != null) {
                    val roofMid = LocalPoint((roofA.x + roofB.x) / 2.0, (roofA.y + roofB.y) / 2.0)
                    val wallPoint = nearestPointOnWall(roofMid)
                    val overhang = hypot(roofMid.x - wallPoint.x, roofMid.y - wallPoint.y)
                    val displayWallPoint = if (overhang > 0.001) wallPoint else {
                        val cx = boundaryLoop.map { it.x }.average()
                        val cy = boundaryLoop.map { it.y }.average()
                        val dx = cx - roofMid.x
                        val dy = cy - roofMid.y
                        val length = hypot(dx, dy).coerceAtLeast(1e-9)
                        LocalPoint(roofMid.x + dx / length * span * 0.035, roofMid.y + dy / length * span * 0.035)
                    }
                    val roof3D = point(GraphNode("overhang-roof-$index", roofMid.x, roofMid.y, project.wallHeightM))
                    val wall3D = point(GraphNode("overhang-wall-$index", displayWallPoint.x, displayWallPoint.y, project.wallHeightM))
                    RoofDimension3D(
                        dimensionId = "roof-overhang",
                        edgeId = edge.id,
                        linkedEdgeIds = eaveEdgeIds,
                        kind = RoofDimensionKind.OVERHANG,
                        start = wall3D,
                        end = roof3D,
                        witnessStart = wall3D,
                        witnessEnd = roof3D,
                        lengthM = overhang
                    )
                } else null
            }
            // A uniform offset is one project parameter. Several geometric candidates share
            // one ID and the projection layer selects the clearest visible placement.
            val representativeOverhang = overhangCandidates.map { it.lengthM }.sorted().let { values ->
                when {
                    values.isEmpty() -> 0.0
                    values.size % 2 == 1 -> values[values.size / 2]
                    else -> (values[values.size / 2 - 1] + values[values.size / 2]) / 2.0
                }
            }
            displayDimensions += overhangCandidates.map { it.copy(lengthM = representativeOverhang) }
        }

        // A degree-mark dimension is anchored to the two largest planes. It is not forced into the
        // foreground; the depth test selects the visible mark and the overlay finds free pixels.
        solved.faces.values.sortedByDescending { face ->
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            abs(nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            })
        }.take(2).forEachIndexed { index, face ->
            val plane = face.plane ?: return@forEachIndexed
            val nodes = face.orderedNodeIds.mapNotNull(solved.nodes::get)
            if (nodes.size < 3) return@forEachIndexed
            val cx = nodes.map { it.x }.average()
            val cy = nodes.map { it.y }.average()
            val longest = nodes.indices.map { nodeIndex ->
                val a = nodes[nodeIndex]
                val b = nodes[(nodeIndex + 1) % nodes.size]
                Triple(b.x - a.x, b.y - a.y, hypot(b.x - a.x, b.y - a.y))
            }.maxByOrNull { it.third } ?: return@forEachIndexed
            val half = minOf(longest.third * 0.12, span * 0.09).coerceAtLeast(span * 0.025)
            val ux = longest.first / longest.third.coerceAtLeast(1e-9)
            val uy = longest.second / longest.third.coerceAtLeast(1e-9)
            fun slopePoint(sign: Double): RoofVec3 {
                val x = cx + ux * half * sign
                val y = cy + uy * half * sign
                return point(GraphNode("slope-$index-$sign", x, y, plane.zAt(x, y)), span * 0.004)
            }
            val a = slopePoint(-1.0)
            val b = slopePoint(1.0)
            displayDimensions += RoofDimension3D(
                dimensionId = "roof-slope",
                edgeId = "roof-slope-$index",
                linkedEdgeIds = emptyList(),
                kind = RoofDimensionKind.SLOPE,
                start = a,
                end = b,
                witnessStart = a,
                witnessEnd = b,
                lengthM = project.slopeDeg
            )
        }
        val atticEdges = solved.edges.values.filter { it.semanticRole == EdgeSemantic.ATTIC && it.boundary }
        val atticHeight = project.atticHeightM.coerceIn(0.1, 3.0)
        val atticWidth = project.atticWidthM.coerceIn(0.06, 1.5)
        val atticTopZ = atticEdges.flatMap { edge ->
            listOfNotNull(solved.nodes[edge.startNodeId], solved.nodes[edge.endNodeId])
        }.maxOfOrNull { it.z }?.plus(atticHeight)

        data class AtticOffset(
            val edge: GraphEdge,
            val a: GraphNode,
            val b: GraphNode,
            val inwardX: Double,
            val inwardY: Double,
            val face: GraphFace?
        )
        fun atticOffset(edge: GraphEdge): AtticOffset? {
            val a = solved.nodes[edge.startNodeId] ?: return null
            val b = solved.nodes[edge.endNodeId] ?: return null
            val face = edge.adjacentFaceIds.firstNotNullOfOrNull(solved.faces::get)
                ?: solved.faces.values.firstOrNull { edge.id in it.orderedEdgeIds }
            val faceNodes = face?.orderedNodeIds?.mapNotNull(solved.nodes::get).orEmpty()
            val centroidX = faceNodes.map { it.x }.average().takeIf(Double::isFinite) ?: (a.x + b.x) / 2.0
            val centroidY = faceNodes.map { it.y }.average().takeIf(Double::isFinite) ?: (a.y + b.y) / 2.0
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            var inwardX = -dy / length
            var inwardY = dx / length
            val midX = (a.x + b.x) / 2.0
            val midY = (a.y + b.y) / 2.0
            if (inwardX * (centroidX - midX) + inwardY * (centroidY - midY) < 0.0) {
                inwardX = -inwardX
                inwardY = -inwardY
            }
            return AtticOffset(edge, a, b, inwardX, inwardY, face)
        }
        val atticOffsets = atticEdges.mapNotNull(::atticOffset).associateBy { it.edge.id }
        val atticAtNode = atticEdges.flatMap { edge ->
            listOf(edge.startNodeId to edge.id, edge.endNodeId to edge.id)
        }.groupBy({ it.first }, { it.second })
        fun offsetIntersection(first: AtticOffset, second: AtticOffset): LocalPoint? {
            val ax = first.a.x + first.inwardX * atticWidth
            val ay = first.a.y + first.inwardY * atticWidth
            val adx = first.b.x - first.a.x
            val ady = first.b.y - first.a.y
            val bx = second.a.x + second.inwardX * atticWidth
            val by = second.a.y + second.inwardY * atticWidth
            val bdx = second.b.x - second.a.x
            val bdy = second.b.y - second.a.y
            val denominator = adx * bdy - ady * bdx
            if (kotlin.math.abs(denominator) <= 1e-9) return null
            val t = ((bx - ax) * bdy - (by - ay) * bdx) / denominator
            return LocalPoint(ax + adx * t, ay + ady * t)
        }
        fun joinedInnerPoint(current: AtticOffset, node: GraphNode): Pair<LocalPoint, Boolean> {
            val raw = LocalPoint(
                node.x + current.inwardX * atticWidth,
                node.y + current.inwardY * atticWidth
            )
            val neighbour = atticAtNode[node.id].orEmpty()
                .firstOrNull { it != current.edge.id }
                ?.let(atticOffsets::get)
                ?: return raw to false
            val intersection = offsetIntersection(current, neighbour) ?: return raw to true
            // An almost straight or malformed corner can yield a remote mathematical
            // intersection. Keep a bounded bevel there instead of creating a spike.
            val miterLength = hypot(intersection.x - node.x, intersection.y - node.y)
            return if (miterLength <= atticWidth * 6.0) intersection to true else raw to true
        }
        atticEdges.forEach { edge ->
            val offset = atticOffsets[edge.id] ?: return@forEach
            val a = offset.a
            val b = offset.b
            val topZ = atticTopZ ?: return@forEach
            val midX = (a.x + b.x) / 2.0
            val midY = (a.y + b.y) / 2.0
            val (innerA, joinedAtA) = joinedInnerPoint(offset, a)
            val (innerB, joinedAtB) = joinedInnerPoint(offset, b)
            val innerAX = innerA.x
            val innerAY = innerA.y
            val innerBX = innerB.x
            val innerBY = innerB.y
            val plane = offset.face?.plane
            val outerBottomA = point(GraphNode("attic-outer-a-${edge.id}", a.x, a.y, project.wallHeightM))
            val outerBottomB = point(GraphNode("attic-outer-b-${edge.id}", b.x, b.y, project.wallHeightM))
            val innerBottomA = point(GraphNode(
                "attic-inner-a-${edge.id}", innerAX, innerAY, plane?.zAt(innerAX, innerAY) ?: a.z
            ))
            val innerBottomB = point(GraphNode(
                "attic-inner-b-${edge.id}", innerBX, innerBY, plane?.zAt(innerBX, innerBY) ?: b.z
            ))
            val outerTopA = point(GraphNode("attic-top-oa-${edge.id}", a.x, a.y, topZ))
            val outerTopB = point(GraphNode("attic-top-ob-${edge.id}", b.x, b.y, topZ))
            val innerTopA = point(GraphNode("attic-top-ia-${edge.id}", innerAX, innerAY, topZ))
            val innerTopB = point(GraphNode("attic-top-ib-${edge.id}", innerBX, innerBY, topZ))

            // Exterior, interior and horizontal crown make the parapet a real solid band.
            addTriangle(positions, normals, materials, outerBottomA, outerBottomB, outerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerBottomA, outerTopB, outerTopA, material = 0f)
            addTriangle(positions, normals, materials, innerBottomB, innerBottomA, innerTopA, material = 0f)
            addTriangle(positions, normals, materials, innerBottomB, innerTopA, innerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerTopA, outerTopB, innerTopB, material = 0f)
            addTriangle(positions, normals, materials, outerTopA, innerTopB, innerTopA, material = 0f)
            if (!joinedAtA) {
                addTriangle(positions, normals, materials, outerBottomA, outerTopA, innerTopA, material = 0f)
                addTriangle(positions, normals, materials, outerBottomA, innerTopA, innerBottomA, material = 0f)
            }
            if (!joinedAtB) {
                addTriangle(positions, normals, materials, outerBottomB, innerBottomB, innerTopB, material = 0f)
                addTriangle(positions, normals, materials, outerBottomB, innerTopB, outerTopB, material = 0f)
            }
            addLine(edges, outerTopA, outerTopB)
            addLine(edges, innerTopA, innerTopB)
            addLine(edges, outerTopA, innerTopA)
            addLine(edges, outerTopB, innerTopB)

            val dimensionBottom = point(GraphNode(
                "attic-dimension-bottom-${edge.id}", midX, midY, topZ - atticHeight
            ))
            val dimensionTop = point(GraphNode(
                "attic-dimension-top-${edge.id}", midX, midY, topZ
            ))
            displayDimensions += RoofDimension3D(
                dimensionId = "attic-height",
                edgeId = edge.id,
                linkedEdgeIds = atticEdges.map { it.id },
                kind = RoofDimensionKind.ATTIC_HEIGHT,
                start = dimensionBottom,
                end = dimensionTop,
                witnessStart = dimensionBottom,
                witnessEnd = dimensionTop,
                lengthM = atticHeight
            )
            val widthStart = point(GraphNode(
                "attic-width-outer-${edge.id}", midX, midY, topZ
            ))
            val widthEnd = point(GraphNode(
                "attic-width-inner-${edge.id}",
                midX + offset.inwardX * atticWidth,
                midY + offset.inwardY * atticWidth,
                topZ
            ))
            displayDimensions += RoofDimension3D(
                dimensionId = "attic-width",
                edgeId = edge.id,
                linkedEdgeIds = atticEdges.map { it.id },
                kind = RoofDimensionKind.ATTIC_WIDTH,
                start = widthStart,
                end = widthEnd,
                witnessStart = widthStart,
                witnessEnd = widthEnd,
                lengthM = atticWidth
            )
        }
        // Technical objects are a derived shell layer. They never own or duplicate roof topology.
        project.objects.filter { it.type in setOf(
            ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH, ObjectType.VENT
        ) }.forEach { item ->
            val local = Geometry.toLocal(item.center, solved.origin)
            val face = item.attachedFaceId?.let(solved.faces::get) ?: solved.faces.values.firstOrNull { candidate ->
                val outer = candidate.orderedNodeIds.mapNotNull(solved.nodes::get).map { LocalPoint(it.x, it.y) }
                val insideOuter = outer.size >= 3 && Geometry.pointInPolygon(local, outer)
                val insideHole = candidate.holeNodeIdLoops.any { loop ->
                    val hole = loop.mapNotNull(solved.nodes::get).map { LocalPoint(it.x, it.y) }
                    hole.size >= 3 && Geometry.pointInPolygon(local, hole)
                }
                insideOuter && !insideHole
            } ?: return@forEach
            val plane = face.plane ?: return@forEach
            val width = when (item.type) {
                ObjectType.VENT -> item.diameterMm
                else -> item.widthMm
            }.coerceAtLeast(100.0) / 1000.0
            val depth = when (item.type) {
                ObjectType.VENT -> item.diameterMm
                else -> item.heightMm
            }.coerceAtLeast(100.0) / 1000.0
            val shellHeight = when (item.type) {
                ObjectType.CHIMNEY -> (item.value.takeIf { it > 0.0 } ?: 0.8).coerceIn(0.2, 8.0)
                ObjectType.HATCH -> 0.18
                ObjectType.VENT -> 0.35
                else -> 0.045
            }
            val gradientLength = hypot(plane.a, plane.b)
            val levelDirection = if (gradientLength > 1e-8) atan2(-plane.a, plane.b) else null
            // Width follows the real eave of the attached face. This applies equally to
            // chimneys, roof windows and access hatches; stored manual rotation is only a
            // fallback for legacy/flat faces without an identifiable low edge.
            val angle = when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH ->
                    faceEaveDirection(solved, face) ?: levelDirection ?: Math.toRadians(item.rotationDeg)
                else -> Math.toRadians(item.rotationDeg)
            }
            val cos = kotlin.math.cos(angle); val sin = kotlin.math.sin(angle)
            fun corner(dx: Double, dy: Double, top: Boolean): RoofVec3 {
                val x = local.x + dx * cos - dy * sin
                val y = local.y + dx * sin + dy * cos
                return point(GraphNode("object", x, y, plane.zAt(x, y) + if (top) shellHeight else 0.012))
            }
            val bottom = listOf(
                corner(-width / 2, -depth / 2, false), corner(width / 2, -depth / 2, false),
                corner(width / 2, depth / 2, false), corner(-width / 2, depth / 2, false)
            )
            val top = listOf(
                corner(-width / 2, -depth / 2, true), corner(width / 2, -depth / 2, true),
                corner(width / 2, depth / 2, true), corner(-width / 2, depth / 2, true)
            )
            if (item.type == ObjectType.VENT) {
                val segments = 16
                val radius = width / 2.0
                val ringBottom = (0 until segments).map { index ->
                    val theta = 2.0 * PI * index / segments
                    corner(kotlin.math.cos(theta) * radius, kotlin.math.sin(theta) * radius, false)
                }
                val ringTop = (0 until segments).map { index ->
                    val theta = 2.0 * PI * index / segments
                    corner(kotlin.math.cos(theta) * radius, kotlin.math.sin(theta) * radius, true)
                }
                val topCenter = corner(0.0, 0.0, true)
                repeat(segments) { index ->
                    val next = (index + 1) % segments
                    addTriangle(positions, normals, materials, topCenter, ringTop[index], ringTop[next], material = 0f)
                    addTriangle(positions, normals, materials, ringBottom[index], ringBottom[next], ringTop[next], material = 0f)
                    addTriangle(positions, normals, materials, ringBottom[index], ringTop[next], ringTop[index], material = 0f)
                    addLine(edges, ringTop[index], ringTop[next])
                }
            } else {
                addTriangle(positions, normals, materials, top[0], top[1], top[2], material = 0f)
                addTriangle(positions, normals, materials, top[0], top[2], top[3], material = 0f)
                repeat(4) { index ->
                    val next = (index + 1) % 4
                    addTriangle(positions, normals, materials, bottom[index], bottom[next], top[next], material = 0f)
                    addTriangle(positions, normals, materials, bottom[index], top[next], top[index], material = 0f)
                    addLine(edges, top[index], top[next])
                }
            }
            objectAnchors += RoofObjectAnchor3D(
                objectId = item.id,
                type = item.type,
                center = point(GraphNode("object-anchor", local.x, local.y, plane.zAt(local.x, local.y) + shellHeight)),
                localX = local.x,
                localY = local.y,
                planeA = plane.a,
                planeB = plane.b,
                normalization = normalization,
                outerNormal = run {
                    val length = sqrt(plane.a * plane.a + plane.b * plane.b + 1.0).toFloat()
                    RoofVec3(-plane.a.toFloat() / length, 1f / length, plane.b.toFloat() / length)
                }
            )
            fun objectDimension(
                suffix: String,
                kind: RoofDimensionKind,
                a: RoofVec3,
                b: RoofVec3,
                metres: Double
            ) {
                displayDimensions += RoofDimension3D(
                    dimensionId = "object-${item.id}-$suffix",
                    edgeId = item.id,
                    linkedEdgeIds = emptyList(),
                    kind = kind,
                    start = a,
                    end = b,
                    witnessStart = a,
                    witnessEnd = b,
                    lengthM = metres
                )
            }
            when (item.type) {
                ObjectType.CHIMNEY -> {
                    objectDimension("width", RoofDimensionKind.CHIMNEY_WIDTH, top[0], top[1], width)
                    objectDimension("length", RoofDimensionKind.CHIMNEY_LENGTH, top[1], top[2], depth)
                    objectDimension("height", RoofDimensionKind.CHIMNEY_HEIGHT, bottom[2], top[2], shellHeight)
                }
                ObjectType.ROOF_WINDOW -> {
                    objectDimension("width", RoofDimensionKind.ROOF_WINDOW_WIDTH, top[0], top[1], width)
                    objectDimension("length", RoofDimensionKind.ROOF_WINDOW_LENGTH, top[1], top[2], depth)
                }
                ObjectType.HATCH -> {
                    objectDimension("width", RoofDimensionKind.HATCH_WIDTH, top[0], top[1], width)
                    objectDimension("length", RoofDimensionKind.HATCH_LENGTH, top[1], top[2], depth)
                }
                ObjectType.VENT -> objectDimension(
                    "diameter", RoofDimensionKind.VENT_DIAMETER,
                    top[0], top[1], width
                )
                else -> Unit
            }
        }
        val allLogoCandidates = arrayListOf<RoofLogoQuad>()
        addCompanyLogos(solved, span, ::point, allLogoCandidates)
        logoQuads += allLogoCandidates.take(2)
        val logoFaceCount = logoQuads.size
        return RoofMesh(
            triangles = positions.toFloatArray(),
            normals = normals.toFloatArray(),
            edges = edges.toFloatArray(),
            internalEdges = internalEdges.toFloatArray(),
            wallEdges = wallEdges.toFloatArray(),
            padEdges = padEdges.toFloatArray(),
            materials = materials.toFloatArray(),
            logoEdges = logoEdges.toFloatArray(),
            logoQuads = logoQuads,
            logoCandidates = allLogoCandidates,
            dimensions = displayDimensions,
            objectAnchors = objectAnchors,
            logoFaceCount = logoFaceCount,
            overhangSectionCount = overhangSolution.sections.size
        )
    }

    /** Deterministic ear clipping for a simple face; unlike triangle fans it is safe for concave polygons. */
    private fun earClip(polygon: List<LocalPoint>): List<Triangle> {
        if (polygon.size < 3) return emptyList()
        fun cross2(a: LocalPoint, b: LocalPoint, c: LocalPoint) =
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        val signedArea = polygon.indices.sumOf { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            a.x * b.y - b.x * a.y
        }
        val indices = if (signedArea >= 0.0) polygon.indices.toMutableList()
        else polygon.indices.reversed().toMutableList()
        fun inside(p: LocalPoint, a: LocalPoint, b: LocalPoint, c: LocalPoint): Boolean {
            val ab = cross2(a, b, p)
            val bc = cross2(b, c, p)
            val ca = cross2(c, a, p)
            return ab >= -1e-8 && bc >= -1e-8 && ca >= -1e-8
        }
        val result = mutableListOf<Triangle>()
        var guard = 0
        while (indices.size > 3 && guard++ < polygon.size * polygon.size) {
            var clipped = false
            for (position in indices.indices) {
                val previous = indices[(position - 1 + indices.size) % indices.size]
                val current = indices[position]
                val next = indices[(position + 1) % indices.size]
                val a = polygon[previous]
                val b = polygon[current]
                val c = polygon[next]
                if (cross2(a, b, c) <= 1e-8) continue
                if (indices.any { candidate ->
                        candidate != previous && candidate != current && candidate != next &&
                            inside(polygon[candidate], a, b, c)
                    }
                ) continue
                result += Triangle(previous, current, next)
                indices.removeAt(position)
                clipped = true
                break
            }
            if (!clipped) return emptyList()
        }
        if (indices.size == 3 && abs(cross2(polygon[indices[0]], polygon[indices[1]], polygon[indices[2]])) > 1e-8) {
            result += Triangle(indices[0], indices[1], indices[2])
        }
        return result
    }

    private fun buildSurfaceSamples(
        polygon: List<LocalPoint>,
        lines: List<Triple<LineType, LocalPoint, LocalPoint>>,
        maxSpan: Double,
        wallHeight: Double,
        height: (LocalPoint) -> Double
    ): List<HeightPoint> {
        val spacing = (maxSpan / 11.0).coerceAtLeast(0.35)
        val points = mutableListOf<LocalPoint>()
        fun addUnique(point: LocalPoint) {
            if (points.none { hypot(it.x - point.x, it.y - point.y) < spacing * 0.08 }) points += point
        }
        polygon.indices.forEach { index ->
            val a = polygon[index]
            val b = polygon[(index + 1) % polygon.size]
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(1, kotlin.math.ceil(length / spacing).toInt())
            for (step in 0 until count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        lines.forEach { (_, a, b) ->
            val length = hypot(b.x - a.x, b.y - a.y)
            val count = max(2, kotlin.math.ceil(length / (spacing * 0.55)).toInt())
            for (step in 0..count) {
                val t = step.toDouble() / count
                addUnique(LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        val minX = polygon.minOf { it.x }
        val maxX = polygon.maxOf { it.x }
        val minY = polygon.minOf { it.y }
        val maxY = polygon.maxOf { it.y }
        var y = minY + spacing * 0.5
        while (y < maxY) {
            var x = minX + spacing * 0.5
            while (x < maxX) {
                val p = LocalPoint(x, y)
                if (Geometry.pointInPolygon(p, polygon)) addUnique(p)
                x += spacing
            }
            y += spacing
        }
        return points.map { HeightPoint(it, max(wallHeight, height(it))) }
    }

    private fun delaunay(points: List<LocalPoint>, polygon: List<LocalPoint>): List<Triangle> {
        if (points.size < 3) return emptyList()
        val all = points.toMutableList()
        val minX = points.minOf { it.x }
        val maxX = points.maxOf { it.x }
        val minY = points.minOf { it.y }
        val maxY = points.maxOf { it.y }
        val span = max(maxX - minX, maxY - minY).coerceAtLeast(1.0)
        val midX = (minX + maxX) / 2.0
        val midY = (minY + maxY) / 2.0
        val originalCount = all.size
        all += LocalPoint(midX - span * 20, midY - span * 10)
        all += LocalPoint(midX, midY + span * 20)
        all += LocalPoint(midX + span * 20, midY - span * 10)
        val triangles = mutableListOf(Triangle(originalCount, originalCount + 1, originalCount + 2))
        for (index in 0 until originalCount) {
            val bad = triangles.filter { circumcircleContains(all, it, all[index]) }
            val counts = linkedMapOf<Edge, Int>()
            bad.forEach { triangle ->
                listOf(Edge(triangle.a, triangle.b), Edge(triangle.b, triangle.c), Edge(triangle.c, triangle.a))
                    .map { it.normalized() }
                    .forEach { edge -> counts[edge] = (counts[edge] ?: 0) + 1 }
            }
            triangles.removeAll(bad.toSet())
            counts.filterValues { it == 1 }.keys.forEach { edge -> triangles += Triangle(edge.a, edge.b, index) }
        }
        return triangles.filter { triangle ->
            triangle.a < originalCount && triangle.b < originalCount && triangle.c < originalCount &&
                Geometry.pointInPolygon(
                    LocalPoint(
                        (all[triangle.a].x + all[triangle.b].x + all[triangle.c].x) / 3.0,
                        (all[triangle.a].y + all[triangle.b].y + all[triangle.c].y) / 3.0
                    ),
                    polygon
                )
        }
    }

    private fun circumcircleContains(points: List<LocalPoint>, triangle: Triangle, point: LocalPoint): Boolean {
        val a = points[triangle.a]
        val b = points[triangle.b]
        val c = points[triangle.c]
        val d = 2.0 * (a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y))
        if (abs(d) < 1e-9) return false
        val a2 = a.x * a.x + a.y * a.y
        val b2 = b.x * b.x + b.y * b.y
        val c2 = c.x * c.x + c.y * c.y
        val ux = (a2 * (b.y - c.y) + b2 * (c.y - a.y) + c2 * (a.y - b.y)) / d
        val uy = (a2 * (c.x - b.x) + b2 * (a.x - c.x) + c2 * (b.x - a.x)) / d
        val radius2 = (ux - a.x) * (ux - a.x) + (uy - a.y) * (uy - a.y)
        val pointDistance2 = (ux - point.x) * (ux - point.x) + (uy - point.y) * (uy - point.y)
        return pointDistance2 <= radius2 + 1e-7
    }

    /** Two shared dimensions are sufficient for an orthogonal four-sided plan. */
    private fun collapseSymmetricBoundaryDimensions(
        graph: RoofGraph,
        raw: List<RoofDimension3D>
    ): List<RoofDimension3D> {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology())?.second ?: return raw
        if (ordered.size != 4) return raw
        val byId = raw.associateBy { it.edgeId }
        fun direction(edge: TopologyEdge): Double {
            val a = graph.nodes.getValue(edge.startNodeId)
            val b = graph.nodes.getValue(edge.endNodeId)
            return atan2(b.y - a.y, b.x - a.x)
        }
        fun angularDistance(a: Double, b: Double): Double {
            var delta = abs(a - b) % PI
            if (delta > PI / 2.0) delta = PI - delta
            return abs(delta)
        }
        val directions = ordered.map(::direction)
        val tolerance = Math.toRadians(10.0)
        val oppositeParallel = angularDistance(directions[0], directions[2]) <= tolerance &&
            angularDistance(directions[1], directions[3]) <= tolerance
        val adjacentOrthogonal = abs(angularDistance(directions[0], directions[1]) - PI / 2.0) <= tolerance
        if (!oppositeParallel || !adjacentOrthogonal) return raw
        val pairs = listOf(0 to 2, 1 to 3)
        return pairs.flatMap { (firstIndex, secondIndex) ->
            val first = byId[ordered[firstIndex].id] ?: return raw
            val second = byId[ordered[secondIndex].id] ?: return raw
            val relativeDifference = abs(first.lengthM - second.lengthM) /
                max(first.lengthM, second.lengthM).coerceAtLeast(1e-9)
            if (relativeDifference > 0.15) return raw
            val dimensionId = "paired-${first.edgeId}-${second.edgeId}"
            val linked = listOf(first.edgeId, second.edgeId)
            val sharedLength = (first.lengthM + second.lengthM) / 2.0
            listOf(
                first.copy(dimensionId = dimensionId, linkedEdgeIds = linked, lengthM = sharedLength),
                second.copy(dimensionId = dimensionId, linkedEdgeIds = linked, lengthM = sharedLength)
            )
        }.takeIf { it.size == 4 } ?: raw
    }

    /** Textured company-logo planes placed above the two largest roof faces. */
    private fun addCompanyLogos(
        graph: RoofGraph,
        span: Double,
        point: (GraphNode, Double) -> RoofVec3,
        output: MutableList<RoofLogoQuad>
    ): Int {
        fun area(face: GraphFace): Double {
            val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            if (nodes.size < 3) return 0.0
            return kotlin.math.abs(nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            } / 2.0)
        }
        var renderedFaces = 0
        graph.faces.values.sortedByDescending(::area).forEach { face ->
            val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            val plane = face.plane ?: return@forEach
            if (nodes.size < 3) return@forEach
            val longest = nodes.indices.map { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                Triple(a, b, hypot(b.x - a.x, b.y - a.y))
            }.maxByOrNull { it.third } ?: return@forEach
            if (longest.third < 1e-6) return@forEach
            val gradientLength = hypot(plane.a, plane.b)
            // Logo top points uphill and its bottom points downhill to the eave. Texture
            // mapping stays semantic (left/right); exterior triangle winding is selected
            // explicitly by the OpenGL upload and is independent from this orientation.
            val uphill = if (gradientLength > 1e-8) {
                LocalPoint(plane.a / gradientLength, plane.b / gradientLength)
            } else {
                val eave = faceEaveDirection(graph, face)
                if (eave != null) LocalPoint(-sin(eave), cos(eave))
                else LocalPoint(
                    -(longest.second.y - longest.first.y) / longest.third,
                    (longest.second.x - longest.first.x) / longest.third
                )
            }
            val vx = uphill.x
            val vy = uphill.y
            val ux = vy
            val uy = -vx
            val polygon = nodes.map { LocalPoint(it.x, it.y) }
            val signed = nodes.indices.sumOf { index ->
                val a = nodes[index]
                val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            }
            var center = if (abs(signed) > 1e-9) {
                LocalPoint(
                    nodes.indices.sumOf { index ->
                        val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                        (a.x + b.x) * (a.x * b.y - b.x * a.y)
                    } / (3.0 * signed),
                    nodes.indices.sumOf { index ->
                        val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                        (a.y + b.y) * (a.x * b.y - b.x * a.y)
                    } / (3.0 * signed)
                )
            } else LocalPoint(nodes.map { it.x }.average(), nodes.map { it.y }.average())
            if (!Geometry.pointInPolygon(center, polygon)) {
                val triangle = earClip(polygon).maxByOrNull { candidate ->
                    abs((polygon[candidate.b].x - polygon[candidate.a].x) * (polygon[candidate.c].y - polygon[candidate.a].y) -
                        (polygon[candidate.b].y - polygon[candidate.a].y) * (polygon[candidate.c].x - polygon[candidate.a].x))
                }
                if (triangle != null) center = LocalPoint(
                    (polygon[triangle.a].x + polygon[triangle.b].x + polygon[triangle.c].x) / 3.0,
                    (polygon[triangle.a].y + polygon[triangle.b].y + polygon[triangle.c].y) / 3.0
                )
            }
            val centerX = center.x
            val centerY = center.y
            val clearance = polygon.indices.minOf { index ->
                Geometry.distanceToSegment(center, polygon[index], polygon[(index + 1) % polygon.size])
            }.coerceAtLeast(longest.third * 0.02)
            val logoWidth = minOf(longest.third * 0.60, clearance * 3.0)
            val logoHeight = logoWidth * 0.46
            val zLift = span * 0.004
            fun logoPoint(along: Double, across: Double): RoofVec3 {
                val x = centerX + ux * along + vx * across
                val y = centerY + uy * along + vy * across
                return point(GraphNode("logo", x, y, plane.zAt(x, y)), zLift)
            }
            output += RoofLogoQuad(
                faceId = face.id,
                topLeft = logoPoint(-logoWidth / 2.0, logoHeight / 2.0),
                topRight = logoPoint(logoWidth / 2.0, logoHeight / 2.0),
                bottomRight = logoPoint(logoWidth / 2.0, -logoHeight / 2.0),
                bottomLeft = logoPoint(-logoWidth / 2.0, -logoHeight / 2.0)
            )
            renderedFaces++
        }
        return renderedFaces
    }

    /** Direction of the longest low/eave edge belonging to a face. */
    private fun faceEaveDirection(graph: RoofGraph, face: GraphFace): Double? =
        face.orderedEdgeIds.asSequence().mapNotNull(graph.edges::get)
            .filter { it.semanticRole in setOf(EdgeSemantic.EAVE, EdgeSemantic.LOW_EDGE, EdgeSemantic.PULT) }
            .mapNotNull { edge ->
                val a = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                val b = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                val length = hypot(b.x - a.x, b.y - a.y)
                if (length <= 1e-8) null else Triple(length, b.x - a.x, b.y - a.y)
            }
            .maxByOrNull { it.first }
            ?.let { atan2(it.third, it.second) }

    private fun addTriangle(
        positions: MutableList<Float>,
        normals: MutableList<Float>,
        materials: MutableList<Float>,
        a: RoofVec3,
        b: RoofVec3,
        c: RoofVec3,
        material: Float
    ) {
        var normal = normalized(cross(b - a, c - a))
        if (normal.y < 0f) {
            normal = RoofVec3(-normal.x, -normal.y, -normal.z)
            addVertex(positions, a)
            addVertex(positions, c)
            addVertex(positions, b)
        } else {
            addVertex(positions, a)
            addVertex(positions, b)
            addVertex(positions, c)
        }
        repeat(3) { addVertex(normals, normal) }
        repeat(3) { materials += material }
    }

    private fun addLine(values: MutableList<Float>, a: RoofVec3, b: RoofVec3) {
        addVertex(values, a)
        addVertex(values, b)
    }

    private fun addVertex(values: MutableList<Float>, value: RoofVec3) {
        values += value.x
        values += value.y
        values += value.z
    }

    private fun cross(a: RoofVec3, b: RoofVec3) = RoofVec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )

    private fun normalized(value: RoofVec3): RoofVec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) RoofVec3(0f, 1f, 0f)
        else RoofVec3(value.x / length, value.y / length, value.z / length)
    }
}

private class Roof3DRenderer : GLSurfaceView.Renderer {
    private data class ProjectedPoint(val point: PointF, val depth: Float)
    @Volatile private var pendingMesh = RoofMesh(FloatArray(0), FloatArray(0), FloatArray(0))
    @Volatile var yawDegrees = -34f
    @Volatile var pitchDegrees = 28f
    @Volatile var zoom = 1f
    @Volatile var panX = 0f
    @Volatile var panY = 0f

    private var width = 1
    private var height = 1
    private var surfaceProgram = 0
    private var edgeProgram = 0
    private var logoProgram = 0
    private var logoTexture = 0
    private var triangleVbo = 0
    private var edgeVbo = 0
    private var logoVbo = 0
    private var triangleCount = 0
    private var edgeCount = 0
    private var internalEdgeCount = 0
    private var wallEdgeCount = 0
    private var padEdgeCount = 0
    private var logoCount = 0
    private var uploaded: RoofMesh? = null

    fun setProject(project: RoofProject) {
        pendingMesh = RoofMeshBuilder.build(project)
    }

    fun resetView() {
        yawDegrees = -34f
        pitchDegrees = 28f
        zoom = 1f
        panX = 0f
        panY = 0f
    }

    private fun projectPoint(
        point: RoofVec3,
        mvp: FloatArray,
        viewWidth: Int,
        viewHeight: Int
    ): ProjectedPoint? {
        val source = floatArrayOf(point.x, point.y, point.z, 1f)
        val clip = FloatArray(4)
        Matrix.multiplyMV(clip, 0, mvp, 0, source, 0)
        val w = clip[3]
        if (!w.isFinite() || w <= 0.0001f) return null
        val ndcX = clip[0] / w
        val ndcY = clip[1] / w
        if (!ndcX.isFinite() || !ndcY.isFinite()) return null
        return ProjectedPoint(
            PointF(
                (ndcX * 0.5f + 0.5f) * viewWidth,
                (0.5f - ndcY * 0.5f) * viewHeight
            ),
            clip[2] / w
        )
    }

    fun projectObjects(viewWidth: Int, viewHeight: Int): List<ProjectedRoofObject> {
        val mesh = pendingMesh
        if (mesh.objectAnchors.isEmpty()) return emptyList()
        val mvp = buildMvp(FloatArray(16), viewWidth, viewHeight)
        return mesh.objectAnchors.mapNotNull { anchor ->
            val projected = projectPoint(anchor.center, mvp, viewWidth, viewHeight) ?: return@mapNotNull null
            ProjectedRoofObject(anchor.objectId, anchor.type, projected.point, projected.depth)
        }
    }

    /** Converts a screen drag to the attached roof plane's local east/north displacement.
     * The two projected plane tangents form a 2x2 Jacobian, so the object stays on its face
     * instead of being moved in screen coordinates or detached from the roof. */
    fun objectDragDelta(
        objectId: String,
        dxPixels: Float,
        dyPixels: Float,
        viewWidth: Int,
        viewHeight: Int
    ): LocalPoint? {
        val anchor = pendingMesh.objectAnchors.firstOrNull { it.objectId == objectId } ?: return null
        val mvp = buildMvp(FloatArray(16), viewWidth, viewHeight)
        val center = projectPoint(anchor.center, mvp, viewWidth, viewHeight)?.point ?: return null
        val n = anchor.normalization.coerceAtLeast(0.000001f)
        val east = projectPoint(
            RoofVec3(anchor.center.x + n, anchor.center.y + anchor.planeA.toFloat() * n, anchor.center.z),
            mvp, viewWidth, viewHeight
        )?.point ?: return null
        val north = projectPoint(
            RoofVec3(anchor.center.x, anchor.center.y + anchor.planeB.toFloat() * n, anchor.center.z - n),
            mvp, viewWidth, viewHeight
        )?.point ?: return null
        val ex = east.x - center.x; val ey = east.y - center.y
        val nx = north.x - center.x; val ny = north.y - center.y
        val determinant = ex * ny - ey * nx
        if (!determinant.isFinite() || abs(determinant) < 0.0001f) return null
        val localDx = ((dxPixels * ny - dyPixels * nx) / determinant).coerceIn(-2.0f, 2.0f)
        val localDy = ((ex * dyPixels - ey * dxPixels) / determinant).coerceIn(-2.0f, 2.0f)
        return LocalPoint(localDx.toDouble(), localDy.toDouble())
    }

    fun projectDimensions(viewWidth: Int, viewHeight: Int): List<ProjectedRoofDimension> {
        val mesh = pendingMesh
        if (mesh.dimensions.isEmpty()) return emptyList()
        val model = FloatArray(16)
        val mvp = buildMvp(model, viewWidth, viewHeight)
        fun project(point: RoofVec3): ProjectedPoint? =
            projectPoint(point, mvp, viewWidth, viewHeight)
        val projectedTriangles = buildList {
            var offset = 0
            while (offset + 8 < mesh.triangles.size) {
                val a = project(RoofVec3(mesh.triangles[offset], mesh.triangles[offset + 1], mesh.triangles[offset + 2]))
                val b = project(RoofVec3(mesh.triangles[offset + 3], mesh.triangles[offset + 4], mesh.triangles[offset + 5]))
                val c = project(RoofVec3(mesh.triangles[offset + 6], mesh.triangles[offset + 7], mesh.triangles[offset + 8]))
                if (a != null && b != null && c != null) add(Triple(a, b, c))
                offset += 9
            }
        }
        fun triangleDepthAt(sample: PointF, triangle: Triple<ProjectedPoint, ProjectedPoint, ProjectedPoint>): Float? {
            val a = triangle.first; val b = triangle.second; val c = triangle.third
            val denominator = (b.point.y - c.point.y) * (a.point.x - c.point.x) +
                (c.point.x - b.point.x) * (a.point.y - c.point.y)
            if (abs(denominator) < 1e-5f) return null
            val wa = ((b.point.y - c.point.y) * (sample.x - c.point.x) +
                (c.point.x - b.point.x) * (sample.y - c.point.y)) / denominator
            val wb = ((c.point.y - a.point.y) * (sample.x - c.point.x) +
                (a.point.x - c.point.x) * (sample.y - c.point.y)) / denominator
            val wc = 1f - wa - wb
            if (wa < -0.002f || wb < -0.002f || wc < -0.002f) return null
            return wa * a.depth + wb * b.depth + wc * c.depth
        }
        fun isOccluded(sample: ProjectedPoint): Boolean = projectedTriangles.any { triangle ->
            val surfaceDepth = triangleDepthAt(sample.point, triangle) ?: return@any false
            surfaceDepth < sample.depth - 0.003f
        }
        fun coversSurface(point: PointF): Boolean = projectedTriangles.any { triangleDepthAt(point, it) != null }
        val modelCenter = project(RoofVec3(0f, 0f, 0f))?.point ?: PointF(viewWidth / 2f, viewHeight / 2f)
        val visible = RoofDimensionPlacement.stablePlanCandidates(mesh.dimensions).mapNotNull { dimension ->
            val witnessStart = project(dimension.witnessStart) ?: return@mapNotNull null
            val witnessEnd = project(dimension.witnessEnd) ?: return@mapNotNull null
            val visibilityStart = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) dimension.start else dimension.witnessStart
            val visibilityEnd = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) dimension.end else dimension.witnessEnd
            val middle = project(RoofVec3(
                (visibilityStart.x + visibilityEnd.x) / 2f,
                (visibilityStart.y + visibilityEnd.y) / 2f,
                (visibilityStart.z + visibilityEnd.z) / 2f
            )) ?: return@mapNotNull null
            val alwaysDimensioned = dimension.kind in setOf(
                RoofDimensionKind.ATTIC_HEIGHT,
                RoofDimensionKind.CHIMNEY_WIDTH,
                RoofDimensionKind.CHIMNEY_LENGTH,
                RoofDimensionKind.CHIMNEY_HEIGHT,
                RoofDimensionKind.ROOF_WINDOW_WIDTH,
                RoofDimensionKind.ROOF_WINDOW_LENGTH,
                RoofDimensionKind.HATCH_WIDTH,
                RoofDimensionKind.HATCH_LENGTH,
                RoofDimensionKind.VENT_DIAMETER
            )
            if (!alwaysDimensioned && isOccluded(middle)) return@mapNotNull null
            val dx = witnessEnd.point.x - witnessStart.point.x
            val dy = witnessEnd.point.y - witnessStart.point.y
            val screenLength = hypot(dx, dy).coerceAtLeast(1f)
            val baseNx = -dy / screenLength
            val baseNy = dx / screenLength
            val midX = (witnessStart.point.x + witnessEnd.point.x) / 2f
            val midY = (witnessStart.point.y + witnessEnd.point.y) / 2f
            fun surfaceScore(sign: Float): Int {
                var score = 0
                val samples = floatArrayOf(18f, 34f, 56f, 82f)
                val along = floatArrayOf(0.18f, 0.5f, 0.82f)
                samples.forEach { offset -> along.forEach { t ->
                    val px = witnessStart.point.x + dx * t + baseNx * sign * offset
                    val py = witnessStart.point.y + dy * t + baseNy * sign * offset
                    if (coversSurface(PointF(px, py))) score++
                } }
                return score
            }
            val positiveScore = surfaceScore(1f)
            val negativeScore = surfaceScore(-1f)
            val sign = when {
                positiveScore < negativeScore -> 1f
                negativeScore < positiveScore -> -1f
                baseNx * (midX - modelCenter.x) + baseNy * (midY - modelCenter.y) >= 0f -> 1f
                else -> -1f
            }
            ProjectedRoofDimension(
                dimensionId = dimension.dimensionId,
                edgeId = dimension.edgeId,
                linkedEdgeIds = dimension.linkedEdgeIds,
                kind = dimension.kind,
                start = project(dimension.start)?.point ?: return@mapNotNull null,
                end = project(dimension.end)?.point ?: return@mapNotNull null,
                witnessStart = witnessStart.point,
                witnessEnd = witnessEnd.point,
                lengthM = dimension.lengthM,
                modelCenter = modelCenter,
                outwardNormal = PointF(baseNx * sign, baseNy * sign),
                drawWitnessLines = minOf(positiveScore, negativeScore) == 0
            )
        }
        // Height and slope supply candidates on multiple faces. Keep the clearest visible one,
        // rather than drawing duplicate technical dimensions over one another.
        return visible.groupBy { it.dimensionId }.values.map { candidates ->
            candidates.maxBy { dimension ->
                hypot(
                    dimension.witnessEnd.x - dimension.witnessStart.x,
                    dimension.witnessEnd.y - dimension.witnessStart.y
                )
            }
        }
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.962f, 0.968f, 0.970f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)
        surfaceProgram = createProgram(SURFACE_VERTEX, SURFACE_FRAGMENT)
        edgeProgram = createProgram(EDGE_VERTEX, EDGE_FRAGMENT)
        logoProgram = createProgram(LOGO_VERTEX, LOGO_FRAGMENT)
        logoTexture = createLogoTexture()
        val buffers = IntArray(3)
        GLES30.glGenBuffers(3, buffers, 0)
        triangleVbo = buffers[0]
        edgeVbo = buffers[1]
        logoVbo = buffers[2]
        uploaded = null
    }

    override fun onSurfaceChanged(gl: GL10?, widthValue: Int, heightValue: Int) {
        width = max(1, widthValue)
        height = max(1, heightValue)
        GLES30.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (triangleCount == 0) return
        val model = FloatArray(16)
        val mvp = buildMvp(model, width, height)
        drawSurfaces(model, mvp)
        drawEdges(mvp)
        drawLogos(mvp)
    }

    private fun buildMvp(model: FloatArray, viewWidth: Int, viewHeight: Int): FloatArray {
        val view = FloatArray(16)
        val projection = FloatArray(16)
        val viewProjection = FloatArray(16)
        val mvp = FloatArray(16)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        Matrix.scaleM(model, 0, zoom, zoom, zoom)
        Matrix.translateM(model, 0, panX, panY, 0f)
        Matrix.setLookAtM(view, 0, 0f, 0.35f, 5.2f, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.perspectiveM(projection, 0, 34f, viewWidth.toFloat() / viewHeight.coerceAtLeast(1), 0.1f, 20f)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)
        return mvp
    }

    private fun uploadIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploaded) return
        val vertexCount = mesh.triangles.size / 3
        val interleaved = FloatArray(vertexCount * 7)
        var source = 0
        var target = 0
        while (source < mesh.triangles.size) {
            val vertexIndex = source / 3
            interleaved[target++] = mesh.triangles[source]
            interleaved[target++] = mesh.triangles[source + 1]
            interleaved[target++] = mesh.triangles[source + 2]
            interleaved[target++] = mesh.normals[source]
            interleaved[target++] = mesh.normals[source + 1]
            interleaved[target++] = mesh.normals[source + 2]
            interleaved[target++] = mesh.materials.getOrElse(vertexIndex) { 1f }
            source += 3
        }
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, interleaved.size * 4, interleaved.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        triangleCount = mesh.triangles.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val allEdges = mesh.edges + mesh.internalEdges + mesh.wallEdges + mesh.padEdges
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, allEdges.size * 4, allEdges.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        edgeCount = mesh.edges.size / 3
        internalEdgeCount = mesh.internalEdges.size / 3
        wallEdgeCount = mesh.wallEdges.size / 3
        padEdgeCount = mesh.padEdges.size / 3
        val logoVertices = arrayListOf<Float>()
        fun logoVertex(point: RoofVec3, u: Float, v: Float) {
            logoVertices += point.x; logoVertices += point.y; logoVertices += point.z
            logoVertices += u; logoVertices += v
        }
        mesh.logoQuads.forEach { quad ->
            val leftU = StrechoStavLogo.roofSurfaceU(left = true)
            val rightU = StrechoStavLogo.roofSurfaceU(left = false)
            // X=east, Z=-north reflects the old horizontal basis. Reverse only triangle
            // winding so gl_FrontFacing denotes the exterior roof side; keep UVs unchanged
            // so the lettering remains readable rather than mirrored.
            logoVertex(quad.topLeft, leftU, 0f)
            logoVertex(quad.bottomRight, rightU, 1f)
            logoVertex(quad.topRight, rightU, 0f)
            logoVertex(quad.topLeft, leftU, 0f)
            logoVertex(quad.bottomLeft, leftU, 1f)
            logoVertex(quad.bottomRight, rightU, 1f)
        }
        val logoArray = logoVertices.toFloatArray()
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, logoVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, logoArray.size * 4, logoArray.nativeBuffer(), GLES30.GL_STATIC_DRAW)
        logoCount = logoArray.size / 5
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        uploaded = mesh
    }

    private fun drawSurfaces(model: FloatArray, mvp: FloatArray) {
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uModel"), 1, false, model, 0)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(surfaceProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uColor"), 0.145f, 0.166f, 0.178f)
        GLES30.glUniform3f(GLES30.glGetUniformLocation(surfaceProgram, "uLight"), -0.42f, 0.72f, 0.86f)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        val material = GLES30.glGetAttribLocation(surfaceProgram, "aMaterial")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(normal)
        GLES30.glEnableVertexAttribArray(material)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 28, 0)
        GLES30.glVertexAttribPointer(normal, 3, GLES30.GL_FLOAT, false, 28, 12)
        GLES30.glVertexAttribPointer(material, 1, GLES30.GL_FLOAT, false, 28, 24)
        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, triangleCount)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(normal)
        GLES30.glDisableVertexAttribArray(material)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeCount == 0 && internalEdgeCount == 0 && wallEdgeCount == 0 && padEdgeCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(edgeProgram, "uMvp"), 1, false, mvp, 0)
        val colorLocation = GLES30.glGetUniformLocation(edgeProgram, "uColor")
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 12, 0)
        GLES30.glLineWidth(1.35f)
        GLES30.glDepthMask(false)
        // Strict depth comparison keeps triangulation/roof edges behind opaque wall fragments hidden.
        GLES30.glDepthFunc(GLES30.GL_LESS)
        if (edgeCount > 0) {
            GLES30.glUniform4f(colorLocation, 0.055f, 0.065f, 0.070f, 0.94f)
            GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeCount)
        }
        if (internalEdgeCount > 0) {
            GLES30.glUniform4f(colorLocation, 0.55f, 0.58f, 0.59f, 0.86f)
            GLES30.glLineWidth(1.0f)
            GLES30.glDrawArrays(GLES30.GL_LINES, edgeCount, internalEdgeCount)
        }
        if (wallEdgeCount > 0) {
            GLES30.glUniform4f(colorLocation, 0.70f, 0.72f, 0.73f, 0.54f)
            GLES30.glLineWidth(1.0f)
            GLES30.glDrawArrays(GLES30.GL_LINES, edgeCount + internalEdgeCount, wallEdgeCount)
        }
        if (padEdgeCount > 0) {
            GLES30.glUniform4f(colorLocation, 0.32f, 0.36f, 0.38f, 0.58f)
            GLES30.glLineWidth(1.0f)
            GLES30.glDrawArrays(GLES30.GL_LINES, edgeCount + internalEdgeCount + wallEdgeCount, padEdgeCount)
        }
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
    }

    private fun drawLogos(mvp: FloatArray) {
        if (logoCount == 0) return
        GLES30.glUseProgram(logoProgram)
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(logoProgram, "uMvp"), 1, false, mvp, 0)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, logoTexture)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(logoProgram, "uLogo"), 0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, logoVbo)
        val position = GLES30.glGetAttribLocation(logoProgram, "aPosition")
        val uv = GLES30.glGetAttribLocation(logoProgram, "aUv")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(uv)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 20, 0)
        GLES30.glVertexAttribPointer(uv, 2, GLES30.GL_FLOAT, false, 20, 12)
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, logoCount)
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(uv)
    }

    private fun createLogoTexture(): Int {
        val textures = IntArray(1)
        GLES30.glGenTextures(1, textures, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textures[0])
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val bitmap = StrechoStavLogo.bitmap()
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
        bitmap.recycle()
        return textures[0]
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        val vs = compile(GLES30.GL_VERTEX_SHADER, vertex)
        val fs = compile(GLES30.GL_FRAGMENT_SHADER, fragment)
        val program = GLES30.glCreateProgram()
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL program: ${GLES30.glGetProgramInfoLog(program)}" }
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)
        return program
    }

    private fun compile(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        require(status[0] != 0) { "OpenGL shader: ${GLES30.glGetShaderInfoLog(shader)}" }
        return shader
    }

    private fun FloatArray.nativeBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(this@nativeBuffer)
            position(0)
        }

    companion object {
        private const val SURFACE_VERTEX = """
            #version 300 es
            uniform mat4 uModel;
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec3 aNormal;
            in float aMaterial;
            out vec3 vNormal;
            out vec3 vPosition;
            out float vRoofMix;
            void main() {
                vNormal = mat3(uModel) * aNormal;
                // Material grain is anchored to the model and must not shimmer
                // or change when the user rotates the camera.
                vPosition = aPosition;
                vRoofMix = aMaterial;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val SURFACE_FRAGMENT = """
            #version 300 es
            precision highp float;
            uniform vec3 uColor;
            uniform vec3 uLight;
            in vec3 vNormal;
            in vec3 vPosition;
            in float vRoofMix;
            out vec4 outColor;
            float hash31(vec3 p) {
                return fract(sin(dot(p, vec3(127.1, 311.7, 74.7))) * 43758.5453);
            }
            void main() {
                vec3 normal = normalize(vNormal);
                if (!gl_FrontFacing) normal = -normal;
                vec3 keyLight = normalize(uLight);
                vec3 fillLight = normalize(vec3(0.55, -0.25, 0.48));
                float diffuse = max(dot(normal, keyLight), 0.0);
                float fill = max(dot(normal, fillLight), 0.0);
                float material = vRoofMix;
                float roofMix = step(0.5, material) * (1.0 - step(1.5, material));
                float padMix = step(1.5, material);
                float mineral = hash31(floor(vPosition * 72.0));
                float fine = hash31(floor(vPosition * 215.0) + vec3(7.0, 3.0, 11.0));
                float materialVariation = 1.000 + (mineral - 0.5) * 0.040 + (fine - 0.5) * 0.020;
                vec3 roofColor = uColor * materialVariation;
                vec3 wallColor = vec3(0.875, 0.886, 0.892);
                vec3 padColor = vec3(0.973, 0.977, 0.977);
                // Material plus camera lighting stays within an approximately 20% anthracite range.
                float roofShade = clamp(0.960 + diffuse * 0.070 + fill * 0.010, 0.960, 1.040);
                float wallShade = clamp(0.82 + diffuse * 0.16 + fill * 0.04, 0.80, 1.0);
                float padShade = clamp(0.90 + diffuse * 0.08 + fill * 0.02, 0.88, 1.0);
                vec3 baseColor = mix(mix(wallColor, roofColor, roofMix), padColor, padMix);
                float shade = mix(mix(wallShade, roofShade, roofMix), padShade, padMix);
                vec3 color = baseColor * shade;
                outColor = vec4(color, 1.0);
            }
        """
        private const val EDGE_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            void main() { gl_Position = uMvp * vec4(aPosition, 1.0); }
        """
        private const val EDGE_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform vec4 uColor;
            out vec4 outColor;
            void main() { outColor = uColor; }
        """
        private const val LOGO_VERTEX = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec2 aUv;
            out vec2 vUv;
            void main() {
                vUv = aUv;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """
        private const val LOGO_FRAGMENT = """
            #version 300 es
            precision mediump float;
            uniform sampler2D uLogo;
            in vec2 vUv;
            out vec4 outColor;
            void main() {
                // A roof logo has only a printable outer side. Rendering its back face would
                // show the lettering mirrored, like looking through transparent foil.
                if (!gl_FrontFacing) discard;
                vec4 logo = texture(uLogo, vUv);
                if (logo.a < 0.04) discard;
                outColor = logo;
            }
        """
    }
}
