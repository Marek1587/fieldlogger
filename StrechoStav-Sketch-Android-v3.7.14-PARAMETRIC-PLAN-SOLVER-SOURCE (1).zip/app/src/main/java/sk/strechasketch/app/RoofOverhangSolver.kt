package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Semantic overhang solver. An overhang is a roof construction only at EAVE edges;
 * ATTIC, GABLE and every other boundary role remain on the wall line.
 *
 * The generated shell follows the STN reference model: a vertical fascia, a 200 mm
 * horizontal soffit next to the eave and a sloping underside continuing to the wall.
 */
internal object RoofOverhangSolver {
    const val DEFAULT_FLAT_SOFFIT_DEPTH_M = 0.20
    const val DEFAULT_ROOF_SHELL_THICKNESS_M = 0.18

    internal data class Section(
        val edgeId: String,
        val outerTopA: GraphNode,
        val outerTopB: GraphNode,
        val outerBottomA: GraphNode,
        val outerBottomB: GraphNode,
        val flatInnerA: GraphNode,
        val flatInnerB: GraphNode,
        val wallInnerA: GraphNode,
        val wallInnerB: GraphNode,
        val overhangM: Double,
        val flatDepthM: Double
    )

    internal data class Solution(
        val eligibleEdgeIds: List<String>,
        val representativeOverhangM: Double,
        val sections: List<Section>
    )

    /**
     * Builds the physical wall footprint from the roof boundary. Only EAVE support
     * lines move inward. Intersections of adjacent support lines preserve L/T/H corners
     * and make one wheel value a shared overhang parameter for every eave.
     */
    fun selectiveWallFootprint(graph: RoofGraph, overhangM: Double): List<LocalPoint>? {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology()) ?: return null
        val points = ordered.first.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        val edges = ordered.second.mapNotNull { graph.edges[it.id] }
        if (points.size < 3 || edges.size != points.size || overhangM < 0.0) return null
        if (overhangM <= 1e-9) return points

        val eaveLengths = edges.mapIndexedNotNull { index, edge ->
            if (edge.semanticRole != EdgeSemantic.EAVE) null else {
                val a = points[index]
                val b = points[(index + 1) % points.size]
                hypot(b.x - a.x, b.y - a.y)
            }
        }
        if (eaveLengths.isEmpty() || overhangM >= eaveLengths.min() * 0.45) return null

        val twiceArea = points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        }
        val orientation = if (twiceArea >= 0.0) 1.0 else -1.0
        data class SupportLine(val point: LocalPoint, val dx: Double, val dy: Double)
        val lines = points.indices.map { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            val distance = if (edges[index].semanticRole == EdgeSemantic.EAVE) overhangM else 0.0
            val nx = -dy / length * orientation
            val ny = dx / length * orientation
            SupportLine(LocalPoint(a.x + nx * distance, a.y + ny * distance), dx, dy)
        }
        fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx
        val result = lines.indices.map { index ->
            val previous = lines[(index - 1 + lines.size) % lines.size]
            val current = lines[index]
            val denominator = cross(previous.dx, previous.dy, current.dx, current.dy)
            if (abs(denominator) < 1e-9) return null
            val qx = current.point.x - previous.point.x
            val qy = current.point.y - previous.point.y
            val t = cross(qx, qy, current.dx, current.dy) / denominator
            LocalPoint(previous.point.x + previous.dx * t, previous.point.y + previous.dy * t)
        }
        if (result.any { !it.x.isFinite() || !it.y.isFinite() }) return null
        val resultArea = abs(result.indices.sumOf { index ->
            val a = result[index]
            val b = result[(index + 1) % result.size]
            a.x * b.y - b.x * a.y
        }) / 2.0
        if (resultArea <= 1e-5 || result.any { point ->
                !Geometry.pointInPolygon(point, points) && points.indices.none { index ->
                    Geometry.distanceToSegment(point, points[index], points[(index + 1) % points.size]) <= 1e-5
                }
            }
        ) return null
        return result
    }

    fun solve(
        graph: RoofGraph,
        wallLoop: List<LocalPoint>,
        roofThicknessM: Double = DEFAULT_ROOF_SHELL_THICKNESS_M,
        flatSoffitDepthM: Double = DEFAULT_FLAT_SOFFIT_DEPTH_M
    ): Solution {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology())
            ?: return Solution(emptyList(), 0.0, emptyList())
        val eaves = ordered.second.mapNotNull { graph.edges[it.id] }
            .filter { it.semanticRole == EdgeSemantic.EAVE }
        if (wallLoop.size < 3 || eaves.isEmpty()) {
            return Solution(eaves.map { it.id }, 0.0, emptyList())
        }

        data class Candidate(
            val edge: GraphEdge,
            val a: GraphNode,
            val b: GraphNode,
            val plane: RoofPlane,
            val inwardX: Double,
            val inwardY: Double,
            val measuredDepth: Double
        )

        fun raySegmentDepth(origin: LocalPoint, dx: Double, dy: Double): Double? {
            fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx
            var best = Double.POSITIVE_INFINITY
            wallLoop.indices.forEach { index ->
                val a = wallLoop[index]
                val b = wallLoop[(index + 1) % wallLoop.size]
                val sx = b.x - a.x
                val sy = b.y - a.y
                val denominator = cross(dx, dy, sx, sy)
                if (abs(denominator) <= 1e-10) return@forEach
                val qx = a.x - origin.x
                val qy = a.y - origin.y
                val t = cross(qx, qy, sx, sy) / denominator
                val u = cross(qx, qy, dx, dy) / denominator
                if (t >= -1e-7 && u in -1e-7..1.0000001 && t < best) best = t
            }
            return best.takeIf { it.isFinite() }?.coerceAtLeast(0.0)
        }

        val candidates = eaves.mapNotNull { edge ->
            val a = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
            val face = edge.adjacentFaceIds.asSequence().mapNotNull(graph.faces::get)
                .firstOrNull { it.plane != null } ?: return@mapNotNull null
            val plane = face.plane ?: return@mapNotNull null
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= 1e-8) return@mapNotNull null
            val mid = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
            val faceNodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            val faceCenterX = faceNodes.map { it.x }.average()
            val faceCenterY = faceNodes.map { it.y }.average()
            var nx = -(b.y - a.y) / length
            var ny = (b.x - a.x) / length
            if ((faceCenterX - mid.x) * nx + (faceCenterY - mid.y) * ny < 0.0) {
                nx = -nx
                ny = -ny
            }
            val depth = raySegmentDepth(mid, nx, ny) ?: 0.0
            Candidate(edge, a, b, plane, nx, ny, depth)
        }
        val positiveDepths = candidates.map { it.measuredDepth }.filter { it > 0.001 }.sorted()
        val representative = when {
            positiveDepths.isEmpty() -> 0.0
            positiveDepths.size % 2 == 1 -> positiveDepths[positiveDepths.size / 2]
            else -> (positiveDepths[positiveDepths.size / 2 - 1] + positiveDepths[positiveDepths.size / 2]) / 2.0
        }
        if (representative <= 0.001) {
            return Solution(eaves.map { it.id }, 0.0, emptyList())
        }

        val shellThickness = roofThicknessM.coerceIn(0.05, 0.60)
        val flatDepth = minOf(flatSoffitDepthM.coerceAtLeast(0.0), representative)
        // Once a valid shared value exists, every semantic eave receives the same shell.
        // This also covers concave L corners where a midpoint ray can touch a neighbouring
        // support line at t=0 even though the eave's own shifted support is valid.
        val sections = candidates.map { candidate ->
            fun node(id: String, x: Double, y: Double, z: Double) = GraphNode(id, x, y, z)
            val innerAx = candidate.a.x + candidate.inwardX * representative
            val innerAy = candidate.a.y + candidate.inwardY * representative
            val innerBx = candidate.b.x + candidate.inwardX * representative
            val innerBy = candidate.b.y + candidate.inwardY * representative
            val flatAx = candidate.a.x + candidate.inwardX * flatDepth
            val flatAy = candidate.a.y + candidate.inwardY * flatDepth
            val flatBx = candidate.b.x + candidate.inwardX * flatDepth
            val flatBy = candidate.b.y + candidate.inwardY * flatDepth
            val bottomAz = candidate.a.z - shellThickness
            val bottomBz = candidate.b.z - shellThickness
            Section(
                edgeId = candidate.edge.id,
                outerTopA = candidate.a,
                outerTopB = candidate.b,
                outerBottomA = node("${candidate.edge.id}-fascia-a", candidate.a.x, candidate.a.y, bottomAz),
                outerBottomB = node("${candidate.edge.id}-fascia-b", candidate.b.x, candidate.b.y, bottomBz),
                flatInnerA = node("${candidate.edge.id}-soffit-a", flatAx, flatAy, bottomAz),
                flatInnerB = node("${candidate.edge.id}-soffit-b", flatBx, flatBy, bottomBz),
                wallInnerA = node(
                    "${candidate.edge.id}-wall-a", innerAx, innerAy,
                    if (representative - flatDepth <= 1e-6) bottomAz
                    else candidate.plane.zAt(innerAx, innerAy) - shellThickness
                ),
                wallInnerB = node(
                    "${candidate.edge.id}-wall-b", innerBx, innerBy,
                    if (representative - flatDepth <= 1e-6) bottomBz
                    else candidate.plane.zAt(innerBx, innerBy) - shellThickness
                ),
                overhangM = representative,
                flatDepthM = flatDepth
            )
        }
        return Solution(eaves.map { it.id }, representative, sections)
    }
}
