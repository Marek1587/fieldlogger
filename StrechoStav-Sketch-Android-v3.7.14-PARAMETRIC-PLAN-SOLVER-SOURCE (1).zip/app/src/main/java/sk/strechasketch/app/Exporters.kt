package sk.strechasketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private data class PlanProjection(
    val localPolygon: List<LocalPoint>,
    val minX: Double,
    val maxX: Double,
    val minY: Double,
    val maxY: Double,
    val origin: GeoPoint,
    val angle: Double
) {
    fun local(point: GeoPoint): LocalPoint {
        val raw = Geometry.toLocal(point, origin)
        val c = cos(-angle)
        val s = sin(-angle)
        return LocalPoint(raw.x * c - raw.y * s, raw.x * s + raw.y * c)
    }
}

object Exporters {
    fun json(project: RoofProject): ByteArray =
        ProjectJson.encode(project).toByteArray(Charsets.UTF_8)

    fun svg(project: RoofProject): ByteArray {
        if (project.polygon.size < 3) {
            return """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 800"><rect width="100%" height="100%" fill="white"/><text x="50" y="70" font-family="Arial" font-size="28">Nákres nemá uzavretý obrys.</text></svg>"""
                .toByteArray(Charsets.UTF_8)
        }
        val plan = projection(project)
        val pageW = 1600.0
        val pageH = 1000.0
        val drawX = 70.0
        val drawY = 120.0
        val drawW = 950.0
        val drawH = 740.0
        val scale = min(drawW / max(1.0, plan.maxX - plan.minX), drawH / max(1.0, plan.maxY - plan.minY))
        fun screen(point: LocalPoint): LocalPoint = LocalPoint(
            drawX + (point.x - plan.minX) * scale,
            drawY + (plan.maxY - point.y) * scale
        )
        fun line(a: LocalPoint, b: LocalPoint, color: String = "#111", width: Double = 2.0, dash: String = "") =
            """<line x1="${n(a.x)}" y1="${n(a.y)}" x2="${n(b.x)}" y2="${n(b.y)}" stroke="$color" stroke-width="$width"${if (dash.isNotBlank()) " stroke-dasharray=\"$dash\"" else ""}/>"""
        fun text(x: Double, y: Double, value: String, size: Int = 16, anchor: String = "start", weight: String = "400") =
            """<text x="${n(x)}" y="${n(y)}" font-family="Arial,sans-serif" font-size="$size" text-anchor="$anchor" font-weight="$weight" fill="#111">${xml(value)}</text>"""
        val out = StringBuilder()
        out.append("""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000">""")
        out.append("""<rect width="1600" height="1000" fill="white"/><rect x="10" y="10" width="1580" height="980" fill="none" stroke="#111"/>""")
        out.append(text(35.0, 48.0, "NÁKRES STRECHY", 25, weight = "700"))
        out.append(text(35.0, 76.0, "Projekt: ${project.name}", 15))
        out.append(text(35.0, 99.0, "Adresa: ${project.address.ifBlank { "—" }}", 14))
        val polygon = plan.localPolygon.map(::screen)
        val path = polygon.mapIndexed { index, p -> "${if (index == 0) "M" else "L"} ${n(p.x)} ${n(p.y)}" }.joinToString(" ") + " Z"
        out.append("""<path d="$path" fill="#fafafa" stroke="#111" stroke-width="4"/>""")
        if (project.wallFootprint.size >= 3) {
            val wallPath = project.wallFootprint.map { screen(plan.local(it)) }
                .mapIndexed { index, p -> "${if (index == 0) "M" else "L"} ${n(p.x)} ${n(p.y)}" }
                .joinToString(" ") + " Z"
            out.append("""<path d="$wallPath" fill="none" stroke="#555" stroke-width="1.2" stroke-dasharray="12 5 2 5"/>""")
        }
        project.polygon.indices.forEach { index ->
            val next = (index + 1) % project.polygon.size
            val a = polygon[index]
            val b = polygon[next]
            val length = Geometry.distanceM(project.polygon[index], project.polygon[next])
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 - 8, "${(length * 1000).toInt()} mm", 12, "middle"))
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 + 9, (project.edgeTypes[index] ?: LineType.EAVE).label, 10, "middle"))
        }
        project.lines.forEach { roofLine ->
            val a = screen(plan.local(roofLine.start))
            val b = screen(plan.local(roofLine.end))
            val dash = if (roofLine.type == LineType.WALL_END || roofLine.type == LineType.OPENING_BOUNDARY) "10 7" else ""
            val width = when (roofLine.type) {
                LineType.RIDGE, LineType.HIP, LineType.PULT -> 2.4
                LineType.VALLEY -> 2.0
                else -> 1.6
            }
            out.append(line(a, b, "#111", width, dash))
            out.append(text((a.x + b.x) / 2, (a.y + b.y) / 2 - 7, roofLine.type.label, 12, "middle", "700"))
        }
        project.objects.forEach { item ->
            val p = screen(plan.local(item.center))
            when (item.type) {
                ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH -> {
                    val w = max(12.0, item.widthMm / 1000.0 * scale)
                    val h = max(12.0, item.heightMm / 1000.0 * scale)
                    out.append("""<rect x="${n(p.x - w / 2)}" y="${n(p.y - h / 2)}" width="${n(w)}" height="${n(h)}" fill="none" stroke="#111" stroke-width="1.5"/>""")
                }
                ObjectType.VENT, ObjectType.DRAIN, ObjectType.DOWNSPOUT -> {
                    val r = max(5.0, item.diameterMm / 2000.0 * scale)
                    out.append("""<circle cx="${n(p.x)}" cy="${n(p.y)}" r="${n(r)}" fill="none" stroke="#111" stroke-width="1.5"/>""")
                }
                ObjectType.HEIGHT_MARK -> out.append("""<path d="M ${n(p.x - 10)} ${n(p.y)} H ${n(p.x + 10)} M ${n(p.x)} ${n(p.y - 10)} V ${n(p.y + 10)}" stroke="#111"/>""")
                ObjectType.SLOPE_MARK -> out.append("""<path d="M ${n(p.x - 14)} ${n(p.y + 10)} L ${n(p.x + 14)} ${n(p.y - 10)}" stroke="#111"/>""")
            }
            out.append(text(p.x, p.y - 12, item.type.label, 10, "middle"))
        }
        val totals = ProjectSummary.calculate(project)
        val boxX = 1090.0
        out.append("""<rect x="$boxX" y="105" width="440" height="720" fill="#fafafa" stroke="#111"/>""")
        var yy = 140.0
        val rows = listOf(
            "VÝKAZ VÝMER" to "",
            "Pôdorysná plocha" to "${f(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${f(totals.roofAreaM2)} m²",
            "Obvod" to "${f(totals.perimeterM)} m",
            "Hrebeň" to "${f(totals.ridgeM)} m",
            "Úžľabie" to "${f(totals.valleyM)} m",
            "Nárožie" to "${f(totals.hipM)} m",
            "Atika" to "${f(totals.atticM)} m",
            "Odkvap" to "${f(totals.eaveM)} m",
            "Štít" to "${f(totals.gableM)} m",
            "Komíny / okná / výlezy" to "${totals.chimneys} / ${totals.roofWindows} / ${totals.hatches}",
            "Prestupy / vpuste / zvody" to "${totals.vents} / ${totals.drains} / ${totals.downspouts}",
            "3D model" to "FaceId + roviny",
            "Predvolený sklon" to "${f(project.slopeDeg)}°",
            "Výška stien" to "${f(project.wallHeightM)} m"
        )
        rows.forEachIndexed { index, row ->
            if (row.first.isBlank()) {
                yy += 12
            } else {
                val bold = index == 0
                out.append(text(boxX + 18, yy, row.first, if (bold) 15 else 13, weight = if (bold) "700" else "400"))
                if (row.second.isNotBlank()) out.append(text(boxX + 420, yy, row.second, if (bold) 15 else 13, "end", if (bold) "700" else "400"))
                yy += 31
            }
        }
        out.append(text(35.0, 953.0, "Mierka je automatická. Rozmery pred realizáciou overte na stavbe.", 13))
        out.append("</svg>")
        return out.toString().toByteArray(Charsets.UTF_8)
    }

    fun pdf(project: RoofProject): ByteArray {
        val document = PdfDocument()
        val audit = RoofQuantityEngine.calculate(project)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1f
        }

        fun begin(number: Int, title: String): PdfDocument.Page {
            // ISO A4 portrait at 72 PDF points per inch: 595 × 842 pt.
            val page = document.startPage(PdfDocument.PageInfo.Builder(595, 842, number).create())
            page.canvas.drawColor(Color.WHITE)
            page.canvas.drawRect(10f, 10f, 585f, 832f, border)
            drawText(page.canvas, title, 24f, 34f, 15f, true)
            drawText(page.canvas, "StrechoStav Sketch • ${project.name}", 571f, 34f, 8f, alignRight = true)
            return page
        }

        begin(1, "PROJEKT A 3D TECHNICKÉ POHĽADY").also { page ->
            val canvas = page.canvas
            val date = SimpleDateFormat("d. M. yyyy", Locale("sk", "SK")).format(Date())
            drawText(canvas, "Projekt: ${project.name}", 26f, 58f, 10f, true)
            drawText(canvas, "Zákazník: ${project.customer.ifBlank { "—" }}", 26f, 75f, 9f)
            drawText(canvas, "Adresa: ${project.address.ifBlank { "—" }}", 26f, 91f, 9f)
            drawText(canvas, "Dátum: $date", 400f, 58f, 9f)
            val views = listOf(
                Triple(RectF(24f, 112f, 287f, 390f), RoofBitmapCamera(-45.0, 29.0), "Pohľad z rohu A"),
                Triple(RectF(308f, 112f, 571f, 390f), RoofBitmapCamera(45.0, 29.0), "Pohľad z rohu B"),
                Triple(RectF(24f, 423f, 287f, 701f), RoofBitmapCamera(135.0, 29.0), "Pohľad z rohu C"),
                Triple(RectF(308f, 423f, 571f, 701f), RoofBitmapCamera(225.0, 29.0), "Pohľad z rohu D")
            )
            views.forEach { (bounds, camera, label) ->
                drawPdfRoofBitmap(canvas, project, bounds, camera)
                drawText(canvas, label, bounds.centerX(), bounds.bottom + 17f, 8.5f, true, centered = true)
            }
            if (audit.faces.any { it.underconstrained }) {
                drawText(canvas, "Upozornenie: niektoré plochy potrebujú doplniť sklon alebo výškovú kótu.", 26f, 810f, 8f, true)
            }
            document.finishPage(page)
        }

        begin(2, "PÔDORYS STRECHY – TECHNICKÝ VÝKRES").also { page ->
            val canvas = page.canvas
            if (project.polygon.size >= 3) drawPdfPlan(canvas, project, RectF(28f, 58f, 567f, 792f))
            else drawText(canvas, "Nákres nemá uzavretý obrys.", 80f, 250f, 13f, true)
            drawText(canvas, "Kóty sú v mm. Výkres je generovaný z aktuálneho RoofGraph, nie zo snímky obrazovky.", 24f, 817f, 8f)
            document.finishPage(page)
        }

        begin(3, "VÝKAZ VÝMER – AUDIT PODĽA ID").also { page ->
            val canvas = page.canvas
            var y = 62f
            val totals = audit.totals
            listOf(
                "Pôdorysná plocha" to "${f(totals.footprintAreaM2)} m²",
                "Celková skutočná 3D plocha" to "${f(totals.roofAreaM2)} m²",
                "Obvod v 3D" to "${f(totals.perimeterM)} m",
                "Odkvapy / hrebene / nárožia / úžľabia" to "${f(totals.eaveM)} / ${f(totals.ridgeM)} / ${f(totals.hipM)} / ${f(totals.valleyM)} m"
            ).forEach { (name, value) ->
                drawText(canvas, name, 30f, y, 9f, true)
                drawText(canvas, value, 565f, y, 9f, true, alignRight = true)
                y += 17f
            }
            y += 8f
            drawText(canvas, "FaceId", 30f, y, 8f, true)
            drawText(canvas, "Plocha 3D", 315f, y, 8f, true, alignRight = true)
            drawText(canvas, "Stav", 335f, y, 8f, true)
            y += 14f
            audit.faces.take(18).forEach { face ->
                drawText(canvas, face.faceId, 30f, y, 7f)
                drawText(canvas, "${f(face.area3DM2)} m²", 315f, y, 7f, alignRight = true)
                drawText(canvas, if (face.underconstrained) "doplniť constraint" else "určená", 335f, y, 7f)
                y += 13f
            }
            y += 8f
            drawText(canvas, "EdgeId", 30f, y, 8f, true)
            drawText(canvas, "Typ", 335f, y, 8f, true)
            drawText(canvas, "Dĺžka 3D", 565f, y, 8f, true, alignRight = true)
            y += 14f
            audit.edges.take(((812f - y) / 13f).toInt().coerceAtLeast(0)).forEach { edge ->
                drawText(canvas, edge.edgeId, 30f, y, 7f)
                drawText(canvas, edge.semanticRole.toLegacy().label, 335f, y, 7f)
                drawText(canvas, "${f(edge.length3DM)} m", 565f, y, 7f, alignRight = true)
                y += 13f
            }
            document.finishPage(page)
        }

        begin(4, "ROZSAH PRÁC A ROZPOČET").also { page ->
            val canvas = page.canvas
            var y = 64f
            drawText(canvas, "Položka", 28f, y, 8f, true)
            drawText(canvas, "MJ", 330f, y, 8f, true)
            drawText(canvas, "Množstvo", 405f, y, 8f, true, alignRight = true)
            drawText(canvas, "Jedn. cena", 485f, y, 8f, true, alignRight = true)
            drawText(canvas, "Cena", 565f, y, 8f, true, alignRight = true)
            y += 18f
            val selected = WorkScopeEngine.resolve(project).filter { project.selectedWorkItems[it.item.code]?.selected == true }
            selected.take(((770f - y) / 17f).toInt().coerceAtLeast(0)).forEach { item ->
                drawText(canvas, "${item.item.code} • ${item.item.label}", 28f, y, 7.5f)
                drawText(canvas, item.item.unit, 330f, y, 7.5f)
                drawText(canvas, f(item.quantity), 405f, y, 7.5f, alignRight = true)
                drawText(canvas, item.unitPrice?.let { "${f(it)} €" } ?: "—", 485f, y, 7.5f, alignRight = true)
                drawText(canvas, item.totalPrice?.let { "${f(it)} €" } ?: "—", 565f, y, 7.5f, alignRight = true)
                y += 17f
            }
            if (selected.isEmpty()) drawText(canvas, "Nie je vybraná žiadna položka rozsahu prác.", 28f, y, 9f)
            val total = selected.mapNotNull { it.totalPrice }.sum()
            drawText(canvas, "SÚČET ZADANÝCH CIEN", 365f, 790f, 9f, true)
            drawText(canvas, "${f(total)} €", 565f, 790f, 10f, true, alignRight = true)
            drawText(canvas, "Položky bez jednotkovej ceny nie sú do súčtu zahrnuté.", 28f, 816f, 7f)
            document.finishPage(page)
        }
        return ByteArrayOutputStream().use { output ->
            document.writeTo(output)
            document.close()
            output.toByteArray()
        }
    }

    private fun drawPdfRoofBitmap(
        canvas: Canvas,
        project: RoofProject,
        bounds: RectF,
        camera: RoofBitmapCamera
    ) {
        // Six samples per PDF point produce roughly 432 DPI source images. Each view is
        // rendered independently and recycled immediately, keeping peak memory bounded.
        val width = (bounds.width() * 6f).toInt().coerceIn(900, 3072)
        val height = (bounds.height() * 6f).toInt().coerceIn(900, 3072)
        val bitmap = RoofBitmapRenderer.render(
            project, width, height, camera, Color.WHITE, showDimensions = false
        )
        try {
            canvas.drawBitmap(
                bitmap, null, bounds,
                Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            )
        } finally {
            bitmap.recycle()
        }
    }

    private fun drawPdfPlan(canvas: Canvas, project: RoofProject, bounds: RectF) {
        StnRoofPlanRenderer.draw(
            canvas = canvas,
            project = project,
            bounds = bounds,
            options = StnRoofPlanRenderer.Options(
                drawFrame = true,
                drawTitleBlock = true,
                pixelsPerInch = 72f,
                backgroundColor = Color.WHITE
            )
        )
    }

    private fun drawPdfSummary(canvas: Canvas, project: RoofProject, bounds: RectF) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.BLACK
            strokeWidth = 1f
        }
        canvas.drawRect(bounds, paint)
        val totals = ProjectSummary.calculate(project)
        var y = bounds.top + 22
        val rows = listOf(
            "VÝKAZ VÝMER" to "",
            "Pôdorys" to "${f(totals.footprintAreaM2)} m²",
            "Plocha v sklone" to "${f(totals.roofAreaM2)} m²",
            "Obvod" to "${f(totals.perimeterM)} m",
            "Hrebeň" to "${f(totals.ridgeM)} m",
            "Úžľabie" to "${f(totals.valleyM)} m",
            "Nárožie" to "${f(totals.hipM)} m",
            "Atika" to "${f(totals.atticM)} m",
            "Odkvap" to "${f(totals.eaveM)} m",
            "Štít" to "${f(totals.gableM)} m",
            "Komíny / okná" to "${totals.chimneys} / ${totals.roofWindows}",
            "Prestupy / vpuste" to "${totals.vents} / ${totals.drains}",
            "Model / sklon" to "FaceId / ${f(project.slopeDeg)}°",
            "Výška stien" to "${f(project.wallHeightM)} m"
        )
        rows.forEachIndexed { index, (label, value) ->
            if (label.isBlank()) {
                y += 8
            } else {
                val bold = index == 0
                drawText(canvas, label, bounds.left + 10, y, if (bold) 10f else 8f, bold)
                if (value.isNotBlank()) {
                    drawText(canvas, value, bounds.right - 10, y, if (bold) 10f else 8f, bold, alignRight = true)
                }
                y += if (bold) 22 else 19
            }
        }
        drawText(canvas, "Výmera z mapy je orientačná.", bounds.left + 10, bounds.bottom - 24, 7f, true)
        drawText(canvas, "Rozmery overte meraním na stavbe.", bounds.left + 10, bounds.bottom - 12, 7f)
    }

    private fun projection(project: RoofProject): PlanProjection {
        val origin = Geometry.centroid(project.polygon)
        val raw = project.polygon.map { Geometry.toLocal(it, origin) }
        val longest = raw.indices.maxByOrNull { index ->
            val next = raw[(index + 1) % raw.size]
            hypot(next.x - raw[index].x, next.y - raw[index].y)
        } ?: 0
        val b = raw[(longest + 1) % raw.size]
        val angle = atan2(b.y - raw[longest].y, b.x - raw[longest].x)
        val c = cos(-angle)
        val s = sin(-angle)
        val rotated = raw.map { LocalPoint(it.x * c - it.y * s, it.x * s + it.y * c) }
        return PlanProjection(
            rotated,
            rotated.minOf { it.x },
            rotated.maxOf { it.x },
            rotated.minOf { it.y },
            rotated.maxOf { it.y },
            origin,
            angle
        )
    }

    private fun drawText(
        canvas: Canvas,
        value: String,
        x: Float,
        y: Float,
        size: Float,
        bold: Boolean = false,
        alignRight: Boolean = false,
        centered: Boolean = false
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(24, 31, 37)
            textSize = size
            typeface = if (bold) android.graphics.Typeface.DEFAULT_BOLD else android.graphics.Typeface.DEFAULT
            textAlign = when {
                centered -> Paint.Align.CENTER
                alignRight -> Paint.Align.RIGHT
                else -> Paint.Align.LEFT
            }
        }
        canvas.drawText(value, x, y, paint)
    }

    private fun xml(value: String) = value
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")

    private fun colorHex(color: Int) = String.format("#%06X", 0xFFFFFF and color)
    private fun n(value: Double) = String.format(Locale.US, "%.1f", value)
    private fun f(value: Double) = String.format(Locale("sk", "SK"), "%.1f", value)
}
