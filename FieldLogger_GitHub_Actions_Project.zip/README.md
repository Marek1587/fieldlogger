# FieldLogger Android

Minimal Android field logger.

## Features
- GPS event log to CSV
- manual notes
- camera capture
- compressed photo
- share CSV

## Build APK
GitHub Actions builds APK automatically.

Open Actions -> Build Android APK -> download artifact FieldLogger-debug-apk.
