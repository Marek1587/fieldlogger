package sk.strechostav.fieldlogger

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val reqPerm = 1001
    private val reqPhoto = 2001
    private lateinit var noteEdit: EditText
    private lateinit var statusText: TextView
    private var pendingPhotoNote = ""
    private var pendingPhotoFile: File? = null
    private var pendingPhotoUri: Uri? = null

    private val header = listOf("timestamp","event_type","lat","lon","accuracy_m","provider","title","note","photo_path")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestPermissionsIfNeeded()
        buildUi()
        refreshStatus()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(28, 28, 28, 28)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Field Logger"
        title.textSize = 28f
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "GPS + poznámky + fotodokumentácia do CSV"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Poznámka k záznamu..."
        noteEdit.minLines = 3
        noteEdit.gravity = Gravity.TOP
        root.addView(noteEdit, full())

        addButton(root, "Príchod na stavbu / miesto") { writeEvent("SITE_ARRIVAL", "Príchod na stavbu / miesto", takeNote()) }
        addButton(root, "Obhliadka / kontrola") { writeEvent("INSPECTION", "Obhliadka / kontrola", takeNote()) }
        addButton(root, "Meranie / zameranie") { writeEvent("MEASUREMENT", "Meranie / zameranie", takeNote()) }
        addButton(root, "Telefonát / komunikácia") { writeEvent("PHONE_CALL", "Telefonát / komunikácia", takeNote()) }
        addButton(root, "Odchod zo stavby / miesta") { writeEvent("SITE_DEPARTURE", "Odchod zo stavby / miesta", takeNote()) }
        addButton(root, "Vlastná poznámka") { writeEvent("MANUAL_NOTE", "Vlastná poznámka", takeNote()) }
        addButton(root, "Rýchly GPS zápis") { writeEvent("GPS_CHECK", "Rýchly GPS zápis", "") }
        addButton(root, "Odfotiť + zapísať fotku") {
            pendingPhotoNote = takeNote()
            openCamera()
        }
        addButton(root, "Zdieľať CSV") { shareCsv() }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, 18, 0, 0)
        root.addView(statusText, full())
        setContentView(scroll)
    }

    private fun addButton(root: LinearLayout, text: String, fn: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.textSize = 15f
        b.setOnClickListener { fn() }
        root.addView(b, full())
    }

    private fun full() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 8, 0, 8) }

    private fun takeNote(): String {
        val note = noteEdit.text.toString().trim()
        noteEdit.setText("")
        return note
    }

    private fun requestPermissionsIfNeeded() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CAMERA)
        if (android.os.Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), reqPerm)
    }

    private fun baseDir(): File {
        val d = File(getExternalFilesDir(null), "field_logger")
        d.mkdirs()
        return d
    }

    private fun photoDir(): File {
        val d = File(baseDir(), "photos")
        d.mkdirs()
        return d
    }

    private fun csvFile(): File {
        val f = File(baseDir(), "field_activity_log.csv")
        if (!f.exists()) f.writeText(header.joinToString(";") + "\\n", Charsets.UTF_8)
        return f
    }

    private fun now() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun bestLocation(): Location? {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            lm.getProviders(true).mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } }.maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun writeEvent(eventType: String, title: String, note: String, photoPath: String = "") {
        val loc = bestLocation()
        val row = listOf(
            now(), eventType,
            loc?.latitude?.toString() ?: "",
            loc?.longitude?.toString() ?: "",
            loc?.accuracy?.toString() ?: "",
            loc?.provider ?: "",
            title, note, photoPath
        ).joinToString(";") { csv(it) }
        csvFile().appendText(row + "\\n", Charsets.UTF_8)
        Toast.makeText(this, "Zapísané: $title", Toast.LENGTH_SHORT).show()
        refreshStatus()
    }

    private fun csv(v: String): String {
        val x = v.replace("\\n", " ").replace("\\r", " ").trim()
        return if (x.contains(";") || x.contains("\\"")) "\\"" + x.replace("\\"", "\\"\\"") + "\\"" else x
    }

    private fun refreshStatus() {
        val f = csvFile()
        statusText.text = "CSV: ${f.absolutePath}\\nVeľkosť: ${f.length()} B\\nFotky: ${photoDir().absolutePath}"
    }

    private fun openCamera() {
        val f = File(cacheDir, "camera_${stamp()}.jpg")
        pendingPhotoFile = f
        pendingPhotoUri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        i.putExtra(MediaStore.EXTRA_OUTPUT, pendingPhotoUri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        startActivityForResult(i, reqPhoto)
    }

    @Deprecated("Deprecated in Android framework")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPhoto) {
            val f = pendingPhotoFile
            if (resultCode == RESULT_OK && f != null && f.exists()) {
                val small = compressImage(f)
                writeEvent("PHOTO_NOTE", "Fotodokumentácia", pendingPhotoNote, small.absolutePath)
                pendingPhotoNote = ""
            } else {
                Toast.makeText(this, "Fotka nebola uložená.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun compressImage(src: File): File {
        val out = File(photoDir(), "photo_${stamp()}_compressed.jpg")
        val bmp = BitmapFactory.decodeFile(src.absolutePath) ?: return src
        val max = 1600
        val scale = minOf(1.0f, max.toFloat() / maxOf(bmp.width, bmp.height).toFloat())
        val resized = if (scale < 1.0f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        FileOutputStream(out).use { resized.compress(Bitmap.CompressFormat.JPEG, 82, it) }
        if (resized != bmp) resized.recycle()
        bmp.recycle()
        return out
    }

    private fun shareCsv() {
        val f = csvFile()
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/csv"
        i.putExtra(Intent.EXTRA_STREAM, uri)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Zdieľať CSV"))
    }
}
