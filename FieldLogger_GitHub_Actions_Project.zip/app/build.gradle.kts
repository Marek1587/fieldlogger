plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "sk.strechostav.fieldlogger"
    compileSdk = 35
    defaultConfig {
        applicationId = "sk.strechostav.fieldlogger"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
}
