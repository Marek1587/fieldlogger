package sk.strechostav.mobileactivity

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LocalLogStore {
    fun baseDir(context: Context): File {
        val d = File(context.getExternalFilesDir(null), "MobileActivityLogger")
        d.mkdirs()
        return d
    }

    fun logFile(context: Context): File {
        val f = File(baseDir(context), "mobile_activity_log.tsv")
        if (!f.exists()) {
            f.writeText(
                listOf(
                    "timestamp",
                    "source",
                    "event_type",
                    "app_name",
                    "package_name",
                    "start_time",
                    "end_time",
                    "duration_sec",
                    "lat",
                    "lon",
                    "accuracy_m",
                    "provider",
                    "title",
                    "note"
                ).joinToString("\t") + "\n",
                Charsets.UTF_8
            )
        }
        return f
    }

    fun pendingFile(context: Context): File = File(baseDir(context), "pending_events.ndjson")

    fun now(): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

    fun appendLocal(context: Context, event: Map<String, String>) {
        val row = listOf(
            event["timestamp"] ?: "",
            event["source"] ?: "",
            event["event_type"] ?: "",
            event["app_name"] ?: "",
            event["package_name"] ?: "",
            event["start_time"] ?: "",
            event["end_time"] ?: "",
            event["duration_sec"] ?: "",
            event["lat"] ?: "",
            event["lon"] ?: "",
            event["accuracy_m"] ?: "",
            event["provider"] ?: "",
            event["title"] ?: "",
            event["note"] ?: ""
        ).joinToString("\t") { clean(it) }
        logFile(context).appendText(row + "\n", Charsets.UTF_8)
    }

    fun queue(context: Context, json: String) {
        pendingFile(context).appendText(json + "\n", Charsets.UTF_8)
    }

    fun loadPending(context: Context): List<String> {
        val f = pendingFile(context)
        if (!f.exists()) return emptyList()
        return f.readLines(Charsets.UTF_8).filter { it.isNotBlank() }
    }

    fun replacePending(context: Context, lines: List<String>) {
        val f = pendingFile(context)
        if (lines.isEmpty()) {
            if (f.exists()) f.delete()
        } else {
            f.writeText(lines.joinToString("\n") + "\n", Charsets.UTF_8)
        }
    }

    private fun clean(v: String): String {
        return v.replace("\n", " ").replace("\r", " ").replace("\t", " ").trim()
    }
}
