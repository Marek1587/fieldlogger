# Mobile Activity Logger

Separate Android app for automatic background logging of foreground mobile apps.

## Features

- Logs foreground app segments to Google Sheets.
- Does not log:
  - sk.strechostav.mobileactivity
  - sk.strechostav.fieldmanual
  - sk.strechostav.fieldlogger
- Foreground service with notification.
- Starts automatically after phone reboot if enabled.
- Local queue when network or Google sync fails.

## Required phone settings

1. Open app once.
2. Paste Apps Script Web App URL.
3. Tap "Povoliť Usage Access" and allow Mobile Activity Logger.
4. Tap "Spustiť logger na pozadí".
5. Set battery mode to Unrestricted for this app.

## Apps Script

Use `docs/google_apps_script_unified.gs` as the single endpoint for manual logger and mobile activity logger.
