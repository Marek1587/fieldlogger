# KlampSketch 2.2.0 – Tapered profiles

## Nové funkcie

1. Editor má prepínač **Predný profil / Zadný profil**.
2. Zadný profil sa vytvorí z predného a môže mať samostatne upravené dĺžky a geometriu.
3. 3D renderer vytvára medzi oboma profilmi skutočné trojuholníkové plochy so Z-bufferom.
4. SQLite databáza bola migrovaná na verziu 2 a ukladá `back_points_json`.
5. PDF výrobného výkresu pri skosenom profile zobrazuje predný aj zadný profil.
6. Každý skosený profil dostane ďalší samostatný A4 landscape list s rozvinutým plášťom.
7. Rozvin používa trianguláciu jednotlivých pásov, zachováva skutočné hrany a uvádza všetky skosené dĺžky.
8. Mierka sa vyberá automaticky zo štandardných mierok a je doplnená 50 mm kontrolnou čiarou.

## Tlač

Rozvinutý plášť treba tlačiť na 100 % bez voľby „Prispôsobiť strane“. Kontrolná čiara musí mať na papieri 50 mm.
