# KlampSketch Offline 2.4.1

- Farby oboch strán boli vo všetkých 3D náhľadoch prehodené tak, aby súhlasili s červenou čiarou v 2D profile.
- Pri voľbe lakovanej vrchnej strany je vrchná plocha v 3D červená a rubová plocha bledosivá.
- Dlhý pomocný text nad prepínačmi predného a zadného profilu bol odstránený.
- Nad prepínače profilu bola presunutá rýchla lišta: Údaje, Otočiť lak, 3D náhľad, Fotoaparát a Galéria.
- Spodná lišta obsahuje už iba nástroje na tvorbu a úpravu geometrie.
