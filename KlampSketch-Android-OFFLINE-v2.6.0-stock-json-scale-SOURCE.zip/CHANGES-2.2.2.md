# KlampSketch 2.2.2 – červený 3D nákres a spotreba polotovaru

- 3D model v aplikácii aj v PDF používa pevnú technickú červenú RAL 3000,
- spotreba plechu sa počíta ako najväčšia rozvinutá šírka × výrobná dĺžka,
- pri rozdielnom prednom a zadnom rozvine PDF vykreslí celý polotovar a červený odrezok,
- rozvinová tabuľka uvádza rozmer polotovaru, spotrebu a odrezok na kus,
- hmotnosť profilu sa počíta z čistej plochy plášťa bez odrezku,
- zvýšený `versionCode` na 6 a `versionName` na `2.2.2-red-offcut`.
