# KlampSketch 2.3.1

- Solver dĺžkových kót úsekov používa zrkadlovo opačnú preferovanú stranu.
- Vodorovné kóty, ktoré boli pod úsekom, sa prednostne zobrazia nad úsekom.
- Zvislé kóty, ktoré boli napravo od úseku, sa prednostne zobrazia naľavo.
- Kolízne pásy, odsadenie, šípky a ochrana proti prekrývaniu zostali zachované.
- Uhlové kóty a kóty rozvinutého plášťa sa nemenia.
