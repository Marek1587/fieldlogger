# KlampSketch Android OFFLINE – zmeny 2.2.6

- Dlhé rozviny sa zobrazujú skrátene: prvých 150 mm + posledných 150 mm.
- Vynechaná stredná časť je označená dvojitou vlnitou prerušovacou čiarou.
- Výkres uvádza skutočnú vynechanú aj celkovú výrobnú dĺžku.
- Predná a zadná rezná hrana majú samostatné kóty P1/P2/... a Z1/Z2/....
- Celkový predný a zadný rozvin je kótovaný bez červeného odrezku.
- Červená plocha zostáva výrobným odrezkom a nevstupuje do rozmeru hotového plášťa.
