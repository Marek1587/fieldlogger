# KlampSketch Offline 2.4.0

- Každý výrobok má uloženú voľbu lakovanej pohľadovej strany.
- Tlačidlo **Otočiť lak** prepína lakovanú stranu profilu.
- V 2D profile je lakovaná strana označená tesnou červenou čiarou.
- V 3D modeli je lakovaná strana červená a rubová strana bledosivá.
- Rovnaké označenie sa používa v editore, PDF, JPG aj 3D náhľadoch v zozname.
- Zoznam výrobkov obsahuje 3D obrázok každého profilu.
- Vybrané výrobky možno uložiť ako jeden PDF report.
- Vybrané výrobky možno zdieľať do WhatsAppu ako jeden PDF alebo viac JPG obrázkov.
- PDF report možno odoslať cez e-mailovú aplikáciu.
- PDF sa pri každom exporte naďalej uloží do `Downloads/KlampSketch`.
- Existujúce záznamy sa pri migrácii nastavia na lakovanú vrchnú stranu.
