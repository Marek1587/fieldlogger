# KlampSketch Android OFFLINE – zmeny 2.2.4

## PDF rozvinutého plášťa
- nový **solver rozloženia**: rozvin sa automaticky otočí o 0° alebo 90° a zvolí mierku tak, aby čo najviac využil A4
- výraznejší, pre dielňu čitateľnejší výkres rozvinu
- jednotlivé panely sú farebne rozlíšené
- ohybové čiary sú označené oranžovo ako **O1, O2, ...**
- rezné čiary sú označené červeno ako **K0** a posledný rez
- na oboch stranách výkresu sa uvádza **využiteľná šírka pásu**
- červenou plochou je naďalej zobrazený **odrezok**
- pribudla legenda a tabuľka "Ako to v dielni ohýbať"
