# KlampSketch 2.2.1 – oprava zostavenia

- odstránené neplatné volanie `GLES30.glEnable(GLES30.GL_MULTISAMPLE)`,
- multisampling zostáva riadený konfiguráciou EGL povrchu; depth buffer a depth test zostávajú aktívne,
- zvýšený `versionCode` na 5 a `versionName` na `2.2.1-tapered`,
- aktualizovaný názov APK artefaktu v GitHub Actions.
