# KlampSketch Offline 2.5.0

- Pôvodný výrobný report zostáva zachovaný bez zmeny.
- Pribudla samostatná funkcia **PDF + delenie** pre označené výrobky stavby.
- Používateľ vyberá zvitok šírky 1000 alebo 1250 mm.
- Voliteľne možno pripojiť kontrolnú a cenovú súhrnnú stranu.
- Optimalizátor rozbalí počet kusov a skúsi viac poradí uloženia pásov.
- Rozdielny materiál, RAL a hrúbka sa plánujú ako samostatné zvitky.
- Jedna zostava rešpektuje najviac tri pozdĺžne nože.
- PDF zobrazuje pozdĺžne rezy, priečne rezy, rozmery pásov a bočný aj dĺžkový odpad.
- Súhrn uvádza potrebné bežné metre a m² zvitku, využitie, odpad, hmotnosť a cenu plechu.
- Cena ohýbania je 0,50 €/m ohybu.
- Cena rezania je 0,50 €/m rezu a zahŕňa pozdĺžne aj priečne rezanie.
- Pre každý výrobok sa uvádza počet kusov, metre ohybov, metre rezania a výrobná cena.
- Na konci sa sumarizujú všetky metre ohybov, pozdĺžnych a priečnych rezov a celkové náklady bez DPH.
