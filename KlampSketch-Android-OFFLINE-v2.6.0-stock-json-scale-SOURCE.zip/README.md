# KlampSketch Offline pre Android

Natívna Android aplikácia v Kotline. Nepoužíva WebView, JavaScript, hosting,
OpenAI účet ani internetové pripojenie. Stavby, výkresy a fotografie ukladá
iba do telefónu a PDF vytvára priamo v zariadení.

## Zostavenie cez pripravený GitHub Actions workflow

1. Nahrajte ZIP s týmto projektom do koreňa GitHub repozitára.
2. Súbor workflow musí byť v `.github/workflows/`.
3. Spustite workflow alebo odošlite zmenu do vetvy `main`/`master`.
4. Hotové `app-debug.apk` bude dostupné medzi Artifacts daného workflow.

Projekt podporuje kreslenie prstom, automatické vyrovnanie profilu, úpravu
dĺžok po 5 mm, celé uhly, stavby, kopírovanie profilov, fotoaparát, galériu
a natívne PDF s technickým aj proporčným 3D náhľadom.

## Verzia 2.2.2 – Tapered profiles + Depth 3D

- interaktívny natívny OpenGL ES 3.0 náhľad,
- 24-bitový hĺbkový buffer na správne prekrytie plôch,
- 4× MSAA, ak ho zariadenie poskytne,
- ploché normály, smerové svetlo, kovový lesk a viditeľné iba neprekryté hrany,
- otáčanie jedným prstom, zoom dvoma prstami a reset dvojitým ťuknutím,
- softvérový Z-buffer pre PDF a ako náhradný renderer na starších zariadeniach,
- 3D výrobný nákres má vždy jednotnú červenú technickú farbu RAL 3000.

Workflow `.github/workflows/build-apk.yml` zostaví APK aj bez Gradle Wrappera.
Po spustení akcie je súbor dostupný v artefakte `KlampSketch-v2.2.2-red-offcut-debug`.


## Skosené a trojuholníkové profily

- prepínanie medzi predným a zadným profilom v editore,
- zadný profil vznikne ako presná kópia predného a jeho rozmery možno samostatne upraviť,
- 3D model spája rozdielne koncové profily skutočnými lichobežníkovými plochami,
- databázová migrácia zachová všetky výkresy z verzie 2.1.0,
- pri aktivovanom zadnom profile PDF obsahuje predný aj zadný technický profil,
- automaticky sa pridá samostatný A4 landscape list s rozvinutým plášťom,
- rozvin je v automaticky zvolenej mierke a obsahuje predné, zadné aj skosené rozmery,
- kontrolná 50 mm čiara umožňuje overiť tlač bez zmeny mierky.


## Verzia 2.2.2 – spotreba polotovaru a odrezok

- spotreba plechu sa počíta z najväčšej rozvinutej šírky predného alebo zadného profilu,
- rozvinutý plášť zobrazuje celý obdĺžnikový polotovar,
- nepoužitá klinovitá časť polotovaru je v PDF vyznačená červenou ako odrezok,
- tabuľka rozvinu uvádza rozmer polotovaru, spotrebu aj plochu odrezku,
- hmotnosť hotového profilu zostáva vypočítaná z čistej plochy výrobku bez odrezku.
