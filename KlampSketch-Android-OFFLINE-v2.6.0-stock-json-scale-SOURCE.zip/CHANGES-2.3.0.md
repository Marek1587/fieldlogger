# KlampSketch 2.3.0

- Dve STN deliace značky sú posunuté na opačné strany stredovej osi.
- Prerušované pokračovacie čiary vo vnútri sivého pásu sú tmavšie a výraznejšie.
- Z PDF bol odstránený text aj kóta s vypočítanou dĺžkou vynechaného stredu.
- Na skrátenom výkrese zostáva iba kóta skutočnej celkovej výrobnej dĺžky profilu.
- Editor obsahuje tlačidlo `Pridať bod`; rozdelí vybranú alebo najdlhšiu stranu.
- Na plátne sú samostatné tlačidlá `+` a `−` na zoomovanie.
- Akčné tlačidlá majú jednotný štvorcový vzhľad: ikona nad názvom, biela plocha, antracitový zaoblený okraj a pastelový pás na ľavej hrane.
