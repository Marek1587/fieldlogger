# KlampSketch 2.2.8

- Normové lomové čiary vynechaného stredu sú mierne skrátené smerom dovnútra.
- Začiatočný a koncový diel spája svetlosivá plocha s prerušovanými pokračovacími čiarami.
- Predvolený materiál nového výrobku je `Farebný pozink`, hrúbka `0,50 mm` a farba `RAL 8028`.
- Pre farebný pozink hrúbky 0,50 mm sa používa plošná hmotnosť `3,928 kg/m²`.
- Orientačná cena plechu sa počíta zo spotreby polotovaru sadzbou `3,06 €/kg bez DPH`, na kus aj celkom.
- Z 3D ilustrácie bol odstránený text o ilustračnej dĺžke 500 mm.
