# KlampSketch 2.2.9

- Značka prerušenia má na oboch hraniciach súvislú deliacu čiaru s krátkym cikcakom uprostred.
- Deliace čiary mierne presahujú obrys profilu podľa dodanej technickej ukážky.
- Cez začiatočný diel, sivú vynechanú plochu aj koncový diel prechádza tenká čiarkovo-bodkovaná stredová os.
