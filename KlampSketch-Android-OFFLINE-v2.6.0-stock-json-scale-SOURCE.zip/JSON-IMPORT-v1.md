# Import výrobkov do KlampSketch

Podporovaná schéma má označenie `klampsketch.drawings.v1`. Súradnice bodov a rozmery
profilu sú v milimetroch. Výrobná dĺžka `profileLengthM` je v metroch.

Povinné polia každého výrobku:

- `name` - názov výrobku,
- `points` - najmenej dva body `{ "x": ..., "y": ... }`.

Voliteľné polia:

- `identifier` - vlastné označenie; pri vynechaní ho doplní aplikácia,
- `backPoints` - zadný profil s rovnakým počtom bodov ako predný profil,
- `material`, `ral`, `thicknessMm`, `profileLengthM`, `quantity`,
- `paintedTopSide` alebo `paintedSide` s hodnotou `top`/`bottom`.

Import vždy pridáva nové výrobky do otvorenej stavby. Existujúce výrobky nemení ani
neodstraňuje. Pred zápisom zobrazí kontrolný zoznam a vyžiada potvrdenie.

Pri väčšom výpise možno spoločnú geometriu uložiť iba raz do objektu `profiles` a vo
výrobku na ňu odkázať poľom `profile`. Spoločný materiál, RAL a hrúbku možno uviesť
v objekte `defaults`. Hodnota priamo vo výrobku má prednosť pred profilom a profil má
prednosť pred predvolenou hodnotou.
