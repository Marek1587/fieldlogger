# KlampSketch 2.6.0

- Technický profil v PDF uvádza skutočnú mierku automatického zobrazenia.
- Každý technický profil má kontrolnú stupnicu pre 10 cm (100 mm).
- Rozvinutý plášť uvádza mierku a rovnakú 10 cm kontrolnú stupnicu.
- Cena plechu je 2,69 €/kg bez DPH.
- Výroba profilu sa počíta podľa výrobnej dĺžky: 0,77 €/m do 2 m a 0,72 €/m od 2 m.
- Cenový súhrn obsahuje počty kusov v jednotlivých dĺžkových pásmach.
- Stavba môže evidovať skladové tabule vrátane rozmeru, množstva, materiálu, RAL a hrúbky.
- Optimalizátor použije zhodné skladové tabule pred novým zvitkom a pôvod výrobkov označí v PDF.
- Pribudlo hromadné vybratie a zrušenie výberu všetkých výrobkov.
- Pribudol kontrolovaný import výrobkov zo schémy `klampsketch.drawings.v1`.
- Databáza sa migruje bez odstránenia existujúcich nákresov alebo ciest k fotografiám.
- APK používa pribalený stabilný aktualizačný podpis pre rovnaké budúce zostavenia.
