# KlampSketch Android OFFLINE – zmeny 2.2.5

- opravená Kotlin kompilácia v `DevelopedProfilePdfRenderer.kt`
- odstránené tieňovanie parametra `color` vo vnútri `Paint.apply`
- zachovaný nový solver rozloženia a dielenské označenia rozvinu
