package sk.klampsketch.app

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import kotlin.math.max

class Profile3DView(context: Context) : GLSurfaceView(context) {
    private val profileRenderer = Profile3DRenderer()
    private var lastX = 0f
    private var lastY = 0f

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                profileRenderer.zoom = (
                    profileRenderer.zoom * detector.scaleFactor
                ).coerceIn(0.55f, 2.6f)
                requestRender()
                return true
            }
        }
    )

    private val gestureDetector = GestureDetector(
        context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetView()
                return true
            }
        }
    )

    init {
        setEGLContextClientVersion(3)
        setEGLConfigChooser(MultisampleConfigChooser())
        setPreserveEGLContextOnPause(true)
        setRenderer(profileRenderer)
        setRenderMode(RENDERMODE_WHEN_DIRTY)
        contentDescription = "Interaktívny trojrozmerný náhľad klampiarskeho profilu"
    }

    fun setProfile(
        frontPoints: List<ProfilePoint>,
        backPoints: List<ProfilePoint>?,
        profileLengthMm: Float,
        ral: String,
        material: String,
        paintedTopSide: Boolean
    ) {
        profileRenderer.setProfile(
            frontPoints,
            backPoints,
            profileLengthMm,
            ral,
            material,
            paintedTopSide
        )
        requestRender()
    }

    fun resetView() {
        profileRenderer.resetView()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x
                lastY = event.y
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (!scaleDetector.isInProgress && event.pointerCount == 1) {
                    val density = max(1f, resources.displayMetrics.density)
                    val dx = (event.x - lastX) / density
                    val dy = (event.y - lastY) / density
                    profileRenderer.yawDegrees += dx * 0.62f
                    profileRenderer.pitchDegrees = (
                        profileRenderer.pitchDegrees + dy * 0.62f
                    ).coerceIn(-82f, 82f)
                    requestRender()
                }
                lastX = event.x
                lastY = event.y
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                performClick()
                return true
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private class MultisampleConfigChooser : GLSurfaceView.EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
            return choose(egl, display, samples = 4, depthBits = 24, stencilBits = 8)
                ?: choose(egl, display, samples = 0, depthBits = 24, stencilBits = 8)
                ?: choose(egl, display, samples = 0, depthBits = 16, stencilBits = 0)
                ?: error("Zariadenie neposkytlo vhodnú OpenGL ES 3 konfiguráciu.")
        }

        private fun choose(
            egl: EGL10,
            display: EGLDisplay,
            samples: Int,
            depthBits: Int,
            stencilBits: Int
        ): EGLConfig? {
            val attributes = mutableListOf(
                EGL10.EGL_RED_SIZE, 8,
                EGL10.EGL_GREEN_SIZE, 8,
                EGL10.EGL_BLUE_SIZE, 8,
                EGL10.EGL_ALPHA_SIZE, 8,
                EGL10.EGL_DEPTH_SIZE, depthBits,
                EGL10.EGL_STENCIL_SIZE, stencilBits,
                EGL10.EGL_RENDERABLE_TYPE, 0x0040
            )
            if (samples > 0) {
                attributes += EGL10.EGL_SAMPLE_BUFFERS
                attributes += 1
                attributes += EGL10.EGL_SAMPLES
                attributes += samples
            }
            attributes += EGL10.EGL_NONE

            val count = IntArray(1)
            if (!egl.eglChooseConfig(
                    display,
                    attributes.toIntArray(),
                    null,
                    0,
                    count
                ) || count[0] <= 0
            ) {
                return null
            }
            val configs = arrayOfNulls<EGLConfig>(count[0])
            if (!egl.eglChooseConfig(
                    display,
                    attributes.toIntArray(),
                    configs,
                    configs.size,
                    count
                )
            ) {
                return null
            }
            return configs.firstOrNull()
        }
    }
}
