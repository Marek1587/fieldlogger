package sk.klampsketch.app

import android.graphics.Color
import kotlin.math.max
import kotlin.math.sqrt

data class Vec3(
    val x: Float,
    val y: Float,
    val z: Float
) {
    operator fun minus(other: Vec3) = Vec3(x - other.x, y - other.y, z - other.z)
}

data class Profile3DMesh(
    val triangleVertices: FloatArray,
    val triangleNormals: FloatArray,
    val edgeVertices: FloatArray
)

object Profile3DMeshBuilder {
    fun build(
        frontPoints: List<ProfilePoint>,
        backPoints: List<ProfilePoint>?,
        profileLengthMm: Float
    ): Profile3DMesh {
        if (frontPoints.size < 2) {
            return Profile3DMesh(FloatArray(0), FloatArray(0), FloatArray(0))
        }
        val back = backPoints?.takeIf { it.size == frontPoints.size } ?: frontPoints
        val allPoints = frontPoints + back
        val minX = allPoints.minOf { it.x }
        val maxX = allPoints.maxOf { it.x }
        val minY = allPoints.minOf { it.y }
        val maxY = allPoints.maxOf { it.y }
        val centerX = (minX + maxX) / 2f
        val centerY = (minY + maxY) / 2f
        val length = profileLengthMm.coerceAtLeast(1f)
        val normalization = 2f / max(
            1f,
            max(maxX - minX, max(maxY - minY, length))
        )
        val frontZ = -length / 2f
        val backZ = length / 2f

        fun vertex(point: ProfilePoint, z: Float) = Vec3(
            (point.x - centerX) * normalization,
            -(point.y - centerY) * normalization,
            z * normalization
        )

        val frontVertices = frontPoints.map { vertex(it, frontZ) }
        val backVertices = back.map { vertex(it, backZ) }
        val trianglePositions = ArrayList<Float>((frontPoints.size - 1) * 18)
        val triangleNormals = ArrayList<Float>((frontPoints.size - 1) * 18)
        val edges = ArrayList<Float>(frontPoints.size * 12 + (frontPoints.size - 1) * 12)

        for (index in 0 until frontPoints.lastIndex) {
            val a = frontVertices[index]
            val b = frontVertices[index + 1]
            val c = backVertices[index + 1]
            val d = backVertices[index]
            val normalA = normalized(cross(b - a, c - a))
            val normalB = normalized(cross(c - a, d - a))
            addTriangle(trianglePositions, triangleNormals, a, b, c, normalA)
            addTriangle(trianglePositions, triangleNormals, a, c, d, normalB)
        }

        for (index in 0 until frontVertices.lastIndex) {
            addLine(edges, frontVertices[index], frontVertices[index + 1])
            addLine(edges, backVertices[index], backVertices[index + 1])
        }
        for (index in frontVertices.indices) {
            addLine(edges, frontVertices[index], backVertices[index])
        }

        return Profile3DMesh(
            trianglePositions.toFloatArray(),
            triangleNormals.toFloatArray(),
            edges.toFloatArray()
        )
    }

    fun build(points: List<ProfilePoint>, profileLengthMm: Float): Profile3DMesh =
        build(points, null, profileLengthMm)

    private fun addTriangle(
        positions: MutableList<Float>,
        normals: MutableList<Float>,
        a: Vec3,
        b: Vec3,
        c: Vec3,
        normal: Vec3
    ) {
        addVertex(positions, a)
        addVertex(positions, b)
        addVertex(positions, c)
        repeat(3) { addVertex(normals, normal) }
    }

    private fun addLine(values: MutableList<Float>, a: Vec3, b: Vec3) {
        addVertex(values, a)
        addVertex(values, b)
    }

    private fun addVertex(values: MutableList<Float>, vertex: Vec3) {
        values += vertex.x
        values += vertex.y
        values += vertex.z
    }

    private fun cross(a: Vec3, b: Vec3) = Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    )

    private fun normalized(value: Vec3): Vec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) Vec3(0f, 1f, 0f) else Vec3(
            value.x / length,
            value.y / length,
            value.z / length
        )
    }
}

object ProfileMaterialPalette {
    // Výrobný 3D nákres má jednotnú technickú farbu nezávislú od skutočnej
    // povrchovej úpravy výrobku. Použitý je sýty červený odtieň RAL 3000.
    private val drawingRed = Color.rgb(175, 43, 30)
    private val undersideLightGray = Color.rgb(211, 218, 222)

    @Suppress("UNUSED_PARAMETER")
    fun androidColor(ral: String, material: String): Int = drawingRed

    fun androidUndersideColor(): Int = undersideLightGray

    fun openGlColor(ral: String, material: String): FloatArray {
        val color = androidColor(ral, material)
        return floatArrayOf(
            Color.red(color) / 255f,
            Color.green(color) / 255f,
            Color.blue(color) / 255f
        )
    }

    fun openGlUndersideColor(): FloatArray = floatArrayOf(
        Color.red(undersideLightGray) / 255f,
        Color.green(undersideLightGray) / 255f,
        Color.blue(undersideLightGray) / 255f
    )
}
