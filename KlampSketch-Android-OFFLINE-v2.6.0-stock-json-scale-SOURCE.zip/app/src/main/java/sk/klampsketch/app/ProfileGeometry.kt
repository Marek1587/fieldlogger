package sk.klampsketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin

object ProfileGeometry {
    fun magicClean(raw: List<ProfilePoint>): MutableList<ProfilePoint> {
        if (raw.size < 2) return mutableListOf()
        val simplified = rdp(raw, 14f).toMutableList()
        if (simplified.size < 2) {
            simplified.clear()
            simplified += raw.first().copy()
            simplified += raw.last().copy()
        }

        val result = mutableListOf(ProfilePoint(0f, 0f))
        simplified.zipWithNext().forEach { (start, end) ->
            val dx = (end.x - start.x).toDouble()
            val dy = (end.y - start.y).toDouble()
            if (hypot(dx, dy) < 8.0) return@forEach
            val length = snapFive(hypot(dx, dy)).toFloat()
            val rawDegrees = Math.toDegrees(atan2(dy, dx))
            val snappedDegrees = round(rawDegrees / 5.0) * 5.0
            val angle = Math.toRadians(snappedDegrees)
            val previous = result.last()
            result += ProfilePoint(
                previous.x + (cos(angle) * length).toFloat(),
                previous.y + (sin(angle) * length).toFloat()
            )
        }

        return if (result.size >= 2) result else mutableListOf(
            ProfilePoint(0f, 0f),
            ProfilePoint(100f, 0f)
        )
    }

    fun snapProfile(points: List<ProfilePoint>): MutableList<ProfilePoint> {
        if (points.size < 2) return points.map { it.copy() }.toMutableList()
        val result = mutableListOf(points.first().copy())
        points.zipWithNext().forEach { (start, end) ->
            val dx = (end.x - start.x).toDouble()
            val dy = (end.y - start.y).toDouble()
            val length = snapFive(hypot(dx, dy)).toFloat()
            val angle = atan2(dy, dx)
            val previous = result.last()
            result += ProfilePoint(
                previous.x + (cos(angle) * length).toFloat(),
                previous.y + (sin(angle) * length).toFloat()
            )
        }
        return result
    }

    fun segmentLength(points: List<ProfilePoint>, index: Int): Int {
        if (index !in 0 until points.lastIndex) return 5
        val start = points[index]
        val end = points[index + 1]
        return snapFive(hypot(
            (end.x - start.x).toDouble(),
            (end.y - start.y).toDouble()
        ))
    }

    fun updateSegmentLength(
        points: List<ProfilePoint>,
        segmentIndex: Int,
        newLengthMm: Int
    ): MutableList<ProfilePoint> {
        val result = points.map { it.copy() }.toMutableList()
        if (segmentIndex !in 0 until result.lastIndex) return result
        val start = result[segmentIndex]
        val oldEnd = result[segmentIndex + 1]
        val angle = atan2(
            (oldEnd.y - start.y).toDouble(),
            (oldEnd.x - start.x).toDouble()
        )
        val length = snapFive(newLengthMm.toDouble()).toFloat()
        val newEnd = ProfilePoint(
            start.x + (cos(angle) * length).toFloat(),
            start.y + (sin(angle) * length).toFloat()
        )
        val shiftX = newEnd.x - oldEnd.x
        val shiftY = newEnd.y - oldEnd.y
        for (index in segmentIndex + 1 until result.size) {
            result[index].x += shiftX
            result[index].y += shiftY
        }
        return result
    }

    fun internalAngle(points: List<ProfilePoint>, vertexIndex: Int): Int {
        if (vertexIndex !in 1 until points.lastIndex) return 180
        val before = points[vertexIndex - 1]
        val vertex = points[vertexIndex]
        val after = points[vertexIndex + 1]
        val ax = (before.x - vertex.x).toDouble()
        val ay = (before.y - vertex.y).toDouble()
        val bx = (after.x - vertex.x).toDouble()
        val by = (after.y - vertex.y).toDouble()
        val denominator = hypot(ax, ay) * hypot(bx, by)
        if (denominator < 0.0001) return 180
        val cosine = ((ax * bx + ay * by) / denominator).coerceIn(-1.0, 1.0)
        return Math.toDegrees(acos(cosine)).roundToIntSafe().coerceIn(1, 179)
    }

    fun updateAngle(
        points: List<ProfilePoint>,
        vertexIndex: Int,
        targetAngle: Int
    ): MutableList<ProfilePoint> {
        val result = points.map { it.copy() }.toMutableList()
        if (vertexIndex !in 1 until result.lastIndex) return result

        val before = result[vertexIndex - 1]
        val vertex = result[vertexIndex]
        val after = result[vertexIndex + 1]
        val incomingHeading = atan2(
            (vertex.y - before.y).toDouble(),
            (vertex.x - before.x).toDouble()
        )
        val outgoingHeading = atan2(
            (after.y - vertex.y).toDouble(),
            (after.x - vertex.x).toDouble()
        )
        val currentTurn = normalizeRadians(outgoingHeading - incomingHeading)
        val sign = if (currentTurn >= 0.0) 1.0 else -1.0
        val desiredTurn = sign * Math.toRadians(180.0 - targetAngle.coerceIn(1, 179))
        val rotation = desiredTurn - currentTurn
        val cosine = cos(rotation)
        val sine = sin(rotation)

        for (index in vertexIndex + 1 until result.size) {
            val dx = (result[index].x - vertex.x).toDouble()
            val dy = (result[index].y - vertex.y).toDouble()
            result[index].x = (vertex.x + dx * cosine - dy * sine).toFloat()
            result[index].y = (vertex.y + dx * sine + dy * cosine).toFloat()
        }
        return snapProfile(result)
    }


    fun alignDirections(
        reference: List<ProfilePoint>,
        target: List<ProfilePoint>
    ): MutableList<ProfilePoint> {
        if (reference.size < 2 || target.size != reference.size) {
            return reference.map { it.copy() }.toMutableList()
        }
        val result = mutableListOf(target.first().copy())
        for (index in 0 until reference.lastIndex) {
            val referenceStart = reference[index]
            val referenceEnd = reference[index + 1]
            val heading = atan2(
                (referenceEnd.y - referenceStart.y).toDouble(),
                (referenceEnd.x - referenceStart.x).toDouble()
            )
            val targetLength = segmentLength(target, index).toFloat()
            val previous = result.last()
            result += ProfilePoint(
                previous.x + (cos(heading) * targetLength).toFloat(),
                previous.y + (sin(heading) * targetLength).toFloat()
            )
        }
        return result
    }

    fun distanceToSegment(
        pointX: Float,
        pointY: Float,
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float
    ): Float {
        val dx = endX - startX
        val dy = endY - startY
        if (abs(dx) + abs(dy) < 0.001f) {
            return hypot((pointX - startX).toDouble(), (pointY - startY).toDouble()).toFloat()
        }
        val t = (((pointX - startX) * dx + (pointY - startY) * dy) /
            (dx * dx + dy * dy)).coerceIn(0f, 1f)
        val nearestX = startX + t * dx
        val nearestY = startY + t * dy
        return hypot(
            (pointX - nearestX).toDouble(),
            (pointY - nearestY).toDouble()
        ).toFloat()
    }

    private fun rdp(points: List<ProfilePoint>, epsilon: Float): List<ProfilePoint> {
        if (points.size < 3) return points.map { it.copy() }
        var maxDistance = 0f
        var maxIndex = 0
        val first = points.first()
        val last = points.last()
        for (index in 1 until points.lastIndex) {
            val distance = distanceToSegment(
                points[index].x,
                points[index].y,
                first.x,
                first.y,
                last.x,
                last.y
            )
            if (distance > maxDistance) {
                maxDistance = distance
                maxIndex = index
            }
        }
        if (maxDistance <= epsilon) return listOf(first.copy(), last.copy())
        val left = rdp(points.subList(0, maxIndex + 1), epsilon)
        val right = rdp(points.subList(maxIndex, points.size), epsilon)
        return left.dropLast(1) + right
    }

    private fun normalizeRadians(value: Double): Double {
        var normalized = value
        while (normalized > PI) normalized -= 2 * PI
        while (normalized < -PI) normalized += 2 * PI
        return normalized
    }

    private fun Double.roundToIntSafe(): Int =
        max(Int.MIN_VALUE.toDouble(), min(Int.MAX_VALUE.toDouble(), round(this))).toInt()
}
