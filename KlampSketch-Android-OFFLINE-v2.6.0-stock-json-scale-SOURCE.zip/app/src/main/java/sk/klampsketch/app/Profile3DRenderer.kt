package sk.klampsketch.app

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

class Profile3DRenderer : GLSurfaceView.Renderer {
    @Volatile
    private var pendingMesh = Profile3DMesh(FloatArray(0), FloatArray(0), FloatArray(0))

    @Volatile
    private var pendingBaseColor = floatArrayOf(0.46f, 0.57f, 0.62f)

    @Volatile
    private var pendingPaintedTopSide = true

    @Volatile
    var yawDegrees = -38f

    @Volatile
    var pitchDegrees = 24f

    @Volatile
    var zoom = 1f

    private var surfaceWidth = 1
    private var surfaceHeight = 1
    private var surfaceProgram = 0
    private var edgeProgram = 0
    private var triangleVbo = 0
    private var edgeVbo = 0
    private var triangleVertexCount = 0
    private var edgeVertexCount = 0
    private var uploadedMesh: Profile3DMesh? = null

    fun setProfile(
        frontPoints: List<ProfilePoint>,
        backPoints: List<ProfilePoint>?,
        profileLengthMm: Float,
        ral: String,
        material: String,
        paintedTopSide: Boolean
    ) {
        pendingMesh = Profile3DMeshBuilder.build(frontPoints, backPoints, profileLengthMm)
        pendingBaseColor = ProfileMaterialPalette.openGlColor(ral, material)
        pendingPaintedTopSide = paintedTopSide
    }

    fun resetView() {
        yawDegrees = -38f
        pitchDegrees = 24f
        zoom = 1f
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glClearColor(0.958f, 0.972f, 0.980f, 1f)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glDepthFunc(GLES30.GL_LEQUAL)
        GLES30.glClearDepthf(1f)
        GLES30.glEnable(GLES30.GL_POLYGON_OFFSET_FILL)

        surfaceProgram = createProgram(SURFACE_VERTEX_SHADER, SURFACE_FRAGMENT_SHADER)
        edgeProgram = createProgram(EDGE_VERTEX_SHADER, EDGE_FRAGMENT_SHADER)

        val buffers = IntArray(2)
        GLES30.glGenBuffers(2, buffers, 0)
        triangleVbo = buffers[0]
        edgeVbo = buffers[1]
        uploadedMesh = null
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        surfaceWidth = max(1, width)
        surfaceHeight = max(1, height)
        GLES30.glViewport(0, 0, surfaceWidth, surfaceHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        uploadPendingMeshIfNeeded()
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        if (triangleVertexCount == 0) return

        val model = FloatArray(16)
        val view = FloatArray(16)
        val projection = FloatArray(16)
        val viewProjection = FloatArray(16)
        val mvp = FloatArray(16)

        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, pitchDegrees, 1f, 0f, 0f)
        Matrix.rotateM(model, 0, yawDegrees, 0f, 1f, 0f)
        val safeZoom = zoom.coerceIn(0.55f, 2.6f)
        Matrix.scaleM(model, 0, safeZoom, safeZoom, safeZoom)

        Matrix.setLookAtM(
            view,
            0,
            0f,
            0f,
            4.8f,
            0f,
            0f,
            0f,
            0f,
            1f,
            0f
        )
        val aspect = surfaceWidth.toFloat() / surfaceHeight.toFloat()
        Matrix.perspectiveM(projection, 0, 35f, aspect, 0.1f, 20f)
        Matrix.multiplyMM(viewProjection, 0, projection, 0, view, 0)
        Matrix.multiplyMM(mvp, 0, viewProjection, 0, model, 0)

        drawSurface(model, mvp)
        drawEdges(mvp)
    }

    private fun uploadPendingMeshIfNeeded() {
        val mesh = pendingMesh
        if (mesh === uploadedMesh) return

        val interleaved = FloatArray((mesh.triangleVertices.size / 3) * 6)
        var source = 0
        var target = 0
        while (source < mesh.triangleVertices.size) {
            interleaved[target++] = mesh.triangleVertices[source]
            interleaved[target++] = mesh.triangleVertices[source + 1]
            interleaved[target++] = mesh.triangleVertices[source + 2]
            interleaved[target++] = mesh.triangleNormals[source]
            interleaved[target++] = mesh.triangleNormals[source + 1]
            interleaved[target++] = mesh.triangleNormals[source + 2]
            source += 3
        }

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            interleaved.size * FLOAT_BYTES,
            interleaved.toNativeBuffer(),
            GLES30.GL_STATIC_DRAW
        )
        triangleVertexCount = mesh.triangleVertices.size / 3

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            mesh.edgeVertices.size * FLOAT_BYTES,
            mesh.edgeVertices.toNativeBuffer(),
            GLES30.GL_STATIC_DRAW
        )
        edgeVertexCount = mesh.edgeVertices.size / 3
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        uploadedMesh = mesh
    }

    private fun drawSurface(model: FloatArray, mvp: FloatArray) {
        GLES30.glUseProgram(surfaceProgram)
        GLES30.glUniformMatrix4fv(
            GLES30.glGetUniformLocation(surfaceProgram, "uModel"),
            1,
            false,
            model,
            0
        )
        GLES30.glUniformMatrix4fv(
            GLES30.glGetUniformLocation(surfaceProgram, "uMvp"),
            1,
            false,
            mvp,
            0
        )
        val color = pendingBaseColor
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(surfaceProgram, "uPaintedColor"),
            color[0],
            color[1],
            color[2]
        )
        val underside = ProfileMaterialPalette.openGlUndersideColor()
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(surfaceProgram, "uUndersideColor"),
            underside[0],
            underside[1],
            underside[2]
        )
        GLES30.glUniform1f(
            GLES30.glGetUniformLocation(surfaceProgram, "uPaintedTopSide"),
            if (pendingPaintedTopSide) 1f else 0f
        )
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(surfaceProgram, "uCameraPosition"),
            0f,
            0f,
            4.8f
        )
        GLES30.glUniform3f(
            GLES30.glGetUniformLocation(surfaceProgram, "uLightDirection"),
            -0.38f,
            0.72f,
            0.58f
        )

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, triangleVbo)
        val position = GLES30.glGetAttribLocation(surfaceProgram, "aPosition")
        val normal = GLES30.glGetAttribLocation(surfaceProgram, "aNormal")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glEnableVertexAttribArray(normal)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 6 * FLOAT_BYTES, 0)
        GLES30.glVertexAttribPointer(
            normal,
            3,
            GLES30.GL_FLOAT,
            false,
            6 * FLOAT_BYTES,
            3 * FLOAT_BYTES
        )

        GLES30.glPolygonOffset(1f, 1f)
        GLES30.glDepthMask(true)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, triangleVertexCount)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glDisableVertexAttribArray(normal)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun drawEdges(mvp: FloatArray) {
        if (edgeVertexCount == 0) return
        GLES30.glUseProgram(edgeProgram)
        GLES30.glUniformMatrix4fv(
            GLES30.glGetUniformLocation(edgeProgram, "uMvp"),
            1,
            false,
            mvp,
            0
        )
        GLES30.glUniform4f(
            GLES30.glGetUniformLocation(edgeProgram, "uEdgeColor"),
            0.075f,
            0.105f,
            0.125f,
            0.92f
        )
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, edgeVbo)
        val position = GLES30.glGetAttribLocation(edgeProgram, "aPosition")
        GLES30.glEnableVertexAttribArray(position)
        GLES30.glVertexAttribPointer(position, 3, GLES30.GL_FLOAT, false, 3 * FLOAT_BYTES, 0)
        GLES30.glLineWidth(1.5f)
        GLES30.glDepthMask(false)
        GLES30.glDrawArrays(GLES30.GL_LINES, 0, edgeVertexCount)
        GLES30.glDepthMask(true)
        GLES30.glDisableVertexAttribArray(position)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
    }

    private fun createProgram(vertexSource: String, fragmentSource: String): Int {
        val vertexShader = compileShader(GLES30.GL_VERTEX_SHADER, vertexSource)
        val fragmentShader = compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentSource)
        return GLES30.glCreateProgram().also { program ->
            GLES30.glAttachShader(program, vertexShader)
            GLES30.glAttachShader(program, fragmentShader)
            GLES30.glLinkProgram(program)
            val status = IntArray(1)
            GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) {
                val message = GLES30.glGetProgramInfoLog(program)
                GLES30.glDeleteProgram(program)
                error("OpenGL program sa nepodarilo prepojiť: $message")
            }
            GLES30.glDeleteShader(vertexShader)
            GLES30.glDeleteShader(fragmentShader)
        }
    }

    private fun compileShader(type: Int, source: String): Int =
        GLES30.glCreateShader(type).also { shader ->
            GLES30.glShaderSource(shader, source)
            GLES30.glCompileShader(shader)
            val status = IntArray(1)
            GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                val message = GLES30.glGetShaderInfoLog(shader)
                GLES30.glDeleteShader(shader)
                error("OpenGL shader sa nepodarilo skompilovať: $message")
            }
        }

    private fun FloatArray.toNativeBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * FLOAT_BYTES)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(this@toNativeBuffer)
                position(0)
            }

    companion object {
        private const val FLOAT_BYTES = 4

        private const val SURFACE_VERTEX_SHADER = """
            #version 300 es
            uniform mat4 uModel;
            uniform mat4 uMvp;
            in vec3 aPosition;
            in vec3 aNormal;
            out vec3 vWorldPosition;
            out vec3 vNormal;
            void main() {
                vec4 world = uModel * vec4(aPosition, 1.0);
                vWorldPosition = world.xyz;
                vNormal = mat3(uModel) * aNormal;
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """

        private const val SURFACE_FRAGMENT_SHADER = """
            #version 300 es
            precision highp float;
            uniform vec3 uPaintedColor;
            uniform vec3 uUndersideColor;
            uniform float uPaintedTopSide;
            uniform vec3 uCameraPosition;
            uniform vec3 uLightDirection;
            in vec3 vWorldPosition;
            in vec3 vNormal;
            out vec4 outColor;
            void main() {
                bool paintedSurface = (uPaintedTopSide > 0.5) != gl_FrontFacing;
                vec3 baseColor = paintedSurface ? uPaintedColor : uUndersideColor;
                vec3 normal = normalize(vNormal);
                if (!gl_FrontFacing) normal = -normal;
                vec3 light = normalize(uLightDirection);
                vec3 viewDirection = normalize(uCameraPosition - vWorldPosition);
                vec3 halfVector = normalize(light + viewDirection);
                float diffuse = max(dot(normal, light), 0.0);
                float specular = pow(max(dot(normal, halfVector), 0.0), 42.0);
                float fresnel = pow(1.0 - max(dot(normal, viewDirection), 0.0), 3.0);
                vec3 shaded = baseColor * (0.42 + 0.58 * diffuse);
                shaded += vec3(0.72) * specular * 0.34;
                shaded += baseColor * fresnel * 0.16;
                outColor = vec4(clamp(shaded, 0.0, 1.0), 1.0);
            }
        """

        private const val EDGE_VERTEX_SHADER = """
            #version 300 es
            uniform mat4 uMvp;
            in vec3 aPosition;
            void main() {
                gl_Position = uMvp * vec4(aPosition, 1.0);
            }
        """

        private const val EDGE_FRAGMENT_SHADER = """
            #version 300 es
            precision mediump float;
            uniform vec4 uEdgeColor;
            out vec4 outColor;
            void main() {
                outColor = uEdgeColor;
            }
        """
    }
}
