package sk.klampsketch.app

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot

data class DrawingImportResult(
    val drawings: List<DrawingRecord>,
    val warnings: List<String>
)

object DrawingJsonImporter {
    const val SCHEMA = "klampsketch.drawings.v1"

    fun parse(
        json: String,
        projectId: Long,
        autoIdentifier: (Int) -> String
    ): DrawingImportResult {
        val trimmed = json.trim()
        require(trimmed.isNotEmpty()) { "JSON súbor je prázdny." }
        val root = if (trimmed.startsWith("[")) {
            JSONObject().put("drawings", JSONArray(trimmed))
        } else {
            JSONObject(trimmed)
        }
        val declaredSchema = root.optString("schema")
        require(declaredSchema.isBlank() || declaredSchema == SCHEMA) {
            "Nepodporovaná schéma JSON: $declaredSchema"
        }
        val array = root.optJSONArray("drawings")
            ?: error("JSON neobsahuje pole drawings.")
        val templates = root.optJSONObject("profiles")
        val defaults = root.optJSONObject("defaults") ?: JSONObject()
        require(array.length() in 1..500) {
            "JSON musí obsahovať 1 až 500 výrobkov."
        }

        val warnings = mutableListOf<String>()
        val drawings = List(array.length()) { index ->
            val item = array.getJSONObject(index)
            val templateName = item.optString("profile").trim()
            val template = if (templateName.isBlank()) null else {
                templates?.optJSONObject(templateName)
                    ?: error("Výrobok ${index + 1}: profil '$templateName' nie je definovaný.")
            }
            val name = firstString(item, template, defaults, "name").ifBlank {
                warnings += "Výrobok ${index + 1} nemal názov; bol doplnený všeobecný názov."
                "Importovaný klampiarsky prvok"
            }
            val pointsArray = item.optJSONArray("points") ?: template?.optJSONArray("points")
                ?: error("Výrobok ${index + 1}: chýba points alebo odkaz na profil.")
            val points = parsePoints(pointsArray, index, "points")
            val backPoints = (item.optJSONArray("backPoints")
                ?: template?.optJSONArray("backPoints"))?.let { back ->
                parsePoints(back, index, "backPoints").also {
                    require(it.size == points.size) {
                        "Výrobok ${index + 1}: backPoints musí mať rovnaký počet bodov ako points."
                    }
                }
            }
            val profileLengthM = firstDouble(
                item,
                template,
                defaults,
                "profileLengthM",
                firstDouble(item, template, defaults, "lengthM", 2.0)
            )
            require(profileLengthM.isFinite() && profileLengthM in 0.01..1_000.0) {
                "Výrobok ${index + 1}: neplatná výrobná dĺžka."
            }
            val thicknessMm = firstDouble(item, template, defaults, "thicknessMm", 0.5)
            require(thicknessMm.isFinite() && thicknessMm in 0.1..5.0) {
                "Výrobok ${index + 1}: neplatná hrúbka plechu."
            }
            val quantity = firstInt(item, template, defaults, "quantity", 1)
            require(quantity in 1..10_000) {
                "Výrobok ${index + 1}: neplatný počet kusov."
            }
            val identifier = item.optString("identifier").trim().ifBlank {
                autoIdentifier(index)
            }
            val paintedTop = when (
                firstString(item, template, defaults, "paintedSide").lowercase()
            ) {
                "bottom", "spodna", "spodná" -> false
                else -> firstBoolean(item, template, defaults, "paintedTopSide", true)
            }
            DrawingRecord(
                projectId = projectId,
                name = name,
                identifier = identifier,
                points = points,
                backPoints = backPoints,
                material = firstString(item, template, defaults, "material").trim()
                    .ifBlank { "Farebný pozink" },
                ral = firstString(item, template, defaults, "ral").trim()
                    .ifBlank { "RAL 8028" },
                thicknessMm = thicknessMm,
                profileLengthM = profileLengthM,
                quantity = quantity,
                paintedTopSide = paintedTop,
                updatedAt = System.currentTimeMillis() + index
            )
        }
        return DrawingImportResult(drawings, warnings)
    }

    private fun firstString(
        item: JSONObject,
        template: JSONObject?,
        defaults: JSONObject,
        key: String
    ): String = when {
        item.has(key) -> item.optString(key)
        template?.has(key) == true -> template.optString(key)
        else -> defaults.optString(key)
    }

    private fun firstDouble(
        item: JSONObject,
        template: JSONObject?,
        defaults: JSONObject,
        key: String,
        fallback: Double
    ): Double = when {
        item.has(key) -> item.optDouble(key, fallback)
        template?.has(key) == true -> template.optDouble(key, fallback)
        else -> defaults.optDouble(key, fallback)
    }

    private fun firstInt(
        item: JSONObject,
        template: JSONObject?,
        defaults: JSONObject,
        key: String,
        fallback: Int
    ): Int = when {
        item.has(key) -> item.optInt(key, fallback)
        template?.has(key) == true -> template.optInt(key, fallback)
        else -> defaults.optInt(key, fallback)
    }

    private fun firstBoolean(
        item: JSONObject,
        template: JSONObject?,
        defaults: JSONObject,
        key: String,
        fallback: Boolean
    ): Boolean = when {
        item.has(key) -> item.optBoolean(key, fallback)
        template?.has(key) == true -> template.optBoolean(key, fallback)
        else -> defaults.optBoolean(key, fallback)
    }

    private fun parsePoints(
        array: JSONArray,
        drawingIndex: Int,
        field: String
    ): MutableList<ProfilePoint> {
        require(array.length() in 2..50) {
            "Výrobok ${drawingIndex + 1}: $field musí obsahovať 2 až 50 bodov."
        }
        val points = MutableList(array.length()) { index ->
            val raw = array.get(index)
            val x: Double
            val y: Double
            if (raw is JSONObject) {
                x = raw.getDouble("x")
                y = raw.getDouble("y")
            } else {
                val pair = raw as? JSONArray
                    ?: error("Výrobok ${drawingIndex + 1}: bod $field[$index] nie je platný.")
                require(pair.length() >= 2) {
                    "Výrobok ${drawingIndex + 1}: bod $field[$index] nemá dve súradnice."
                }
                x = pair.getDouble(0)
                y = pair.getDouble(1)
            }
            require(x.isFinite() && y.isFinite() && x in -100_000.0..100_000.0 && y in -100_000.0..100_000.0) {
                "Výrobok ${drawingIndex + 1}: bod $field[$index] je mimo povoleného rozsahu."
            }
            ProfilePoint(x.toFloat(), y.toFloat())
        }
        points.zipWithNext().forEachIndexed { index, (start, end) ->
            require(hypot((end.x - start.x).toDouble(), (end.y - start.y).toDouble()) >= 1.0) {
                "Výrobok ${drawingIndex + 1}: úsek $field[$index] je kratší ako 1 mm."
            }
        }
        return points
    }
}
