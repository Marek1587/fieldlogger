package sk.klampsketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

data class FlatPoint(val x: Double, val y: Double) {
    operator fun plus(other: FlatPoint) = FlatPoint(x + other.x, y + other.y)
    operator fun minus(other: FlatPoint) = FlatPoint(x - other.x, y - other.y)
}

data class DevelopedPanel(
    val index: Int,
    val frontStart: FlatPoint,
    val frontEnd: FlatPoint,
    val backStart: FlatPoint,
    val backEnd: FlatPoint,
    val frontWidthMm: Double,
    val rearWidthMm: Double,
    val startCutLengthMm: Double,
    val endCutLengthMm: Double
)

data class DevelopedProfile(
    val frontEdge: List<FlatPoint>,
    val backEdge: List<FlatPoint>,
    val panels: List<DevelopedPanel>,
    val minX: Double,
    val minY: Double,
    val maxX: Double,
    val maxY: Double
) {
    val widthMm: Double get() = maxX - minX
    val heightMm: Double get() = maxY - minY
}

object DevelopedProfileBuilder {
    fun build(drawing: DrawingRecord): DevelopedProfile? {
        val front = drawing.points
        val back = drawing.validBackPoints() ?: return null
        if (front.size < 2) return null
        val length = drawing.profileLengthM * 1000.0
        val front3 = front.map { Point3(it.x.toDouble(), it.y.toDouble(), 0.0) }
        val back3 = back.map { Point3(it.x.toDouble(), it.y.toDouble(), length) }
        val foldLengths = front.indices.map { distance(front3[it], back3[it]) }

        val flatFront = mutableListOf(FlatPoint(0.0, 0.0))
        val flatBack = mutableListOf(FlatPoint(foldLengths.first(), 0.0))
        val panels = mutableListOf<DevelopedPanel>()

        for (index in 0 until front.lastIndex) {
            val currentFront = flatFront[index]
            val currentBack = flatBack[index]
            val frontWidth = distance(front3[index], front3[index + 1])
            val rearWidth = distance(back3[index], back3[index + 1])
            val diagonal = distance(front3[index], back3[index + 1])
            val nextFold = foldLengths[index + 1]

            val candidates = panelCandidates(
                currentFront,
                currentBack,
                frontWidth,
                rearWidth,
                diagonal,
                nextFold
            )
            val chosen = if (index == 0) {
                candidates.maxByOrNull { sideOfLine(currentFront, currentBack, midpoint(it.first, it.second)) }
            } else {
                val previousMidpoint = midpoint(flatFront[index - 1], flatBack[index - 1])
                val previousSide = sideOfLine(currentFront, currentBack, previousMidpoint)
                candidates.maxByOrNull { candidate ->
                    val nextSide = sideOfLine(currentFront, currentBack, midpoint(candidate.first, candidate.second))
                    if (previousSide * nextSide < 0.0) 1_000_000.0 + abs(nextSide) else abs(nextSide)
                }
            } ?: return null

            flatFront += chosen.first
            flatBack += chosen.second
            panels += DevelopedPanel(
                index = index,
                frontStart = currentFront,
                frontEnd = chosen.first,
                backStart = currentBack,
                backEnd = chosen.second,
                frontWidthMm = frontWidth,
                rearWidthMm = rearWidth,
                startCutLengthMm = foldLengths[index],
                endCutLengthMm = nextFold
            )
        }

        val all = flatFront + flatBack
        return DevelopedProfile(
            frontEdge = flatFront,
            backEdge = flatBack,
            panels = panels,
            minX = all.minOf { it.x },
            minY = all.minOf { it.y },
            maxX = all.maxOf { it.x },
            maxY = all.maxOf { it.y }
        )
    }

    private fun panelCandidates(
        currentFront: FlatPoint,
        currentBack: FlatPoint,
        frontWidth: Double,
        rearWidth: Double,
        diagonal: Double,
        nextFold: Double
    ): List<Pair<FlatPoint, FlatPoint>> {
        val backCandidates = circleIntersections(
            currentFront,
            diagonal,
            currentBack,
            rearWidth
        )
        val result = mutableListOf<Pair<FlatPoint, FlatPoint>>()
        backCandidates.forEach { nextBack ->
            val frontCandidates = circleIntersections(
                currentFront,
                frontWidth,
                nextBack,
                nextFold
            )
            val backSide = sideOfLine(currentFront, nextBack, currentBack)
            val nextFront = frontCandidates.maxByOrNull { candidate ->
                val candidateSide = sideOfLine(currentFront, nextBack, candidate)
                if (backSide * candidateSide < 0.0) 1_000_000.0 + abs(candidateSide) else abs(candidateSide)
            }
            if (nextFront != null) result += nextFront to nextBack
        }
        return result
    }

    private fun circleIntersections(
        firstCenter: FlatPoint,
        firstRadius: Double,
        secondCenter: FlatPoint,
        secondRadius: Double
    ): List<FlatPoint> {
        val delta = secondCenter - firstCenter
        val distance = hypot(delta.x, delta.y)
        if (distance < 0.000001) return emptyList()
        val safeFirst = firstRadius.coerceAtLeast(0.000001)
        val safeSecond = secondRadius.coerceAtLeast(0.000001)
        val x = (
            safeFirst * safeFirst - safeSecond * safeSecond + distance * distance
        ) / (2.0 * distance)
        val hSquared = max(0.0, safeFirst * safeFirst - x * x)
        val h = sqrt(hSquared)
        val unitX = delta.x / distance
        val unitY = delta.y / distance
        val base = FlatPoint(
            firstCenter.x + x * unitX,
            firstCenter.y + x * unitY
        )
        val perpendicular = FlatPoint(-unitY * h, unitX * h)
        return if (h < 0.000001) {
            listOf(base)
        } else {
            listOf(base + perpendicular, base - perpendicular)
        }
    }

    private fun sideOfLine(start: FlatPoint, end: FlatPoint, point: FlatPoint): Double =
        (end.x - start.x) * (point.y - start.y) -
            (end.y - start.y) * (point.x - start.x)

    private fun midpoint(a: FlatPoint, b: FlatPoint) =
        FlatPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)

    private fun distance(a: Point3, b: Point3): Double = hypot(
        hypot(b.x - a.x, b.y - a.y),
        b.z - a.z
    )

    private data class Point3(val x: Double, val y: Double, val z: Double)
}
