package sk.klampsketch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

object ProfileShareImageExporter {
    fun export(
        context: Context,
        project: ProjectRecord,
        drawings: List<DrawingRecord>
    ): ArrayList<Uri> {
        require(drawings.isNotEmpty()) { "Nie sú vybrané žiadne profily." }
        val directory = File(
            context.cacheDir,
            "share/images/${System.currentTimeMillis()}"
        ).apply { mkdirs() }
        return ArrayList(
            drawings.mapIndexed { index, drawing ->
                val file = File(
                    directory,
                    "${(index + 1).toString().padStart(2, '0')}-${safeName(drawing.identifier)}.jpg"
                )
                drawImage(project, drawing).useBitmap { bitmap ->
                    FileOutputStream(file).use { output ->
                        check(bitmap.compress(Bitmap.CompressFormat.JPEG, 94, output)) {
                            "JPG obrázok sa nepodarilo uložiť."
                        }
                    }
                }
                FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
            }
        )
    }

    private fun drawImage(
        project: ProjectRecord,
        drawing: DrawingRecord
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(1600, 1200, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(39, 54, 64)
            style = Paint.Style.STROKE
            strokeWidth = 3f
        }
        val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(24, 43, 57)
            textSize = 44f
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(79, 96, 108)
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
        }
        val section = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(8, 119, 201)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
        }

        canvas.drawRect(25f, 25f, 1575f, 1175f, border)
        canvas.drawText(drawing.name, 60f, 80f, title)
        canvas.drawText(
            "${drawing.identifier}  •  ${project.name}",
            60f,
            118f,
            subtitle
        )

        val technical = RectF(50f, 150f, 1030f, 930f)
        val preview = RectF(1060f, 150f, 1550f, 650f)
        canvas.drawRect(technical, border)
        canvas.drawRect(preview, border)
        drawTechnical(canvas, technical, drawing, section, border)

        val previewBitmap = Profile3DBitmapRenderer.render(
            width = 900,
            height = 900,
            frontPoints = drawing.points,
            backPoints = drawing.validBackPoints(),
            profileLengthMm = 500f,
            ral = drawing.ral,
            material = drawing.material,
            paintedTopSide = drawing.paintedTopSide
        )
        canvas.drawBitmap(
            previewBitmap,
            null,
            RectF(preview.left + 8f, preview.top + 8f, preview.right - 8f, preview.bottom - 8f),
            Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        )
        previewBitmap.recycle()

        val metrics = calculateMetrics(drawing)
        val side = if (drawing.paintedTopSide) "vrchná" else "spodná"
        val infoLines = listOf(
            "Lakovaná strana: $side",
            "${drawing.material}, hr. ${formatDecimal(drawing.thicknessMm, 2)} mm",
            "${drawing.ral}  •  dĺžka ${formatDecimal(drawing.profileLengthM, 2)} m",
            "Rozvin ${metrics.developedWidthMm} mm  •  ${metrics.bends} ohybov",
            "${drawing.quantity} ks  •  ${formatDecimal(metrics.sheetTotalM2)} m² plechu"
        )
        val infoArea = RectF(1060f, 680f, 1550f, 930f)
        canvas.drawRect(infoArea, border)
        infoLines.forEachIndexed { line, value ->
            canvas.drawText(value, infoArea.left + 18f, infoArea.top + 40f + line * 42f, subtitle)
        }

        canvas.drawLine(50f, 980f, 1550f, 980f, border)
        canvas.drawText(
            "Červená čiara a červená plocha označujú lakovanú pohľadovú stranu.",
            60f,
            1035f,
            subtitle
        )
        canvas.drawText(
            "KlampSketch Offline  •  výrobný náhľad",
            60f,
            1120f,
            subtitle
        )
        return bitmap
    }

    private fun drawTechnical(
        canvas: Canvas,
        area: RectF,
        drawing: DrawingRecord,
        sectionPaint: Paint,
        borderPaint: Paint
    ) {
        val back = drawing.validBackPoints()
        if (back == null) {
            canvas.drawText("TECHNICKÝ PROFIL", area.left + 18f, area.top + 36f, sectionPaint)
            ProfileRenderer.renderTechnical(
                canvas = canvas,
                area = RectF(area.left + 12f, area.top + 48f, area.right - 12f, area.bottom - 12f),
                points = drawing.points,
                labelSize = 28f,
                showHandles = false,
                paintedTopSide = drawing.paintedTopSide
            )
            return
        }

        val divider = area.centerY()
        canvas.drawLine(area.left, divider, area.right, divider, borderPaint)
        canvas.drawText("PREDNÝ PROFIL", area.left + 18f, area.top + 36f, sectionPaint)
        ProfileRenderer.renderTechnical(
            canvas = canvas,
            area = RectF(area.left + 12f, area.top + 48f, area.right - 12f, divider - 12f),
            points = drawing.points,
            labelSize = 23f,
            showHandles = false,
            paintedTopSide = drawing.paintedTopSide
        )
        canvas.drawText("ZADNÝ PROFIL", area.left + 18f, divider + 36f, sectionPaint)
        ProfileRenderer.renderTechnical(
            canvas = canvas,
            area = RectF(area.left + 12f, divider + 48f, area.right - 12f, area.bottom - 12f),
            points = back,
            labelSize = 23f,
            showHandles = false,
            paintedTopSide = drawing.paintedTopSide
        )
    }

    private inline fun Bitmap.useBitmap(block: (Bitmap) -> Unit) {
        try {
            block(this)
        } finally {
            recycle()
        }
    }

    private fun safeName(value: String): String =
        value.replace(Regex("""[\\/:*?"<>|\r\n]"""), "_")
            .trim()
            .ifBlank { "profil" }
}
