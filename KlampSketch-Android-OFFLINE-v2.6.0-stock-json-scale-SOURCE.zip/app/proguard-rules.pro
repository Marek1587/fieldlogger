# KlampSketch Offline momentálne nepoužíva reflexiu ani webové rozhranie.
