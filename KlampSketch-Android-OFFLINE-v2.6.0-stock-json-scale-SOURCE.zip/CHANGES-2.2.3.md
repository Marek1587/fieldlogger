# KlampSketch Android OFFLINE – zmeny 2.2.3

## Nové funkcie
- výber bodu ťuknutím a jeho odstránenie cez tlačidlo **Vymazať bod**
- ručné posúvanie plátna jedným prstom mimo profilu
- ručné zoomovanie plátna dvoma prstami
- zvýraznenie vybraného bodu oranžovým krúžkom

## Zlepšenia
- ľahší výber drobných detailov pri malých profiloch
- rozvinutý plášť ide vždy na samostatnú **A4 na výšku**
- PDF zostáva v mierke s kontrolnou čiarou 50 mm
