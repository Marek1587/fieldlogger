# KlampSketch 2.2.7

- Opravená mierka druhej strany PDF: pri skrátenom zobrazení sa už do mierky nezapočítava skrytý stred profilu.
- Profil s výrobnou dĺžkou do 450 mm sa zobrazuje celý.
- Dlhší profil zobrazuje prvých 150 mm, vynechaný stred a posledných 150 mm.
- Vynechaný stred je označený technickou prerušovacou čiarou a textom `VYNECHANÝ STRED`.
- Dĺžková kóta naďalej uvádza skutočnú celkovú výrobnú dĺžku.
- Predné a zadné čelo majú samostatné numerické kóty bez značiek P1/P2 a Z1/Z2.
- Kóty používajú jednoduchý kolízny solver, ktorý im prideľuje voľné pásy.
- Celkové rozviny predného a zadného čela sa kótujú bez červeného výrobného odrezku.
- Ohybové a rezné čiary zostávajú na oboch zobrazených koncoch.
- 3D ilustrácia v PDF používa pevnú ilustračnú dĺžku 500 mm.
