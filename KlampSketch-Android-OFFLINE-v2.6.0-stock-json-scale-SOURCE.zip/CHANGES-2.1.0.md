# KlampSketch 2.1.0 – Depth 3D

## Čo bolo zmenené

Pôvodný 3D náhľad nebol skutočný 3D model. Android Canvas iba nakreslil predný profil,
posunutý zadný profil a spojovacie štvoruholníky v pevnom poradí. Pri prekrytí preto
nebolo možné určiť, ktorá plocha je bližšie ku kamere.

Nová verzia obsahuje:

1. `Profile3DMeshBuilder` – prevod profilu na trojuholníkovú 3D sieť.
2. `Profile3DRenderer` – OpenGL ES 3.0 renderer so Z-bufferom, svetlom a kovovým leskom.
3. `Profile3DView` – dotykové otáčanie, pinch zoom a reset dvojitým ťuknutím.
4. `Profile3DBitmapRenderer` – softvérový Z-buffer pre export do PDF a staršie zariadenia.
5. Mapovanie najbežnejších RAL farieb a kovových materiálov na farbu modelu.
6. Depth-tested hrany: prekryté hrany sa nekreslia cez predné plochy.
7. GitHub Actions workflow na zostavenie debug APK.

## Kde sa funkcia používa

V editore pribudlo tlačidlo **3D náhľad**. PDF export automaticky používa nový
softvérový renderer, takže správne prekrytie funguje aj vo výslednom dokumente.

## Technická poznámka

WebGL2 je koncepčne založený na OpenGL ES 3.0. V natívnom Androide rovnakú úlohu
vykonáva `GLSurfaceView`, `GLES30.GL_DEPTH_TEST` a depth buffer EGL konfigurácie.
Pre `PdfDocument.Canvas` je použitý vlastný rasterizačný Z-buffer, pretože PDF Canvas
nemá natívny OpenGL framebuffer.
