package sk.strechostav.sonixcommander;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_SEND_SMS = 301;
    private static final String PREFS = "sonix_prefs";

    private EditText alarmPhoneInput;
    private EditText passwordInput;
    private Spinner commandSpinner;
    private LinearLayout dynamicFields;
    private TextView commandPreview;
    private TextView helpText;
    private final List<CommandSpec> commands = new ArrayList<>();
    private final List<EditText> activeInputs = new ArrayList<>();
    private String pendingDirectSms;

    static class FieldSpec {
        final String key, label, hint;
        final int inputType;
        final boolean ascii24;
        FieldSpec(String key, String label, String hint, int inputType, boolean ascii24) {
            this.key = key; this.label = label; this.hint = hint; this.inputType = inputType; this.ascii24 = ascii24;
        }
    }

    static class CommandSpec {
        final String title, description, template;
        final FieldSpec[] fields;
        CommandSpec(String title, String description, String template, FieldSpec... fields) {
            this.title = title; this.description = description; this.template = template; this.fields = fields;
        }
        @Override public String toString() { return title; }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        seedCommands();
        buildUi();
        loadPrefs();
        renderDynamicFields();
        updatePreview();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("EVOLVEO Sonix Commander");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Vyber akciu, doplň iba potrebné údaje a aplikácia pripraví SMS príkaz pre alarm.");
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 0, 0, dp(16));
        root.addView(subtitle);

        alarmPhoneInput = input("Telefónne číslo SIM v alarme", "+421940166128", android.text.InputType.TYPE_CLASS_PHONE);
        root.addView(alarmPhoneInput);
        passwordInput = input("Heslo alarmu", "123456", android.text.InputType.TYPE_CLASS_NUMBER);
        root.addView(passwordInput);

        TextView choose = label("Čo chceš urobiť");
        root.addView(choose);
        commandSpinner = new Spinner(this);
        ArrayAdapter<CommandSpec> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, commands);
        commandSpinner.setAdapter(adapter);
        root.addView(commandSpinner);

        helpText = new TextView(this);
        helpText.setTextSize(13);
        helpText.setPadding(0, dp(8), 0, dp(8));
        root.addView(helpText);

        dynamicFields = new LinearLayout(this);
        dynamicFields.setOrientation(LinearLayout.VERTICAL);
        root.addView(dynamicFields);

        TextView previewLabel = label("Pripravená SMS");
        previewLabel.setPadding(0, dp(12), 0, 0);
        root.addView(previewLabel);
        commandPreview = new TextView(this);
        commandPreview.setTextSize(18);
        commandPreview.setPadding(dp(12), dp(10), dp(12), dp(10));
        commandPreview.setBackgroundColor(0xffeeeeee);
        root.addView(commandPreview);

        Button openSms = button("Otvoriť SMS aplikáciu s pripraveným príkazom");
        openSms.setOnClickListener(v -> openSmsApp());
        root.addView(openSms);

        Button directSms = button("Odoslať SMS priamo z aplikácie");
        directSms.setOnClickListener(v -> sendDirectSms());
        root.addView(directSms);

        Button copy = button("Kopírovať príkaz do schránky");
        copy.setOnClickListener(v -> copyCommand());
        root.addView(copy);

        TextView note = new TextView(this);
        note.setText("Poznámka: pri pomenovaní zón používaj radšej text bez diakritiky a max. 24 znakov. Príkazy vychádzajú z manuálu EVOLVEO Sonix.");
        note.setTextSize(12);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scroll);

        TextWatcher watcher = new SimpleWatcher() { @Override public void afterTextChanged(Editable s) { savePrefs(); updatePreview(); } };
        alarmPhoneInput.addTextChangedListener(watcher);
        passwordInput.addTextChangedListener(watcher);
        commandSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { renderDynamicFields(); updatePreview(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });
    }

    private void seedCommands() {
        FieldSpec phone = new FieldSpec("phone", "Telefónne číslo", "0905514643 alebo +421905514643", android.text.InputType.TYPE_CLASS_PHONE, false);
        FieldSpec text = new FieldSpec("text", "Text SMS názvu zóny", "Dvere karavanu otvorene", android.text.InputType.TYPE_CLASS_TEXT, true);
        FieldSpec zone = new FieldSpec("zone", "Číslo zóny", "1-16 bezdrôtové, 21-23 drôtové", android.text.InputType.TYPE_CLASS_NUMBER, false);
        FieldSpec delay = new FieldSpec("value", "Hodnota 00–99", "napr. 10", android.text.InputType.TYPE_CLASS_NUMBER, false);
        FieldSpec pass = new FieldSpec("newpass", "Nové heslo", "1 až 6 číslic", android.text.InputType.TYPE_CLASS_NUMBER, false);

        add("Aktivovať alarm – všetky senzory", "Plná aktivácia. Vhodné keď opúšťaš karavan.", "1#1#");
        add("Čiastočná aktivácia – Home arm", "Stráži iba časť senzorov. Vhodné keď si vnútri a nechceš vnútorný PIR.", "1#2#");
        add("Deaktivovať alarm", "Vypne stráženie všetkých senzorov.", "1#0#");

        add("Zapnúť varovný tón pri vonkajšej aktivácii", "Pípnutie pri aktivácii vonkajšieho alarmu.", "21#1#");
        add("Vypnúť varovný tón pri vonkajšej aktivácii", "Vypnutie pípnutia pri aktivácii vonkajšieho alarmu.", "21#0#");
        add("Zapnúť varovný tón pri vnútornej aktivácii", "Pípnutie pri vnútornej/čiastočnej aktivácii.", "22#1#");
        add("Vypnúť varovný tón pri vnútornej aktivácii", "Vypnutie pípnutia pri vnútornej/čiastočnej aktivácii.", "22#0#");
        add("Zapnúť tón pri deaktivácii", "Pípnutie pri vypnutí alarmu.", "23#1#");
        add("Vypnúť tón pri deaktivácii", "Vypnutie pípnutia pri vypnutí alarmu.", "23#0#");

        add("Nastaviť zpoždenie alarmu 27", "Hodnota 00–99 podľa manuálu. Nepoužívať pre trvalé čidlá typu dym/SOS.", "27#%value%#", delay);
        add("Nastaviť zpoždenie alarmu 28", "Hodnota 00–99 podľa manuálu. Nepoužívať pre trvalé čidlá typu dym/SOS.", "28#%value%#", delay);

        add("Okamžite spustiť sirénu/zvuk", "Test alebo ručné spustenie zvuku.", "3#1#");
        add("Vypnúť sirénu/zvuk", "Zastaví okamžitý zvukový signál.", "3#0#");
        add("Aktivovať načúvanie", "Zapne odpočúvanie cez mikrofón alarmu.", "4#1#");
        add("Vypnúť načúvanie", "Vypne odpočúvanie.", "4#0#");

        add("Siréna pri poplachu ON", "Pri poplachu bude siréna húkať.", "11#1#");
        add("Siréna pri poplachu OFF", "Pri poplachu nebude siréna húkať.", "11#0#");
        add("SMS pri poplachu ON", "Alarm bude posielať SMS pri poplachu.", "12#1#");
        add("SMS pri poplachu OFF", "Alarm nebude posielať SMS pri poplachu.", "12#0#");
        add("Telefonovanie pri poplachu ON", "Alarm bude volať na uložené čísla.", "15#1#");
        add("Telefonovanie pri poplachu OFF", "Alarm nebude volať, iba spustí poplach.", "15#0#");
        add("Relé do 3 minút pri poplachu OFF", "Deaktivuje automatické zopnutie relé po poplachu.", "16#1#");
        add("Relé do 3 minút pri poplachu ON", "Aktivuje automatické zopnutie relé po poplachu.", "16#0#");

        add("Zobraziť stav zón", "Alarm odpovie stavom aktivácie/deaktivácie každej zóny. Iba SMS.", "30##");
        add("Zmeniť heslo", "Nové heslo má mať 1–6 číslic. Po zmene si ho ulož.", "31#%newpass%#", pass);
        add("Aktivovať konkrétnu zónu", "Bezdrôtové zóny 1–16, drôtové zóny 21–23.", "38#%zone%#", zone);
        add("Deaktivovať konkrétnu zónu", "Bezdrôtové zóny 1–16, drôtové zóny 21–23.", "39#%zone%#", zone);

        add("Zobraziť uložené telefónne čísla", "Vypíše Tel1 až Tel5. Iba SMS.", "50##");
        add("Nastaviť Tel1", "Prvé číslo pre SMS/hovory.", "51#%phone%#", phone);
        add("Nastaviť Tel2", "Druhé číslo pre SMS/hovory.", "52#%phone%#", phone);
        add("Nastaviť Tel3", "Tretie číslo pre SMS/hovory.", "53#%phone%#", phone);
        add("Nastaviť Tel4", "Štvrté číslo pre SMS/hovory.", "54#%phone%#", phone);
        add("Nastaviť Tel5", "Piate číslo pre SMS/hovory.", "55#%phone%#", phone);

        add("Zobraziť názvy SMS zón", "Vypíše aktuálne pomenovania správ 1 až 7. Iba SMS.", "80##");
        add("Pomenovať zónu 1", "SMS text pre prvý bezdrôtový senzor.", "81#%text%#", text);
        add("Pomenovať zónu 2", "SMS text pre druhý bezdrôtový senzor.", "82#%text%#", text);
        add("Pomenovať zónu 3", "SMS text pre tretí bezdrôtový senzor.", "83#%text%#", text);
        add("Pomenovať zónu 4", "SMS text pre štvrtý bezdrôtový senzor.", "84#%text%#", text);
        add("Pomenovať zónu 5", "SMS text pre piaty bezdrôtový senzor.", "85#%text%#", text);
        add("Pomenovať zóny 6–16", "Spoločný SMS text pre šiesty až šestnásty bezdrôtový senzor.", "86#%text%#", text);
        add("Pomenovať drôtové vstupy 1–3", "Spoločný SMS text pre drôtové porty I1, I2, I3.", "87#%text%#", text);

        add("Zobraziť stav výstupov", "Vypíše stav výstupov O1/O2/O3/relé. Iba SMS.", "90##");
        add("Výstup 1 na vysoko", "Nastaví O1 na vysokú úroveň.", "91#1#");
        add("Výstup 1 na nízko", "Nastaví O1 na nízku úroveň.", "91#0#");
        add("Výstup 2 na vysoko", "Nastaví O2 na vysokú úroveň.", "92#1#");
        add("Výstup 2 na nízko", "Nastaví O2 na nízku úroveň.", "92#0#");
        add("Povoliť hovor cez reproduktor O3", "Umožní hovoriť cez alarm/reproduktor.", "93#1#");
        add("Zakázať hovor cez reproduktor O3", "Vypne hovor cez alarm/reproduktor.", "93#0#");
        add("Relé prepojené", "Manuálne zopne relé.", "94#1#");
        add("Relé odpojené", "Manuálne rozopne relé.", "94#0#");
        add("Vstup 1: poplach pri otvorení", "Nastaví I1 tak, že poplach nastane pri otvorení vstupu.", "95#1#");
        add("Vstup 1: poplach pri uzemnení GND", "Nastaví I1 tak, že poplach nastane pri uzemnení.", "95#0#");
        add("Vstup 2: poplach pri otvorení", "Nastaví I2 tak, že poplach nastane pri otvorení vstupu.", "96#1#");
        add("Vstup 2: poplach pri uzemnení GND", "Nastaví I2 tak, že poplach nastane pri uzemnení.", "96#0#");
        add("Vstup 3: poplach pri otvorení", "Nastaví I3 tak, že poplach nastane pri otvorení vstupu.", "97#1#");
        add("Vstup 3: poplach pri uzemnení GND", "Nastaví I3 tak, že poplach nastane pri uzemnení.", "97#0#");
    }

    private void add(String title, String desc, String template, FieldSpec... fields) { commands.add(new CommandSpec(title, desc, template, fields)); }

    private void renderDynamicFields() {
        dynamicFields.removeAllViews();
        activeInputs.clear();
        CommandSpec spec = selectedCommand();
        helpText.setText(spec.description);
        for (FieldSpec f : spec.fields) {
            EditText e = input(f.label, f.hint, f.inputType);
            e.setTag(f);
            e.addTextChangedListener(new SimpleWatcher() { @Override public void afterTextChanged(Editable s) { updatePreview(); } });
            activeInputs.add(e);
            dynamicFields.addView(e);
        }
    }

    private CommandSpec selectedCommand() { return (CommandSpec) commandSpinner.getSelectedItem(); }

    private String buildCommand() {
        CommandSpec spec = selectedCommand();
        String cmd = spec.template;
        for (EditText e : activeInputs) {
            FieldSpec f = (FieldSpec) e.getTag();
            String value = e.getText().toString().trim();
            cmd = cmd.replace("%" + f.key + "%", value);
        }
        return passwordInput.getText().toString().trim() + "#" + cmd;
    }

    private String validateForm() {
        String alarmPhone = alarmPhoneInput.getText().toString().trim();
        if (alarmPhone.isEmpty()) return "Doplň telefónne číslo SIM v alarme.";
        String password = passwordInput.getText().toString().trim();
        if (password.isEmpty()) return "Doplň heslo alarmu.";
        if (password.length() > 6) return "Heslo podľa manuálu má mať najviac 6 znakov.";
        for (EditText e : activeInputs) {
            FieldSpec f = (FieldSpec) e.getTag();
            String value = e.getText().toString().trim();
            if (value.isEmpty()) return "Doplň pole: " + f.label;
            if ("value".equals(f.key)) {
                try { int v = Integer.parseInt(value); if (v < 0 || v > 99) return "Hodnota musí byť od 00 do 99."; } catch (Exception ex) { return "Hodnota musí byť číslo 00–99."; }
                if (value.length() == 1) e.setText("0" + value);
            }
            if ("zone".equals(f.key)) {
                try {
                    int z = Integer.parseInt(value);
                    boolean ok = (z >= 1 && z <= 16) || (z >= 21 && z <= 23);
                    if (!ok) return "Zóna musí byť 1–16 alebo 21–23.";
                } catch (Exception ex) { return "Zóna musí byť číslo."; }
            }
            if ("newpass".equals(f.key) && value.length() > 6) return "Nové heslo má mať najviac 6 číslic.";
            if (f.ascii24) {
                if (value.length() > 24) return "Text názvu zóny má mať max. 24 znakov.";
                for (int i = 0; i < value.length(); i++) if (value.charAt(i) > 127) return "Použi text bez diakritiky. Manuál uvádza anglickú abecedu.";
            }
        }
        return null;
    }

    private void updatePreview() {
        try {
            commandPreview.setText(buildCommand());
        } catch (Exception e) {
            commandPreview.setText("—");
        }
    }

    private void openSmsApp() {
        String err = validateForm();
        if (err != null) { toast(err); return; }
        String body = buildCommand();
        String phone = alarmPhoneInput.getText().toString().trim();
        try {
            String encoded = URLEncoder.encode(body, StandardCharsets.UTF_8.name());
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + Uri.encode(phone)));
            intent.putExtra("sms_body", body);
            startActivity(intent);
        } catch (Exception e) {
            toast("Nepodarilo sa otvoriť SMS aplikáciu: " + e.getMessage());
        }
    }

    private void sendDirectSms() {
        String err = validateForm();
        if (err != null) { toast(err); return; }
        pendingDirectSms = buildCommand();
        if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, REQ_SEND_SMS);
            return;
        }
        doSendDirect();
    }

    private void doSendDirect() {
        try {
            String phone = alarmPhoneInput.getText().toString().trim();
            SmsManager sms = SmsManager.getDefault();
            ArrayList<String> parts = sms.divideMessage(pendingDirectSms);
            sms.sendMultipartTextMessage(phone, null, parts, null, null);
            toast("SMS príkaz odoslaný.");
        } catch (Exception e) {
            toast("Priame odoslanie zlyhalo: " + e.getMessage());
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_SEND_SMS && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) doSendDirect();
        else toast("Bez povolenia SMS použij tlačidlo Otvoriť SMS aplikáciu.");
    }

    private void copyCommand() {
        String err = validateForm();
        if (err != null) { toast(err); return; }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Sonix SMS", buildCommand()));
        toast("Príkaz skopírovaný.");
    }

    private EditText input(String label, String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(label + " — " + hint);
        e.setInputType(type);
        e.setSingleLine(true);
        e.setPadding(0, dp(6), 0, dp(6));
        return e;
    }

    private TextView label(String s) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(14);
        v.setPadding(0, dp(10), 0, dp(2));
        return v;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void savePrefs() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString("alarmPhone", alarmPhoneInput.getText().toString().trim())
                .putString("password", passwordInput.getText().toString().trim())
                .apply();
    }

    private void loadPrefs() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        alarmPhoneInput.setText(p.getString("alarmPhone", "+421940166128"));
        passwordInput.setText(p.getString("password", "123456"));
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    abstract static class SimpleWatcher implements TextWatcher {
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) { }
    }
}
