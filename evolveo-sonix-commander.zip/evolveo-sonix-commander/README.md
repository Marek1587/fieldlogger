# EVOLVEO Sonix Commander

Jednoduchá Android aplikácia na programovanie GSM alarmu EVOLVEO Sonix cez SMS príkazy.

## Čo aplikácia vie

- uložiť číslo SIM karty v alarme,
- uložiť heslo alarmu,
- vybrať akciu zo zoznamu,
- zobraziť iba relevantné vstupy pre konkrétny príkaz,
- pripraviť SMS príkaz,
- otvoriť SMS aplikáciu s predvyplneným príkazom,
- voliteľne odoslať SMS priamo z aplikácie po udelení povolenia SEND_SMS,
- kopírovať príkaz do schránky.

## Prednastavené údaje

- číslo alarmu: `+421940166128`
- heslo: `123456`

Tieto údaje sa dajú zmeniť priamo v aplikácii.

## Obsiahnuté príkazy

Aplikácia obsahuje príkazy z manuálu EVOLVEO Sonix:

- aktivácia, čiastočná aktivácia, deaktivácia,
- varovné tóny 21/22/23,
- zpoždenie 27/28,
- okamžitý zvuk 3,
- načúvanie 4,
- siréna pri poplachu 11,
- SMS pri poplachu 12,
- telefonovanie pri poplachu 15,
- relé 16/94,
- stav zón 30,
- zmena hesla 31,
- aktivácia/deaktivácia zón 38/39,
- telefónne čísla Tel1–Tel5 cez 51–55,
- výpis čísel 50,
- výpis SMS názvov 80,
- pomenovanie správ 81–87,
- stav výstupov 90,
- výstupy 91/92/93,
- drôtové vstupy 95/96/97.

## Ako vygenerovať APK cez GitHub

1. Vytvor nový GitHub repozitár.
2. Rozbaľ ZIP a nahraj celý obsah do repozitára.
3. Choď do záložky **Actions**.
4. Spusti workflow **Build Android APK** cez **Run workflow**.
5. Po dokončení otvor posledný build a stiahni artefakt `sonix-commander-debug-apk`.
6. Vnútri bude súbor `app-debug.apk`.

## Poznámka k Androidu

Najspoľahlivejší režim je tlačidlo **Otvoriť SMS aplikáciu s pripraveným príkazom**, lebo Android pri priamom odosielaní SMS vyžaduje povolenie a niektoré telefóny alebo nadstavby môžu priame SMS obmedzovať.

Pri pomenovaní senzorov používaj radšej text bez diakritiky a max. 24 znakov, napríklad:

`Dvere karavanu otvorene`

## Manuálne buildovanie

Na počítači s Android SDK a Gradle:

```bash
gradle assembleDebug
```

APK sa vytvorí v:

```text
app/build/outputs/apk/debug/app-debug.apk
```
