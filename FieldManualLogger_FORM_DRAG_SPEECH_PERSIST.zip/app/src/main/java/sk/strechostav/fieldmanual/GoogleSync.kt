package sk.strechostav.fieldmanual

import android.content.Context
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GoogleSync {
    private const val PREF="field_manual_logger"
    private const val KEY_URL="google_script_url"
    fun url(context: Context): String = context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY_URL,"")?:""
    fun setUrl(context: Context, url: String){ context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY_URL,url.trim()).apply() }
    fun syncAsync(context: Context, entry: ManualLogEntry, callback:(Boolean,String)->Unit){
        val target=url(context); if(target.isBlank()){ callback(false,"Google URL nie je nastavené."); return }
        Thread{
            try{ val conn=URL(target).openConnection() as HttpURLConnection; conn.requestMethod="POST"; conn.connectTimeout=15000; conn.readTimeout=15000; conn.doOutput=true; conn.setRequestProperty("Content-Type","application/json; charset=utf-8"); OutputStreamWriter(conn.outputStream,Charsets.UTF_8).use{it.write(json(entry))}; val code=conn.responseCode; callback(code in 200..299,"HTTP $code"); conn.disconnect() }catch(e:Exception){ callback(false,e.message?:"sync error") }
        }.start()
    }
    private fun json(e:ManualLogEntry):String{ val fields=mapOf("timestamp" to e.timestamp,"event_type" to e.eventType,"lokalita" to e.lokalita,"miesto" to e.miesto,"lat" to e.lat,"lon" to e.lon,"accuracy_m" to e.accuracy,"provider" to e.provider,"title" to e.title,"note" to e.note,"photo_path" to e.photoPath); return fields.entries.joinToString(prefix="{",postfix="}"){"\""+esc(it.key)+"\":\""+esc(it.value)+"\""} }
    private fun esc(v:String):String = v.replace("\\","\\\\").replace("\"","\\\"").replace("\n"," ").replace("\r"," ")
}
