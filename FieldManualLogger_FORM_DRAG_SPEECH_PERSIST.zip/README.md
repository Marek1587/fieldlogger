# Field Manual Logger FORM + DRAG + SPEECH

- Required fields: Lokalita, Miesto, Poznámka
- Tile UI with emoji
- Drag and drop tile reorder by long press
- Speech-to-text dictation into note field
- Local XLSX
- Optional Google Sheets sync via Apps Script Web App

Use `docs/google_apps_script.gs` for Apps Script.
