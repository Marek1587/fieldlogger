(function (root) {
  "use strict";
  const TICKS_PER_MM = 100;

  function parseDimension(value, unit) {
    const normalized = String(value).trim().replace(/\s/g, "").replace(",", ".");
    const number = Number(normalized);
    if (!Number.isFinite(number)) return null;
    return Math.round(number * (unit === "cm" ? 1000 : TICKS_PER_MM));
  }

  function formatDimension(ticks, unit, withUnit) {
    const divider = unit === "cm" ? 1000 : TICKS_PER_MM;
    const value = ticks / divider;
    const text = new Intl.NumberFormat("sk-SK", { maximumFractionDigits: unit === "cm" ? 3 : 2 }).format(value);
    return withUnit === false ? text : text + " " + unit;
  }

  function validate(input) {
    const errors = [];
    if (!Number.isInteger(input.targetLength) || input.targetLength <= 0) errors.push("Cieľová dĺžka musí byť väčšia ako nula.");
    if (!Number.isInteger(input.nominalWidth) || input.nominalWidth <= 0) errors.push("Šírka dielu musí byť väčšia ako nula.");
    if ((input.fixedLeft || 0) < 0 || (input.fixedRight || 0) < 0) errors.push("Pevné kraje nemôžu byť záporné.");
    if ((input.fixedLeft || 0) + (input.fixedRight || 0) >= input.targetLength) errors.push("Pevné kraje musia byť spolu menšie než cieľová dĺžka.");
    if ((input.minCorrection || 0) < 0 || (input.maxCorrection || 0) < 0) errors.push("Tolerancia nemôže byť záporná.");
    return errors;
  }

  function calculateBasicLayout(input) {
    const errors = validate(input);
    if (!errors.length && input.nominalWidth > input.targetLength) errors.push("Šírka dielu nemôže byť väčšia než cieľová dĺžka.");
    if (errors.length) return { ok: false, errors: errors };
    const fullPieceCount = Math.floor(input.targetLength / input.nominalWidth);
    const remainder = input.targetLength - fullPieceCount * input.nominalWidth;
    const leftEdge = remainder / 2;
    const rightEdge = remainder - leftEdge;
    return { ok: true, targetLength: input.targetLength, nominalWidth: input.nominalWidth, fullPieceCount: fullPieceCount, remainder: remainder, leftEdge: leftEdge, rightEdge: rightEdge, achievedLength: leftEdge + fullPieceCount * input.nominalWidth + rightEdge };
  }

  function distributeCorrection(input) {
    const minSteps = Math.ceil(-input.minCorrection / input.step);
    const maxSteps = Math.floor(input.maxCorrection / input.step);
    const wantedSteps = Math.round(input.totalCorrection / input.step);
    const totalSteps = Math.max(input.pieceCount * minSteps, Math.min(input.pieceCount * maxSteps, wantedSteps));
    const base = Math.floor(totalSteps / input.pieceCount);
    const raised = totalSteps - base * input.pieceCount;
    return {
      corrections: Array.from({ length: input.pieceCount }, function (_, index) { return (index < raised ? base + 1 : base) * input.step; }),
      appliedCorrection: totalSteps * input.step
    };
  }

  function makeCandidate(input, pieceCount) {
    const nominalTotal = input.fixedLeft + input.fixedRight + pieceCount * input.nominalWidth;
    const requiredCorrection = input.targetLength - nominalTotal;
    const distribution = distributeCorrection({ pieceCount: pieceCount, totalCorrection: requiredCorrection, step: input.step, minCorrection: input.minCorrection, maxCorrection: input.maxCorrection });
    const pieces = distribution.corrections.map(function (correction, index) { return { index: index + 1, nominalWidth: input.nominalWidth, correction: correction, finalWidth: input.nominalWidth + correction }; });
    const achievedLength = nominalTotal + distribution.appliedCorrection;
    return { targetLength: input.targetLength, nominalWidth: input.nominalWidth, pieceCount: pieceCount, fixedLeft: input.fixedLeft, fixedRight: input.fixedRight, nominalTotal: nominalTotal, requiredCorrection: requiredCorrection, correctionPerPiece: requiredCorrection / pieceCount, pieces: pieces, achievedLength: achievedLength, residualError: achievedLength - input.targetLength, exact: achievedLength === input.targetLength, appliedCorrection: distribution.appliedCorrection, averageCorrection: Math.abs(distribution.appliedCorrection / pieceCount) };
  }

  function solveCorrection(input) {
    const errors = validate(input);
    if (!Number.isInteger(input.step) || input.step <= 0) errors.push("Krok korekcie musí byť väčší ako nula.");
    if (errors.length) return { ok: false, errors: errors };
    const available = input.targetLength - input.fixedLeft - input.fixedRight;
    const minimumWidth = Math.max(1, input.nominalWidth - input.minCorrection);
    const maxCount = Math.min(500, Math.max(1, Math.ceil(available / minimumWidth) + 2));
    const counts = input.pieceCount ? [input.pieceCount] : Array.from({ length: maxCount }, function (_, index) { return index + 1; });
    const candidates = counts.map(function (count) { return makeCandidate(input, count); });
    candidates.sort(function (a, b) { return Math.abs(a.residualError) - Math.abs(b.residualError) || a.averageCorrection - b.averageCorrection || Math.abs(a.pieceCount - available / input.nominalWidth) - Math.abs(b.pieceCount - available / input.nominalWidth); });
    const best = candidates[0];
    best.ok = true;
    best.minimumTolerance = Math.abs(best.requiredCorrection / best.pieceCount);
    return best;
  }

  function groupPieces(pieces) {
    const map = new Map();
    pieces.forEach(function (piece) {
      const key = piece.finalWidth + ":" + piece.correction;
      const group = map.get(key) || { count: 0, finalWidth: piece.finalWidth, correction: piece.correction };
      group.count += 1;
      map.set(key, group);
    });
    return Array.from(map.values()).sort(function (a, b) { return b.correction - a.correction; });
  }

  const api = { TICKS_PER_MM: TICKS_PER_MM, parseDimension: parseDimension, formatDimension: formatDimension, calculateBasicLayout: calculateBasicLayout, distributeCorrection: distributeCorrection, solveCorrection: solveCorrection, groupPieces: groupPieces };
  root.GeometrySolver = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
