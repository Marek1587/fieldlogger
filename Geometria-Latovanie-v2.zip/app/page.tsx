import GeometryApp from "./GeometryApp";

export default function Home() {
  return <GeometryApp />;
}
