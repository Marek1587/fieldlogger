"use client";

import { useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";
import {
  TICKS_PER_MM,
  calculateBasicLayout,
  formatDimension,
  groupPieces,
  parseDimension,
  solveCorrection,
} from "./lib/geometry-solver.mjs";

type Unit = "mm" | "cm";

function Field({ label, value, onChange, unit, hint, onWheel }: { label: string; value: string; onChange: (value: string) => void; unit: string; hint?: string; onWheel?: () => void }) {
  return (
    <label className="field">
      <span>{label}</span>
      <div className="input-wrap">
        <input inputMode="decimal" value={value} onChange={(event) => onChange(event.target.value)} aria-label={label} />
        {onWheel && <button type="button" className="field-wheel" onClick={onWheel} aria-label={`Nastaviť ${label} kolieskom`} title="Nastaviť kolieskom"><i /></button>}
        <b>{unit}</b>
      </div>
      {hint && <small>{hint}</small>}
    </label>
  );
}

function Stat({ label, value, accent = false }: { label: string; value: string; accent?: boolean }) {
  return <div className={`stat ${accent ? "accent" : ""}`}><span>{label}</span><strong>{value}</strong></div>;
}

function DimensionChain({ result, unit, expanded, onToggle }: { result: any; unit: Unit; expanded: boolean; onToggle: () => void }) {
  const n = result.fullPieceCount;
  const compact = !expanded && n > 5;
  const pieces = compact ? [0, 1, -1, n - 1] : Array.from({ length: n }, (_, i) => i);
  const drawingWidth = compact ? 900 : Math.max(900, 280 + n * 105);
  const rightEdgeX = drawingWidth - 140;
  return (
    <button className="drawing" onClick={onToggle} aria-label="Rozbaliť alebo zbaliť nákres">
      <div className="drawing-head"><span>ROZMEROVÝ REŤAZEC</span><span>{compact ? "Rozbaliť všetky diely" : n > 5 ? "Zbaliť nákres" : "Schematický nákres"} ↗</span></div>
      <svg viewBox={`0 0 ${drawingWidth} 210`} style={{ width: drawingWidth }} role="img" aria-label="Schematické rozdelenie cieľovej dĺžky">
        <defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="3.5" refY="3.5" orient="auto"><path d="M7,0 L0,3.5 L7,7" fill="none" stroke="currentColor" /></marker></defs>
        <line x1="35" y1="175" x2={drawingWidth - 35} y2="175" className="dim-line" markerStart="url(#arrow)" markerEnd="url(#arrow)" />
        <text x={drawingWidth / 2} y="203" textAnchor="middle" className="total-label">CELKOM {formatDimension(result.targetLength, unit)}</text>
        <rect x="35" y="55" width="105" height="82" rx="8" className="edge-piece" />
        <text x="87" y="88" textAnchor="middle" className="piece-tag">ĽAVÝ KRAJ</text>
        <text x="87" y="114" textAnchor="middle" className="piece-value">{formatDimension(result.leftEdge, unit, false)}</text>
        {pieces.map((pieceIndex, index) => {
          if (pieceIndex === -1) return <g key={`ellipsis-${index}`}><text x={310 + index * 105} y="102" textAnchor="middle" className="ellipsis">··· {n}× ···</text></g>;
          const x = 153 + index * 105;
          return <g key={`${pieceIndex}-${index}`}><rect x={x} y="42" width="92" height="95" rx="8" className="mid-piece" /><text x={x + 46} y="78" textAnchor="middle" className="piece-tag">DIEL {pieceIndex + 1}</text><text x={x + 46} y="108" textAnchor="middle" className="piece-value">{formatDimension(result.nominalWidth, unit, false)}</text></g>;
        })}
        <rect x={rightEdgeX} y="55" width="105" height="82" rx="8" className="edge-piece" />
        <text x={rightEdgeX + 52} y="88" textAnchor="middle" className="piece-tag">PRAVÝ KRAJ</text>
        <text x={rightEdgeX + 52} y="114" textAnchor="middle" className="piece-value">{formatDimension(result.rightEdge, unit, false)}</text>
      </svg>
    </button>
  );
}

function CorrectionDrawing({ result, unit }: { result: any; unit: Unit }) {
  const groups = groupPieces(result.pieces);
  return (
    <div className="drawing correction-drawing">
      <div className="drawing-head"><span>KOREKČNÝ PLÁN</span><span className={result.exact ? "status-good" : "status-warn"}>{result.exact ? "● PRESNE NA CIELI" : "● NAJBLIŽŠIE RIEŠENIE"}</span></div>
      <div className="chain-row original"><b>PÔVODNÉ</b><div className="locked">⌑ {formatDimension(result.fixedLeft, unit, false)}</div><div className="chain-fill">{result.pieceCount}× {formatDimension(result.nominalWidth, unit)}</div><div className="locked">{formatDimension(result.fixedRight, unit, false)} ⌑</div></div>
      <div className="chain-row adjusted"><b>UPRAVENÉ</b><div className="locked">⌑ {formatDimension(result.fixedLeft, unit, false)}</div>{groups.map((group: any) => <div className={`chain-fill ${group.correction > 0 ? "plus" : group.correction < 0 ? "minus" : "zero"}`} key={`${group.finalWidth}-${group.correction}`}><strong>{group.count}× {formatDimension(group.finalWidth, unit)}</strong><small>{group.correction === 0 ? "bez zmeny" : `${group.correction > 0 ? "+" : ""}${formatDimension(group.correction, "mm")}`}</small></div>)}<div className="locked">{formatDimension(result.fixedRight, unit, false)} ⌑</div></div>
      <div className="dimension-rule"><span>←</span><b>CELKOM {formatDimension(result.achievedLength, unit)}</b><span>→</span></div>
    </div>
  );
}

export default function GeometryApp() {
  const [mode, setMode] = useState<"basic" | "correction">("basic");
  const [unit, setUnit] = useState<Unit>("cm");
  const [target, setTarget] = useState("655");
  const [width, setWidth] = useState("55,9");
  const [expanded, setExpanded] = useState(false);
  const [settings, setSettings] = useState(false);
  const [highContrast, setHighContrast] = useState(false);
  const [compact, setCompact] = useState(false);
  const [correctionTarget, setCorrectionTarget] = useState("656");
  const [fixedLeft, setFixedLeft] = useState("20,05");
  const [fixedRight, setFixedRight] = useState("20,05");
  const [tolerance, setTolerance] = useState("10");
  const [step, setStep] = useState("1");
  const [lockedCount, setLockedCount] = useState<number | undefined>(11);
  const [copied, setCopied] = useState(false);
  const [wheel, setWheel] = useState<{ title: string; apply: (ticks: number) => void } | null>(null);
  const [wheelValue, setWheelValue] = useState(0);
  const [wheelStep, setWheelStep] = useState(TICKS_PER_MM);
  const wheelDrag = useRef<{ pointerId: number; lastAngle: number; remainder: number } | null>(null);

  const basic = useMemo<any>(() => {
    const targetLength = parseDimension(target, unit);
    const nominalWidth = parseDimension(width, unit);
    if (targetLength === null || nominalWidth === null) return { ok: false, errors: ["Zadajte platné rozmery."] };
    return calculateBasicLayout({ targetLength, nominalWidth });
  }, [target, width, unit]);

  const correction = useMemo<any>(() => {
    const values = {
      targetLength: parseDimension(correctionTarget, unit),
      nominalWidth: parseDimension(width, unit),
      fixedLeft: parseDimension(fixedLeft, unit),
      fixedRight: parseDimension(fixedRight, unit),
      minCorrection: parseDimension(tolerance, "mm"),
      maxCorrection: parseDimension(tolerance, "mm"),
      step: parseDimension(step, "mm"),
    };
    if (Object.values(values).some((value) => value === null)) return { ok: false, errors: ["Zadajte platné rozmery."] };
    return solveCorrection({ ...values, pieceCount: lockedCount }) as any;
  }, [correctionTarget, width, fixedLeft, fixedRight, tolerance, step, unit, lockedCount]);

  const transfer = () => {
    if (!basic.ok) return;
    setFixedLeft(formatDimension(basic.leftEdge, unit, false));
    setFixedRight(formatDimension(basic.rightEdge, unit, false));
    setCorrectionTarget(formatDimension(basic.targetLength, unit, false));
    setLockedCount(basic.fullPieceCount);
    setMode("correction");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const mountingText = correction.ok
    ? [`ROZMERY NA MONTÁŽ`, `Ľavý kraj: ${formatDimension(correction.fixedLeft, unit)} – BEZ ZMENY`, ...groupPieces(correction.pieces).map((g: any) => `${g.count}× diel: ${formatDimension(g.finalWidth, unit)}`), `Pravý kraj: ${formatDimension(correction.fixedRight, unit)} – BEZ ZMENY`, `Celkom: ${formatDimension(correction.achievedLength, unit)}`].join("\n")
    : "";

  const copyMounting = async (text: string) => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const changeUnit = (nextUnit: Unit) => {
    if (nextUnit === unit) return;
    const convert = (value: string) => {
      const ticks = parseDimension(value, unit);
      return ticks === null ? value : formatDimension(ticks, nextUnit, false);
    };
    setTarget(convert(target));
    setWidth(convert(width));
    setCorrectionTarget(convert(correctionTarget));
    setFixedLeft(convert(fixedLeft));
    setFixedRight(convert(fixedRight));
    setUnit(nextUnit);
  };

  const openWheel = (title: string, currentValue: string, fieldUnit: Unit, applyValue: (value: string) => void) => {
    const ticks = parseDimension(currentValue, fieldUnit);
    if (ticks === null) return;
    setWheelValue(ticks);
    setWheel({ title, apply: (nextTicks) => applyValue(formatDimension(nextTicks, fieldUnit, false)) });
  };

  const wheelPointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    const box = event.currentTarget.getBoundingClientRect();
    const angle = Math.atan2(event.clientY - (box.top + box.height / 2), event.clientX - (box.left + box.width / 2)) * 180 / Math.PI;
    wheelDrag.current = { pointerId: event.pointerId, lastAngle: angle, remainder: 0 };
    event.currentTarget.setPointerCapture(event.pointerId);
    event.preventDefault();
  };

  const wheelPointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const drag = wheelDrag.current;
    if (!drag || drag.pointerId !== event.pointerId) return;
    const box = event.currentTarget.getBoundingClientRect();
    const angle = Math.atan2(event.clientY - (box.top + box.height / 2), event.clientX - (box.left + box.width / 2)) * 180 / Math.PI;
    let delta = angle - drag.lastAngle;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    drag.lastAngle = angle;
    drag.remainder += delta;
    const steps = Math.trunc(drag.remainder / 4);
    if (steps) {
      setWheelValue((value) => value + steps * wheelStep);
      drag.remainder -= steps * 4;
    }
    event.preventDefault();
  };

  const wheelStyle = { "--dial-angle": `${((wheelValue / wheelStep * 8) % 360 + 360) % 360}deg` } as CSSProperties;

  return (
    <main className={`${highContrast ? "high-contrast" : ""} ${compact ? "compact" : ""}`}>
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Geometria domov"><span className="brand-mark">G</span><span><b>GEOMETRIA</b><small>ROZMEROVÝ SOLVER</small></span></a>
        <div className="top-steps" aria-label="Pracovný postup"><button className={mode === "basic" ? "on" : ""} onClick={() => setMode("basic")}><b>1</b><span>Zadať rozmery</span></button><i /><button className={mode === "correction" ? "on" : ""} onClick={() => setMode("correction")}><b>2</b><span>Doladiť diely</span></button></div>
        <div className="top-actions"><span className="precision">● PRESNOSŤ 0,01 MM</span><button className="settings-button" onClick={() => setSettings(!settings)} aria-label="Nastavenia">⚙</button></div>
      </header>

      {wheel && <div className="wheel-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setWheel(null); }}><section className="wheel-dialog" role="dialog" aria-modal="true" aria-labelledby="wheel-title"><button className="wheel-close" onClick={() => setWheel(null)} aria-label="Zavrieť">×</button><p>NASTAVENIE ROZMERU</p><h3 id="wheel-title">{wheel.title}</h3><div className="wheel-value"><span>{formatDimension(wheelValue, "mm", false)}</span> <small>mm</small></div><div className="rotary" style={wheelStyle} role="slider" tabIndex={0} aria-label="Rozmer v milimetroch" aria-valuenow={wheelValue / TICKS_PER_MM} aria-valuetext={formatDimension(wheelValue, "mm")} onPointerDown={wheelPointerDown} onPointerMove={wheelPointerMove} onPointerUp={() => { wheelDrag.current = null; }} onPointerCancel={() => { wheelDrag.current = null; }} onKeyDown={(event) => { if (["ArrowUp", "ArrowRight"].includes(event.key)) { setWheelValue((value) => value + wheelStep); event.preventDefault(); } if (["ArrowDown", "ArrowLeft"].includes(event.key)) { setWheelValue((value) => value - wheelStep); event.preventDefault(); } }}><span>ŤAHAJTE</span></div><div className="wheel-step"><span>Krok kolieska</span><div>{[[10, "0,1"], [50, "0,5"], [100, "1"], [500, "5"]].map(([ticks, label]) => <button key={ticks} className={wheelStep === ticks ? "active" : ""} onClick={() => setWheelStep(Number(ticks))}>{label} mm</button>)}</div></div><div className="wheel-hint">Otáčajte bez obmedzenia alebo použite šípky na klávesnici.</div><div className="wheel-actions"><button onClick={() => setWheel(null)}>Zrušiť</button><button className="apply" disabled={wheelValue <= 0} onClick={() => { if (wheelValue <= 0) return; wheel.apply(wheelValue); setWheel(null); }}>Použiť rozmer</button></div></section></div>}

      {settings && <aside className="settings-panel"><div className="panel-title"><div><small>NASTAVENIA</small><h3>Zobrazenie</h3></div><button onClick={() => setSettings(false)}>×</button></div><div className="setting-row"><span><b>Vysoký kontrast</b><small>Čitateľnejšie na priamom slnku</small></span><button className={`toggle ${highContrast ? "on" : ""}`} onClick={() => setHighContrast(!highContrast)}><i /></button></div><div className="setting-row"><span><b>Kompaktný režim</b><small>Viac údajov na jednej obrazovke</small></span><button className={`toggle ${compact ? "on" : ""}`} onClick={() => setCompact(!compact)}><i /></button></div><div className="settings-unit"><span>Predvolená jednotka</span><div><button className={unit === "mm" ? "active" : ""} onClick={() => changeUnit("mm")}>mm</button><button className={unit === "cm" ? "active" : ""} onClick={() => changeUnit("cm")}>cm</button></div></div></aside>}

      <section className="hero" id="top"><div><p className="eyebrow">PRESNÉ DELENIE · PRIAMO NA STAVBE</p><h1>Rozmer sedí.<br /><em>Na prvý pokus.</em></h1><p>Zadajte cieľ a šírku dielu. Dostanete presný počet, kraje aj kontrolný výpočet bez ručného počítania.</p></div><div className="hero-badge"><span>01</span><small>REŽIM</small><b>{mode === "basic" ? "ROZDELENIE" : "KOREKCIA"}</b></div></section>

      <nav className="tabs" aria-label="Režimy aplikácie"><button className={mode === "basic" ? "active" : ""} onClick={() => setMode("basic")}><span>01</span><b>ROZDELENIE</b><small>Celé diely a symetrické kraje</small></button><button className={mode === "correction" ? "active" : ""} onClick={() => setMode("correction")}><span>02</span><b>KOREKCIA</b><small>Jemná úprava šírky dielov</small></button></nav>

      {mode === "basic" ? <section className="workspace">
        <aside className="input-card"><div className="section-label"><span>01</span><div><small>VSTUPNÉ ÚDAJE</small><h2>Čo potrebujete rozdeliť?</h2></div></div><div className="unit-switch"><button className={unit === "mm" ? "active" : ""} onClick={() => changeUnit("mm")}>MILIMETRE</button><button className={unit === "cm" ? "active" : ""} onClick={() => changeUnit("cm")}>CENTIMETRE</button></div><Field label="Cieľová dĺžka" value={target} onChange={setTarget} unit={unit} hint="Celková dĺžka priestoru" onWheel={() => openWheel("Cieľová dĺžka", target, unit, setTarget)} /><Field label="Šírka jedného dielu" value={width} onChange={setWidth} unit={unit} hint="Nominálny rozmer opakovaného dielu" onWheel={() => openWheel("Šírka jedného dielu", width, unit, setWidth)} /><div className="wheel-note"><i /><span><b>Rozmery nastavíte aj kolieskom</b><small>Ťuknite na zelené koliesko vo vstupnom poli.</small></span></div><div className="live-note"><i>✓</i><span><b>Výpočet je automatický</b><small>Výsledok sa prepočíta pri každej zmene.</small></span></div></aside>
        <div className="results">
          {basic.ok ? <><div className="results-head"><div><small>VÝSLEDOK ROZDELENIA</small><h2>{basic.fullPieceCount} celých dielov</h2></div><span className="exact-badge">✓ PRESNÝ SÚČET</span></div><div className="stats-grid"><Stat label="POČET CELÝCH DIELOV" value={`${basic.fullPieceCount} ks`} accent /><Stat label="ŠÍRKA DIELU" value={formatDimension(basic.nominalWidth, unit)} /><Stat label="ĽAVÝ KRAJ" value={formatDimension(basic.leftEdge, unit)} /><Stat label="PRAVÝ KRAJ" value={formatDimension(basic.rightEdge, unit)} /></div><div className="checkline"><span>✓</span><div><small>KONTROLNÝ SÚČET</small><b>{formatDimension(basic.leftEdge, unit, false)} + {basic.fullPieceCount} × {formatDimension(basic.nominalWidth, unit, false)} + {formatDimension(basic.rightEdge, unit, false)} = {formatDimension(basic.achievedLength, unit)}</b></div></div><DimensionChain result={basic} unit={unit} expanded={expanded} onToggle={() => setExpanded(!expanded)} /><div className="details-grid"><details open><summary>Ako sme sa dostali k výsledku <span>⌄</span></summary><ol><li><span>01</span><p><small>POČET CELÝCH DIELOV</small><b>{formatDimension(basic.targetLength, unit, false)} ÷ {formatDimension(basic.nominalWidth, unit, false)} = {(basic.targetLength / basic.nominalWidth).toLocaleString("sk-SK", { maximumFractionDigits: 6 })}</b><em>Celá časť = {basic.fullPieceCount} dielov</em></p></li><li><span>02</span><p><small>POUŽITÁ DĹŽKA</small><b>{basic.fullPieceCount} × {formatDimension(basic.nominalWidth, unit, false)} = {formatDimension(basic.fullPieceCount * basic.nominalWidth, unit)}</b></p></li><li><span>03</span><p><small>ZVYŠOK A KRAJE</small><b>{formatDimension(basic.targetLength, unit, false)} − {formatDimension(basic.fullPieceCount * basic.nominalWidth, unit, false)} = {formatDimension(basic.remainder, unit)}</b><em>{formatDimension(basic.remainder, unit, false)} ÷ 2 = {formatDimension(basic.leftEdge, unit)}</em></p></li></ol><div className="formula">n = ⌊L / a⌋ &nbsp;&nbsp; y = (L − n × a) / 2</div></details><div className="mounting"><small>VÝSTUP PRE PRACOVNÍKA</small><h3>ROZMERY NA MONTÁŽ</h3><div><p>Ľavý kraj <b>{formatDimension(basic.leftEdge, unit)}</b></p><p>{basic.fullPieceCount}× diel <b>{formatDimension(basic.nominalWidth, unit)}</b></p><p>Pravý kraj <b>{formatDimension(basic.rightEdge, unit)}</b></p><p className="total">CELKOM <b>{formatDimension(basic.achievedLength, unit)}</b></p></div><button onClick={() => copyMounting(`ROZMERY NA MONTÁŽ\nĽavý kraj: ${formatDimension(basic.leftEdge, unit)}\n${basic.fullPieceCount}× diel: ${formatDimension(basic.nominalWidth, unit)}\nPravý kraj: ${formatDimension(basic.rightEdge, unit)}\nCelkom: ${formatDimension(basic.achievedLength, unit)}`)}>{copied ? "✓ SKOPÍROVANÉ" : "▣ SKOPÍROVAŤ ROZMERY"}</button></div></div><button className="transfer" onClick={transfer}><span><small>ĎALŠÍ KROK</small><b>Potrebujete rozmery jemne doladiť?</b></span><strong>POUŽIŤ V KOREKCII →</strong></button></> : <div className="error-card"><b>Skontrolujte vstupy</b>{basic.errors.map((error: string) => <p key={error}>{error}</p>)}</div>}
        </div>
      </section> : <section className="workspace correction-workspace">
        <aside className="input-card"><div className="section-label"><span>02</span><div><small>VSTUPNÉ ÚDAJE</small><h2>Korekcia rozdelenia</h2></div></div><div className="unit-switch"><button className={unit === "mm" ? "active" : ""} onClick={() => changeUnit("mm")}>MILIMETRE</button><button className={unit === "cm" ? "active" : ""} onClick={() => changeUnit("cm")}>CENTIMETRE</button></div><Field label="Nová cieľová dĺžka" value={correctionTarget} onChange={setCorrectionTarget} unit={unit} onWheel={() => openWheel("Nová cieľová dĺžka", correctionTarget, unit, setCorrectionTarget)} /><Field label="Nominálna šírka dielu" value={width} onChange={setWidth} unit={unit} onWheel={() => openWheel("Nominálna šírka dielu", width, unit, setWidth)} /><div className="two-fields"><Field label="Ľavý pevný kraj" value={fixedLeft} onChange={setFixedLeft} unit={unit} onWheel={() => openWheel("Ľavý pevný kraj", fixedLeft, unit, setFixedLeft)} /><Field label="Pravý pevný kraj" value={fixedRight} onChange={setFixedRight} unit={unit} onWheel={() => openWheel("Pravý pevný kraj", fixedRight, unit, setFixedRight)} /></div><div className="lock-note">⌑ Pevné kraje solver nikdy nemení</div><Field label="Max. korekcia jedného dielu ±" value={tolerance} onChange={setTolerance} unit="mm" onWheel={() => openWheel("Maximálna korekcia", tolerance, "mm", setTolerance)} /><label className="select-field"><span>Krok korekcie</span><select value={step} onChange={(event) => setStep(event.target.value)}><option value="0,1">0,1 mm</option><option value="0,5">0,5 mm</option><option value="1">1 mm</option></select></label><label className="auto-count"><input type="checkbox" checked={!lockedCount} onChange={(event) => setLockedCount(event.target.checked ? undefined : basic.ok ? basic.fullPieceCount : 11)} /><span><b>Počet dielov hľadať automaticky</b><small>{lockedCount ? `Aktuálne uzamknuté: ${lockedCount} ks` : "Solver vyberie najlepší počet"}</small></span></label></aside>
        <div className="results">{correction.ok ? <><div className="results-head"><div><small>OPTIMÁLNE RIEŠENIE</small><h2>{correction.pieceCount} dielov · {correction.requiredCorrection >= 0 ? "rozšíriť" : "zúžiť"}</h2></div><span className={correction.exact ? "exact-badge" : "near-badge"}>{correction.exact ? "✓ CIEĽ DOSIAHNUTÝ" : `ROZDIEL ${formatDimension(correction.residualError, "mm")}`}</span></div><div className="stats-grid correction-stats"><Stat label="POČET VNÚTORNÝCH DIELOV" value={`${correction.pieceCount} ks`} accent /><Stat label="POTREBNÁ KOREKCIA" value={`${correction.requiredCorrection > 0 ? "+" : ""}${formatDimension(correction.requiredCorrection, "mm")}`} /><Stat label="PÔVODNÁ DĹŽKA" value={formatDimension(correction.nominalTotal, unit)} /><Stat label="DOSIAHNUTÁ DĹŽKA" value={formatDimension(correction.achievedLength, unit)} /></div><CorrectionDrawing result={correction} unit={unit} /><div className="details-grid"><details open><summary>Výpočet korekcie <span>⌄</span></summary><ol><li><span>01</span><p><small>PEVNÉ KRAJE</small><b>{formatDimension(correction.fixedLeft, unit, false)} + {formatDimension(correction.fixedRight, unit, false)} = {formatDimension(correction.fixedLeft + correction.fixedRight, unit)}</b></p></li><li><span>02</span><p><small>NOMINÁLNA DĹŽKA</small><b>{correction.pieceCount} × {formatDimension(correction.nominalWidth, unit, false)} = {formatDimension(correction.pieceCount * correction.nominalWidth, unit)}</b><em>S krajmi: {formatDimension(correction.nominalTotal, unit)}</em></p></li><li><span>03</span><p><small>POTREBNÁ KOREKCIA</small><b>{formatDimension(correction.targetLength, unit, false)} − {formatDimension(correction.nominalTotal, unit, false)} = {correction.requiredCorrection > 0 ? "+" : ""}{formatDimension(correction.requiredCorrection, unit)}</b><em>Ideálne {formatDimension(correction.correctionPerPiece, "mm")} / diel</em></p></li><li><span>04</span><p><small>ROZDELENIE PO KROKOCH</small>{groupPieces(correction.pieces).map((g: any) => <b key={g.correction}>{g.count} ks × {g.correction > 0 ? "+" : ""}{formatDimension(g.correction, "mm")}</b>)}</p></li></ol><div className={`formula ${correction.exact ? "success" : "warning"}`}>{correction.exact ? `✓ Kontrola sedí presne: ${formatDimension(correction.achievedLength, unit)}` : `Najbližší rozmer: ${formatDimension(correction.achievedLength, unit)} · minimálna potrebná tolerancia ${formatDimension(correction.minimumTolerance, "mm")}`}</div></details><div className="mounting"><small>VÝSTUP PRE PRACOVNÍKA</small><h3>ROZMERY NA MONTÁŽ</h3><div><p>Ľavý kraj <b>{formatDimension(correction.fixedLeft, unit)} · BEZ ZMENY</b></p>{groupPieces(correction.pieces).map((g: any) => <p key={g.finalWidth}>{g.count}× diel <b>{formatDimension(g.finalWidth, unit)}</b></p>)}<p>Pravý kraj <b>{formatDimension(correction.fixedRight, unit)} · BEZ ZMENY</b></p><p className="total">CELKOM <b>{formatDimension(correction.achievedLength, unit)}</b></p></div><button onClick={() => copyMounting(mountingText)}>{copied ? "✓ SKOPÍROVANÉ" : "▣ SKOPÍROVAŤ ROZMERY"}</button></div></div></> : <div className="error-card"><b>Skontrolujte vstupy</b>{correction.errors.map((error: string) => <p key={error}>{error}</p>)}</div>}</div>
      </section>}
      <footer><b>GEOMETRIA</b><span>Presný rozmerový solver pre prácu v teréne.</span><small>Výpočty používajú presnú celočíselnú aritmetiku.</small></footer>
    </main>
  );
}
