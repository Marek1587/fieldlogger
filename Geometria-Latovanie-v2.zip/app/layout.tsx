import type { Metadata } from "next";
import { Manrope, Space_Mono } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const manrope = Manrope({ variable: "--font-manrope", subsets: ["latin", "latin-ext"] });
const spaceMono = Space_Mono({ variable: "--font-space", weight: ["400", "700"], subsets: ["latin"] });

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const base = new URL(`${protocol}://${host}`);
  return {
    metadataBase: base,
    title: "Geometria – rozmerový solver",
    description: "Presné rozdelenie cieľovej dĺžky a korekcia dielov pre prácu na stavbe.",
    openGraph: {
      title: "Geometria – rozmerový solver",
      description: "Presný rozmer. Na prvý pokus.",
      images: [{ url: new URL("/og.png", base).toString(), width: 1536, height: 1024, alt: "Geometria – presný stavebný rozmerový solver" }],
    },
    twitter: { card: "summary_large_image", title: "Geometria", description: "Presný rozmer. Na prvý pokus.", images: [new URL("/og.png", base).toString()] },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="sk"><body className={`${manrope.variable} ${spaceMono.variable}`}>{children}</body></html>;
}
