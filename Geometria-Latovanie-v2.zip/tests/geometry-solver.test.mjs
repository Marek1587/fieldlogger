import assert from "node:assert/strict";
import test from "node:test";
import { TICKS_PER_MM, calculateBasicLayout, parseDimension, solveCorrection } from "../app/lib/geometry-solver.mjs";

test("TEST 1: rozdelí 655 cm na 11 dielov a symetrické kraje", () => {
  const result = calculateBasicLayout({ targetLength: parseDimension("655", "cm"), nominalWidth: parseDimension("55,9", "cm") });
  assert.equal(result.ok, true);
  assert.equal(result.fullPieceCount, 11);
  assert.equal(result.remainder, parseDimension("40,1", "cm"));
  assert.equal(result.leftEdge, parseDimension("20,05", "cm"));
  assert.equal(result.rightEdge, parseDimension("20,05", "cm"));
});

test("TEST 2: rozdelí +10 mm medzi 11 dielov po 1 mm", () => {
  const result = solveCorrection({ targetLength: 6560 * TICKS_PER_MM, nominalWidth: 559 * TICKS_PER_MM, fixedLeft: 200.5 * TICKS_PER_MM, fixedRight: 200.5 * TICKS_PER_MM, minCorrection: 10 * TICKS_PER_MM, maxCorrection: 10 * TICKS_PER_MM, step: TICKS_PER_MM, pieceCount: 11 });
  assert.equal(result.nominalTotal, 6550 * TICKS_PER_MM);
  assert.equal(result.requiredCorrection, 10 * TICKS_PER_MM);
  assert.equal(result.pieces.filter((piece) => piece.correction === TICKS_PER_MM).length, 10);
  assert.equal(result.pieces.filter((piece) => piece.correction === 0).length, 1);
  assert.equal(result.achievedLength, 6560 * TICKS_PER_MM);
  assert.equal(result.residualError, 0);
});

test("TEST 3: rozdelí -20 mm medzi 11 dielov po 1 mm", () => {
  const result = solveCorrection({ targetLength: 6530 * TICKS_PER_MM, nominalWidth: 559 * TICKS_PER_MM, fixedLeft: 200.5 * TICKS_PER_MM, fixedRight: 200.5 * TICKS_PER_MM, minCorrection: 10 * TICKS_PER_MM, maxCorrection: 10 * TICKS_PER_MM, step: TICKS_PER_MM, pieceCount: 11 });
  assert.equal(result.requiredCorrection, -20 * TICKS_PER_MM);
  assert.equal(result.pieces.filter((piece) => piece.correction === -2 * TICKS_PER_MM).length, 9);
  assert.equal(result.pieces.filter((piece) => piece.correction === -TICKS_PER_MM).length, 2);
  assert.equal(result.achievedLength, 6530 * TICKS_PER_MM);
  assert.equal(result.residualError, 0);
});
