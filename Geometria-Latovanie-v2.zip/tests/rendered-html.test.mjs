import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(new Request("http://localhost/", { headers: { accept: "text/html" } }), { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } }, { waitUntil() {}, passThroughOnException() {} });
}

test("server renders Geometria application shell", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  const html = await response.text();
  assert.match(html, /<title>Geometria – rozmerový solver<\/title>/i);
  assert.match(html, /GEOMETRIA/);
  assert.match(html, /ROZDELENIE/);
  assert.match(html, /KOREKCIA/);
  assert.match(html, /Nastaviť Cieľová dĺžka kolieskom/);
  assert.doesNotMatch(html, /codex-preview/);
});
