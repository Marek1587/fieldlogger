# Geometria 1.0.0

Kompletná offline Android aplikácia na presné rozdelenie cieľovej dĺžky na opakované diely a korekciu ich šírky.

## Funkcie

- rozdelenie dĺžky na celé diely a symetrické kraje,
- automatické hľadanie optimálneho počtu dielov,
- korekcia šírky s toleranciou a krokom 0,1 / 0,5 / 1 mm,
- presná celočíselná aritmetika s interným základom 0,01 mm,
- dotykové otočné koliesko s krokmi 0,1 / 0,5 / 1 / 5 mm,
- dynamický rozmerový reťazec,
- podrobný matematický postup a kontrolný súčet,
- montážny výstup s kopírovaním a systémovým zdieľaním,
- vysoký kontrast a kompaktný režim,
- úplná prevádzka bez internetu, účtu a servera.

## Zostavenie

Projekt vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2.

```text
node --test tests/*.test.js
gradle :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

GitHub workflow `.github/workflows/build-apk.yml` spustí testy a vytvorí release APK automaticky.
