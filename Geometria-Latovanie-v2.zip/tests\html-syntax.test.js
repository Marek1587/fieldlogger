const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");

test("Android projekt je priamo v koreňovom priečinku", function () {
  const root = path.resolve(__dirname, "..");
  assert.equal(fs.existsSync(path.join(root, "settings.gradle.kts")), true);
  assert.equal(fs.existsSync(path.join(root, "app", "build.gradle.kts")), true);
  assert.equal(fs.existsSync(path.join(root, "app", "src", "main", "AndroidManifest.xml")), true);
});

test("offline HTML obsahuje platný JavaScript a oba režimy", function () {
  const html = fs.readFileSync(path.resolve(__dirname, "../app/src/main/assets/index.html"), "utf8");
  const scripts = Array.from(html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi), function (match) { return match[1]; });
  assert.equal(scripts.length, 1);
  assert.doesNotThrow(function () { new Function(scripts[0]); });
  assert.match(html, /ROZDELENIE/);
  assert.match(html, /KOREKCIA/);
  assert.match(html, /class="rotary"/);
});
