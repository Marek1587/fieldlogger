package sk.strechasketch.app

import java.security.MessageDigest
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round
import kotlin.math.sin

/**
 * Deterministic orthogonal decomposition of the physical wall footprint.
 *
 * The solver works in the persistent 100 mm project grid, not in screen pixels. It proposes
 * rectangles first and keeps a user's semantic override when the same region survives a later
 * bounded outline correction. No roof or wall geometry is moved by this classifier.
 */
object WallFootprintSolver {
    data class Solution(
        val parts: List<WallFootprintPart>,
        val signature: String,
        val dominantAxisDeg: Double
    )

    data class Context(
        val origin: GeoPoint,
        val parts: List<LocalPart>
    ) {
        data class LocalPart(
            val id: String,
            val type: WallFootprintPartType,
            val polygon: List<LocalPoint>,
            val areaM2: Double
        )

        fun structuralPartAt(x: Double, y: Double): LocalPart? {
            val point = LocalPoint(x, y)
            return parts.asSequence()
                .filter { it.type != WallFootprintPartType.RECESS }
                .filter { containsInclusive(point, it.polygon) }
                .sortedWith(
                    compareBy<LocalPart> { structuralPriority(it.type) }
                        .thenBy { it.areaM2 }
                        .thenBy { it.id }
                )
                .firstOrNull()
        }

        fun sameStructuralPart(ax: Double, ay: Double, bx: Double, by: Double): Boolean {
            val first = structuralPartAt(ax, ay) ?: return true
            val second = structuralPartAt(bx, by) ?: return true
            return first.id == second.id
        }
    }

    private data class UvPoint(val u: Double, val v: Double)
    private data class Rect(var u0: Double, var v0: Double, var u1: Double, var v1: Double) {
        val area: Double get() = (u1 - u0).coerceAtLeast(0.0) * (v1 - v0).coerceAtLeast(0.0)
        val centerU: Double get() = (u0 + u1) / 2.0
        val centerV: Double get() = (v0 + v1) / 2.0
    }
    private data class Run(val start: Int, val endExclusive: Int)

    private const val EPSILON = 1e-7
    private const val MATCH_DISTANCE_M = 0.75
    private const val MODEL_VERSION = "wall-footprint-v2"

    fun refresh(project: RoofProject, force: Boolean = false): Solution {
        val solution = solve(project)
        if (!force && project.wallFootprintPartsSignature == solution.signature &&
            project.wallFootprintParts.isNotEmpty()
        ) return solution.copy(parts = project.wallFootprintParts.map(::copyPart))

        val merged = mergeUserOverrides(solution.parts, project.wallFootprintParts)
        project.wallFootprintParts = merged.map(::copyPart).toMutableList()
        project.wallFootprintPartsSignature = solution.signature
        return solution.copy(parts = merged)
    }

    fun resetAutomaticProposal(project: RoofProject): Solution {
        project.wallFootprintParts.clear()
        project.wallFootprintPartsSignature = ""
        return refresh(project, force = true)
    }

    fun context(project: RoofProject): Context {
        val solution = if (project.wallFootprintParts.isEmpty() ||
            project.wallFootprintPartsSignature != signature(project)
        ) {
            // A read-only consumer such as 3D/PDF may need a temporary semantic proposal, but
            // it must not initialize grid metadata or otherwise write into the project. Grid
            // ownership belongs to the confirmed outline workflow.
            solve(project.copy()).let { fresh ->
            fresh.copy(parts = mergeUserOverrides(fresh.parts, project.wallFootprintParts))
            }
        } else Solution(
            project.wallFootprintParts,
            project.wallFootprintPartsSignature,
            project.geometryGridRotationDeg.takeIf(Double::isFinite) ?: 0.0
        )
        val origin = project.roofGraph?.origin
            ?: project.roofTopology?.origin
            ?: project.wallFootprint.firstOrNull()
            ?: project.polygon.firstOrNull()
            ?: GeoPoint(project.centerLat, project.centerLon)
        return Context(origin, solution.parts.mapNotNull { part ->
            val local = part.polygon.map { Geometry.toLocal(it, origin) }
            local.takeIf { it.size >= 3 }?.let {
                Context.LocalPart(part.id, part.type, it, polygonArea(it))
            }
        })
    }

    fun solve(project: RoofProject): Solution {
        val footprint = project.wallFootprint.ifEmpty { project.polygon }
        val digest = signature(project)
        if (footprint.size < 3) return Solution(emptyList(), digest, 0.0)
        MetricPlanGrid.ensureProjectFrame(project, footprint)
        val origin = GeoPoint(project.geometryGridOriginLat, project.geometryGridOriginLon)
        val axisDeg = project.geometryGridRotationDeg.takeIf(Double::isFinite) ?: 0.0
        val angle = Math.toRadians(axisDeg)
        val c = cos(angle)
        val s = sin(angle)
        fun toUv(point: GeoPoint): UvPoint {
            val local = Geometry.toLocal(point, origin)
            return UvPoint(
                quantize(local.x * c + local.y * s),
                quantize(-local.x * s + local.y * c)
            )
        }
        fun toGeo(point: UvPoint): GeoPoint = Geometry.toGeo(
            LocalPoint(point.u * c - point.v * s, point.u * s + point.v * c),
            origin
        )

        val polygon = footprint.map(::toUv)
        val us = polygon.map(UvPoint::u).distinctSorted()
        val vs = polygon.map(UvPoint::v).distinctSorted()
        if (us.size < 2 || vs.size < 2) return Solution(emptyList(), digest, axisDeg)

        val filled = Array(vs.size - 1) { row ->
            BooleanArray(us.size - 1) { column ->
                pointInPolygon(
                    UvPoint((us[column] + us[column + 1]) / 2.0, (vs[row] + vs[row + 1]) / 2.0),
                    polygon
                )
            }
        }
        val rawBuildingRects = mergeCells(filled, us, vs, wanted = true)
        if (rawBuildingRects.isEmpty()) return Solution(emptyList(), digest, axisDeg)

        // A run-by-run decomposition is very sensitive to a 100 mm step at one facade end and
        // used to split one long rectangular tract into two parallel "wings".  The normative
        // main tract is instead the largest fully occupied rectangle in the footprint.  Only the
        // occupied cells left outside that core may become projections or independent wings.
        val main = largestFilledRectangle(filled, us, vs)
            ?: return Solution(emptyList(), digest, axisDeg)
        val remaining = Array(filled.size) { row -> filled[row].clone() }
        remaining.indices.forEach { row ->
            remaining[row].indices.forEach { column ->
                val centerU = (us[column] + us[column + 1]) / 2.0
                val centerV = (vs[row] + vs[row + 1]) / 2.0
                if (centerU >= main.u0 - EPSILON && centerU <= main.u1 + EPSILON &&
                    centerV >= main.v0 - EPSILON && centerV <= main.v1 + EPSILON
                ) remaining[row][column] = false
            }
        }
        val minimumSecondaryArea = max(0.75, main.area * 0.015)
        val secondaryRects = mergeCells(remaining, us, vs, wanted = true)
            .filter { rect ->
                rect.area >= minimumSecondaryArea &&
                    min(rect.u1 - rect.u0, rect.v1 - rect.v0) >= 0.30
            }

        val parts = mutableListOf(part(main, WallFootprintPartType.MAIN_TRACT, ::toGeo, 0.96))
        secondaryRects.sortedWith(compareBy<Rect> { it.v0 }.thenBy { it.u0 }).forEach { rect ->
            val type = if (rect.area >= main.area * 0.42 || elongated(rect)) {
                WallFootprintPartType.SEPARATE_WING
            } else {
                WallFootprintPartType.PROJECTION
            }
            parts += part(rect, type, ::toGeo, 0.78)
        }

        // Small orthogonal voids open to the envelope are useful explicit recess candidates.
        val envelopeArea = (us.last() - us.first()) * (vs.last() - vs.first())
        mergeCells(filled, us, vs, wanted = false).asSequence()
            .filter { rect ->
                rect.area >= 0.50 && rect.area <= envelopeArea * 0.25 &&
                    min(rect.u1 - rect.u0, rect.v1 - rect.v0) >= 0.30
            }
            // A genuine recess is open on at most one envelope side and is enclosed by wall
            // footprint on the other three sides.  Requiring only two axes incorrectly painted
            // all free corner/background strips outside an L-shaped building as recesses.
            .filter { recessTouchesBuildingOnThreeSides(it, rawBuildingRects, us, vs) }
            .forEach { rect -> parts += part(rect, WallFootprintPartType.RECESS, ::toGeo, 0.68) }

        project.objects.asSequence()
            .filter { it.type in setOf(ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT) }
            .sortedBy { it.id }
            .forEach { item ->
                val center = toUv(item.center)
                val width = (item.widthMm / 1000.0).coerceAtLeast(0.1)
                val depth = (item.heightMm / 1000.0).coerceAtLeast(0.1)
                val rect = Rect(center.u - width / 2.0, center.v - depth / 2.0, center.u + width / 2.0, center.v + depth / 2.0)
                parts += part(rect, WallFootprintPartType.SUPERSTRUCTURE, ::toGeo, 1.0, item.id)
            }
        return Solution(parts.sortedBy { it.id }, digest, axisDeg)
    }

    private fun mergeCells(
        cells: Array<BooleanArray>,
        us: List<Double>,
        vs: List<Double>,
        wanted: Boolean
    ): List<Rect> {
        val active = mutableMapOf<Run, Rect>()
        val result = mutableListOf<Rect>()
        cells.indices.forEach { row ->
            val runs = mutableListOf<Run>()
            var start = -1
            for (column in 0..cells[row].size) {
                val matches = column < cells[row].size && cells[row][column] == wanted
                if (matches && start < 0) start = column
                if (!matches && start >= 0) {
                    runs += Run(start, column)
                    start = -1
                }
            }
            val current = runs.associateWith { run ->
                active.remove(run)?.apply { v1 = vs[row + 1] }
                    ?: Rect(us[run.start], vs[row], us[run.endExclusive], vs[row + 1])
            }.toMutableMap()
            result += active.values
            active.clear()
            active.putAll(current)
        }
        result += active.values
        return result.filter { it.area > EPSILON }
    }

    /** Largest all-occupied metric rectangle, O(rows² × columns), deterministic on ties. */
    private fun largestFilledRectangle(
        cells: Array<BooleanArray>,
        us: List<Double>,
        vs: List<Double>
    ): Rect? {
        var best: Rect? = null
        cells.indices.forEach { firstRow ->
            val validColumns = BooleanArray(cells[firstRow].size) { true }
            for (lastRow in firstRow until cells.size) {
                validColumns.indices.forEach { column ->
                    validColumns[column] = validColumns[column] && cells[lastRow][column]
                }
                var start = -1
                for (column in 0..validColumns.size) {
                    val occupied = column < validColumns.size && validColumns[column]
                    if (occupied && start < 0) start = column
                    if (!occupied && start >= 0) {
                        val candidate = Rect(us[start], vs[firstRow], us[column], vs[lastRow + 1])
                        val current = best
                        if (current == null || candidate.area > current.area + EPSILON ||
                            (abs(candidate.area - current.area) <= EPSILON &&
                                compareRect(candidate, current) < 0)
                        ) best = candidate
                        start = -1
                    }
                }
            }
        }
        return best
    }

    private fun compareRect(a: Rect, b: Rect): Int {
        val valuesA = doubleArrayOf(a.v0, a.u0, a.v1, a.u1)
        val valuesB = doubleArrayOf(b.v0, b.u0, b.v1, b.u1)
        valuesA.indices.forEach { index ->
            if (valuesA[index] < valuesB[index] - EPSILON) return -1
            if (valuesA[index] > valuesB[index] + EPSILON) return 1
        }
        return 0
    }

    private fun part(
        rect: Rect,
        type: WallFootprintPartType,
        toGeo: (UvPoint) -> GeoPoint,
        confidence: Double,
        sourceObjectId: String? = null
    ): WallFootprintPart {
        val key = listOf(rect.u0, rect.v0, rect.u1, rect.v1).joinToString(":") { mmKey(it) }
        return WallFootprintPart(
            id = "wall-part-${sha256(key).take(16)}",
            type = type,
            polygon = mutableListOf(
                toGeo(UvPoint(rect.u0, rect.v0)),
                toGeo(UvPoint(rect.u1, rect.v0)),
                toGeo(UvPoint(rect.u1, rect.v1)),
                toGeo(UvPoint(rect.u0, rect.v1))
            ),
            confidence = confidence,
            sourceObjectId = sourceObjectId
        )
    }

    private fun elongated(rect: Rect): Boolean {
        val short = min(rect.u1 - rect.u0, rect.v1 - rect.v0).coerceAtLeast(EPSILON)
        val long = max(rect.u1 - rect.u0, rect.v1 - rect.v0)
        return long / short >= 2.6
    }

    private fun recessTouchesBuildingOnThreeSides(
        recess: Rect,
        buildings: List<Rect>,
        us: List<Double>,
        vs: List<Double>
    ): Boolean {
        var north = false
        var south = false
        var west = false
        var east = false
        buildings.forEach { building ->
            val uOverlap = min(recess.u1, building.u1) - max(recess.u0, building.u0)
            val vOverlap = min(recess.v1, building.v1) - max(recess.v0, building.v0)
            if (uOverlap > EPSILON && abs(recess.v1 - building.v0) <= EPSILON) north = true
            if (uOverlap > EPSILON && abs(recess.v0 - building.v1) <= EPSILON) south = true
            if (vOverlap > EPSILON && abs(recess.u0 - building.u1) <= EPSILON) west = true
            if (vOverlap > EPSILON && abs(recess.u1 - building.u0) <= EPSILON) east = true
        }
        val wallSides = listOf(north, south, west, east).count { it }
        val envelopeSides = listOf(
            abs(recess.u0 - us.first()) <= EPSILON,
            abs(recess.u1 - us.last()) <= EPSILON,
            abs(recess.v0 - vs.first()) <= EPSILON,
            abs(recess.v1 - vs.last()) <= EPSILON
        ).count { it }
        return wallSides >= 3 && envelopeSides <= 1
    }

    private fun signature(project: RoofProject): String {
        val footprint = project.wallFootprint.ifEmpty { project.polygon }
        val geometry = footprint.joinToString(";") {
            String.format(Locale.US, "%.8f,%.8f", it.lat, it.lon)
        }
        val superstructures = project.objects.asSequence()
            .filter { it.type in setOf(ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT) }
            .sortedBy { it.id }
            .joinToString(";") { "${it.id}:${it.center.lat}:${it.center.lon}:${it.widthMm}:${it.heightMm}" }
        // Include the classifier version so projects saved by an older automatic proposal are
        // recalculated once after an algorithm correction. USER overrides are still proximity-
        // matched by mergeUserOverrides and therefore survive this migration.
        return sha256("$MODEL_VERSION|$geometry|$superstructures")
    }

    private fun distanceBetweenCentresM(a: WallFootprintPart, b: WallFootprintPart): Double {
        val ac = Geometry.centroid(a.polygon)
        val bc = Geometry.centroid(b.polygon)
        return Geometry.distanceM(ac, bc)
    }

    private fun mergeUserOverrides(
        proposedParts: List<WallFootprintPart>,
        previousParts: List<WallFootprintPart>
    ): List<WallFootprintPart> {
        val unmatched = previousParts
            .filter { it.source == WallFootprintPartSource.USER }
            .toMutableList()
        return proposedParts.map { proposed ->
            val old = unmatched.minByOrNull { distanceBetweenCentresM(it, proposed) }
                ?.takeIf { distanceBetweenCentresM(it, proposed) <= MATCH_DISTANCE_M }
            if (old == null) proposed else {
                unmatched.remove(old)
                proposed.copy(type = old.type, source = WallFootprintPartSource.USER)
            }
        }
    }

    private fun pointInPolygon(point: UvPoint, polygon: List<UvPoint>): Boolean {
        var inside = false
        var previous = polygon.last()
        polygon.forEach { current ->
            val crosses = (current.v > point.v) != (previous.v > point.v)
            if (crosses) {
                val x = (previous.u - current.u) * (point.v - current.v) /
                    (previous.v - current.v) + current.u
                if (point.u < x) inside = !inside
            }
            previous = current
        }
        return inside
    }

    private fun containsInclusive(point: LocalPoint, polygon: List<LocalPoint>): Boolean =
        Geometry.pointInPolygon(point, polygon) || polygon.indices.any { index ->
            Geometry.distanceToSegment(point, polygon[index], polygon[(index + 1) % polygon.size]) <= 0.02
        }

    private fun polygonArea(points: List<LocalPoint>): Double = abs(points.indices.sumOf { index ->
        val a = points[index]
        val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0)

    private fun structuralPriority(type: WallFootprintPartType): Int = when (type) {
        WallFootprintPartType.SUPERSTRUCTURE -> 0
        WallFootprintPartType.PROJECTION -> 1
        WallFootprintPartType.SEPARATE_WING -> 2
        WallFootprintPartType.MAIN_TRACT -> 3
        WallFootprintPartType.RECESS -> 4
    }

    private fun List<Double>.distinctSorted(): List<Double> =
        map(::quantize).distinct().sorted()

    private fun quantize(value: Double): Double = round(value / MetricPlanGrid.STEP_M) * MetricPlanGrid.STEP_M
    private fun mmKey(value: Double): String = round(value * 1000.0).toLong().toString()
    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { byte ->
            "%02x".format(Locale.US, byte.toInt() and 0xff)
        }

    private fun copyPart(part: WallFootprintPart): WallFootprintPart =
        part.copy(polygon = part.polygon.map(GeoPoint::copy).toMutableList())
}
