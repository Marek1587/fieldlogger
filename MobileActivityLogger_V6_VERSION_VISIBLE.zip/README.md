# Mobile Activity Logger V6 - Version Visible

## Changes

- App status now shows:
  - versionName
  - versionCode
  - packageName

This allows checking that the APK installed on the phone is really the newest build.

Previous fixes remain:
- battery notification spam filtered
- call session grouping
- one CALL_NOTE after real call end
- Google Maps navigation start/end only
