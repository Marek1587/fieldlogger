plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.strechostav.mobileactivity"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.mobileactivity"
        minSdk = 26
        targetSdk = 28
        versionCode = 7
        versionName = "2.4-version-visible"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
