package sk.strechostav.mobileactivity

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CallNoteActivity : Activity() {
    private lateinit var noteEdit: EditText

    private var contact: String = ""
    private var number: String = ""
    private var startTime: String = ""
    private var endTime: String = ""
    private var durationSec: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        contact = intent.getStringExtra("contact") ?: "Neznámy kontakt"
        number = intent.getStringExtra("number") ?: ""
        startTime = intent.getStringExtra("start_time") ?: ""
        endTime = intent.getStringExtra("end_time") ?: ""
        durationSec = intent.getStringExtra("duration_sec") ?: ""

        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(32, 32, 32, 32)

        val title = TextView(this)
        title.text = "O čom bol hovor?"
        title.textSize = 24f
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val info = TextView(this)
        info.text =
            "Kontakt: $contact\n" +
            "Číslo: ${if (number.isBlank()) "-" else number}\n" +
            "Trvanie: ${durationSec}s"
        info.textSize = 15f
        root.addView(info, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Napr. dohodnutý termín, cena, ďalší krok..."
        noteEdit.minLines = 4
        noteEdit.gravity = Gravity.TOP
        root.addView(noteEdit, full())

        val save = Button(this)
        save.text = "Uložiť poznámku k hovoru"
        save.setOnClickListener { saveNote() }
        root.addView(save, full())

        val cancel = Button(this)
        cancel.text = "Zrušiť bez poznámky"
        cancel.setOnClickListener { finish() }
        root.addView(cancel, full())

        setContentView(root)
    }

    private fun saveNote() {
        val note = noteEdit.text?.toString()?.trim() ?: ""

        if (note.isBlank()) {
            Toast.makeText(this, "Poznámka je prázdna.", Toast.LENGTH_SHORT).show()
            return
        }

        val event = linkedMapOf(
            "timestamp" to LocalLogStore.now(),
            "source" to "mobile_call_note",
            "event_type" to "CALL_NOTE",
            "title" to "Poznámka k hovoru: $contact",
            "note" to note,
            "package_name" to "com.samsung.android.incallui",
            "app_name" to "Volať",
            "start_time" to startTime,
            "end_time" to endTime,
            "duration_sec" to durationSec,
            "screen_title" to contact,
            "screen_text" to "Kontakt: $contact; číslo: $number; poznámka: $note",
            "capture_method" to "user_after_call_note",
            "confidence" to "1.0"
        )

        LocalLogStore.appendLocal(this, event)
        GoogleSync.sendOrQueue(this, event)

        Toast.makeText(this, "Poznámka uložená.", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun full(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(0, 8, 0, 8)
        }
    }
}
