# Mobile Activity Logger V7 - Build Fixed

Fixes Kotlin compile error from V6:
- added missing callNoteLaunched field
- added missing callEndGraceMillis field

Keeps:
- visible app version in status
- battery notification spam filter
- call grouping with grace period
- one CALL_NOTE after call
- navigation start/end only
