package sk.klampsketch.app

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

object DevelopedProfilePdfRenderer {
    private const val PT_PER_MM = 72f / 25.4f
    private val scaleSteps = intArrayOf(1, 2, 5, 10, 20, 25, 50, 100, 200)

    fun draw(
        canvas: Canvas,
        project: ProjectRecord,
        drawing: DrawingRecord,
        pageNumber: Int,
        totalPages: Int
    ) {
        val developed = DevelopedProfileBuilder.build(drawing)
            ?: error("Rozvinutý plášť sa nepodarilo vypočítať.")
        canvas.drawColor(Color.WHITE)

        val titlePaint = textPaint(17f, Color.rgb(25, 42, 55), bold = true)
        val subtitlePaint = textPaint(8.5f, Color.rgb(73, 92, 106), bold = true)
        val smallPaint = textPaint(7.2f, Color.rgb(44, 61, 73), bold = false)
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(38, 54, 66)
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
        }

        canvas.drawRect(RectF(mm(8f), mm(8f), mm(289f), mm(202f)), borderPaint)
        canvas.drawText("ROZVINUTÝ PLÁŠŤ – ŠABLÓNA NA STRIHANIE", mm(14f), mm(17f), titlePaint)
        canvas.drawText(
            "${drawing.identifier}  •  ${drawing.name}  •  ${project.name}",
            mm(14f),
            mm(23f),
            subtitlePaint
        )
        canvas.drawText("LIST $pageNumber/$totalPages", mm(258f), mm(17f), subtitlePaint)

        val plan = choosePlan(developed)
        canvas.drawText(
            "MIERKA 1:${plan.denominator}  •  tlačiť na 100 %, bez voľby Prispôsobiť strane",
            mm(14f),
            mm(29f),
            subtitlePaint
        )

        val drawingArea = RectF(mm(14f), mm(34f), mm(283f), mm(157f))
        drawDevelopedGeometry(canvas, developed, plan, drawingArea)
        drawSummary(canvas, drawing, developed, plan.denominator, smallPaint, borderPaint)
        drawCalibration(canvas, subtitlePaint)
    }

    private fun drawDevelopedGeometry(
        canvas: Canvas,
        developed: DevelopedProfile,
        plan: Plan,
        area: RectF
    ) {
        val transformedFront = developed.frontEdge.map(plan::transform)
        val transformedBack = developed.backEdge.map(plan::transform)
        val all = transformedFront + transformedBack
        val minX = all.minOf { it.x }
        val maxX = all.maxOf { it.x }
        val minY = all.minOf { it.y }
        val maxY = all.maxOf { it.y }
        val geometryWidthPt = ((maxX - minX) / plan.denominator * PT_PER_MM).toFloat()
        val geometryHeightPt = ((maxY - minY) / plan.denominator * PT_PER_MM).toFloat()
        val originX = area.left + (area.width() - geometryWidthPt) / 2f
        val originY = area.top + (area.height() - geometryHeightPt) / 2f

        fun pagePoint(point: FlatPoint): FlatPoint {
            val transformed = plan.transform(point)
            return FlatPoint(
                originX + ((transformed.x - minX) / plan.denominator * PT_PER_MM),
                originY + ((transformed.y - minY) / plan.denominator * PT_PER_MM)
            )
        }

        val front = developed.frontEdge.map(::pagePoint)
        val back = developed.backEdge.map(::pagePoint)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(239, 246, 250)
            style = Paint.Style.FILL
        }
        val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(24, 41, 54)
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            strokeJoin = Paint.Join.ROUND
        }
        val frontPaint = Paint(outlinePaint).apply {
            color = Color.rgb(8, 119, 201)
            strokeWidth = 2.1f
        }
        val rearPaint = Paint(outlinePaint).apply {
            color = Color.rgb(68, 82, 92)
            strokeWidth = 2.1f
        }
        val foldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(8, 119, 201)
            style = Paint.Style.STROKE
            strokeWidth = 1.0f
            pathEffect = DashPathEffect(floatArrayOf(5f, 4f), 0f)
        }
        val vertexPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }
        val labelPaint = textPaint(7.0f, Color.rgb(21, 39, 52), bold = true)

        val outline = Path().apply {
            moveTo(front.first().x.toFloat(), front.first().y.toFloat())
            front.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
            back.asReversed().forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
            close()
        }
        canvas.drawPath(outline, fillPaint)
        canvas.drawPath(outline, outlinePaint)
        drawPolyline(canvas, front, frontPaint)
        drawPolyline(canvas, back, rearPaint)

        front.indices.forEach { index ->
            val a = front[index]
            val b = back[index]
            val paint = if (index == 0 || index == front.lastIndex) outlinePaint else foldPaint
            canvas.drawLine(a.x.toFloat(), a.y.toFloat(), b.x.toFloat(), b.y.toFloat(), paint)
            canvas.drawCircle(a.x.toFloat(), a.y.toFloat(), 2.5f, vertexPaint)
            canvas.drawCircle(b.x.toFloat(), b.y.toFloat(), 2.5f, vertexPaint)
            canvas.drawCircle(a.x.toFloat(), a.y.toFloat(), 2.5f, outlinePaint)
            canvas.drawCircle(b.x.toFloat(), b.y.toFloat(), 2.5f, outlinePaint)

            val actualLength = hypot(
                drawingCoordinateX(developed.frontEdge[index], developed.backEdge[index]),
                drawingCoordinateY(developed.frontEdge[index], developed.backEdge[index])
            )
            val lineName = when (index) {
                0 -> "K0"
                front.lastIndex -> "K$index"
                else -> "O$index"
            }
            drawLineLabel(
                canvas,
                a,
                b,
                "$lineName  ${actualLength.roundToInt()} mm",
                labelPaint,
                0f
            )
        }

        developed.panels.forEachIndexed { index, panel ->
            drawLineLabel(
                canvas,
                front[index],
                front[index + 1],
                "P${index + 1}  ${panel.frontWidthMm.toInt()} mm",
                labelPaint,
                -10f
            )
            drawLineLabel(
                canvas,
                back[index],
                back[index + 1],
                "Z${index + 1}  ${panel.rearWidthMm.toInt()} mm",
                labelPaint,
                10f
            )
        }

        canvas.drawText("PREDNÁ REZNÁ HRANA", front.first().x.toFloat(), front.first().y.toFloat() - 10f, labelPaint)
        canvas.drawText("ZADNÁ REZNÁ HRANA", back.first().x.toFloat(), back.first().y.toFloat() + 15f, labelPaint)
    }

    private fun drawSummary(
        canvas: Canvas,
        drawing: DrawingRecord,
        developed: DevelopedProfile,
        denominator: Int,
        textPaint: Paint,
        borderPaint: Paint
    ) {
        val table = RectF(mm(14f), mm(161f), mm(283f), mm(192f))
        canvas.drawRect(table, borderPaint)
        val metrics = calculateMetrics(drawing)
        val values = listOf(
            "Profil" to drawing.identifier,
            "Mierka" to "1:$denominator",
            "Predný rozvin" to "${metrics.developedWidthMm} mm",
            "Zadný rozvin" to "${metrics.rearDevelopedWidthMm ?: metrics.developedWidthMm} mm",
            "Výrobná dĺžka" to "${formatDecimal(drawing.profileLengthM, 2)} m",
            "Plocha / kus" to "${formatDecimal(metrics.sheetPerPieceM2)} m²",
            "Materiál" to "${drawing.material}, ${formatDecimal(drawing.thicknessMm, 1)} mm",
            "Farba" to drawing.ral
        )
        val columns = 4
        val rows = 2
        val cellWidth = table.width() / columns
        val cellHeight = table.height() / rows
        values.forEachIndexed { index, (label, value) ->
            val row = index / columns
            val column = index % columns
            val cell = RectF(
                table.left + column * cellWidth,
                table.top + row * cellHeight,
                table.left + (column + 1) * cellWidth,
                table.top + (row + 1) * cellHeight
            )
            canvas.drawRect(cell, borderPaint)
            val bold = Paint(textPaint).apply { typeface = Typeface.DEFAULT_BOLD }
            canvas.drawText(label.uppercase(), cell.left + 5f, cell.top + 10f, textPaint)
            canvas.drawText(value.take(30), cell.left + 5f, cell.top + 24f, bold)
        }

        val foldValues = developed.frontEdge.indices.joinToString("   ") { index ->
            val length = hypot(
                drawingCoordinateX(developed.frontEdge[index], developed.backEdge[index]),
                drawingCoordinateY(developed.frontEdge[index], developed.backEdge[index])
            ).roundToInt()
            val name = if (index == 0 || index == developed.frontEdge.lastIndex) "K$index" else "O$index"
            "$name=$length mm"
        }
        canvas.drawText(
            "SKOSENÉ DĹŽKY ČIAR: ${foldValues.take(190)}",
            mm(14f),
            mm(197f),
            Paint(textPaint).apply { typeface = Typeface.DEFAULT_BOLD }
        )
    }

    private fun drawCalibration(canvas: Canvas, paint: Paint) {
        val startX = mm(224f)
        val endX = startX + mm(50f)
        val y = mm(198f)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(25, 42, 55)
            strokeWidth = 1.2f
        }
        canvas.drawLine(startX, y, endX, y, line)
        canvas.drawLine(startX, y - 4f, startX, y + 4f, line)
        canvas.drawLine(endX, y - 4f, endX, y + 4f, line)
        canvas.drawText("kontrola tlače 50 mm", startX, y - 6f, paint)
    }

    private fun choosePlan(profile: DevelopedProfile): Plan {
        val normal = planFor(profile, rotated = false)
        val rotated = planFor(profile, rotated = true)
        return when {
            rotated.denominator < normal.denominator -> rotated
            rotated.denominator > normal.denominator -> normal
            rotated.usedAreaRatio > normal.usedAreaRatio -> rotated
            else -> normal
        }
    }

    private fun planFor(profile: DevelopedProfile, rotated: Boolean): Plan {
        val points = (profile.frontEdge + profile.backEdge).map { point ->
            if (rotated) FlatPoint(-point.y, point.x) else point
        }
        val width = points.maxOf { it.x } - points.minOf { it.x }
        val height = points.maxOf { it.y } - points.minOf { it.y }
        val availableWidthMm = 255.0
        val availableHeightMm = 112.0
        val denominator = scaleSteps.firstOrNull {
            width / it <= availableWidthMm && height / it <= availableHeightMm
        } ?: ceil(max(width / availableWidthMm, height / availableHeightMm)).toInt().coerceAtLeast(1)
        val usedArea = (width / denominator) * (height / denominator)
        return Plan(rotated, denominator, usedArea / (availableWidthMm * availableHeightMm))
    }

    private fun drawPolyline(canvas: Canvas, points: List<FlatPoint>, paint: Paint) {
        val path = Path().apply {
            moveTo(points.first().x.toFloat(), points.first().y.toFloat())
            points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
        }
        canvas.drawPath(path, paint)
    }

    private fun drawLineLabel(
        canvas: Canvas,
        start: FlatPoint,
        end: FlatPoint,
        label: String,
        paint: Paint,
        normalOffset: Float
    ) {
        val dx = (end.x - start.x).toFloat()
        val dy = (end.y - start.y).toFloat()
        val length = max(0.001f, hypot(dx.toDouble(), dy.toDouble()).toFloat())
        val midX = ((start.x + end.x) / 2.0).toFloat() - dy / length * normalOffset
        val midY = ((start.y + end.y) / 2.0).toFloat() + dx / length * normalOffset
        var angle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (angle > 90f || angle < -90f) angle += 180f
        canvas.save()
        canvas.rotate(angle, midX, midY)
        val width = paint.measureText(label)
        val background = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        canvas.drawRect(midX - width / 2f - 2f, midY - 7f, midX + width / 2f + 2f, midY + 3f, background)
        canvas.drawText(label, midX - width / 2f, midY, paint)
        canvas.restore()
    }

    private fun drawingCoordinateX(a: FlatPoint, b: FlatPoint): Double = b.x - a.x
    private fun drawingCoordinateY(a: FlatPoint, b: FlatPoint): Double = b.y - a.y
    private fun mm(value: Float): Float = value * PT_PER_MM

    private fun textPaint(size: Float, color: Int, bold: Boolean) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        textSize = size
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
    }

    private data class Plan(
        val rotated: Boolean,
        val denominator: Int,
        val usedAreaRatio: Double
    ) {
        fun transform(point: FlatPoint): FlatPoint =
            if (rotated) FlatPoint(-point.y, point.x) else point
    }
}
