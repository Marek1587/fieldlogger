const test = require("node:test");
const assert = require("node:assert/strict");
const Core = require("../app/src/main/assets/planner-core.js");

function base() {
  const state = Core.emptyState();
  const project = Core.createProject(state, "Test");
  state.activeProjectId = project.id;
  state.projectStart[project.id] = "2026-08-10T08:00:00.000Z";
  return { state, project };
}

test("baseline 12 h sa pri dvoch nezávislých sekciách skráti približne na 6 h", () => {
  const { state, project } = base();
  const a = Core.createSection(state, project.id, "Sekcia A", "#3182ce");
  const b = Core.createSection(state, project.id, "Sekcia B", "#38a169");
  const workerA = Core.createWorker(state, "Worker A");
  const workerB = Core.createWorker(state, "Worker B");
  [120, 180, 60].forEach((duration, index) => Core.createTask(state, project.id, `A${index}`, { sectionId: a.id, orderInSection: index + 1, estimatedMinutes: duration, assignedWorkerId: workerA.id }));
  [240, 120].forEach((duration, index) => Core.createTask(state, project.id, `B${index}`, { sectionId: b.id, orderInSection: index + 1, estimatedMinutes: duration, assignedWorkerId: workerB.id }));
  Core.normalizeOrders(state, project.id);
  const baseline = Core.baselineSchedule(state, project.id, state.projectStart[project.id]);
  const parallel = Core.parallelSchedule(state, project.id, state.projectStart[project.id]);
  assert.equal(baseline.totalWorkingMinutes, 720);
  assert.equal(parallel.totalWorkingMinutes, 720);
  assert.equal(Math.max(...parallel.assignments.filter(a => a.workerId === workerA.id).map(a => new Date(a.end))) , Math.max(...parallel.assignments.filter(a => a.workerId === workerB.id).map(a => new Date(a.end))));
  assert.ok(new Date(parallel.projectEnd) < new Date(baseline.projectEnd));
});

test("presun sekcie prečísluje kódy bez zmeny UUID", () => {
  const { state, project } = base();
  const roof = Core.createSection(state, project.id, "Strecha", "#3182ce");
  const chimney = Core.createSection(state, project.id, "Komín", "#805ad5");
  const roofTask = Core.createTask(state, project.id, "R1", { sectionId: roof.id, orderInSection: 1 });
  const chimneyTask = Core.createTask(state, project.id, "K1", { sectionId: chimney.id, orderInSection: 1 });
  const ids = [roofTask.id, chimneyTask.id];
  chimney.order = 1; roof.order = 2; Core.normalizeOrders(state, project.id);
  assert.equal(Core.displayCode(state, chimneyTask), "1.1");
  assert.equal(Core.displayCode(state, roofTask), "2.1");
  assert.deepEqual([roofTask.id, chimneyTask.id], ids);
});

test("nákup agreguje iba presne rovnaký názov a jednotku", () => {
  const { state, project } = base();
  const section = Core.createSection(state, project.id, "A");
  const a = Core.createTask(state, project.id, "X", { sectionId: section.id, orderInSection: 1 });
  const b = Core.createTask(state, project.id, "Y", { sectionId: section.id, orderInSection: 2 });
  a.materials.push({ id: Core.uuid(), taskId: a.id, supplierName: "KJG", name: "Skrutka RA", quantity: 50, unit: "ks", purchaseRequired: true });
  b.materials.push({ id: Core.uuid(), taskId: b.id, supplierName: "KJG", name: "Skrutka RA", quantity: 70, unit: "ks", purchaseRequired: true });
  Core.normalizeOrders(state, project.id);
  const output = Core.aggregatePurchases(state, project.id);
  assert.equal(output[0].items[0].quantity, 120);
  assert.equal(output[0].items[0].sources.length, 2);
});

test("výroba zoskupí spoločný header a nezlučuje odlišné názvy dielov", () => {
  const { state, project } = base();
  const section = Core.createSection(state, project.id, "A");
  const a = Core.createTask(state, project.id, "X", { sectionId: section.id, orderInSection: 1 });
  const b = Core.createTask(state, project.id, "Y", { sectionId: section.id, orderInSection: 2 });
  a.fabrications.push({ id: Core.uuid(), taskId: a.id, fabricationPlace: "KJG", material: "Plech", color: "RAL 7016", thickness: "0,50 mm", name: "Záveterná lišta", quantity: 10, unit: "bm" });
  b.fabrications.push({ id: Core.uuid(), taskId: b.id, fabricationPlace: "KJG", material: "Plech", color: "RAL 7016", thickness: "0,50 mm", name: "Hrebenáč", quantity: 8, unit: "ks" });
  const output = Core.aggregateFabrications(state, project.id);
  assert.equal(output.length, 1);
  assert.equal(output[0].items.length, 2);
});

test("reorder C pred A zostane zachovaný po serializácii a reload simulácii", () => {
  const { state, project } = base();
  const a = Core.createTask(state, project.id, "A");
  const b = Core.createTask(state, project.id, "B");
  const c = Core.createTask(state, project.id, "C");
  Core.reorderIds(state.tasks, [c.id, a.id, b.id], "originalOrder");
  const reloaded = Core.migrateState(JSON.parse(JSON.stringify(state)));
  const ordered = reloaded.tasks
    .filter(task => task.projectId === project.id)
    .sort((left, right) => left.originalOrder - right.originalOrder);
  assert.deepEqual(ordered.map(task => task.name), ["C", "A", "B"]);
  assert.deepEqual(ordered.map(task => task.id), [c.id, a.id, b.id]);
});

test("presun nezaradenej úlohy do sekcie zostane zachovaný po reload simulácii", () => {
  const { state, project } = base();
  const veranda = Core.createSection(state, project.id, "Veranda", "#38a169");
  const task = Core.createTask(state, project.id, "Task X");
  task.sectionId = veranda.id;
  task.orderInSection = 1;
  Core.normalizeOrders(state, project.id);
  const reloaded = Core.migrateState(JSON.parse(JSON.stringify(state)));
  const moved = reloaded.tasks.find(item => item.id === task.id);
  assert.equal(moved.sectionId, veranda.id);
  assert.equal(moved.orderInSection, 1);
  assert.equal(reloaded.tasks.filter(item => item.projectId === project.id && !item.sectionId).length, 0);
});

test("normalizácia 100 úloh zachová stabilné UUID a súvislé poradie", () => {
  const { state, project } = base();
  const section = Core.createSection(state, project.id, "Veľká sekcia");
  const created = Array.from({ length: 100 }, (_, index) => Core.createTask(state, project.id, `Úloha ${index + 1}`, {
    sectionId: section.id,
    originalOrder: 100 - index,
    orderInSection: 100 - index,
  }));
  const ids = new Set(created.map(task => task.id));
  Core.normalizeOrders(state, project.id);
  const normalized = state.tasks.filter(task => task.sectionId === section.id).sort((a, b) => a.orderInSection - b.orderInSection);
  assert.equal(normalized.length, 100);
  assert.deepEqual(normalized.map(task => task.orderInSection), Array.from({ length: 100 }, (_, index) => index + 1));
  assert.ok(normalized.every(task => ids.has(task.id)));
});
