const test = require("node:test");
const assert = require("node:assert/strict");
const Core = require("../app/src/main/assets/planner-core.js");

function base() {
  const state = Core.emptyState();
  const project = Core.createProject(state, "Test");
  state.activeProjectId = project.id;
  state.projectStart[project.id] = "2026-08-10T08:00:00.000Z";
  return { state, project };
}

test("baseline 12 h sa pri dvoch nezávislých sekciách skráti približne na 6 h", () => {
  const { state, project } = base();
  const a = Core.createSection(state, project.id, "Sekcia A", "#3182ce");
  const b = Core.createSection(state, project.id, "Sekcia B", "#38a169");
  const workerA = Core.createWorker(state, "Worker A");
  const workerB = Core.createWorker(state, "Worker B");
  [120, 180, 60].forEach((duration, index) => Core.createTask(state, project.id, `A${index}`, { sectionId: a.id, orderInSection: index + 1, estimatedMinutes: duration, assignedWorkerId: workerA.id }));
  [240, 120].forEach((duration, index) => Core.createTask(state, project.id, `B${index}`, { sectionId: b.id, orderInSection: index + 1, estimatedMinutes: duration, assignedWorkerId: workerB.id }));
  Core.normalizeOrders(state, project.id);
  const baseline = Core.baselineSchedule(state, project.id, state.projectStart[project.id]);
  const parallel = Core.parallelSchedule(state, project.id, state.projectStart[project.id]);
  assert.equal(baseline.totalWorkingMinutes, 720);
  assert.equal(parallel.totalWorkingMinutes, 720);
  assert.equal(Math.max(...parallel.assignments.filter(a => a.workerId === workerA.id).map(a => new Date(a.end))) , Math.max(...parallel.assignments.filter(a => a.workerId === workerB.id).map(a => new Date(a.end))));
  assert.ok(new Date(parallel.projectEnd) < new Date(baseline.projectEnd));
});

test("presun sekcie prečísluje kódy bez zmeny UUID", () => {
  const { state, project } = base();
  const roof = Core.createSection(state, project.id, "Strecha", "#3182ce");
  const chimney = Core.createSection(state, project.id, "Komín", "#805ad5");
  const roofTask = Core.createTask(state, project.id, "R1", { sectionId: roof.id, orderInSection: 1 });
  const chimneyTask = Core.createTask(state, project.id, "K1", { sectionId: chimney.id, orderInSection: 1 });
  const ids = [roofTask.id, chimneyTask.id];
  chimney.order = 1; roof.order = 2; Core.normalizeOrders(state, project.id);
  assert.equal(Core.displayCode(state, chimneyTask), "1.1");
  assert.equal(Core.displayCode(state, roofTask), "2.1");
  assert.deepEqual([roofTask.id, chimneyTask.id], ids);
});

test("nákup agreguje iba presne rovnaký názov a jednotku", () => {
  const { state, project } = base();
  const section = Core.createSection(state, project.id, "A");
  const a = Core.createTask(state, project.id, "X", { sectionId: section.id, orderInSection: 1 });
  const b = Core.createTask(state, project.id, "Y", { sectionId: section.id, orderInSection: 2 });
  a.materials.push({ id: Core.uuid(), taskId: a.id, supplierName: "KJG", name: "Skrutka RA", quantity: 50, unit: "ks", purchaseRequired: true });
  b.materials.push({ id: Core.uuid(), taskId: b.id, supplierName: "KJG", name: "Skrutka RA", quantity: 70, unit: "ks", purchaseRequired: true });
  Core.normalizeOrders(state, project.id);
  const output = Core.aggregatePurchases(state, project.id);
  assert.equal(output[0].items[0].quantity, 120);
  assert.equal(output[0].items[0].sources.length, 2);
});

test("výroba zoskupí spoločný header a nezlučuje odlišné názvy dielov", () => {
  const { state, project } = base();
  const section = Core.createSection(state, project.id, "A");
  const a = Core.createTask(state, project.id, "X", { sectionId: section.id, orderInSection: 1 });
  const b = Core.createTask(state, project.id, "Y", { sectionId: section.id, orderInSection: 2 });
  a.fabrications.push({ id: Core.uuid(), taskId: a.id, fabricationPlace: "KJG", material: "Plech", color: "RAL 7016", thickness: "0,50 mm", name: "Záveterná lišta", quantity: 10, unit: "bm" });
  b.fabrications.push({ id: Core.uuid(), taskId: b.id, fabricationPlace: "KJG", material: "Plech", color: "RAL 7016", thickness: "0,50 mm", name: "Hrebenáč", quantity: 8, unit: "ks" });
  const output = Core.aggregateFabrications(state, project.id);
  assert.equal(output.length, 1);
  assert.equal(output[0].items.length, 2);
});
