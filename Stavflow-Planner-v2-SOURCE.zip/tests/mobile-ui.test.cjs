const test = require("node:test");
const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");

const html = readFileSync(join(__dirname, "../app/src/main/assets/index.html"), "utf8");

test("mobile layout uzatvára hlavné wrappery do šírky viewportu", () => {
  assert.match(html, /html,body\{width:100%;max-width:100vw;overflow-x:hidden\}/);
  assert.match(html, /\.bottom-nav\{width:100%;max-width:100vw;min-width:0\}/);
  assert.match(html, /\.workflow\{width:calc\(100% \+ 28px\);max-width:100vw;min-width:0;overflow-x:auto;overflow-y:hidden/);
  assert.match(html, /\.gantt-wrap\{overflow-x:auto;overflow-y:hidden\}/);
});

test("nezaradené úlohy a sekcie sú vertikálne a karty zalamujú dlhé názvy", () => {
  assert.match(html, /\.unassigned-list\{display:flex;flex-direction:column;/);
  assert.match(html, /\.assign-card\{min-width:0;display:flex;/);
  assert.match(html, /\.section-grid\{grid-template-columns:minmax\(0,1fr\)\}/);
  assert.match(html, /overflow-wrap:anywhere;word-break:break-word/);
});

test("drag lifecycle používa hold, overlay, stabilné ID a viditeľný drop target", () => {
  assert.match(html, /overlay\.dataset\.dragOverlay='true'/);
  assert.match(html, /setTimeout\(\(\)=>activate\(event\),230\)/);
  assert.match(html, /setPointerCapture\(event\.pointerId\)/);
  assert.match(html, /dataset\.sortId/);
  assert.match(html, /dataset\.assignTask/);
  assert.match(html, /classList\.add\('drop-target'\)/);
  assert.match(html, /container\.insertBefore\(card,before\?target:target\.nextSibling\)/);
  assert.doesNotMatch(html, /function moveGhost\(/);
});

test("autosave je debounce a flushne sa pri opustení WebView", () => {
  assert.match(html, /autosaveTimer=setTimeout\(persistStateNow,450\)/);
  assert.match(html, /addEventListener\('pagehide'/);
  assert.match(html, /visibilityState==='hidden'/);
});
