const assert = require("node:assert/strict");
const { chromium } = require("playwright");
const { join } = require("node:path");

const baseUrl = process.argv[2] || "http://127.0.0.1:8765/index.html";
const screenshotDir = process.argv[3] || process.cwd();
const edgePath = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";
const mobileWidths = [320, 360, 375, 390, 412, 430, 768];
const routes = ["tasks", "order", "sections", "refine", "assign", "purchases", "fabrication", "gantt"];

async function viewportReport(page, label, expectedWidth, expectTouch) {
  await page.waitForTimeout(90);
  const report = await page.evaluate(() => ({
    ...window.__plannerDiagnostics.mobileViewportReport(),
    innerWidth: window.innerWidth,
    visualViewportWidth: window.visualViewport?.width,
    touchPoints: navigator.maxTouchPoints,
  }));
  assert.ok(Math.abs(report.innerWidth - expectedWidth) <= 1, `${label}: innerWidth ${report.innerWidth}, očakávané ${expectedWidth}`);
  assert.ok(Math.abs(report.visualViewportWidth - expectedWidth) <= 1, `${label}: visual viewport ${report.visualViewportWidth}`);
  if (expectTouch) assert.ok(report.touchPoints > 0, `${label}: touch emulácia nie je aktívna`);
  assert.ok(report.documentScrollWidth <= expectedWidth + 1, `${label}: document scrollWidth ${report.documentScrollWidth}; vinníci ${JSON.stringify(report.offenders)}`);
  assert.ok(report.bodyScrollWidth <= expectedWidth + 1, `${label}: body scrollWidth ${report.bodyScrollWidth}; vinníci ${JSON.stringify(report.offenders)}`);
  assert.deepEqual(report.offenders, [], `${label}: elementy presahujú viewport`);
  return report;
}

async function openSeedProject(page) {
  await page.locator("[data-open-project]").first().click();
  await page.locator("#plannerScreen:not(.hidden)").waitFor();
}

async function openRoute(page, route) {
  await page.locator(`.workflow [data-route="${route}"]`).click();
  await page.waitForTimeout(35);
}

async function longPressDrag(cdp, page, source, target) {
  await source.scrollIntoViewIfNeeded();
  const sourceBox = await source.boundingBox();
  const targetBox = await target.boundingBox();
  assert.ok(sourceBox && targetBox, "Drag source alebo target nie je viditeľný");
  const start = { x: Math.round(sourceBox.x + sourceBox.width / 2), y: Math.round(sourceBox.y + sourceBox.height / 2) };
  const end = { x: Math.round(targetBox.x + targetBox.width / 2), y: Math.round(targetBox.y + Math.min(12, targetBox.height / 3)) };
  await cdp.send("Input.dispatchTouchEvent", { type: "touchStart", touchPoints: [{ ...start, radiusX: 5, radiusY: 5, force: 1 }] });
  await page.waitForTimeout(280);
  await page.locator("[data-drag-overlay]").waitFor({ state: "visible" });
  await cdp.send("Input.dispatchTouchEvent", { type: "touchMove", touchPoints: [{ ...end, radiusX: 5, radiusY: 5, force: 1 }] });
  await page.waitForTimeout(90);
  await cdp.send("Input.dispatchTouchEvent", { type: "touchEnd", touchPoints: [] });
  await page.waitForTimeout(520);
}

(async () => {
  const browser = await chromium.launch({ executablePath: edgePath, headless: true });
  const results = [];
  try {
    for (const width of mobileWidths) {
      const height = width === 768 ? 1024 : 844;
      const context = await browser.newContext({
        viewport: { width, height },
        screen: { width, height },
        deviceScaleFactor: 3,
        isMobile: true,
        hasTouch: true,
        userAgent: "Mozilla/5.0 (Linux; Android 14; PlannerViewportTest) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36",
      });
      const page = await context.newPage();
      await page.goto(baseUrl, { waitUntil: "networkidle" });
      await viewportReport(page, `${width}px/projects`, width, true);
      await openSeedProject(page);
      await openRoute(page, "tasks");
      await page.locator("#bulkInput").fill("odkvapy pod nástrešný žľab z dvora – chýbajúce množstvo, odpadové rúry, objímky a veľmi dlhý názov pracovnej úlohy");
      await page.locator("#bulkCreate").click();
      for (const route of routes) {
        await openRoute(page, route);
        await viewportReport(page, `${width}px/${route}`, width, true);
      }

      if (width === 390) {
        const cdp = await context.newCDPSession(page);
        await openRoute(page, "order");
        const cards = page.locator("#globalOrder > [data-sort-id]");
        const movedName = await cards.nth(2).locator("strong").textContent();
        await longPressDrag(cdp, page, cards.nth(2).locator(".drag-handle"), cards.nth(0));
        assert.equal((await cards.nth(0).locator("strong").textContent()).trim(), movedName.trim(), "Touch reorder C → A sa nevykonal");
        await page.reload({ waitUntil: "networkidle" });
        await openSeedProject(page);await openRoute(page, "order");
        assert.equal((await page.locator("#globalOrder > [data-sort-id]").nth(0).locator("strong").textContent()).trim(), movedName.trim(), "Reorder sa po reload stratil");

        await openRoute(page, "sections");
        const before = await page.locator("[data-assign-task]").count();
        const taskHandle = page.locator("[data-assign-task] .card-drag-handle").first();
        const sectionTarget = page.locator("[data-section-drop]").first();
        await longPressDrag(cdp, page, taskHandle, sectionTarget);
        assert.equal(await page.locator("[data-assign-task]").count(), before - 1, "Touch task → section sa nevykonal");
        await viewportReport(page, "390px/sections-after-touch-drop", width, true);
        await page.screenshot({ path: join(screenshotDir, "Planner-mobile-390-sections.png"), fullPage: true });
      }
      results.push({ width, routes: routes.length, touch: true });
      await context.close();
    }

    const desktop = await browser.newContext({ viewport: { width: 1280, height: 900 }, screen: { width: 1280, height: 900 } });
    const desktopPage = await desktop.newPage();
    await desktopPage.goto(baseUrl, { waitUntil: "networkidle" });
    await viewportReport(desktopPage, "1280px/projects", 1280, false);
    await openSeedProject(desktopPage);
    for (const route of routes) { await openRoute(desktopPage, route); await viewportReport(desktopPage, `1280px/${route}`, 1280, false); }
    await desktop.close();
    console.log(JSON.stringify({ ok: true, mobileDevices: results, desktop: 1280 }, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
