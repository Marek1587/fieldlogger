# Planner 2.0.2 — test report

## Reálny Android build

Overené lokálne rovnakým základným príkazom ako v GitHub Actions:

```text
gradle :app:assembleDebug --stacktrace
```

Prostredie: Microsoft OpenJDK 17, Gradle 8.10.2, Android SDK/compile SDK 35.

Výsledok: `BUILD SUCCESSFUL`, vytvorený `app/build/outputs/apk/debug/app-debug.apk`.

Overené APK metadata:

```text
applicationId: sk.latovanie.app
versionCode: 11
versionName: 2.0.2
application label: Planner
targetSdkVersion: 35
APK Signature Scheme v2: verified
```

Ak `signing.properties` a pôvodný JKS nie sú dostupné, debug build použije štandardný Android debug podpis a nezlyhá. Ak sú dostupné všetky podpisové secrets, debug aj release použijú pôvodný stabilný podpis.

## Skutočná mobilná emulácia

Test nebol vykonaný iba zmenšením desktopového okna. Microsoft Edge/Chromium bol spustený pre každú mobilnú šírku so zapnutými parametrami:

- `isMobile: true`,
- `hasTouch: true`,
- Android mobile user-agent,
- device scale factor 3,
- samostatné hodnoty `viewport` aj `screen`.

Úspešne overené šírky:

```text
320, 360, 375, 390, 412, 430, 768 px
```

Na každej šírke prešlo všetkých osem workflow obrazoviek. Diagnostika overila:

```text
document.documentElement.scrollWidth <= window.innerWidth + 1
document.body.scrollWidth <= window.innerWidth + 1
offending elements = 0
```

Pri 390 px boli cez Chrome DevTools Protocol odoslané reálne touch udalosti. Prešlo:

- long-press drag overlay,
- presun tretej úlohy pred prvú,
- zachovanie poradia po reload,
- presun nezaradenej úlohy do sekcie,
- okamžitá zmena počtu nezaradených úloh.

Rovnaká kontrola všetkých obrazoviek prešla aj pri desktop šírke 1280 px.

## Automatické testy

Node test suite: 12 testov, 12 úspešných, 0 neúspešných.
