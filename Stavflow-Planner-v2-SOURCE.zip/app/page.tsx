"use client";

import { useMemo, useRef, useState } from "react";

type TaskType = "expert" | "assembly" | "logistics" | "material" | "admin" | "move" | "blocked";
type Status = "READY" | "IN PROGRESS" | "BLOCKED" | "WAITING MATERIAL" | "DONE";

type WheelConfig = {
  title: string;
  value: number;
  unit: string;
  step: number;
  onApply: (value: number) => void;
};

type Task = {
  id: number;
  worker: string;
  project: string;
  zone: string;
  name: string;
  start: number;
  end: number;
  type: TaskType;
  status: Status;
  progress?: number;
  box?: string;
  note?: string;
  mechanizable?: boolean;
};

const people = [
  { name: "Marek", role: "Majster klampiar", initials: "MK", color: "#2446a8" },
  { name: "Ján", role: "Strechár", initials: "JN", color: "#128067" },
  { name: "Vlado", role: "Montážnik", initials: "VL", color: "#b36b13" },
  { name: "Otec", role: "Logistika & výroba", initials: "OT", color: "#6f4aa0" },
];

const initialTasks: Task[] = [
  { id: 1, worker: "Marek", project: "Pompura", zone: "Strecha S2", name: "Falcovaná krytina", start: 8, end: 11.5, type: "expert", status: "IN PROGRESS", progress: 68, box: "BOX-KRYTINA" },
  { id: 2, worker: "Marek", project: "Pompura", zone: "Komín K1", name: "Detail pri murive", start: 11.5, end: 12.5, type: "expert", status: "READY", box: "BOX-KLAMPIAR" },
  { id: 3, worker: "Marek", project: "Pompura", zone: "Hrebeň H1", name: "Montáž hrebeňa", start: 13, end: 15, type: "expert", status: "WAITING MATERIAL", box: "BOX-HREBEN", note: "Hrebenáče prídu 12:30" },
  { id: 4, worker: "Marek", project: "Pompura", zone: "Celá strecha", name: "Výstupná kontrola", start: 15, end: 16, type: "admin", status: "READY" },
  { id: 5, worker: "Ján", project: "Armadei", zone: "Strecha S4", name: "Latovanie zóny S4", start: 8, end: 10.5, type: "assembly", status: "IN PROGRESS", progress: 42, box: "BOX-LATY" },
  { id: 6, worker: "Ján", project: "Armadei", zone: "Odkvap O2", name: "Vetrací pás", start: 10.5, end: 12, type: "assembly", status: "READY", box: "BOX-FOLIA" },
  { id: 7, worker: "Ján", project: "Armadei", zone: "Štít Š1", name: "Podbitie štítu", start: 13, end: 15.25, type: "assembly", status: "READY" },
  { id: 8, worker: "Ján", project: "Armadei", zone: "Zvody Z1", name: "Zvody a kolená", start: 15.25, end: 16.75, type: "expert", status: "BLOCKED", note: "Chýba zameranie kolena" },
  { id: 9, worker: "Vlado", project: "Armadei", zone: "Strecha S4", name: "Pomocná montáž", start: 8, end: 11, type: "assembly", status: "IN PROGRESS", progress: 51, box: "BOX-LATY" },
  { id: 10, worker: "Vlado", project: "Armadei", zone: "Dvor", name: "Presun materiálu", start: 11, end: 12, type: "logistics", status: "READY", mechanizable: true },
  { id: 11, worker: "Vlado", project: "Armadei", zone: "Odkvap O2", name: "Odkvapové štetiny", start: 13, end: 15, type: "assembly", status: "READY" },
  { id: 12, worker: "Otec", project: "KJG", zone: "Sklad", name: "Nákup kotvenia", start: 7.5, end: 9, type: "material", status: "IN PROGRESS", progress: 80 },
  { id: 13, worker: "Otec", project: "Dielňa", zone: "Výroba", name: "Výroba lemovania", start: 9.5, end: 12, type: "expert", status: "READY" },
  { id: 14, worker: "Otec", project: "Pompura", zone: "Stavenisko", name: "Vykládka krytiny", start: 13, end: 14, type: "logistics", status: "READY", mechanizable: true },
  { id: 15, worker: "Otec", project: "Kancelária", zone: "Admin", name: "Objednávky na pondelok", start: 14.25, end: 16, type: "admin", status: "READY" },
];

const typeLabel: Record<TaskType, string> = {
  expert: "Odborná výroba", assembly: "Montáž", logistics: "Logistika", material: "Materiál / nákup", admin: "Administratíva", move: "Presun", blocked: "Blokácia",
};

const statusLabel: Record<Status, string> = {
  READY: "Pripravené", "IN PROGRESS": "Prebieha", BLOCKED: "Blokované", "WAITING MATERIAL": "Čaká na materiál", DONE: "Hotovo",
};

function time(value: number) {
  const hour = Math.floor(value);
  const minutes = Math.round((value - hour) * 60);
  return `${String(hour).padStart(2, "0")}:${String(minutes).padStart(2, "0")}`;
}

export default function Home() {
  const [tasks, setTasks] = useState(initialTasks);
  const [view, setView] = useState<"people" | "projects" | "card">("people");
  const [selected, setSelected] = useState<Task | null>(null);
  const [command, setCommand] = useState("");
  const [notice, setNotice] = useState("3 úlohy vyžadujú pozornosť");
  const [dateOffset, setDateOffset] = useState(0);
  const [dragged, setDragged] = useState<number | null>(null);
  const [cardWorker, setCardWorker] = useState("Vlado");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [solverSettings, setSolverSettings] = useState({ workday: 9, buffer: 12, travel: 35, timeStep: 15 });
  const [wheel, setWheel] = useState<WheelConfig | null>(null);
  const wheelDrag = useRef<{ angle: number; remainder: number } | null>(null);

  const projectRows = useMemo(() => ["Pompura", "Armadei", "KJG", "Dielňa", "Kancelária"], []);
  const totalHours = tasks.reduce((sum, task) => sum + task.end - task.start, 0);
  const alerts = tasks.filter((task) => task.status === "BLOCKED" || task.status === "WAITING MATERIAL").length;

  function applyCommand() {
    const input = command.trim().toLowerCase();
    if (!input) return;
    if (input.includes("vlado") && (input.includes("nepríde") || input.includes("nepride"))) {
      setTasks((all) => all.map((task) => task.worker === "Vlado" ? { ...task, status: "BLOCKED" as Status, note: "Vlado – nedostupný" } : task));
      setNotice("Prepočítané: 3 úlohy Vlada sú blokované");
    } else if (input.includes("krytina") && input.includes("piatok")) {
      setTasks((all) => all.map((task) => [1, 3, 4].includes(task.id) ? { ...task, status: "WAITING MATERIAL" as Status, note: "Krytina potvrdená na piatok" } : task));
      setNotice("Prepočítané: krytina a 2 nadväzujúce úlohy presunuté");
    } else {
      setNotice("Zmena zapísaná. Solver našiel 2 dotknuté väzby.");
    }
    setCommand("");
  }

  function finishTask(id: number) {
    setTasks((all) => all.map((task) => task.id === id ? { ...task, status: "DONE" as Status, progress: 100 } : task));
    setSelected(null);
    setNotice("Skutočný čas uložený. Nasledujúca úloha je pripravená.");
  }

  function moveTask(worker: string) {
    if (dragged === null) return;
    setTasks((all) => all.map((task) => task.id === dragged ? { ...task, worker } : task));
    setNotice(`Úloha presunutá na ${worker}. Kapacita a väzby prepočítané.`);
    setDragged(null);
  }

  function openWheel(title: string, value: number, unit: string, step: number, onApply: (next: number) => void) {
    setWheel({ title, value, unit, step, onApply });
  }

  function turnWheel(delta: number) {
    setWheel((current) => current ? { ...current, value: Math.max(current.step, current.value + delta * current.step) } : null);
  }

  function startWheel(event: React.PointerEvent<HTMLDivElement>) {
    const box = event.currentTarget.getBoundingClientRect();
    wheelDrag.current = { angle: Math.atan2(event.clientY - (box.top + box.height / 2), event.clientX - (box.left + box.width / 2)) * 180 / Math.PI, remainder: 0 };
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function moveWheel(event: React.PointerEvent<HTMLDivElement>) {
    if (!wheelDrag.current) return;
    const box = event.currentTarget.getBoundingClientRect();
    const angle = Math.atan2(event.clientY - (box.top + box.height / 2), event.clientX - (box.left + box.width / 2)) * 180 / Math.PI;
    let delta = angle - wheelDrag.current.angle;
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;
    wheelDrag.current.angle = angle;
    wheelDrag.current.remainder += delta;
    const steps = Math.trunc(wheelDrag.current.remainder / 5);
    if (steps) {
      turnWheel(steps);
      wheelDrag.current.remainder -= steps * 5;
    }
  }

  function updateTaskDuration(task: Task, minutes: number) {
    const nextEnd = task.start + minutes / 60;
    setTasks((all) => all.map((item) => item.id === task.id ? { ...item, end: nextEnd } : item));
    setSelected({ ...task, end: nextEnd });
    setNotice(`Trvanie úlohy „${task.name}“ nastavené na ${minutes} min. Harmonogram prepočítaný.`);
  }

  const dayLabel = dateOffset === 0 ? "Dnes, piatok 7. augusta" : dateOffset === 1 ? "Sobota 8. augusta" : "Štvrtok 6. augusta";

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="brand-mark">S</span><span>stav<span>flow</span></span></div>
        <nav aria-label="Hlavná navigácia">
          <button className="nav-item active"><span>⌁</span> Harmonogram</button>
          <button className="nav-item"><span>▣</span> Zákazky <b>6</b></button>
          <button className="nav-item"><span>♙</span> Tím</button>
          <button className="nav-item"><span>◇</span> Materiál <i>3</i></button>
          <button className="nav-item"><span>▱</span> Boxy & náradie</button>
          <button className="nav-item"><span>⚙</span> Mechanizácia <em>M 4</em></button>
          <button className="nav-item" onClick={() => setSettingsOpen(true)}><span>◉</span> Nastavenia solvera</button>
        </nav>
        <div className="sidebar-spacer" />
        <div className="solver-card">
          <div><span className="pulse" /> Solver online</div>
          <p>Posledný prepočet pred 2 min.</p>
        </div>
        <button className="nav-item small"><span>?</span> Pomoc a pravidlá</button>
        <div className="profile"><div className="avatar dark">MN</div><div><strong>Michal Novák</strong><small>Majiteľ firmy</small></div><span>⋮</span></div>
      </aside>

      <section className="workspace">
        <header className="topbar">
          <div><h1>Výrobný harmonogram</h1><p>Plánovanie ľudí, materiálu a nadväzností</p></div>
          <div className="top-actions"><button className="icon-btn settings-trigger" onClick={() => setSettingsOpen(true)} aria-label="Nastavenia solvera">⚙</button><button className="icon-btn" aria-label="Upozornenia">♢<b>{alerts}</b></button><button className="primary-btn" onClick={() => document.getElementById("command")?.focus()}>＋ Nová úloha</button></div>
        </header>

        <div className="control-row">
          <div className="date-control"><button onClick={() => setDateOffset(-1)}>‹</button><button className="calendar">▦</button><div><span>{dayLabel}</span><small>Týždeň 32</small></div><button onClick={() => setDateOffset(1)}>›</button></div>
          <div className="view-switch" role="tablist">
            <button className={view === "people" ? "active" : ""} onClick={() => setView("people")}>♙ Podľa ľudí</button>
            <button className={view === "projects" ? "active" : ""} onClick={() => setView("projects")}>▣ Podľa stavby</button>
            <button className={view === "card" ? "active" : ""} onClick={() => setView("card")}>▤ Pracovná karta</button>
          </div>
          <button className="filter-btn">≡ Filtre <span>2</span></button>
        </div>

        <div className="command-bar">
          <span className="ai-mark">✦</span>
          <input id="command" value={command} onChange={(e) => setCommand(e.target.value)} onKeyDown={(e) => e.key === "Enter" && applyCommand()} placeholder="Napíšte zmenu… napr. „Vlado zajtra nepríde“" />
          <button className="mic" aria-label="Hlasové zadanie">●</button>
          <button className="solve-btn" onClick={applyCommand}>Prepočítať <span>⌘↵</span></button>
        </div>

        <div className="notice"><span>✦</span><strong>{notice}</strong><span className="notice-link">Zobraziť kritické body →</span></div>

        {view === "people" && (
          <section className="board-card">
            <div className="board-head"><div><h2>Kapacita tímu</h2><span>{Math.round(totalHours)} z 36 hodín naplánovaných</span></div><div className="legend"><span><i className="dot expert" /> Odborná</span><span><i className="dot assembly" /> Montáž</span><span><i className="dot logistics" /> Logistika</span><span><i className="dot blocked" /> Problém</span></div></div>
            <div className="timeline-header"><div className="person-col">PRACOVNÍK / STAVBA</div><div className="hours">{[7,8,9,10,11,12,13,14,15,16,17].map((h) => <span key={h}>{String(h).padStart(2,"0")}:00</span>)}</div></div>
            <div className="timeline-body">
              <div className="now-line"><span>TERAZ 10:35</span></div>
              {people.map((person) => (
                <div className="person-row" key={person.name} onDragOver={(e) => e.preventDefault()} onDrop={() => moveTask(person.name)}>
                  <div className="person-info"><div className="avatar" style={{ background: person.color }}>{person.initials}</div><div><strong>{person.name}</strong><span>{person.role}</span><small>{tasks.find((t) => t.worker === person.name)?.project}</small></div></div>
                  <div className="track">
                    {tasks.filter((task) => task.worker === person.name).map((task) => (
                      <button draggable onDragStart={() => setDragged(task.id)} onClick={() => setSelected(task)} key={task.id} className={`task ${task.type} ${task.status === "BLOCKED" ? "is-blocked" : ""} ${task.status === "DONE" ? "done" : ""}`} style={{ left: `${((task.start - 7) / 10) * 100}%`, width: `${((task.end - task.start) / 10) * 100}%` }}>
                        <strong>{task.name}</strong><span>{time(task.start)}–{time(task.end)} · {task.project}</span>
                        {task.progress && task.status === "IN PROGRESS" ? <i className="progress" style={{ width: `${task.progress}%` }} /> : null}
                        {task.mechanizable ? <em title="Kandidát na mechanizáciu">M</em> : null}
                        {task.status === "BLOCKED" || task.status === "WAITING MATERIAL" ? <b title={task.note}>!</b> : null}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="board-foot"><span>↔ Potiahnutím presuňte úlohu inému pracovníkovi</span><strong><i /> 2 konflikty · 1 čakanie na materiál</strong></div>
          </section>
        )}

        {view === "projects" && (
          <section className="board-card project-view">
            <div className="board-head"><div><h2>Technologická postupnosť</h2><span>Zoskupené podľa stavieb a pracovných zón</span></div><button className="outline-btn">Zobraziť závislosti</button></div>
            <div className="timeline-header"><div className="person-col">STAVBA / STAV</div><div className="hours">{[7,8,9,10,11,12,13,14,15,16,17].map((h) => <span key={h}>{String(h).padStart(2,"0")}:00</span>)}</div></div>
            <div className="timeline-body">
              <div className="now-line"><span>TERAZ 10:35</span></div>
              {projectRows.map((project) => {
                const projectTasks = tasks.filter((task) => task.project === project);
                if (!projectTasks.length) return null;
                return <div className="person-row" key={project}>
                  <div className="project-info"><span className={`project-badge ${project.toLowerCase()}`}>{project.slice(0,2).toUpperCase()}</span><div><strong>{project}</strong><span>{projectTasks.length} úloh · {projectTasks.filter(t => t.status === "BLOCKED").length ? "blokácia" : "v procese"}</span></div></div>
                  <div className="track">{projectTasks.map((task, index) => <button key={task.id} onClick={() => setSelected(task)} className={`task compact ${task.type}`} style={{ left: `${((task.start - 7) / 10) * 100}%`, width: `${Math.max(((task.end-task.start)/10)*100, 7)}%`, top: `${6 + (index%2)*34}px` }}><strong>{task.name}</strong><span>{task.worker}</span>{index > 0 && <i className="dependency">‹</i>}</button>)}</div>
                </div>;
              })}
            </div>
          </section>
        )}

        {view === "card" && (
          <section className="worker-card-view">
            <div className="worker-list"><h2>Pracovná karta</h2><p>Jednoduchý plán pre pracovníka</p>{people.map((p) => <button key={p.name} className={cardWorker === p.name ? "active" : ""} onClick={() => setCardWorker(p.name)}><div className="avatar" style={{background:p.color}}>{p.initials}</div><span><strong>{p.name}</strong><small>{tasks.filter(t=>t.worker===p.name && t.status!=="DONE").length} úlohy dnes</small></span><b>›</b></button>)}</div>
            <div className="daily-card">
              <div className="daily-top"><span>DNES · {cardWorker.toUpperCase()}</span><div><i className="pulse" /> Plán aktuálny</div></div>
              {tasks.filter((t) => t.worker === cardWorker).slice(0,3).map((task, index) => <article className={index === 0 ? "current" : ""} key={task.id}>
                <div className="card-time"><strong>{time(task.start)}</strong><span>{time(task.end)}</span></div>
                <div className="card-main"><div className="card-label">{index === 0 ? "PRÁVE TERAZ" : index === 1 ? "NASLEDUJE" : "NESKÔR"}</div><h3>{task.name}</h3><p>{task.project} · {task.zone}</p><div className="needs"><div><span>Potrebujem</span><strong>▣ {task.box || "Bežné náradie"}</strong><small>Aku skrutkovač · meradlo</small></div><div><span>Výsledok</span><strong>✓ Dokončená pracovná zóna</strong><small>Kontrola geometrie a kotvenia</small></div></div>{index === 0 && <div className="card-actions"><button className="late" onClick={() => {setNotice("NESTÍHAM: zvyšok dňa bol prepočítaný"); setView("people")}}>⏱ NESTÍHAM</button><button className="done-btn" onClick={() => finishTask(task.id)}>✓ HOTOVO</button></div>}</div>
              </article>)}
            </div>
          </section>
        )}

        <section className="summary-grid">
          <div className="summary-card"><span className="summary-icon blue">↗</span><div><small>Využitie tímu</small><strong>82 %</strong><p><i className="up">↑ 6 %</i> oproti včerajšku</p></div><div className="ring">82</div></div>
          <div className="summary-card"><span className="summary-icon red">!</span><div><small>Kritické body</small><strong>{alerts}</strong><p>1 materiál · 1 rozhodnutie</p></div><button onClick={() => setSelected(tasks.find(t=>t.status === "BLOCKED") || null)}>Riešiť →</button></div>
          <div className="summary-card"><span className="summary-icon amber">M</span><div><small>Mechanizovateľné</small><strong>{tasks.filter(t=>t.mechanizable).length} úlohy</strong><p>2,5 h ľudskej práce</p></div><button onClick={() => setNotice("Backlog mechanizácie: vykládka, presun, podávanie, zdvih")}>Zobraziť →</button></div>
        </section>
      </section>

      {selected && <div className="drawer-backdrop" onClick={() => setSelected(null)}><aside className="drawer" onClick={(e) => e.stopPropagation()}><button className="drawer-close" onClick={() => setSelected(null)}>×</button><div className={`drawer-type ${selected.type}`}>{typeLabel[selected.type]}</div><h2>{selected.name}</h2><p className="drawer-sub">{selected.project} · {selected.zone}</p><div className="drawer-grid"><div><small>Pracovník</small><strong>{selected.worker}</strong></div><button className="numeric-tile" onClick={() => openWheel("Trvanie úlohy", Math.round((selected.end - selected.start) * 60), "min", solverSettings.timeStep, (value) => updateTaskDuration(selected, value))}><small>Trvanie · otočiť kolieskom</small><strong>{Math.round((selected.end - selected.start) * 60)} min <i>◉</i></strong></button><div><small>Stav</small><strong className={`status ${selected.status.toLowerCase().replaceAll(" ", "-")}`}>{statusLabel[selected.status]}</strong></div><div><small>Istota trvania</small><strong>82 % · odhad</strong></div></div>{selected.note && <div className="warning"><b>!</b><span><strong>Vyžaduje pozornosť</strong>{selected.note}</span></div>}<h3>Pripravenosť</h3><ul className="checklist"><li className="ok">✓ Pracovný front pripravený</li><li className={selected.status === "WAITING MATERIAL" ? "bad" : "ok"}>{selected.status === "WAITING MATERIAL" ? "× Materiál ešte nie je v zóne" : "✓ Materiál pripravený v zóne"}</li><li className="ok">✓ {selected.box || "Náradie"} pripravené</li></ul><h3>Kontrola kvality</h3><p className="quality">Geometria, kotvenie a vizuálna kontrola detailu pred uvoľnením nadväzujúcej úlohy.</p><div className="drawer-actions"><button onClick={() => openWheel("Trvanie úlohy", Math.round((selected.end - selected.start) * 60), "min", solverSettings.timeStep, (value) => updateTaskDuration(selected, value))}>◉ Upraviť trvanie</button><button className="done-btn" onClick={() => finishTask(selected.id)}>✓ Označiť HOTOVO</button></div></aside></div>}

      {settingsOpen && <div className="modal-backdrop" onClick={() => setSettingsOpen(false)}><section className="settings-modal" onClick={(event) => event.stopPropagation()}><button className="drawer-close" onClick={() => setSettingsOpen(false)}>×</button><div className="settings-kicker">NASTAVENIA VÝROBNÉHO SOLVERA</div><h2>Číselné údaje bez klávesnice</h2><p>Ťuknite na hodnotu a nastavte ju otočným kolieskom. Zmena sa ihneď premietne do ďalšieho prepočtu.</p><div className="settings-list"><button onClick={() => openWheel("Dĺžka pracovného dňa", solverSettings.workday, "h", 0.5, (value) => setSolverSettings((s) => ({ ...s, workday: value }))) }><span><b>Pracovný deň</b><small>Dostupná kapacita pracovníka</small></span><strong>{solverSettings.workday.toLocaleString("sk-SK")} h <i>◉</i></strong></button><button onClick={() => openWheel("Plánovacia rezerva", solverSettings.buffer, "%", 1, (value) => setSolverSettings((s) => ({ ...s, buffer: value }))) }><span><b>Plánovacia rezerva</b><small>Ochrana pred sklzom úloh</small></span><strong>{solverSettings.buffer} % <i>◉</i></strong></button><button onClick={() => openWheel("Presun medzi stavbami", solverSettings.travel, "min", 5, (value) => setSolverSettings((s) => ({ ...s, travel: value }))) }><span><b>Presun medzi stavbami</b><small>Automatický logistický blok</small></span><strong>{solverSettings.travel} min <i>◉</i></strong></button><button onClick={() => openWheel("Krok plánovania", solverSettings.timeStep, "min", 5, (value) => setSolverSettings((s) => ({ ...s, timeStep: value }))) }><span><b>Krok plánovania</b><small>Presnosť časového pásu</small></span><strong>{solverSettings.timeStep} min <i>◉</i></strong></button></div><div className="settings-note"><span>✦</span><div><strong>Solver používa tieto hodnoty pri každej zmene.</strong><small>Bezpečnosť a technologické väzby majú vždy vyššiu prioritu.</small></div></div><button className="save-settings" onClick={() => { setSettingsOpen(false); setNotice("Nastavenia solvera uložené. Harmonogram bol prepočítaný."); }}>Uložiť a prepočítať</button></section></div>}

      {wheel && <div className="wheel-backdrop" onClick={() => setWheel(null)}><section className="wheel-dialog" onClick={(event) => event.stopPropagation()}><div className="wheel-symbol" /><div className="wheel-kicker">OTOČNÉ NASTAVENIE</div><h2>{wheel.title}</h2><div className="wheel-value">{wheel.value.toLocaleString("sk-SK")} <small>{wheel.unit}</small></div><div className="rotary-wrap"><button onClick={() => turnWheel(-1)} aria-label="Znížiť hodnotu">−</button><div className="rotary" role="slider" tabIndex={0} aria-label={wheel.title} aria-valuenow={wheel.value} onPointerDown={startWheel} onPointerMove={moveWheel} onPointerUp={() => { wheelDrag.current = null; }} onPointerCancel={() => { wheelDrag.current = null; }} onKeyDown={(event) => { if (event.key === "ArrowUp" || event.key === "ArrowRight") turnWheel(1); if (event.key === "ArrowDown" || event.key === "ArrowLeft") turnWheel(-1); }} style={{ "--dial-angle": `${((wheel.value / wheel.step) * 18) % 360}deg` } as React.CSSProperties}><span>STAVFLOW</span></div><button onClick={() => turnWheel(1)} aria-label="Zvýšiť hodnotu">＋</button></div><p>Otáčajte kolieskom bez horného obmedzenia · krok {wheel.step.toLocaleString("sk-SK")} {wheel.unit}</p><div className="wheel-actions"><button onClick={() => setWheel(null)}>Zrušiť</button><button onClick={() => { wheel.onApply(wheel.value); setWheel(null); }}>Použiť hodnotu</button></div></section></div>}
    </main>
  );
}
