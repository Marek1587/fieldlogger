import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingProperties = Properties()
val signingPropertiesFile = rootProject.file("signing.properties")
if (signingPropertiesFile.exists()) {
    signingPropertiesFile.inputStream().use { signingProperties.load(it) }
}

val signingKeyFile = rootProject.file(
    signingProperties.getProperty("storeFile", "app/latovanie-update-key.jks")
)
val signingStorePassword = signingProperties.getProperty("storePassword", "")
val signingKeyAlias = signingProperties.getProperty("keyAlias", "")
val signingKeyPassword = signingProperties.getProperty("keyPassword", "")

if (!signingKeyFile.exists() || signingStorePassword.isBlank() || signingKeyAlias.isBlank() || signingKeyPassword.isBlank()) {
    throw GradleException(
        "Chýba bezpečná konfigurácia podpisu. Vytvorte signing.properties a dodajte pôvodný JKS kľúč."
    )
}

android {
    namespace = "sk.latovanie.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.latovanie.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "2.0.1"

        val secrets = Properties()
        val secretsFile = rootProject.file("secrets.properties")
        if (secretsFile.exists()) {
            secretsFile.inputStream().use { secrets.load(it) }
        }
        manifestPlaceholders["MAPS_API_KEY"] = secrets.getProperty("MAPS_API_KEY", "")
    }

    signingConfigs {
        create("stableUpdate") {
            storeFile = signingKeyFile
            storePassword = signingStorePassword
            keyAlias = signingKeyAlias
            keyPassword = signingKeyPassword
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("stableUpdate")
            applicationIdSuffix = ""
        }
        release {
            signingConfig = signingConfigs.getByName("stableUpdate")
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("androidx.core:core:1.15.0")
}
