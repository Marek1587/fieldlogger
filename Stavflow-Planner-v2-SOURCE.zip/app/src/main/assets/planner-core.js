(function (root, factory) {
  const api = factory();
  if (typeof module === "object" && module.exports) module.exports = api;
  root.StrechoCore = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  const SCHEMA_VERSION = 2;

  function uuid() {
    if (globalThis.crypto && typeof globalThis.crypto.randomUUID === "function") {
      return globalThis.crypto.randomUUID();
    }
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
      const r = Math.random() * 16 | 0;
      return (c === "x" ? r : (r & 3 | 8)).toString(16);
    });
  }

  function nowIso() { return new Date().toISOString(); }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function minutes(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number) && number >= 0 ? number : (fallback || 0);
  }

  function defaultCalendar() {
    return {
      id: uuid(), name: "Stavebný deň", start: "08:00", lunchStart: "12:00",
      lunchEnd: "12:30", end: "17:00", workingDays: [1, 2, 3, 4, 5], splitPolicy: "smart"
    };
  }

  function emptyState() {
    const calendar = defaultCalendar();
    return {
      schemaVersion: SCHEMA_VERSION,
      projects: [], sections: [], tasks: [], workers: [], calendars: [calendar],
      activeProjectId: null, projectStart: {}, updatedAt: nowIso()
    };
  }

  function createProject(state, name, fields) {
    const stamp = nowIso();
    const project = Object.assign({
      id: uuid(), name: String(name || "Nová stavba").trim() || "Nová stavba",
      address: "", customer: "", description: "", createdAt: stamp, updatedAt: stamp, archived: false
    }, fields || {});
    state.projects.push(project);
    state.projectStart[project.id] = nextMondayIso();
    return project;
  }

  function createTask(state, projectId, name, fields) {
    const stamp = nowIso();
    const projectTasks = state.tasks.filter(t => t.projectId === projectId);
    const task = Object.assign({
      id: uuid(), projectId, name: String(name || "Nová úloha").trim() || "Nová úloha",
      originalOrder: projectTasks.length + 1, sectionId: null, orderInSection: null,
      estimatedMinutes: null, assignedWorkerId: null, plannedStart: null, plannedEnd: null,
      status: "NEW", tools: [], materials: [], fabrications: [], createdAt: stamp, updatedAt: stamp
    }, fields || {});
    state.tasks.push(task);
    return task;
  }

  function bulkCreateTasks(state, projectId, text) {
    return String(text || "").split(/\r?\n/).map(line => line.trim()).filter(Boolean)
      .map(name => createTask(state, projectId, name));
  }

  function createSection(state, projectId, name, color) {
    const stamp = nowIso();
    const order = state.sections.filter(s => s.projectId === projectId).length + 1;
    const section = { id: uuid(), projectId, name: String(name || "Nová sekcia").trim() || "Nová sekcia", color: color || "#3182ce", order, createdAt: stamp, updatedAt: stamp };
    state.sections.push(section);
    return section;
  }

  function createWorker(state, name, color, calendarId) {
    const worker = { id: uuid(), name: String(name || "Pracovník").trim() || "Pracovník", color: color || "#f97316", workingCalendarId: calendarId || state.calendars[0].id, active: true };
    state.workers.push(worker);
    return worker;
  }

  function normalizeOrders(state, projectId) {
    const sections = state.sections.filter(s => s.projectId === projectId).sort((a, b) => a.order - b.order);
    sections.forEach((section, index) => { section.order = index + 1; });
    const unassigned = state.tasks.filter(t => t.projectId === projectId && !t.sectionId).sort((a, b) => a.originalOrder - b.originalOrder);
    unassigned.forEach((task, index) => { task.originalOrder = index + 1; task.orderInSection = null; });
    sections.forEach(section => {
      const tasks = state.tasks.filter(t => t.projectId === projectId && t.sectionId === section.id)
        .sort((a, b) => (a.orderInSection || a.originalOrder) - (b.orderInSection || b.originalOrder));
      tasks.forEach((task, index) => { task.orderInSection = index + 1; });
    });
    state.updatedAt = nowIso();
    return state;
  }

  function displayCode(state, task) {
    if (!task || !task.sectionId) return "—";
    const section = state.sections.find(s => s.id === task.sectionId);
    return section ? `${section.order}.${task.orderInSection || 0}` : "—";
  }

  function reorderIds(items, orderedIds, field) {
    const index = new Map(orderedIds.map((id, i) => [id, i + 1]));
    items.forEach(item => { if (index.has(item.id)) item[field] = index.get(item.id); });
  }

  function parseClock(value) {
    const parts = String(value || "00:00").split(":").map(Number);
    return (parts[0] || 0) * 60 + (parts[1] || 0);
  }

  function atMinute(date, minute) {
    const d = new Date(date); d.setHours(Math.floor(minute / 60), minute % 60, 0, 0); return d;
  }

  function dayIntervals(date, calendar) {
    if (!calendar.workingDays.includes(new Date(date).getDay())) return [];
    const start = parseClock(calendar.start), end = parseClock(calendar.end);
    const lunchStart = parseClock(calendar.lunchStart), lunchEnd = parseClock(calendar.lunchEnd);
    if (lunchStart > start && lunchEnd < end && lunchEnd > lunchStart) {
      return [[atMinute(date, start), atMinute(date, lunchStart)], [atMinute(date, lunchEnd), atMinute(date, end)]];
    }
    return [[atMinute(date, start), atMinute(date, end)]];
  }

  function nextWorkingTime(input, calendar) {
    let date = new Date(input);
    for (let guard = 0; guard < 370; guard++) {
      const intervals = dayIntervals(date, calendar);
      for (const interval of intervals) {
        if (date <= interval[0]) return new Date(interval[0]);
        if (date > interval[0] && date < interval[1]) return date;
      }
      date.setDate(date.getDate() + 1); date.setHours(0, 0, 0, 0);
    }
    throw new Error("Pracovný kalendár nemá dostupný deň.");
  }

  function capacityPerDay(calendar) {
    return (parseClock(calendar.end) - parseClock(calendar.start)) - Math.max(0, parseClock(calendar.lunchEnd) - parseClock(calendar.lunchStart));
  }

  function remainingToday(input, calendar) {
    const date = nextWorkingTime(input, calendar);
    return dayIntervals(date, calendar).reduce((sum, interval) => {
      const start = Math.max(date.getTime(), interval[0].getTime());
      return sum + Math.max(0, Math.round((interval[1].getTime() - start) / 60000));
    }, 0);
  }

  function addWorkingMinutes(input, amount, calendar, splitPolicy) {
    let date = nextWorkingTime(input, calendar), remaining = Math.max(0, Math.round(amount));
    const policy = splitPolicy || calendar.splitPolicy || "smart";
    const shouldKeepWhole = policy === "whole" || (policy === "smart" && remaining <= 120);
    if (shouldKeepWhole && remaining <= capacityPerDay(calendar) && remaining > remainingToday(date, calendar)) {
      date.setDate(date.getDate() + 1); date.setHours(0, 0, 0, 0); date = nextWorkingTime(date, calendar);
    }
    const start = new Date(date), segments = [];
    while (remaining > 0) {
      date = nextWorkingTime(date, calendar);
      const interval = dayIntervals(date, calendar).find(pair => date >= pair[0] && date < pair[1]);
      if (!interval) continue;
      const available = Math.max(0, Math.round((interval[1].getTime() - date.getTime()) / 60000));
      const used = Math.min(remaining, available);
      const segmentStart = new Date(date); date = new Date(date.getTime() + used * 60000);
      segments.push({ start: segmentStart.toISOString(), end: date.toISOString(), minutes: used });
      remaining -= used;
      if (remaining > 0) date = nextWorkingTime(new Date(date.getTime() + 60000), calendar);
    }
    return { start, end: date, segments };
  }

  function maxDate(a, b) { return new Date(Math.max(new Date(a).getTime(), new Date(b).getTime())); }
  function projectCalendar(state) { return state.calendars[0] || defaultCalendar(); }
  function workerCalendar(state, workerId) {
    const worker = state.workers.find(w => w.id === workerId);
    return state.calendars.find(c => c.id === (worker && worker.workingCalendarId)) || projectCalendar(state);
  }

  function orderedSectionTasks(state, projectId) {
    return state.sections.filter(s => s.projectId === projectId).sort((a, b) => a.order - b.order).map(section => ({
      section,
      tasks: state.tasks.filter(t => t.projectId === projectId && t.sectionId === section.id).sort((a, b) => a.orderInSection - b.orderInSection)
    }));
  }

  function baselineSchedule(state, projectId, startIso) {
    const calendar = projectCalendar(state), start = nextWorkingTime(startIso || state.projectStart[projectId] || new Date(), calendar);
    let cursor = new Date(start); const assignments = [];
    orderedSectionTasks(state, projectId).forEach(group => group.tasks.forEach(task => {
      const duration = minutes(task.estimatedMinutes);
      const planned = addWorkingMinutes(cursor, duration, calendar);
      assignments.push({ taskId: task.id, workerId: "virtual", sectionId: group.section.id, start: planned.start.toISOString(), end: planned.end.toISOString(), minutes: duration, segments: planned.segments });
      cursor = planned.end;
    }));
    return { projectStart: start.toISOString(), projectEnd: cursor.toISOString(), totalWorkingMinutes: assignments.reduce((sum, a) => sum + a.minutes, 0), assignments };
  }

  function parallelSchedule(state, projectId, startIso) {
    const groups = orderedSectionTasks(state, projectId).filter(group => group.tasks.length);
    const start = nextWorkingTime(startIso || state.projectStart[projectId] || new Date(), projectCalendar(state));
    const heads = new Map(groups.map(group => [group.section.id, 0]));
    const sectionReady = new Map(groups.map(group => [group.section.id, new Date(start)]));
    const workerReady = new Map(); const assignments = [];
    while ([...heads.values()].reduce((sum, value) => sum + value, 0) < groups.reduce((sum, group) => sum + group.tasks.length, 0)) {
      const candidates = [];
      for (const group of groups) {
        const index = heads.get(group.section.id);
        if (index >= group.tasks.length) continue;
        const task = group.tasks[index];
        const assignedWorker = state.workers.find(worker => worker.id === task.assignedWorkerId && worker.active);
        const workerId = assignedWorker ? assignedWorker.id : "unassigned";
        const calendar = workerCalendar(state, workerId);
        const ready = maxDate(sectionReady.get(group.section.id), workerReady.get(workerId) || start);
        candidates.push({ group, task, workerId, calendar, ready: nextWorkingTime(ready, calendar) });
      }
      candidates.sort((a, b) => a.ready - b.ready || a.group.section.order - b.group.section.order);
      const candidate = candidates[0]; if (!candidate) break;
      const duration = minutes(candidate.task.estimatedMinutes);
      const planned = addWorkingMinutes(candidate.ready, duration, candidate.calendar);
      const assignment = { taskId: candidate.task.id, workerId: candidate.workerId, sectionId: candidate.group.section.id, start: planned.start.toISOString(), end: planned.end.toISOString(), minutes: duration, segments: planned.segments };
      assignments.push(assignment);
      heads.set(candidate.group.section.id, heads.get(candidate.group.section.id) + 1);
      sectionReady.set(candidate.group.section.id, planned.end);
      workerReady.set(candidate.workerId, planned.end);
    }
    const end = assignments.length ? new Date(Math.max(...assignments.map(a => new Date(a.end).getTime()))) : start;
    return { projectStart: start.toISOString(), projectEnd: end.toISOString(), totalWorkingMinutes: assignments.reduce((sum, a) => sum + a.minutes, 0), assignments };
  }

  function applySchedule(state, schedule) {
    const byTask = new Map(schedule.assignments.map(a => [a.taskId, a]));
    state.tasks.forEach(task => {
      const assignment = byTask.get(task.id);
      if (assignment) { task.plannedStart = assignment.start; task.plannedEnd = assignment.end; }
    });
    return schedule;
  }

  function aggregatePurchases(state, projectId) {
    const groups = new Map();
    state.tasks.filter(t => t.projectId === projectId).forEach(task => (task.materials || []).filter(item => item.purchaseRequired).forEach(item => {
      const supplier = String(item.supplierName || "Bez dodávateľa").trim();
      const name = String(item.name || "").trim(), unit = String(item.unit || "").trim();
      const key = `${supplier}\u0000${name}\u0000${unit}`;
      if (!groups.has(key)) groups.set(key, { supplier, name, unit, quantity: 0, sources: [] });
      const group = groups.get(key), quantity = Number(item.quantity) || 0;
      group.quantity += quantity; group.sources.push({ taskId: task.id, quantity, code: displayCode(state, task), taskName: task.name });
    }));
    const suppliers = new Map();
    [...groups.values()].forEach(item => { if (!suppliers.has(item.supplier)) suppliers.set(item.supplier, { supplier: item.supplier, items: [] }); suppliers.get(item.supplier).items.push(item); });
    return [...suppliers.values()].sort((a, b) => a.supplier.localeCompare(b.supplier));
  }

  function aggregateFabrications(state, projectId) {
    const headers = new Map();
    state.tasks.filter(t => t.projectId === projectId).forEach(task => (task.fabrications || []).forEach(item => {
      const place = String(item.fabricationPlace || "Bez miesta").trim(), material = String(item.material || "").trim();
      const color = String(item.color || "").trim(), thickness = String(item.thickness || "").trim();
      const headerKey = `${place}\u0000${material}\u0000${color}\u0000${thickness}`;
      if (!headers.has(headerKey)) headers.set(headerKey, { fabricationPlace: place, material, color, thickness, items: [] });
      const header = headers.get(headerKey), name = String(item.name || "").trim(), unit = String(item.unit || "").trim();
      let row = header.items.find(existing => existing.name === name && existing.unit === unit && existing.dimensions === String(item.dimensions || "").trim());
      if (!row) { row = { name, unit, dimensions: String(item.dimensions || "").trim(), quantity: 0, sources: [] }; header.items.push(row); }
      const quantity = Number(item.quantity) || 0; row.quantity += quantity; row.sources.push({ taskId: task.id, quantity, code: displayCode(state, task), taskName: task.name });
    }));
    return [...headers.values()].sort((a, b) => a.fabricationPlace.localeCompare(b.fabricationPlace));
  }

  function nextMondayIso() {
    const date = new Date(); date.setHours(8, 0, 0, 0);
    const offset = (8 - date.getDay()) % 7 || 7; date.setDate(date.getDate() + offset); return date.toISOString();
  }

  function seedState() {
    const state = emptyState(), project = createProject(state, "Pompura", { address: "Stará Ľubovňa", customer: "Pompura" });
    state.activeProjectId = project.id;
    const roof = createSection(state, project.id, "Strecha pri múre", "#3182ce");
    const veranda = createSection(state, project.id, "Veranda", "#38a169");
    const chimney = createSection(state, project.id, "Komín", "#805ad5");
    const marek = createWorker(state, "Marek", "#f97316"), vlado = createWorker(state, "Vlado", "#38a169"), otec = createWorker(state, "Otec", "#805ad5");
    [
      [roof,"Montáž hákov",120,marek],[roof,"Montáž žľabu",180,marek],[roof,"Montáž podkladového plechu",90,marek],
      [roof,"Montáž krytiny",240,marek],[veranda,"Fólia a kontralaty",180,vlado],[veranda,"Latovanie",180,vlado],
      [veranda,"Krytina na verande",240,vlado],[chimney,"Zameranie komína",60,otec],[chimney,"Výroba lemovania",150,otec],[chimney,"Oplechovanie komína",180,otec]
    ].forEach((row, i) => createTask(state, project.id, row[1], { sectionId: row[0].id, orderInSection: state.tasks.filter(t => t.sectionId === row[0].id).length + 1, estimatedMinutes: row[2], assignedWorkerId: row[3].id, originalOrder: i + 1 }));
    const first = state.tasks[0];
    first.tools.push({ id: uuid(), taskId: first.id, name: "Aku skrutkovač", quantity: 1, note: "" });
    first.materials.push({ id: uuid(), taskId: first.id, name: "Žľabový hák", quantity: 15, unit: "ks", supplierName: "KJG", purchaseRequired: true, note: "" });
    state.tasks[1].materials.push({ id: uuid(), taskId: state.tasks[1].id, name: "Skrutka RA", quantity: 50, unit: "ks", supplierName: "KJG", purchaseRequired: true, note: "" });
    state.tasks[3].materials.push({ id: uuid(), taskId: state.tasks[3].id, name: "Skrutka RA", quantity: 70, unit: "ks", supplierName: "KJG", purchaseRequired: true, note: "" });
    state.tasks[8].fabrications.push({ id: uuid(), taskId: state.tasks[8].id, name: "Záveterná lišta", quantity: 10, unit: "bm", material: "Plech", color: "RAL 7016", thickness: "0,50 mm", dimensions: "r.š. 330 mm", fabricationPlace: "KJG", note: "" });
    normalizeOrders(state, project.id); return state;
  }

  function migrateState(input) {
    if (!input || typeof input !== "object") return seedState();
    const state = Object.assign(emptyState(), input);
    state.schemaVersion = SCHEMA_VERSION;
    state.projects = state.projects || []; state.sections = state.sections || []; state.tasks = state.tasks || []; state.workers = state.workers || [];
    state.tasks.forEach(task => { task.tools = task.tools || []; task.materials = task.materials || []; task.fabrications = task.fabrications || []; });
    state.projects.forEach(project => normalizeOrders(state, project.id));
    return state;
  }

  class PlanningAssistant {
    suggestTasks() { return []; }
    suggestDurations() { return []; }
    suggestTools() { return []; }
    suggestMaterials() { return []; }
  }
  class NoOpPlanningAssistant extends PlanningAssistant {}

  return {
    SCHEMA_VERSION, uuid, clone, emptyState, seedState, migrateState, createProject, createTask,
    bulkCreateTasks, createSection, createWorker, normalizeOrders, displayCode, reorderIds,
    defaultCalendar, capacityPerDay, nextWorkingTime, addWorkingMinutes, baselineSchedule,
    parallelSchedule, applySchedule, aggregatePurchases, aggregateFabrications,
    PlanningAssistant, NoOpPlanningAssistant
  };
});
