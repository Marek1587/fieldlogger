import type { Metadata } from "next";
import { Manrope } from "next/font/google";
import "./globals.css";

const manrope = Manrope({ variable: "--font-manrope", subsets: ["latin", "latin-ext"] });

export const metadata: Metadata = {
  title: "Stavflow — Stavebný plánovací solver",
  description: "Dynamický výrobný harmonogram pre malú stavebnú firmu.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="sk"><body className={manrope.variable}>{children}</body></html>;
}
