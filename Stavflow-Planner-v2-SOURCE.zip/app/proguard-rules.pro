-keepclassmembers class sk.latovanie.app.MainActivity$LatovanieBridge {
    @android.webkit.JavascriptInterface <methods>;
}
