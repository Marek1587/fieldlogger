# StrechoStav Planner — Implementation Plan

## 1. Dátový model

- `Project`: stabilné UUID, názov, adresa, zákazník, popis, timestamps, archívny stav.
- `Task`: stabilné UUID, `projectId`, názov, globálne poradie, voliteľná sekcia,
  poradie v sekcii, trvanie v minútach, pracovník, vypočítané termíny, stav a zdroje.
- `Section`: stabilné UUID, `projectId`, názov, farba, poradie a timestamps.
- `Worker`: stabilné UUID, meno, farba, kalendár a aktívny stav.
- Zdroje úlohy sú samostatné kolekcie: `tools`, `materials`, `fabrications`.
- Viditeľný kód úlohy sa vždy počíta z poradia sekcie a poradia úlohy; nikdy nie je ID.

## 2. Routing / obrazovky

- Vstupná obrazovka `Stavby`.
- Po otvorení projektu horizontálny workflow: Úlohy, Poradie, Sekcie, Spresnenie,
  Kto & kedy, Nákupy, Výroba, Harmonogram.
- Obrazovky sa prepínajú lokálnym routerom bez servera a bez externého API.
- Detail úlohy a numerické pickery sú modálne bottom sheets použiteľné jednou rukou.

## 3. State management

- Jeden normalizovaný stav projektu v JavaScripte.
- Každá mutácia ide cez `commitAction()`: uloží undo snapshot, aplikuje zmenu,
  prepočíta poradia, baseline a harmonogram a vykoná autosave do `localStorage`.
- Undo podporuje presuny úloh, zaradenie do sekcie, poradie sekcií a zmenu pracovníka.
- Exportovaná čistá dátová logika nemá závislosť od DOM ani Android WebView.

## 4. Solver

- Baseline: sekcie podľa `order`, úlohy podľa `orderInSection`, jeden virtuálny pracovník.
- Paralelný plán: úlohy v jednej sekcii sú sekvenčné, sekcie sú nezávislé.
- Pracovník a sekcia majú vlastný čas dostupnosti; ďalšia úloha začne v maxime oboch.
- Kalendár podporuje začiatok/koniec dňa, obednú prestávku a politiku delenia úloh.
- Výsledok vždy obsahuje čisté minúty, začiatok, koniec a priradenia.

## 5. Drag-and-drop

- Desktop: natívny drag-and-drop.
- Mobil: pointer long-press, vizuálny ghost, zvýraznenie cieľa a pustenie.
- Rovnaký mechanizmus obslúži poradie úloh, presun do sekcie, poradie sekcií
  a priradenie pracovníkovi.
- Každá operácia vytvorí snackbar s možnosťou VRÁTIŤ.

## 6. Gantt

- Ľavá identifikačná časť: pracovník, úloha, stavba.
- Pravá horizontálne scrollovateľná časová os.
- Blok používa farbu sekcie, nie pracovníka; dĺžka vychádza z vypočítaného času.
- Tap na blok otvorí detail úlohy.

## 7. Migrácia

- Existujúce demo dáta sa nahradia novým seed projektom iba pri prvom spustení.
- Stav bez verzie dostane `schemaVersion` a bezpečne sa skonvertuje na nové kolekcie.
- Žiadne staré poradie ani číselný kód sa nepoužije ako primárny kľúč.
- Android/Gradle wrapper, offline WebView a oranžový vizuálny systém zostávajú zachované.

## 8. Testy

- Baseline 12 h vs. dve paralelné sekcie po 6 h.
- Prečíslovanie sekcií bez zmeny UUID.
- Presná agregácia nákupu podľa dodávateľa, názvu a jednotky.
- Zoskupenie klampiarskej výroby podľa miesta, materiálu, farby a hrúbky.
