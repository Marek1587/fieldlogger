# Stavflow Planner 2.0 — Android

Offline Android aplikácia pre operatívne plánovanie malej stavebnej firmy.

## Funkcie

- harmonogram podľa pracovníkov, stavieb a pracovnej karty,
- technologické blokácie, materiálové čakania a M-backlog mechanizácie,
- reakcie HOTOVO a NESTÍHAM,
- prepočet po textovej operatívnej zmene,
- oranžovo-krémový pracovný dizajn,
- nastavovanie numerických údajov otočným kolieskom,
- lokálne uchovanie rozpracovaného plánu,
- offline WebView bez externého servera.

## Kompatibilita s dodaným GitHub Actions workflow

ZIP obsahuje Android projekt priamo v koreňovom priečinku. Po rozbalení sú teda
okamžite dostupné súbory `settings.gradle.kts`, `build.gradle.kts` a priečinok
`app`.

Workflow vytvorí v koreňovom priečinku súbor `secrets.properties`:

```text
MAPS_API_KEY=AIza...
```

Gradle túto hodnotu načíta a vloží do manifestu cez placeholder `MAPS_API_KEY`.

## Zostavenie

Požiadavky: Java 17, Android SDK 35 a Gradle 8.10.2.

```text
gradle :app:assembleDebug --stacktrace
```

Výsledok:

```text
app/build/outputs/apk/debug/app-debug.apk
```
