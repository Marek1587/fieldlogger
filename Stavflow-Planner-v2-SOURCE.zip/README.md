# Planner — Android

Mobilný plánovač stavebných prác, ktorý vytvorí harmonogram postupne zo surového zoznamu úloh. Základné fungovanie je lokálne a nevyžaduje GPT ani OpenAI API.

Aktuálna verzia: `2.0.2` (`versionCode 11`).

## Hlavné funkcie

- stavby a hromadné zadanie úloh po riadkoch,
- zoraďovanie úloh a farebných technologických sekcií,
- dynamické číslovanie bez zmeny stabilných UUID,
- trvania nastavované mobilným kolieskom a rýchlymi voľbami,
- náradie, materiály, nákupy a klampiarska výroba,
- baseline jedného pracovníka a paralelný deterministický solver,
- pracovnícke denné plány a mobilný Gantt,
- autosave a vrátenie posledného presunu.

## Mobilná použiteľnosť

- bežné obrazovky neprekračujú šírku viewportu; horizontálne sa posúvajú iba explicitné pásy a Gantt,
- nezaradené úlohy a technologické sekcie sú vertikálne pod sebou,
- dlhé názvy sa zalamujú bez rozširovania karty,
- drag-and-drop používa dotykové podržanie, viditeľný overlay, zvýraznenie cieľa a automatický vertikálny scroll,
- po dropnutí sa stav zmení okamžite a autosave sa vykoná s 450 ms debounce,
- na obrazovke Sekcie zostáva dostupný aj fallback: ťuknúť na úlohu a potom na cieľovú sekciu.
- Android WebView má explicitne vypnutý široký viewport a overview zoom; CSS grid tracky majú nulové minimum, aby min-content šírka nerozťahovala dokument.

## Identita a podpis aplikácie

- názov aplikácie: `Planner`,
- application ID: `sk.latovanie.app`,
- debug aj release používajú pôvodný podpis, aby bol balík kompatibilný s aktualizáciou pôvodnej aplikácie,
- súkromný JKS kľúč nie je vložený v zdrojovom ZIP-e; GitHub Actions ho bezpečne obnoví zo secretu `SIGNING_KEYSTORE_BASE64`.

V GitHub repozitári nastavte štyri Actions secrets:

- `SIGNING_KEYSTORE_BASE64` — pôvodný JKS súbor zakódovaný ako Base64,
- `SIGNING_STORE_PASSWORD`,
- `SIGNING_KEY_ALIAS`,
- `SIGNING_KEY_PASSWORD`.

Lokálne vytvorte `signing.properties` podľa `signing.properties.example` a položte pôvodný kľúč na cestu uvedenú v `storeFile`. Oba citlivé súbory sú v `.gitignore`.

Ak podpisové údaje chýbajú, `assembleDebug` sa nezastaví a použije štandardný Android debug podpis. Pre aktualizáciu už nainštalovanej pôvodnej aplikácie však musia byť podpisové secrets nastavené, aby sa použil pôvodný kľúč.

Podrobné výsledky reálneho Android buildu a mobilnej touch emulácie sú v `TEST_REPORT.md`.

## Kompatibilita s GitHub Actions

ZIP obsahuje Android projekt priamo v koreňovom priečinku. Po rozbalení sú okamžite dostupné `settings.gradle.kts`, `build.gradle.kts` a priečinok `app`.

Workflow vytvorí v koreňovom priečinku súbor `secrets.properties`:

```text
MAPS_API_KEY=AIza...
```

Gradle hodnotu načíta a vloží do manifestu cez placeholder `MAPS_API_KEY`.

## Zostavenie

Požiadavky: Java 17, Android SDK 35 a Gradle 8.10.2.

```text
gradle :app:assembleDebug --stacktrace
```

Výsledok:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Testy dátového jadra:

```text
npm test
```
