package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofWallProfileSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun `recess walls follow continuous roof underside instead of constant wall height`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 3.0),
            GraphNode("b", 10.0, 0.0, 3.0),
            GraphNode("c", 10.0, 8.0, 6.2),
            GraphNode("d", 0.0, 8.0, 6.2)
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                GraphEdge("ab", "a", "b", true, EdgeSemantic.EAVE, setOf("face")),
                GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
                GraphEdge("cd", "c", "d", true, EdgeSemantic.RIDGE, setOf("face")),
                GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
            ).associateBy { it.id },
            faces = mapOf(
                "face" to GraphFace(
                    "face", listOf("a", "b", "c", "d"),
                    listOf("ab", "bc", "cd", "da"), 80.0,
                    plane = RoofPlane(0.0, 0.4, 3.0)
                )
            )
        )
        val recessedWall = listOf(
            LocalPoint(1.0, 1.0), LocalPoint(9.0, 1.0),
            LocalPoint(9.0, 7.0), LocalPoint(1.0, 7.0),
            LocalPoint(1.0, 5.0), LocalPoint(3.0, 5.0),
            LocalPoint(3.0, 3.0), LocalPoint(1.0, 3.0)
        )

        val solution = RoofWallProfileSolver.solve(graph, recessedWall, 3.0)
        val recessSide = solution.segments.single { it.index == 5 }.samples

        assertEquals(4.82, recessSide.first().node.z, 1e-9)
        assertEquals(4.02, recessSide.last().node.z, 1e-9)
        assertTrue(solution.raisedSegmentCount >= 3)
    }

    @Test
    fun `ridge crossing adds one apex support without splitting the physical wall`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("m0", 5.0, 0.0),
            GraphNode("b", 10.0, 0.0), GraphNode("c", 10.0, 8.0),
            GraphNode("m1", 5.0, 8.0), GraphNode("d", 0.0, 8.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("am0", "a", "m0", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("m0b", "m0", "b", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("right")),
            GraphEdge("cm1", "c", "m1", true, EdgeSemantic.EAVE, setOf("right")),
            GraphEdge("m1d", "m1", "d", true, EdgeSemantic.EAVE, setOf("left")),
            GraphEdge("da", "d", "a", true, EdgeSemantic.GABLE, setOf("left")),
            GraphEdge("ridge", "m0", "m1", false, EdgeSemantic.RIDGE, setOf("left", "right"))
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin, nodes, edges,
            faces = mapOf(
                "left" to GraphFace(
                    "left", listOf("a", "m0", "m1", "d"),
                    listOf("am0", "ridge", "m1d", "da"), 40.0,
                    plane = RoofPlane(0.5, 0.0, 3.0)
                ),
                "right" to GraphFace(
                    "right", listOf("m0", "b", "c", "m1"),
                    listOf("m0b", "bc", "cm1", "ridge"), 40.0,
                    plane = RoofPlane(-0.5, 0.0, 8.0)
                )
            )
        )

        val result = RoofWallProfileSolver.solve(
            graph,
            listOf(LocalPoint(1.0, 4.0), LocalPoint(9.0, 4.0), LocalPoint(9.0, 5.0), LocalPoint(1.0, 5.0)),
            3.0
        )
        val crossing = result.segments.first().samples

        assertEquals(3, crossing.size)
        assertEquals(0.5, crossing[1].t, 1e-9)
        assertEquals(5.32, crossing[1].node.z, 1e-9)
    }

    @Test
    fun `wall inset inside a roof recess extrapolates the nearest solved plane`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("b", 10.0, 0.0),
            GraphNode("c", 10.0, 8.0), GraphNode("d", 6.0, 8.0),
            GraphNode("e", 6.0, 4.0), GraphNode("f", 4.0, 4.0),
            GraphNode("g", 4.0, 8.0), GraphNode("h", 0.0, 8.0)
        ).associateBy { it.id }
        val order = listOf("a", "b", "c", "d", "e", "f", "g", "h")
        val edges = order.indices.map { index ->
            val start = order[index]
            val end = order[(index + 1) % order.size]
            GraphEdge("edge-$index", start, end, true, EdgeSemantic.EAVE, setOf("face"))
        }.associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = edges,
            faces = mapOf(
                "face" to GraphFace(
                    id = "face",
                    orderedNodeIds = order,
                    orderedEdgeIds = edges.keys.toList(),
                    signedAreaM2 = 72.0,
                    plane = RoofPlane(0.0, 0.4, 3.0)
                )
            )
        )
        // The inset wall sides x=4.5 and x=5.5 are in the concave roof notch. The roof
        // plane still extends above them as an overhang and must define their top edge.
        val wallLoop = listOf(
            LocalPoint(1.0, 1.0), LocalPoint(9.0, 1.0),
            LocalPoint(9.0, 7.0), LocalPoint(5.5, 7.0),
            LocalPoint(5.5, 4.5), LocalPoint(4.5, 4.5),
            LocalPoint(4.5, 7.0), LocalPoint(1.0, 7.0)
        )

        val solution = RoofWallProfileSolver.solve(graph, wallLoop, 3.0)
        val rightRecessWall = solution.segments.single { it.index == 3 }.samples
        val leftRecessWall = solution.segments.single { it.index == 5 }.samples

        assertEquals(5.62, rightRecessWall.first().node.z, 1e-9)
        assertEquals(4.62, rightRecessWall.last().node.z, 1e-9)
        assertEquals(4.62, leftRecessWall.first().node.z, 1e-9)
        assertEquals(5.62, leftRecessWall.last().node.z, 1e-9)
        assertTrue(solution.raisedSegmentCount >= 2)
    }

    @Test
    fun `eave and two gable projection bypasses generic wall floor and follows one roof plane`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0), GraphNode("b", 10.0, 0.0),
            GraphNode("c", 10.0, 8.0), GraphNode("d", 0.0, 8.0),
            GraphNode("p0", -3.0, 3.0), GraphNode("p1", 0.0, 3.0),
            GraphNode("p2", 0.0, 5.0), GraphNode("p3", -3.0, 5.0)
        ).associateBy { it.id }
        val graph = RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                GraphEdge("ab", "a", "b", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("bc", "b", "c", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("cd", "c", "d", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("dp2", "d", "p2", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("p2p3", "p2", "p3", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("p3p0", "p3", "p0", true, EdgeSemantic.EAVE, setOf("main-plane")),
                GraphEdge("p0p1", "p0", "p1", true, EdgeSemantic.GABLE, setOf("main-plane")),
                GraphEdge("p1a", "p1", "a", true, EdgeSemantic.EAVE, setOf("main-plane"))
            ).associateBy { it.id },
            faces = mapOf(
                "main-plane" to GraphFace(
                    id = "main-plane",
                    orderedNodeIds = listOf("a", "b", "c", "d", "p2", "p3", "p0", "p1"),
                    orderedEdgeIds = listOf("ab", "bc", "cd", "dp2", "p2p3", "p3p0", "p0p1", "p1a"),
                    signedAreaM2 = 86.0,
                    // The main roof underside is 3.22 m at x=0 and descends over
                    // the projection to 2.02 m at x=-3 after shell subtraction.
                    plane = RoofPlane(0.4, 0.0, 3.4)
                )
            )
        )
        val wallLoop = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
            LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0),
            LocalPoint(0.0, 5.0), LocalPoint(-3.0, 5.0),
            LocalPoint(-3.0, 3.0), LocalPoint(0.0, 3.0)
        )
        val context = WallFootprintSolver.Context(
            origin,
            listOf(
                WallFootprintSolver.Context.LocalPart(
                    "main", WallFootprintPartType.MAIN_TRACT,
                    listOf(
                        LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
                        LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0)
                    ),
                    80.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    "projection", WallFootprintPartType.PROJECTION,
                    listOf(
                        LocalPoint(-3.0, 3.0), LocalPoint(0.0, 3.0),
                        LocalPoint(0.0, 5.0), LocalPoint(-3.0, 5.0)
                    ),
                    6.0
                )
            )
        )

        val semantic = RoofWallProfileSolver.solve(
            graph, wallLoop, 3.0, footprintContext = context
        )
        val legacy = RoofWallProfileSolver.solve(graph, wallLoop, 3.0)
        val projectionRules = ProjectionWallProfileSolver.rules(graph, context)
        val upperReturn = semantic.segments.single { it.index == 4 }.samples
        val outerFacade = semantic.segments.single { it.index == 5 }.samples

        assertEquals(1, projectionRules.size)
        assertEquals("p3p0", projectionRules.single().frontEaveEdgeId)
        assertEquals(setOf("p2p3", "p0p1"), projectionRules.single().sideGableEdgeIds)
        assertEquals(3.22, upperReturn.first().node.z, 1e-9)
        assertEquals(2.02, upperReturn.last().node.z, 1e-9)
        assertEquals(2.02, outerFacade.first().node.z, 1e-9)
        assertEquals(2.02, outerFacade.last().node.z, 1e-9)
        assertEquals(3.0, legacy.segments.single { it.index == 5 }.samples.first().node.z, 1e-9)

        val invalidEdges = graph.edges.toMutableMap().apply {
            this["p0p1"] = getValue("p0p1").copy(semanticRole = EdgeSemantic.EAVE)
        }
        val invalidGraph = graph.copy(edges = invalidEdges)
        assertTrue(ProjectionWallProfileSolver.rules(invalidGraph, context).isEmpty())
        assertEquals(
            "Without the exact EAVE + 2x GABLE assembly the generic wall floor stays active",
            3.0,
            RoofWallProfileSolver.solve(
                invalidGraph, wallLoop, 3.0, footprintContext = context
            ).segments.single { it.index == 5 }.samples.first().node.z,
            1e-9
        )
    }
}
