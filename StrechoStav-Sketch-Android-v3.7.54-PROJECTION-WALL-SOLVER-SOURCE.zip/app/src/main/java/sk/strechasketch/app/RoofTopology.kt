package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.PI
import kotlin.math.round
import kotlin.math.sin

/**
 * Model-space (metre) topology used by the roof solver.  It intentionally lives
 * beside the legacy [RoofProject] model: loading an old project never rewrites it
 * until [RoofTopologyMigration.applyToProject] is called explicitly.
 */
enum class TopologyNodeType {
    FOOTPRINT,
    LINE_ENDPOINT,
    INTERSECTION,
    JUNCTION
}

data class TopologyNode(
    val id: String,
    val x: Double,
    val y: Double,
    val type: TopologyNodeType,
    val locked: Boolean = false
)

data class TopologyEdge(
    val id: String,
    val startNodeId: String,
    val endNodeId: String,
    val type: LineType,
    val locked: Boolean = false,
    val boundary: Boolean = false,
    val sourceId: String? = null,
    val note: String = ""
)

data class RoofTopology(
    val origin: GeoPoint,
    val nodes: List<TopologyNode>,
    val edges: List<TopologyEdge>,
    val schemaVersion: Int = 3,
    /** Stable project-local 100 mm grid axis; it must not be inferred again after edits. */
    val gridRotationDeg: Double = Double.NaN
)

data class RoofSolverConfig(
    /** Solver tolerances are metres. Pixel tolerances belong to the editor only. */
    val mergeToleranceM: Double = 0.05,
    val snapToleranceM: Double = 0.35,
    val minimumEdgeLengthM: Double = 0.01,
    val intersectionEpsilon: Double = 1e-7,
    val allowFreeInternalEnds: Boolean = false,
    /** PHP-compatible correction: base, base+90°, base±45°. */
    val regularizeAngles: Boolean = false,
    val maximumRegularizationDisplacementM: Double = 4.0,
    val minimumBoundaryEdgeLengthM: Double = 0.18
) {
    init {
        require(mergeToleranceM >= 0.0)
        require(snapToleranceM >= mergeToleranceM)
        require(minimumEdgeLengthM >= 0.0)
        require(intersectionEpsilon > 0.0)
        require(maximumRegularizationDisplacementM >= 0.0)
        require(minimumBoundaryEdgeLengthM >= minimumEdgeLengthM)
    }
}

enum class TopologyIssueSeverity { WARNING, ERROR }

data class TopologyIssue(
    val code: String,
    val message: String,
    val severity: TopologyIssueSeverity,
    val nodeIds: List<String> = emptyList(),
    val edgeIds: List<String> = emptyList(),
    val x: Double? = null,
    val y: Double? = null,
    val distanceM: Double? = null
)

data class RoofSolverStatistics(
    val mergedNodes: Int = 0,
    val createdIntersections: Int = 0,
    val splitEdges: Int = 0,
    val snappedFreeEnds: Int = 0,
    val removedShortEdges: Int = 0,
    val removedDuplicateEdges: Int = 0,
    val regularizedBoundaryNodes: Int = 0,
    val alignedHipValleyNodes: Int = 0,
    val alignedRidgeNodes: Int = 0
) {
    val totalChanges: Int
        get() = mergedNodes + createdIntersections + splitEdges + snappedFreeEnds +
            removedShortEdges + removedDuplicateEdges + regularizedBoundaryNodes +
            alignedHipValleyNodes + alignedRidgeNodes
}

data class NodeMovement(
    val sourceNodeId: String,
    val targetNodeId: String,
    val fromX: Double,
    val fromY: Double,
    val toX: Double,
    val toY: Double,
    val reason: String
)

/** Immutable preview. The caller applies [proposed] only after user confirmation. */
data class RoofSolverPreview(
    val original: RoofTopology,
    val proposed: RoofTopology,
    val statistics: RoofSolverStatistics,
    val movements: List<NodeMovement>,
    val issues: List<TopologyIssue>,
    val faces: List<TopologyFace>
) {
    val isValid: Boolean get() = issues.none { it.severity == TopologyIssueSeverity.ERROR }
}

data class TopologyFace(
    val nodeIds: List<String>,
    val edgeIds: List<String>,
    val signedAreaM2: Double
)

data class TopologyApplyResult(
    val applied: Boolean,
    val issues: List<TopologyIssue>
)

/** Backwards-compatible adapter for the current polygon/lines representation. */
object RoofTopologyMigration {
    fun fromProject(
        project: RoofProject,
        lockedNodeIds: Set<String> = emptySet(),
        lockedEdgeIds: Set<String> = emptySet()
    ): RoofTopology = project.roofGraph?.toTopology()
        ?: fromLegacyProject(project, lockedNodeIds, lockedEdgeIds)

    fun fromLegacyProject(
        project: RoofProject,
        lockedNodeIds: Set<String> = emptySet(),
        lockedEdgeIds: Set<String> = emptySet()
    ): RoofTopology {
        val allPoints = buildList {
            addAll(project.polygon)
            project.lines.forEach { add(it.start); add(it.end) }
        }
        MetricPlanGrid.ensureProjectFrame(project, project.polygon.ifEmpty { allPoints })
        val origin = GeoPoint(project.geometryGridOriginLat, project.geometryGridOriginLon)
        val rotation = project.geometryGridRotationDeg
        val nodes = mutableListOf<TopologyNode>()
        val edges = mutableListOf<TopologyEdge>()

        project.polygon.forEachIndexed { index, point ->
            val local = MetricPlanGrid.snap(Geometry.toLocal(point, origin), rotation)
            val id = "footprint-node-${index.toString().padStart(4, '0')}"
            nodes += TopologyNode(id, local.x, local.y, TopologyNodeType.FOOTPRINT, id in lockedNodeIds)
        }
        if (project.polygon.size >= 2) {
            project.polygon.indices.forEach { index ->
                val id = "footprint-edge-${index.toString().padStart(4, '0')}"
                edges += TopologyEdge(
                    id = id,
                    startNodeId = "footprint-node-${index.toString().padStart(4, '0')}",
                    endNodeId = "footprint-node-${((index + 1) % project.polygon.size).toString().padStart(4, '0')}",
                    type = project.edgeTypes[index] ?: LineType.EAVE,
                    locked = id in lockedEdgeIds,
                    boundary = true,
                    sourceId = index.toString()
                )
            }
        }
        project.lines.forEachIndexed { index, line ->
            val stableLineId = line.id.ifBlank { "legacy-line-${index.toString().padStart(4, '0')}" }
            val startId = "line-$stableLineId-start"
            val endId = "line-$stableLineId-end"
            val start = MetricPlanGrid.snap(Geometry.toLocal(line.start, origin), rotation)
            val end = MetricPlanGrid.snap(Geometry.toLocal(line.end, origin), rotation)
            nodes += TopologyNode(startId, start.x, start.y, TopologyNodeType.LINE_ENDPOINT, startId in lockedNodeIds)
            nodes += TopologyNode(endId, end.x, end.y, TopologyNodeType.LINE_ENDPOINT, endId in lockedNodeIds)
            edges += TopologyEdge(
                id = stableLineId,
                startNodeId = startId,
                endNodeId = endId,
                type = line.type,
                locked = stableLineId in lockedEdgeIds,
                boundary = false,
                sourceId = stableLineId,
                note = line.note
            )
        }
        return RoofTopology(origin.copy(), nodes, edges, gridRotationDeg = rotation)
    }

    /**
     * Writes a confirmed topology back to the legacy model. Invalid boundary
     * topology leaves the project untouched.
     */
    fun applyToProject(
        project: RoofProject,
        topology: RoofTopology,
        requireFullyValid: Boolean = true
    ): TopologyApplyResult {
        val normalized = MetricPlanGrid.snap(topology)
        val validation = RoofTopologySolver.validate(normalized)
        val boundary = orderedBoundary(normalized)
        if (boundary == null) {
            return TopologyApplyResult(
                false,
                validation + TopologyIssue(
                    code = "BOUNDARY_NOT_SINGLE_CYCLE",
                    message = "Vonkajší obrys netvorí jeden uzavretý cyklus.",
                    severity = TopologyIssueSeverity.ERROR
                )
            )
        }
        if (requireFullyValid && validation.any { it.severity == TopologyIssueSeverity.ERROR }) {
            return TopologyApplyResult(false, validation)
        }
        val nodeById = normalized.nodes.associateBy { it.id }
        val newPolygon = boundary.first.map { nodeId ->
            val node = requireNotNull(nodeById[nodeId])
            Geometry.toGeo(LocalPoint(node.x, node.y), normalized.origin)
        }.toMutableList()
        val newEdgeTypes = boundary.second.mapIndexed { index, edge -> index to edge.type }.toMap().toMutableMap()
        val newLines = topology.edges.asSequence()
            .filterNot { it.boundary }
            .sortedBy { it.id }
            .map { edge ->
                val a = requireNotNull(nodeById[edge.startNodeId])
                val b = requireNotNull(nodeById[edge.endNodeId])
                RoofLine(
                    id = edge.id,
                    type = edge.type,
                    start = Geometry.toGeo(LocalPoint(a.x, a.y), normalized.origin),
                    end = Geometry.toGeo(LocalPoint(b.x, b.y), normalized.origin),
                    note = edge.note
                )
            }.toMutableList()

        project.polygon = newPolygon
        project.edgeTypes = newEdgeTypes
        project.lines = newLines
        project.roofTopology = normalized
        project.roofGraph = RoofGraphFactory.fromTopology(normalized, project.roofGraph)
        project.geometryGridOriginLat = normalized.origin.lat
        project.geometryGridOriginLon = normalized.origin.lon
        project.geometryGridRotationDeg = normalized.gridRotationDeg.takeIf(Double::isFinite)
            ?: MetricPlanGrid.axisDeg(normalized)
            ?: project.geometryGridRotationDeg.takeIf(Double::isFinite)
            ?: 0.0
        project.updatedAt = System.currentTimeMillis()
        return TopologyApplyResult(true, validation)
    }

    internal fun orderedBoundary(topology: RoofTopology): Pair<List<String>, List<TopologyEdge>>? {
        val boundaryEdges = topology.edges.filter { it.boundary }
        if (boundaryEdges.size < 3) return null
        val adjacency = mutableMapOf<String, MutableList<TopologyEdge>>()
        boundaryEdges.forEach { edge ->
            adjacency.getOrPut(edge.startNodeId) { mutableListOf() } += edge
            adjacency.getOrPut(edge.endNodeId) { mutableListOf() } += edge
        }
        if (adjacency.values.any { it.size != 2 }) return null
        val start = adjacency.keys.minOrNull() ?: return null
        val first = adjacency.getValue(start).minBy { it.id }
        val nodeIds = mutableListOf(start)
        val walkedEdges = mutableListOf<TopologyEdge>()
        var current = start
        var edge = first
        val used = mutableSetOf<String>()
        while (edge.id !in used) {
            used += edge.id
            walkedEdges += edge
            val next = if (edge.startNodeId == current) edge.endNodeId else edge.startNodeId
            if (next == start) break
            nodeIds += next
            current = next
            edge = adjacency.getValue(current).firstOrNull { it.id !in used } ?: return null
        }
        if (used.size != boundaryEdges.size || walkedEdges.lastOrNull()?.let {
                if (it.startNodeId == current) it.endNodeId else it.startNodeId
            } != start
        ) return null
        val nodeById = topology.nodes.associateBy { it.id }
        val area = signedArea(nodeIds.map { requireNotNull(nodeById[it]) })
        return if (area >= 0.0) {
            nodeIds to walkedEdges
        } else {
            val reversedEdges = walkedEdges.asReversed().let { it.drop(1) + it.first() }
            nodeIds.asReversed() to reversedEdges
        }
    }
}

object RoofTopologySolver {
    fun solve(input: RoofTopology, config: RoofSolverConfig = RoofSolverConfig()): RoofSolverPreview {
        val graph = MutableGraph(MetricPlanGrid.snap(input))
        graph.mergeNearbyNodes(config)
        graph.splitAllIntersections(config)
        graph.snapFreeInternalEnds(config)
        graph.mergeNearbyNodes(config)
        if (config.regularizeAngles) {
            graph.collapseInternalNearCornerSplits(config)
            graph.regularizeBoundary(config)
            graph.alignHipAndValley(config)
            graph.alignRidgesToStraightBoundary(config)
        }
        graph.splitAllIntersections(config)
        graph.removeShortAndDuplicateEdges(config)
        graph.normalizeNodeTypes()
        val proposed = MetricPlanGrid.snap(graph.freeze())
        val issues = validate(proposed, config) + graph.operationIssues
        return RoofSolverPreview(
            original = input.deepCopy(),
            proposed = proposed,
            statistics = graph.statistics,
            movements = graph.movements.toList(),
            issues = issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) },
            faces = extractFaces(proposed, config.intersectionEpsilon)
        )
    }

    /**
     * Outline-card correction. Internal topology is preserved, but a ridge endpoint already
     * attached to a nearly symmetric straight gable split follows the centered tract axis.
     */
    fun solveOutline(
        input: RoofTopology,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofSolverPreview {
        val boundaryEdges = input.edges.filter { it.boundary }
        val boundaryNodeIds = boundaryEdges.flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        val boundaryOnly = input.copy(
            nodes = input.nodes.filter { it.id in boundaryNodeIds },
            edges = boundaryEdges
        )
        val solved = solve(
            boundaryOnly,
            RoofSolverConfig(
                regularizeAngles = true,
                minimumBoundaryEdgeLengthM = 0.01,
                allowFreeInternalEnds = true
            )
        )
        val proposedBoundaryIds = solved.proposed.nodes.map { it.id }.toSet()
        val boundaryCorrected = input.copy(
            nodes = solved.proposed.nodes + input.nodes.filter { it.id !in boundaryNodeIds && it.id !in proposedBoundaryIds },
            edges = solved.proposed.edges + input.edges.filterNot { it.boundary }
        )
        val tract = RoofTractSymmetrySolver.solve(boundaryCorrected, footprintContext)
        val proposed = MetricPlanGrid.snap(tract.topology)
        return RoofSolverPreview(
            original = input.deepCopy(),
            proposed = proposed,
            statistics = solved.statistics.copy(
                alignedRidgeNodes = solved.statistics.alignedRidgeNodes + tract.centeredRidgeContacts
            ),
            movements = solved.movements + tract.movements,
            issues = validate(proposed),
            faces = extractFaces(proposed)
        )
    }

    /**
     * Card-2 correction. It preserves the drawn topology and only performs
     * limited movement/merging of already existing nodes. Physical boundary
     * corners remain immutable; a collinear gable contact may move at most
     * 300 mm so both opposite gables use one tract division ratio.
     */
    fun solveInternal(
        input: RoofTopology,
        angleToleranceDeg: Double = 10.0,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofSolverPreview {
        // Pair both gable contacts while the original boundary/ridge identities are
        // still available. The following conservative pass may merge an already
        // magnetized line endpoint into that boundary contact.
        val tract = RoofTractSymmetrySolver.solve(input, footprintContext)
        val lines = ConservativeInternalLineSolver.solve(
            input = tract.topology,
            angleToleranceDeg = angleToleranceDeg,
            maximumLengthChangeFraction = 0.10
        )
        val proposed = MetricPlanGrid.snap(lines.proposed)
        return lines.copy(
            original = input.deepCopy(),
            proposed = proposed,
            statistics = lines.statistics.copy(
                alignedRidgeNodes = lines.statistics.alignedRidgeNodes + tract.centeredRidgeContacts
            ),
            movements = tract.movements + lines.movements,
            issues = validate(proposed),
            faces = extractFaces(proposed)
        )
    }

    /** Retained only as implementation history; never used by the editor. */
    @Suppress("unused")
    private fun solveInternalTopologyRebuildingLegacy(
        input: RoofTopology,
        angleToleranceDeg: Double = 5.0
    ): RoofSolverPreview {
        val boundaryNodeIds = input.edges.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        val locked = input.copy(
            nodes = input.nodes.map { if (it.id in boundaryNodeIds) it.copy(locked = true) else it },
            edges = input.edges.map { if (it.boundary) it.copy(locked = true) else it }
        )
        // Boundary nodes are locked, therefore regularizeBoundary cannot move
        // the footprint. Enabling the angular pass here is nevertheless
        // essential: HIP/VALLEY junctions must be solved at exact 45° support
        // lines before the face-plane solver receives the network.
        val internalConfig = RoofSolverConfig(regularizeAngles = true)
        val first = solve(locked, internalConfig)
        val snapped = snapInternalDirections(first.proposed, boundaryNodeIds, angleToleranceDeg)
        val second = solve(snapped.first, internalConfig)
        val boundaryEdges = input.edges.filter { it.boundary }
        val movableStraightBoundaryNodes = boundaryNodeIds.filter { nodeId ->
            val incident = boundaryEdges.filter { it.startNodeId == nodeId || it.endNodeId == nodeId }
            if (incident.size != 2) return@filter false
            val center = input.nodes.firstOrNull { it.id == nodeId } ?: return@filter false
            val others = incident.mapNotNull { edge ->
                val otherId = if (edge.startNodeId == nodeId) edge.endNodeId else edge.startNodeId
                input.nodes.firstOrNull { it.id == otherId }
            }
            others.size == 2 && angularDistanceModuloPi(
                atan2(others[0].y - center.y, others[0].x - center.x),
                atan2(others[1].y - center.y, others[1].x - center.x)
            ) <= Math.toRadians(2.0)
        }.toSet()
        val originalBoundary = input.nodes.filter {
            it.id in boundaryNodeIds && it.id !in movableStraightBoundaryNodes
        }.associateBy { it.id }
        val protectedNodes = second.proposed.nodes.map { node -> originalBoundary[node.id] ?: node }
        val proposed = second.proposed.copy(nodes = protectedNodes)
        return RoofSolverPreview(
            original = input.deepCopy(),
            proposed = proposed,
            statistics = RoofSolverStatistics(
                mergedNodes = first.statistics.mergedNodes + second.statistics.mergedNodes,
                createdIntersections = first.statistics.createdIntersections + second.statistics.createdIntersections,
                splitEdges = first.statistics.splitEdges + second.statistics.splitEdges,
                snappedFreeEnds = first.statistics.snappedFreeEnds + second.statistics.snappedFreeEnds,
                removedShortEdges = first.statistics.removedShortEdges + second.statistics.removedShortEdges,
                removedDuplicateEdges = first.statistics.removedDuplicateEdges + second.statistics.removedDuplicateEdges,
                alignedHipValleyNodes = first.statistics.alignedHipValleyNodes + second.statistics.alignedHipValleyNodes,
                alignedRidgeNodes = first.statistics.alignedRidgeNodes + second.statistics.alignedRidgeNodes
            ),
            movements = first.movements + snapped.second + second.movements,
            issues = validate(proposed),
            faces = extractFaces(proposed)
        )
    }

    private fun snapInternalDirections(
        topology: RoofTopology,
        boundaryNodeIds: Set<String>,
        toleranceDeg: Double
    ): Pair<RoofTopology, List<NodeMovement>> {
        val boundaryEdges = topology.edges.filter { it.boundary }
        val nodes = topology.nodes.associateBy { it.id }.toMutableMap()
        val dominant = boundaryEdges.maxByOrNull { edge ->
            val a = nodes[edge.startNodeId] ?: return@maxByOrNull 0.0
            val b = nodes[edge.endNodeId] ?: return@maxByOrNull 0.0
            hypot(b.x - a.x, b.y - a.y)
        }?.let { edge ->
            val a = nodes.getValue(edge.startNodeId)
            val b = nodes.getValue(edge.endNodeId)
            atan2(b.y - a.y, b.x - a.x)
        } ?: 0.0
        val degree = topology.edges.flatMap { listOf(it.startNodeId, it.endNodeId) }.groupingBy { it }.eachCount()
        val movements = mutableListOf<NodeMovement>()
        topology.edges.filterNot { it.boundary }.sortedBy { it.id }.forEach { edge ->
            val a = nodes[edge.startNodeId] ?: return@forEach
            val b = nodes[edge.endNodeId] ?: return@forEach
            val raw = atan2(b.y - a.y, b.x - a.x)
            val targets = listOf(0.0, PI / 4.0, PI / 2.0, 3.0 * PI / 4.0).map { dominant + it }
            val target = targets.minByOrNull { angularDistanceModuloPi(raw, it) } ?: return@forEach
            if (Math.toDegrees(angularDistanceModuloPi(raw, target)) > toleranceDeg + 1e-9) return@forEach
            val mobileIsEnd = degree[b.id] == 1 && b.id !in boundaryNodeIds && !b.locked
            val mobileIsStart = degree[a.id] == 1 && a.id !in boundaryNodeIds && !a.locked
            if (!mobileIsEnd && !mobileIsStart) return@forEach
            val anchor = if (mobileIsEnd) a else b
            val mobile = if (mobileIsEnd) b else a
            val length = hypot(mobile.x - anchor.x, mobile.y - anchor.y)
            var dx = cos(target)
            var dy = sin(target)
            if (dx * (mobile.x - anchor.x) + dy * (mobile.y - anchor.y) < 0.0) {
                dx = -dx; dy = -dy
            }
            val moved = mobile.copy(x = anchor.x + dx * length, y = anchor.y + dy * length)
            nodes[mobile.id] = moved
            movements += NodeMovement(mobile.id, mobile.id, mobile.x, mobile.y, moved.x, moved.y, "SNAP_INTERNAL_ANGLE")
        }
        return topology.copy(nodes = topology.nodes.map { nodes.getValue(it.id) }) to movements
    }

    private fun angularDistanceModuloPi(a: Double, b: Double): Double {
        var delta = abs(a - b) % PI
        if (delta > PI / 2.0) delta = PI - delta
        return abs(delta)
    }

    fun validate(
        topology: RoofTopology,
        config: RoofSolverConfig = RoofSolverConfig()
    ): List<TopologyIssue> {
        val issues = mutableListOf<TopologyIssue>()
        val nodes = topology.nodes.associateBy { it.id }
        if (nodes.size != topology.nodes.size) {
            issues += error("DUPLICATE_NODE_ID", "Topológia obsahuje duplicitné ID uzla.")
        }
        if (topology.edges.map { it.id }.toSet().size != topology.edges.size) {
            issues += error("DUPLICATE_EDGE_ID", "Topológia obsahuje duplicitné ID hrany.")
        }
        topology.nodes.forEach { node ->
            if (!node.x.isFinite() || !node.y.isFinite()) {
                issues += error("NON_FINITE_NODE", "Uzol ${node.id} nemá platné súradnice.", nodes = listOf(node.id))
            }
        }
        val validEdges = topology.edges.filter { edge ->
            val a = nodes[edge.startNodeId]
            val b = nodes[edge.endNodeId]
            if (a == null || b == null) {
                issues += error(
                    "MISSING_EDGE_NODE",
                    "Hrana ${edge.id} odkazuje na neexistujúci uzol.",
                    edges = listOf(edge.id)
                )
                false
            } else {
                val length = distance(a, b)
                if (edge.startNodeId == edge.endNodeId || length <= config.minimumEdgeLengthM) {
                    issues += error(
                        "ZERO_OR_SHORT_EDGE",
                        "Hrana ${edge.id} je nulová alebo kratšia než ${formatM(config.minimumEdgeLengthM)} m.",
                        nodes = listOf(edge.startNodeId, edge.endNodeId),
                        edges = listOf(edge.id),
                        x = (a.x + b.x) / 2.0,
                        y = (a.y + b.y) / 2.0,
                        distance = length
                    )
                }
                true
            }
        }
        validEdges.groupBy { unorderedPair(it.startNodeId, it.endNodeId) }.values
            .filter { it.size > 1 }
            .forEach { duplicates ->
                issues += error(
                    "DUPLICATE_EDGE",
                    "Medzi rovnakými uzlami existuje viac hrán.",
                    nodes = listOf(duplicates.first().startNodeId, duplicates.first().endNodeId),
                    edges = duplicates.map { it.id }
                )
            }
        val sortedNodes = topology.nodes.sortedBy { it.id }
        for (i in sortedNodes.indices) for (j in i + 1 until sortedNodes.size) {
            val d = distance(sortedNodes[i], sortedNodes[j])
            if (d <= config.mergeToleranceM) {
                issues += error(
                    "NEAR_DUPLICATE_NODES",
                    "Uzly ${sortedNodes[i].id} a ${sortedNodes[j].id} sú od seba iba ${formatM(d)} m.",
                    nodes = listOf(sortedNodes[i].id, sortedNodes[j].id),
                    x = (sortedNodes[i].x + sortedNodes[j].x) / 2.0,
                    y = (sortedNodes[i].y + sortedNodes[j].y) / 2.0,
                    distance = d
                )
            }
        }
        val sortedEdges = validEdges.sortedBy { it.id }
        for (i in sortedEdges.indices) for (j in i + 1 until sortedEdges.size) {
            val first = sortedEdges[i]
            val second = sortedEdges[j]
            val a = nodes[first.startNodeId] ?: continue
            val b = nodes[first.endNodeId] ?: continue
            val c = nodes[second.startNodeId] ?: continue
            val d = nodes[second.endNodeId] ?: continue
            val hit = segmentIntersection(a, b, c, d, config.intersectionEpsilon)
            if (hit.collinearOverlap) {
                issues += error(
                    "COLLINEAR_OVERLAP",
                    "Hrany ${first.id} a ${second.id} sa nejednoznačne prekrývajú.",
                    edges = listOf(first.id, second.id)
                )
            } else if (hit.exists) {
                val shared = setOf(first.startNodeId, first.endNodeId)
                    .intersect(setOf(second.startNodeId, second.endNodeId))
                if (shared.isEmpty()) {
                    issues += error(
                        "UNSPLIT_INTERSECTION",
                        "Pretínajúce sa hrany ${first.id} a ${second.id} nemajú spoločný uzol.",
                        edges = listOf(first.id, second.id),
                        x = hit.x,
                        y = hit.y
                    )
                }
            }
        }
        val incident = mutableMapOf<String, MutableList<TopologyEdge>>()
        validEdges.forEach { edge ->
            incident.getOrPut(edge.startNodeId) { mutableListOf() } += edge
            incident.getOrPut(edge.endNodeId) { mutableListOf() } += edge
        }
        if (!config.allowFreeInternalEnds) {
            validEdges.filterNot { it.boundary }.forEach { edge ->
                listOf(edge.startNodeId, edge.endNodeId).forEach { nodeId ->
                    if (incident[nodeId]?.size == 1) {
                        val node = nodes[nodeId]
                        issues += error(
                            "FREE_INTERNAL_END",
                            "Koniec línie ${edge.type.label} nie je pripojený k inej strešnej hrane.",
                            nodes = listOf(nodeId),
                            edges = listOf(edge.id),
                            x = node?.x,
                            y = node?.y
                        )
                    }
                }
            }
        }
        val boundaryIncident = mutableMapOf<String, Int>()
        validEdges.filter { it.boundary }.forEach { edge ->
            boundaryIncident[edge.startNodeId] = (boundaryIncident[edge.startNodeId] ?: 0) + 1
            boundaryIncident[edge.endNodeId] = (boundaryIncident[edge.endNodeId] ?: 0) + 1
        }
        boundaryIncident.filterValues { it != 2 }.forEach { (nodeId, degree) ->
            issues += error(
                "OPEN_BOUNDARY",
                "Uzol obrysu $nodeId má stupeň $degree namiesto 2.",
                nodes = listOf(nodeId)
            )
        }
        val bridges = findBridges(topology)
        validEdges.filterNot { it.boundary }.filter { it.id in bridges }.forEach { edge ->
            issues += error(
                "INTERNAL_EDGE_NOT_IN_FACE",
                "Hrana ${edge.type.label} ${edge.id} nevytvára hranicu uzavretej strešnej plochy.",
                edges = listOf(edge.id),
                nodes = listOf(edge.startNodeId, edge.endNodeId)
            )
        }
        if (topology.edges.any { it.boundary } && extractFaces(topology, config.intersectionEpsilon).isEmpty()) {
            issues += error("NO_CLOSED_FACE", "Topológia neobsahuje žiadnu platnú uzavretú plochu.")
        }
        return issues.distinctBy { Triple(it.code, it.nodeIds, it.edgeIds) }
    }

    /** Extracts bounded planar faces. Exterior and degenerate walks are omitted. */
    fun extractFaces(topology: RoofTopology, epsilon: Double = 1e-7): List<TopologyFace> {
        val nodes = topology.nodes.associateBy { it.id }
        val edges = topology.edges.filter { nodes.containsKey(it.startNodeId) && nodes.containsKey(it.endNodeId) }
        val outgoing = mutableMapOf<String, MutableList<Pair<String, TopologyEdge>>>()
        edges.forEach { edge ->
            outgoing.getOrPut(edge.startNodeId) { mutableListOf() } += edge.endNodeId to edge
            outgoing.getOrPut(edge.endNodeId) { mutableListOf() } += edge.startNodeId to edge
        }
        outgoing.forEach { (nodeId, list) ->
            val center = requireNotNull(nodes[nodeId])
            list.sortWith(compareBy<Pair<String, TopologyEdge>> {
                val target = requireNotNull(nodes[it.first])
                atan2(target.y - center.y, target.x - center.x)
            }.thenBy { it.second.id }.thenBy { it.first })
        }
        val visited = mutableSetOf<Pair<String, String>>()
        val result = mutableListOf<TopologyFace>()
        edges.sortedBy { it.id }.forEach { seed ->
            listOf(seed.startNodeId to seed.endNodeId, seed.endNodeId to seed.startNodeId).forEach direction@{ startDirection ->
                if (startDirection in visited) return@direction
                val faceNodes = mutableListOf<String>()
                val faceEdges = mutableListOf<String>()
                var from = startDirection.first
                var to = startDirection.second
                var guard = 0
                while ((from to to) !in visited && guard++ <= edges.size * 2 + 2) {
                    visited += from to to
                    faceNodes += from
                    val options = outgoing[to] ?: break
                    val reverseIndex = options.indexOfFirst { it.first == from }
                    if (reverseIndex < 0) break
                    val usedEdge = options[reverseIndex].second
                    faceEdges += usedEdge.id
                    val next = options[(reverseIndex - 1 + options.size) % options.size]
                    from = to
                    to = next.first
                    if (from == startDirection.first && to == startDirection.second) break
                }
                if (faceNodes.size >= 3 && from == startDirection.first && to == startDirection.second) {
                    val area = signedArea(faceNodes.mapNotNull(nodes::get))
                    if (area > epsilon) {
                        result += TopologyFace(faceNodes, faceEdges, area)
                    }
                }
            }
        }
        return result.distinctBy { canonicalCycle(it.nodeIds) }.sortedBy { canonicalCycle(it.nodeIds) }
    }

    /** Pure manual operation backing the future “Spojiť do uzla” command. */
    fun mergeSelectedNodes(
        topology: RoofTopology,
        nodeIds: Set<String>,
        preferredNodeId: String? = null,
        epsilon: Double = 1e-7
    ): RoofSolverPreview {
        val graph = MutableGraph(topology)
        graph.mergeSelected(nodeIds, preferredNodeId, epsilon)
        graph.removeShortAndDuplicateEdges(RoofSolverConfig(intersectionEpsilon = epsilon))
        graph.normalizeNodeTypes()
        val proposed = graph.freeze()
        return RoofSolverPreview(
            topology.deepCopy(), proposed, graph.statistics, graph.movements,
            validate(proposed), extractFaces(proposed)
        )
    }

    /** Pure manual operation backing the future “Rozpojiť uzol” command. */
    fun disconnectNode(topology: RoofTopology, nodeId: String): RoofTopology {
        val graph = MutableGraph(topology)
        graph.disconnect(nodeId)
        graph.normalizeNodeTypes()
        return graph.freeze()
    }

    /** Pure edge split; returns the original topology when the point is not on the edge. */
    fun splitEdge(
        topology: RoofTopology,
        edgeId: String,
        x: Double,
        y: Double,
        toleranceM: Double = 0.05
    ): RoofTopology {
        val graph = MutableGraph(topology)
        val rotation = MetricPlanGrid.axisDeg(topology) ?: 0.0
        val snapped = MetricPlanGrid.snap(LocalPoint(x, y), rotation)
        graph.splitEdgeAt(edgeId, snapped.x, snapped.y, toleranceM + MetricPlanGrid.STEP_M)
        graph.normalizeNodeTypes()
        return MetricPlanGrid.snap(graph.freeze())
    }

    private class MutableGraph(topology: RoofTopology) {
        val nodes = linkedMapOf<String, TopologyNode>()
        val edges = linkedMapOf<String, TopologyEdge>()
        val movements = mutableListOf<NodeMovement>()
        val operationIssues = mutableListOf<TopologyIssue>()
        var statistics = RoofSolverStatistics()
        private val origin = topology.origin.copy()
        private val gridRotationDeg = MetricPlanGrid.axisDeg(topology) ?: 0.0
        private var generatedNodeCounter = 0

        init {
            topology.nodes.sortedBy { it.id }.forEach { nodes[it.id] = it.copy() }
            topology.edges.sortedBy { it.id }.forEach { edges[it.id] = it.copy() }
        }

        fun freeze() = RoofTopology(
            origin = origin.copy(),
            nodes = nodes.values.toList(),
            edges = edges.values.toList(),
            gridRotationDeg = gridRotationDeg
        )

        /**
         * Ports the proven PHP regularizePolygonLocal approach to the topological
         * graph. The longest boundary edge defines the base direction. Boundary
         * support lines pass through original midpoints and use base, base+90°
         * or base±45°. Adjacent support-line intersections define new corners.
         * Shared node IDs are moved, so attached roof lines cannot become detached.
         */
        fun regularizeBoundary(config: RoofSolverConfig) {
            val cycle = orderedBoundaryCycle() ?: return
            if (cycle.nodeIds.size < 3) return
            val original = cycle.nodeIds.mapNotNull(nodes::get)
            if (original.size != cycle.nodeIds.size) return
            val originalArea = abs(signedArea(original))
            if (originalArea <= config.intersectionEpsilon) return

            // The construction grid is the authoritative project axis. Reusing the raw
            // longest-edge angle here would allow a one-cell measuring error to rotate the
            // entire solver frame and would make opposite sides subtly non-parallel.
            val baseAngle = normalizeAngle180(Math.toRadians(gridRotationDeg))
            val angleSet = listOf(baseAngle, baseAngle + PI / 2.0, baseAngle + PI / 4.0, baseAngle - PI / 4.0)

            val supportLines = cycle.edges.map { edge ->
                val a = requireNotNull(nodes[edge.startNodeId])
                val b = requireNotNull(nodes[edge.endNodeId])
                val midpointX = (a.x + b.x) / 2.0
                val midpointY = (a.y + b.y) / 2.0
                val rawAngle = atan2(b.y - a.y, b.x - a.x)
                val angle = if (edge.locked || (a.locked && b.locked)) rawAngle else snapAngle(rawAngle, angleSet)
                val rawAnchor = when {
                    a.locked -> a.x to a.y
                    b.locked -> b.x to b.y
                    else -> midpointX to midpointY
                }
                val gridAnchor = MetricPlanGrid.snap(LocalPoint(rawAnchor.first, rawAnchor.second), gridRotationDeg)
                val anchor = gridAnchor.x to gridAnchor.y
                SupportLine(anchor.first, anchor.second, cos(angle), sin(angle))
            }
            val candidates = original.indices.map { index ->
                val node = original[index]
                if (node.locked) return@map node
                val previous = supportLines[(index - 1 + supportLines.size) % supportLines.size]
                val current = supportLines[index]
                val intersection = supportLineIntersection(previous, current, config.intersectionEpsilon)
                    ?: return@map node
                if (distance(node.x, node.y, intersection.first, intersection.second) >
                    config.maximumRegularizationDisplacementM
                ) node else node.copy(x = intersection.first, y = intersection.second)
            }
            val candidateArea = abs(signedArea(candidates))
            val areaRatio = candidateArea / originalArea
            if (candidateArea <= config.intersectionEpsilon || areaRatio !in 0.55..1.80 ||
                polygonSelfIntersects(candidates, config.intersectionEpsilon)
            ) {
                operationIssues += TopologyIssue(
                    code = "BOUNDARY_REGULARIZATION_REJECTED",
                    message = "Vyrovnanie obrysu bolo odmietnuté, pretože by vytvorilo neplatný polygón.",
                    severity = TopologyIssueSeverity.WARNING,
                    nodeIds = cycle.nodeIds
                )
                return
            }
            var moved = 0
            candidates.forEach { candidate ->
                val old = nodes[candidate.id] ?: return@forEach
                if (distance(old, candidate) > config.intersectionEpsilon) {
                    nodes[candidate.id] = candidate
                    movements += NodeMovement(
                        old.id, old.id, old.x, old.y, candidate.x, candidate.y, "REGULARIZE_BOUNDARY"
                    )
                    moved++
                }
            }
            statistics = statistics.copy(regularizedBoundaryNodes = statistics.regularizedBoundaryNodes + moved)
            collapseTinyBoundaryEdges(config)
        }

        /**
         * Aligns HIP and VALLEY constraints after the corrected boundary exists.
         * Each diagonal is constrained to ±45° from its connected EAVE. When
         * several diagonals meet, their common node is solved by deterministic
         * least-squares line intersection instead of being moved edge-by-edge.
         */
        fun alignHipAndValley(config: RoofSolverConfig) {
            val cycle = orderedBoundaryCycle() ?: return
            val boundaryNodes = cycle.nodeIds.toSet()
            val boundaryEdgesAt = mutableMapOf<String, MutableList<TopologyEdge>>()
            cycle.edges.forEach { edge ->
                boundaryEdgesAt.getOrPut(edge.startNodeId) { mutableListOf() } += edge
                boundaryEdgesAt.getOrPut(edge.endNodeId) { mutableListOf() } += edge
            }
            val kinds = boundaryVertexKinds(cycle)
            val constraints = mutableMapOf<String, MutableList<DiagonalConstraint>>()
            edges.values.asSequence()
                .filter { !it.boundary && !it.locked && it.type in setOf(LineType.HIP, LineType.VALLEY) }
                .sortedBy { it.id }
                .forEach { edge ->
                    val startBoundary = edge.startNodeId in boundaryNodes
                    val endBoundary = edge.endNodeId in boundaryNodes
                    if (startBoundary == endBoundary) return@forEach
                    val anchorId = if (startBoundary) edge.startNodeId else edge.endNodeId
                    val mobileId = if (startBoundary) edge.endNodeId else edge.startNodeId
                    val anchor = nodes[anchorId] ?: return@forEach
                    val mobile = nodes[mobileId] ?: return@forEach
                    if (mobile.locked || mobileId in boundaryNodes) return@forEach
                    val expectedKind = if (edge.type == LineType.HIP) BoundaryVertexKind.CONVEX else BoundaryVertexKind.CONCAVE
                    if (kinds[anchorId] != expectedKind) return@forEach
                    val connectedEaves = boundaryEdgesAt[anchorId].orEmpty().filter { it.type == LineType.EAVE }
                    if (connectedEaves.isEmpty()) return@forEach
                    val currentAngle = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
                    val candidateAngles = connectedEaves.flatMap { eave ->
                        val eaveOtherId = if (eave.startNodeId == anchorId) eave.endNodeId else eave.startNodeId
                        val other = nodes[eaveOtherId] ?: return@flatMap emptyList()
                        val eaveAngle = atan2(other.y - anchor.y, other.x - anchor.x)
                        listOf(eaveAngle + PI / 4.0, eaveAngle - PI / 4.0)
                    }
                    val targetAngle = candidateAngles.minWithOrNull(
                        compareBy<Double> { angleDiff180(currentAngle, it) }.thenBy { normalizeAngle180(it) }
                    ) ?: return@forEach
                    var dx = cos(targetAngle)
                    var dy = sin(targetAngle)
                    if (dx * (mobile.x - anchor.x) + dy * (mobile.y - anchor.y) < 0.0) {
                        dx = -dx
                        dy = -dy
                    }
                    constraints.getOrPut(mobileId) { mutableListOf() } += DiagonalConstraint(
                        edge.id, anchor.x, anchor.y, dx, dy, distance(anchor, mobile)
                    )
                }

            constraints.toSortedMap().forEach { (nodeId, nodeConstraints) ->
                val node = nodes[nodeId] ?: return@forEach
                val target = solveConstraintPoint(node, nodeConstraints, config.intersectionEpsilon)
                    ?: return@forEach
                val displacement = distance(node.x, node.y, target.first, target.second)
                if (displacement <= config.intersectionEpsilon ||
                    displacement > config.maximumRegularizationDisplacementM
                ) return@forEach
                nodes[nodeId] = node.copy(x = target.first, y = target.second, type = TopologyNodeType.JUNCTION)
                movements += NodeMovement(nodeId, nodeId, node.x, node.y, target.first, target.second, "ALIGN_HIP_VALLEY_45")
                statistics = statistics.copy(
                    alignedHipValleyNodes = statistics.alignedHipValleyNodes + 1
                )
            }
        }

        /** Repairs an older bad snap: HIP/VALLEY attached to a collinear
         * boundary split only centimetres from a real corner is rewired to the
         * corner and the tiny boundary segment disappears. */
        fun collapseInternalNearCornerSplits(config: RoofSolverConfig) {
            var changed = true
            while (changed) {
                changed = false
                val cycle = orderedBoundaryCycle() ?: return
                val boundaryIncident = cycle.nodeIds.associateWith { nodeId ->
                    cycle.edges.filter { it.startNodeId == nodeId || it.endNodeId == nodeId }
                }
                val candidate = cycle.nodeIds.sorted().firstNotNullOfOrNull splitLoop@{ splitId ->
                    val split = nodes[splitId] ?: return@splitLoop null
                    val incident = boundaryIncident[splitId].orEmpty()
                    if (incident.size != 2 || edges.values.none {
                            !it.boundary && (it.startNodeId == splitId || it.endNodeId == splitId)
                        }
                    ) return@splitLoop null
                    val neighbours = incident.mapNotNull { edge ->
                        nodes[if (edge.startNodeId == splitId) edge.endNodeId else edge.startNodeId]
                    }
                    if (neighbours.size != 2 || angularDistanceModuloPi(
                            atan2(neighbours[0].y - split.y, neighbours[0].x - split.x),
                            atan2(neighbours[1].y - split.y, neighbours[1].x - split.x)
                        ) > Math.toRadians(2.0)
                    ) return@splitLoop null
                    neighbours.filter { distance(split, it) <= config.snapToleranceM }
                        .sortedWith(compareBy<TopologyNode> { distance(split, it) }.thenBy { it.id })
                        .firstOrNull { neighbour ->
                            val neighbourEdges = boundaryIncident[neighbour.id].orEmpty()
                            if (neighbourEdges.size != 2) false else {
                                val cornerOthers = neighbourEdges.mapNotNull { edge ->
                                    nodes[if (edge.startNodeId == neighbour.id) edge.endNodeId else edge.startNodeId]
                                }
                                cornerOthers.size == 2 && angularDistanceModuloPi(
                                    atan2(cornerOthers[0].y - neighbour.y, cornerOthers[0].x - neighbour.x),
                                    atan2(cornerOthers[1].y - neighbour.y, cornerOthers[1].x - neighbour.x)
                                ) > Math.toRadians(2.0)
                            }
                        }?.let { split to it }
                }
                if (candidate != null) {
                    val (split, corner) = candidate
                    mergeCluster(
                        setOf(split.id, corner.id), forcedTargetId = corner.id,
                        forcedX = corner.x, forcedY = corner.y
                    )
                    statistics = statistics.copy(removedShortEdges = statistics.removedShortEdges + 1)
                    removeShortAndDuplicateEdges(config)
                    changed = true
                }
            }
        }

        /**
         * When HIP constraints move their common junction, a connected ridge
         * must remain parallel to the roof's dominant axes. Its opposite node
         * may slide along a straight, already split boundary side. Sliding that
         * collinear subdivision node does not change the physical footprint.
         */
        fun alignRidgesToStraightBoundary(config: RoofSolverConfig, angleToleranceDeg: Double = 5.0) {
            val cycle = orderedBoundaryCycle() ?: return
            val boundaryNodes = cycle.nodeIds.toSet()
            val dominantEdge = cycle.edges.maxByOrNull { edge ->
                val a = nodes[edge.startNodeId] ?: return@maxByOrNull 0.0
                val b = nodes[edge.endNodeId] ?: return@maxByOrNull 0.0
                distance(a, b)
            } ?: return
            val dominantA = nodes[dominantEdge.startNodeId] ?: return
            val dominantB = nodes[dominantEdge.endNodeId] ?: return
            val dominantAngle = atan2(dominantB.y - dominantA.y, dominantB.x - dominantA.x)

            edges.values.asSequence().filter { !it.boundary && !it.locked && it.type == LineType.RIDGE }
                .sortedBy { it.id }.forEach { ridge ->
                    val startBoundary = ridge.startNodeId in boundaryNodes
                    val endBoundary = ridge.endNodeId in boundaryNodes
                    if (startBoundary == endBoundary) return@forEach
                    val boundaryId = if (startBoundary) ridge.startNodeId else ridge.endNodeId
                    val anchorId = if (startBoundary) ridge.endNodeId else ridge.startNodeId
                    val boundary = nodes[boundaryId] ?: return@forEach
                    val anchor = nodes[anchorId] ?: return@forEach
                    val incident = cycle.edges.filter { it.startNodeId == boundaryId || it.endNodeId == boundaryId }
                    if (incident.size != 2) return@forEach
                    val otherNodes = incident.mapNotNull { edge ->
                        nodes[if (edge.startNodeId == boundaryId) edge.endNodeId else edge.startNodeId]
                    }
                    if (otherNodes.size != 2) return@forEach
                    val sideA = otherNodes[0]
                    val sideB = otherNodes[1]
                    val firstSideAngle = atan2(sideA.y - boundary.y, sideA.x - boundary.x)
                    val secondSideAngle = atan2(sideB.y - boundary.y, sideB.x - boundary.x)
                    if (angularDistanceModuloPi(firstSideAngle, secondSideAngle) > Math.toRadians(2.0)) return@forEach

                    val currentAngle = atan2(boundary.y - anchor.y, boundary.x - anchor.x)
                    val targetAngle = listOf(dominantAngle, dominantAngle + PI / 2.0)
                        .minByOrNull { angularDistanceModuloPi(currentAngle, it) } ?: return@forEach
                    if (angularDistanceModuloPi(currentAngle, targetAngle) > Math.toRadians(angleToleranceDeg)) return@forEach
                    val target = supportLineIntersection(
                        SupportLine(anchor.x, anchor.y, cos(targetAngle), sin(targetAngle)),
                        SupportLine(boundary.x, boundary.y, sideA.x - boundary.x, sideA.y - boundary.y),
                        config.intersectionEpsilon
                    ) ?: return@forEach
                    val sideDx = sideB.x - sideA.x
                    val sideDy = sideB.y - sideA.y
                    val sideLength2 = sideDx * sideDx + sideDy * sideDy
                    if (sideLength2 <= config.intersectionEpsilon) return@forEach
                    val t = ((target.first - sideA.x) * sideDx + (target.second - sideA.y) * sideDy) / sideLength2
                    if (t !in -1e-7..1.0000001) return@forEach
                    val displacement = distance(boundary.x, boundary.y, target.first, target.second)
                    if (displacement <= config.intersectionEpsilon ||
                        displacement > config.maximumRegularizationDisplacementM
                    ) return@forEach
                    nodes[boundaryId] = boundary.copy(x = target.first, y = target.second)
                    movements += NodeMovement(
                        boundaryId, boundaryId, boundary.x, boundary.y,
                        target.first, target.second, "ALIGN_RIDGE_TO_BOUNDARY"
                    )
                    statistics = statistics.copy(alignedRidgeNodes = statistics.alignedRidgeNodes + 1)
                }
        }

        private fun collapseTinyBoundaryEdges(config: RoofSolverConfig) {
            var changed = true
            while (changed) {
                changed = false
                val tiny = edges.values.asSequence().filter { it.boundary }.sortedBy { it.id }.firstOrNull { edge ->
                    val a = nodes[edge.startNodeId]
                    val b = nodes[edge.endNodeId]
                    a != null && b != null && distance(a, b) < config.minimumBoundaryEdgeLengthM &&
                        !(a.locked && b.locked)
                } ?: break
                mergeCluster(setOf(tiny.startNodeId, tiny.endNodeId))
                edges.remove(tiny.id)
                changed = true
            }
        }

        private fun orderedBoundaryCycle(): BoundaryCycle? {
            val boundary = edges.values.filter { it.boundary }
            if (boundary.size < 3) return null
            val adjacency = mutableMapOf<String, MutableList<TopologyEdge>>()
            boundary.forEach { edge ->
                adjacency.getOrPut(edge.startNodeId) { mutableListOf() } += edge
                adjacency.getOrPut(edge.endNodeId) { mutableListOf() } += edge
            }
            if (adjacency.values.any { it.size != 2 }) return null
            val start = adjacency.keys.minOrNull() ?: return null
            var current = start
            var edge = adjacency.getValue(start).minBy { it.id }
            val nodeIds = mutableListOf<String>()
            val walkedEdges = mutableListOf<TopologyEdge>()
            val used = mutableSetOf<String>()
            while (edge.id !in used) {
                used += edge.id
                nodeIds += current
                walkedEdges += edge
                val next = if (edge.startNodeId == current) edge.endNodeId else edge.startNodeId
                current = next
                if (current == start) break
                edge = adjacency.getValue(current).firstOrNull { it.id !in used } ?: return null
            }
            if (current != start || used.size != boundary.size) return null
            return BoundaryCycle(nodeIds, walkedEdges)
        }

        private fun boundaryVertexKinds(cycle: BoundaryCycle): Map<String, BoundaryVertexKind> {
            val polygon = cycle.nodeIds.mapNotNull(nodes::get)
            if (polygon.size != cycle.nodeIds.size) return emptyMap()
            val orientation = if (signedArea(polygon) >= 0.0) 1.0 else -1.0
            return polygon.indices.associate { index ->
                val previous = polygon[(index - 1 + polygon.size) % polygon.size]
                val current = polygon[index]
                val next = polygon[(index + 1) % polygon.size]
                val turn = cross(
                    current.x - previous.x, current.y - previous.y,
                    next.x - current.x, next.y - current.y
                ) * orientation
                current.id to if (turn >= 0.0) BoundaryVertexKind.CONVEX else BoundaryVertexKind.CONCAVE
            }
        }

        fun mergeNearbyNodes(config: RoofSolverConfig) {
            val candidates = mutableListOf<Triple<Double, String, String>>()
            val list = nodes.values.sortedBy { it.id }
            for (i in list.indices) for (j in i + 1 until list.size) {
                val d = distance(list[i], list[j])
                if (d <= config.mergeToleranceM) candidates += Triple(d, list[i].id, list[j].id)
            }
            candidates.sortWith(compareBy<Triple<Double, String, String>> { it.first }
                .thenBy { it.second }.thenBy { it.third })
            val clusters = list.associate { it.id to mutableSetOf(it.id) }.toMutableMap()
            fun rootOf(id: String): String = clusters.entries.first { id in it.value }.key
            candidates.forEach { (_, aId, bId) ->
                val aRoot = rootOf(aId)
                val bRoot = rootOf(bId)
                if (aRoot == bRoot) return@forEach
                val merged = (clusters.getValue(aRoot) + clusters.getValue(bRoot)).toSet()
                val members = merged.mapNotNull(nodes::get)
                val locked = members.filter { it.locked }
                if (locked.size > 1 && locked.any { distance(it, locked.first()) > config.intersectionEpsilon }) {
                    return@forEach
                }
                var diameter = 0.0
                for (i in members.indices) for (j in i + 1 until members.size) {
                    diameter = max(diameter, distance(members[i], members[j]))
                }
                if (diameter > config.mergeToleranceM) return@forEach
                val keep = minOf(aRoot, bRoot)
                val remove = maxOf(aRoot, bRoot)
                clusters[keep] = merged.toMutableSet()
                clusters.remove(remove)
            }
            clusters.values.filter { it.size > 1 }.sortedBy { it.minOrNull() }.forEach { ids ->
                mergeCluster(ids)
            }
            removeShortAndDuplicateEdges(config)
        }

        private fun mergeCluster(
            ids: Set<String>,
            forcedTargetId: String? = null,
            forcedX: Double? = null,
            forcedY: Double? = null
        ) {
            val members = ids.mapNotNull(nodes::get).sortedBy { it.id }
            if (members.size < 2) return
            val locked = members.firstOrNull { it.locked }
            val targetId = forcedTargetId?.takeIf { id -> members.any { it.id == id } }
                ?: locked?.id ?: members.first().id
            val targetX = forcedX ?: locked?.x ?: members.map { it.x }.average()
            val targetY = forcedY ?: locked?.y ?: members.map { it.y }.average()
            val targetType = members.maxBy { nodeTypePriority(it.type) }.type
            val targetWasLocked = members.first { it.id == targetId }.locked
            val target = TopologyNode(targetId, targetX, targetY, targetType, targetWasLocked || locked != null)
            members.forEach { node ->
                if (node.id != targetId || distance(node.x, node.y, targetX, targetY) > 0.0) {
                    movements += NodeMovement(node.id, targetId, node.x, node.y, targetX, targetY, "MERGE")
                }
            }
            ids.forEach { nodes.remove(it) }
            nodes[targetId] = target
            edges.replaceAll { _, edge ->
                edge.copy(
                    startNodeId = if (edge.startNodeId in ids) targetId else edge.startNodeId,
                    endNodeId = if (edge.endNodeId in ids) targetId else edge.endNodeId
                )
            }
            statistics = statistics.copy(mergedNodes = statistics.mergedNodes + members.size - 1)
        }

        fun splitAllIntersections(config: RoofSolverConfig) {
            val snapshot = edges.values.sortedBy { it.id }
            val cuts = snapshot.associate { it.id to mutableListOf(0.0 to it.startNodeId, 1.0 to it.endNodeId) }.toMutableMap()
            for (i in snapshot.indices) for (j in i + 1 until snapshot.size) {
                val first = snapshot[i]
                val second = snapshot[j]
                val a = nodes[first.startNodeId] ?: continue
                val b = nodes[first.endNodeId] ?: continue
                val c = nodes[second.startNodeId] ?: continue
                val d = nodes[second.endNodeId] ?: continue
                val hit = segmentIntersection(a, b, c, d, config.intersectionEpsilon)
                if (hit.collinearOverlap) continue
                if (!hit.exists) continue
                val firstNode = endpointNode(first, hit.t, config.intersectionEpsilon)
                val secondNode = endpointNode(second, hit.u, config.intersectionEpsilon)
                val sharedNodeId = when {
                    firstNode != null && secondNode != null -> {
                        if (firstNode != secondNode) {
                            val firstValue = nodes[firstNode]
                            val secondValue = nodes[secondNode]
                            if (firstValue != null && secondValue != null &&
                                distance(firstValue, secondValue) <= config.mergeToleranceM
                            ) {
                                if (firstValue.locked && secondValue.locked &&
                                    distance(firstValue, secondValue) > config.intersectionEpsilon
                                ) continue
                                mergeCluster(setOf(firstNode, secondNode))
                                if (nodes.containsKey(firstNode)) firstNode else secondNode
                            } else continue
                        } else firstNode
                    }
                    firstNode != null -> firstNode
                    secondNode != null -> secondNode
                    else -> ensureIntersectionNode(hit.x, hit.y, config.intersectionEpsilon)
                }
                cuts[first.id]?.add(hit.t.coerceIn(0.0, 1.0) to sharedNodeId)
                cuts[second.id]?.add(hit.u.coerceIn(0.0, 1.0) to sharedNodeId)
            }
            snapshot.forEach { original ->
                val raw = cuts[original.id].orEmpty().sortedWith(compareBy<Pair<Double, String>> { it.first }.thenBy { it.second })
                val unique = mutableListOf<Pair<Double, String>>()
                raw.forEach { cut ->
                    if (unique.isEmpty() || abs(cut.first - unique.last().first) > config.intersectionEpsilon) {
                        unique += cut
                    } else if (cut.second < unique.last().second) {
                        unique[unique.lastIndex] = cut
                    }
                }
                if (unique.size <= 2) return@forEach
                edges.remove(original.id)
                unique.zipWithNext().forEachIndexed { index, (from, to) ->
                    if (from.second == to.second) return@forEachIndexed
                    val id = segmentId(original.id, index, unique.size - 1)
                    edges[id] = original.copy(id = id, startNodeId = from.second, endNodeId = to.second)
                }
                statistics = statistics.copy(splitEdges = statistics.splitEdges + unique.size - 2)
            }
        }

        private fun endpointNode(edge: TopologyEdge, t: Double, epsilon: Double): String? = when {
            t <= epsilon -> edge.startNodeId
            t >= 1.0 - epsilon -> edge.endNodeId
            else -> null
        }

        private fun ensureIntersectionNode(x: Double, y: Double, epsilon: Double): String {
            nodes.values.firstOrNull { distance(it.x, it.y, x, y) <= epsilon }?.let { return it.id }
            val id = nextNodeId("intersection")
            nodes[id] = TopologyNode(id, x, y, TopologyNodeType.INTERSECTION)
            statistics = statistics.copy(createdIntersections = statistics.createdIntersections + 1)
            return id
        }

        fun snapFreeInternalEnds(config: RoofSolverConfig) {
            val boundaryNodeIds = edges.values.asSequence().filter { it.boundary }
                .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
            val endpoints = edges.values.filterNot { it.boundary }.flatMap { edge ->
                listOf(edge.id to edge.startNodeId, edge.id to edge.endNodeId)
            }.sortedWith(compareBy<Pair<String, String>> { it.second }.thenBy { it.first })
            endpoints.forEach { (edgeId, nodeId) ->
                val edge = edges[edgeId] ?: return@forEach
                val degree = edges.values.count { it.startNodeId == nodeId || it.endNodeId == nodeId }
                if (degree != 1) return@forEach
                val node = nodes[nodeId] ?: return@forEach
                val otherId = if (edge.startNodeId == nodeId) edge.endNodeId else edge.startNodeId
                val nodeCandidate = nodes.values.asSequence()
                    .filter { it.id != nodeId && it.id != otherId }
                    .map { it to distance(node, it) }
                    .filter { it.second <= config.snapToleranceM }
                    .sortedWith(compareBy<Pair<TopologyNode, Double>> { it.second }.thenBy { it.first.id })
                    .firstOrNull()
                // A nearby existing footprint vertex has precedence over a
                // mathematically closer projection onto the adjacent boundary
                // edge. Otherwise a line drawn only a few centimetres from a
                // corner creates a tiny 76/183 mm boundary segment instead of
                // magnetising to that corner.
                val boundaryNodeCandidate = nodes.values.asSequence()
                    .filter { it.id in boundaryNodeIds && it.id != nodeId && it.id != otherId }
                    .map { it to distance(node, it) }
                    .filter { it.second <= config.snapToleranceM }
                    .sortedWith(compareBy<Pair<TopologyNode, Double>> { it.second }.thenBy { it.first.id })
                    .firstOrNull()
                val edgeCandidate = edges.values.asSequence()
                    .filter { it.id != edgeId && it.startNodeId != nodeId && it.endNodeId != nodeId }
                    .mapNotNull { candidate ->
                        val a = nodes[candidate.startNodeId] ?: return@mapNotNull null
                        val b = nodes[candidate.endNodeId] ?: return@mapNotNull null
                        val projection = projectToSegment(node.x, node.y, a, b)
                        if (projection.t <= config.intersectionEpsilon || projection.t >= 1.0 - config.intersectionEpsilon) null
                        else Triple(candidate, projection, hypot(node.x - projection.x, node.y - projection.y))
                    }
                    .filter { it.third <= config.snapToleranceM }
                    .sortedWith(compareBy<Triple<TopologyEdge, Projection, Double>> { it.third }.thenBy { it.first.id })
                    .firstOrNull()
                val preferredNode = boundaryNodeCandidate ?: nodeCandidate
                val useNode = boundaryNodeCandidate != null ||
                    (preferredNode != null && (edgeCandidate == null || preferredNode.second <= edgeCandidate.third))
                if (node.locked) {
                    if (nodeCandidate != null || edgeCandidate != null) {
                        operationIssues += TopologyIssue(
                            "LOCKED_FREE_END",
                            "Uzamknutý koniec ${edge.type.label} sa nepresunul.",
                            TopologyIssueSeverity.WARNING,
                            nodeIds = listOf(node.id), edgeIds = listOf(edge.id), x = node.x, y = node.y
                        )
                    }
                    return@forEach
                }
                if (useNode) {
                    val target = preferredNode!!.first
                    rewireEndpoint(edgeId, nodeId, target.id)
                    nodes.remove(nodeId)
                    movements += NodeMovement(nodeId, target.id, node.x, node.y, target.x, target.y, "SNAP_TO_NODE")
                    statistics = statistics.copy(snappedFreeEnds = statistics.snappedFreeEnds + 1)
                } else if (edgeCandidate != null) {
                    val targetEdge = edgeCandidate.first
                    val p = edgeCandidate.second
                    val junctionId = nextNodeId("junction")
                    nodes[junctionId] = TopologyNode(junctionId, p.x, p.y, TopologyNodeType.JUNCTION)
                    rewireEndpoint(edgeId, nodeId, junctionId)
                    nodes.remove(nodeId)
                    splitExistingEdge(targetEdge.id, junctionId)
                    movements += NodeMovement(nodeId, junctionId, node.x, node.y, p.x, p.y, "SNAP_TO_EDGE")
                    statistics = statistics.copy(
                        snappedFreeEnds = statistics.snappedFreeEnds + 1,
                        splitEdges = statistics.splitEdges + 1
                    )
                }
            }
        }

        private fun rewireEndpoint(edgeId: String, oldNodeId: String, newNodeId: String) {
            val edge = edges[edgeId] ?: return
            edges[edgeId] = edge.copy(
                startNodeId = if (edge.startNodeId == oldNodeId) newNodeId else edge.startNodeId,
                endNodeId = if (edge.endNodeId == oldNodeId) newNodeId else edge.endNodeId
            )
        }

        private fun splitExistingEdge(edgeId: String, nodeId: String) {
            val edge = edges.remove(edgeId) ?: return
            edges[segmentId(edgeId, 0, 2)] = edge.copy(
                id = segmentId(edgeId, 0, 2), endNodeId = nodeId
            )
            edges[segmentId(edgeId, 1, 2)] = edge.copy(
                id = segmentId(edgeId, 1, 2), startNodeId = nodeId
            )
        }

        fun removeShortAndDuplicateEdges(config: RoofSolverConfig) {
            var short = 0
            edges.values.toList().forEach { edge ->
                val a = nodes[edge.startNodeId]
                val b = nodes[edge.endNodeId]
                if (a == null || b == null || edge.startNodeId == edge.endNodeId || distance(a, b) <= config.minimumEdgeLengthM) {
                    edges.remove(edge.id)
                    short++
                }
            }
            var duplicates = 0
            edges.values.groupBy { unorderedPair(it.startNodeId, it.endNodeId) }.values.forEach { group ->
                if (group.size > 1) {
                    val keep = group.sortedWith(compareByDescending<TopologyEdge> { it.locked }
                        .thenByDescending { it.boundary }.thenBy { it.id }).first()
                    group.filter { it.id != keep.id }.forEach { edges.remove(it.id); duplicates++ }
                }
            }
            val usedNodes = edges.values.flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
            nodes.keys.toList().filter { it !in usedNodes }.forEach(nodes::remove)
            statistics = statistics.copy(
                removedShortEdges = statistics.removedShortEdges + short,
                removedDuplicateEdges = statistics.removedDuplicateEdges + duplicates
            )
        }

        fun normalizeNodeTypes() {
            val incident = nodes.keys.associateWith { id ->
                edges.values.filter { it.startNodeId == id || it.endNodeId == id }
            }
            nodes.replaceAll { id, node ->
                val at = incident[id].orEmpty()
                val type = when {
                    at.any { it.boundary } -> TopologyNodeType.FOOTPRINT
                    at.size > 2 -> TopologyNodeType.JUNCTION
                    node.type == TopologyNodeType.INTERSECTION -> TopologyNodeType.INTERSECTION
                    else -> TopologyNodeType.LINE_ENDPOINT
                }
                node.copy(type = type)
            }
        }

        fun mergeSelected(ids: Set<String>, preferred: String?, epsilon: Double) {
            val members = ids.mapNotNull(nodes::get).sortedBy { it.id }
            if (members.size < 2) return
            val locked = members.filter { it.locked }
            if (locked.size > 1 && locked.any { distance(it, locked.first()) > epsilon }) {
                operationIssues += error(
                    "LOCKED_NODES_CONFLICT",
                    "Dva uzamknuté body s rozdielnou polohou nemožno zlúčiť.",
                    nodes = locked.map { it.id }
                )
                return
            }
            val chosen = locked.firstOrNull()
                ?: preferred?.takeIf { it in ids }?.let(nodes::get)
            val targetId = chosen?.id ?: members.first().id
            val x = chosen?.x ?: members.map { it.x }.average()
            val y = chosen?.y ?: members.map { it.y }.average()
            mergeCluster(ids, forcedTargetId = targetId, forcedX = x, forcedY = y)
        }

        fun disconnect(nodeId: String) {
            val node = nodes[nodeId] ?: return
            val incident = edges.values.filter { it.startNodeId == nodeId || it.endNodeId == nodeId }.sortedBy { it.id }
            incident.drop(1).forEachIndexed { index, edge ->
                val newId = uniqueId("$nodeId-disconnected-${(index + 1).toString().padStart(2, '0')}", nodes.keys)
                nodes[newId] = node.copy(id = newId, type = TopologyNodeType.LINE_ENDPOINT, locked = false)
                edges[edge.id] = edge.copy(
                    startNodeId = if (edge.startNodeId == nodeId) newId else edge.startNodeId,
                    endNodeId = if (edge.endNodeId == nodeId) newId else edge.endNodeId
                )
            }
        }

        fun splitEdgeAt(edgeId: String, x: Double, y: Double, toleranceM: Double) {
            val edge = edges[edgeId] ?: return
            val a = nodes[edge.startNodeId] ?: return
            val b = nodes[edge.endNodeId] ?: return
            val p = projectToSegment(x, y, a, b)
            if (p.t <= 1e-7 || p.t >= 1.0 - 1e-7 || hypot(x - p.x, y - p.y) > toleranceM) return
            val nodeId = nextNodeId("manual-split")
            nodes[nodeId] = TopologyNode(nodeId, p.x, p.y, TopologyNodeType.JUNCTION)
            splitExistingEdge(edge.id, nodeId)
            statistics = statistics.copy(splitEdges = statistics.splitEdges + 1)
        }

        private fun nextNodeId(kind: String): String {
            while (true) {
                generatedNodeCounter++
                val id = "topology-$kind-${generatedNodeCounter.toString().padStart(6, '0')}"
                if (id !in nodes) return id
            }
        }

        private fun segmentId(base: String, index: Int, total: Int): String {
            if (total == 1 && base !in edges) return base
            return uniqueId("$base-segment-${(index + 1).toString().padStart(3, '0')}", edges.keys)
        }
    }

    private data class BoundaryCycle(
        val nodeIds: List<String>,
        val edges: List<TopologyEdge>
    )

    private enum class BoundaryVertexKind { CONVEX, CONCAVE }

    private data class SupportLine(
        val x: Double,
        val y: Double,
        val dx: Double,
        val dy: Double
    )

    private data class DiagonalConstraint(
        val edgeId: String,
        val anchorX: Double,
        val anchorY: Double,
        val dx: Double,
        val dy: Double,
        val originalLength: Double
    )

    private data class Projection(val x: Double, val y: Double, val t: Double)

    private data class SegmentHit(
        val exists: Boolean,
        val x: Double = Double.NaN,
        val y: Double = Double.NaN,
        val t: Double = Double.NaN,
        val u: Double = Double.NaN,
        val collinearOverlap: Boolean = false
    )

    private fun normalizeAngle180(angle: Double): Double {
        var normalized = angle % PI
        if (normalized < 0.0) normalized += PI
        return normalized
    }

    private fun angleDiff180(first: Double, second: Double): Double {
        val raw = abs(normalizeAngle180(first) - normalizeAngle180(second))
        return min(raw, PI - raw)
    }

    private fun snapAngle(angle: Double, allowed: List<Double>): Double =
        allowed.minWithOrNull(compareBy<Double> { angleDiff180(angle, it) }.thenBy { normalizeAngle180(it) })
            ?: angle

    private fun supportLineIntersection(
        first: SupportLine,
        second: SupportLine,
        epsilon: Double
    ): Pair<Double, Double>? {
        val denominator = cross(first.dx, first.dy, second.dx, second.dy)
        if (abs(denominator) <= epsilon) return null
        val qx = second.x - first.x
        val qy = second.y - first.y
        val t = cross(qx, qy, second.dx, second.dy) / denominator
        return first.x + t * first.dx to first.y + t * first.dy
    }

    private fun solveConstraintPoint(
        current: TopologyNode,
        constraints: List<DiagonalConstraint>,
        epsilon: Double
    ): Pair<Double, Double>? {
        if (constraints.isEmpty()) return null
        if (constraints.size == 1) {
            val c = constraints.first()
            return c.anchorX + c.dx * c.originalLength to c.anchorY + c.dy * c.originalLength
        }
        var a11 = 0.0
        var a12 = 0.0
        var a22 = 0.0
        var b1 = 0.0
        var b2 = 0.0
        constraints.sortedBy { it.edgeId }.forEach { c ->
            val m11 = 1.0 - c.dx * c.dx
            val m12 = -c.dx * c.dy
            val m22 = 1.0 - c.dy * c.dy
            a11 += m11
            a12 += m12
            a22 += m22
            b1 += m11 * c.anchorX + m12 * c.anchorY
            b2 += m12 * c.anchorX + m22 * c.anchorY
        }
        val determinant = a11 * a22 - a12 * a12
        if (abs(determinant) > epsilon) {
            return (b1 * a22 - b2 * a12) / determinant to
                (a11 * b2 - a12 * b1) / determinant
        }
        val projections = constraints.map { c ->
            val along = (current.x - c.anchorX) * c.dx + (current.y - c.anchorY) * c.dy
            c.anchorX + along * c.dx to c.anchorY + along * c.dy
        }
        return projections.map { it.first }.average() to projections.map { it.second }.average()
    }

    private fun polygonSelfIntersects(nodes: List<TopologyNode>, epsilon: Double): Boolean {
        if (nodes.size < 3) return true
        for (firstIndex in nodes.indices) {
            val firstNext = (firstIndex + 1) % nodes.size
            for (secondIndex in firstIndex + 1 until nodes.size) {
                val secondNext = (secondIndex + 1) % nodes.size
                if (firstIndex == secondIndex || firstNext == secondIndex || secondNext == firstIndex) continue
                val hit = segmentIntersection(
                    nodes[firstIndex], nodes[firstNext], nodes[secondIndex], nodes[secondNext], epsilon
                )
                if (hit.exists || hit.collinearOverlap) return true
            }
        }
        return false
    }

    private fun segmentIntersection(
        a: TopologyNode,
        b: TopologyNode,
        c: TopologyNode,
        d: TopologyNode,
        epsilon: Double
    ): SegmentHit {
        val rx = b.x - a.x
        val ry = b.y - a.y
        val sx = d.x - c.x
        val sy = d.y - c.y
        val denominator = cross(rx, ry, sx, sy)
        val qpx = c.x - a.x
        val qpy = c.y - a.y
        if (abs(denominator) <= epsilon) {
            if (abs(cross(qpx, qpy, rx, ry)) > epsilon) return SegmentHit(false)
            val rr = rx * rx + ry * ry
            if (rr <= epsilon * epsilon) return SegmentHit(false)
            val t0 = (qpx * rx + qpy * ry) / rr
            val t1 = t0 + (sx * rx + sy * ry) / rr
            val overlapStart = max(0.0, min(t0, t1))
            val overlapEnd = min(1.0, max(t0, t1))
            return SegmentHit(false, collinearOverlap = overlapEnd - overlapStart > epsilon)
        }
        val t = cross(qpx, qpy, sx, sy) / denominator
        val u = cross(qpx, qpy, rx, ry) / denominator
        if (t < -epsilon || t > 1.0 + epsilon || u < -epsilon || u > 1.0 + epsilon) return SegmentHit(false)
        return SegmentHit(true, a.x + t * rx, a.y + t * ry, t, u)
    }

    private fun projectToSegment(x: Double, y: Double, a: TopologyNode, b: TopologyNode): Projection {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val length2 = dx * dx + dy * dy
        if (length2 <= 1e-20) return Projection(a.x, a.y, 0.0)
        val t = (((x - a.x) * dx + (y - a.y) * dy) / length2).coerceIn(0.0, 1.0)
        return Projection(a.x + t * dx, a.y + t * dy, t)
    }

    private fun findBridges(topology: RoofTopology): Set<String> {
        val adjacency = mutableMapOf<String, MutableList<Pair<String, String>>>()
        topology.edges.forEach { edge ->
            adjacency.getOrPut(edge.startNodeId) { mutableListOf() } += edge.endNodeId to edge.id
            adjacency.getOrPut(edge.endNodeId) { mutableListOf() } += edge.startNodeId to edge.id
        }
        val discovery = mutableMapOf<String, Int>()
        val low = mutableMapOf<String, Int>()
        val bridges = mutableSetOf<String>()
        var time = 0
        fun visit(node: String, parentEdge: String?) {
            discovery[node] = ++time
            low[node] = time
            adjacency[node].orEmpty().sortedWith(compareBy<Pair<String, String>> { it.second }.thenBy { it.first })
                .forEach { (next, edgeId) ->
                    if (edgeId == parentEdge) return@forEach
                    if (next !in discovery) {
                        visit(next, edgeId)
                        low[node] = min(low.getValue(node), low.getValue(next))
                        if (low.getValue(next) > discovery.getValue(node)) bridges += edgeId
                    } else {
                        low[node] = min(low.getValue(node), discovery.getValue(next))
                    }
                }
        }
        adjacency.keys.sorted().forEach { if (it !in discovery) visit(it, null) }
        return bridges
    }

    private fun error(
        code: String,
        message: String,
        nodes: List<String> = emptyList(),
        edges: List<String> = emptyList(),
        x: Double? = null,
        y: Double? = null,
        distance: Double? = null
    ) = TopologyIssue(code, message, TopologyIssueSeverity.ERROR, nodes, edges, x, y, distance)
}

private fun RoofTopology.deepCopy() = RoofTopology(
    origin = origin.copy(),
    nodes = nodes.map { it.copy() },
    edges = edges.map { it.copy() },
    schemaVersion = schemaVersion,
    gridRotationDeg = gridRotationDeg
)

private fun distance(a: TopologyNode, b: TopologyNode): Double = hypot(a.x - b.x, a.y - b.y)
private fun distance(ax: Double, ay: Double, bx: Double, by: Double): Double = hypot(ax - bx, ay - by)
private fun cross(ax: Double, ay: Double, bx: Double, by: Double): Double = ax * by - ay * bx
private fun unorderedPair(a: String, b: String) = if (a <= b) a to b else b to a
private fun nodeTypePriority(type: TopologyNodeType): Int = when (type) {
    TopologyNodeType.FOOTPRINT -> 4
    TopologyNodeType.INTERSECTION -> 3
    TopologyNodeType.JUNCTION -> 2
    TopologyNodeType.LINE_ENDPOINT -> 1
}

private fun signedArea(nodes: List<TopologyNode>): Double {
    if (nodes.size < 3) return 0.0
    return nodes.indices.sumOf { index ->
        val next = (index + 1) % nodes.size
        nodes[index].x * nodes[next].y - nodes[next].x * nodes[index].y
    } / 2.0
}

private fun canonicalCycle(ids: List<String>): String {
    if (ids.isEmpty()) return ""
    fun rotations(values: List<String>) = values.indices.map { shift ->
        values.indices.joinToString("|") { values[(it + shift) % values.size] }
    }
    return (rotations(ids) + rotations(ids.asReversed())).minOrNull().orEmpty()
}

private fun uniqueId(base: String, existing: Collection<String>): String {
    if (base !in existing) return base
    var suffix = 2
    while ("$base-$suffix" in existing) suffix++
    return "$base-$suffix"
}

private fun formatM(value: Double): String = "%.3f".format(java.util.Locale.US, value)
