package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class RoofSuperstructureSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun graph(): RoofGraph {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 4.0),
            GraphNode("b", 10.0, 0.0, 4.0),
            GraphNode("c", 10.0, 8.0, 5.6),
            GraphNode("d", 0.0, 8.0, 5.6)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("eave", "a", "b", true, EdgeSemantic.EAVE, setOf("face")),
            GraphEdge("right", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
            GraphEdge("high", "c", "d", true, EdgeSemantic.RIDGE, setOf("face")),
            GraphEdge("left", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
        ).associateBy { it.id }
        val face = GraphFace(
            id = "face",
            orderedNodeIds = listOf("a", "b", "c", "d"),
            orderedEdgeIds = listOf("eave", "right", "high", "left"),
            signedAreaM2 = 80.0,
            plane = RoofPlane(0.0, 0.2, 4.0)
        )
        return RoofGraph(origin, nodes, edges, mapOf(face.id to face))
    }

    private fun objectAt(
        type: ObjectType,
        widthMm: Double,
        depthMm: Double,
        dormerType: DormerType = DormerType.GABLE
    ) = RoofObject(
        id = "test-${type.name.lowercase()}",
        type = type,
        center = Geometry.toGeo(LocalPoint(5.0, 4.0), origin),
        widthMm = widthMm,
        heightMm = depthMm,
        attachedFaceId = "face",
        dormerType = dormerType,
        superstructureHeightM = 1.2,
        superstructureSlopeDeg = 25.0
    )

    @Test
    fun `gable dormer cuts host face and creates its own roof surfaces`() {
        val solution = RoofSuperstructureSolver.solve(
            graph(), listOf(objectAt(ObjectType.DORMER, 1800.0, 2400.0))
        )
        val item = solution.items.single()
        assertEquals(1, solution.graphWithOpenings.faces.getValue("face").holeNodeIdLoops.size)
        assertEquals(4.32, item.openingPlanAreaM2, 1e-6)
        assertEquals(4.32 * sqrt(1.04), item.openingArea3DM2, 1e-6)
        assertTrue(item.addedRoofAreaM2 > 0.0)
        assertEquals(2, item.surfaces.count { it.role == SuperstructureSurfaceRole.ROOF })
        assertFalse(item.projectsBeyondHost)
    }

    @Test
    fun `all dormer tiles produce deterministic roof geometry`() {
        DormerType.entries.forEach { type ->
            val item = RoofSuperstructureSolver.solve(
                graph(), listOf(objectAt(ObjectType.DORMER, 1800.0, 2400.0, type))
            ).items.single()
            assertTrue("$type must have a roof", item.surfaces.any { it.role == SuperstructureSurfaceRole.ROOF })
            assertTrue(item.surfaces.all { surface -> surface.vertices.size >= 3 })
        }
    }

    @Test
    fun `terrace is a real opening with floor and side walls but no added roof`() {
        val solution = RoofSuperstructureSolver.solve(
            graph(), listOf(objectAt(ObjectType.TERRACE, 3000.0, 4000.0))
        )
        val item = solution.items.single()
        assertEquals(12.0, item.openingPlanAreaM2, 1e-6)
        assertEquals(0.0, item.addedRoofAreaM2, 1e-9)
        assertEquals(1, item.surfaces.count { it.role == SuperstructureSurfaceRole.FLOOR })
        assertEquals(4, item.surfaces.count { it.role == SuperstructureSurfaceRole.WALL })
        assertEquals(1, solution.graphWithOpenings.faces.getValue("face").holeNodeIdLoops.size)
    }

    @Test
    fun `machine room and shaft are secondary components with flat roofs`() {
        val objects = listOf(
            objectAt(ObjectType.MACHINE_ROOM, 2200.0, 2600.0),
            objectAt(ObjectType.SHAFT, 1200.0, 1400.0).copy(id = "test-shaft-2")
        )
        val solution = RoofSuperstructureSolver.solve(graph(), objects)
        assertEquals(2, solution.items.size)
        solution.items.forEach { item ->
            assertEquals(1, item.surfaces.count { it.role == SuperstructureSurfaceRole.ROOF })
            assertEquals(4, item.surfaces.count { it.role == SuperstructureSurfaceRole.WALL })
        }
    }

    @Test
    fun `superstructure parameters survive canonical project json`() {
        val project = RoofProject(name = "Vikiere").apply {
            objects += objectAt(ObjectType.DORMER, 2100.0, 2800.0, DormerType.NAPOLEON).copy(
                superstructureHeightM = 1.75,
                superstructureSlopeDeg = 32.5
            )
            objects += objectAt(ObjectType.TERRACE, 3200.0, 4500.0).copy(
                id = "terrace-json",
                superstructureHeightM = 0.35
            )
        }
        val decoded = ProjectJson.decode(ProjectJson.encode(project))
        val dormer = decoded.objects.first { it.type == ObjectType.DORMER }
        val terrace = decoded.objects.first { it.type == ObjectType.TERRACE }
        assertEquals(DormerType.NAPOLEON, dormer.dormerType)
        assertEquals(1.75, dormer.superstructureHeightM, 0.0)
        assertEquals(32.5, dormer.superstructureSlopeDeg, 0.0)
        assertEquals(0.35, terrace.superstructureHeightM, 0.0)
    }
}
