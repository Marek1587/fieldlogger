package sk.strechasketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

enum class SuperstructureSurfaceRole { ROOF, WALL, FRONT, GLASS, FLOOR }

data class RoofSuperstructureSurface(
    val id: String,
    val role: SuperstructureSurfaceRole,
    val vertices: List<GraphNode>
)

data class SolvedRoofSuperstructure(
    val source: RoofObject,
    val hostFaceId: String,
    val footprint: List<GraphNode>,
    val surfaces: List<RoofSuperstructureSurface>,
    val openingPlanAreaM2: Double,
    val openingArea3DM2: Double,
    val addedRoofAreaM2: Double,
    val projectsBeyondHost: Boolean
)

data class RoofSuperstructureSolution(
    val graphWithOpenings: RoofGraph,
    val items: List<SolvedRoofSuperstructure>,
    val warnings: List<String>
)

/**
 * Deterministic secondary-envelope solver for dormers, shafts and machine rooms.
 *
 * It derives every surface from the already solved host [RoofPlane]. The saved RoofGraph is
 * never re-solved here. A fully contained footprint becomes a real inner loop of its host face,
 * while a projected machine room remains an explicit secondary component and reports the exact
 * clipped opening area. This keeps 2D, quantities, BIM and both 3D renderers on one data source.
 */
object RoofSuperstructureSolver {
    private val supported = setOf(
        ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT, ObjectType.TERRACE
    )

    fun solve(graph: RoofGraph, objects: List<RoofObject>): RoofSuperstructureSolution {
        val generatedNodes = linkedMapOf<String, GraphNode>()
        val generatedHoles = linkedMapOf<String, MutableList<List<String>>>()
        val warnings = arrayListOf<String>()
        val items = objects.filter { it.type in supported }.sortedBy { it.id }.mapNotNull { item ->
            val local = Geometry.toLocal(item.center, graph.origin)
            val face = item.attachedFaceId?.let(graph.faces::get)?.takeIf { contains(graph, it, local) }
                ?: graph.faces.values.sortedBy { it.id }.firstOrNull { contains(graph, it, local) }
            if (face == null) {
                warnings += "${item.type.label} ${item.id}: chýba hostiteľská strešná plocha."
                return@mapNotNull null
            }
            val plane = face.plane ?: run {
                warnings += "${item.type.label} ${item.id}: hostiteľská plocha nemá vyriešenú rovinu."
                return@mapNotNull null
            }
            val width = (item.widthMm.takeIf { it > 0.0 } ?: defaultWidth(item.type)) / 1000.0
            val depth = (item.heightMm.takeIf { it > 0.0 } ?: defaultDepth(item.type)) / 1000.0
            val axes = axes(item, face, graph)
            val footprint2D = rectangle(local, axes.first, axes.second, width, depth)
            val footprint = footprint2D.mapIndexed { index, point ->
                GraphNode("super-${item.id}-foot-$index", point.x, point.y, plane.zAt(point.x, point.y))
            }
            val outer = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
            val intersectionPlanArea = intersectionArea(footprint2D, outer)
            if (intersectionPlanArea <= 1e-6) {
                warnings += "${item.type.label} ${item.id}: pôdorys neleží na hostiteľskej ploche."
                return@mapNotNull null
            }
            val footprintArea = width * depth
            val fullyInside = abs(intersectionPlanArea - footprintArea) <= max(1e-6, footprintArea * 1e-7) &&
                face.holeNodeIdLoops.none { ids ->
                    val hole = ids.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
                    footprint2D.any { Geometry.pointInPolygon(it, hole) }
                }
            if (fullyInside) {
                footprint.forEach { generatedNodes[it.id] = it }
                generatedHoles.getOrPut(face.id, ::arrayListOf) += footprint.map { it.id }
            }
            val surfaces = when (item.type) {
                ObjectType.DORMER -> dormerSurfaces(item, footprint, axes.first, axes.second)
                ObjectType.MACHINE_ROOM, ObjectType.SHAFT -> boxSurfaces(item, footprint, graph)
                ObjectType.TERRACE -> terraceSurfaces(item, footprint)
                else -> emptyList()
            }
            val opening3D = intersectionPlanArea * sqrt(1.0 + plane.a * plane.a + plane.b * plane.b)
            val roofArea = surfaces.filter { it.role == SuperstructureSurfaceRole.ROOF }
                .sumOf { polygonArea3D(it.vertices) }
            SolvedRoofSuperstructure(
                source = item,
                hostFaceId = face.id,
                footprint = footprint,
                surfaces = surfaces,
                openingPlanAreaM2 = intersectionPlanArea,
                openingArea3DM2 = opening3D,
                addedRoofAreaM2 = roofArea,
                projectsBeyondHost = !fullyInside
            )
        }
        val faces = graph.faces.mapValues { (id, face) ->
            face.copy(holeNodeIdLoops = face.holeNodeIdLoops + generatedHoles[id].orEmpty())
        }
        return RoofSuperstructureSolution(
            graphWithOpenings = graph.copy(nodes = graph.nodes + generatedNodes, faces = faces),
            items = items,
            warnings = warnings
        )
    }

    private fun defaultWidth(type: ObjectType) = when (type) {
        ObjectType.DORMER -> 1800.0
        ObjectType.MACHINE_ROOM -> 4000.0
        ObjectType.SHAFT -> 1800.0
        ObjectType.TERRACE -> 3000.0
        else -> 1000.0
    }

    private fun defaultDepth(type: ObjectType) = when (type) {
        ObjectType.DORMER -> 2400.0
        ObjectType.MACHINE_ROOM -> 5000.0
        ObjectType.SHAFT -> 1800.0
        ObjectType.TERRACE -> 4000.0
        else -> 1000.0
    }

    /** Width is parallel to the host eave and depth points uphill. */
    private fun axes(item: RoofObject, face: GraphFace, graph: RoofGraph): Pair<LocalPoint, LocalPoint> {
        val plane = requireNotNull(face.plane)
        val gradient = hypot(plane.a, plane.b)
        if (gradient > 1e-8) {
            val uphill = LocalPoint(plane.a / gradient, plane.b / gradient)
            return LocalPoint(-uphill.y, uphill.x) to uphill
        }
        val angle = Math.toRadians(item.rotationDeg)
        val width = LocalPoint(cos(angle), sin(angle))
        return width to LocalPoint(-width.y, width.x)
    }

    private fun rectangle(
        center: LocalPoint,
        widthAxis: LocalPoint,
        depthAxis: LocalPoint,
        width: Double,
        depth: Double
    ): List<LocalPoint> = listOf(
        local(center, widthAxis, depthAxis, -width / 2.0, -depth / 2.0),
        local(center, widthAxis, depthAxis, width / 2.0, -depth / 2.0),
        local(center, widthAxis, depthAxis, width / 2.0, depth / 2.0),
        local(center, widthAxis, depthAxis, -width / 2.0, depth / 2.0)
    )

    private fun local(c: LocalPoint, u: LocalPoint, v: LocalPoint, du: Double, dv: Double) =
        LocalPoint(c.x + u.x * du + v.x * dv, c.y + u.y * du + v.y * dv)

    private fun dormerSurfaces(
        item: RoofObject,
        base: List<GraphNode>,
        widthAxis: LocalPoint,
        depthAxis: LocalPoint
    ): List<RoofSuperstructureSurface> {
        val rise = item.superstructureHeightM.coerceIn(0.3, 8.0)
        val pitch = Math.toRadians(item.superstructureSlopeDeg.coerceIn(2.0, 70.0))
        val width = hypot(base[1].x - base[0].x, base[1].y - base[0].y)
        fun node(suffix: String, x: Double, y: Double, z: Double) = GraphNode("super-${item.id}-$suffix", x, y, z)
        fun lifted(index: Int, suffix: String, dz: Double = rise) = base[index].let { node(suffix, it.x, it.y, it.z + dz) }
        val lf = lifted(0, "left-front-top")
        val rf = lifted(1, "right-front-top")
        val rb = lifted(2, "right-back-top")
        val lb = lifted(3, "left-back-top")
        val surfaces = arrayListOf<RoofSuperstructureSurface>()
        fun surface(id: String, role: SuperstructureSurfaceRole, vararg vertices: GraphNode) {
            surfaces += RoofSuperstructureSurface("super-${item.id}-$id", role, vertices.toList())
        }
        surface("wall-left", SuperstructureSurfaceRole.WALL, base[0], base[3], lb, lf)
        surface("wall-right", SuperstructureSurfaceRole.WALL, base[1], rf, rb, base[2])
        when (item.dormerType) {
            DormerType.SHED, DormerType.TRAPEZOID -> {
                val backRise = rise + tan(pitch) * hypot(base[3].x - base[0].x, base[3].y - base[0].y)
                val highRb = lifted(2, "right-back-high", backRise)
                val highLb = lifted(3, "left-back-high", backRise)
                surface("front", SuperstructureSurfaceRole.FRONT, base[0], base[1], rf, lf)
                surface("roof", SuperstructureSurfaceRole.ROOF, lf, rf, highRb, highLb)
            }
            DormerType.GABLE, DormerType.TRIANGULAR -> {
                val ridgeRise = rise + tan(pitch) * width / 2.0
                val frontMid = midpoint(base[0], base[1], "front-ridge", ridgeRise)
                val backMid = midpoint(base[3], base[2], "back-ridge", ridgeRise)
                surface("front-left", SuperstructureSurfaceRole.FRONT, base[0], base[1], frontMid)
                surface("roof-left", SuperstructureSurfaceRole.ROOF, lf, frontMid, backMid, lb)
                surface("roof-right", SuperstructureSurfaceRole.ROOF, frontMid, rf, rb, backMid)
            }
            DormerType.HIPPED -> {
                val ridgeRise = rise + tan(pitch) * width / 2.0
                val frontCenter = midpoint(base[0], base[1], "front-hip", ridgeRise)
                val backCenter = midpoint(base[3], base[2], "back-hip", ridgeRise)
                surface("front", SuperstructureSurfaceRole.ROOF, lf, rf, frontCenter)
                surface("roof-left", SuperstructureSurfaceRole.ROOF, lf, frontCenter, backCenter, lb)
                surface("roof-right", SuperstructureSurfaceRole.ROOF, frontCenter, rf, rb, backCenter)
                surface("roof-back", SuperstructureSurfaceRole.ROOF, lb, backCenter, rb)
            }
            DormerType.NAPOLEON, DormerType.EYEBROW, DormerType.ARCHED -> {
                val segments = if (item.dormerType in setOf(DormerType.EYEBROW, DormerType.ARCHED)) 8 else 6
                val front = (0..segments).map { index ->
                    val t = index.toDouble() / segments
                    val dx = (t - 0.5) * width
                    val baseCenterX = (base[0].x + base[1].x) / 2.0
                    val baseCenterY = (base[0].y + base[1].y) / 2.0
                    val arch = sin(PI * t).coerceAtLeast(0.0)
                    node("arch-front-$index", baseCenterX + widthAxis.x * dx, baseCenterY + widthAxis.y * dx,
                        base[0].z * (1.0 - t) + base[1].z * t + rise + arch * tan(pitch) * width / 2.0)
                }
                val back = front.mapIndexed { index, p ->
                    val depth = hypot(base[3].x - base[0].x, base[3].y - base[0].y)
                    node("arch-back-$index", p.x + depthAxis.x * depth, p.y + depthAxis.y * depth, p.z)
                }
                repeat(segments) { index ->
                    surface("roof-arch-$index", SuperstructureSurfaceRole.ROOF,
                        front[index], front[index + 1], back[index + 1], back[index])
                }
                surface("front", SuperstructureSurfaceRole.FRONT, base[0], base[1], *front.reversed().toTypedArray())
            }
        }
        return surfaces
    }

    private fun boxSurfaces(item: RoofObject, base: List<GraphNode>, graph: RoofGraph): List<RoofSuperstructureSurface> {
        val eaveReference = graph.edges.values.filter { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
            .flatMap { edge -> listOfNotNull(graph.nodes[edge.startNodeId], graph.nodes[edge.endNodeId]) }
            .minOfOrNull { it.z } ?: graph.nodes.values.minOfOrNull { it.z } ?: 0.0
        val topZ = max(base.maxOf { it.z } + 0.15, eaveReference + item.superstructureHeightM.coerceIn(0.3, 20.0))
        val top = base.mapIndexed { index, p -> GraphNode("super-${item.id}-top-$index", p.x, p.y, topZ) }
        val result = arrayListOf<RoofSuperstructureSurface>()
        repeat(4) { index ->
            val next = (index + 1) % 4
            result += RoofSuperstructureSurface(
                "super-${item.id}-wall-$index", SuperstructureSurfaceRole.WALL,
                listOf(base[index], base[next], top[next], top[index])
            )
        }
        result += RoofSuperstructureSurface("super-${item.id}-roof", SuperstructureSurfaceRole.ROOF, top)
        return result
    }

    private fun terraceSurfaces(item: RoofObject, rim: List<GraphNode>): List<RoofSuperstructureSurface> {
        val floorZ = rim.minOf { it.z } - item.superstructureHeightM.coerceIn(0.05, 1.5)
        val floor = rim.mapIndexed { index, p ->
            GraphNode("super-${item.id}-terrace-floor-$index", p.x, p.y, floorZ)
        }
        val result = arrayListOf<RoofSuperstructureSurface>()
        result += RoofSuperstructureSurface("super-${item.id}-floor", SuperstructureSurfaceRole.FLOOR, floor)
        repeat(4) { index ->
            val next = (index + 1) % 4
            result += RoofSuperstructureSurface(
                "super-${item.id}-side-$index", SuperstructureSurfaceRole.WALL,
                listOf(floor[index], floor[next], rim[next], rim[index])
            )
        }
        return result
    }

    private fun midpoint(a: GraphNode, b: GraphNode, suffix: String, rise: Double) = GraphNode(
        "${a.id.substringBeforeLast('-') }-$suffix", (a.x + b.x) / 2.0, (a.y + b.y) / 2.0,
        max(a.z, b.z) + rise
    )

    private fun contains(graph: RoofGraph, face: GraphFace, point: LocalPoint): Boolean {
        val outer = face.orderedNodeIds.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        if (outer.size < 3 || !Geometry.pointInPolygon(point, outer)) return false
        return face.holeNodeIdLoops.none { ids ->
            val hole = ids.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
            hole.size >= 3 && Geometry.pointInPolygon(point, hole)
        }
    }

    private fun polygonArea3D(nodes: List<GraphNode>): Double {
        if (nodes.size < 3) return 0.0
        var nx = 0.0; var ny = 0.0; var nz = 0.0
        nodes.indices.forEach { index ->
            val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
            nx += (a.y - b.y) * (a.z + b.z)
            ny += (a.z - b.z) * (a.x + b.x)
            nz += (a.x - b.x) * (a.y + b.y)
        }
        return 0.5 * sqrt(nx * nx + ny * ny + nz * nz)
    }

    /** Exact rectangle/concave-face intersection via deterministic face triangulation. */
    private fun intersectionArea(rectangle: List<LocalPoint>, polygon: List<LocalPoint>): Double =
        earClip(polygon).sumOf { triangle ->
            val clip = listOf(polygon[triangle[0]], polygon[triangle[1]], polygon[triangle[2]])
            area(clipConvex(rectangle, clip))
        }

    private fun clipConvex(subject: List<LocalPoint>, clip: List<LocalPoint>): List<LocalPoint> {
        if (subject.isEmpty() || clip.size < 3) return emptyList()
        val orientation = if (signedArea(clip) >= 0.0) 1.0 else -1.0
        var output: List<LocalPoint> = subject
        clip.indices.forEach { index ->
            val a = clip[index]; val b = clip[(index + 1) % clip.size]
            val input = output
            if (input.isEmpty()) return@forEach
            val clipped = arrayListOf<LocalPoint>()
            var previous = input.last()
            var previousInside = cross(a, b, previous) * orientation >= -1e-9
            input.forEach { current ->
                val currentInside = cross(a, b, current) * orientation >= -1e-9
                if (currentInside != previousInside) lineIntersection(previous, current, a, b)?.let(clipped::add)
                if (currentInside) clipped += current
                previous = current; previousInside = currentInside
            }
            output = clipped
        }
        return output
    }

    private fun lineIntersection(p: LocalPoint, q: LocalPoint, a: LocalPoint, b: LocalPoint): LocalPoint? {
        val rx = q.x - p.x; val ry = q.y - p.y
        val sx = b.x - a.x; val sy = b.y - a.y
        val denominator = rx * sy - ry * sx
        if (abs(denominator) < 1e-12) return null
        val t = ((a.x - p.x) * sy - (a.y - p.y) * sx) / denominator
        return LocalPoint(p.x + t * rx, p.y + t * ry)
    }

    private fun earClip(polygon: List<LocalPoint>): List<IntArray> {
        if (polygon.size < 3) return emptyList()
        val ccw = signedArea(polygon) >= 0.0
        val indices = if (ccw) polygon.indices.toMutableList() else polygon.indices.reversed().toMutableList()
        val result = arrayListOf<IntArray>()
        var guard = 0
        while (indices.size > 3 && guard++ < polygon.size * polygon.size) {
            var clipped = false
            for (cursor in indices.indices) {
                val prev = indices[(cursor - 1 + indices.size) % indices.size]
                val current = indices[cursor]
                val next = indices[(cursor + 1) % indices.size]
                if (cross(polygon[prev], polygon[current], polygon[next]) <= 1e-10) continue
                if (indices.any { candidate ->
                        candidate !in setOf(prev, current, next) &&
                            pointInTriangle(polygon[candidate], polygon[prev], polygon[current], polygon[next])
                    }) continue
                result += intArrayOf(prev, current, next)
                indices.removeAt(cursor); clipped = true; break
            }
            if (!clipped) break
        }
        if (indices.size == 3) result += intArrayOf(indices[0], indices[1], indices[2])
        return result
    }

    private fun pointInTriangle(p: LocalPoint, a: LocalPoint, b: LocalPoint, c: LocalPoint): Boolean {
        val c1 = cross(a, b, p); val c2 = cross(b, c, p); val c3 = cross(c, a, p)
        return c1 >= -1e-10 && c2 >= -1e-10 && c3 >= -1e-10
    }

    private fun cross(a: LocalPoint, b: LocalPoint, c: LocalPoint) =
        (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)

    private fun signedArea(points: List<LocalPoint>) = points.indices.sumOf { index ->
        val a = points[index]; val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    private fun area(points: List<LocalPoint>) = abs(signedArea(points))
}
