package sk.strechasketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.hypot

/** Clickable screen-space dimensions projected from the current OpenGL camera. */
class Roof3DDimensionOverlay(context: Context) : View(context) {
    var source: Roof3DView? = null
    internal var dimensionFilter: (RoofDimensionKind) -> Boolean = { true }
    var objectEditingEnabled: Boolean = false
    internal var onDimensionClick: ((ProjectedRoofDimension) -> Unit)? = null
    internal var onObjectMove: ((String, LocalPoint, Int?) -> RoofObjectOffset?)? = null
    internal var onObjectOffsetRequested: ((String) -> RoofObjectOffset?)? = null
    internal var onObjectDragStateChanged: ((String?) -> Unit)? = null
    private val hitBoxes = linkedMapOf<String, Pair<ProjectedRoofDimension, RectF>>()
    private var pressedDimensionId: String? = null
    private var pressedObjectId: String? = null
    private var activeObjectOffset: RoofObjectOffset? = null
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private val density = resources.displayMetrics.density.coerceAtLeast(1f)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(31, 108, 52)
        strokeWidth = 1.5f * density
        style = Paint.Style.STROKE
    }
    private val witnessPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 84, 91, 87)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(27, 58, 37)
        textSize = 12f * density
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private val labelBackground = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(238, 255, 253, 246)
        style = Paint.Style.FILL
    }
    private val labelBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(35, 122, 53)
        strokeWidth = 1f * density
        style = Paint.Style.STROKE
    }
    private val movingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(202, 45, 37)
        strokeWidth = 2f * density
        style = Paint.Style.STROKE
    }
    private val movingWitnessPaint = Paint(movingPaint).apply {
        color = Color.argb(150, 202, 45, 37)
        strokeWidth = 1f * density
        pathEffect = android.graphics.DashPathEffect(floatArrayOf(5f * density, 4f * density), 0f)
    }
    private val movingLabelPaint = Paint(labelPaint).apply { color = Color.rgb(150, 30, 25) }
    private val movingLabelBackground = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(244, 255, 240, 237)
        style = Paint.Style.FILL
    }

    init {
        isClickable = true
        contentDescription = "Klikateľné parametrické kóty trojrozmerného modelu"
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        hitBoxes.clear()
        val occupied = mutableListOf<RectF>()
        val occupiedLines = mutableListOf<Pair<android.graphics.PointF, android.graphics.PointF>>()
        fun lineIntersectsRect(a: android.graphics.PointF, b: android.graphics.PointF, box: RectF): Boolean {
            if (box.contains(a.x, a.y) || box.contains(b.x, b.y)) return true
            fun intersects(
                p1: android.graphics.PointF, p2: android.graphics.PointF,
                p3: android.graphics.PointF, p4: android.graphics.PointF
            ): Boolean {
                fun cross(u: android.graphics.PointF, v: android.graphics.PointF, w: android.graphics.PointF) =
                    (v.x - u.x) * (w.y - u.y) - (v.y - u.y) * (w.x - u.x)
                val c1 = cross(p1, p2, p3)
                val c2 = cross(p1, p2, p4)
                val c3 = cross(p3, p4, p1)
                val c4 = cross(p3, p4, p2)
                if (c1 * c2 > 0f || c3 * c4 > 0f) return false
                val epsilon = 0.5f
                return maxOf(minOf(p1.x, p2.x), minOf(p3.x, p4.x)) <=
                    minOf(maxOf(p1.x, p2.x), maxOf(p3.x, p4.x)) + epsilon &&
                    maxOf(minOf(p1.y, p2.y), minOf(p3.y, p4.y)) <=
                    minOf(maxOf(p1.y, p2.y), maxOf(p3.y, p4.y)) + epsilon
            }
            val tl = android.graphics.PointF(box.left, box.top)
            val tr = android.graphics.PointF(box.right, box.top)
            val br = android.graphics.PointF(box.right, box.bottom)
            val bl = android.graphics.PointF(box.left, box.bottom)
            return intersects(a, b, tl, tr) || intersects(a, b, tr, br) ||
                intersects(a, b, br, bl) || intersects(a, b, bl, tl)
        }
        if (pressedObjectId == null) source?.projectedDimensions()
            ?.filter { dimensionFilter(it.kind) }
            ?.sortedWith(compareBy<ProjectedRoofDimension> {
                when (it.kind) {
                    RoofDimensionKind.WALL_HEIGHT -> 0
                    RoofDimensionKind.ATTIC_HEIGHT -> 1
                    RoofDimensionKind.ATTIC_WIDTH -> 1
                    RoofDimensionKind.CHIMNEY_HEIGHT -> 2
                    RoofDimensionKind.CHIMNEY_WIDTH, RoofDimensionKind.CHIMNEY_LENGTH -> 3
                    RoofDimensionKind.ROOF_WINDOW_WIDTH, RoofDimensionKind.ROOF_WINDOW_LENGTH,
                    RoofDimensionKind.HATCH_WIDTH, RoofDimensionKind.HATCH_LENGTH,
                    RoofDimensionKind.VENT_DIAMETER,
                    RoofDimensionKind.SUPERSTRUCTURE_WIDTH,
                    RoofDimensionKind.SUPERSTRUCTURE_LENGTH,
                    RoofDimensionKind.SUPERSTRUCTURE_HEIGHT,
                    RoofDimensionKind.SUPERSTRUCTURE_SLOPE -> 4
                    RoofDimensionKind.SLOPE -> 5
                    RoofDimensionKind.OVERHANG -> 6
                    RoofDimensionKind.PLAN_LENGTH -> 7
                }
            }.thenByDescending {
                hypot(it.witnessEnd.x - it.witnessStart.x, it.witnessEnd.y - it.witnessStart.y)
            })
            ?.forEach { dimension ->
            val witnessA = dimension.witnessStart
            val witnessB = dimension.witnessEnd
            // Plan dimensions have an explicit world-space line on the presentation board.
            // Other annotations still use adaptive screen-space displacement.
            val dimensionBaseA = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) dimension.start else witnessA
            val dimensionBaseB = if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) dimension.end else witnessB
            val edgeDx = dimensionBaseB.x - dimensionBaseA.x
            val edgeDy = dimensionBaseB.y - dimensionBaseA.y
            val edgeLength = hypot(edgeDx, edgeDy).coerceAtLeast(1f)
            val nx = dimension.outwardNormal.x
            val ny = dimension.outwardNormal.y
            val text = when (dimension.kind) {
                RoofDimensionKind.PLAN_LENGTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.WALL_HEIGHT -> String.format(Locale("sk", "SK"), "H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_HEIGHT -> String.format(Locale("sk", "SK"), "Atika  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_WIDTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.OVERHANG -> String.format(Locale("sk", "SK"), "Presah  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SLOPE -> String.format(Locale("sk", "SK"), "\u2220  %.1f\u00B0", dimension.lengthM)
                RoofDimensionKind.CHIMNEY_WIDTH -> String.format(Locale("sk", "SK"), "Komín Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_LENGTH -> String.format(Locale("sk", "SK"), "Komín D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_HEIGHT -> String.format(Locale("sk", "SK"), "Komín H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_WIDTH -> String.format(Locale("sk", "SK"), "Okno Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_LENGTH -> String.format(Locale("sk", "SK"), "Okno D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.HATCH_WIDTH -> String.format(Locale("sk", "SK"), "Výlez Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.HATCH_LENGTH -> String.format(Locale("sk", "SK"), "Výlez D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.VENT_DIAMETER -> String.format(Locale("sk", "SK"), "Ø  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SUPERSTRUCTURE_WIDTH -> String.format(Locale("sk", "SK"), "Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SUPERSTRUCTURE_LENGTH -> String.format(Locale("sk", "SK"), "D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SUPERSTRUCTURE_HEIGHT -> String.format(Locale("sk", "SK"), "H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SUPERSTRUCTURE_SLOPE -> String.format(Locale("sk", "SK"), "∠  %.1f°", dimension.lengthM)
            }
            val paddingX = 8f * density
            val halfWidth = labelPaint.measureText(text) / 2f + paddingX
            val halfHeight = 14f * density
            var chosen: Triple<android.graphics.PointF, android.graphics.PointF, RectF>? = null
            if (dimension.kind == RoofDimensionKind.PLAN_LENGTH) {
                val centerX = (dimensionBaseA.x + dimensionBaseB.x) / 2f
                val centerY = (dimensionBaseA.y + dimensionBaseB.y) / 2f
                chosen = Triple(
                    android.graphics.PointF(dimensionBaseA.x, dimensionBaseA.y),
                    android.graphics.PointF(dimensionBaseB.x, dimensionBaseB.y),
                    RectF(centerX - halfWidth, centerY - halfHeight, centerX + halfWidth, centerY + halfHeight)
                )
            } else for (level in 0..5) {
                val offset = (24f + level * 30f) * density
                val a = android.graphics.PointF(dimensionBaseA.x + nx * offset, dimensionBaseA.y + ny * offset)
                val b = android.graphics.PointF(dimensionBaseB.x + nx * offset, dimensionBaseB.y + ny * offset)
                val centerX = (a.x + b.x) / 2f
                val centerY = (a.y + b.y) / 2f
                val box = RectF(centerX - halfWidth, centerY - halfHeight, centerX + halfWidth, centerY + halfHeight)
                val inside = box.left >= 3f * density && box.right <= width - 3f * density &&
                    box.top >= 3f * density && box.bottom <= height - 3f * density
                val crossesLabel = occupied.any { existing ->
                    lineIntersectsRect(a, b, existing) || RectF.intersects(existing, box)
                }
                val coversLine = occupiedLines.any { (lineA, lineB) -> lineIntersectsRect(lineA, lineB, box) }
                if (inside && !crossesLabel && !coversLine) {
                    chosen = Triple(a, b, box)
                    break
                }
            }
            val (a, b, box) = chosen ?: return@forEach
            if ((a.x < -100f && b.x < -100f) || (a.x > width + 100f && b.x > width + 100f) ||
                (a.y < -100f && b.y < -100f) || (a.y > height + 100f && b.y > height + 100f)
            ) return@forEach
            // Never paint extension lines through an opaque roof or wall. The dimension and
            // label remain available, while hidden witness fragments are suppressed.
            if (dimension.drawWitnessLines) {
                canvas.drawLine(witnessA.x, witnessA.y, a.x, a.y, witnessPaint)
                canvas.drawLine(witnessB.x, witnessB.y, b.x, b.y, witnessPaint)
            }
            canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1f)
            val tickNx = -dy / length
            val tickNy = dx / length
            val tick = 5f * density
            canvas.drawLine(a.x - tickNx * tick, a.y - tickNy * tick, a.x + tickNx * tick, a.y + tickNy * tick, linePaint)
            canvas.drawLine(b.x - tickNx * tick, b.y - tickNy * tick, b.x + tickNx * tick, b.y + tickNy * tick, linePaint)

            val centerX = (a.x + b.x) / 2f
            val centerY = (a.y + b.y) / 2f
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBackground)
            canvas.drawRoundRect(box, 7f * density, 7f * density, labelBorder)
            val baseline = centerY - (labelPaint.ascent() + labelPaint.descent()) / 2f
            canvas.drawText(text, centerX, baseline, labelPaint)
            val hit = RectF(box).apply { inset(-5f * density, -5f * density) }
            hitBoxes[dimension.dimensionId] = dimension to hit
            occupied += RectF(hit)
            occupiedLines += a to b
        }
        drawMovingObjectReadout(canvas)
    }

    private fun drawMovingObjectReadout(canvas: Canvas) {
        val objectId = pressedObjectId ?: return
        val offset = activeObjectOffset ?: return
        val projected = source?.projectedObjectOffset(objectId, offset) ?: return
        val origin = projected.referenceCorner
        val objectPoint = projected.objectPoint
        val xEnd = projected.xEnd
        val yEnd = projected.yEnd
        val tick = 5f * density
        canvas.drawCircle(objectPoint.x, objectPoint.y, 18f * density, movingPaint)
        canvas.drawLine(origin.x, origin.y, xEnd.x, xEnd.y, movingPaint)
        canvas.drawLine(origin.x, origin.y, yEnd.x, yEnd.y, movingPaint)
        canvas.drawLine(xEnd.x, xEnd.y, objectPoint.x, objectPoint.y, movingWitnessPaint)
        canvas.drawLine(yEnd.x, yEnd.y, objectPoint.x, objectPoint.y, movingWitnessPaint)
        fun tick(point: android.graphics.PointF, a: android.graphics.PointF, b: android.graphics.PointF) {
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1f)
            val nx = -dy / length
            val ny = dx / length
            canvas.drawLine(
                point.x - nx * tick, point.y - ny * tick,
                point.x + nx * tick, point.y + ny * tick, movingPaint
            )
        }
        tick(origin, origin, xEnd)
        tick(xEnd, origin, xEnd)
        tick(origin, origin, yEnd)
        tick(yEnd, origin, yEnd)
        fun label(text: String, x: Float, y: Float) {
            val paddingX = 7f * density
            val halfWidth = movingLabelPaint.measureText(text) / 2f + paddingX
            val halfHeight = 13f * density
            val box = RectF(x - halfWidth, y - halfHeight, x + halfWidth, y + halfHeight)
            canvas.drawRoundRect(box, 6f * density, 6f * density, movingLabelBackground)
            canvas.drawRoundRect(box, 6f * density, 6f * density, movingPaint)
            val baseline = y - (movingLabelPaint.ascent() + movingLabelPaint.descent()) / 2f
            canvas.drawText(text, x, baseline, movingLabelPaint)
        }
        val xDx = xEnd.x - origin.x
        val xDy = xEnd.y - origin.y
        val xLength = hypot(xDx, xDy).coerceAtLeast(1f)
        val yDx = yEnd.x - origin.x
        val yDy = yEnd.y - origin.y
        val yLength = hypot(yDx, yDy).coerceAtLeast(1f)
        label(
            String.format(Locale("sk", "SK"), "X  %,.0f mm", offset.xM * 1000.0),
            (origin.x + xEnd.x) / 2f - xDy / xLength * 15f * density,
            (origin.y + xEnd.y) / 2f + xDx / xLength * 15f * density
        )
        label(
            String.format(Locale("sk", "SK"), "Y  %,.0f mm", offset.yM * 1000.0),
            (origin.x + yEnd.x) / 2f - yDy / yLength * 15f * density,
            (origin.y + yEnd.y) / 2f + yDx / yLength * 15f * density
        )
        label("roh ${offset.cornerIndex + 1}", origin.x, origin.y - 22f * density)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedDimensionId = hitBoxes.entries.lastOrNull { it.value.second.contains(event.x, event.y) }?.key
                if (pressedDimensionId != null) return true
                val objectHitRadius = 34f * density
                pressedObjectId = if (objectEditingEnabled) source?.projectedObjects()
                    ?.filter { it.type in setOf(ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW, ObjectType.HATCH, ObjectType.VENT) }
                    ?.filter { hypot(it.point.x - event.x, it.point.y - event.y) <= objectHitRadius }
                    ?.minByOrNull { hypot(it.point.x - event.x, it.point.y - event.y) }
                    ?.objectId else null
                pressedObjectId?.let { objectId ->
                    activeObjectOffset = onObjectOffsetRequested?.invoke(objectId)
                    onObjectDragStateChanged?.invoke(objectId)
                    postInvalidateOnAnimation()
                }
                lastTouchX = event.x
                lastTouchY = event.y
                return pressedObjectId != null
            }
            MotionEvent.ACTION_MOVE -> {
                val objectId = pressedObjectId ?: return pressedDimensionId != null
                val delta = source?.objectDragDelta(
                    objectId, event.x - lastTouchX, event.y - lastTouchY
                )
                lastTouchX = event.x
                lastTouchY = event.y
                if (delta != null && (kotlin.math.abs(delta.x) > 1e-7 || kotlin.math.abs(delta.y) > 1e-7)) {
                    activeObjectOffset = onObjectMove?.invoke(
                        objectId,
                        delta,
                        activeObjectOffset?.cornerIndex
                    )
                    postInvalidateOnAnimation()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (pressedObjectId != null) {
                    pressedObjectId = null
                    activeObjectOffset = null
                    onObjectDragStateChanged?.invoke(null)
                    postInvalidateOnAnimation()
                    performClick()
                    return true
                }
                val dimensionId = pressedDimensionId
                pressedDimensionId = null
                val hit = dimensionId?.let(hitBoxes::get)
                if (hit != null && hit.second.contains(event.x, event.y)) {
                    performClick()
                    onDimensionClick?.invoke(hit.first)
                    return true
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                pressedDimensionId = null
                pressedObjectId = null
                activeObjectOffset = null
                onObjectDragStateChanged?.invoke(null)
                postInvalidateOnAnimation()
            }
        }
        return pressedDimensionId != null || pressedObjectId != null
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }
}
