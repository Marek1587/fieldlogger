const assert = require("node:assert/strict");
const test = require("node:test");
const Drawing = require("../app/src/main/assets/technical-drawing.js");
const Solver = require("../app/src/main/assets/geometry-solver.js");

const { TechnicalDrawingModel, TechnicalDrawingRenderer, DrawingStyle, EntityType } = Drawing;
const P = Drawing.geometry.p;
const render = model => new TechnicalDrawingRenderer().render(model);
const dimension = (model,p1,p2,value,extra={}) => model.dimension(Object.assign({p1,p2,exactValue:value,displayValue:String(value),semanticName:"test"},extra));

test("centrálny renderer používa stabilnú hierarchiu čiar", () => {
  assert.ok(DrawingStyle.objectVisibleWeight >= DrawingStyle.dimensionWeight * 2);
  for (const name of ["drawLinearDimension","drawAlignedDimension","drawAngularDimension","drawRadiusDimension","drawDiameterDimension","drawLeader","drawCenterLine"]) assert.equal(typeof Drawing[name],"function");
});

test("vodorovná, zvislá a šikmá kóta majú vynášacie čiary a čitateľný text", () => {
  const m=new TechnicalDrawingModel({viewport:{width:700,height:500}});m.geometry({kind:"polygon",points:[P(0,0),P(400,0),P(400,220),P(0,220)]});
  dimension(m,P(0,0),P(400,0),400,{preferredSide:"bottom"});dimension(m,P(0,0),P(0,220),220,{preferredSide:"left"});dimension(m,P(0,220),P(400,0),457,{dimensionType:"aligned",preferredSide:"top"});
  const out=render(m);assert.equal(out.layout.collisionCount,0);assert.equal((out.svg.match(/td-extension/g)||[]).length>=6,true);assert.doesNotMatch(out.svg,/class="td-dimension-text"[^>]*>[^<]*mm/);
});

test("uhlové kóty pod 45° a nad 90° používajú oblúk a šípky", () => {
  const m=new TechnicalDrawingModel({viewport:{width:700,height:500}});m.geometry({points:[P(0,0),P(300,0)]});
  m.angle({vertex:P(0,0),startAngle:0,endAngle:32,exactValue:32,displayValue:"32",semanticName:"a"});m.angle({vertex:P(300,0),startAngle:0,endAngle:118,exactValue:118,displayValue:"118",semanticName:"b"});
  const out=render(m);assert.match(out.svg,/td-angle-arc/);assert.match(out.svg,/marker-start="url\(#td-arrow\)"/);assert.match(out.svg,/>32°</);assert.match(out.svg,/>118°</);
});

test("priemer a polomer používajú iba technické značky Ø a R", () => {
  const m=new TechnicalDrawingModel({viewport:{width:600,height:420}});m.geometry({kind:"circle",center:P(0,0),radius:80});m.diameter({target:P(80,0),exactValue:120,displayValue:"120",semanticName:"diameter"});m.radius({target:P(0,80),exactValue:80,displayValue:"80",semanticName:"radius"});
  const svg=render(m).svg;assert.match(svg,/>Ø120</);assert.match(svg,/>R80</);assert.doesNotMatch(svg,/P ·|RADIUS/);
});

test("krátka kóta presunie text mimo zakončení bez kolízie", () => {
  const m=new TechnicalDrawingModel({viewport:{width:500,height:300}});m.geometry({points:[P(0,0),P(5,0)]});dimension(m,P(0,0),P(5,0),123456,{preferredSide:"bottom"});
  const out=render(m);assert.equal(out.layout.collisionCount,0);assert.match(out.svg,/>123456</);
});

test("tri susedné a vnorené kóty sa rozložia do samostatných dráh", () => {
  const m=new TechnicalDrawingModel({viewport:{width:850,height:480}});m.geometry({points:[P(0,0),P(600,0)]});dimension(m,P(0,0),P(200,0),200);dimension(m,P(200,0),P(400,0),200);dimension(m,P(400,0),P(600,0),200);dimension(m,P(0,0),P(600,0),600,{priority:100});
  const out=render(m);assert.equal(out.layout.collisionCount,0);assert.equal(out.layout.placements.size,4);
});

test("DimensionGraph odstráni duplicitnú kótu a eviduje exact/display oddelene", () => {
  const m=new TechnicalDrawingModel();const d={p1:P(0,0),p2:P(100,0),exactValue:99.731,displayValue:"100",semanticName:"X"};m.dimension(d);m.dimension(d);
  assert.equal(m.entities.filter(e=>e.type===EntityType.Dimension).length,1);assert.equal(m.entities[0].exactValue,99.731);assert.equal(m.entities[0].displayValue,"100");
});

test("nulový fyzický diel sa v adaptéri 3 KOLENÁ nekreslí ako rúra", () => {
  const r=Solver.solveThreeElbowOffset({x:11000,diameter:12000,alphaDegrees:26,insertion:5000}),m=Drawing.Adapters.optimizer(r);
  const svg=render(m).svg;assert.equal(r.a,0);assert.equal(r.b,0);assert.equal(m.entities.filter(e=>e.type===EntityType.Dimension&&["a","b"].includes(e.semanticName)).length,0);assert.equal(m.entities.filter(e=>e.kind==="straightPipe").length,0);assert.doesNotMatch(svg,/NIE JE POTREBNÁ|PRÍDAVNÁ RÚRKA [ab]/);
});

test("analytická zostava 3 KOLENÁ zachová tangent points a obvody",()=>{
  const r=Solver.solveThreeElbowOffset({x:30000,diameter:12000,alphaDegrees:10,insertion:7000}),m=Drawing.Adapters.optimizer(r),topology=m.topology,svg=render(m).svg;
  assert.equal(m.validation.ok,true);assert.equal(topology.elbows.length,3);assert.equal(topology.pipes.length,(r.a>0?1:0)+(r.b>0?1:0));assert.ok(topology.components.every(component=>component.kind==="analyticElbow"||component.kind==="straightPipe"));assert.doesNotMatch(svg,/class="td-pipe-assembly"/);assert.match(svg,/td-analytic-elbow/);if(topology.pipes.length)assert.match(svg,/td-extension-pipe/);
});

test("zmena zasunutia prepočíta reznú a montážnu geometriu 3 KOLENÁ",()=>{
  const a=Solver.solveThreeElbowOffset({x:30000,diameter:12000,alphaDegrees:10,insertion:5000}),b=Solver.solveThreeElbowOffset({x:30000,diameter:12000,alphaDegrees:10,insertion:7000});assert.equal(a.ok,true);assert.equal(b.ok,true);assert.equal(b.insertion,7000);assert.ok(a.a!==b.a||a.b!==b.b||a.y!==b.y);
});

test("zasunutie mení montážnu geometriu X/Y solvera 3 KOLENÁ", () => {
  const r=Solver.solveThreeElbowOffset({x:30000,diameter:12000,alphaDegrees:10,insertion:5000});assert.equal(r.ok,true);assert.equal(r.xError,0);assert.equal(r.jointA,r.a-2*r.insertion);assert.equal(r.jointB,-r.insertion);assert.notEqual(r.jointA,r.a);
});

test("všetky kartové adaptéry renderujú s nulovou hlásenou kolíziou", () => {
  const basic=Solver.calculateBasicLayout({targetLength:100000,nominalWidth:30000}),tri=Solver.solveRightTriangle({a:30000,b:40000,c:50000},["a","b"]),sqv={l1:400000,l2:400000,d1:500000,d2:503200},sq=Solver.solveRectangleSquaring(sqv),slv={width:10000,angleDegrees:32},sl=Solver.solveSheetPerpendicular(slv),cl=Solver.solveClipLayout({length:200000,angleDegrees:30,spacing:30000}),di=Solver.solveUpperSlidingDilatation({panelLength:200000,fixedZoneEnd:150000,screwDiameter:400}),dw=Solver.solveDownpipeOffset({x:100000,diameter:12000,insertion:5000,angleDegrees:72}),op=Solver.solveThreeElbowOffset({x:30000,diameter:12000,insertion:5000,alphaDegrees:10});
  const fakeCorrection={achievedLength:100000,fixedLeft:5000,fixedRight:5000,pieceCount:3,pieces:[{finalWidth:30000},{finalWidth:30000},{finalWidth:30000}]};
  const models=[Drawing.Adapters.division(basic,false),Drawing.Adapters.division(basic,false,true),Drawing.Adapters.correction(fakeCorrection),Drawing.Adapters.triangle(tri.values,tri.computedSide),Drawing.Adapters.squaring(sqv,sq),Drawing.Adapters.slope(slv,sl),Drawing.Adapters.clips(cl),Drawing.Adapters.dilatation(di),Drawing.Adapters.downpipe(dw),Drawing.Adapters.optimizer(op)];
  models.forEach(model=>{const out=render(model);assert.equal(out.layout.collisionCount,0,model.title);assert.match(out.svg,/viewBox=/);for(const box of out.layout.occupied){assert.ok(box.x1>=0&&box.y1>=0&&box.x2<=model.viewport.width&&box.y2<=model.viewport.height,model.title+" text mimo viewportu");}});
});

test("malý mobilný viewport a SVG export zachovajú neškálované čiary", () => {
  const m=new TechnicalDrawingModel({viewport:{width:320,height:260}});m.geometry({points:[P(0,0),P(1000,0)]});dimension(m,P(0,0),P(1000,0),1000,{preferredSide:"bottom"});const out=render(m);
  assert.equal(out.layout.collisionCount,0);assert.match(out.svg,/vector-effect:non-scaling-stroke/);assert.match(out.svg,/^<svg/);
});
