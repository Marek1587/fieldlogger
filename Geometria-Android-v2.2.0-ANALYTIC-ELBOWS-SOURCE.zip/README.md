# Geometria 2.2.0

Kompletná offline Android aplikácia na presné rozdelenie cieľovej dĺžky na opakované diely a korekciu ich šírky.

## Funkcie

- spoločný sémantický `TechnicalDrawingRenderer`, `DimensionLayoutEngine` a `DrawingStyle` pre všetky karty,
- `UserDimensionLockManager` rozlišuje predvolené, odvodené, automaticky upravené a ručne uzamknuté rozmery,
- neplatné uhlovanie sa automaticky zachráni proporcionálnou úpravou a následnou obmedzenou optimalizáciou iba nezamknutých rozmerov,
- pri úplnom konflikte ručne uzamknutých rozmerov aplikácia označí konflikty a ponúkne explicitné uvoľnenie najmenej dôležitého vstupu,
- KOLMICA obsahuje geometricky viazanú zvislú olovnicu ako samostatný typ `PLUMB_LINE`,
- potrubia a kolená sú duté technické obrysy bez plnej výplne, s voliteľnou stredovou osou,
- modul 3 KOLENÁ skladá každé koleno ako analytický anulárny sektor a každú rovnú rúru z osi a tangent points,
- prídavné rúry a/b sú modré obrysové diely; nulové diely sa nevykresľujú, nekótujú ani nespomínajú vo výsledkoch,
- zasunutie rúry do kolena je jeden editovateľný parameter s predvolenou hodnotou 50 mm a okamžitým prepočtom rezov aj montážnej geometrie,
- pred renderovaním sa automaticky kontroluje kontinuita osí, tangentných smerov a oboch obvodových hrán,
- centrálny technický štýl používa zväčšené mobilne čitateľné kóty a oddelené SVG vrstvy geometrie, osí, kót a poznámok,
- technické SVG kóty podľa zásad STN 01 3420, ISO 128, ISO 129-1 a čitateľnosti ISO 3098: tenké kótovacie a vynášacie čiary, dominantný obrys, šikmé zakončenia, uhlové oblúky, Ø a R,
- automatické dráhy kót, detekcia kolízií, odstránenie duplicít a normalizovaná orientácia textu,
- rozmery v mm sú deklarované raz; samotné dĺžkové kóty obsahujú iba číselnú hodnotu,
- solver troch kolien rozlišuje reznú dĺžku rúrok od skutočnej osovej vzdialenosti po zasunutí a započítava prekrytie spojov do X aj Y,

- rozdelenie dĺžky cez jednoduchý technický vstupný nákres s klikateľnými kótami L a a,
- automatický výsledný nákres s počtom dielov a symetrickými krajmi y/2,
- zvislé prerušovacie značky medzi krajnými dielmi `y/2` a strednou časťou `n × a`,
- dva proporcionálne výsledky rozdelenia: symetrické `y/2 + n × a + y/2` a jednostranné `y + n × a`, oba so zdieľaním obrázka,
- automatické hľadanie optimálneho počtu dielov,
- korekcia šírky s toleranciou a krokom 0,1 / 0,5 / 1 mm,
- proporcionálny technický korekčný plán v rovnakom štýle ako rozdelenie so zdieľaním obrázka,
- presná celočíselná aritmetika s interným základom 0,01 mm,
- všetky vstupné dĺžkové kóty cez koliesko alebo šípky po 5 mm; uhlové kóty po 1°,
- pravouhlý trojuholník podľa Pytagorovej vety: dve naposledy upravené strany určujú automaticky dopočítanú tretiu stranu,
- uhlovanie z hornej dĺžky L1, spodnej dĺžky L2 a diagonál d1/d2 s rekonštrukciou lichobežníka, samostatnými posunmi X1/X2 a výpočtom všetkých štyroch uhlov,
- automatické označenie každého 90° rohu štvrťkružnicou s bodkou; pri nepravouhlom výsledku sa žiadny roh neoznačí,
- výpočet kolmice cez šikmý pás plechu zo šírky V a uhla α s výsledným posunom X,
- rozloženie príponiek na páse: dĺžka L po 5 mm, sklon strechy po 1°, pevný raster 300 mm, číslované zóny a presná poloha každej pevnej alebo posuvnej príponky,
- automatická pevná zóna podľa sklonu: stred, 2/3, 3/4 alebo pri hrebeni; dĺžka zóny 1 m do dĺžky pásu 10 m a 3 m nad 10 m,
- pevné príponky ako štvorce, posuvné ako elipsy, jedno-stĺpcový zoznam od odkvapu a automatický súčet skrutiek,
- násobenie počtu pevných a posuvných príponiek aj skrutiek podľa používateľom zadaného počtu pásov,
- samostatný modul dilatácie hornej posuvnej zóny pre oceľ, prepojený s dĺžkou pásu a horným okrajom pevnej zóny z modulu Príponky,
- nastaviteľný priemer skrutky po 0,1 mm, výpočet tepelného pohybu pri ΔT 100 K, minimálnej dĺžky otvoru a normalizovaného párneho otvoru vrátane montážnej rezervy 2 mm,
- modul zvodov s dvoma kolenami 40° / 72° / 87°, nastaviteľnými osovými rozmermi X a Y, priemerom rúry P a zasunutím na oboch koncoch,
- rezná dĺžka šikmej rúry R vrátane zasunutí a automatický návrh korekcie rozmeru Y pre zvolený uhol kolien,
- optimalizácia zostavy troch kolien: preverenie všetkých 27 kombinácií uhlov 40° / 72° / 87°, minimalizácia prídavných rúrok a, b a návrh posunu Y,
- veľký zdieľateľný nákres optimálnej zostavy s klikateľnými kótami X, Y a priemerom P,
- vstupný sklon výtoku α pre optimalizáciu troch kolien; Y je v oboch zvodových kartách automaticky vypočítaná montážna kóta,
- priemery zvodových rúr 80–150 mm po 10 mm a osový radius každého kolena rovný zvolenému priemeru P,
- úplné okótovanie reznej dĺžky R vrátane samostatného zasunutia na začiatku a konci rúry,
- jednoznačný reťazec `R rezná = zasunutie + čistá rúra + zasunutie` a zdieľanie nákresu karty Zvody ako PNG,
- zdieľanie technických nákresov trojuholníka, uhlovania a kolmice ako PNG obrázkov,
- celé milimetre pre stavebné kóty a automaticky vypočítané hodnoty X,
- technické čiarové nákresy s kótami pre všetky výpočtové režimy,
- podrobný matematický postup a kontrolný súčet,
- montážny výstup s kopírovaním a systémovým zdieľaním,
- vysoký kontrast a kompaktný režim,
- úplná prevádzka bez internetu, účtu a servera.

## Zostavenie

Projekt vyžaduje Java 17, Android SDK 35 a Gradle 8.10.2.

```text
node --test tests/*.test.js
gradle :app:assembleRelease
```

APK vznikne v `app/build/outputs/apk/release/app-release.apk`.

GitHub workflow `.github/workflows/build-apk.yml` spustí testy a vytvorí release APK automaticky.
