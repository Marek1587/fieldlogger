# Technical drawing engine

Verzia 2.0 oddeľuje štyri vrstvy:

1. `geometry-solver.js` – presný výpočtový model v krokoch 0,01 mm,
2. `TechnicalDrawingModel` – sémantické objekty geometrie, kót, osí, odkazov a poznámok,
3. `DimensionLayoutEngine` – dráhy kót, odstraňovanie duplicít, textové obálky a detekcia kolízií,
4. `TechnicalDrawingRenderer` – spoločný responzívny SVG výstup pre všetky karty.

## Zasunutie v zostave troch kolien

Solver rozlišuje:

- `a`, `b`: dielenské rezné dĺžky vložených rúrok,
- `jointA`, `jointB`: skutočné osové vzdialenosti medzi tangentnými bodmi kolien po montáži.

Pre rúrku zasunutú o `I` na oboch koncoch platí:

`joint = cutLength - 2 × I`

Ak rúrka nie je potrebná a kolená sú spojené priamo, model používa prekrytie:

`joint = -I`

Takto sa zasunutie premieta do oboch súradníc X/Y a nie iba do textu reznej dĺžky. Model predpokladá, že deklarované zasunutie sa meria pozdĺž spoločnej osi hrdla. Pre výrobok s iným konštrukčným rozmerom stred–hrdlo treba použiť údaj konkrétneho výrobcu.

## Kresliace pravidlá

- rozmery sú v mm a jednotka sa vo výkrese deklaruje raz,
- dĺžkové kóty zobrazujú iba hodnotu,
- uhly používajú oblúk so šípkami a symbol `°`,
- priemer a polomer používajú `Ø` a `R`,
- obrys predmetu je minimálne dvojnásobne hrubší než kótovacie čiary,
- technický význam nie je závislý iba od farby,
- SVG používa nemennú hrúbku technických čiar pri responzívnom škálovaní.
