(function (root) {
  "use strict";

  const EntityType = Object.freeze({
    GeometryObject: "GeometryObject",
    Dimension: "Dimension",
    ExtensionLine: "ExtensionLine",
    DimensionLine: "DimensionLine",
    Leader: "Leader",
    CenterLine: "CenterLine",
    Axis: "Axis",
    AngleDimension: "AngleDimension",
    RadiusDimension: "RadiusDimension",
    DiameterDimension: "DiameterDimension",
    Note: "Note",
    ReferenceLabel: "ReferenceLabel"
  });

  const LineClass = Object.freeze({
    OBJECT_VISIBLE: "OBJECT_VISIBLE",
    DIMENSION: "DIMENSION",
    EXTENSION: "EXTENSION",
    LEADER: "LEADER",
    CENTER: "CENTER",
    CONSTRUCTION: "CONSTRUCTION",
    HIDDEN: "HIDDEN"
  });

  const DrawingStyle = Object.freeze({
    objectVisibleWeight: 2.4,
    dimensionWeight: 0.8,
    extensionWeight: 0.7,
    leaderWeight: 0.7,
    centerWeight: 0.65,
    constructionWeight: 0.6,
    hiddenWeight: 0.65,
    dimensionFontSize: 14,
    noteFontSize: 11,
    referenceFontSize: 10,
    extensionGap: 4,
    extensionOvershoot: 5,
    slashLength: 10,
    textGap: 7,
    laneGap: 30,
    margin: 56,
    monochrome: true,
    technicalFont: "Arial Narrow, Roboto Condensed, DejaVu Sans, sans-serif"
  });

  function p(x, y) { return { x: Number(x), y: Number(y) }; }
  function add(a, b) { return p(a.x + b.x, a.y + b.y); }
  function sub(a, b) { return p(a.x - b.x, a.y - b.y); }
  function mul(a, k) { return p(a.x * k, a.y * k); }
  function length(v) { return Math.hypot(v.x, v.y); }
  function unit(v) { const l = length(v) || 1; return p(v.x / l, v.y / l); }
  function normal(v) { const u = unit(v); return p(-u.y, u.x); }
  function midpoint(a, b) { return p((a.x + b.x) / 2, (a.y + b.y) / 2); }
  function rad(degrees) { return degrees * Math.PI / 180; }
  function deg(radians) { return radians * 180 / Math.PI; }
  function esc(value) { return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"); }
  function roundDisplay(value) { return Math.round(Number(value)); }
  function formatNumber(value) { return new Intl.NumberFormat("sk-SK", { maximumFractionDigits: 2 }).format(Number(value)); }
  function getDimensionTextRotation(direction) {
    let angle = deg(Math.atan2(direction.y, direction.x));
    while (angle > 180) angle -= 360;
    while (angle <= -180) angle += 360;
    if (angle > 90) angle -= 180;
    if (angle < -90) angle += 180;
    return angle;
  }
  function textBox(text, center, rotation, fontSize) {
    const width = Math.max(fontSize * 1.3, String(text).length * fontSize * 0.62 + 8);
    const height = fontSize * 1.35;
    const a = Math.abs(Math.cos(rad(rotation))), b = Math.abs(Math.sin(rad(rotation)));
    const rw = width * a + height * b, rh = width * b + height * a;
    return { x1: center.x - rw / 2, y1: center.y - rh / 2, x2: center.x + rw / 2, y2: center.y + rh / 2 };
  }
  function boxesOverlap(a, b, padding) {
    const pad = padding || 0;
    return !(a.x2 + pad < b.x1 || a.x1 - pad > b.x2 || a.y2 + pad < b.y1 || a.y1 - pad > b.y2);
  }
  function pointsBox(points) {
    if (!points.length) return { x1: 0, y1: 0, x2: 1, y2: 1 };
    return { x1: Math.min.apply(null, points.map(q => q.x)), y1: Math.min.apply(null, points.map(q => q.y)), x2: Math.max.apply(null, points.map(q => q.x)), y2: Math.max.apply(null, points.map(q => q.y)) };
  }
  function expandBox(box, amount) { return { x1: box.x1 - amount, y1: box.y1 - amount, x2: box.x2 + amount, y2: box.y2 + amount }; }
  function entityPoints(entity) {
    if (entity.points) return entity.points;
    const result = [];
    ["p1", "p2", "center", "vertex", "arcPoint", "target"].forEach(key => { if (entity[key]) result.push(entity[key]); });
    return result;
  }
  function entityCollisionBoxes(entity, transform) {
    if (entity.kind === "circle") {
      const c=transform.point(entity.center),r=Math.max(3,(entity.radius||1)*transform.scale);
      return [{x1:c.x-r,y1:c.y-r,x2:c.x+r,y2:c.y+r}];
    }
    let points=entityPoints(entity).map(transform.point),closed=entity.kind==="polygon"||entity.kind==="rect";
    if(entity.kind==="rect"&&entity.p1&&entity.p2){const a=transform.point(entity.p1),b=transform.point(entity.p2);points=[p(a.x,a.y),p(b.x,a.y),p(b.x,b.y),p(a.x,b.y)];}
    const padding=entity.kind==="tube"?Math.max(4,(entity.diameter||1)*transform.scale/2):4,boxes=[];
    function addSegment(a,b){const steps=Math.max(1,Math.ceil(length(sub(b,a))/24));for(let j=0;j<steps;j+=1){const q1=add(a,mul(sub(b,a),j/steps)),q2=add(a,mul(sub(b,a),(j+1)/steps));boxes.push(expandBox(pointsBox([q1,q2]),padding));}}
    for(let i=1;i<points.length;i+=1)addSegment(points[i-1],points[i]);
    if(closed&&points.length>2)addSegment(points[points.length-1],points[0]);
    if(!boxes.length&&points.length)boxes.push(expandBox(pointsBox(points),padding));
    return boxes;
  }

  class DimensionGraph {
    constructor() { this.keys = new Set(); }
    key(dimension) {
      const q = v => Math.round(v * 100) / 100;
      const pair = dimension.p1 && dimension.p2 ? [dimension.p1, dimension.p2].map(v => q(v.x) + "," + q(v.y)).sort().join("|") : "";
      return [dimension.type, pair, dimension.semanticName || "", dimension.displayValue].join(":");
    }
    accept(dimension) { const key = this.key(dimension); if (this.keys.has(key)) return false; this.keys.add(key); return true; }
  }

  class TechnicalDrawingModel {
    constructor(options) {
      const input = options || {};
      this.title = input.title || "TECHNICKÝ MONTÁŽNY VÝKRES";
      this.unit = input.unit || "mm";
      this.viewport = input.viewport || { width: 900, height: 620 };
      this.entities = [];
      this.dimensionGraph = new DimensionGraph();
    }
    add(entity) {
      const item = Object.assign({}, entity);
      if ((item.type === EntityType.Dimension || item.type === EntityType.AngleDimension || item.type === EntityType.RadiusDimension || item.type === EntityType.DiameterDimension) && !this.dimensionGraph.accept(item)) return null;
      this.entities.push(item);
      return item;
    }
    geometry(entity) { return this.add(Object.assign({ type: EntityType.GeometryObject, lineClass: LineClass.OBJECT_VISIBLE }, entity)); }
    dimension(entity) { return this.add(Object.assign({ type: EntityType.Dimension, dimensionType: "linear", priority: 50 }, entity)); }
    angle(entity) { return this.add(Object.assign({ type: EntityType.AngleDimension, dimensionType: "angular", priority: 60 }, entity)); }
    radius(entity) { return this.add(Object.assign({ type: EntityType.RadiusDimension, dimensionType: "radius", priority: 30 }, entity)); }
    diameter(entity) { return this.add(Object.assign({ type: EntityType.DiameterDimension, dimensionType: "diameter", priority: 30 }, entity)); }
    leader(entity) { return this.add(Object.assign({ type: EntityType.Leader, lineClass: LineClass.LEADER }, entity)); }
    center(entity) { return this.add(Object.assign({ type: EntityType.CenterLine, lineClass: LineClass.CENTER }, entity)); }
    note(entity) { return this.add(Object.assign({ type: EntityType.Note }, entity)); }
    reference(entity) { return this.add(Object.assign({ type: EntityType.ReferenceLabel }, entity)); }
  }

  class DimensionLayoutEngine {
    constructor(style) { this.style = Object.assign({}, DrawingStyle, style || {}); }
    layout(model, transform) {
      const geometry = model.entities.filter(e => e.type === EntityType.GeometryObject || e.type === EntityType.CenterLine || e.type === EntityType.Axis);
      const geometryBoxes = geometry.flatMap(e => entityCollisionBoxes(e,transform));
      const occupied = [];
      const dimensions = model.entities.filter(e => [EntityType.Dimension, EntityType.AngleDimension, EntityType.RadiusDimension, EntityType.DiameterDimension].includes(e.type)).sort((a, b) => (b.priority || 0) - (a.priority || 0));
      const placements = new Map();
      let lane = { top: 0, bottom: 0, left: 0, right: 0, aligned: 0, angular: 0 };
      dimensions.forEach(dimension => {
        let candidates = [];
        if (dimension.type === EntityType.Dimension) {
          const a = transform.point(dimension.p1), b = transform.point(dimension.p2), direction = unit(sub(b, a)), n = normal(direction), horizontal = Math.abs(direction.x) >= Math.abs(direction.y), preferred = dimension.preferredSide || (horizontal ? "bottom" : "left"), sides = [preferred].concat(["top", "bottom", "left", "right"].filter(side => side !== preferred));
          sides.forEach((side, sideIndex) => {
            const sign = side === "top" || side === "left" ? -1 : 1;
            const axisNormal = dimension.dimensionType === "aligned"
              ? mul(normal(direction), sign)
              : (horizontal ? p(0, sign) : p(sign, 0));
            for (let extra = 0; extra < 12; extra += 1) {
              const distance = this.style.laneGap * (1 + (lane[side] || 0) + extra) + (dimension.offset || 0);
              const q1 = add(a, mul(axisNormal, distance)), q2 = add(b, mul(axisNormal, distance));
              const text = dimension.displayValue !== undefined ? String(dimension.displayValue) : String(roundDisplay(dimension.exactValue));
              const rotation = getDimensionTextRotation(sub(q2, q1));
              const textPosition = add(midpoint(q1, q2), mul(axisNormal, this.style.textGap));
              const box = textBox(text, textPosition, rotation, this.style.dimensionFontSize);
              const outside=box.x1<8||box.y1<8||box.x2>model.viewport.width-8||box.y2>model.viewport.height-8?1:0;
              const collisions = outside+occupied.filter(o => boxesOverlap(box, o, 3)).length + geometryBoxes.filter(g => boxesOverlap(box, g, 2)).length;
              candidates.push({ q1, q2, text, textPosition, rotation, box, side, score: collisions * 10000 + sideIndex * 100 + extra });
            }
          });
        } else if (dimension.type === EntityType.AngleDimension) {
          const vertex = transform.point(dimension.vertex), baseRadius = dimension.radius || 42;
          for (let extra = 0; extra < 12; extra += 1) {
            const radius = baseRadius + extra * 18;
            const start = Number(dimension.startAngle), end = Number(dimension.endAngle), middle = start + (end - start) / 2;
            const text = dimension.displayValue !== undefined ? String(dimension.displayValue) + "°" : formatNumber(dimension.exactValue) + "°";
            [0,-18,18,-32,32].forEach((angleOffset,offsetIndex)=>{
              const textAngle=middle+angleOffset,textPosition=add(vertex,p(Math.cos(rad(textAngle))*(radius+18),-Math.sin(rad(textAngle))*(radius+18)));
              const box=textBox(text,textPosition,0,this.style.dimensionFontSize),outside=box.x1<8||box.y1<8||box.x2>model.viewport.width-8||box.y2>model.viewport.height-8?1:0;
              const collisions=outside+occupied.filter(o=>boxesOverlap(box,o,4)).length+geometryBoxes.filter(g=>boxesOverlap(box,g,4)).length;
              candidates.push({vertex,radius,startAngle:start,endAngle:end,text,textPosition,rotation:0,box,score:collisions*10000+extra+offsetIndex*.1});
            });
          }
        } else {
          const target = transform.point(dimension.target || dimension.arcPoint || dimension.center), preferred = dimension.preferredSide || "right";
          const directions = preferred === "left" ? [-1, 1] : [1, -1];
          directions.forEach((sign, sideIndex) => {[-1,1].forEach((verticalSign,verticalIndex)=>{
            for (let extra = 0; extra < 8; extra += 1) {
              const elbow = add(target, p(sign * (38 + extra * 24), verticalSign*(25 + extra * 8)));
              const textPosition = add(elbow, p(sign * 42, verticalSign * 20));
              const prefix = dimension.type === EntityType.RadiusDimension ? "R" : "Ø";
              const text = prefix + String(dimension.displayValue !== undefined ? dimension.displayValue : roundDisplay(dimension.exactValue));
              const box = textBox(text, textPosition, 0, this.style.dimensionFontSize);
              const outside=box.x1<8||box.y1<8||box.x2>model.viewport.width-8||box.y2>model.viewport.height-8?1:0;
              const collisions = outside+occupied.filter(o => boxesOverlap(box, o, 4)).length + geometryBoxes.filter(g => boxesOverlap(box, g, 4)).length;
              candidates.push({ target, elbow, textPosition, text, rotation: 0, box, score: collisions * 10000 + sideIndex * 100 + verticalIndex*.1 + extra });
            }
          });});
          [p(90,48),p(model.viewport.width-90,48),p(90,model.viewport.height-48),p(model.viewport.width-90,model.viewport.height-48)].forEach((textPosition,index)=>{
            const prefix=dimension.type===EntityType.RadiusDimension?"R":"Ø",text=prefix+String(dimension.displayValue!==undefined?dimension.displayValue:roundDisplay(dimension.exactValue)),box=textBox(text,textPosition,0,this.style.dimensionFontSize),collisions=occupied.filter(o=>boxesOverlap(box,o,4)).length+geometryBoxes.filter(g=>boxesOverlap(box,g,4)).length,elbow=p((target.x+textPosition.x)/2,(target.y+textPosition.y)/2);
            candidates.push({target,elbow,textPosition,text,rotation:0,box,score:collisions*10000+500+index});
          });
        }
        candidates.sort((a, b) => a.score - b.score);
        const best = candidates[0];
        placements.set(dimension, best);
        if (best) { occupied.push(best.box); if (best.side) lane[best.side] = (lane[best.side] || 0) + 1; }
      });
      const annotationPlacements=new Map(),annotations=model.entities.filter(e=>e.type===EntityType.Note||e.type===EntityType.ReferenceLabel||e.type===EntityType.Leader);
      annotations.forEach(entity=>{
        const source=entity.type===EntityType.Leader?transform.point(entity.points[entity.points.length-1]):transform.point(entity.position),text=String(entity.text||""),fontSize=entity.type===EntityType.ReferenceLabel?this.style.referenceFontSize:this.style.noteFontSize,candidates=[];
        [p(0,0),p(0,-1),p(0,1),p(-1,0),p(1,0),p(-.75,-.75),p(.75,-.75),p(-.75,.75),p(.75,.75)].forEach((direction,index)=>{for(let laneIndex=0;laneIndex<8;laneIndex+=1){const textPosition=add(source,mul(direction,18+laneIndex*20)),box=textBox(text,textPosition,0,fontSize),outside=box.x1<8||box.y1<8||box.x2>model.viewport.width-8||box.y2>model.viewport.height-8?1:0,collisions=outside+occupied.filter(o=>boxesOverlap(box,o,4)).length+geometryBoxes.filter(g=>boxesOverlap(box,g,3)).length;candidates.push({textPosition,box,score:collisions*10000+index*10+laneIndex});}});
        [p(120,48),p(model.viewport.width-120,48),p(120,model.viewport.height-48),p(model.viewport.width-120,model.viewport.height-48),p(model.viewport.width/2,48),p(model.viewport.width/2,model.viewport.height-48)].forEach((textPosition,index)=>{const box=textBox(text,textPosition,0,fontSize),collisions=occupied.filter(o=>boxesOverlap(box,o,4)).length+geometryBoxes.filter(g=>boxesOverlap(box,g,3)).length;candidates.push({textPosition,box,score:collisions*10000+900+index});});
        candidates.sort((a,b)=>a.score-b.score);const best=candidates[0];annotationPlacements.set(entity,best);if(best)occupied.push(best.box);
      });
      const dimensionCollisions=Array.from(placements.values()).reduce((sum,value)=>sum+(value&&value.score>=10000?1:0),0),annotationCollisions=Array.from(annotationPlacements.values()).reduce((sum,value)=>sum+(value&&value.score>=10000?1:0),0);
      return { placements, annotationPlacements, occupied, geometryBoxes, collisionCount: dimensionCollisions+annotationCollisions };
    }
  }

  class TechnicalDrawingRenderer {
    constructor(style) { this.style = Object.assign({}, DrawingStyle, style || {}); this.layoutEngine = new DimensionLayoutEngine(this.style); }
    makeTransform(model) {
      const geometryPoints = model.entities.filter(e => e.type === EntityType.GeometryObject || e.type === EntityType.CenterLine || e.type === EntityType.Axis).flatMap(entityPoints);
      const world = pointsBox(geometryPoints.length ? geometryPoints : [p(0, 0), p(1, 1)]), viewport = model.viewport, margin = this.style.margin;
      const width = Math.max(1, world.x2 - world.x1), height = Math.max(1, world.y2 - world.y1), scale = Math.min((viewport.width - margin * 2) / width, (viewport.height - margin * 2) / height);
      const usedWidth = width * scale, usedHeight = height * scale, offsetX = (viewport.width - usedWidth) / 2 - world.x1 * scale, offsetY = (viewport.height - usedHeight) / 2 + world.y2 * scale;
      return { scale, point: q => p(offsetX + q.x * scale, offsetY - q.y * scale), world, viewport };
    }
    slash(point, direction) {
      const d = unit(direction), n = normal(d), s = this.style.slashLength / 2, a = add(point, add(mul(d, s), mul(n, -s))), b = add(point, add(mul(d, -s), mul(n, s)));
      return `<line class="td-dimension" x1="${a.x.toFixed(2)}" y1="${a.y.toFixed(2)}" x2="${b.x.toFixed(2)}" y2="${b.y.toFixed(2)}"/>`;
    }
    drawGeometry(entity, transform) {
      const pts = (entity.points || []).map(transform.point), cls = "td-" + String(entity.lineClass || LineClass.OBJECT_VISIBLE).toLowerCase().replace(/_/g, "-");
      if (entity.kind === "rect") { const a = transform.point(entity.p1), b = transform.point(entity.p2); return `<rect class="${cls}" x="${Math.min(a.x,b.x)}" y="${Math.min(a.y,b.y)}" width="${Math.abs(b.x-a.x)}" height="${Math.abs(b.y-a.y)}"/>`; }
      if (entity.kind === "circle") { const c = transform.point(entity.center); return `<circle class="${cls}" cx="${c.x}" cy="${c.y}" r="${Math.max(2,(entity.radius||1)*transform.scale)}"/>`; }
      if (entity.kind === "tube") return `<polyline class="td-object-visible td-tube" points="${pts.map(q=>q.x.toFixed(2)+","+q.y.toFixed(2)).join(" ")}" style="stroke-width:${Math.max(5,(entity.diameter||1)*transform.scale).toFixed(2)}"/>`;
      if (entity.kind === "polygon") return `<polygon class="${cls}" points="${pts.map(q=>q.x.toFixed(2)+","+q.y.toFixed(2)).join(" ")}"/>`;
      return `<polyline class="${cls}" points="${pts.map(q=>q.x.toFixed(2)+","+q.y.toFixed(2)).join(" ")}"/>`;
    }
    drawLinearDimension(dimension, placement, transform) {
      if (!placement) return "";
      const a = transform.point(dimension.p1), b = transform.point(dimension.p2), q1 = placement.q1, q2 = placement.q2, direction = sub(q2, q1), action = dimension.action ? ` data-td-action="${esc(dimension.action)}"` : "";
      const ext1 = unit(sub(q1, a)), ext2 = unit(sub(q2, b)), e1s = add(a, mul(ext1, this.style.extensionGap)), e1e = add(q1, mul(ext1, this.style.extensionOvershoot)), e2s = add(b, mul(ext2, this.style.extensionGap)), e2e = add(q2, mul(ext2, this.style.extensionOvershoot));
      return `<g class="td-dimension-entity"${action}><line class="td-extension" x1="${e1s.x}" y1="${e1s.y}" x2="${e1e.x}" y2="${e1e.y}"/><line class="td-extension" x1="${e2s.x}" y1="${e2s.y}" x2="${e2e.x}" y2="${e2e.y}"/><line class="td-dimension" x1="${q1.x}" y1="${q1.y}" x2="${q2.x}" y2="${q2.y}"/>${this.slash(q1,direction)}${this.slash(q2,direction)}<text class="td-dimension-text" x="${placement.textPosition.x}" y="${placement.textPosition.y}" text-anchor="middle" dominant-baseline="middle" transform="rotate(${placement.rotation} ${placement.textPosition.x} ${placement.textPosition.y})">${esc(placement.text)}</text><line class="td-hit" x1="${q1.x}" y1="${q1.y}" x2="${q2.x}" y2="${q2.y}"/></g>`;
    }
    drawAlignedDimension(dimension, placement, transform) { return this.drawLinearDimension(dimension, placement, transform); }
    drawAngularDimension(dimension, placement) {
      if (!placement) return "";
      const v = placement.vertex, r = placement.radius, start = placement.startAngle, end = placement.endAngle, a = p(v.x + Math.cos(rad(start))*r, v.y - Math.sin(rad(start))*r), b = p(v.x + Math.cos(rad(end))*r, v.y - Math.sin(rad(end))*r), large = Math.abs(end-start)>180?1:0, sweep = end < start ? 1 : 0, action = dimension.action ? ` data-td-action="${esc(dimension.action)}"` : "";
      const arm = r + 16, a2 = p(v.x + Math.cos(rad(start))*arm, v.y - Math.sin(rad(start))*arm), b2 = p(v.x + Math.cos(rad(end))*arm, v.y - Math.sin(rad(end))*arm);
      return `<g class="td-angle-entity"${action}><line class="td-construction" x1="${v.x}" y1="${v.y}" x2="${a2.x}" y2="${a2.y}"/><line class="td-construction" x1="${v.x}" y1="${v.y}" x2="${b2.x}" y2="${b2.y}"/><path class="td-dimension td-angle-arc" d="M${a.x} ${a.y} A${r} ${r} 0 ${large} ${sweep} ${b.x} ${b.y}" marker-start="url(#td-arrow)" marker-end="url(#td-arrow)"/><text class="td-dimension-text" x="${placement.textPosition.x}" y="${placement.textPosition.y}" text-anchor="middle" dominant-baseline="middle">${esc(placement.text)}</text><path class="td-hit" d="M${a.x} ${a.y} A${r} ${r} 0 ${large} ${sweep} ${b.x} ${b.y}"/></g>`;
    }
    drawRadiusDimension(dimension, placement) { return this.drawLeaderDimension(dimension, placement, "td-radius-entity"); }
    drawDiameterDimension(dimension, placement) { return this.drawLeaderDimension(dimension, placement, "td-diameter-entity"); }
    drawLeaderDimension(dimension, placement, className) {
      if (!placement) return "";
      const action = dimension.action ? ` data-td-action="${esc(dimension.action)}"` : "";
      return `<g class="${className}"${action}><polyline class="td-leader" points="${placement.target.x},${placement.target.y} ${placement.elbow.x},${placement.elbow.y} ${placement.textPosition.x},${placement.textPosition.y}" marker-start="url(#td-arrow)"/><text class="td-dimension-text" x="${placement.textPosition.x}" y="${placement.textPosition.y-5}" text-anchor="middle">${esc(placement.text)}</text></g>`;
    }
    drawLeader(entity, transform, placement) {
      const points = (entity.points || []).map(transform.point), end = placement?placement.textPosition:points[points.length-1];if(placement)points[points.length-1]=end;const action = entity.action ? ` data-td-action="${esc(entity.action)}"` : "";
      return `<g${action}><polyline class="td-leader" points="${points.map(q=>q.x+","+q.y).join(" ")}" marker-start="url(#td-arrow)"/><text class="td-note-text" x="${end.x}" y="${end.y-5}" text-anchor="${entity.textAnchor||"middle"}">${esc(entity.text||"")}</text></g>`;
    }
    drawCenterLine(entity, transform) { return this.drawGeometry(Object.assign({}, entity, { lineClass: LineClass.CENTER }), transform); }
    render(model) {
      const transform = this.makeTransform(model), layout = this.layoutEngine.layout(model, transform), viewport = model.viewport;
      const geometry = model.entities.filter(e => e.type === EntityType.GeometryObject).map(e => this.drawGeometry(e, transform)).join("");
      const centers = model.entities.filter(e => e.type === EntityType.CenterLine || e.type === EntityType.Axis).map(e => this.drawCenterLine(e, transform)).join("");
      const dims = model.entities.filter(e => e.type === EntityType.Dimension).map(e => e.dimensionType === "aligned" ? this.drawAlignedDimension(e, layout.placements.get(e), transform) : this.drawLinearDimension(e, layout.placements.get(e), transform)).join("");
      const angles = model.entities.filter(e => e.type === EntityType.AngleDimension).map(e => this.drawAngularDimension(e, layout.placements.get(e), transform)).join("");
      const radii = model.entities.filter(e => e.type === EntityType.RadiusDimension).map(e => this.drawRadiusDimension(e, layout.placements.get(e))).join("");
      const diameters = model.entities.filter(e => e.type === EntityType.DiameterDimension).map(e => this.drawDiameterDimension(e, layout.placements.get(e))).join("");
      const leaders = model.entities.filter(e => e.type === EntityType.Leader).map(e => this.drawLeader(e, transform,layout.annotationPlacements.get(e))).join("");
      const notes = model.entities.filter(e => e.type === EntityType.Note || e.type === EntityType.ReferenceLabel).map(e => { const placement=layout.annotationPlacements.get(e),q=placement?placement.textPosition:transform.point(e.position); return `<text class="${e.type===EntityType.Note?'td-note-text':'td-reference-text'}" x="${q.x}" y="${q.y}" text-anchor="${e.textAnchor||'middle'}">${esc(e.text)}</text>`; }).join("");
      const style = `<style>.td-svg{background:#fff;color:#111}.td-object-visible{fill:none;stroke:#111;stroke-width:${this.style.objectVisibleWeight};stroke-linecap:round;stroke-linejoin:round;vector-effect:non-scaling-stroke}.td-tube{stroke:#111;stroke-linecap:butt;stroke-linejoin:round;vector-effect:none}.td-dimension,.td-extension,.td-leader,.td-center,.td-construction,.td-hidden{fill:none;stroke:#111;vector-effect:non-scaling-stroke}.td-dimension{stroke-width:${this.style.dimensionWeight}}.td-extension{stroke-width:${this.style.extensionWeight}}.td-leader{stroke-width:${this.style.leaderWeight}}.td-center{stroke-width:${this.style.centerWeight};stroke-dasharray:14 3 3 3}.td-construction{stroke-width:${this.style.constructionWeight};stroke-dasharray:7 5}.td-hidden{stroke-width:${this.style.hiddenWeight};stroke-dasharray:5 4}.td-dimension-text{font:${this.style.dimensionFontSize}px ${this.style.technicalFont};font-weight:600;fill:#111}.td-note-text{font:${this.style.noteFontSize}px ${this.style.technicalFont};fill:#111}.td-reference-text{font:${this.style.referenceFontSize}px ${this.style.technicalFont};fill:#333}.td-hit{stroke:transparent;stroke-width:26;fill:none;cursor:pointer}.td-angle-arc{stroke-linecap:round}</style>`;
      return { svg: `<svg class="technical-svg td-svg" viewBox="0 0 ${viewport.width} ${viewport.height}" role="img" aria-label="${esc(model.title)}" data-td-collisions="${layout.collisionCount}"><defs><marker id="td-arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M10 5 L0 0 L0 10 Z" fill="#111"/></marker></defs>${style}<text class="td-reference-text" x="18" y="22">ROZMERY V ${esc(model.unit)}</text>${geometry}${centers}${dims}${angles}${radii}${diameters}${leaders}${notes}</svg>`, layout, transform };
    }
  }

  function sampleArc(start, headingDegrees, turnDegrees, radius, count) {
    const points = [], heading = rad(headingDegrees), turn = rad(turnDegrees), direction = Math.sign(turn) || 1;
    for (let i=0;i<=(count||18);i+=1) { const current=heading+turn*i/(count||18); points.push(p(start.x+radius/direction*(Math.sin(current)-Math.sin(heading)),start.y+radius/direction*(-Math.cos(current)+Math.cos(heading)))); }
    return { points, end: points[points.length-1], headingDegrees: headingDegrees+turnDegrees };
  }
  function pipeChain(start, initialHeading, commands, diameter) {
    let current=p(start.x,start.y), heading=initialHeading, points=[current], elbows=[];
    commands.forEach(command=>{ if(command.kind==="arc"){const arc=sampleArc(current,heading,command.turn,command.radius,20);points.push.apply(points,arc.points.slice(1));elbows.push({points:arc.points,angle:Math.abs(command.turn),centerPoint:arc.points[Math.floor(arc.points.length/2)]});current=arc.end;heading=arc.headingDegrees;}else{current=add(current,p(Math.cos(rad(heading))*command.length,Math.sin(rad(heading))*command.length));points.push(current);} });
    return { points, elbows, end:current, headingDegrees:heading, diameter };
  }

  function mm(ticks) { return Number(ticks)/100; }
  function dim(model, p1, p2, value, options) { return model.dimension(Object.assign({ p1, p2, exactValue:value, displayValue:roundDisplay(value), semanticName:"length" }, options||{})); }
  function note(model, text, position, options) { return model.note(Object.assign({ text, position },options||{})); }

  const Adapters = {
    division(values, input, oneSide) {
      const L=mm(values.targetLength), a=mm(values.nominalWidth), remainder=values.remainder!==undefined?mm(values.remainder):Math.max(0,L-a), left=input?(L-a)/2:(oneSide?0:mm(values.leftEdge)), right=input?(L-a)/2:(oneSide?remainder:mm(values.rightEdge)), m=new TechnicalDrawingModel({title:input?"VSTUP ROZDELENIA":"ROZDELENIE",viewport:{width:900,height:360}}), h=Math.max(30,Math.min(100,L*.08)), c=L/2;
      m.geometry({kind:"polygon",points:[p(0,0),p(L,0),p(L,h),p(0,h)]});
      if(input){m.geometry({points:[p(c-a/2,0),p(c-a/2,h)]});m.geometry({points:[p(c+a/2,0),p(c+a/2,h)]});}
      else { for(let i=0;i<=values.fullPieceCount;i+=1){const x=left+i*a;if(x>0&&x<L)m.geometry({points:[p(x,0),p(x,h)]});} }
      dim(m,p(0,h),p(L,h),L,{preferredSide:"top",priority:100,semanticName:"L",action:input?"basic:target":null});const pieceStart=input?c-a/2:left;dim(m,p(pieceStart,0),p(pieceStart+a,0),a,{preferredSide:"bottom",priority:30,semanticName:"a",action:input?"basic:width":null});
      if(!input&&left>0)dim(m,p(0,0),p(left,0),left,{preferredSide:"bottom",priority:20,semanticName:"leftEdge"});if(!input&&right>0)dim(m,p(L-right,0),p(L,0),right,{preferredSide:"bottom",priority:20,semanticName:"rightEdge"});
      note(m,input?"VSTUPNÉ KÓTY L, a":values.fullPieceCount+" × DIEL",p(c,h/2));return m;
    },
    correction(r){const L=mm(r.achievedLength),m=new TechnicalDrawingModel({title:"KOREKČNÝ PLÁN",viewport:{width:900,height:350}}),h=Math.max(30,L*.07),items=[mm(r.fixedLeft)].concat(r.pieces.map(piece=>mm(piece.finalWidth)),[mm(r.fixedRight)]),cursor=0;m.geometry({kind:"polygon",points:[p(0,0),p(L,0),p(L,h),p(0,h)]});items.forEach((value,index)=>{if(index>0){m.geometry({points:[p(cursor,0),p(cursor,h)]});}if(index===0||index===items.length-1||index===Math.floor(items.length/2))dim(m,p(cursor,0),p(cursor+value,0),value,{preferredSide:"bottom",priority:20,semanticName:"segment"});cursor+=value;});dim(m,p(0,h),p(L,h),L,{preferredSide:"top",priority:100,semanticName:"total"});note(m,r.pieceCount+" DIELov",p(L/2,h/2));return m;},
    triangle(values,computed){const a=mm(values.a),b=mm(values.b),c=mm(values.c),m=new TechnicalDrawingModel({title:"PRAVOUHLÝ TROJUHOLNÍK",viewport:{width:900,height:580}}),A=p(0,0),B=p(b,0),C=p(0,a);m.geometry({kind:"polygon",points:[A,B,C]});m.geometry({points:[p(0,Math.min(a,b)*.08),p(Math.min(a,b)*.08,Math.min(a,b)*.08),p(Math.min(a,b)*.08,0)]});dim(m,A,B,b,{preferredSide:"bottom",priority:70,semanticName:"b",action:"triangle:b"});dim(m,A,C,a,{preferredSide:"left",priority:70,semanticName:"a",action:"triangle:a"});dim(m,C,B,c,{preferredSide:"top",priority:70,semanticName:"c",dimensionType:"aligned",action:"triangle:c"});note(m,"90°",p(Math.min(a,b)*.12,Math.min(a,b)*.12));if(computed)note(m,"DOPOČÍTANÁ STRANA: "+computed.toUpperCase(),p(b*.72,a*.82));return m;},
    squaring(values,r){const l1=mm(values.l1),l2=mm(values.l2),h=mm(r.derivedHeight),shift=mm(r.signedXLeft),A=p(0,0),B=p(l2,0),C=p(shift+l1,h),D=p(shift,h),m=new TechnicalDrawingModel({title:"UHLOVANIE",viewport:{width:960,height:650}});m.geometry({kind:"polygon",points:[A,B,C,D]});m.geometry({lineClass:LineClass.CONSTRUCTION,points:[D,B]});m.geometry({lineClass:LineClass.CONSTRUCTION,points:[A,C]});dim(m,D,C,l1,{preferredSide:"top",priority:90,semanticName:"L1",action:"squaring:l1"});dim(m,A,B,l2,{preferredSide:"bottom",priority:90,semanticName:"L2",action:"squaring:l2"});dim(m,D,B,mm(values.d1),{preferredSide:"top",priority:40,semanticName:"d1",dimensionType:"aligned",action:"squaring:d1"});dim(m,A,C,mm(values.d2),{preferredSide:"bottom",priority:40,semanticName:"d2",dimensionType:"aligned",action:"squaring:d2"});if(Math.abs(shift)>0.1)dim(m,p(0,h),D,Math.abs(shift),{preferredSide:"top",priority:25,semanticName:"X1"});if(Math.abs((shift+l1)-l2)>0.1)dim(m,B,p(shift+l1,0),Math.abs((shift+l1)-l2),{preferredSide:"bottom",priority:25,semanticName:"X2"});Object.entries(r.angles).forEach(([key,value],index)=>{const vertices=[D,C,B,A],starts=[0,180,180,0],ends=[-value,180+value,180-value,value];m.angle({vertex:vertices[index],startAngle:starts[index],endAngle:ends[index],exactValue:value,displayValue:formatNumber(value),semanticName:key,priority:20});});return m;},
    slope(values,r){const w=mm(values.width),x=mm(r.x),angle=values.angleDegrees,L=Math.max(w*3,300),u=p(Math.cos(rad(angle)),Math.sin(rad(angle))),n=p(-u.y,u.x),A=p(0,0),B=mul(u,L),C=add(B,mul(n,w)),D=mul(n,w),m=new TechnicalDrawingModel({title:"KOLMICA",viewport:{width:900,height:560}});m.geometry({kind:"polygon",points:[A,B,C,D]});m.geometry({lineClass:LineClass.CONSTRUCTION,points:[p(-L*.15,0),p(L*.15,0)]});dim(m,B,C,w,{preferredSide:"right",priority:70,semanticName:"V",dimensionType:"aligned",action:"slope:width"});dim(m,add(C,mul(u,-x)),C,x,{preferredSide:"top",priority:50,semanticName:"X",dimensionType:"aligned"});m.angle({vertex:A,startAngle:0,endAngle:angle,exactValue:angle,displayValue:formatNumber(angle),semanticName:"alpha",action:"slope:angleDegrees",priority:80});return m;},
    clips(r){const L=mm(r.length),W=Math.max(250,L*.12),m=new TechnicalDrawingModel({title:"ROZLOŽENIE PRÍPONIEK",viewport:{width:900,height:700}});m.geometry({kind:"polygon",points:[p(0,0),p(W,0),p(W,L),p(0,L)]});r.zones.forEach(zone=>{m.geometry({kind:"rect",lineClass:zone.type==="fixed"?LineClass.OBJECT_VISIBLE:LineClass.CONSTRUCTION,p1:p(0,mm(zone.start)),p2:p(W,mm(zone.end))});note(m,String(zone.number),p(W*.22,(mm(zone.start)+mm(zone.end))/2));});r.clips.forEach(clip=>m.geometry({kind:"circle",center:p(W*.58,mm(clip.position)),radius:clip.type==="fixed"?7:5,lineClass:clip.type==="fixed"?LineClass.OBJECT_VISIBLE:LineClass.CONSTRUCTION}));dim(m,p(W,0),p(W,L),L,{preferredSide:"right",priority:100,semanticName:"L",action:"clips:length"});m.angle({vertex:p(-W*.3,0),startAngle:0,endAngle:r.angleDegrees,exactValue:r.angleDegrees,displayValue:formatNumber(r.angleDegrees),semanticName:"alpha",action:"clips:angleDegrees",priority:80});note(m,"ODKVAP",p(W/2,-L*.04));note(m,"HREBEŇ",p(W/2,L*1.04));return m;},
    dilatation(r){const L=mm(r.panelLength),upper=mm(r.upperSlidingLength),W=Math.max(220,L*.1),m=new TechnicalDrawingModel({title:"DILATÁCIA PRI HREBENI",viewport:{width:900,height:650}});m.geometry({kind:"polygon",points:[p(0,0),p(W,0),p(W,L),p(0,L)]});m.geometry({lineClass:LineClass.CONSTRUCTION,points:[p(0,L-upper),p(W,L-upper)]});dim(m,p(0,L-upper),p(0,L),upper,{preferredSide:"left",priority:90,semanticName:"upper"});m.diameter({target:p(W*.75,L-upper/2),exactValue:mm(r.screwDiameter),displayValue:formatNumber(mm(r.screwDiameter)),semanticName:"screw",action:"dilatation:screwDiameter"});note(m,"HORNÁ POSUVNÁ ZÓNA",p(W/2,L-upper/2));note(m,"OVÁL "+roundDisplay(mm(r.recommendedSlotWidth))+" × "+roundDisplay(mm(r.recommendedSlotLength)),p(W*1.55,L-upper/2));return m;},
    downpipe(r){const R=mm(r.bendRadius),I=mm(r.insertion),clear=mm(r.clearLength),theta=r.angleDegrees,chain=pipeChain(p(0,0),90,[{kind:"arc",turn:-theta,radius:R},{kind:"line",length:clear},{kind:"arc",turn:theta,radius:R}],mm(r.diameter)),m=new TechnicalDrawingModel({title:"ZVOD – DVE KOLENÁ",viewport:{width:980,height:680}}),start=chain.points[0],end=chain.end,t1=chain.elbows[0].points[chain.elbows[0].points.length-1],t2=chain.elbows[1].points[0],h=90-theta,u=p(Math.cos(rad(h)),Math.sin(rad(h))),cut1=add(t1,mul(u,-I)),cut2=add(t2,mul(u,I));m.geometry({kind:"tube",points:chain.points,diameter:mm(r.diameter)});m.center({points:chain.points});dim(m,p(start.x,start.y),p(end.x,start.y),mm(r.x),{preferredSide:"bottom",priority:100,semanticName:"X",action:"downpipe:x"});dim(m,p(start.x,start.y),p(start.x,end.y),mm(r.requiredY),{preferredSide:"left",priority:100,semanticName:"Y"});dim(m,cut1,cut2,mm(r.cutLength),{preferredSide:"top",priority:70,semanticName:"R",dimensionType:"aligned"});dim(m,cut1,t1,I,{preferredSide:"bottom",priority:20,semanticName:"insert1",dimensionType:"aligned",action:"downpipe:insertion"});dim(m,t2,cut2,I,{preferredSide:"bottom",priority:20,semanticName:"insert2",dimensionType:"aligned",action:"downpipe:insertion"});m.angle({vertex:t2,startAngle:90-theta,endAngle:90,exactValue:theta,displayValue:formatNumber(theta),semanticName:"elbow",action:"downpipe:angleDegrees",priority:60});m.diameter({target:chain.points[Math.floor(chain.points.length*.55)],exactValue:mm(r.diameter),displayValue:roundDisplay(mm(r.diameter)),semanticName:"diameter",action:"downpipe:diameter"});m.radius({target:chain.elbows[1].centerPoint,exactValue:R,displayValue:roundDisplay(R),semanticName:"radius"});note(m,"REZNÁ DĹŽKA R",midpoint(cut1,cut2));return m;},
    optimizer(r){const R=mm(r.bendRadius),I=mm(r.insertion||5000),a=mm(r.a),b=mm(r.b),ja=mm(r.jointA!==undefined?r.jointA:r.a),jb=mm(r.jointB!==undefined?r.jointB:r.b),commands=[{kind:"arc",turn:-r.angles[0],radius:R},{kind:"line",length:ja},{kind:"arc",turn:r.angles[1],radius:R},{kind:"line",length:jb},{kind:"arc",turn:r.angles[2],radius:R}],chain=pipeChain(p(0,0),90,commands,mm(r.diameter)),m=new TechnicalDrawingModel({title:"ZVOD – TRI KOLENÁ",viewport:{width:1000,height:760}}),start=chain.points[0],end=chain.end;m.geometry({kind:"tube",points:chain.points,diameter:mm(r.diameter)});m.center({points:chain.points});dim(m,p(start.x,start.y),p(end.x,start.y),Math.abs(end.x-start.x),{preferredSide:"bottom",priority:100,semanticName:"X",action:"optimizer:x"});dim(m,p(start.x,start.y),p(start.x,end.y),Math.abs(end.y-start.y),{preferredSide:"left",priority:100,semanticName:"Y"});let index=0,arc1=chain.elbows[0],arc2=chain.elbows[1];const s1=arc1.points[arc1.points.length-1],s2=arc2.points[0],s3=arc2.points[arc2.points.length-1],s4=chain.elbows[2].points[0];if(a>0)dim(m,s1,s2,a,{preferredSide:"bottom",priority:45,semanticName:"a",dimensionType:"aligned"});else note(m,"RÚRKA a NIE JE POTREBNÁ",p((s1.x+s2.x)/2,(s1.y+s2.y)/2));if(b>0)dim(m,s3,s4,b,{preferredSide:"bottom",priority:45,semanticName:"b",dimensionType:"aligned"});else note(m,"RÚRKA b NIE JE POTREBNÁ",p((s3.x+s4.x)/2,(s3.y+s4.y)/2));chain.elbows.forEach((elbow,i)=>m.leader({points:[elbow.centerPoint,add(elbow.centerPoint,p(i%2?R*.8:-R*.8,R*.8))],text:"K"+(i+1)+"  KOLENO "+r.angles[i]+"°"}));m.angle({vertex:end,startAngle:180-r.alphaDegrees,endAngle:180,exactValue:r.alphaDegrees,displayValue:formatNumber(r.alphaDegrees),semanticName:"alpha",action:"optimizer:alphaDegrees",priority:90});m.diameter({target:chain.points[Math.floor(chain.points.length*.58)],exactValue:mm(r.diameter),displayValue:roundDisplay(mm(r.diameter)),semanticName:"diameter",action:"optimizer:diameter"});m.radius({target:chain.elbows[1].centerPoint,exactValue:R,displayValue:roundDisplay(R),semanticName:"radius"});note(m,"ZASUNUTIE SPOJOV "+roundDisplay(I),p(end.x+R,end.y-R));return m;}
  };

  Adapters.correction = function (r) {
    const L=mm(r.achievedLength),m=new TechnicalDrawingModel({title:"KOREKČNÝ PLÁN",viewport:{width:900,height:350}}),h=Math.max(30,L*.07),items=[mm(r.fixedLeft)].concat(r.pieces.map(piece=>mm(piece.finalWidth)),[mm(r.fixedRight)]);
    let cursor=0;m.geometry({kind:"polygon",points:[p(0,0),p(L,0),p(L,h),p(0,h)]});
    items.forEach((value,index)=>{if(index>0)m.geometry({points:[p(cursor,0),p(cursor,h)]});if(index===0||index===items.length-1||index===Math.floor(items.length/2))dim(m,p(cursor,0),p(cursor+value,0),value,{preferredSide:"bottom",priority:20,semanticName:"segment"});cursor+=value;});
    dim(m,p(0,h),p(L,h),L,{preferredSide:"top",priority:100,semanticName:"total"});note(m,r.pieceCount+" DIELOV",p(L/2,h/2));return m;
  };

  // The three-elbow adapter deliberately works with two different lengths:
  // workshop cut length (a/b) and installed tangent distance (jointA/jointB).
  // This prevents insertion from being counted only in the result table.
  Adapters.optimizer = function (r) {
    const R=mm(r.bendRadius), I=mm(r.insertion||5000), a=mm(r.a), b=mm(r.b), ja=mm(r.jointA), jb=mm(r.jointB);
    const chain=pipeChain(p(0,0),90,[{kind:"arc",turn:-r.angles[0],radius:R},{kind:"line",length:ja},{kind:"arc",turn:r.angles[1],radius:R},{kind:"line",length:jb},{kind:"arc",turn:r.angles[2],radius:R}],mm(r.diameter));
    const m=new TechnicalDrawingModel({title:"ZVOD – TRI KOLENÁ",viewport:{width:1000,height:760}}), start=chain.points[0], end=chain.end;
    m.geometry({kind:"tube",points:chain.points,diameter:mm(r.diameter)});m.center({points:chain.points});
    dim(m,p(start.x,start.y),p(end.x,start.y),Math.abs(end.x-start.x),{preferredSide:"bottom",priority:100,semanticName:"X",action:"optimizer:x"});
    dim(m,p(start.x,start.y),p(start.x,end.y),Math.abs(end.y-start.y),{preferredSide:"left",priority:100,semanticName:"Y"});
    const arc1=chain.elbows[0],arc2=chain.elbows[1],arc3=chain.elbows[2],s1=arc1.points[arc1.points.length-1],s2=arc2.points[0],s3=arc2.points[arc2.points.length-1],s4=arc3.points[0];
    function cutDimensions(from,to,cutLength,name){
      if(cutLength<=0){note(m,"RÚRKA "+name+" NIE JE POTREBNÁ",midpoint(from,to));return;}
      const u=unit(sub(to,from)),cutStart=add(from,mul(u,-I)),cutEnd=add(to,mul(u,I));
      dim(m,cutStart,cutEnd,cutLength,{preferredSide:"bottom",priority:48,semanticName:name,dimensionType:"aligned"});
      dim(m,cutStart,from,I,{preferredSide:"top",priority:18,semanticName:name+"-insert-1",dimensionType:"aligned"});
      dim(m,to,cutEnd,I,{preferredSide:"top",priority:18,semanticName:name+"-insert-2",dimensionType:"aligned"});
    }
    cutDimensions(s1,s2,a,"a");cutDimensions(s3,s4,b,"b");
    chain.elbows.forEach((elbow,i)=>m.leader({points:[elbow.centerPoint,add(elbow.centerPoint,p(i%2?R*.9:-R*.9,R*.9))],text:"K"+(i+1)+"  KOLENO "+r.angles[i]+"°"}));
    m.angle({vertex:end,startAngle:180-r.alphaDegrees,endAngle:180,exactValue:r.alphaDegrees,displayValue:formatNumber(r.alphaDegrees),semanticName:"alpha",action:"optimizer:alphaDegrees",priority:90});
    m.diameter({target:chain.points[Math.floor(chain.points.length*.58)],exactValue:mm(r.diameter),displayValue:roundDisplay(mm(r.diameter)),semanticName:"diameter",action:"optimizer:diameter"});
    m.radius({target:chain.elbows[1].centerPoint,exactValue:R,displayValue:roundDisplay(R),semanticName:"radius"});
    return m;
  };

  function replaceSvg(selector, model, actions) {
    const old = typeof selector === "string" ? document.querySelector(selector) : selector;
    if (!old || !model) return null;
    const result = new TechnicalDrawingRenderer().render(model), holder = document.createElement("div"); holder.innerHTML = result.svg; const svg = holder.firstElementChild;
    if (old.id) svg.id = old.id;
    svg.style.width = old.style.width || "100%"; svg.style.height = "auto";
    old.replaceWith(svg);
    svg.querySelectorAll("[data-td-action]").forEach(element=>{element.addEventListener("click",event=>{event.stopPropagation();const action=element.dataset.tdAction;if(actions&&actions[action])actions[action]();});});
    return result;
  }

  const API = {
    EntityType, LineClass, DrawingStyle, TechnicalDrawingModel, DimensionGraph, DimensionLayoutEngine, TechnicalDrawingRenderer, Adapters, replaceSvg,
    getDimensionTextRotation, drawLinearDimension:function(renderer,d,p,t){return renderer.drawLinearDimension(d,p,t);}, drawAlignedDimension:function(renderer,d,p,t){return renderer.drawAlignedDimension(d,p,t);}, drawAngularDimension:function(renderer,d,p){return renderer.drawAngularDimension(d,p);}, drawRadiusDimension:function(renderer,d,p){return renderer.drawRadiusDimension(d,p);}, drawDiameterDimension:function(renderer,d,p){return renderer.drawDiameterDimension(d,p);}, drawLeader:function(renderer,e,t){return renderer.drawLeader(e,t);}, drawCenterLine:function(renderer,e,t){return renderer.drawCenterLine(e,t);},
    geometry:{p,add,sub,mul,length,unit,normal,midpoint,sampleArc,pipeChain,textBox,boxesOverlap}
  };
  root.TechnicalDrawing = API;
  if (typeof module !== "undefined" && module.exports) module.exports = API;
})(typeof window !== "undefined" ? window : globalThis);
