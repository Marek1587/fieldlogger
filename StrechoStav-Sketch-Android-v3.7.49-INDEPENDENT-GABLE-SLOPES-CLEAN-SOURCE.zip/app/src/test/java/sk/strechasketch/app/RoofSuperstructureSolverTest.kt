package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class RoofSuperstructureSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun graph(): RoofGraph {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 4.0),
            GraphNode("b", 10.0, 0.0, 4.0),
            GraphNode("c", 10.0, 8.0, 10.4),
            GraphNode("d", 0.0, 8.0, 10.4)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("eave", "a", "b", true, EdgeSemantic.EAVE, setOf("face")),
            GraphEdge("right", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
            GraphEdge("high", "c", "d", true, EdgeSemantic.RIDGE, setOf("face")),
            GraphEdge("left", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
        ).associateBy { it.id }
        val face = GraphFace(
            id = "face",
            orderedNodeIds = listOf("a", "b", "c", "d"),
            orderedEdgeIds = listOf("eave", "right", "high", "left"),
            signedAreaM2 = 80.0,
            plane = RoofPlane(0.0, 0.8, 4.0)
        )
        return RoofGraph(origin, nodes, edges, mapOf(face.id to face))
    }

    private fun objectAt(
        type: ObjectType,
        widthMm: Double,
        depthMm: Double,
        dormerType: DormerType = DormerType.GABLE
    ) = RoofObject(
        id = "test-${type.name.lowercase()}",
        type = type,
        center = Geometry.toGeo(LocalPoint(5.0, 4.0), origin),
        widthMm = widthMm,
        heightMm = depthMm,
        attachedFaceId = "face",
        dormerType = dormerType,
        dormerOverhangMm = 250.0,
        superstructureHeightM = 1.2,
        superstructureSlopeDeg = 25.0
    )

    @Test
    fun `gable dormer cuts host face and creates its own roof surfaces`() {
        val solution = RoofSuperstructureSolver.solve(
            graph(), listOf(objectAt(ObjectType.DORMER, 1800.0, 2400.0))
        )
        val item = solution.items.single()
        assertEquals(1, solution.graphWithOpenings.faces.getValue("face").holeNodeIdLoops.size)
        assertEquals(5, item.footprint.size)
        assertEquals(5, solution.graphWithOpenings.faces.getValue("face").holeNodeIdLoops.single().size)
        assertTrue(item.openingPlanAreaM2 > 0.0)
        assertEquals(item.openingPlanAreaM2 * sqrt(1.64), item.openingArea3DM2, 1e-6)
        assertTrue(item.addedRoofAreaM2 > 0.0)
        assertEquals(2, item.surfaces.count { it.role == SuperstructureSurfaceRole.ROOF })
        assertEquals(2, item.surfaces.count { it.role == SuperstructureSurfaceRole.WALL && it.vertices.size == 3 })
        assertFalse(item.projectsBeyondHost)
    }

    @Test
    fun `gable dormer planes are planar trapezoids clipped by real host intersections`() {
        val sourceGraph = graph()
        val item = RoofSuperstructureSolver.solve(
            sourceGraph, listOf(objectAt(ObjectType.DORMER, 1800.0, 2400.0, DormerType.GABLE))
        ).items.single()
        val roofs = item.surfaces.filter { it.role == SuperstructureSurfaceRole.ROOF }
        assertEquals(2, roofs.size)
        assertTrue(roofs.all { it.vertices.size == 4 && isPlanar(it.vertices) })
        val rear = roofs.flatMap { it.vertices }.filter { it.id.contains("rear-intersection") }.distinctBy { it.id }
        assertEquals(3, rear.size)
        val host = sourceGraph.faces.getValue("face").plane!!
        rear.forEach { assertEquals(host.zAt(it.x, it.y), it.z, 1e-9) }
        val ridge = rear.single { it.id.contains("ridge") }
        val eaves = rear.filterNot { it.id.contains("ridge") }
        assertTrue(eaves.all { ridge.y > it.y })
    }

    @Test
    fun `hipped dormer uses triangular front plane and planar side trapezoids`() {
        val sourceGraph = graph()
        val item = RoofSuperstructureSolver.solve(
            sourceGraph, listOf(objectAt(ObjectType.DORMER, 2000.0, 2800.0, DormerType.HIPPED))
        ).items.single()
        val roofs = item.surfaces.filter { it.role == SuperstructureSurfaceRole.ROOF }
        assertEquals(3, roofs.size)
        assertEquals(3, roofs.single { it.id.endsWith("roof-front") }.vertices.size)
        assertTrue(roofs.filterNot { it.id.endsWith("roof-front") }.all { it.vertices.size == 4 && isPlanar(it.vertices) })
        assertEquals(5, item.footprint.size)
        val host = sourceGraph.faces.getValue("face").plane!!
        roofs.flatMap { it.vertices }.filter { it.id.contains("rear-intersection") }.distinctBy { it.id }
            .forEach { assertEquals(host.zAt(it.x, it.y), it.z, 1e-9) }
    }

    @Test
    fun `all dormer tiles produce deterministic roof geometry`() {
        DormerType.entries.forEach { type ->
            val item = RoofSuperstructureSolver.solve(
                graph(), listOf(objectAt(ObjectType.DORMER, 1800.0, 2400.0, type))
            ).items.single()
            assertTrue("$type must have a roof", item.surfaces.any { it.role == SuperstructureSurfaceRole.ROOF })
            assertTrue(item.surfaces.all { surface -> surface.vertices.size >= 3 })
        }
    }

    @Test
    fun `trapezoid dormer has central and two chamfered side roof planes with rear seam on host roof`() {
        val sourceGraph = graph()
        val item = RoofSuperstructureSolver.solve(
            sourceGraph,
            listOf(objectAt(ObjectType.DORMER, 2400.0, 3000.0, DormerType.TRAPEZOID))
        ).items.single()
        val roofs = item.surfaces.filter { it.role == SuperstructureSurfaceRole.ROOF }
        assertEquals(3, roofs.size)
        assertTrue(roofs.any { it.id.endsWith("roof-main") })
        assertTrue(roofs.any { it.id.endsWith("roof-side-left") })
        assertTrue(roofs.any { it.id.endsWith("roof-side-right") })

        val plane = sourceGraph.faces.getValue("face").plane!!
        val rearVertices = roofs
            .flatMap { it.vertices }
            .filter { it.id.contains("rear-intersection") }
            .distinctBy { it.id }
        assertTrue("Rear seam needs explicit host-roof intersections", rearVertices.size >= 3)
        rearVertices.forEach { vertex ->
            assertEquals(plane.zAt(vertex.x, vertex.y), vertex.z, 1e-9)
        }
        assertTrue(roofs.flatMap { it.vertices }.all { it.x.isFinite() && it.y.isFinite() && it.z.isFinite() })
    }

    @Test
    fun `dormer roof overhang extends beyond its wall footprint`() {
        val dormer = objectAt(ObjectType.DORMER, 2400.0, 3000.0, DormerType.TRAPEZOID).copy(
            dormerOverhangMm = 400.0
        )
        val item = RoofSuperstructureSolver.solve(graph(), listOf(dormer)).items.single()
        val roofVertices = item.surfaces
            .filter { it.role == SuperstructureSurfaceRole.ROOF }
            .flatMap { it.vertices }
        val wallMinY = item.footprint.minOf { it.y }
        assertTrue(roofVertices.minOf { it.y } <= wallMinY - 0.399)
    }

    @Test
    fun `terrace is a real opening with floor and side walls but no added roof`() {
        val solution = RoofSuperstructureSolver.solve(
            graph(), listOf(objectAt(ObjectType.TERRACE, 3000.0, 4000.0))
        )
        val item = solution.items.single()
        assertEquals(12.0, item.openingPlanAreaM2, 1e-6)
        assertEquals(0.0, item.addedRoofAreaM2, 1e-9)
        assertEquals(1, item.surfaces.count { it.role == SuperstructureSurfaceRole.FLOOR })
        assertEquals(4, item.surfaces.count { it.role == SuperstructureSurfaceRole.WALL })
        assertEquals(1, solution.graphWithOpenings.faces.getValue("face").holeNodeIdLoops.size)
    }

    @Test
    fun `machine room and shaft are secondary components with flat roofs`() {
        val objects = listOf(
            objectAt(ObjectType.MACHINE_ROOM, 2200.0, 2600.0),
            objectAt(ObjectType.SHAFT, 1200.0, 1400.0).copy(id = "test-shaft-2")
        )
        val solution = RoofSuperstructureSolver.solve(graph(), objects)
        assertEquals(2, solution.items.size)
        solution.items.forEach { item ->
            assertEquals(1, item.surfaces.count { it.role == SuperstructureSurfaceRole.ROOF })
            assertEquals(4, item.surfaces.count { it.role == SuperstructureSurfaceRole.WALL })
        }
    }

    @Test
    fun `superstructure parameters survive canonical project json`() {
        val project = RoofProject(name = "Vikiere").apply {
            objects += objectAt(ObjectType.DORMER, 2100.0, 2800.0, DormerType.NAPOLEON).copy(
                superstructureHeightM = 1.75,
                superstructureSlopeDeg = 32.5,
                dormerOverhangMm = 420.0
            )
            objects += objectAt(ObjectType.TERRACE, 3200.0, 4500.0).copy(
                id = "terrace-json",
                superstructureHeightM = 0.35
            )
        }
        val decoded = ProjectJson.decode(ProjectJson.encode(project))
        val dormer = decoded.objects.first { it.type == ObjectType.DORMER }
        val terrace = decoded.objects.first { it.type == ObjectType.TERRACE }
        assertEquals(DormerType.NAPOLEON, dormer.dormerType)
        assertEquals(1.75, dormer.superstructureHeightM, 0.0)
        assertEquals(32.5, dormer.superstructureSlopeDeg, 0.0)
        assertEquals(420.0, dormer.dormerOverhangMm, 0.0)
        assertEquals(0.35, terrace.superstructureHeightM, 0.0)
    }

    private fun isPlanar(vertices: List<GraphNode>): Boolean {
        if (vertices.size <= 3) return true
        val a = vertices[0]
        val b = vertices[1]
        val c = vertices[2]
        val ux = b.x - a.x; val uy = b.y - a.y; val uz = b.z - a.z
        val vx = c.x - a.x; val vy = c.y - a.y; val vz = c.z - a.z
        val nx = uy * vz - uz * vy
        val ny = uz * vx - ux * vz
        val nz = ux * vy - uy * vx
        return vertices.drop(3).all { p ->
            kotlin.math.abs(nx * (p.x - a.x) + ny * (p.y - a.y) + nz * (p.z - a.z)) < 1e-8
        }
    }
}
