package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

class MetricPlanGridTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun projectGridIsMetricAndIndependentOfMapZoom() {
        val angle = Math.toRadians(23.0)
        fun world(u: Double, v: Double) = LocalPoint(
            u * cos(angle) - v * sin(angle),
            u * sin(angle) + v * cos(angle)
        )
        val project = RoofProject(
            centerLat = origin.lat,
            centerLon = origin.lon,
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 23.0
        )
        val raw = Geometry.toGeo(world(1.047, 2.062), origin)

        project.zoom = 14
        val first = MetricPlanGrid.snap(project, raw)
        project.zoom = 22
        val second = MetricPlanGrid.snap(project, raw)

        assertEquals(first.lat, second.lat, 1e-12)
        assertEquals(first.lon, second.lon, 1e-12)
        val local = Geometry.toLocal(first, origin)
        assertTrue(MetricPlanGrid.isOnGrid(local, 23.0))
        val expected = world(1.0, 2.1)
        assertEquals(expected.x, local.x, 1e-6)
        assertEquals(expected.y, local.y, 1e-6)
    }

    @Test
    fun topologySolverReturnsEveryNodeOnOneHundredMillimetreGrid() {
        val topology = RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("a", 0.013, -0.018, TopologyNodeType.FOOTPRINT),
                TopologyNode("b", 6.027, 0.041, TopologyNodeType.FOOTPRINT),
                TopologyNode("c", 6.012, 4.064, TopologyNodeType.FOOTPRINT),
                TopologyNode("d", -0.033, 4.019, TopologyNodeType.FOOTPRINT)
            ),
            edges = listOf(
                TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true),
                TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true),
                TopologyEdge("cd", "c", "d", LineType.EAVE, boundary = true),
                TopologyEdge("da", "d", "a", LineType.GABLE, boundary = true)
            )
        )

        val solved = RoofTopologySolver.solveOutline(topology).proposed
        val rotation = MetricPlanGrid.axisDeg(solved) ?: 0.0
        assertTrue(solved.nodes.all { MetricPlanGrid.isOnGrid(LocalPoint(it.x, it.y), rotation) })
    }

    @Test
    fun graphOperationsCannotMoveNodeInsideGridCell() {
        val topology = RoofTopology(
            origin,
            listOf(
                TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b", 5.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("c", 5.0, 4.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("d", 0.0, 4.0, TopologyNodeType.FOOTPRINT)
            ),
            listOf(
                TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true),
                TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true),
                TopologyEdge("cd", "c", "d", LineType.EAVE, boundary = true),
                TopologyEdge("da", "d", "a", LineType.GABLE, boundary = true)
            )
        )
        val graph = RoofGraphFactory.fromTopology(topology)
        val moved = requireNotNull(RoofGraphOperations.moveNode(graph, "b", 5.037, 0.044))

        assertEquals(5.0, moved.nodes.getValue("b").x, 1e-9)
        assertEquals(0.0, moved.nodes.getValue("b").y, 1e-9)
    }

    @Test
    fun projectTopologyAndGraphKeepTheSameGridFrameAfterJsonRoundTrip() {
        val topology = RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b", 4.6, 1.9, TopologyNodeType.FOOTPRINT),
                TopologyNode("c", 3.1, 5.6, TopologyNodeType.FOOTPRINT)
            ),
            edges = listOf(
                TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true),
                TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true),
                TopologyEdge("ca", "c", "a", LineType.EAVE, boundary = true)
            ),
            gridRotationDeg = 23.0
        )
        val project = RoofProject(
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 23.0,
            roofTopology = topology,
            roofGraph = RoofGraphFactory.fromTopology(topology)
        )

        val restored = ProjectJson.decode(ProjectJson.encode(project))

        assertEquals(23.0, restored.geometryGridRotationDeg, 1e-12)
        assertEquals(23.0, requireNotNull(restored.roofTopology).gridRotationDeg, 1e-12)
        assertEquals(23.0, requireNotNull(restored.roofGraph).gridRotationDeg, 1e-12)
    }
}
