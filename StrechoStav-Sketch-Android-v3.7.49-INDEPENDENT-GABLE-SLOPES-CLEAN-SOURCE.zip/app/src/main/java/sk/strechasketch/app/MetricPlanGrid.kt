package sk.strechasketch.app

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sin

/**
 * Invisible project-local construction grid.
 *
 * The grid is expressed in metres, never in screen pixels. Its origin and axis are persisted
 * in [RoofProject], therefore map zoom, map rotation and panning cannot move the lattice below
 * already created geometry. Only XY plan coordinates are quantized; solved elevations stay exact.
 */
object MetricPlanGrid {
    const val STEP_M = 0.10
    private const val EPS = 1e-9

    fun ensureProjectFrame(project: RoofProject, candidates: List<GeoPoint> = emptyList()) {
        if (!project.geometryGridOriginLat.isFinite() || !project.geometryGridOriginLon.isFinite()) {
            val origin = project.roofGraph?.origin
                ?: project.roofTopology?.origin
                ?: candidates.firstOrNull()
                ?: project.polygon.firstOrNull()
                ?: project.lines.firstOrNull()?.start
                ?: GeoPoint(project.centerLat, project.centerLon)
            project.geometryGridOriginLat = origin.lat
            project.geometryGridOriginLon = origin.lon
        }
        if (!project.geometryGridRotationDeg.isFinite()) {
            val origin = projectOrigin(project)
            val source = when {
                candidates.size >= 2 -> candidates
                project.polygon.size >= 2 -> project.polygon
                else -> emptyList()
            }
            project.geometryGridRotationDeg = source.longestAxisDeg(origin)
                ?: project.roofGraph?.let(::axisDeg)
                ?: project.roofTopology?.let(::axisDeg)
                ?: 0.0
        }
        project.geometryGridRotationDeg = normalizeSquareAxis(project.geometryGridRotationDeg)
    }

    fun snap(project: RoofProject, point: GeoPoint, candidates: List<GeoPoint> = emptyList()): GeoPoint {
        ensureProjectFrame(project, candidates)
        val origin = projectOrigin(project)
        return Geometry.toGeo(
            snap(Geometry.toLocal(point, origin), project.geometryGridRotationDeg),
            origin
        )
    }

    fun snap(point: LocalPoint, rotationDeg: Double): LocalPoint {
        val angle = Math.toRadians(normalizeSquareAxis(rotationDeg))
        val c = cos(angle)
        val s = sin(angle)
        val u = point.x * c + point.y * s
        val v = -point.x * s + point.y * c
        val snappedU = quantize(u)
        val snappedV = quantize(v)
        return LocalPoint(
            x = clean(snappedU * c - snappedV * s),
            y = clean(snappedU * s + snappedV * c)
        )
    }

    fun snap(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        return topology.copy(
            nodes = topology.nodes.map { node ->
                val point = snap(LocalPoint(node.x, node.y), rotation)
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    fun snap(graph: RoofGraph): RoofGraph {
        val rotation = axisDeg(graph) ?: 0.0
        return graph.copy(
            nodes = graph.nodes.mapValues { (_, node) ->
                val point = snap(LocalPoint(node.x, node.y), rotation)
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    fun isOnGrid(point: LocalPoint, rotationDeg: Double, toleranceM: Double = 1e-7): Boolean {
        val snapped = snap(point, rotationDeg)
        return hypot(point.x - snapped.x, point.y - snapped.y) <= toleranceM
    }

    fun axisDeg(topology: RoofTopology): Double? {
        topology.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val nodes = topology.nodes.associateBy { it.id }
        return topology.edges.asSequence().filter { it.boundary }.mapNotNull { edge ->
            val a = nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = nodes[edge.endNodeId] ?: return@mapNotNull null
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    fun axisDeg(graph: RoofGraph): Double? {
        graph.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val topology = graph.toTopology()
        return axisDeg(topology)
    }

    private fun List<GeoPoint>.longestAxisDeg(origin: GeoPoint): Double? {
        if (size < 2) return null
        return indices.mapNotNull { index ->
            val a = Geometry.toLocal(this[index], origin)
            val b = Geometry.toLocal(this[(index + 1) % size], origin)
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    private fun projectOrigin(project: RoofProject) =
        GeoPoint(project.geometryGridOriginLat, project.geometryGridOriginLon)

    private fun quantize(value: Double): Double = round(value / STEP_M) * STEP_M

    private fun clean(value: Double): Double = if (kotlin.math.abs(value) < EPS) 0.0 else value

    private fun normalizeSquareAxis(value: Double): Double {
        if (!value.isFinite()) return 0.0
        var normalized = value % 90.0
        if (normalized < 0.0) normalized += 90.0
        // 90 degrees describes the same square lattice as 0 degrees.
        if (kotlin.math.abs(normalized - 90.0) < 1e-10) normalized = 0.0
        return normalized
    }
}
