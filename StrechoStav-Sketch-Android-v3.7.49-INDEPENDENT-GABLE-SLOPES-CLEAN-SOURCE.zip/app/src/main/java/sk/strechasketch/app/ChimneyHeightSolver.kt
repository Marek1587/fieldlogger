package sk.strechasketch.app

import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.tan

/** Why the automatic chimney height was selected. Kept explicit for deterministic tests/audit. */
enum class ChimneyHeightRule {
    RIDGE_WITHIN_TWO_METRES,
    RIDGE_TEN_DEGREE_CLEARANCE,
    LOW_SLOPE_PARALLEL_CLEARANCE,
    ATTIC_CLEARANCE,
    NO_RIDGE_CLEARANCE
}

data class ChimneyHeightResult(
    /** Height stored by [RoofObject.value], measured vertically above the roof at chimney axis. */
    val heightAboveRoofM: Double,
    val topElevationM: Double,
    val roofElevationM: Double,
    val rule: ChimneyHeightRule,
    val ridgeDistanceM: Double? = null
)

/**
 * Deterministic chimney-height solver operating on the solved RoofGraph.
 *
 * It never changes topology. All elevations come from the attached face plane z=a*x+b*y+c
 * and from solved graph nodes, so moving a chimney across faces remains reproducible.
 */
object ChimneyHeightSolver {
    const val RIDGE_NEAR_DISTANCE_M = 2.0
    const val RIDGE_CLEARANCE_M = 0.65
    const val FLAT_OR_ATTIC_CLEARANCE_M = 1.0
    const val LOW_SLOPE_LIMIT_DEG = 20.0
    const val CLEARANCE_ANGLE_DEG = 10.0

    private data class RidgeReference(val distanceM: Double, val elevationM: Double)

    /**
     * Re-enables automatic mode and applies the deterministic solver result to the chimney.
     * The manual lock is cleared only after a valid solution has been found.
     */
    fun applyAutomatic(
        graph: RoofGraph,
        face: GraphFace,
        chimneyAxis: LocalPoint,
        atticHeightM: Double,
        fallbackSlopeDeg: Double,
        chimney: RoofObject
    ): ChimneyHeightResult? {
        val solved = solve(graph, face, chimneyAxis, atticHeightM, fallbackSlopeDeg) ?: return null
        chimney.value = solved.heightAboveRoofM
        chimney.chimneyHeightManual = false
        return solved
    }

    fun solve(
        graph: RoofGraph,
        face: GraphFace,
        chimneyAxis: LocalPoint,
        atticHeightM: Double,
        fallbackSlopeDeg: Double
    ): ChimneyHeightResult? {
        val plane = face.plane ?: return null
        val roofZ = plane.zAt(chimneyAxis.x, chimneyAxis.y)
        if (!roofZ.isFinite()) return null

        val slopeDeg = face.slopeConstraint?.angleDeg
            ?.takeIf { it.isFinite() && it >= 0.0 }
            ?: Math.toDegrees(atan(hypot(plane.a, plane.b)))
                .takeIf { it.isFinite() }
            ?: fallbackSlopeDeg.coerceAtLeast(0.0)

        val faceEdges = face.orderedEdgeIds.mapNotNull(graph.edges::get)
        val atticEdges = faceEdges.filter { it.boundary && it.semanticRole == EdgeSemantic.ATTIC }
        val atticTopZ = atticEdges.flatMap { edge ->
            listOfNotNull(graph.nodes[edge.startNodeId], graph.nodes[edge.endNodeId])
        }.maxOfOrNull { node -> node.z }?.plus(atticHeightM.coerceAtLeast(0.0))

        // For roofs below 20 degrees, the clearance plane is parallel to the local roof.
        // A parapet remains the controlling obstacle when it rises above that plane.
        if (slopeDeg < LOW_SLOPE_LIMIT_DEG) {
            val referenceZ = max(roofZ, atticTopZ ?: Double.NEGATIVE_INFINITY)
            return result(
                roofZ = roofZ,
                requestedTopZ = referenceZ + FLAT_OR_ATTIC_CLEARANCE_M,
                rule = if (atticTopZ != null && atticTopZ >= roofZ) {
                    ChimneyHeightRule.ATTIC_CLEARANCE
                } else {
                    ChimneyHeightRule.LOW_SLOPE_PARALLEL_CLEARANCE
                }
            )
        }

        val incidentRidges = faceEdges.filter { it.semanticRole == EdgeSemantic.RIDGE }
        val ridgePool = if (incidentRidges.isNotEmpty()) incidentRidges else {
            // Legacy graphs may omit orderedEdgeIds on a face. Prefer explicitly adjacent
            // ridges, then use the nearest ridge as a safe deterministic fallback.
            graph.edges.values.filter { edge ->
                edge.semanticRole == EdgeSemantic.RIDGE &&
                    (face.id in edge.adjacentFaceIds || edge.adjacentFaceIds.isEmpty())
            }.ifEmpty { graph.edges.values.filter { it.semanticRole == EdgeSemantic.RIDGE } }
        }
        val ridge = ridgePool.mapNotNull { nearestRidgeReference(graph, it, chimneyAxis) }
            .minByOrNull { it.distanceM }

        if (ridge != null) {
            return if (ridge.distanceM <= RIDGE_NEAR_DISTANCE_M + 1e-9) {
                result(
                    roofZ = roofZ,
                    requestedTopZ = ridge.elevationM + RIDGE_CLEARANCE_M,
                    rule = ChimneyHeightRule.RIDGE_WITHIN_TWO_METRES,
                    ridgeDistanceM = ridge.distanceM
                )
            } else {
                val tenDegreeLineZ = ridge.elevationM -
                    tan(Math.toRadians(CLEARANCE_ANGLE_DEG)) * ridge.distanceM
                result(
                    roofZ = roofZ,
                    requestedTopZ = max(
                        tenDegreeLineZ + RIDGE_CLEARANCE_M,
                        roofZ + RIDGE_CLEARANCE_M
                    ),
                    rule = ChimneyHeightRule.RIDGE_TEN_DEGREE_CLEARANCE,
                    ridgeDistanceM = ridge.distanceM
                )
            }
        }

        if (atticTopZ != null) {
            return result(
                roofZ = roofZ,
                requestedTopZ = atticTopZ + FLAT_OR_ATTIC_CLEARANCE_M,
                rule = ChimneyHeightRule.ATTIC_CLEARANCE
            )
        }

        // Pult/only-eave roofs have no ridge. Their highest solved boundary is the reference.
        val highestBoundaryZ = faceEdges.filter(GraphEdge::boundary).flatMap { edge ->
            listOfNotNull(graph.nodes[edge.startNodeId], graph.nodes[edge.endNodeId])
        }.maxOfOrNull(GraphNode::z) ?: roofZ
        return result(
            roofZ = roofZ,
            requestedTopZ = max(highestBoundaryZ, roofZ) + FLAT_OR_ATTIC_CLEARANCE_M,
            rule = ChimneyHeightRule.NO_RIDGE_CLEARANCE
        )
    }

    private fun result(
        roofZ: Double,
        requestedTopZ: Double,
        rule: ChimneyHeightRule,
        ridgeDistanceM: Double? = null
    ): ChimneyHeightResult {
        val height = (requestedTopZ - roofZ).coerceIn(RIDGE_CLEARANCE_M, 20.0)
        return ChimneyHeightResult(
            heightAboveRoofM = height,
            topElevationM = roofZ + height,
            roofElevationM = roofZ,
            rule = rule,
            ridgeDistanceM = ridgeDistanceM
        )
    }

    private fun nearestRidgeReference(
        graph: RoofGraph,
        edge: GraphEdge,
        point: LocalPoint
    ): RidgeReference? {
        val start = graph.nodes[edge.startNodeId] ?: return null
        val end = graph.nodes[edge.endNodeId] ?: return null
        val dx = end.x - start.x
        val dy = end.y - start.y
        val lengthSquared = dx * dx + dy * dy
        val t = if (lengthSquared <= 1e-12) 0.0 else {
            ((point.x - start.x) * dx + (point.y - start.y) * dy) / lengthSquared
        }.coerceIn(0.0, 1.0)
        val closestX = start.x + dx * t
        val closestY = start.y + dy * t
        val z = start.z + (end.z - start.z) * t
        return RidgeReference(hypot(point.x - closestX, point.y - closestY), z)
    }
}
