package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset

class IfcExporterTest {
    @Test fun simpleGableMatchesGoldenIfcFixture() {
        val clock = Clock.fixed(Instant.parse("2026-08-17T10:00:00Z"), ZoneOffset.UTC)
        val expected = requireNotNull(javaClass.getResourceAsStream("/ifc/simple_gable.ifc")) {
            "Missing golden IFC fixture"
        }.use { it.readBytes() }
        val actual = IfcExporter.export(IfcTestFixtures.gableProject(), clock).bytes
        assertArrayEquals(expected, actual)
    }

    @Test fun repeatedExportIsByteStableWithInjectedClockAndPassesSanityValidation() {
        val clock = Clock.fixed(Instant.parse("2026-08-17T10:00:00Z"), ZoneOffset.UTC)
        val project = IfcTestFixtures.gableProject()
        val first = IfcExporter.export(project, clock)
        val second = IfcExporter.export(project, clock)
        assertArrayEquals(first.bytes, second.bytes)
        assertTrue(first.validation.errors.joinToString(), first.validation.valid)
        assertEquals(first.statistics, second.statistics)
        assertFalse(first.bytes.toString(Charsets.US_ASCII).contains("NaN"))
        assertFalse(first.bytes.toString(Charsets.US_ASCII).contains("Infinity"))
    }
}
