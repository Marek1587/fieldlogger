// Field Manual Logger -> Google Sheets + Google Drive photos
//
// This script receives JSON from Android.
// If photo_base64 is present, it creates a JPG file in Google Drive
// and stores photo_url + photo_file_id in the Sheet.
//
// Deploy as Web App:
// Execute as: Me
// Who has access: Anyone

const SPREADSHEET_ID = '1FC3tOKFC2hyid--rvhoISmF_1CNYiRhN'; // uprav podľa svojej natívnej Google tabuľky
const SHEET_NAME = 'Manual Log';
const PHOTO_FOLDER_NAME = 'FieldLoggerPhotos';

const HEADER = [
  'timestamp',
  'event_type',
  'lokalita',
  'miesto',
  'lat',
  'lon',
  'accuracy_m',
  'provider',
  'title',
  'note',
  'local_photo_path',
  'photo_file_id',
  'photo_url',
  'photo_filename'
];

function doPost(e) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME);
    if (!sh) sh = ss.insertSheet(SHEET_NAME);

    if (sh.getLastRow() === 0) {
      sh.appendRow(HEADER);
    }

    const d = JSON.parse((e && e.postData && e.postData.contents) ? e.postData.contents : '{}');

    let photoFileId = '';
    let photoUrl = '';
    let photoFilename = d.photo_filename || '';

    if (d.photo_base64 && d.photo_filename) {
      const folder = getOrCreateFolder_(PHOTO_FOLDER_NAME);
      const bytes = Utilities.base64Decode(d.photo_base64);
      const mimeType = d.photo_mime_type || 'image/jpeg';
      const filename = makeSafeFilename_(d.photo_filename, d.timestamp, d.lokalita, d.miesto);

      const blob = Utilities.newBlob(bytes, mimeType, filename);
      const file = folder.createFile(blob);
      photoFileId = file.getId();
      photoUrl = file.getUrl();
      photoFilename = filename;

      // Voliteľné: ak chceš, aby link vedel otvoriť každý s odkazom, odkomentuj:
      // file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    }

    sh.appendRow([
      d.timestamp || '',
      d.event_type || '',
      d.lokalita || '',
      d.miesto || '',
      d.lat || '',
      d.lon || '',
      d.accuracy_m || '',
      d.provider || '',
      d.title || '',
      d.note || '',
      d.local_photo_path || d.photo_path || '',
      photoFileId,
      photoUrl,
      photoFilename
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true, photo_url: photoUrl, photo_file_id: photoFileId }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(err) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput('Field Manual Logger endpoint OK')
    .setMimeType(ContentService.MimeType.TEXT);
}

function getOrCreateFolder_(name) {
  const it = DriveApp.getFoldersByName(name);
  if (it.hasNext()) return it.next();
  return DriveApp.createFolder(name);
}

function makeSafeFilename_(original, timestamp, lokalita, miesto) {
  const ts = (timestamp || new Date().toISOString()).replace(/[^0-9A-Za-z_-]/g, '_');
  const loc = (lokalita || '').toString().substring(0, 40).replace(/[^0-9A-Za-zÁÄČĎÉÍĹĽŇÓÔŔŠŤÚÝŽáäčďéíĺľňóôŕšťúýž_-]/g, '_');
  const place = (miesto || '').toString().substring(0, 40).replace(/[^0-9A-Za-zÁÄČĎÉÍĹĽŇÓÔŔŠŤÚÝŽáäčďéíĺľňóôŕšťúýž_-]/g, '_');

  const ext = original.toLowerCase().endsWith('.png') ? '.png' : '.jpg';
  const base = [ts, loc, place].filter(Boolean).join('__');
  return (base || 'field_photo') + ext;
}
