// Field Manual Logger -> Google Sheets
// Use this as Google Apps Script Web App endpoint.
// Replace SPREADSHEET_ID with your native Google Sheet ID if needed.

const SPREADSHEET_ID = '1FC3tOKFC2hyid--rvhoISmF_1CNYiRhN';
const SHEET_NAME = 'Manual Log';

const HEADER = [
  'timestamp',
  'event_type',
  'lokalita',
  'miesto',
  'lat',
  'lon',
  'accuracy_m',
  'provider',
  'title',
  'note',
  'photo_path'
];

function doPost(e) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME);
    if (!sh) sh = ss.insertSheet(SHEET_NAME);
    if (sh.getLastRow() === 0) sh.appendRow(HEADER);
    const d = JSON.parse(e.postData.contents || '{}');
    sh.appendRow([
      d.timestamp || '',
      d.event_type || '',
      d.lokalita || '',
      d.miesto || '',
      d.lat || '',
      d.lon || '',
      d.accuracy_m || '',
      d.provider || '',
      d.title || '',
      d.note || '',
      d.photo_path || ''
    ]);
    return ContentService.createTextOutput(JSON.stringify({ ok: true })).setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ ok: false, error: String(err) })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService.createTextOutput('Field Manual Logger endpoint OK').setMimeType(ContentService.MimeType.TEXT);
}
