package sk.strechostav.fieldmanual

import android.content.Context
import android.util.Base64
import java.io.File
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object GoogleSync {
    private const val PREF = "field_manual_logger"
    private const val KEY_URL = "google_script_url"

    fun url(context: Context): String {
        return context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY_URL, "") ?: ""
    }

    fun setUrl(context: Context, url: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY_URL, url.trim()).apply()
    }

    fun syncAsync(context: Context, entry: ManualLogEntry, callback: (Boolean, String) -> Unit) {
        val target = url(context)
        if (target.isBlank()) {
            callback(false, "Google URL nie je nastavené.")
            return
        }

        Thread {
            try {
                val conn = URL(target).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 30000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(json(entry))
                }

                val code = conn.responseCode
                callback(code in 200..299, "HTTP $code")
                conn.disconnect()
            } catch (e: Exception) {
                callback(false, e.message ?: "sync error")
            }
        }.start()
    }

    private fun json(entry: ManualLogEntry): String {
        val map = LinkedHashMap<String, String>()
        map["timestamp"] = entry.timestamp
        map["event_type"] = entry.eventType
        map["lokalita"] = entry.lokalita
        map["miesto"] = entry.miesto
        map["lat"] = entry.lat
        map["lon"] = entry.lon
        map["accuracy_m"] = entry.accuracy
        map["provider"] = entry.provider
        map["title"] = entry.title
        map["note"] = entry.note
        map["local_photo_path"] = entry.photoPath

        val photoFile = if (entry.photoPath.isNotBlank()) File(entry.photoPath) else null
        if (photoFile != null && photoFile.exists() && photoFile.isFile) {
            try {
                val bytes = photoFile.readBytes()
                map["photo_filename"] = photoFile.name
                map["photo_mime_type"] = "image/jpeg"
                map["photo_base64"] = Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (_: Exception) {
                // Ak sa fotka nepodarí načítať, syncne sa aspoň textový záznam.
            }
        }

        return map.entries.joinToString(prefix = "{", postfix = "}") { item ->
            "\"" + esc(item.key) + "\":\"" + esc(item.value) + "\""
        }
    }

    private fun esc(v: String): String {
        return v
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", " ")
            .replace("\r", " ")
    }
}
