package sk.strechostav.fieldmanual

import android.content.Context
import android.location.Location
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.FileOutputStream

data class ManualLogEntry(
    val timestamp: String,
    val eventType: String,
    val lokalita: String,
    val miesto: String,
    val lat: String,
    val lon: String,
    val accuracy: String,
    val provider: String,
    val title: String,
    val note: String,
    val photoPath: String
) {
    fun values(): List<String> = listOf(timestamp, eventType, lokalita, miesto, lat, lon, accuracy, provider, title, note, photoPath)
}

object ManualLogStore {
    private val header = listOf("timestamp", "event_type", "lokalita", "miesto", "lat", "lon", "accuracy_m", "provider", "title", "note", "photo_path")

    fun baseDir(context: Context): File {
        val d = File(context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "FieldLogger")
        d.mkdirs()
        return d
    }

    fun photoDir(context: Context): File {
        val d = File(baseDir(context), "photos")
        d.mkdirs()
        return d
    }

    fun dataFile(context: Context): File {
        val f = File(baseDir(context), "field_manual_log_data.tsv")
        if (!f.exists()) f.writeText(header.joinToString("\t") + "\n", Charsets.UTF_8)
        return f
    }

    fun localXlsxFile(context: Context): File = File(baseDir(context), "field_manual_log.xlsx")

    fun now(): String = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(java.util.Date())
    fun stamp(): String = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    fun append(context: Context, eventType: String, title: String, lokalita: String, miesto: String, note: String = "", location: Location? = null, photoPath: String = ""): ManualLogEntry? {
        return try {
            val entry = ManualLogEntry(
                timestamp = now(),
                eventType = eventType,
                lokalita = lokalita,
                miesto = miesto,
                lat = location?.latitude?.toString() ?: "",
                lon = location?.longitude?.toString() ?: "",
                accuracy = location?.accuracy?.toString() ?: "",
                provider = location?.provider ?: "",
                title = title,
                note = note,
                photoPath = photoPath
            )
            dataFile(context).appendText(entry.values().joinToString("\t") { clean(it) } + "\n", Charsets.UTF_8)
            rebuildLocalXlsx(context)
            exportToConfiguredDocument(context)
            entry
        } catch (_: Exception) {
            null
        }
    }

    fun rows(context: Context): List<List<String>> {
        return dataFile(context).readLines(Charsets.UTF_8).map { line -> line.split("\t") }
    }

    fun rebuildLocalXlsx(context: Context): Boolean {
        return try {
            FileOutputStream(localXlsxFile(context)).use { out -> XlsxWriter.writeWorkbook(out, rows(context)) }
            true
        } catch (_: Exception) { false }
    }

    fun configuredDocumentUri(context: Context): Uri? {
        val s = context.getSharedPreferences("field_manual_logger", Context.MODE_PRIVATE).getString("excel_uri", null)
        return if (s.isNullOrBlank()) null else Uri.parse(s)
    }

    fun setConfiguredDocumentUri(context: Context, uri: Uri) {
        context.getSharedPreferences("field_manual_logger", Context.MODE_PRIVATE).edit().putString("excel_uri", uri.toString()).apply()
    }

    fun exportToConfiguredDocument(context: Context): Boolean {
        val uri = configuredDocumentUri(context) ?: return false
        return try {
            context.contentResolver.openOutputStream(uri, "wt")?.use { out -> XlsxWriter.writeWorkbook(out, rows(context)) }
            true
        } catch (_: Exception) { false }
    }

    private fun clean(value: String): String {
        return value.replace("\n", " ").replace("\r", " ").replace("\t", " ").trim()
    }
}
