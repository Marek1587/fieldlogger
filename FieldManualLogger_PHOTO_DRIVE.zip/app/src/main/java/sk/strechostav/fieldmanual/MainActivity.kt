package sk.strechostav.fieldmanual

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.DragEvent
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

data class TileDef(val id: String, val label: String, val color: String)

class MainActivity : Activity() {
    private val reqPerm = 1001
    private val reqPhoto = 2001
    private val reqExcelDocument = 3001

    private lateinit var lokalitaEdit: EditText
    private lateinit var miestoEdit: EditText
    private lateinit var noteEdit: EditText
    private lateinit var statusText: TextView

    private var pendingPhotoLokalita: String = ""
    private var pendingPhotoMiesto: String = ""
    private var pendingPhotoNote: String = ""
    private var pendingPhotoFile: File? = null

    private var speechRecognizer: SpeechRecognizer? = null
    private var isDictating = false
    private val handler = Handler(Looper.getMainLooper())

    private val defaultOrder = listOf("excel", "google", "dictate", "arrival", "inspection", "measurement", "phone", "departure", "note", "gps", "photo", "rebuild", "share")

    private val tiles = mapOf(
        "excel" to TileDef("excel", "📄\nExcel", "#455A64"),
        "google" to TileDef("google", "☁️\nGoogle URL", "#3367D6"),
        "dictate" to TileDef("dictate", "🎙️\nDiktovať", "#AD1457"),
        "arrival" to TileDef("arrival", "🏗️\nPríchod", "#2E7D32"),
        "inspection" to TileDef("inspection", "🔍\nObhliadka", "#1565C0"),
        "measurement" to TileDef("measurement", "📏\nMeranie", "#6A1B9A"),
        "phone" to TileDef("phone", "☎️\nTelefonát", "#EF6C00"),
        "departure" to TileDef("departure", "🚗\nOdchod", "#C62828"),
        "note" to TileDef("note", "📝\nPoznámka", "#5D4037"),
        "gps" to TileDef("gps", "📍\nGPS", "#00838F"),
        "photo" to TileDef("photo", "📷\nFotka", "#283593"),
        "rebuild" to TileDef("rebuild", "🔄\nObnoviť", "#546E7A"),
        "share" to TileDef("share", "📤\nZdieľať", "#00796B")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                File(getExternalFilesDir(null), "field_manual_crash.txt").appendText("${ManualLogStore.now()} ${e.stackTraceToString()}\n\n", Charsets.UTF_8)
            } catch (_: Exception) {}
        }
        requestPermissionsIfNeeded()
        buildUi()
        safeRefreshStatus()
    }

    override fun onDestroy() {
        stopDictation()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        if (::statusText.isInitialized) safeRefreshStatus()
    }

    private fun buildUi() {
        val oldLokalita = if (::lokalitaEdit.isInitialized) lokalitaEdit.text.toString() else loadSavedLokalita()
        val oldMiesto = if (::miestoEdit.isInitialized) miestoEdit.text.toString() else loadSavedMiesto()
        val oldNote = if (::noteEdit.isInitialized) noteEdit.text.toString() else ""

        val scroll = ScrollView(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(16), dp(16), dp(16))
        scroll.addView(root)

        val title = TextView(this)
        title.text = "Field Manual Logger"
        title.textSize = 25f
        title.typeface = Typeface.DEFAULT_BOLD
        title.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title, full())

        val subtitle = TextView(this)
        subtitle.text = "Lokalita + miesto + poznámka + fotky + Excel/Sheets"
        subtitle.textSize = 14f
        subtitle.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(subtitle, full())

        lokalitaEdit = EditText(this)
        lokalitaEdit.hint = "Lokalita: napr. ulica stavby"
        lokalitaEdit.setText(oldLokalita)
        root.addView(lokalitaEdit, full())

        miestoEdit = EditText(this)
        miestoEdit.hint = "Miesto: napr. ľavá strana vikiera"
        miestoEdit.setText(oldMiesto)
        root.addView(miestoEdit, full())

        noteEdit = EditText(this)
        noteEdit.hint = "Poznámka / nadpis záznamu..."
        noteEdit.minLines = 3
        noteEdit.gravity = Gravity.TOP
        noteEdit.setText(oldNote)
        root.addView(noteEdit, full())

        val hint = TextView(this)
        hint.text = "Dlaždicu podrž a presuň na inú dlaždicu pre zmenu poradia. Poznámka je povinná."
        hint.textSize = 12f
        hint.setTextColor(Color.DKGRAY)
        root.addView(hint, full())

        val grid = GridLayout(this)
        grid.columnCount = 2
        root.addView(grid, full())

        loadOrder().forEach { id -> tiles[id]?.let { addTile(grid, it) } }

        statusText = TextView(this)
        statusText.textSize = 12f
        statusText.setPadding(0, dp(14), 0, 0)
        root.addView(statusText, full())
        setContentView(scroll)
    }

    private fun addTile(grid: GridLayout, tile: TileDef) {
        val b = Button(this)
        b.text = if (tile.id == "dictate" && isDictating) "⏹️\nStop" else tile.label
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.CENTER
        b.isAllCaps = false
        b.typeface = Typeface.DEFAULT_BOLD
        val bg = GradientDrawable()
        bg.setColor(Color.parseColor(tile.color))
        bg.cornerRadius = dp(14).toFloat()
        b.background = bg
        b.setOnClickListener { handleTile(tile.id) }
        b.setOnLongClickListener {
            val data = ClipData.newPlainText("tile_id", tile.id)
            it.startDragAndDrop(data, View.DragShadowBuilder(it), tile.id, 0)
            true
        }
        b.setOnDragListener { _, event ->
            when (event.action) {
                DragEvent.ACTION_DROP -> {
                    val from = event.localState as? String
                    if (from != null && from != tile.id) swapTiles(from, tile.id)
                    true
                }
                else -> true
            }
        }
        val lp = GridLayout.LayoutParams()
        lp.width = 0
        lp.height = dp(112)
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
        lp.setMargins(dp(6), dp(6), dp(6), dp(6))
        grid.addView(b, lp)
    }

    private fun handleTile(id: String) {
        when (id) {
            "excel" -> createExcelDocument()
            "google" -> showGoogleUrlDialog()
            "dictate" -> toggleDictation()
            "arrival" -> writeChecked("SITE_ARRIVAL", "Príchod na stavbu / miesto")
            "inspection" -> writeChecked("INSPECTION", "Obhliadka / kontrola")
            "measurement" -> writeChecked("MEASUREMENT", "Meranie / zameranie")
            "phone" -> writeChecked("PHONE_CALL", "Telefonát / komunikácia")
            "departure" -> writeChecked("SITE_DEPARTURE", "Odchod zo stavby / miesta")
            "note" -> writeChecked("MANUAL_NOTE", "Vlastná poznámka")
            "gps" -> writeChecked("GPS_CHECK", "Rýchly GPS zápis")
            "photo" -> openCameraChecked()
            "rebuild" -> {
                val ok = ManualLogStore.rebuildLocalXlsx(this)
                ManualLogStore.exportToConfiguredDocument(this)
                Toast.makeText(this, if (ok) "Excel obnovený." else "Excel sa nepodarilo obnoviť.", Toast.LENGTH_SHORT).show()
                safeRefreshStatus()
            }
            "share" -> shareExcel()
        }
    }

    private fun loadOrder(): MutableList<String> {
        val saved = getSharedPreferences("field_manual_logger", MODE_PRIVATE).getString("tile_order", null)
        if (saved.isNullOrBlank()) return defaultOrder.toMutableList()
        val list = saved.split(",").filter { tiles.containsKey(it) }.toMutableList()
        defaultOrder.forEach { if (!list.contains(it)) list.add(it) }
        return list
    }

    private fun saveOrder(order: List<String>) {
        getSharedPreferences("field_manual_logger", MODE_PRIVATE).edit().putString("tile_order", order.joinToString(",")).apply()
    }

    private fun swapTiles(from: String, to: String) {
        val order = loadOrder()
        val i = order.indexOf(from)
        val j = order.indexOf(to)
        if (i >= 0 && j >= 0) {
            val tmp = order[i]
            order[i] = order[j]
            order[j] = tmp
            saveOrder(order)
            buildUi()
        }
    }

    private fun full(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun saveTopFields() {
        getSharedPreferences("field_manual_logger", MODE_PRIVATE).edit()
            .putString("last_lokalita", lokalitaEdit.text?.toString() ?: "")
            .putString("last_miesto", miestoEdit.text?.toString() ?: "")
            .apply()
    }

    private fun loadSavedLokalita(): String = getSharedPreferences("field_manual_logger", MODE_PRIVATE).getString("last_lokalita", "") ?: ""
    private fun loadSavedMiesto(): String = getSharedPreferences("field_manual_logger", MODE_PRIVATE).getString("last_miesto", "") ?: ""

    private data class FormData(val lokalita: String, val miesto: String, val note: String)

    private fun readRequiredForm(): FormData? {
        val lokalita = lokalitaEdit.text?.toString()?.trim() ?: ""
        val miesto = miestoEdit.text?.toString()?.trim() ?: ""
        val note = noteEdit.text?.toString()?.trim() ?: ""
        if (lokalita.isBlank()) {
            lokalitaEdit.requestFocus()
            Toast.makeText(this, "Vyplň Lokalitu.", Toast.LENGTH_SHORT).show()
            return null
        }
        if (miesto.isBlank()) {
            miestoEdit.requestFocus()
            Toast.makeText(this, "Vyplň Miesto.", Toast.LENGTH_SHORT).show()
            return null
        }
        if (note.isBlank()) {
            noteEdit.requestFocus()
            Toast.makeText(this, "Vyplň Poznámku.", Toast.LENGTH_SHORT).show()
            return null
        }
        saveTopFields()
        return FormData(lokalita, miesto, note)
    }

    private fun clearNoteOnly() {
        noteEdit.setText("")
    }

    private fun requestPermissionsIfNeeded() {
        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), reqPerm)
    }

    private fun bestLocation(): Location? {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            lm.getProviders(true).mapNotNull { provider -> try { lm.getLastKnownLocation(provider) } catch (_: Exception) { null } }.maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun writeChecked(eventType: String, title: String) {
        val form = readRequiredForm() ?: return
        writeEvent(eventType, title, form)
    }

    private fun writeEvent(eventType: String, title: String, form: FormData, photoPath: String = "") {
        val entry = ManualLogStore.append(this, eventType, title, form.lokalita, form.miesto, form.note, bestLocation(), photoPath)
        if (entry == null) {
            Toast.makeText(this, "Zápis zlyhal.", Toast.LENGTH_SHORT).show()
            safeRefreshStatus()
            return
        }
        Toast.makeText(this, "Zapísané: $title", Toast.LENGTH_SHORT).show()
        clearNoteOnly()
        GoogleSync.syncAsync(this, entry) { ok, msg ->
            runOnUiThread {
                if (GoogleSync.url(this).isNotBlank()) Toast.makeText(this, if (ok) "Google sync OK" else "Google sync zlyhal: $msg", Toast.LENGTH_SHORT).show()
            }
        }
        safeRefreshStatus()
    }

    private fun safeRefreshStatus() {
        try {
            val local = ManualLogStore.localXlsxFile(this)
            val data = ManualLogStore.dataFile(this)
            val configured = ManualLogStore.configuredDocumentUri(this)
            val gUrl = GoogleSync.url(this)
            statusText.text =
                "Excel v Dokumentoch: ${if (configured != null) "nastavený" else "nenastavený"}\n" +
                "Google sync: ${if (gUrl.isNotBlank()) "nastavený" else "nenastavený"}\n" +
                "Lokálny Excel: ${local.absolutePath}\n" +
                "Veľkosť: ${if (local.exists()) local.length() else 0} B\n" +
                "Dáta: ${data.absolutePath}\n" +
                "Fotky: ${ManualLogStore.photoDir(this).absolutePath}"
        } catch (e: Exception) {
            statusText.text = "Stav sa nepodarilo načítať: ${e.message}"
        }
    }

    private fun createExcelDocument() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_TITLE, "field_manual_log.xlsx")
        startActivityForResult(intent, reqExcelDocument)
    }

    private fun showGoogleUrlDialog() {
        val input = EditText(this)
        input.hint = "Apps Script Web App URL"
        input.setText(GoogleSync.url(this))
        AlertDialog.Builder(this)
            .setTitle("Google Sheets sync")
            .setMessage("Sem vlož URL z Google Apps Script Web App. Priamy Google Sheets edit link nestačí.")
            .setView(input)
            .setPositiveButton("Uložiť") { _, _ ->
                GoogleSync.setUrl(this, input.text.toString())
                Toast.makeText(this, "Google URL uložené.", Toast.LENGTH_SHORT).show()
                safeRefreshStatus()
            }
            .setNegativeButton("Zrušiť", null)
            .show()
    }

    private fun openCameraChecked() {
        val form = readRequiredForm() ?: return
        pendingPhotoLokalita = form.lokalita
        pendingPhotoMiesto = form.miesto
        pendingPhotoNote = form.note
        openCamera()
    }

    private fun openCamera() {
        val f = File(cacheDir, "camera_${ManualLogStore.stamp()}.jpg")
        pendingPhotoFile = f
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try { startActivityForResult(intent, reqPhoto) } catch (e: Exception) { Toast.makeText(this, "Nepodarilo sa otvoriť fotoaparát.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Android framework")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPhoto) {
            val f = pendingPhotoFile
            if (resultCode == RESULT_OK && f != null && f.exists()) {
                val small = compressImage(f)
                writeEvent("PHOTO_NOTE", "Fotodokumentácia", FormData(pendingPhotoLokalita, pendingPhotoMiesto, pendingPhotoNote), small.absolutePath)
                pendingPhotoNote = ""
            } else {
                Toast.makeText(this, "Fotka nebola uložená.", Toast.LENGTH_SHORT).show()
            }
        }
        if (requestCode == reqExcelDocument) {
            if (resultCode == RESULT_OK && data?.data != null) {
                val uri = data.data!!
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
                ManualLogStore.setConfiguredDocumentUri(this, uri)
                val ok = ManualLogStore.exportToConfiguredDocument(this)
                Toast.makeText(this, if (ok) "Excel v Dokumentoch nastavený." else "Excel nastavený, export zatiaľ zlyhal.", Toast.LENGTH_LONG).show()
                safeRefreshStatus()
            }
        }
    }

    private fun compressImage(src: File): File {
        val out = File(ManualLogStore.photoDir(this), "photo_${ManualLogStore.stamp()}_compressed.jpg")
        val bmp = BitmapFactory.decodeFile(src.absolutePath) ?: return src
        val maxSide = 1600
        val scale = minOf(1.0f, maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat())
        val resized = if (scale < 1.0f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
        FileOutputStream(out).use { stream -> resized.compress(Bitmap.CompressFormat.JPEG, 82, stream) }
        if (resized != bmp) resized.recycle()
        bmp.recycle()
        return out
    }

    private fun shareExcel() {
        ManualLogStore.rebuildLocalXlsx(this)
        val f = ManualLogStore.localXlsxFile(this)
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", f)
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        intent.putExtra(Intent.EXTRA_STREAM, uri)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(intent, "Zdieľať Excel"))
    }

    private fun toggleDictation() {
        if (isDictating) {
            stopDictation()
            Toast.makeText(this, "Diktovanie zastavené.", Toast.LENGTH_SHORT).show()
            buildUi()
        } else startDictation()
    }

    private fun startDictation() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqPerm)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Rozpoznávanie reči nie je dostupné.", Toast.LENGTH_LONG).show()
            return
        }
        isDictating = true
        Toast.makeText(this, "Diktovanie spustené.", Toast.LENGTH_SHORT).show()
        buildUi()
        startSpeechRecognizer()
    }

    private fun startSpeechRecognizer() {
        if (!isDictating) return
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { if (isDictating) handler.postDelayed({ startSpeechRecognizer() }, 800) }
            override fun onResults(results: Bundle?) {
                val texts = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = texts?.firstOrNull()?.trim() ?: ""
                if (text.isNotBlank()) appendDictation(text)
                if (isDictating) handler.postDelayed({ startSpeechRecognizer() }, 400)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "sk-SK")
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        try { speechRecognizer?.startListening(intent) } catch (_: Exception) { if (isDictating) handler.postDelayed({ startSpeechRecognizer() }, 1000) }
    }

    private fun appendDictation(text: String) {
        val old = noteEdit.text?.toString() ?: ""
        val sep = if (old.isBlank() || old.endsWith(" ")) "" else " "
        noteEdit.setText(old + sep + text)
        noteEdit.setSelection(noteEdit.text.length)
    }

    private fun stopDictation() {
        isDictating = false
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
    }
}
