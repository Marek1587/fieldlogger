# Field Manual Logger PHOTO DRIVE

## New

- Android app sends compressed photo as Base64 to Google Apps Script.
- Apps Script creates JPG file in Google Drive folder `FieldLoggerPhotos`.
- Google Sheet stores:
  - local_photo_path
  - photo_file_id
  - photo_url
  - photo_filename

## Important

Google Sheets cannot open `/storage/emulated/...` local Android paths.
Those are only paths inside your phone.

To make photos visible from PC / Google Slides:
1. Use `docs/google_apps_script_photo_drive.gs`.
2. Deploy as Web App:
   - Execute as: Me
   - Who has access: Anyone
3. Paste Web App URL into Android app tile `Google URL`.

## Sheet ID

Update `SPREADSHEET_ID` in Apps Script to your native Google Sheet ID.
