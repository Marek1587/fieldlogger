package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectGeometryCorrectionTest {
    private val origin = GeoPoint(48.0, 18.0)

    @Test
    fun `confirmed correction keeps roof wall footprint and user tract in one coordinate frame`() {
        val original = projectionTopology(-2.0)
        val proposed = projectionTopology(-2.1)
        val originalGraph = RoofGraphFactory.fromTopology(original)
        val originalLoop = orderedLocal(original).map { Geometry.toGeo(it, origin) }
        val project = RoofProject(
            polygon = originalLoop.map(GeoPoint::copy).toMutableList(),
            wallFootprint = originalLoop.map(GeoPoint::copy).toMutableList(),
            roofTopology = original,
            roofGraph = originalGraph,
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 0.0,
            wallFootprintParts = mutableListOf(
                WallFootprintPart(
                    id = "user-projection",
                    type = WallFootprintPartType.PROJECTION,
                    polygon = listOf(
                        LocalPoint(0.0, 4.0), LocalPoint(-2.0, 4.0),
                        LocalPoint(-2.0, 8.0), LocalPoint(0.0, 8.0)
                    ).map { Geometry.toGeo(it, origin) }.toMutableList(),
                    source = WallFootprintPartSource.USER
                )
            )
        )
        val preview = RoofSolverPreview(
            original = original,
            proposed = proposed,
            statistics = RoofSolverStatistics(regularizedBoundaryNodes = 2),
            movements = emptyList(),
            issues = emptyList(),
            faces = RoofTopologySolver.extractFaces(proposed)
        )

        val result = ProjectGeometryCorrection.apply(project, preview)

        assertTrue(result.issues.joinToString { it.message }, result.applied)
        val expected = orderedLocal(proposed)
        assertLocalLoopEquals(expected, project.polygon)
        assertLocalLoopEquals(expected, project.wallFootprint)
        assertTrue("Semantic decomposition must already be persisted for immediate IFC export",
            project.wallFootprintPartsSignature.isNotBlank())
        val projection = project.wallFootprintParts.single {
            it.type == WallFootprintPartType.PROJECTION && it.source == WallFootprintPartSource.USER
        }
        val projectionLocal = projection.polygon.map { Geometry.toLocal(it, origin) }
        assertEquals(-2.1, projectionLocal.minOf { it.x }, 0.002)
        assertEquals(0.0, projectionLocal.maxOf { it.x }, 0.002)
    }

    private fun projectionTopology(outerX: Double): RoofTopology {
        val points = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(8.0, 0.0),
            LocalPoint(8.0, 12.0), LocalPoint(0.0, 12.0),
            LocalPoint(0.0, 8.0), LocalPoint(outerX, 8.0),
            LocalPoint(outerX, 4.0), LocalPoint(0.0, 4.0)
        )
        val nodes = points.mapIndexed { index, point ->
            TopologyNode("N$index", point.x, point.y, TopologyNodeType.FOOTPRINT)
        }
        val edges = nodes.indices.map { index ->
            TopologyEdge(
                id = "E$index",
                startNodeId = nodes[index].id,
                endNodeId = nodes[(index + 1) % nodes.size].id,
                type = LineType.EAVE,
                boundary = true
            )
        }
        return RoofTopology(origin, nodes, edges, gridRotationDeg = 0.0)
    }

    private fun orderedLocal(topology: RoofTopology): List<LocalPoint> {
        val byId = topology.nodes.associateBy { it.id }
        return RoofTopologyMigration.orderedBoundary(topology)!!.first.map { id ->
            byId.getValue(id).let { LocalPoint(it.x, it.y) }
        }
    }

    private fun assertLocalLoopEquals(expected: List<LocalPoint>, actual: List<GeoPoint>) {
        val local = actual.map { Geometry.toLocal(it, origin) }
        assertEquals(expected.size, local.size)
        expected.indices.forEach { index ->
            assertEquals(expected[index].x, local[index].x, 0.002)
            assertEquals(expected[index].y, local[index].y, 0.002)
        }
    }
}
