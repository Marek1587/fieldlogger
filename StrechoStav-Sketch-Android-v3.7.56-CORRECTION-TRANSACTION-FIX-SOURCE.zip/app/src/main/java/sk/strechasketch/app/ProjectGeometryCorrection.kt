package sk.strechasketch.app

/**
 * Commits one confirmed outline/internal-line correction as one project-wide XY deformation.
 *
 * A correction is not valid when only RoofGraph moves. The masonry footprint, semantic roof
 * tracts and attached technical objects must follow the same node displacement; otherwise the
 * next 3D/IFC preparation receives mutually inconsistent coordinate owners.
 */
object ProjectGeometryCorrection {
    fun apply(project: RoofProject, preview: RoofSolverPreview): TopologyApplyResult {
        val beforeGraph = RoofGraphFactory.fromTopology(preview.original, project.roofGraph)
        val afterGraph = RoofGraphFactory.fromTopology(preview.proposed, beforeGraph)
        if (!ProjectPlanSynchronizer.apply(project, beforeGraph, afterGraph)) {
            return TopologyApplyResult(
                applied = false,
                issues = listOf(
                    TopologyIssue(
                        code = "PROJECT_PLAN_SYNCHRONIZATION_FAILED",
                        message = "Opravu nemožno bezpečne preniesť do pôdorysu stien a strešných traktov.",
                        severity = TopologyIssueSeverity.ERROR
                    )
                )
            )
        }

        // Persist a fresh semantic decomposition now, not lazily during a later 3D screen.
        // This guarantees that JSON/IFC exported directly after correction contains the same XY.
        WallFootprintSolver.refresh(project, force = true)
        if (!preview.isValid) project.roofTopology = null
        return TopologyApplyResult(true, RoofTopologySolver.validate(afterGraph.toTopology()))
    }
}
