# StrechoStav Sketch 3.7.54

## Rizalit: samostatný stenový solver

`ProjectionWallProfileSolver` sa aktivuje iba v oblasti `WallFootprintPartType.PROJECTION`,
ktorej exponované strany sú tvorené presne jedným čelným `EAVE` a dvoma bočnými `GABLE`.
Podporná rovina sa vyberie z `GraphFace`, ktorý je incidentný k čelnému odkvapu.

Pre body muriva rizalitu potom platí:

```text
wallTopZ = roofPlane.zAt(x, y) - roofShellThickness
```

Táto vetva zámerne obchádza všeobecný `RoofWallProfileSolver`, a teda nevynucuje
globálnu výšku podlažia. Pri neúplnej alebo inej zostave hrán sa špeciálna vetva
neaktivuje a platí doterajší konzervatívny solver.

## Trapézový vikier

- bočné plochy: 60°,
- čelná stena: lichobežník,
- pultová časť a predné výšky sa vždy prepočítajú po zmene sklonu,
- predvolený sklon trapézového, pultového a oblúkového vikiera: 10°,
- strešný plášť vikiera: 150 mm,
- materiál strechy vikiera: antracit zosvetlený o 20 %.
