# StrechoStav Sketch 3.7.49

## Nezávislé sklony pri spoločnom hrebeni

`GableTractSlopeSolver` už nepovažuje predvolený sklon projektu za rovnostný constraint všetkých plôch. Pre každú hranu `RIDGE` s dvoma susednými plochami určí kolmé vzdialenosti k rovnobežným odkvapom. Ak používateľ neurčil konkrétnu plochu, väčší rozpon dostane predvolený sklon a spoločné prevýšenie je:

```text
rise = longerRun * tan(defaultSlope)
otherSlope = atan(rise / otherRun)
```

Obe roviny preto incidujú do toho istého hrebeňa, hoci majú rozdielne sklony.

## Pôvod constraintu

`FaceSlopeConstraint.source` rozlišuje:

- `USER` – hodnota zadaná na konkrétnej ploche,
- `AUTOMATIC_GABLE` – hodnota odvodená zo spoločnej výšky hrebeňa,
- `LEGACY` – hodnota načítaná zo staršieho projektu bez metadáta pôvodu.

Automatické a legacy hodnoty sa po zmene pôdorysu prepočítajú. Jedna používateľská hodnota zostáva riadiaca; protiľahlý sklon sa odvodí. Dve používateľské hodnoty sa zachovajú iba vtedy, keď dávajú rovnaké prevýšenie s toleranciou 1 mm.

## 3D ovládanie

Kóta sklonu používa identitu `roof-slope:<FaceId>` a zobrazuje skutočný sklon danej vyriešenej roviny. Kliknutie na kótu nastavuje iba túto plochu. Predvolený projektový sklon zostáva predvolenou hodnotou pre nové alebo automaticky riešené plochy.

## Regresné pokrytie

Testovací trakt s kolmými rozponmi 7,7 m a 3,6 m overuje:

- presných 40° na dlhšej ploche,
- strmší odvodený sklon kratšej plochy,
- identické prevýšenie na oboch stranách hrebeňa,
- možnosť zvoliť ktorúkoľvek plochu ako používateľský výškový driver,
- zachovanie `AUTOMATIC_GABLE` v JSON.
