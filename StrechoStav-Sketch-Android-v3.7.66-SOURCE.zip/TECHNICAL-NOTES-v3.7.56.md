# StrechoStav Sketch 3.7.56 – konzistentná korekcia projektu

## Príčina chyby z analyzovaného IFC

Náhľad funkcie `Skorigovať` obsahoval správne navrhnuté uzly, ale potvrdenie návrhu aktualizovalo iba strešný polygón, topológiu a `RoofGraph`. Pôdorys muriva, semantické oblasti `WallFootprintPart` a pripojené strešné prvky zostali v pôvodných súradniciach. IFC preto mohlo obsahovať správne vyriešenú strešnú rovinu a zároveň o 50 až 70 mm posunutý rizalit.

## Oprava

Nový `ProjectGeometryCorrection` je jediným vstupným bodom pre potvrdenie korekcie. Z pôvodnej a navrhnutej topológie vytvorí dvojicu grafov a cez `ProjectPlanSynchronizer` prenesie rovnaké posuny identifikovaných uzlov na:

- `RoofProject.polygon`,
- `RoofProject.roofGraph` a `roofTopology`,
- `wallFootprint`,
- polygóny všetkých `wallFootprintParts`,
- polohy pripojených `RoofObject` prvkov.

Po úspešnom prenose sa spustí `WallFootprintSolver.refresh(project, force = true)`. Aktuálna semantická dekompozícia je preto uložená pred JSON/IFC exportom. Ak identita obvodových uzlov neumožňuje deterministický prenos, korekcia sa bezpečne odmietne a projekt sa nezmení.

## Bez maskovania chyby v 3D

Tolerancie `ProjectionWallProfileSolver` boli vrátené na pôvodné prísne hodnoty. Stenový solver už nemá za úlohu tolerovať zastarané súradnice. Konzistencia sa musí zabezpečiť pri potvrdení korekcie, teda ešte pred 3D prípravou, výkazom a IFC exportom.

## Regresné overenie

`ProjectGeometryCorrectionTest` simuluje korekciu rizalitu a kontroluje, že obrys strechy, pôdorys muriva aj používateľom klasifikovaný trakt skončia v zhodných súradniciach. Test presných súradníc z dodaného IFC zároveň kontroluje, že zastaraná poloha traktu neaktivuje špeciálny stenový profil iba vďaka širokej tolerancii.
