# Technické poznámky 3.7.28

## Značka spádu každej plochy

`RoofPlanAnnotationSolver.faceSlopes()` používa vyriešenú rovinu `GraphFace.plane`. Veľkosť sklonu je `atan(sqrt(a²+b²))` a pôdorysný smer nadol je normalizovaný vektor `(-a,-b)`. Pri nulovom gradiente sa zachová smer explicitného `FaceSlopeConstraint`, prípadne stabilný predvolený smer.

`StnRoofPlanRenderer` umiestni šípku a text `SPÁD x,x°` pri ťažisku plochy s bočným odsadením od automatickej výškovej značky. Každá plocha s vyriešenou rovinou tak dostane vlastnú hodnotu.

## Skryté línie na stenách

Strešné hrany majú už v `RoofMeshBuilder` malý geometrický odstup od strešnej plochy, preto dodatočný kladný depth bias nebol potrebný a pri tesných uhloch mohol sprístupniť zadnú líniu cez stenu. Statický `SoftwareDepthRasterizer` teraz kreslí strešné a vnútorné hrany s nulovým biasom.

OpenGL renderer vypína `GL_POLYGON_OFFSET_FILL`. Zadné strešné línie preto neprejdú cez hĺbku fasády; jemná spodná línia fyzického stenového pôdorysu sa samostatne vykreslí s `GL_LEQUAL`.
