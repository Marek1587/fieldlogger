# StrechoStav Sketch 3.7.66 – relačná symetria a úplný strešný plášť

## Jediný reťazec geometrie

Autoritatívny tok je:

`polygon → sémantické trakty → validované antracitové plochy → steny/podbitie/obvod/odvodnenie`

`wallFootprint` a obdĺžniky traktov sú odvodené cache. Podpis `wall-footprint-v4` sa po zmene
obrysu zneplatní a pri otvorení karty Strešné trakty sa dekompozícia vytvorí znova z polygonu.
Kladné bunky sa nezahadzujú ani pri úzkom výstupku. Jeden deterministický hlavný trakt je koreň
hierarchie a deti majú explicitný `hostPartId`.

## XY solver vnútorných línií

Hrebeň už nedostáva jednorazovo vypočítanú konštantu z bounding boxu. V spoločnom celočíselnom
solve platí pre jeho normálovú súradnicu:

`2R = E₁ + E₂`

`R` je hrebeň na 25 mm mriežke a `E₁`, `E₂` sú skutočné protiľahlé podpery obrysu na 50 mm
mriežke. Ak je hrebeň zamknutý, vzťah môže v limite 300 mm posunúť podriadenú odkvapovú stranu.
Cena pohybu chráni poradie hlavný trakt, krídlo, výstupok, výklenok. Voľný koniec nárožia alebo
úžľabia pri obryse dostane v tej istej transakcii väzbu na jeho podpornú hranu; 3D ho už nesnapuje.

## Spoločná výška hrebeňovej siete

`GableTractSlopeSolver` rieši pripojené hrebene po komponentoch. Jedna používateľská kóta sklonu,
alebo inak hlavný trakt, určí spoločný výškový vzostup. Automatický sklon každej podriadenej plochy
sa dopočíta z jej vlastného kolmého rozponu. Výsledok je nezávislý od poradia ID hrán. Plocha s
dvoma neparalelnými hrebeňmi je neplatná a vyžaduje topologické rozdelenie.

## Brána úplnosti 3D

Pred výpočtom rovín sa overí jeden jednoduchý obvod, incidencia 1 plochy na obvodovej a 2 plôch
na deliacej hrane, úplné cykly, nepretínanie, triangulovateľnosť a rovnosť súčtu plôch s plochou
obrysu. Pri chybe sa nevytvorí čiastočný mesh ani aproximačný plášť. `SolvedRoofSurfaceGeometry`
vyžaduje plane-backed vlastníka každej obvodovej hrany; fallback na `GraphNode.z` bol odstránený.

## Overenie

217 jednotkových testov pokrýva aj 8-bodový Z/H pôdorys 852,9775 m², 100 mm relačný posun
odkvapovej podpery, idempotenciu, kolmé hrebene so spoločnou výškou, neprítomnosť druhého 3D
coordinate solvera a odmietnutie neúplného obvodu/plochy. Distribučný zdrojový ZIP neobsahuje
žiadny keystore; debug zostava používa štandardný lokálny podpis Android SDK.
