# StrechoStav Sketch 3.7.47

## Párovaný štítový trakt

`RoofTractSymmetrySolver` spracuje oba konce jedného hrebeňa ako spoločný constraint. Rozdelenie dvoch rovnobežných protiľahlých štítov sa vyjadrí jedným orientovaným pomerom. Ak je rozdiel opraviteľný pohybom najviac 300 mm na kontakt, oba kontakty sa presunú na rovnaký pomer. Pri blízkej symetrii sa použije presná polovica; pri zámerne vyosenom hrebeni sa zachová priemerný spoločný pomer.

Párovanie prebehne pred konzervatívnou magnetizáciou vnútorných línií. Nevytvára nové uzly ani hrany a neposúva skutočné rohy obrysu alebo výklenkov.

## Kompatibilné sklony

`GableTractSlopeSolver` pracuje nad vyriešeným `RoofGraph`. Pre každú dvojicu plôch pri hrebeni určí kolmý pôdorysný rozpon od hrebeňa po príslušný odkvap. Rozdielne rozpony dostanú rozdielne sklony, ale spoločnú výšku hrebeňa. Ak jedna plocha obsahuje explicitný sklon, ostáva normatívny a chýbajúci sklon druhej plochy sa odvodí z rovnakého prevýšenia.

Rovnaký graf a roviny následne používajú interaktívne 3D, statický renderer, PDF, výkaz aj IFC export.
