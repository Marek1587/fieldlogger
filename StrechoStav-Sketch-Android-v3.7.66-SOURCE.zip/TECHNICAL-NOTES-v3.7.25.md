# StrechoStav Sketch 3.7.25 – ponukový rozpočet

Rozpočtová časť PDF bola prerobená podľa dodaného `pdfcreate-rozpocet-kat.php` a vizuálneho referenčného PDF.

## Dátový tok

`RoofProject -> RoofQuantityEngine -> WorkScopeEngine -> BudgetOfferBuilder -> Exporters.pdf`

Rozpočet nevytvára vlastnú geometriu ani vlastné množstvá. Číta rovnaké auditované hodnoty ako karta Rozsah prác. Ručný override množstva zostáva explicitne oddelený od automatickej hodnoty.

## Hlavička

- názov zákazky = `RoofProject.name`,
- objednávateľ a kontaktná osoba = `RoofProject.customer`,
- miesto stavby = `RoofProject.address`,
- kód zákazky je deterministicky odvodený z `RoofProject.id`,
- dátum spracovania a platnosť 180 dní sa generujú pri exporte,
- firemný blok používa údaje StrechoStav z dodanej referencie.

## Položky

`WorkItem` obsahuje stabilné `budgetOrder`, zobrazovaný katalógový kód, rozpočtový názov a špecifikáciu. Interný `code` sa nemení, preto sú staršie projekty a uložené ceny spätne kompatibilné.

## DPH

`RoofProject.budgetVatPercent` má predvolenú hodnotu 23 %, rozsah 0–100 % a ukladá sa do projektového JSON. Starší JSON bez poľa sa načíta s hodnotou 23 %. Úprava v UI používa spoločné numerické koliesko.

## PDF

Položka sa kreslí ako tučný hlavný riadok a zeleno orámovaný riadok špecifikácie. Text sa zalamuje podľa reálnej šírky fontu. Strany sa rozdeľujú deterministicky a súčty sa nikdy nevykreslia cez položky.

## Overenie

- `:app:testDebugUnitTest`: 99/99 PASS,
- vizuálny A4 náhľad bol vyrenderovaný do PNG pri 150 DPI a skontrolovaný bez prekrývania alebo odrezania.
