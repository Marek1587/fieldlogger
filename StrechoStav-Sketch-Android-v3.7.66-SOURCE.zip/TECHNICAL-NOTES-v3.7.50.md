# StrechoStav Sketch 3.7.50 – WallFootprint a strešné trakty

## Účel vrstvy

`WallFootprintPart` je významová vrstva nad fyzickým pôdorysom muriva. Nemení body obrysu ani strešnú topológiu. Poskytuje solverom chýbajúci kontext, či konkrétna oblasť predstavuje:

- hlavný strešný trakt,
- výstupok alebo rizalit,
- výklenok,
- samostatné krídlo,
- nadstavbu alebo vikier.

## Deterministický automatický návrh

`WallFootprintSolver` pracuje v projektovej mriežke `MetricPlanGrid` s krokom 100 mm. Ortogonálny pôdorys rozdelí na maximálne obdĺžnikové oblasti, zvolí dominantný hlavný trakt a klasifikuje vedľajšie oblasti podľa veľkosti a pomeru strán. Prázdne oblasti dotýkajúce sa stavby na dvoch osiach navrhne ako výklenky. Vikiere, strojovne a šachty sa pridávajú ako nadstavby.

Identita časti je deterministický SHA-256 odtlačok jej mriežkových hraníc. Ručné rozhodnutie používateľa má `source = USER` a po malej korekcii obrysu sa prenesie na najbližšiu zodpovedajúcu oblasť. Úplný reset ručných rozhodnutí sa vykoná iba explicitným tlačidlom `Automatický návrh`.

## Napojenie na výpočty

Spoločný `WallFootprintSolver.Context` používajú:

- korekcia obrysu a vnútorných línií,
- párovanie protiľahlých štítov,
- odvodenie nezávislých sklonov pri spoločnom hrebeni,
- `Roof3DPreparation`, a tým aj OpenGL 3D, PDF, výkaz a IFC.

Hrebeň, štítové kontakty a protiľahlé odkvapy sa párujú iba v tej istej štrukturálnej časti. Výklenok sa nepovažuje za samostatnú strešnú plochu, ale ostáva explicitnou informáciou pre profil muriva.

## Dáta a migrácia

Projektová JSON schéma 10 ukladá `wall_footprint_parts` a `wall_footprint_parts_signature`. Staršie projekty sa načítajú s prázdnou vrstvou a návrh sa vytvorí pri prvom otvorení karty. Nové údaje sú súčasťou kanonického JSON a IFC round-trip payloadu.
