# StrechoStav Sketch 3.7.64 – immutable authored topology and one solved envelope

## Correction transaction

The internal-line solver owns coordinates only. Its preview and commit preserve the exact node and edge inventory, endpoint connections, line types, locks, provenance, notes, legacy boundary semantics and relative order of existing user lines. Any structural mutation rejects and rolls back the whole transaction. A preview is also tied to the exact project revision and workspace that created it.

Crossings, T-junctions and boundary subdivisions required for face walking are produced only by `Roof3DPreparation` in a disposable incidence graph. That graph is shared by 3D, PDF, quantities and IFC but is never persisted.

## Geometry ownership

The dependency chain is:

`footprint → authored topology → solved anthracite faces → boundary/soffit/buildup/walls/drainage`

`SolvedRoofSurfaceGeometry` selects one deterministic owner for every visible boundary section. Structural overlap follows `main tract > wing > projection > recess`, then deterministic geometric tie-breakers. The same solved plane supplies the roof skin, lower buildup face, wall top and gutter elevation.

The black roof outline has its own `roofBoundaryEdges` mesh buffer and is populated only from the solved anthracite surface boundary. Gutters, flashings and construction details remain in the subordinate detail-edge buffer.

Flat soffits use the measured overhang of each boundary section. Adjacent eave/gable pieces resolve their shared corner once, so top, bottom, flat and wall-side vertices remain continuous even when local overhang depths differ.

ATTIC parapet base/crown geometry, plan height markers, chimney clearances and machine-room/shaft references also consume solved boundary sections or solved face-edge segments. Drainage includes exposed `EAVE`, `PULT`, `LOW_EDGE` and `ELEVATED_LOW_EDGE` roles while excluding `ATTIC`, `GABLE` and `WALL_END`.

## Stable object references

Objects created or moved in the disposable 3D graph are mapped back to authored face and edge IDs before saving. Runtime `::virtual-*` and `-segment-*` identifiers cannot enter their persisted geometric attachment fields. Existing projects containing such attachment references are accepted and resolve to the corresponding authored edge when edited.

## PDF rendering profile

PDF export builds one shared `RoofMesh` for all four views and opts into `PDF_PHOTOREALISTIC`. This deterministic CPU profile adds model-space material variation, ACES-inspired filmic tone mapping, soft ambient/contact occlusion, a restrained studio background gradient and lighter detail edges. `TECHNICAL` remains the default for the live application and catalogue previews.

## Verification

Regression coverage includes immutable solver transactions, stale-preview rejection, topology-cache compatibility, component ownership, solved internal-edge elevations, canonical wall profiles, local soffit depths, shared soffit corners, stable authored object references, black-boundary separation and both bitmap render profiles.
