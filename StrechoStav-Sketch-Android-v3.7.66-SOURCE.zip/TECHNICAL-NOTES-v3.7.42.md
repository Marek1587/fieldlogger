# StrechoStav Sketch 3.7.42

## Prienik sedloveho a valboveho vikiera

V lokalnych osiach hostitelskej plochy je `u` rovnobezne s odkvapom a `v` smeruje hore po spade. Hostitelska rovina je preto na kazdom generatore s konstantnym `u` linearna funkcia `H(u,v)`.

Solver najprv vytvori rovinnu plochu vikiera s konstantnym sklonom. Pre kazdy jej charakteristicky bod potom riesi rovnicu:

`H(u, v_intersection) = Z_dormer_plane(u)`

Vysledkom nie je spolocna umela zadna hlbka, ale skutocna priesecnicova hrana dvoch rovin.

- sedlovy vikier: dva planarne lichobezniky,
- valbovy vikier: predny trojuholnik a dva planarne lichobezniky,
- otvor hostitelskej plochy: patbodovy polygon vedeny uzlabiami ku koncu hrebena,
- bocne murivo: trojuholniky konciace presne na hostitelskom plasti.

Rovnaky polygon sa pouziva na orezanie 3D siete, vypocet odratanej plochy a exportne datove vrstvy.
