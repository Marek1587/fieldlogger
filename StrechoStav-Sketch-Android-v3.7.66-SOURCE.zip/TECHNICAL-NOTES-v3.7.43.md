# StrechoStav Sketch 3.7.43 - profil muriva pod suvislou strechou

## Pricina

Stresne plochy boli vytvarane z vyrieseneho `RoofGraph`, ale steny sa extrudovali po
konstantnu hodnotu `RoofProject.wallHeightM`. V ustupenom vyklenku preto spravne
pokračujuca stresna rovina zostala nad obdlznikovou stenou a medzeru uzatvaral iba
pomocny pas materialu podbitia.

## Riesenie

`RoofWallProfileSolver` pracuje vyhradne s uz vyriesenymi `GraphFace.plane` a nemeni
ulozeny podorys ani topologiu strechy. Kazdy fyzicky segment steny rozdeli v presnych
prienikoch s hranami `RoofGraph`. Pre kazdy interval urci kryciu stresnu plochu a
vypocita hornu hranu muriva:

```text
z_muriva(x,y) = max(wallHeightM, z_strechy(x,y) - 0.18 m)
```

Hodnota 0,18 m je spolocna fyzicka hrubka plasta z `RoofOverhangSolver`. Pri prechode
cez hreben, narozie alebo uzlabie vznikne iba odvodený profilovy bod. Fyzicky obrys
steny ani jej viditelne hranove ciary sa nerozdeluju.

## Spolocny vystup

Profil sa aplikuje pri tvorbe `RoofMesh`, preto ho bez samostatneho prepocitu pouziva:

- `GLSurfaceView` / OpenGL ES 3.0,
- obrazkovy nahlad v zozname projektov,
- staticky Kotlin bitmapovy renderer,
- 3D pohlady v PDF.

## Testy

`RoofWallProfileSolverTest` kontroluje:

1. rozdielne vysky koncov ustupenej steny pod jednou suvislou rovinou,
2. deterministicky vrchol profilu v prieniku steny s hrebenom,
3. zachovanie jedneho fyzickeho segmentu fasady bez solverom vytvoreneho zvisleho svu.
