# StrechoStav Sketch 3.7.41

## Vikierovy solver

- Zadny sev vikiera je topologicky viazany na `GraphFace.plane`; jeho vrcholy pouzivaju priamo `RoofPlane.zAt(x, y)`.
- Trapezovy vikier sa sklada z ploch `roof-main`, `roof-side-left` a `roof-side-right`.
- Presah vikiera je domenovy parameter `RoofObject.dormerOverhangMm`, nie vizualny posun renderera.
- Predvolena hodnota je 250 mm a stara projektova schema ju pri migracii doplni bez zmeny existujucej geometrie muriva.
- Renderer, bitmapovy export, JSON a IFC citaju rovnaky parameter z vyrieseneho domenoveho modelu.
