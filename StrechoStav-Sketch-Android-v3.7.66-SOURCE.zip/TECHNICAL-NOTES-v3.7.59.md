# StrechoStav Sketch 3.7.59

## Spodný obal strechy pri výklenkoch

Strešná skladba, 200 mm rovná časť podbitia, pokračovanie podbitia po sklone a čelná hrana teraz používajú spoločnú výškovú obálku. Výška sa vždy vyhodnocuje z vyriešených rovín strechy `z = a*x + b*y + c`.

V konkávnom alebo spoločnom rohu sa vyberá nižšia z incidentných rovín. Priemerovanie rovín by vytvorilo neexistujúcu výšku medzi plochami a spôsobovalo plávajúce podbitie.

## Žľab

Stred polkruhového žľabu sa odvodzuje z tej istej vyriešenej roviny ako odkvap. Horný okraj profilu je 30 mm pod strešnou hranou; montážny spád 4 mm/m sa od tejto výšky odpočítava smerom ku zvodu.

