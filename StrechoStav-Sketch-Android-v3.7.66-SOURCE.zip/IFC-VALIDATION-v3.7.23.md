# IFC export validation report – StrechoStav Sketch 3.7.23

## Výsledok

- IFC schema deklarovaná vo výstupe: `IFC4X3_ADD2`
- STEP syntax, interná kontrola: `PASS`
- interná kontrola GUID, STEP referencií, FaceId a finite súradníc: `PASS`
- unit/regression testy: `PASS` – 95 testov, 0 failures, 0 errors, 0 skipped
- externá buildingSMART schema validation: `NOT EXECUTED`
- externá buildingSMART normative rules validation: `NOT EXECUTED`

Externé overenie nebolo predstierané. Golden fixture `app/src/test/resources/ifc/simple_gable.ifc` je pripravený na manuálne nahratie do buildingSMART IFC Validation Service.

## Aktuálny štandardný IFC subset

- priestorová štruktúra: `IfcProject`, `IfcSite`, `IfcBuilding`, `IfcBuildingStorey`
- strecha: `IfcRoof` a jeden `IfcSlab` s `PredefinedType=ROOF` pre každý `GraphFace`
- geometria: `IfcCartesianPointList3D`, `IfcIndexedPolygonalFace`, `IfcIndexedPolygonalFaceWithVoids`, `IfcPolygonalFaceSet`, `IfcShapeRepresentation`
- otvory a výplne: `IfcOpeningElement`, `IfcRelVoidsElement`, `IfcRelFillsElement`
- objekty: `IfcWindow`, `IfcChimney`, `IfcBuildingElementProxy`
- vzťahy: `IfcRelAggregates`, `IfcRelContainedInSpatialStructure`, `IfcRelDefinesByProperties`
- quantities: `IfcElementQuantity`, `IfcQuantityArea`, `IfcQuantityLength`
- vlastnosti: `IfcPropertySet`, `IfcPropertySingleValue`

## Známe obmedzenia prvej verzie

- model používa lokálny engineering coordinate system; WGS84 origin je uložený ako metadata, ale nevytvára sa falošný `IfcProjectedCRS` ani `IfcMapConversion`,
- materiálová skladba, hrúbka a vrstvy sa nevymýšľajú; strešné plochy sú LOD100 surface/tessellation,
- plne geometrické sú strešné plochy a otvory z `GraphFace.holeNodeIdLoops`; komín a strešné okno majú štandardnú IFC sémantiku a raw vlastnosti, no zatiaľ nemajú samostatnú LOD100 objemovú IFC geometriu,
- strešné okno bez zodpovedajúceho otvoru v hostiteľskom `GraphFace` dostane sémantický `IfcOpeningElement`, ale povrch dosky sa geometricky vyreže až vtedy, keď je otvor prítomný v `holeNodeIdLoops`,
- `HATCH`, `VENT`, `DRAIN`, `DOWNSPOUT`, `HEIGHT_MARK` a `SLOPE_MARK` používajú štandardný fallback `IfcBuildingElementProxy`; úplné dáta zostávajú v `StrechoStav_Object` a kanonickom payload-e,
- export sa neoznačuje ako certifikovaný MVD ani Reference View.
