# StrechoStav Sketch 3.7.60

## Hierarchia strešných traktov

Parametrický editor používa explicitné poradie vlastníctva geometrie:

1. hlavný strešný trakt,
2. samostatné krídlo,
3. výstupok alebo rizalit,
4. výklenok,
5. nadstavba alebo vikier.

Pri zmene rozmeru nižšie postavenej časti zostávajú uzly vyššej časti pevné. Uzol na spoločnej hranici sa smie posunúť iba po dotyčnici chránenej hrany; pohyb kolmo do hlavného traktu je zakázaný. Protiľahlá hrana sa hľadá najprv v tej istej sémantickej oblasti, nie globálne v celom pôdoryse.

## Steny výstupkov

Výstupok s odkvapom a dvoma štítovými bokmi používa samostatné pravidlo profilu steny. Predná stena môže zostať vodorovná pod odkvapom, kým bočné návratové steny sú lichobežníkové a ich horná hrana sleduje vyriešenú strešnú rovinu `z = a*x + b*y + c`. Pravidlo toleruje stavebné odsadenie muriva od sémantickej hranice do 650 mm bez toho, aby menilo rovinu hlavného traktu.

## Regresná ochrana

Testy overujú, že:

- výstupok nemôže zmeniť žiadny uzol hlavného traktu,
- cieľová kóta výstupku sa napriek ochrane dosiahne,
- vlastníctvo v prekrytí rešpektuje poradie hlavný trakt → krídlo → výstupok → výklenok,
- odsadená bočná stena výstupku preberá výšku zo strešnej roviny.
