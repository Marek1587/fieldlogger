# StrechoStav Sketch 3.7.46 – symetria strešného traktu

## Príčina chyby

Pôvodná korekcia obrysu vyrovnala nosné priamky, ale kolineárny bod, v ktorom sa hrebeň pripája na rozdelenú štítovú stranu, ponechala na zameranej polohe. Pri rozdiele niekoľkých centimetrov medzi dvoma polovicami štítu preto hrebeň sledoval hlučný bod z ortofotomapy namiesto osi fyzického strešného traktu. Globálne ťažisko konkávneho pôdorysu navyše nie je správnou osou strechy nad výklenkom.

## Deterministické pravidlo

`RoofTractSymmetrySolver` zasahuje iba vtedy, keď sú splnené všetky podmienky:

1. bod leží na fyzicky rovnej obvodovej strane (uhlová tolerancia 3°),
2. v bode alebo najviac 350 mm od neho končí existujúci hrebeň,
3. medzi dvoma skutočnými rohmi strany možno bod vycentrovať posunom najviac 300 mm,
4. rozdiel dĺžok oboch polovíc je najviac 600 mm,
5. bod ani pripojená línia nie sú uzamknuté.

Ak podmienky neplatia, geometria ostáva bez zmeny. Solver nevytvára nové uzly ani hrany, neposúva rohy výklenku a nemení zámerne trojuholníkový alebo výrazne asymetrický pôdorys.

## Spoločná dátová cesta

Korekcia sa vykoná v `RoofTopologySolver.solveOutline()` pre používateľsky potvrdenú opravu a tiež v `Roof3DPreparation.prepare()` pre odvodený model. Preto 3D, statický Kotlin renderer, PDF, výkaz, IFC a náhľady používajú rovnakú os traktu a rovnaký vyriešený `RoofGraph`.

## Regresné krytie

- mierne rozdielne polovice štítu sa vycentrujú,
- hrebeň a obvodový kontakt ostanú v jednom uzle,
- konkávny výklenok sa neposunie,
- zámerná asymetria vyžadujúca viac ako 300 mm sa zachová,
- výsledný konkávny model vytvorí dve platné plochy bez blokujúcej chyby rovinného solvera.
