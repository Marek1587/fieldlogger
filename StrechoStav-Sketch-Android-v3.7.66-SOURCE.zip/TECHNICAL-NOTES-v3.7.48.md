# StrechoStav Sketch 3.7.48

## Neviditeľná metrická mriežka

`MetricPlanGrid` zavádza jediný projektový raster s krokom 0,10 m v oboch osiach. Raster existuje v lokálnom inžinierskom súradnicovom systéme strechy; nie je odvodený z pixelov displeja ani z mapovej dlaždice. Zoom, pan a otočenie podkladu preto nemenia jeho fyzický krok ani už uložené uzly.

Pri prvom vytvorení obrysu sa uloží geografický origin a natočenie hlavnej osi stavby. Tieto údaje sú súčasťou `RoofProject`, `RoofTopology` aj `RoofGraph` a serializujú sa do JSON. Starší projekt bez rámca ho deterministicky vytvorí z najdlhšej obvodovej hrany.

## Jednotná geometrická cesta

Na priesečník mriežky sa kvantizujú iba konštrukčné XY uzly:

- body obrysu a výsledok kreslenia voľnou rukou,
- konce vnútorných strešných línií,
- presun, rozdelenie a vloženie uzla,
- magnetické prichytenie a korekčný solver,
- operácie `RoofGraph` a parametrické pôdorysné zmeny,
- synchronizovaný pôdorys stien.

Výšky `z`, strešné objekty a ich špecializované polohové pravidlá zostávajú spojité; mriežka nemení solver rovín `z = a*x + b*y + c`.

## Stabilita solvera

Korekcia používa uložené natočenie mriežky ako normatívnu základnú os. Podperné línie 0°/90° a ich kotvy sa riešia v tom istom rámci. Rám sa po zmene dĺžky najdlhšej hrany už neodvodzuje znova, takže parametrická úprava nemôže spôsobiť skrytú rotáciu alebo drift existujúcich uzlov.

Projektový JSON má schému 9; dekódovanie starších schém zostáva spätne kompatibilné.
