# Technické poznámky 3.7.30

## Priestorové kóty presúvaného prvku

- `RoofObjectPlacement` vracia referenčný roh, oba osové konce a polohu prvku v lokálnych BIM súradniciach.
- Po začatí presunu sa index referenčného rohu uzamkne; počas jedného gesta preto nepreskakuje medzi rohmi.
- `Roof3DRenderer.projectObjectOffset()` vynesie všetky body na rovinu priradenej plochy `z = a*x + b*y + c` a až potom ich premietne aktuálnou OpenGL kamerou.
- Overlay počas presunu vykresľuje iba červené X/Y kóty, pomocné svedkovacie čiary a označenie referenčného rohu. Ostatné kóty sú dočasne skryté.

## Polohové kóty v technickom pôdoryse

- `RoofObjectPlanDimensionSolver` vytvára pre každý podporovaný strešný prvok dve deterministické kóty od jedného najbližšieho rohu.
- Kóty používajú vonkajšie normály `PlanDimensionPlacementSolver` a tvoria samostatný rad za obvodovými a celkovými kótami.
- Podporované prvky: komín, strešné okno, výlez a prestup.
- Regresné testy kontrolujú stabilitu zvoleného rohu, osové vzdialenosti aj to, že úsečky zostávajú mimo pôdorysu.
