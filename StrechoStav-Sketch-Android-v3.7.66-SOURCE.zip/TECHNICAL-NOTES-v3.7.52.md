# StrechoStav Sketch 3.7.52 – profil stien rizalitu podľa strešnej roviny

## Príčina chyby

`RoofWallProfileSolver` už pred touto verziou vyhodnocoval strešnú rovinu nad každým úsekom fyzického `WallFootprint`. Výsledná výška však bola vždy orezaná výrazom `max(wallHeightM, roofUndersideZ)`. To je správna ochrana bežnej obvodovej steny, ale pri rizalite znemožňovala, aby sa murivo smerom od hlavného traktu postupne znížilo pod globálnu výšku podlažia.

## Významová podmienka

Solver dostáva spoločný `WallFootprintSolver.Context`. Pre každý interval fyzickej steny určí, v ktorej stavebnej časti leží jeho stred:

- `PROJECTION` povoľuje hornú hranu muriva odvodiť priamo z podhľadu strešnej roviny,
- `MAIN_TRACT`, `SEPARATE_WING`, `SUPERSTRUCTURE` a neklasifikované staršie projekty zachovávajú minimum `wallHeightM`,
- `RECESS` nie je samostatná štrukturálna plocha muriva a nemení toto pravidlo.

Výška rizalitu je teda:

`wallTopZ = a*x + b*y + c - roofShellThickness`

so spodnou fyzickou poistkou 50 mm nad základňou. Nejde o nový strešný solver ani o samostatnú aproximáciu. Používa sa rovina z už vyriešeného `RoofGraph`.

## Spojitosť

Profil sa stále delí iba v skutočných priesečníkoch s hranami strešných plôch. Na zhodnom bode dvoch intervalov sa vyberie konzervatívna nižšia hodnota, takže nevznikne zvislá štrbina. Na pripojení rizalitu má jeho význam prednosť pred prekrývajúcim sa obdĺžnikom hlavného traktu, a preto sa lineárny pokles začne presne v spoločnom styku.

## Renderery

Výsledok zostáva súčasťou spoločného `RoofMesh`. Rovnaké murivo preto používa:

- interaktívny `GLSurfaceView` / OpenGL ES 3.0,
- statický Kotlin bitmapový renderer,
- 3D pohľady v PDF,
- náhľady projektu.

Geometria strešných plôch, výkaz, uložený projekt ani IFC strešné plochy sa touto prezentačnou deriváciou nemenia.
