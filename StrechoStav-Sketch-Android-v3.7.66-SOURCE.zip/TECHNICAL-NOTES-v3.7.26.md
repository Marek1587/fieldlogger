# StrechoStav Sketch 3.7.26 – situácia osadenia stavby

## Dátový tok

Prvá strana PDF používa priamo `RoofProject.polygon` a ZBGIS dlaždice uložené v:

```text
filesDir/project-map-cache/<project-id>/tiles-v3/zbgis-ortho/<zoom>/<x>/<y>.tile
```

Export nevolá nový mapový ani geometrický solver. Súradnice obrysu sa premietajú rovnakou Web Mercator transformáciou ako editor a dlaždicová mapa.

## Výrez

`SituationMapLayout` vypočíta severne orientovaný a deterministický viewport iba z geometrie obrysu. Aktuálne posunutie mapy v editore preto nemôže zmeniť polohu situácie v PDF. Celý obrys zostáva vo výreze aj pri neštandardne veľkom projekte; digitálne zväčšenie je obmedzené tak, aby sa zbytočne neznižovala čitateľnosť okolia.

## Vykreslenie

`SituationMapRenderer` skladá tlačovú bitmapu z existujúcej projektovej cache. Nad mapu kreslí iba:

- jemnú polopriehľadnú zelenú výplň,
- diagonálne šrafovanie,
- dvojitý kontrastný obvod polygonu.

Kóty, uzly, vnútorné strešné línie, objekty a technické popisy sa na situačnej strane nevykresľujú. Povinná atribúcia ortofotomapy zostáva pod mapovým rámom.

## Offline správanie

PDF export nevykonáva sieťový request na hlavnom Android vlákne. Použije všetky dostupné dlaždice, ktoré používateľ predtým zobrazil v editore. Chýbajúce dlaždice sa zobrazia neutrálnym podkladom a nepoškodia vytvorenie zvyšku dokumentu.
