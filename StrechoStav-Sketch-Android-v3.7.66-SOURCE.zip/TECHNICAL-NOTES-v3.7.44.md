# StrechoStav Sketch 3.7.44 - stabilná 3D kamera a spätná väzba kóty

## Kamera nezávislá od prepočtu geometrie

`Roof3DView` poskytuje explicitný `Roof3DCameraState` so stavom orbitu, náklonu,
priblíženia a posunu. `MainActivity.show3D()` pred prepočtom parametrického modelu
uloží stav existujúceho `GLSurfaceView` a po vytvorení nového rendereru ho obnoví.
Zmena rozmeru preto nemení používateľom nastavený pohľad; predvolenú kameru naďalej
aktivuje iba tlačidlo `Reset` alebo dvojité ťuknutie.

## Dvojsekundové potvrdenie zmenenej kóty

Kliknutá 3D kóta odovzdá svoje stabilné `dimensionId` spoločnému dialógu kolieska.
Po potvrdení hodnoty sa ID prenesie aj cez prípadné znovuvytvorenie 3D obrazovky.
`Roof3DDimensionOverlay` na 2 000 ms vykreslí kótovaciu čiaru, vynášacie čiary,
koncové značky a štítok žltou farbou. Časovanie používa monotónny
`SystemClock.uptimeMillis()`, takže zmena systémového času nemôže zvýraznenie predĺžiť
ani predčasne ukončiť.
