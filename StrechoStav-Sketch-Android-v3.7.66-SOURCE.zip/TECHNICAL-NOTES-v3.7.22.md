# StrechoStav Sketch 3.7.22 – poloha strešných okien a výlezov

## Výšková podmienka

Horná hrana otvoru má absolútnu výšku:

`z_head = wallHeightM + 2,10 m`

Hostiteľská strešná plocha je určená rovinou:

`z = a*x + b*y + c`

Vektor `(a,b)` smeruje v pôdoryse nahor po spáde. Kolmý vektor `(b,-a)` je smer vrstevnice, teda smer rovnobežný s odkvapom.

## Skutočná dĺžka po šikmine

Pri gradiente `g = sqrt(a²+b²)` a zadanej dĺžke otvoru `L`:

- pôdorysná dĺžka: `Lxy = L / sqrt(1+g²)`,
- výškový rozdiel: `Lz = L*g / sqrt(1+g²)`,
- výška stredu: `z_center = z_head - Lz/2`.

Tým zostáva kóta dĺžky fyzickou dĺžkou po strešnej ploche a horná hrana je presne 2 100 mm nad podlahou.

## Interakcia

Pohybový vektor dotyku sa skalárne premietne do vrstevnicového smeru. Zložka pozdĺž gradientu sa zahodí. Po každej zmene dĺžky sa poloha stredu nanovo vyrieši. Horný aj spodný stred otvoru musia zostať vo vnútri hostiteľského `FaceId`.

## LOD100 geometria

- vonkajší obdĺžnik tvorí nízky súvislý rám,
- vnútorný obdĺžnik tvorí mierne zapustené sklo,
- bez kovania, pántov, tesnení a výrobného členenia,
- samostatné materiály rámu a skla fungujú v OpenGL ES 3.0 aj v statickom bitmapovom/PDF rendereri.

Regresná sada obsahuje 86 úspešných testov.
