# StrechoStav Sketch 3.7.57 – uzamknutý pôdorys

## Vlastníctvo geometrie

- Karta **1 Obrys** je jediná bežná korekcia, ktorá smie meniť fyzický obvod budovy.
- Obvod používa metrickú mriežku 50 mm.
- Karta **3 Vnútorné línie** pracuje iba s existujúcimi vnútornými uzlami a hranami. Obvod, pôdorys muriva a potvrdené oblasti `WallFootprint` zostávajú bitovo zhodné.
- Vnútorné línie používajú samostatnú mriežku 25 mm.
- Strešné trakty sú sémantická vrstva a nesmú deformovať geometriu obvodu.

## 3D príprava

`Roof3DPreparation` už nespúšťa všeobecný topologický solver nad uloženým projektom. Ak existujúci koniec vnútornej línie leží na obvodovej hrane, incidencia sa rozdelí iba vo výslednom odvodenom `RoofGraph`. Projekt, polygon, uložená topológia ani trakty sa nemenia.

Presah strechy je odvodená geometria strešného plášťa. Nezvyšuje, neposúva ani nerozdeľuje pôdorys muriva a nemení jeho horný profil.

## Povolená parametrická zmena

Vedomá zmena pôdorysnej kóty v 3D modeli môže naďalej meniť obvod cez kontrolovaný parametrický solver. Táto operácia je oddelená od korekcie vnútorných línií a od čítacích exportov.

## Overenie

- regresný test zachovania obvodu, pôdorysu muriva a sémantických oblastí po korekcii vnútorných línií,
- regresný test zákazu spätného zápisu virtuálnej incidencie z 3D prípravy,
- úplná sada 169 testov prešla.
