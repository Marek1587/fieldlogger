# STN 01 3420 – rozsah implementácie výkresu strechy

Zdroj preverenia: https://kniznica.npremstav.sk/upload/1755456784_404.pdf

Implementácia technického pôdorysu používa najmä články 5.14.1 až 5.14.4 a tabuľku 2:

- viditeľný obrys hotovej strechy a konštrukcie vystupujúce nad strechu sú kreslené hrubou súvislou čiarou,
- priesečnice strešných rovín sú kreslené hrubou súvislou čiarou,
- strešné okná a výlezy majú hrubý súvislý obrys a tenké súvislé uhlopriečky,
- prestup, vetracie zariadenie, strešná vpusť a výtok do zvodu používajú rozdielne značky z tabuľky 2,
- každá vyriešená plocha používa smerovú šípku a číselnú hodnotu sklonu,
- hrebeň, odkvap, horná hrana atiky, komín a vložené výškové body používajú normový zápis výškovej úrovne,
- rozmerové a polohové kóty sú vedené mimo obrysu výkresu,
- pri natočení pôdorysu podľa najdlhšej strany je vo výkrese zachovaný smer severu.

Zdrojová norma nie je vložená do aplikácie ani do distribučného ZIP súboru. Tento dokument eviduje iba implementovaný rozsah a odkaz na použitý zdroj.
