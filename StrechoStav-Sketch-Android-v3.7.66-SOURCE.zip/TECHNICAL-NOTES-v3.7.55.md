# StrechoStav Sketch 3.7.55

## Oprava profilu muriva rizalitu podľa terénneho IFC

Export IFC z verzie 3.7.54 potvrdil, že solved strešná rovina bola správna, ale
`ProjectionWallProfileSolver` sa vôbec neaktivoval. Významová oblasť rizalitu opisuje
pôdorys muriva, zatiaľ čo obvodové hrany `RoofGraph` opisujú fyzický okraj strechy s
presahom. V dodanom projekte boli medzi týmito reprezentáciami normálové odstupy
200 mm a 300 mm; pôvodná tolerancia 180 mm preto zamietla predný odkvap aj oba štíty.

Po následnej korekcii na projektovej mriežke sa navyše aktuálny stenový obrys od
uloženej významovej oblasti líšil približne o 50 až 70 mm. Takmer nulová tolerancia
testu príslušnosti potom priradila rizalitu iba časť jeho muriva.

Verzia 3.7.55 preto:

- porovnáva obvod rizalitu s hranami fyzickej strechy v tolerancii zahŕňajúcej bežný
  presah a jednu bunku korekcie,
- zachováva prísnu kontrolu rovnobežnosti a presnej zostavy `EAVE + 2× GABLE`,
- považuje pás do 120 mm okolo používateľsky potvrdenej oblasti za ten istý rizalit,
- pre všetky tri exponované steny používa priamo
  `wallTopZ = roofPlane.zAt(x, y) - roofShellThickness`,
- v tejto vetve nevynucuje globálnu výšku podlažia.

Regresný test rekonštruuje súradnice z dodaného IFC a overuje konkrétne výšky oboch
koncov prednej aj bočných stien. Tým chráni chybu, pri ktorej sa strešná plocha javila
ako nadvihnutá nad obdĺžnikovým murivom rizalitu.
