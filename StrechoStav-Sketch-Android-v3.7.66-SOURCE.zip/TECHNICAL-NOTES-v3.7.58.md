# StrechoStav Sketch 3.7.58 – metrický obrys a spoločné uzly

## Jednotná metrika

`Geometry.distanceM` teraz meria vzdialenosť cez rovnakú lokálnu Web Mercator rovinu ako `Geometry.toLocal`, `Geometry.toGeo` a `MetricPlanGrid`. Editor, solver, obvod, plocha a exporty preto nepoužívajú dva rozdielne polomery Zeme. Po potvrdení 50 mm mriežky sa kóta zobrazuje presne ako násobok 50 mm.

## Incidencia na karte obrysu

`RoofTopologySolver.solveOutline` po korekcii fyzického obrysu vykoná samostatný incidenčný prechod. Ten smie:

- zlúčiť existujúci koniec línie s rohom obrysu,
- vytvoriť spoločný uzol v skutočnom priesečníku,
- rozdeliť iba reálne pretínanú obvodovú hranu,
- odstrániť krátku alebo duplicitnú hranu vzniknutú týmto spojením.

Nesmie pritom pravidelne posúvať ostatné vnútorné body. Tie zostávajú vlastníctvom konzervatívneho solvera na karte vnútorných línií.

## Trvalé uloženie topológie

`ProjectPlanSynchronizer` rozlišuje geometrickú zmenu rohov a topologické rozdelenie obvodu. Nový spoločný uzol sa preto uloží do legacy polygónu aj do kanonického `RoofGraph`; už sa neobnoví starý polygon iba preto, že pôvodné rohy nezmenili XY.

## Overenie

Regresné testy kontrolujú presné 50 mm násobky, zhodu zobrazenej geodetickej dĺžky s lokálnou mriežkou, zachovanie voľných vnútorných bodov a odstránenie chyby `UNSPLIT_INTERSECTION` po potvrdení opravy.
