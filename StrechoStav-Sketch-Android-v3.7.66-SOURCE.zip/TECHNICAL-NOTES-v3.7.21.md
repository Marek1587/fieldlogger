# StrechoStav Sketch 3.7.21 – automatická výška komína

## Dátový model

- `RoofObject.value` pri komíne naďalej znamená zvislú výšku komína nad strešnou rovinou v osi komína.
- `RoofObject.chimneyHeightManual` rozlišuje automatickú výšku od hodnoty zadanej používateľom kolieskom.
- Príznak sa ukladá ako `chimney_height_manual` v projektovom JSON.
- Starý JSON bez príznaku a s kladnou hodnotou výšky sa migruje ako ručne uzamknutý, aby sa pôvodný údaj nezmenil.

## Geometrický výpočet

Solver pracuje s vyriešeným `RoofGraph` a rovinou hostiteľskej plochy:

`z_roof = a*x + b*y + c`

Vzdialenosť k hrebeňu je najkratšia pôdorysná vzdialenosť osi komína k úseku hrebeňa vrátane jeho koncových bodov. Výška hrebeňa sa lineárne interpoluje v najbližšom bode úseku.

Pravidlá:

1. sklon `< 20°`: `z_top = z_roof + 1,00 m`, pričom vyššia atika zostáva riadiacou prekážkou,
2. vzdialenosť k hrebeňu `≤ 2,00 m`: `z_top = z_ridge + 0,65 m`,
3. vzdialenosť k hrebeňu `> 2,00 m`: `z_top = z_ridge - tan(10°)*d + 0,65 m`, najmenej však `z_roof + 0,65 m`,
4. atiková strecha bez hrebeňa: `z_top = z_atika + 1,00 m`,
5. strecha bez hrebeňa a atiky: `z_top = max(z_obvod) + 1,00 m`.

Výsledok sa pre uloženie prevedie späť na lokálnu výšku:

`h_chimney = z_top - z_roof`

Automatika sa spúšťa iba pri zmene polohy komína a iba dovtedy, kým používateľ výšku výslovne nezadá kolieskom. Nemení uzly, hrany, plochy ani sklony strechy.

## Overenie

- blízky komín do 2 m od hrebeňa,
- vzdialený komín a ochranný uhol 10°,
- strecha so sklonom pod 20°,
- atiková strecha bez hrebeňa,
- strecha iba s obvodovými hranami,
- zachovanie ručného príznaku cez JSON,
- bezpečná migrácia staršieho JSON.

Celá sada obsahuje 82 úspešných jednotkových a regresných testov.
