# StrechoStav Sketch 3.7.61 – úplná oprava vnútorných línií

## Cieľ

Funkcia `Skorigovať línie` musí dokončiť všetky problémy vnútorného grafu, ktoré diagnostikuje. Rozdelenie na „bezpečné“ a iba vypísané „nebezpečné“ opravy bolo odstránené z používateľom výslovne spustenej korekcie.

## Pipeline explicitnej opravy

1. konzervatívne zarovnanie existujúcich hrebeňov, nároží a úžľabí,
2. 25 mm metrická mriežka vnútorných uzlov,
3. zlúčenie blízkych uzlov,
4. vytvorenie spoločných uzlov v kríženiach a rozdelenie vnútorných úsekov,
5. magnetické pripojenie voľných koncov,
6. odstránenie krátkych a duplicitných úsekov,
7. opakovaná validácia a deterministické odstránenie zostávajúcej konfliktnej vnútornej línie.

Obvodové uzly a obvodové hrany sú počas celej operácie nemenné. Karta obrysu zostáva jediným vlastníkom fyzickej geometrie pôdorysu.

## Bezpečnosť dát

Úplná oprava sa vykonáva iba po stlačení `Skorigovať línie`, najprv ako `RoofSolverPreview`. Potvrdenie je jedna undo transakcia. `Roof3DPreparation` používa konzervatívny režim a pri obyčajnom otvorení 3D nesmie odstraňovať používateľove línie.

## Overenie

- kompletná sada 175 unit testov prešla,
- overené kríženia, T-spoje, voľné konce a duplicity,
- overená presná nemennosť obvodových uzlov a hrán,
- overené existujúce regresie 3D prípravy.
