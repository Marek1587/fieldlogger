# StrechoStav Sketch 3.7.51 – korekcia rozkladu WallFootprint

## Hlavný trakt

Predošlý riadkový rozklad vedel pri malej 100 mm odchýlke kraja rozdeliť jeden dlhý trakt na dva rovnobežné obdĺžniky. Nový solver hľadá najväčší obdĺžnik, ktorého všetky bunky ležia v pôdoryse muriva. Tento obdĺžnik je normatívne jadro hlavného traktu. Výstupky a krídla vznikajú až rozkladom zostávajúcich obsadených buniek.

## Výklenky

Prázdna oblasť v ohraničujúcom obdĺžniku nestačí na klasifikáciu výklenku. Kandidát musí:

- susediť s fyzickým `WallFootprint` aspoň z troch svetových strán lokálnej mriežky,
- dotýkať sa najviac jednej strany celkovej obálky,
- mať oba rozmery aspoň 300 mm a plochu aspoň 0,5 m²,
- nepresiahnuť 25 % plochy obálky.

Tým sa ako výklenok neoznačí voľné pozadie pri L-pôdoryse ani úzky pás spôsobený zaokrúhlením ortofotomapy.

## Android dialóg

`AlertDialog` na niektorých verziách Samsung Androidu nevykreslí súčasne `setMessage` a `setItems`, pretože obe používajú rovnaký obsahový panel. Dialóg významu oblasti teraz obsahuje iba zoznam všetkých piatich typov a vysvetlenie je súčasťou názvu. Voľby sú preto dostupné na Android 7 až 15.

## Migrácia automatického návrhu

Podpis `wallFootprintPartsSignature` obsahuje verziu klasifikátora `wall-footprint-v2`. Starý automatický návrh sa po aktualizácii vytvorí nanovo. Časti so `source = USER` sa pred nahradením priradia k najbližšej novej oblasti do 0,75 m, takže ručné rozhodnutie sa nestratí.
