package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import kotlin.math.hypot
import kotlin.math.tan

class RoofOpeningPlacementSolverTest {
    @Test
    fun upperEdgeIsExactly2100MillimetresAboveFloor() {
        val plane = RoofPlane(0.0, tan(Math.toRadians(40.0)), 4.0)
        val result = RoofOpeningPlacementSolver.solve(
            plane, LocalPoint(3.0, 2.0), surfaceLengthM = 1.18, floorElevationM = 4.0
        )!!
        assertEquals(6.10, result.upperEdgeElevationM, 1e-9)
        assertEquals(6.10, plane.zAt(result.upperEdgeCenter.x, result.upperEdgeCenter.y), 1e-9)
        val dx = result.upperEdgeCenter.x - result.lowerEdgeCenter.x
        val dy = result.upperEdgeCenter.y - result.lowerEdgeCenter.y
        val dz = plane.zAt(result.upperEdgeCenter.x, result.upperEdgeCenter.y) -
            plane.zAt(result.lowerEdgeCenter.x, result.lowerEdgeCenter.y)
        assertEquals(1.18, kotlin.math.sqrt(dx * dx + dy * dy + dz * dz), 1e-9)
    }

    @Test
    fun dragIsProjectedOnlyAlongEave() {
        val plane = RoofPlane(0.0, tan(Math.toRadians(35.0)), 4.0)
        val constrained = RoofOpeningPlacementSolver.constrainMoveAlongEave(
            plane, LocalPoint(3.0, 5.0)
        )
        assertEquals(3.0, constrained.x, 1e-9)
        assertEquals(0.0, constrained.y, 1e-9)
        assertEquals(0.0, plane.a * constrained.x + plane.b * constrained.y, 1e-9)
    }

    @Test
    fun lateralMovementKeepsTheSameHeadElevation() {
        val plane = RoofPlane(0.15, 0.65, 3.8)
        val first = RoofOpeningPlacementSolver.solve(
            plane, LocalPoint(1.0, 2.0), 1.40, 4.0
        )!!
        val delta = RoofOpeningPlacementSolver.constrainMoveAlongEave(plane, LocalPoint(4.0, -1.0))
        val second = RoofOpeningPlacementSolver.solve(
            plane,
            LocalPoint(first.center.x + delta.x, first.center.y + delta.y),
            1.40,
            4.0
        )!!
        assertEquals(6.10, first.upperEdgeElevationM, 1e-9)
        assertEquals(first.upperEdgeElevationM, second.upperEdgeElevationM, 1e-9)
        assertEquals(hypot(delta.x, delta.y), hypot(second.center.x - first.center.x, second.center.y - first.center.y), 1e-9)
    }

    @Test
    fun flatPlaneHasNoUniqueUphillPlacement() {
        assertNull(RoofOpeningPlacementSolver.solve(
            RoofPlane(0.0, 0.0, 4.0), LocalPoint(2.0, 2.0), 1.18, 4.0
        ))
    }
}
