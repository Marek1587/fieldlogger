package sk.strechasketch.app

import org.junit.Assert.assertTrue
import org.junit.Test

class RoofSurfaceCoverageValidatorTest {
    private fun completeGableGraph(): RoofGraph {
        val nodes = linkedMapOf(
            "a" to GraphNode("a", 0.0, 0.0),
            "b" to GraphNode("b", 4.0, 0.0),
            "c" to GraphNode("c", 8.0, 0.0),
            "d" to GraphNode("d", 8.0, 6.0),
            "t" to GraphNode("t", 4.0, 6.0),
            "f" to GraphNode("f", 0.0, 6.0)
        )
        val edges = linkedMapOf(
            "e0" to GraphEdge("e0", "a", "b", true, EdgeSemantic.GABLE, setOf("left")),
            "e1" to GraphEdge("e1", "b", "c", true, EdgeSemantic.GABLE, setOf("right")),
            "e2" to GraphEdge("e2", "c", "d", true, EdgeSemantic.EAVE, setOf("right")),
            "e3" to GraphEdge("e3", "d", "t", true, EdgeSemantic.GABLE, setOf("right")),
            "e4" to GraphEdge("e4", "t", "f", true, EdgeSemantic.GABLE, setOf("left")),
            "e5" to GraphEdge("e5", "f", "a", true, EdgeSemantic.EAVE, setOf("left")),
            "ridge" to GraphEdge("ridge", "b", "t", false, EdgeSemantic.RIDGE, setOf("left", "right"))
        )
        val faces = linkedMapOf(
            "left" to GraphFace(
                "left", listOf("b", "t", "f", "a"), listOf("ridge", "e4", "e5", "e0"), 24.0
            ),
            "right" to GraphFace(
                "right", listOf("b", "c", "d", "t"), listOf("e1", "e2", "e3", "ridge"), 24.0
            )
        )
        return RoofGraph(GeoPoint(48.0, 18.0), nodes, edges, faces)
    }

    @Test
    fun completeFaceSubdivisionPassesCoverageGate() {
        assertTrue(RoofSurfaceCoverageValidator.validate(completeGableGraph()).isEmpty())
    }

    @Test
    fun missingFaceIsBlockedInsteadOfProducingPartialEnvelope() {
        val complete = completeGableGraph()
        val incomplete = complete.copy(faces = complete.faces - "right")

        val issues = RoofSurfaceCoverageValidator.validate(incomplete)

        assertTrue(issues.all { it.blocking })
        assertTrue(issues.any { it.code == "ROOF_SURFACE_EDGE_INCIDENCE" })
        assertTrue(issues.any { it.code == "ROOF_SURFACE_AREA_MISMATCH" })
    }

    @Test
    fun oneFaceCannotHideTwoPerpendicularRidgeAxes() {
        val complete = completeGableGraph()
        val alteredEdges = complete.edges + mapOf(
            // Deliberately corrupt semantic input: the left face would contain both the
            // vertical shared ridge and a perpendicular ridge segment without a face split.
            "e4" to complete.edges.getValue("e4").copy(semanticRole = EdgeSemantic.RIDGE)
        )

        val issues = RoofSurfaceCoverageValidator.validate(complete.copy(edges = alteredEdges))

        assertTrue(issues.any { it.code == "ROOF_SURFACE_MISSING_RIDGE_SPLIT" })
    }
}
