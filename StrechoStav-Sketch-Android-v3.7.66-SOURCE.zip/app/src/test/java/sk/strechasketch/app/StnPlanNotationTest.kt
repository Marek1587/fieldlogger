package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Test

class StnPlanNotationTest {
    @Test
    fun `elevation uses signed metres with three decimals and no unit`() {
        assertEquals("±0,000", StnPlanNotation.elevation(0.0))
        assertEquals("+4,000", StnPlanNotation.elevation(4.0))
        assertEquals("-0,125", StnPlanNotation.elevation(-0.125))
    }

    @Test
    fun `slope uses degrees and unit symbol without descriptive prefix`() {
        assertEquals("40,0°", StnPlanNotation.slopeDegrees(40.0))
        assertEquals("7,5°", StnPlanNotation.slopeDegrees(7.5))
    }
}
