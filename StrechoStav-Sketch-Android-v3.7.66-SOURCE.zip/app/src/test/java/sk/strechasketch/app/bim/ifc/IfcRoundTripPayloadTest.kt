package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import sk.strechasketch.app.ProjectJson
import sk.strechasketch.app.bim.RoofBimSnapshotFactory
import sk.strechasketch.app.bim.StrechoStavBimBuilder
import java.security.MessageDigest
import java.time.Instant

class IfcRoundTripPayloadTest {
    @Test fun payloadChunksReassembleAndSha256MatchesCanonicalJson() {
        val snapshot = RoofBimSnapshotFactory.create(IfcTestFixtures.gableProject())
        val bim = StrechoStavBimBuilder.build(snapshot)
        val model = Ifc43Mapper.map(bim, "3.7.23", Instant.EPOCH, "test.ifc")
        val properties = model.entities.filter { it.type == "IFCPROPERTYSINGLEVALUE" }.associate { entity ->
            val name = (entity.attributes[0] as IfcStepValue.Text).value
            val typed = entity.attributes[2] as IfcStepValue.Typed
            name to typed.value
        }
        val count = (properties.getValue("PayloadChunkCount") as IfcStepValue.Integer).value
        val payload = (1..count).joinToString("") { index ->
            (properties.getValue("Payload${index.toString().padStart(4, '0')}") as IfcStepValue.Text).value
        }
        assertEquals(snapshot.canonicalProjectJson, payload)
        assertEquals(snapshot.project.id, ProjectJson.decode(payload).id)
        val sha = MessageDigest.getInstance("SHA-256").digest(payload.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        assertEquals(sha, (properties.getValue("PayloadSha256") as IfcStepValue.Text).value)
    }
}
