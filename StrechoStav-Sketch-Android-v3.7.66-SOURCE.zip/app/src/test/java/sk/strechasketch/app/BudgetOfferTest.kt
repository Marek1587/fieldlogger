package sk.strechasketch.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BudgetOfferTest {
    @Test
    fun catalogueAndOfferUseStableConstructionSequence() {
        assertEquals(WorkCatalog.items.map { it.budgetOrder }.sorted(), WorkCatalog.items.map { it.budgetOrder })
        val project = RoofProject(id = "project-budget", name = "Strecha A", customer = "Objednávateľ")
        project.selectedWorkItems["RIDGE_DETAIL"] = SelectedWorkItem(
            "RIDGE_DETAIL", selected = true, unitPrice = 12.0, manualQuantityOverride = 5.0
        )
        project.selectedWorkItems["ROOF_DISMANTLE"] = SelectedWorkItem(
            "ROOF_DISMANTLE", selected = true, unitPrice = 8.0, manualQuantityOverride = 10.0
        )
        project.selectedWorkItems["ROOF_COVERING"] = SelectedWorkItem(
            "ROOF_COVERING", selected = true, unitPrice = 20.0, manualQuantityOverride = 10.0
        )

        val offer = BudgetOfferBuilder.build(project, nowMillis = 1_700_000_000_000L)

        assertEquals(listOf("ROOF_DISMANTLE", "ROOF_COVERING", "RIDGE_DETAIL"), offer.items.map { it.item.code })
        assertTrue(offer.items.all { it.item.specification.isNotBlank() && it.item.budgetCode.isNotBlank() })
    }

    @Test
    fun totalsUseEditableVatWithoutChangingQuantities() {
        val project = RoofProject(id = "project-vat", budgetVatPercent = 23.0)
        project.selectedWorkItems["ROOF_COVERING"] = SelectedWorkItem(
            "ROOF_COVERING", selected = true, unitPrice = 25.0, manualQuantityOverride = 4.0
        )

        val offer = BudgetOfferBuilder.build(project, nowMillis = 1_700_000_000_000L)

        assertEquals(100.0, offer.subtotal, 1e-9)
        assertEquals(23.0, offer.vat, 1e-9)
        assertEquals(123.0, offer.totalWithVat, 1e-9)
        assertEquals(4.0, offer.items.single().quantity, 0.0)
    }

    @Test
    fun vatPersistsInProjectJsonAndOldProjectsDefaultToTwentyThreePercent() {
        val project = RoofProject(id = "project-json", budgetVatPercent = 19.0)
        val decoded = ProjectJson.decode(ProjectJson.encode(project))
        assertEquals(19.0, decoded.budgetVatPercent, 0.0)

        val legacy = JSONObject(ProjectJson.encode(project)).apply { remove("budget_vat_percent") }.toString()
        assertEquals(23.0, ProjectJson.decode(legacy).budgetVatPercent, 0.0)
    }
}
