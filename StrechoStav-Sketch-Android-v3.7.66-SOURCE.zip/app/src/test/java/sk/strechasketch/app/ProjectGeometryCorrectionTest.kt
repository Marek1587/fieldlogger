package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectGeometryCorrectionTest {
    private val origin = GeoPoint(48.0, 18.0)

    @Test
    fun `confirmed correction keeps roof wall footprint and user tract in one coordinate frame`() {
        val original = projectionTopology(-2.0)
        val proposed = projectionTopology(-2.1)
        val originalGraph = RoofGraphFactory.fromTopology(original)
        val originalLoop = orderedLocal(original).map { Geometry.toGeo(it, origin) }
        val project = RoofProject(
            polygon = originalLoop.map(GeoPoint::copy).toMutableList(),
            wallFootprint = originalLoop.map(GeoPoint::copy).toMutableList(),
            roofTopology = original,
            roofGraph = originalGraph,
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 0.0,
            wallFootprintParts = mutableListOf(
                WallFootprintPart(
                    id = "user-projection",
                    type = WallFootprintPartType.PROJECTION,
                    polygon = listOf(
                        LocalPoint(0.0, 4.0), LocalPoint(-2.0, 4.0),
                        LocalPoint(-2.0, 8.0), LocalPoint(0.0, 8.0)
                    ).map { Geometry.toGeo(it, origin) }.toMutableList(),
                    source = WallFootprintPartSource.USER
                )
            )
        )
        val preview = RoofSolverPreview(
            original = original,
            proposed = proposed,
            statistics = RoofSolverStatistics(regularizedBoundaryNodes = 2),
            movements = emptyList(),
            issues = emptyList(),
            faces = RoofTopologySolver.extractFaces(proposed)
        )

        val result = ProjectGeometryCorrection.apply(project, preview)

        assertTrue(result.issues.joinToString { it.message }, result.applied)
        val expected = orderedLocal(proposed)
        assertLocalLoopEquals(expected, project.polygon)
        assertLocalLoopEquals(expected, project.wallFootprint)
        assertTrue(
            "A transformed decomposition must stay invalid until rebuilt from the corrected polygon",
            project.wallFootprintPartsSignature.isBlank()
        )
        val projection = project.wallFootprintParts.single {
            it.type == WallFootprintPartType.PROJECTION && it.source == WallFootprintPartSource.USER
        }
        val projectionLocal = projection.polygon.map { Geometry.toLocal(it, origin) }
        assertEquals(-2.1, projectionLocal.minOf { it.x }, 0.002)
        assertEquals(0.0, projectionLocal.maxOf { it.x }, 0.002)
        val rebuilt = WallFootprintSolver.refresh(project)
        assertEquals(rebuilt.signature, project.wallFootprintPartsSignature)
        assertEquals(1, rebuilt.parts.count { it.type == WallFootprintPartType.MAIN_TRACT })
    }

    @Test
    fun `internal correction may move bounded outline and keeps all semantic identities`() {
        val boundaryOrder = listOf("tl", "ts", "tr", "br", "bs", "bl")
        val nodes = listOf(
            TopologyNode("tl", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("ts", 3.20, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("tr", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("br", 8.0, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bs", 3.28, 14.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("bl", 0.0, 14.0, TopologyNodeType.FOOTPRINT)
        )
        val edges = boundaryOrder.indices.map { index ->
            TopologyEdge(
                id = "boundary-$index",
                startNodeId = boundaryOrder[index],
                endNodeId = boundaryOrder[(index + 1) % boundaryOrder.size],
                type = if (index in setOf(0, 1, 3, 4)) LineType.GABLE else LineType.EAVE,
                boundary = true,
                sourceId = index.toString()
            )
        } + TopologyEdge(
            "ridge", "ts", "bs", LineType.RIDGE, sourceId = "authored-ridge", note = "keep"
        )
        val internal = RoofTopology(origin, nodes, edges, gridRotationDeg = 0.0)
        val polygon = boundaryOrder.map { id ->
            nodes.first { it.id == id }.let { Geometry.toGeo(LocalPoint(it.x, it.y), origin) }
        }
        val wallPart = WallFootprintPart(
            id = "locked-main",
            type = WallFootprintPartType.MAIN_TRACT,
            polygon = polygon.map(GeoPoint::copy).toMutableList(),
            source = WallFootprintPartSource.USER
        )
        val project = RoofProject(
            polygon = polygon.map(GeoPoint::copy).toMutableList(),
            wallFootprint = polygon.map(GeoPoint::copy).toMutableList(),
            roofTopology = internal.copy(
                nodes = internal.nodes.map { it.copy() },
                edges = internal.edges.map { it.copy() }
            ),
            roofGraph = RoofGraphFactory.fromTopology(internal, normalizeGrid = false),
            lines = mutableListOf(
                RoofLine(
                    id = "ridge",
                    type = LineType.RIDGE,
                    start = Geometry.toGeo(LocalPoint(3.20, 0.0), origin),
                    end = Geometry.toGeo(LocalPoint(3.28, 14.0), origin),
                    note = "keep"
                )
            ),
            edgeTypes = edges.filter { it.boundary }.mapIndexed { index, edge -> index to edge.type }.toMap().toMutableMap(),
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 0.0,
            wallFootprintParts = mutableListOf(wallPart),
            wallFootprintPartsSignature = "locked-signature"
        )
        val edgeTypesBefore = project.edgeTypes.toMap()
        val lineOrderBefore = project.lines.map { it.id }
        val meaningBefore = project.wallFootprintParts.map { listOf(it.id, it.type, it.source, it.hostPartId, it.sourceObjectId) }
        val preview = RoofTopologySolver.solveInternal(internal)

        val result = ProjectGeometryCorrection.apply(project, preview, kind = GeometryCorrectionKind.INTERNAL)

        assertTrue(result.issues.joinToString { it.message }, result.applied)
        assertEquals(edgeTypesBefore, project.edgeTypes)
        assertEquals(lineOrderBefore, project.lines.map { it.id })
        assertEquals(meaningBefore, project.wallFootprintParts.map {
            listOf(it.id, it.type, it.source, it.hostPartId, it.sourceObjectId)
        })
        val finalTopology = requireNotNull(project.roofTopology)
        assertEquals(internal.nodes.map { it.id }, finalTopology.nodes.map { it.id })
        assertEquals(internal.edges, finalTopology.edges)
        val solvedById = preview.proposed.nodes.associateBy { it.id }
        assertEquals(3.2, solvedById.getValue("bs").x, 1e-9)
        project.polygon.indices.forEach { index ->
            val actual = Geometry.toLocal(project.polygon[index], origin)
            val expected = solvedById.getValue(boundaryOrder[index])
            assertEquals(expected.x, actual.x, 0.002)
            assertEquals(expected.y, actual.y, 0.002)
            val wall = Geometry.toLocal(project.wallFootprint[index], origin)
            assertEquals(expected.x, wall.x, 0.002)
            assertEquals(expected.y, wall.y, 0.002)
        }
    }

    @Test
    fun `internal boundary shift over limit is rejected without any project mutation`() {
        val original = transactionTopology()
        val project = transactionProject(original)
        val beforeJson = ProjectJson.encode(project)
        val proposed = original.copy(nodes = original.nodes.map { node ->
            if (node.id == "b1") node.copy(x = node.x + 0.40) else node.copy()
        })
        val preview = RoofSolverPreview(
            original = original,
            proposed = proposed,
            statistics = RoofSolverStatistics(regularizedBoundaryNodes = 1),
            movements = emptyList(),
            issues = emptyList(),
            faces = emptyList()
        )

        val result = ProjectGeometryCorrection.apply(project, preview, kind = GeometryCorrectionKind.INTERNAL)

        assertFalse(result.applied)
        assertEquals("INTERNAL_BOUNDARY_SHIFT_LIMIT", result.issues.single().code)
        assertEquals(beforeJson, ProjectJson.encode(project))
    }

    @Test
    fun `outline transaction cannot move an internal coordinate`() {
        val original = transactionTopology()
        val project = transactionProject(original)
        val beforeJson = ProjectJson.encode(project)
        val proposed = original.copy(nodes = original.nodes.map { node ->
            if (node.id == "r0") node.copy(x = node.x + 0.025) else node.copy()
        })
        val preview = RoofSolverPreview(
            original, proposed, RoofSolverStatistics(), emptyList(), emptyList(), emptyList()
        )

        val result = ProjectGeometryCorrection.apply(project, preview, kind = GeometryCorrectionKind.OUTLINE)

        assertFalse(result.applied)
        assertEquals("OUTLINE_INTERNAL_COORDINATE_CHANGED", result.issues.single().code)
        assertEquals(beforeJson, ProjectJson.encode(project))
    }

    @Test
    fun `internal correction preserves clockwise legacy edge types and line order`() {
        val topology = transactionTopology()
        val project = transactionProject(topology)
        val edgeTypesBefore = project.edgeTypes.toMap()
        val lineOrderBefore = project.lines.map(RoofLine::id)
        val proposed = topology.copy(nodes = topology.nodes.map { node ->
            if (node.id == "r1") node.copy(x = 5.025) else node.copy()
        })
        val preview = RoofSolverPreview(
            topology,
            proposed,
            RoofSolverStatistics(),
            emptyList(),
            emptyList(),
            RoofTopologySolver.extractFaces(proposed)
        )

        val result = ProjectGeometryCorrection.apply(project, preview, allowBoundaryChanges = false)

        assertTrue(result.issues.joinToString { it.message }, result.applied)
        assertEquals(edgeTypesBefore, project.edgeTypes)
        assertEquals(lineOrderBefore, project.lines.map(RoofLine::id))
        assertEquals(
            topology.edges.filter { it.boundary },
            requireNotNull(project.roofTopology).edges.filter { it.boundary }
        )
    }

    @Test
    fun `internal transaction rejects every topology mutation including provenance`() {
        val original = transactionTopology()
        val extraNode = TopologyNode("extra", 3.0, 2.0, TopologyNodeType.LINE_ENDPOINT)
        val mutations = linkedMapOf(
            "delete" to original.copy(edges = original.edges.filterNot { it.id == "z-ridge" }),
            "add" to original.copy(
                nodes = original.nodes + extraNode,
                edges = original.edges + TopologyEdge("extra-edge", "r0", "extra", LineType.RIDGE)
            ),
            "split" to original.copy(
                nodes = original.nodes + extraNode,
                edges = original.edges.filterNot { it.id == "z-ridge" } + listOf(
                    TopologyEdge("z-ridge-1", "r0", "extra", LineType.RIDGE, sourceId = "auth-z"),
                    TopologyEdge("z-ridge-2", "extra", "r1", LineType.RIDGE, sourceId = "auth-z")
                )
            ),
            "retype" to original.copy(edges = original.edges.map { edge ->
                if (edge.id == "z-ridge") edge.copy(type = LineType.VALLEY) else edge
            }),
            "reconnect" to original.copy(edges = original.edges.map { edge ->
                if (edge.id == "z-ridge") edge.copy(endNodeId = "b2") else edge
            }),
            "source" to original.copy(edges = original.edges.map { edge ->
                if (edge.id == "z-ridge") edge.copy(sourceId = "runtime-segment") else edge
            })
        )

        mutations.forEach { (name, proposed) ->
            val project = transactionProject(original)
            val topologyBefore = project.roofTopology
            val linesBefore = project.lines.map { it.copy(start = it.start.copy(), end = it.end.copy()) }
            val preview = RoofSolverPreview(
                original, proposed, RoofSolverStatistics(), emptyList(), emptyList(), emptyList()
            )

            val result = ProjectGeometryCorrection.apply(project, preview, allowBoundaryChanges = false)

            assertFalse(name, result.applied)
            assertEquals(name, "INTERNAL_TOPOLOGY_MUTATION_REJECTED", result.issues.single().code)
            assertEquals(name, topologyBefore, project.roofTopology)
            assertEquals(name, linesBefore, project.lines)
        }
    }

    @Test
    fun `stale solver preview cannot overwrite a newer authored line`() {
        val original = transactionTopology()
        val project = transactionProject(original)
        val proposed = original.copy(nodes = original.nodes.map { node ->
            if (node.id == "r1") node.copy(x = 5.025) else node.copy()
        })
        val preview = RoofSolverPreview(
            original, proposed, RoofSolverStatistics(), emptyList(), emptyList(), emptyList()
        )
        val newer = original.copy(
            nodes = original.nodes + TopologyNode("new-end", 4.0, 2.0, TopologyNodeType.LINE_ENDPOINT),
            edges = original.edges + TopologyEdge(
                "new-user-line", "b1", "new-end", LineType.VALLEY, sourceId = "new-user-line"
            )
        )
        assertTrue(RoofTopologyMigration.applyToProject(
            project, newer, requireFullyValid = false, normalizeGrid = false
        ).applied)
        val topologyBefore = project.roofTopology
        val linesBefore = project.lines.map { it.copy(start = it.start.copy(), end = it.end.copy()) }

        val result = ProjectGeometryCorrection.apply(project, preview, allowBoundaryChanges = false)

        assertFalse(result.applied)
        assertEquals("STALE_SOLVER_PREVIEW", result.issues.single().code)
        assertEquals(topologyBefore, project.roofTopology)
        assertEquals(linesBefore, project.lines)
        assertTrue(project.lines.any { it.id == "new-user-line" })
    }

    private fun transactionTopology(): RoofTopology {
        // Clockwise order deliberately differs from orderedBoundary()'s canonical CCW cycle.
        val nodes = listOf(
            TopologyNode("b0", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b1", 0.0, 4.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b2", 6.0, 4.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("b3", 6.0, 0.0, TopologyNodeType.FOOTPRINT),
            TopologyNode("r0", 1.0, 1.0, TopologyNodeType.LINE_ENDPOINT),
            TopologyNode("r1", 5.0, 3.0, TopologyNodeType.LINE_ENDPOINT)
        )
        return RoofTopology(
            origin = origin,
            nodes = nodes,
            edges = listOf(
                TopologyEdge("e0", "b0", "b1", LineType.EAVE, boundary = true, sourceId = "0"),
                TopologyEdge("e1", "b1", "b2", LineType.GABLE, boundary = true, sourceId = "1"),
                TopologyEdge("e2", "b2", "b3", LineType.PULT, boundary = true, sourceId = "2"),
                TopologyEdge("e3", "b3", "b0", LineType.ATTIC, boundary = true, sourceId = "3"),
                TopologyEdge("z-ridge", "r0", "r1", LineType.RIDGE, sourceId = "auth-z"),
                TopologyEdge("a-hip", "b0", "r0", LineType.HIP, sourceId = "auth-a")
            ),
            gridRotationDeg = 0.0
        )
    }

    private fun transactionProject(topology: RoofTopology): RoofProject {
        val nodes = topology.nodes.associateBy(TopologyNode::id)
        val boundaryIds = listOf("b0", "b1", "b2", "b3")
        val polygon = boundaryIds.map { id ->
            nodes.getValue(id).let { Geometry.toGeo(LocalPoint(it.x, it.y), origin) }
        }
        val lines = topology.edges.filterNot { it.boundary }.map { edge ->
            val a = nodes.getValue(edge.startNodeId)
            val b = nodes.getValue(edge.endNodeId)
            RoofLine(
                id = edge.id,
                type = edge.type,
                start = Geometry.toGeo(LocalPoint(a.x, a.y), origin),
                end = Geometry.toGeo(LocalPoint(b.x, b.y), origin),
                note = edge.note
            )
        }
        return RoofProject(
            polygon = polygon.map(GeoPoint::copy).toMutableList(),
            wallFootprint = polygon.map(GeoPoint::copy).toMutableList(),
            lines = lines.toMutableList(),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.PULT,
                3 to LineType.ATTIC
            ),
            roofTopology = topology.copy(
                origin = topology.origin.copy(),
                nodes = topology.nodes.map { it.copy() },
                edges = topology.edges.map { it.copy() }
            ),
            roofGraph = RoofGraphFactory.fromTopology(topology, normalizeGrid = false),
            geometryGridOriginLat = origin.lat,
            geometryGridOriginLon = origin.lon,
            geometryGridRotationDeg = 0.0
        )
    }

    private fun projectionTopology(outerX: Double): RoofTopology {
        val points = listOf(
            LocalPoint(0.0, 0.0), LocalPoint(8.0, 0.0),
            LocalPoint(8.0, 12.0), LocalPoint(0.0, 12.0),
            LocalPoint(0.0, 8.0), LocalPoint(outerX, 8.0),
            LocalPoint(outerX, 4.0), LocalPoint(0.0, 4.0)
        )
        val nodes = points.mapIndexed { index, point ->
            TopologyNode("N$index", point.x, point.y, TopologyNodeType.FOOTPRINT)
        }
        val edges = nodes.indices.map { index ->
            TopologyEdge(
                id = "E$index",
                startNodeId = nodes[index].id,
                endNodeId = nodes[(index + 1) % nodes.size].id,
                type = LineType.EAVE,
                boundary = true
            )
        }
        return RoofTopology(origin, nodes, edges, gridRotationDeg = 0.0)
    }

    private fun orderedLocal(topology: RoofTopology): List<LocalPoint> {
        val byId = topology.nodes.associateBy { it.id }
        return RoofTopologyMigration.orderedBoundary(topology)!!.first.map { id ->
            byId.getValue(id).let { LocalPoint(it.x, it.y) }
        }
    }

    private fun assertLocalLoopEquals(expected: List<LocalPoint>, actual: List<GeoPoint>) {
        val local = actual.map { Geometry.toLocal(it, origin) }
        assertEquals(expected.size, local.size)
        expected.indices.forEach { index ->
            assertEquals(expected[index].x, local[index].x, 0.002)
            assertEquals(expected[index].y, local[index].y, 0.002)
        }
    }
}
