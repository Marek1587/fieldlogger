package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class StnRoofPlanSymbolsTest {
    @Test
    fun `prestup uses pipe penetration mark`() {
        assertEquals(
            StnRoofPlanSymbol.PIPE_PENETRATION,
            StnRoofPlanSymbols.forObject(ObjectType.VENT)
        )
    }

    @Test
    fun `explicit ventilation note uses ventilation device mark`() {
        assertEquals(
            StnRoofPlanSymbol.VENTILATION_DEVICE,
            StnRoofPlanSymbols.forObject(ObjectType.VENT, "Vetracia hlavica")
        )
    }

    @Test
    fun `drain and downspout keep distinct STN meanings`() {
        assertEquals(StnRoofPlanSymbol.ROOF_INLET, StnRoofPlanSymbols.forObject(ObjectType.DRAIN))
        assertEquals(StnRoofPlanSymbol.GUTTER_OUTLET, StnRoofPlanSymbols.forObject(ObjectType.DOWNSPOUT))
    }

    @Test
    fun `ordinary roof objects do not receive table 2 mark`() {
        assertNull(StnRoofPlanSymbols.forObject(ObjectType.CHIMNEY))
        assertNull(StnRoofPlanSymbols.forObject(ObjectType.ROOF_WINDOW))
    }
}
