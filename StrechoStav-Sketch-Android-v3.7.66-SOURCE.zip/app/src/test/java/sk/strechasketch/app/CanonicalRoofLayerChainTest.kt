package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CanonicalRoofLayerChainTest {
    private fun graphWithRuntimeBoundarySplit(): RoofGraph {
        val nodes = linkedMapOf(
            "b0" to GraphNode("b0", 0.0, 0.0, -10.0),
            "b1" to GraphNode("b1", 5.0, 0.0, -10.0),
            "b2" to GraphNode("b2", 10.0, 0.0, -10.0),
            "b3" to GraphNode("b3", 10.0, 6.0, -10.0),
            "b4" to GraphNode("b4", 0.0, 6.0, -10.0)
        )
        val edgeIds = listOf("e0a", "e0b", "e1", "e2", "e3")
        val endpoints = listOf(
            "b0" to "b1", "b1" to "b2", "b2" to "b3",
            "b3" to "b4", "b4" to "b0"
        )
        val edges = linkedMapOf<String, GraphEdge>().apply {
            edgeIds.indices.forEach { index ->
                val (a, b) = endpoints[index]
                put(
                    edgeIds[index],
                    GraphEdge(
                        edgeIds[index], a, b, boundary = true,
                        semanticRole = EdgeSemantic.EAVE,
                        adjacentFaceIds = setOf("face")
                    )
                )
            }
        }
        val face = GraphFace(
            id = "face",
            orderedNodeIds = nodes.keys.toList(),
            orderedEdgeIds = edgeIds,
            signedAreaM2 = 60.0,
            plane = RoofPlane(0.05, 0.10, 4.0)
        )
        return RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = nodes,
            edges = edges,
            faces = linkedMapOf("face" to face)
        )
    }

    @Test
    fun soffitInterpolatesVirtualIncidenceOnExactSavedWallSegment() {
        val graph = graphWithRuntimeBoundarySplit()
        val exactWall = listOf(
            LocalPoint(0.50, 0.30),
            LocalPoint(9.40, 0.30),
            LocalPoint(9.40, 5.60),
            LocalPoint(0.50, 5.60)
        )

        val solution = RoofOverhangSolver.solve(graph, exactWall)
        val first = solution.sections.single { it.edgeId == "e0a" }
        val second = solution.sections.single { it.edgeId == "e0b" }

        assertEquals(0.50, first.wallInnerA.x, 1e-9)
        assertEquals(0.30, first.wallInnerA.y, 1e-9)
        assertEquals(4.95, first.wallInnerB.x, 1e-9)
        assertEquals(0.30, first.wallInnerB.y, 1e-9)
        assertEquals(first.wallInnerB.x, second.wallInnerA.x, 1e-9)
        assertEquals(first.wallInnerB.y, second.wallInnerA.y, 1e-9)
        assertEquals(9.40, second.wallInnerB.x, 1e-9)
        assertEquals(0.30, second.wallInnerB.y, 1e-9)
        assertTrue(solution.sections.map { it.overhangM }.distinct().size > 1)
    }

    @Test
    fun gutterUsesTheSameCanonicalEdgeHeightAsAnthracitePerimeter() {
        val graph = graphWithRuntimeBoundarySplit()
        val surface = requireNotNull(SolvedRoofSurfaceGeometry.from(graph))
        val drainage = RainwaterDrainageSolver.solve(graph)

        drainage.gutters.forEach { gutter ->
            val section = requireNotNull(surface.section(gutter.edgeId))
            val expectedStart = section.topA.z - RainwaterDrainageSolver.GUTTER_TOP_CLEARANCE_M -
                RainwaterDrainageSolver.GUTTER_WIDTH_M / 2.0
            assertEquals(expectedStart, gutter.profile.first().elevationZ, 1e-9)
        }
    }
}
