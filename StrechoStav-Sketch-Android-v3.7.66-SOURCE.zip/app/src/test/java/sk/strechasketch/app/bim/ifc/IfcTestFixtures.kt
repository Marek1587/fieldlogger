package sk.strechasketch.app.bim.ifc

import sk.strechasketch.app.*

internal object IfcTestFixtures {
    val origin = GeoPoint(49.0, 18.0)

    fun gableProject(): RoofProject {
        fun node(id: String, x: Double, y: Double) = TopologyNode(id, x, y, TopologyNodeType.FOOTPRINT)
        fun edge(id: String, a: String, b: String, type: LineType, boundary: Boolean) =
            TopologyEdge(id, a, b, type, boundary = boundary)
        val topology = RoofTopology(
            origin,
            listOf(
                node("A", 0.0, 0.0), node("B", 10.0, 0.0), node("R", 10.0, 3.0),
                node("C", 10.0, 6.0), node("D", 0.0, 6.0), node("L", 0.0, 3.0)
            ),
            listOf(
                edge("AB", "A", "B", LineType.EAVE, true),
                edge("BR", "B", "R", LineType.GABLE, true),
                edge("RC", "R", "C", LineType.GABLE, true),
                edge("CD", "C", "D", LineType.EAVE, true),
                edge("DL", "D", "L", LineType.GABLE, true),
                edge("LA", "L", "A", LineType.GABLE, true),
                edge("RIDGE", "L", "R", LineType.RIDGE, false)
            )
        )
        val graph = RoofGraphFactory.fromTopology(topology)
        val boundary = RoofTopologyMigration.orderedBoundary(topology)!!.first
        val faceId = graph.faces.values.minBy { it.id }.id
        return RoofProject(
            id = "ifc-test-project",
            name = "Skúšobná sedlová strecha",
            customer = "Žofia O'Connor",
            address = "Martin, Slovensko",
            slopeDeg = 30.0,
            wallHeightM = 3.0,
            shape = RoofShape.GABLE,
            polygon = boundary.map { id ->
                val n = graph.nodes.getValue(id)
                Geometry.toGeo(LocalPoint(n.x, n.y), origin)
            }.toMutableList(),
            wallFootprint = boundary.map { id ->
                val n = graph.nodes.getValue(id)
                Geometry.toGeo(LocalPoint(n.x, n.y), origin)
            }.toMutableList(),
            objects = mutableListOf(
                RoofObject(
                    id = "window-1", type = ObjectType.ROOF_WINDOW,
                    center = Geometry.toGeo(LocalPoint(5.0, 1.5), origin),
                    widthMm = 780.0, heightMm = 1180.0, attachedFaceId = faceId
                ),
                RoofObject(
                    id = "chimney-1", type = ObjectType.CHIMNEY,
                    center = Geometry.toGeo(LocalPoint(2.0, 4.5), origin),
                    widthMm = 700.0, heightMm = 700.0, value = 1.2,
                    attachedFaceId = graph.faces.values.maxBy { it.id }.id
                )
            ),
            roofGraph = graph,
            roofTopology = topology,
            createdAt = 1_700_000_000_000L,
            updatedAt = 1_700_000_000_000L
        )
    }
}
