package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WallFootprintSolverTest {
    private val origin = GeoPoint(49.0, 18.0)

    @Test
    fun rectangleProducesOneMainTract() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 7.0),
            LocalPoint(0.0, 7.0)
        )

        val solution = WallFootprintSolver.refresh(project)

        assertEquals(1, solution.parts.size)
        assertEquals(WallFootprintPartType.MAIN_TRACT, solution.parts.single().type)
        assertTrue(solution.parts.single().id.startsWith("wall-part-"))
    }

    @Test
    fun lFootprintProducesMainTractAndSemanticSecondaryRegion() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )

        val solution = WallFootprintSolver.refresh(project)

        assertTrue(solution.parts.any { it.type == WallFootprintPartType.MAIN_TRACT })
        assertTrue(solution.parts.any {
            it.type in setOf(
                WallFootprintPartType.PROJECTION,
                WallFootprintPartType.SEPARATE_WING
            )
        })
        assertFalse(solution.parts.any { it.type == WallFootprintPartType.RECESS })
    }

    @Test
    fun onlyThreeSidedConcavityProducesRecess() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 10.0),
            LocalPoint(0.0, 10.0),
            LocalPoint(0.0, 7.0),
            LocalPoint(3.0, 7.0),
            LocalPoint(3.0, 3.0),
            LocalPoint(0.0, 3.0)
        )

        val solution = WallFootprintSolver.refresh(project)

        val recesses = solution.parts.filter { it.type == WallFootprintPartType.RECESS }
        assertEquals(1, recesses.size)
        val local = recesses.single().polygon.map { Geometry.toLocal(it, origin) }
        assertEquals(1.5, local.map { it.x }.average(), 0.06)
        assertEquals(5.0, local.map { it.y }.average(), 0.06)
    }

    @Test
    fun userClassificationSurvivesBoundedOutlineCorrection() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )
        WallFootprintSolver.refresh(project)
        val secondary = project.wallFootprintParts.first {
            it.type in setOf(WallFootprintPartType.PROJECTION, WallFootprintPartType.SEPARATE_WING)
        }
        secondary.type = WallFootprintPartType.SEPARATE_WING
        secondary.source = WallFootprintPartSource.USER

        project.polygon = listOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.1, 0.0),
            LocalPoint(12.1, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        ).map { Geometry.toGeo(it, origin) }.toMutableList()
        val refreshed = WallFootprintSolver.refresh(project)

        assertTrue(refreshed.parts.any {
            it.type == WallFootprintPartType.SEPARATE_WING &&
                it.source == WallFootprintPartSource.USER
        })
    }

    @Test
    fun exactEightPointZPolygonOverridesStaleWallFootprintWithoutCoverageGaps() {
        val zPoints = listOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(38.20, 0.0),
            LocalPoint(38.20, -14.70),
            LocalPoint(48.95, -14.70),
            LocalPoint(48.95, 9.95),
            LocalPoint(10.50, 9.95),
            LocalPoint(10.50, 29.75),
            LocalPoint(0.0, 29.75)
        )
        val project = projectOf(*zPoints.toTypedArray()).apply {
            // Deliberately stale cache: if it won, the solver would return one 2 176 m2 block.
            wallFootprint = listOf(
                LocalPoint(0.0, -14.70),
                LocalPoint(48.95, -14.70),
                LocalPoint(48.95, 29.75),
                LocalPoint(0.0, 29.75)
            ).map { Geometry.toGeo(it, origin) }.toMutableList()
        }

        val solution = WallFootprintSolver.refresh(project)
        val structural = solution.parts.filter {
            it.type !in setOf(WallFootprintPartType.RECESS, WallFootprintPartType.SUPERSTRUCTURE)
        }

        assertEquals(1, structural.count { it.type == WallFootprintPartType.MAIN_TRACT })
        val mainId = structural.single { it.type == WallFootprintPartType.MAIN_TRACT }.id
        assertTrue(structural.filterNot { it.id == mainId }.all { it.hostPartId == mainId })
        assertEquals(852.9775, structural.sumOf(::partAreaM2), 0.01)
        structural.indices.forEach { first ->
            for (second in first + 1 until structural.size) {
                assertEquals(0.0, rectangleOverlapM2(structural[first], structural[second]), 1e-6)
            }
        }
        val context = WallFootprintSolver.context(project)
        assertTrue(context.structuralPartAt(20.0, 20.0) == null)
        assertTrue(context.structuralPartAt(5.0, 20.0) != null)
        assertTrue(context.sameStructuralPart(5.0, 9.90, 5.0, 10.00))
        assertTrue(context.sameStructuralPart(40.0, -0.05, 40.0, 0.05))
    }

    @Test
    fun narrowPositiveProjectionIsNotDiscarded() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(8.0, 0.0),
            LocalPoint(8.0, 5.0),
            LocalPoint(8.20, 5.0),
            LocalPoint(8.20, 6.0),
            LocalPoint(8.0, 6.0),
            LocalPoint(8.0, 8.0),
            LocalPoint(0.0, 8.0)
        )

        val solution = WallFootprintSolver.refresh(project)
        val structuralArea = solution.parts.asSequence()
            .filter { it.type !in setOf(WallFootprintPartType.RECESS, WallFootprintPartType.SUPERSTRUCTURE) }
            .sumOf(::partAreaM2)

        assertEquals(64.20, structuralArea, 0.01)
    }

    @Test
    fun refreshRestoresExactlyOneDeterministicMainAfterInvalidUserRetyping() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )
        val original = WallFootprintSolver.refresh(project)
        val rootId = original.parts.single { it.type == WallFootprintPartType.MAIN_TRACT }.id
        project.wallFootprintParts.forEach { part ->
            part.type = if (part.id == rootId) {
                WallFootprintPartType.PROJECTION
            } else {
                WallFootprintPartType.MAIN_TRACT
            }
            part.source = WallFootprintPartSource.USER
        }

        val restored = WallFootprintSolver.refresh(project)

        assertEquals(1, restored.parts.count { it.type == WallFootprintPartType.MAIN_TRACT })
        assertEquals(rootId, restored.parts.single { it.type == WallFootprintPartType.MAIN_TRACT }.id)
    }

    @Test
    fun semanticPartsRoundTripThroughCanonicalProjectJson() {
        val project = projectOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(12.0, 0.0),
            LocalPoint(12.0, 5.0),
            LocalPoint(7.0, 5.0),
            LocalPoint(7.0, 10.0),
            LocalPoint(0.0, 10.0)
        )
        WallFootprintSolver.refresh(project)
        val edited = project.wallFootprintParts.first { it.type != WallFootprintPartType.MAIN_TRACT }.apply {
            type = WallFootprintPartType.PROJECTION
            source = WallFootprintPartSource.USER
        }

        val restored = ProjectJson.decode(ProjectJson.encode(project))
        val restoredEdited = restored.wallFootprintParts.single { it.id == edited.id }

        assertFalse(restored.wallFootprintPartsSignature.isBlank())
        assertEquals(project.wallFootprintParts.size, restored.wallFootprintParts.size)
        assertEquals(WallFootprintPartType.PROJECTION, restoredEdited.type)
        assertEquals(WallFootprintPartSource.USER, restoredEdited.source)
    }

    @Test
    fun structuralOwnershipAlwaysPrefersHostBeforeAttachedParts() {
        val context = WallFootprintSolver.Context(
            origin,
            listOf(
                WallFootprintSolver.Context.LocalPart(
                    "recess", WallFootprintPartType.RECESS,
                    listOf(
                        LocalPoint(3.0, 2.0), LocalPoint(5.0, 2.0),
                        LocalPoint(5.0, 4.0), LocalPoint(3.0, 4.0)
                    ), 4.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    "projection", WallFootprintPartType.PROJECTION,
                    listOf(
                        LocalPoint(8.0, 2.0), LocalPoint(12.0, 2.0),
                        LocalPoint(12.0, 5.0), LocalPoint(8.0, 5.0)
                    ), 12.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    "wing", WallFootprintPartType.SEPARATE_WING,
                    listOf(
                        LocalPoint(6.0, 1.0), LocalPoint(11.0, 1.0),
                        LocalPoint(11.0, 7.0), LocalPoint(6.0, 7.0)
                    ), 30.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    "main", WallFootprintPartType.MAIN_TRACT,
                    listOf(
                        LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
                        LocalPoint(10.0, 8.0), LocalPoint(0.0, 8.0)
                    ), 80.0
                )
            )
        )

        assertEquals("main", context.structuralPartAt(9.0, 3.0)?.id)
        assertEquals("wing", context.structuralPartAt(10.5, 3.0)?.id)
        assertEquals("projection", context.structuralPartAt(11.5, 3.0)?.id)
        assertEquals("main", context.structuralPartAt(4.0, 3.0)?.id)
        assertEquals(
            context.structuralPartAt(9.0, 3.0)?.id,
            context.partsAt(9.0, 3.0).firstOrNull()?.id
        )
        assertFalse(context.sameStructuralPart(4.0, 3.0, 40.0, 40.0))
        assertTrue(
            context.priorityOf(WallFootprintPartType.MAIN_TRACT) <
                context.priorityOf(WallFootprintPartType.SEPARATE_WING)
        )
        assertTrue(
            context.priorityOf(WallFootprintPartType.SEPARATE_WING) <
                context.priorityOf(WallFootprintPartType.PROJECTION)
        )
        assertTrue(
            context.priorityOf(WallFootprintPartType.PROJECTION) <
                context.priorityOf(WallFootprintPartType.RECESS)
        )
    }

    private fun projectOf(vararg points: LocalPoint): RoofProject = RoofProject(
        centerLat = origin.lat,
        centerLon = origin.lon,
        geometryGridOriginLat = origin.lat,
        geometryGridOriginLon = origin.lon,
        geometryGridRotationDeg = 0.0,
        polygon = points.map { Geometry.toGeo(it, origin) }.toMutableList(),
        wallFootprint = points.map { Geometry.toGeo(it, origin) }.toMutableList()
    )

    private fun partAreaM2(part: WallFootprintPart): Double {
        val points = part.polygon.map { Geometry.toLocal(it, origin) }
        return kotlin.math.abs(points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        } / 2.0)
    }

    private fun rectangleOverlapM2(a: WallFootprintPart, b: WallFootprintPart): Double {
        val first = a.polygon.map { Geometry.toLocal(it, origin) }
        val second = b.polygon.map { Geometry.toLocal(it, origin) }
        val width = (minOf(first.maxOf { it.x }, second.maxOf { it.x }) -
            maxOf(first.minOf { it.x }, second.minOf { it.x })).coerceAtLeast(0.0)
        val height = (minOf(first.maxOf { it.y }, second.maxOf { it.y }) -
            maxOf(first.minOf { it.y }, second.minOf { it.y })).coerceAtLeast(0.0)
        return width * height
    }
}
