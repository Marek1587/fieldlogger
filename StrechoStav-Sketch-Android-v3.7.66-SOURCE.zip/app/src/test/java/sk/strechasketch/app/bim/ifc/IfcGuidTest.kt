package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import java.util.UUID

class IfcGuidTest {
    @Test fun compressedGuidIsStandardLengthStableAndValid() {
        assertEquals("0000000000000000000000", IfcGuid.compress(UUID(0L, 0L)))
        val first = IfcGuid.fromIdentity("project:test:face:A")
        assertEquals(first, IfcGuid.fromIdentity("project:test:face:A"))
        assertEquals(22, first.length)
        assertTrue(IfcGuid.isValid(first))
        assertNotEquals(first, IfcGuid.fromIdentity("project:test:face:B"))
    }
}
