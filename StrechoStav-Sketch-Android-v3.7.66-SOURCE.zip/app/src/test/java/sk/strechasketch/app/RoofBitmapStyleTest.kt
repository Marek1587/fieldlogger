package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofBitmapStyleTest {
    @Test
    fun technicalProfileRemainsTheDefaultAndDoesNotEnablePdfEffects() {
        assertEquals(RoofBitmapStyle.TECHNICAL, RoofBitmapStyle.entries.first())
        val profile = RoofBitmapStyle.TECHNICAL.renderProfile()
        assertFalse(profile.usesModelSpaceMaterial)
        assertFalse(profile.usesFilmicToneMapping)
        assertFalse(profile.usesAmbientOcclusion)
        assertEquals(1.0, profile.edgeStrength, 1e-9)
    }

    @Test
    fun pdfProfileUsesCameraIndependentMaterialAndSofterEdges() {
        val profile = RoofBitmapStyle.PDF_PHOTOREALISTIC.renderProfile()
        assertTrue(profile.usesModelSpaceMaterial)
        assertTrue(profile.usesFilmicToneMapping)
        assertTrue(profile.usesAmbientOcclusion)
        assertTrue(profile.edgeStrength in 0.0..0.75)

        val grainA = RoofBitmapPhotometry.materialGrain(0.71, -0.18, 1.33)
        val grainB = RoofBitmapPhotometry.materialGrain(0.71, -0.18, 1.33)
        assertEquals(grainA, grainB, 0.0)
        assertTrue(grainA in 0.0..1.0)
    }

    @Test
    fun filmicToneMappingIsClampedAndMonotonic() {
        val black = RoofBitmapPhotometry.filmicChannel(0, 1.0, 0.0)
        val middle = RoofBitmapPhotometry.filmicChannel(128, 1.0, 0.0)
        val white = RoofBitmapPhotometry.filmicChannel(255, 1.0, 0.0)
        val highlight = RoofBitmapPhotometry.filmicChannel(255, 4.0, 1.0)
        assertEquals(0, black)
        assertTrue(middle in 1 until white)
        assertTrue(white in middle..255)
        assertTrue(highlight in white..255)
    }

    @Test
    fun ambientOcclusionDarkensContactsButNotRoofTop() {
        val wallBase = RoofBitmapPhotometry.ambientOcclusion(0f, 0.0, 0.0, 2.0, 0.0)
        val wallTop = RoofBitmapPhotometry.ambientOcclusion(0f, 2.0, 0.0, 2.0, 0.0)
        val roofTop = RoofBitmapPhotometry.ambientOcclusion(1f, 1.8, 0.0, 2.0, 0.8)
        assertTrue(wallBase > wallTop)
        assertEquals(0.0, roofTop, 1e-9)
    }
}
