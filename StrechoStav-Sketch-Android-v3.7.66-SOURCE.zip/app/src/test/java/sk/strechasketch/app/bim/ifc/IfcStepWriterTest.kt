package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import java.time.Instant
import java.util.Locale

class IfcStepWriterTest {
    @Test fun assignsStepIdsByStableKeyAndUsesLocaleIndependentDecimals() {
        val original = Locale.getDefault()
        try {
            Locale.setDefault(Locale("sk", "SK"))
            val model = Ifc43Model(
                "test.ifc", Instant.parse("2026-08-17T10:00:00Z"), "3.7.23",
                listOf(
                    Ifc43Entity("z", "IFCCARTESIANPOINT", listOf(IfcStepValue.Values(listOf(IfcStepValue.Number(1.25), IfcStepValue.Number(0.0), IfcStepValue.Number(0.0))))),
                    Ifc43Entity("a", "IFCDIRECTION", listOf(IfcStepValue.Values(listOf(IfcStepValue.Number(1.0), IfcStepValue.Number(0.0), IfcStepValue.Number(0.0)))))
                ), emptySet(), emptyMap()
            )
            val text = IfcStepWriter.write(model).toString(Charsets.US_ASCII)
            assertTrue(text.indexOf("#1=IFCDIRECTION") < text.indexOf("#2=IFCCARTESIANPOINT"))
            assertTrue(text.contains("1.25"))
            assertFalse(text.contains("1,25"))
            assertTrue(text.contains("FILE_SCHEMA(('IFC4X3_ADD2'))"))
        } finally {
            Locale.setDefault(original)
        }
    }
}
