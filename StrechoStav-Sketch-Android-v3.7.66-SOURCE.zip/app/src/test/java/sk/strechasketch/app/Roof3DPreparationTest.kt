package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.tan

class Roof3DPreparationTest {
    private val origin = GeoPoint(49.0, 18.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    @Test
    fun incompleteFaceSubdivisionBlocksEveryDownstreamSurface() {
        val topology = RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("c", 8.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("d", 0.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("r0", 2.0, 2.0, TopologyNodeType.LINE_ENDPOINT),
                TopologyNode("r1", 6.0, 2.0, TopologyNodeType.LINE_ENDPOINT)
            ),
            edges = listOf(
                TopologyEdge("ab", "a", "b", LineType.EAVE, boundary = true),
                TopologyEdge("bc", "b", "c", LineType.GABLE, boundary = true),
                TopologyEdge("cd", "c", "d", LineType.EAVE, boundary = true),
                TopologyEdge("da", "d", "a", LineType.GABLE, boundary = true),
                // A divider with no closed faces formerly left a black outline around a
                // partially generated anthracite roof.
                TopologyEdge("orphan-ridge", "r0", "r1", LineType.RIDGE)
            )
        )
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 6.0), geo(0.0, 6.0)
            ),
            roofTopology = topology,
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)

        assertTrue(prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.planeSolution.issues.any {
            it.code == "ROOF_SURFACE_EDGE_INCIDENCE"
        })
        assertTrue(RoofMeshBuilder.build(project).triangles.isEmpty())
        assertTrue(SolvedRoofSurfaceGeometry.from(prepared.graph) == null)
    }

    @Test
    fun lFootprintWithTwoGablesRidgesHipAndValleyBuildsFourRoofFaces() {
        val junction = geo(4.0, 4.0)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(16.0, 0.0), geo(16.0, 8.0),
                geo(8.0, 8.0), geo(8.0, 16.0), geo(0.0, 16.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.GABLE, 2 to LineType.EAVE,
                3 to LineType.EAVE, 4 to LineType.GABLE, 5 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(4.0, 16.0), end = junction.copy()),
                RoofLine(type = LineType.VALLEY, start = junction.copy(), end = geo(8.0, 8.0)),
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = junction.copy()),
                RoofLine(type = LineType.RIDGE, start = junction.copy(), end = geo(16.0, 4.0))
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val internalDividerEdges = prepared.graph.edges.values.filter {
            !it.boundary && it.semanticRole in setOf(
                EdgeSemantic.RIDGE, EdgeSemantic.HIP, EdgeSemantic.VALLEY
            )
        }

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message },
            !prepared.planeSolution.hasBlockingIssues)
        assertTrue(internalDividerEdges.isNotEmpty())
        assertTrue(internalDividerEdges.all { it.adjacentFaceIds.size == 2 })
        assertTrue(RoofMeshBuilder.build(project).triangles.isNotEmpty())
        assertTrue(RoofQuantityEngine.calculate(project).totals.roofAreaM2 > 0.0)
    }

    @Test
    fun roofLogoUsesUnmirroredSourceMappingForBothRenderers() {
        assertEquals(0f, StrechoStavLogo.roofSurfaceU(left = true), 0f)
        assertEquals(1f, StrechoStavLogo.roofSurfaceU(left = false), 0f)
        assertTrue(StrechoStavLogo.roofSurfaceSourceCorners(100, 40).contentEquals(
            floatArrayOf(0f, 0f, 100f, 0f, 100f, 40f, 0f, 40f)
        ))
    }

    @Test
    fun dormerRoofMeshUsesLighterMaterialAndFixed150MillimetreShell() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(10.0, 0.0), geo(10.0, 8.0), geo(0.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0,
            objects = mutableListOf(
                RoofObject(
                    id = "dormer-shell",
                    type = ObjectType.DORMER,
                    center = geo(5.0, 4.0),
                    widthMm = 1800.0,
                    heightMm = 2400.0,
                    dormerType = DormerType.TRAPEZOID,
                    superstructureHeightM = 1.2,
                    superstructureSlopeDeg = 10.0,
                    dormerOverhangMm = 250.0
                )
            )
        )
        val mesh = RoofMeshBuilder.build(project)
        assertTrue("Dormer top surfaces must use their lighter anthracite material", mesh.materials.any { it == 9f })
        assertTrue("Dormer underside must use the soffit material", mesh.materials.any { it == 6f })

        fun vertices(material: Float): List<Triple<Float, Float, Float>> = mesh.materials.indices
            .filter { mesh.materials[it] == material }
            .map { index ->
                val offset = index * 3
                Triple(mesh.triangles[offset], mesh.triangles[offset + 1], mesh.triangles[offset + 2])
            }
        val tops = vertices(9f)
        val undersides = vertices(6f)
        val normalization = mesh.objectAnchors.single { it.objectId == "dormer-shell" }.normalization
        val expected = 0.150f * normalization
        val verticalShellDepths = tops.flatMap { top ->
            undersides.mapNotNull { underside ->
                val samePlanPoint = abs(top.first - underside.first) < 1e-5f &&
                    abs(top.third - underside.third) < 1e-5f
                if (samePlanPoint) top.second - underside.second else null
            }
        }
        assertTrue(
            "A 150 mm dormer shell must exist below at least one roof corner; " +
                "expected model depth $expected, candidates=$verticalShellDepths",
            verticalShellDepths.any { depth -> abs(depth - expected) <= expected * 0.03f }
        )
    }

    @Test
    fun imperfectHipAndRidgeDrawingStillProduces3DMeshAndQuantities() {
        val lowerJunction = geo(6.18, 5.55)
        val upperJunction = geo(5.84, 12.62)
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 18.0), geo(0.0, 18.0)
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 0.0), end = lowerJunction.copy()),
                RoofLine(type = LineType.RIDGE, start = lowerJunction.copy(), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(0.0, 18.0), end = upperJunction.copy()),
                RoofLine(type = LineType.HIP, start = geo(12.0, 18.0), end = upperJunction.copy())
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val quantities = RoofQuantityEngine.calculate(project)
        val mesh = RoofMeshBuilder.build(project)

        assertEquals(4, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.code }, !prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.graph.nodes.values.all { it.z.isFinite() })
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
        assertTrue(quantities.totals.perimeterM > 0.0)
        assertTrue(mesh.triangles.isNotEmpty())
        val solvedSurface = requireNotNull(SolvedRoofSurfaceGeometry.from(prepared.graph))
        assertTrue(mesh.roofBoundaryEdges.isNotEmpty())
        assertEquals(solvedSurface.topEdgeSegments.size * 6, mesh.roofBoundaryEdges.size)
        assertTrue(mesh.internalEdges.isNotEmpty())
        assertEquals(mesh.triangles.size / 3, mesh.materials.size)
        assertTrue(mesh.materials.any { it == 1f })
        assertTrue(mesh.materials.any { it == 0f })
        assertEquals(2, mesh.logoFaceCount)
        assertEquals(2, mesh.logoQuads.size)
        assertEquals(prepared.graph.faces.size, mesh.logoCandidates.size)
        assertTrue(mesh.logoQuads.all { it.faceId in prepared.graph.faces })
        assertTrue(mesh.logoQuads.all { quad ->
            val abX = quad.topRight.x - quad.topLeft.x
            val abZ = quad.topRight.z - quad.topLeft.z
            val acX = quad.bottomRight.x - quad.topLeft.x
            val acZ = quad.bottomRight.z - quad.topLeft.z
            // Model Z is -north; this winding keeps the source SVG readable, not mirrored.
            abZ * acX - abX * acZ < 0f
        })
        assertTrue(mesh.logoQuads.all { quad ->
            val plane = prepared.graph.faces.getValue(quad.faceId).plane!!
            val topX = (quad.topLeft.x + quad.topRight.x) / 2f
            val topZ = (quad.topLeft.z + quad.topRight.z) / 2f
            val bottomX = (quad.bottomLeft.x + quad.bottomRight.x) / 2f
            val bottomZ = (quad.bottomLeft.z + quad.bottomRight.z) / 2f
            // Plane gradient is uphill; the bottom of the logo must point downhill.
            (bottomX - topX) * plane.a - (bottomZ - topZ) * plane.b < -1e-7
        })
        assertEquals(12, StrechoStavLogo.originalSvgPathCount)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        assertEquals(4, planDimensions.size)
        assertEquals(2, planDimensions.map { it.dimensionId }.toSet().size)
        assertTrue(planDimensions.all { it.linkedEdgeIds.size == 2 })
        val modelBaseY = mesh.materials.indices
            .filter { mesh.materials[it] < 0.5f }
            .minOf { mesh.triangles[it * 3 + 1] }
        assertTrue(planDimensions.all { abs(it.witnessStart.y - modelBaseY) < 1e-5f })
        assertTrue(planDimensions.all { abs(it.witnessEnd.y - modelBaseY) < 1e-5f })
        assertTrue(planDimensions.all { it.start.y < it.witnessStart.y })
        assertTrue(planDimensions.all { it.end.y < it.witnessEnd.y })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.WALL_HEIGHT })
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.OVERHANG })
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
        assertTrue(mesh.dimensions.any { it.kind == RoofDimensionKind.SLOPE })
    }

    @Test
    fun unsplitGableFootprintBuildsMasonryToRidgeWithoutFacadeSplitLine() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.GABLE,
                2 to LineType.EAVE, 3 to LineType.GABLE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            ),
            slopeDeg = 35.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val ordinaryWallTop = mesh.dimensions.first { it.kind == RoofDimensionKind.WALL_HEIGHT }.end.y
        val wallVertexHeights = mesh.materials.indices
            .filter { mesh.materials[it] == 0f }
            .map { mesh.triangles[it * 3 + 1] }

        assertTrue(mesh.triangles.isNotEmpty())
        assertTrue("Murivo pod štítom musí dosiahnuť nad rímsu až k hrebeňu",
            wallVertexHeights.max() > ordinaryWallTop + 1e-4f)
        assertEquals("Štyri skutočné strany obrysu, bez deliacej čiary pri hrebeni",
            project.polygon.size * 6, mesh.wallEdges.size)
    }

    @Test
    fun staleRectangularWallFootprintCannotReplaceSixCornerBuildingPlan() {
        val lPolygon = mutableListOf(
            geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 4.0),
            geo(14.0, 4.0), geo(14.0, 10.0), geo(0.0, 10.0)
        )
        val project = RoofProject(
            polygon = lPolygon,
            wallFootprint = mutableListOf(
                geo(0.0, 0.0), geo(14.0, 0.0), geo(14.0, 10.0), geo(0.0, 10.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }

        assertTrue(mesh.triangles.isNotEmpty())
        assertEquals(6, planDimensions.size)
        assertEquals(1, mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
            .map { it.dimensionId }.toSet().size)
    }

    @Test
    fun planDimensionsMeasureWallFootprintAndOverhangIsOneSharedParameter() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            wallFootprint = mutableListOf(
                geo(0.5, 0.5), geo(11.5, 0.5), geo(11.5, 7.5), geo(0.5, 7.5)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )

        val mesh = RoofMeshBuilder.build(project)
        val planValues = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
            .map { it.lengthM }.toSet()
        val overhangs = mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }

        assertTrue(planValues.any { abs(it - 11.0) < 1e-3 })
        assertTrue(planValues.any { abs(it - 7.0) < 1e-3 })
        assertEquals(1, overhangs.map { it.dimensionId }.toSet().size)
        assertTrue(overhangs.all { abs(it.lengthM - 0.5) < 1e-3 })
    }

    @Test
    fun flatRoofWithThreeParapetsAndOneEaveBuildsSlopedDeckAndLevelParapet() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(13.0, 0.0), geo(13.0, 10.0), geo(0.0, 10.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.ATTIC,
                1 to LineType.ATTIC,
                2 to LineType.EAVE,
                3 to LineType.ATTIC
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0,
            atticHeightM = 0.3,
            atticWidthM = 0.28
        )

        val prepared = Roof3DPreparation.prepare(project)
        val mesh = RoofMeshBuilder.build(project)
        val quantities = RoofQuantityEngine.calculate(project)

        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(2.0)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        val eave = prepared.graph.edges.values.single { it.semanticRole == EdgeSemantic.EAVE }
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.startNodeId).z, 1e-6)
        assertEquals(3.0, prepared.graph.nodes.getValue(eave.endNodeId).z, 1e-6)
        assertTrue(prepared.graph.nodes.values.map { it.z }.distinct().size > 1)
        assertTrue(mesh.triangles.isNotEmpty())
        val padVertices = mesh.materials.indices.filter { mesh.materials[it] in 1.5f..<2.5f }
        assertEquals(30, padVertices.size)
        val padX = padVertices.map { mesh.triangles[it * 3] }
        val padZ = padVertices.map { mesh.triangles[it * 3 + 2] }
        assertTrue(padX.max() - padX.min() > 2.8f)
        assertTrue(padZ.max() - padZ.min() > 2.3f)
        assertTrue("Doska musí mať vonkajší a dva jemné vnútorné rámy", mesh.padEdges.size >= 72)
        val atticDimension = mesh.dimensions.first { it.kind == RoofDimensionKind.ATTIC_HEIGHT }
        assertEquals(0.3, atticDimension.lengthM, 1e-9)
        val atticWidthDimension = mesh.dimensions.first { it.kind == RoofDimensionKind.ATTIC_WIDTH }
        assertEquals(0.28, atticWidthDimension.lengthM, 1e-9)
        val vertexHeights = mesh.triangles.indices.filter { it % 3 == 1 }.map { mesh.triangles[it] }
        val maximum = vertexHeights.max()
        assertTrue(vertexHeights.count { abs(it - maximum) < 1e-5f } >= 6)
        assertTrue(quantities.totals.roofAreaM2 > quantities.totals.footprintAreaM2)
    }

    @Test
    fun overhangSolverOffsetsOnlyEaveAndBuildsStnSoffitShell() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(13.0, 0.0), geo(13.0, 10.0), geo(0.0, 10.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.ATTIC,
                1 to LineType.ATTIC,
                2 to LineType.EAVE,
                3 to LineType.ATTIC
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )
        val prepared = Roof3DPreparation.prepare(project)
        val footprint = RoofOverhangSolver.selectiveWallFootprint(prepared.graph, 0.60)!!
        val ordered = RoofTopologyMigration.orderedBoundary(prepared.graph.toTopology())!!
        val original = ordered.first.map { prepared.graph.nodes.getValue(it) }
        ordered.second.forEachIndexed { index, topologyEdge ->
            val a = original[index]
            val b = original[(index + 1) % original.size]
            val length = hypot(b.x - a.x, b.y - a.y)
            val supportDistance = abs(
                (footprint[index].x - a.x) * (b.y - a.y) -
                    (footprint[index].y - a.y) * (b.x - a.x)
            ) / length
            val role = prepared.graph.edges.getValue(topologyEdge.id).semanticRole
            assertEquals(if (role == EdgeSemantic.EAVE) 0.60 else 0.0, supportDistance, 1e-6)
        }

        val shell = RoofOverhangSolver.solve(prepared.planeSolution.graph, footprint)
        assertEquals(1, shell.eligibleEdgeIds.size)
        assertEquals(1, shell.sections.size)
        val section = shell.sections.single()
        assertEquals(0.60, section.overhangM, 1e-6)
        assertEquals(0.20, section.flatDepthM, 1e-9)
        assertEquals(section.outerBottomA.z, section.flatInnerA.z, 1e-9)
        assertEquals(section.outerBottomB.z, section.flatInnerB.z, 1e-9)
        assertTrue("Za 200 mm rovným podhľadom musí spodok pokračovať po sklone krokvy",
            abs(section.wallInnerA.z - section.flatInnerA.z) > 1e-4)

        project.wallFootprint = footprint.map { Geometry.toGeo(it, prepared.graph.origin) }.toMutableList()
        val mesh = RoofMeshBuilder.build(project)
        assertEquals(1, mesh.overhangSectionCount)
        assertTrue("Soffit must use its dedicated grey material", mesh.materials.any { it == 6f })
        val overhangDimensions = mesh.dimensions.filter { it.kind == RoofDimensionKind.OVERHANG }
        assertTrue(overhangDimensions.isNotEmpty())
        assertTrue(overhangDimensions.all { dimension ->
            dimension.linkedEdgeIds.all { id ->
                prepared.graph.edges[id]?.semanticRole == EdgeSemantic.EAVE
            }
        })
    }

    @Test
    fun oneAtticAndFiveEavesProduceFiveOverhangSections() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(14.0, 0.0), geo(14.0, 6.0),
                geo(8.0, 6.0), geo(8.0, 12.0), geo(0.0, 12.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.ATTIC,
                1 to LineType.EAVE,
                2 to LineType.EAVE,
                3 to LineType.EAVE,
                4 to LineType.EAVE,
                5 to LineType.EAVE
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            wallHeightM = 3.0
        )
        val prepared = Roof3DPreparation.prepare(project)
        val footprint = RoofOverhangSolver.selectiveWallFootprint(prepared.graph, 0.40)!!
        val shell = RoofOverhangSolver.solve(prepared.planeSolution.graph, footprint)

        assertEquals(5, shell.eligibleEdgeIds.size)
        assertEquals(5, shell.sections.size)
        assertTrue(shell.sections.none { section ->
            prepared.graph.edges[section.edgeId]?.semanticRole == EdgeSemantic.ATTIC
        })
    }

    @Test
    fun hipCornersUseOneSharedMiterNodeInsteadOfOverlappingStrips() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE,
                2 to LineType.EAVE, 3 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(4.0, 4.0), end = geo(8.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(0.0, 0.0), end = geo(4.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(0.0, 8.0), end = geo(4.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(12.0, 0.0), end = geo(8.0, 4.0)),
                RoofLine(type = LineType.HIP, start = geo(12.0, 8.0), end = geo(8.0, 4.0))
            ),
            slopeDeg = 30.0,
            wallHeightM = 3.0
        )
        val prepared = Roof3DPreparation.prepare(project)
        val footprint = RoofOverhangSolver.selectiveWallFootprint(prepared.graph, 0.60)!!
        val shell = RoofOverhangSolver.solve(prepared.planeSolution.graph, footprint)

        assertEquals(4, shell.sections.size)
        val endpoints = shell.sections.flatMap { section ->
            listOf(
                Triple(section.outerTopA.id, section.flatInnerA, section.wallInnerA),
                Triple(section.outerTopB.id, section.flatInnerB, section.wallInnerB)
            )
        }.groupBy { it.first }
        endpoints.values.forEach { corner ->
            assertEquals(2, corner.size)
            assertEquals(corner[0].second.x, corner[1].second.x, 1e-9)
            assertEquals(corner[0].second.y, corner[1].second.y, 1e-9)
            assertEquals(corner[0].second.z, corner[1].second.z, 1e-9)
            assertEquals(corner[0].third.x, corner[1].third.x, 1e-9)
            assertEquals(corner[0].third.y, corner[1].third.y, 1e-9)
            assertEquals(corner[0].third.z, corner[1].third.z, 1e-9)
        }
    }

    @Test
    fun gableOverhangUsesSolverRidgePointAndStaysContinuousAtTheApex() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.GABLE,
                2 to LineType.EAVE, 3 to LineType.GABLE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            ),
            slopeDeg = 35.0,
            wallHeightM = 3.0
        )
        val prepared = Roof3DPreparation.prepare(project)
        val footprint = RoofOverhangSolver.selectiveWallFootprint(prepared.graph, 0.60)!!
        val shell = RoofOverhangSolver.solve(prepared.planeSolution.graph, footprint)
        val gables = shell.sections.filter { it.semanticRole == EdgeSemantic.GABLE }

        assertTrue("Presah musí vzniknúť aj na štítovej hrane", gables.isNotEmpty())
        val apex = gables.flatMap { listOf(it.outerTopA, it.outerTopB) }.maxBy { it.z }
        assertTrue("Riešiteľ musí doplniť bod štítu pri hrebeni", apex.z > project.wallHeightM)
        val apexSupports = gables.flatMap { section ->
            listOf(
                section.outerTopA.id to section.wallInnerA,
                section.outerTopB.id to section.wallInnerB
            )
        }.filter { it.first == apex.id }.map { it.second }
        assertTrue(apexSupports.size >= 2)
        assertTrue(apexSupports.all { it.id == apexSupports.first().id })
        assertTrue(apexSupports.all {
            abs(it.x - apexSupports.first().x) < 1e-9 &&
                abs(it.y - apexSupports.first().y) < 1e-9 &&
                abs(it.z - apexSupports.first().z) < 1e-9
        })
    }

    @Test
    fun explicitFlatShapeNeedsNoRidgeOrInternalLine() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(9.0, 0.0), geo(9.0, 7.0), geo(0.0, 7.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.EAVE, 2 to LineType.EAVE, 3 to LineType.EAVE
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 1.5,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        assertEquals(1, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message }, !prepared.planeSolution.hasBlockingIssues)
        val plane = prepared.graph.faces.values.single().plane!!
        assertEquals(tan(Math.toRadians(1.5)), kotlin.math.hypot(plane.a, plane.b), 1e-6)
        assertTrue(RoofMeshBuilder.build(project).triangles.isNotEmpty())
    }

    @Test
    fun planDimensionExtensionsArePerpendicularToFoundationWalls() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 1.0), geo(11.0, 9.0), geo(-1.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        RoofMeshBuilder.build(project).dimensions
            .filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
            .forEach { dimension ->
                val wallX = dimension.witnessEnd.x - dimension.witnessStart.x
                val wallZ = dimension.witnessEnd.z - dimension.witnessStart.z
                val extensionX = dimension.start.x - dimension.witnessStart.x
                val extensionZ = dimension.start.z - dimension.witnessStart.z
                assertEquals(0.0, (wallX * extensionX + wallZ * extensionZ).toDouble(), 1e-5)
            }
    }

    @Test
    fun pairedPlanDimensionsKeepOneDeterministicPhysicalSide() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        val allPlanDimensions = RoofMeshBuilder.build(project).dimensions
            .filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        val fixedPlanDimensions = RoofDimensionPlacement.stablePlanCandidates(allPlanDimensions)

        assertEquals(4, allPlanDimensions.size)
        assertEquals(2, fixedPlanDimensions.size)
        assertEquals(2, fixedPlanDimensions.map { it.dimensionId }.toSet().size)
        allPlanDimensions.groupBy { it.dimensionId }.forEach { (dimensionId, candidates) ->
            val expected = candidates.minWith(compareBy<RoofDimension3D> { it.edgeId }
                .thenBy { it.start.x }.thenBy { it.start.z })
            assertEquals(expected.edgeId, fixedPlanDimensions.single { it.dimensionId == dimensionId }.edgeId)
        }
    }

    @Test
    fun roofObjectsExposeAllRequiredParametricDimensions() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0,
            objects = mutableListOf(
                RoofObject(
                    type = ObjectType.CHIMNEY, center = geo(3.0, 3.0),
                    widthMm = 700.0, heightMm = 900.0, value = 1.2
                ),
                RoofObject(
                    type = ObjectType.ROOF_WINDOW, center = geo(8.0, 4.0),
                    widthMm = 780.0, heightMm = 1180.0
                ),
                RoofObject(
                    type = ObjectType.HATCH, center = geo(7.0, 6.0),
                    widthMm = 650.0, heightMm = 900.0
                ),
                RoofObject(
                    type = ObjectType.VENT, center = geo(5.0, 5.0), diameterMm = 180.0
                )
            )
        )
        val mesh = RoofMeshBuilder.build(project)
        val dimensions = mesh.dimensions
        assertEquals(0.7, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_WIDTH }.lengthM, 1e-9)
        assertEquals(0.9, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_LENGTH }.lengthM, 1e-9)
        assertEquals(1.2, dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_HEIGHT }.lengthM, 1e-9)
        assertEquals(0.78, dimensions.single { it.kind == RoofDimensionKind.ROOF_WINDOW_WIDTH }.lengthM, 1e-9)
        assertEquals(1.18, dimensions.single { it.kind == RoofDimensionKind.ROOF_WINDOW_LENGTH }.lengthM, 1e-9)
        assertEquals(0.65, dimensions.single { it.kind == RoofDimensionKind.HATCH_WIDTH }.lengthM, 1e-9)
        assertEquals(0.9, dimensions.single { it.kind == RoofDimensionKind.HATCH_LENGTH }.lengthM, 1e-9)
        assertEquals(0.18, dimensions.single { it.kind == RoofDimensionKind.VENT_DIAMETER }.lengthM, 1e-9)
        assertTrue(mesh.materials.any { it == 4f })
        assertTrue(mesh.materials.any { it == 5f })
        val chimneyWidth = dimensions.single { it.kind == RoofDimensionKind.CHIMNEY_WIDTH }
        val prepared = Roof3DPreparation.prepare(project)
        val chimneyLocal = Geometry.toLocal(project.objects.first().center, prepared.graph.origin)
        val chimneyFace = prepared.graph.faces.values.first { face ->
            val polygon = face.orderedNodeIds.map { id -> prepared.graph.nodes.getValue(id) }
                .map { LocalPoint(it.x, it.y) }
            Geometry.pointInPolygon(chimneyLocal, polygon)
        }
        val plane = chimneyFace.plane!!
        val widthX = chimneyWidth.end.x - chimneyWidth.start.x
        val widthZ = chimneyWidth.end.z - chimneyWidth.start.z
        // Model Z is deliberately -north so its top view agrees with the non-mirrored 2D map.
        assertEquals(0.0, widthX * plane.a - widthZ * plane.b, 1e-5)

        val anchors = RoofMeshBuilder.build(project).objectAnchors
        assertTrue(anchors.all { it.outerNormal.y > 0f })
        val south = anchors.single { it.type == ObjectType.ROOF_WINDOW }
        val north = anchors.single { it.type == ObjectType.HATCH }
        assertTrue(north.localY > south.localY)
        assertTrue("Sever nesmie byť v 3D zrkadlovo obrátený", north.center.z < south.center.z)
    }

    @Test
    fun modelTransformPreservesRightAnglesAndPadFollowsLongestWall() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 3.0), geo(10.75, 8.0), geo(-1.25, 5.0)
            ),
            shape = RoofShape.FLAT,
            slopeDeg = 2.0
        )
        val mesh = RoofMeshBuilder.build(project)
        val plan = mesh.dimensions.filter { it.kind == RoofDimensionKind.PLAN_LENGTH }
        val vectors = plan.map { dimension ->
            (dimension.witnessEnd.x - dimension.witnessStart.x) to
                (dimension.witnessEnd.z - dimension.witnessStart.z)
        }
        vectors.forEachIndexed { index, vector ->
            assertTrue(vectors.withIndex().any { (otherIndex, other) ->
                otherIndex != index && abs(vector.first * other.first + vector.second * other.second) < 1e-5
            })
        }

        fun padSegmentLength(offset: Int): Double {
            val dx = mesh.padEdges[offset + 3] - mesh.padEdges[offset]
            val dz = mesh.padEdges[offset + 5] - mesh.padEdges[offset + 2]
            return hypot(dx.toDouble(), dz.toDouble())
        }
        assertTrue("Prvá os dosky má sledovať najdlhšiu stenu", padSegmentLength(0) > padSegmentLength(6))
    }

    @Test
    fun preparationAttachesRidgeWithoutMovingConfirmedGableBoundary() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(4.20, 0.0), geo(8.0, 0.0),
                geo(8.0, 14.0), geo(3.75, 14.0), geo(0.0, 14.0),
                geo(0.0, 9.0), geo(1.2, 9.0), geo(1.2, 7.0), geo(0.0, 7.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.GABLE, 1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.GABLE, 4 to LineType.GABLE,
                5 to LineType.EAVE, 6 to LineType.GABLE,
                7 to LineType.EAVE, 8 to LineType.GABLE, 9 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(
                    type = LineType.RIDGE,
                    start = geo(4.18, 0.02),
                    end = geo(3.76, 13.98)
                )
            ),
            slopeDeg = 40.0,
            wallHeightM = 4.8
        )

        val prepared = Roof3DPreparation.prepare(project)
        val ridge = prepared.topology.edges.single { !it.boundary && it.type == LineType.RIDGE }
        val boundaryIds = RoofTopologyMigration.orderedBoundary(prepared.topology)!!.first
        val nodeById = prepared.topology.nodes.associateBy { it.id }

        assertTrue(prepared.topologyWasAdjusted)
        assertTrue(boundaryIds.contains(ridge.startNodeId))
        assertTrue(boundaryIds.contains(ridge.endNodeId))
        assertEquals(4.20, nodeById.getValue(ridge.startNodeId).x, 1e-9)
        assertEquals(3.75, nodeById.getValue(ridge.endNodeId).x, 1e-9)
        assertEquals(0.0, nodeById.getValue(ridge.startNodeId).y, 1e-9)
        assertEquals(14.0, nodeById.getValue(ridge.endNodeId).y, 1e-9)
        assertEquals(2, prepared.graph.faces.size)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message },
            !prepared.planeSolution.hasBlockingIssues)
    }

    @Test
    fun preparationNeverWritesDerivedIncidenceBackIntoProject() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(8.0, 0.0), geo(8.0, 14.0), geo(0.0, 14.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.GABLE, 1 to LineType.EAVE,
                2 to LineType.GABLE, 3 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(4.0, 0.0), end = geo(4.0, 14.0))
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )
        val polygonBefore = project.polygon.map(GeoPoint::copy)
        val linesBefore = project.lines.map { it.copy(start = it.start.copy(), end = it.end.copy()) }
        val topologyBefore = project.roofTopology
        val graphBefore = project.roofGraph

        val prepared = Roof3DPreparation.prepare(project)

        assertEquals(polygonBefore, project.polygon)
        assertEquals(linesBefore, project.lines)
        assertEquals(topologyBefore, project.roofTopology)
        assertEquals(graphBefore, project.roofGraph)
        assertTrue(project.geometryGridOriginLat.isNaN())
        assertTrue(project.geometryGridOriginLon.isNaN())
        assertTrue(project.geometryGridRotationDeg.isNaN())
        assertTrue(prepared.topology.edges.count { it.boundary } > project.polygon.size)
        assertEquals(4, project.polygon.size)
        assertEquals(1, project.lines.size)
    }

    @Test
    fun offCentreGableRidgeDerivesTwoCompatiblePitchAngles() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(4.0, 0.0), geo(10.0, 0.0),
                geo(10.0, 14.0), geo(4.0, 14.0), geo(0.0, 14.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.GABLE, 1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.GABLE, 4 to LineType.GABLE,
                5 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(4.0, 0.0), end = geo(4.0, 14.0))
            ),
            slopeDeg = 40.0,
            wallHeightM = 3.0
        )

        val prepared = Roof3DPreparation.prepare(project)
        val slopes = prepared.graph.faces.values.mapNotNull { it.slopeConstraint?.angleDeg }.sorted()
        val ridge = prepared.graph.edges.values.single { it.semanticRole == EdgeSemantic.RIDGE }
        val ridgeHeights = listOf(ridge.startNodeId, ridge.endNodeId)
            .map { prepared.graph.nodes.getValue(it).z }

        assertEquals(2, slopes.size)
        assertEquals(40.0, slopes.first(), 1e-8)
        assertTrue(slopes.last() > 40.0)
        assertEquals(ridgeHeights[0], ridgeHeights[1], 1e-8)
        assertTrue(prepared.planeSolution.issues.joinToString { it.message },
            !prepared.planeSolution.hasBlockingIssues)
        assertTrue(prepared.planeSolution.issues.none { it.code == "APPROXIMATED_HARD_CONSTRAINTS" })
    }

    @Test
    fun staleEqualGablePitchesAreRecomputedAfterAsymmetricPlanChange() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(3.6, 0.0), geo(11.3, 0.0),
                geo(11.3, 16.0), geo(3.6, 16.0), geo(0.0, 16.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.GABLE, 1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.GABLE, 4 to LineType.GABLE,
                5 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(3.6, 0.0), end = geo(3.6, 16.0))
            ),
            slopeDeg = 40.0,
            wallHeightM = 4.8
        )
        val initial = Roof3DPreparation.prepare(project).graph
        val stale = initial.copy(faces = initial.faces.mapValues { (_, face) ->
            val old = face.slopeConstraint!!
            face.copy(
                plane = null,
                slopeConstraint = old.copy(
                    angleDeg = 40.0,
                    source = SlopeConstraintSource.LEGACY
                )
            )
        })

        val corrected = GableTractSlopeSolver.apply(stale, 40.0)
        val ridge = corrected.edges.values.single { it.semanticRole == EdgeSemantic.RIDGE }
        val ridgeStart = corrected.nodes.getValue(ridge.startNodeId)
        val ridgeEnd = corrected.nodes.getValue(ridge.endNodeId)
        val ridgeX = (ridgeStart.x + ridgeEnd.x) / 2.0
        val faceRuns = corrected.faces.values.associateWith { face ->
            val eave = face.orderedEdgeIds.mapNotNull(corrected.edges::get)
                .single { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
            val a = corrected.nodes.getValue(eave.startNodeId)
            val b = corrected.nodes.getValue(eave.endNodeId)
            abs((a.x + b.x) / 2.0 - ridgeX)
        }
        val longFace = faceRuns.maxByOrNull { it.value }!!.key
        val shortFace = faceRuns.minByOrNull { it.value }!!.key
        val longSlope = longFace.slopeConstraint!!
        val shortSlope = shortFace.slopeConstraint!!
        val longRise = tan(Math.toRadians(longSlope.angleDeg)) * faceRuns.getValue(longFace)
        val shortRise = tan(Math.toRadians(shortSlope.angleDeg)) * faceRuns.getValue(shortFace)

        assertEquals(7.7, faceRuns.getValue(longFace), 1e-6)
        assertEquals(3.6, faceRuns.getValue(shortFace), 1e-6)
        assertEquals(40.0, longSlope.angleDeg, 1e-8)
        assertTrue(shortSlope.angleDeg > 55.0)
        assertEquals(longRise, shortRise, 1e-8)
        assertEquals(SlopeConstraintSource.AUTOMATIC_GABLE, longSlope.source)
        assertEquals(SlopeConstraintSource.AUTOMATIC_GABLE, shortSlope.source)
    }

    @Test
    fun userPitchOnEitherFaceDrivesOneCommonRidgeHeight() {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(3.6, 0.0), geo(11.3, 0.0),
                geo(11.3, 10.0), geo(3.6, 10.0), geo(0.0, 10.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.GABLE, 1 to LineType.GABLE, 2 to LineType.EAVE,
                3 to LineType.GABLE, 4 to LineType.GABLE, 5 to LineType.EAVE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(3.6, 0.0), end = geo(3.6, 10.0))
            ),
            slopeDeg = 40.0
        )
        val initial = Roof3DPreparation.prepare(project).graph
        val shortFace = initial.faces.values.minByOrNull { face ->
            face.orderedEdgeIds.mapNotNull(initial.edges::get)
                .filter { it.semanticRole == EdgeSemantic.EAVE }
                .maxOfOrNull { edge ->
                    val a = initial.nodes.getValue(edge.startNodeId)
                    val b = initial.nodes.getValue(edge.endNodeId)
                    abs(((a.x + b.x) / 2.0) - 3.6)
                } ?: Double.MAX_VALUE
        }!!
        val manuallyEdited = initial.copy(faces = initial.faces.mapValues { (id, face) ->
            if (id == shortFace.id) face.copy(
                plane = null,
                slopeConstraint = face.slopeConstraint!!.copy(
                    angleDeg = 35.0,
                    source = SlopeConstraintSource.USER
                )
            ) else face.copy(
                plane = null,
                slopeConstraint = face.slopeConstraint?.copy(source = SlopeConstraintSource.AUTOMATIC_GABLE)
            )
        })

        val corrected = GableTractSlopeSolver.apply(manuallyEdited, 40.0)
        val edited = corrected.faces.getValue(shortFace.id).slopeConstraint!!
        val other = corrected.faces.values.single { it.id != shortFace.id }.slopeConstraint!!

        assertEquals(35.0, edited.angleDeg, 1e-8)
        assertEquals(SlopeConstraintSource.USER, edited.source)
        assertTrue(other.angleDeg < 35.0)
        assertEquals(SlopeConstraintSource.AUTOMATIC_GABLE, other.source)
    }
}
