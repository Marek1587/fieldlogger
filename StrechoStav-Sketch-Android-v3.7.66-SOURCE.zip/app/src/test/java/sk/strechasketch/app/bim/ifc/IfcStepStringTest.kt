package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test

class IfcStepStringTest {
    @Test fun escapesApostropheBackslashAndSlovakUnicode() {
        val value = IfcStepString.quote("Žofia O'Connor\\strecha")
        assertTrue(value.startsWith("'\\X2\\017D\\X0\\ofia O''Connor"))
        assertTrue(value.contains("\\X2\\005C\\X0\\"))
        assertFalse(value.contains("Ž"))
        assertTrue(value.endsWith("'"))
    }
}
