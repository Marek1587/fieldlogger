package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.json.JSONObject
import kotlin.math.tan

class ChimneyHeightSolverTest {
    private fun graph(
        plane: RoofPlane,
        slopeDeg: Double,
        ridge: Boolean = true,
        attic: Boolean = false
    ): Pair<RoofGraph, GraphFace> {
        val nodes = linkedMapOf(
            "A" to GraphNode("A", -5.0, 0.0, 5.0),
            "B" to GraphNode("B", 5.0, 0.0, 5.0),
            "C" to GraphNode("C", 5.0, 6.0, plane.zAt(5.0, 6.0)),
            "D" to GraphNode("D", -5.0, 6.0, plane.zAt(-5.0, 6.0))
        )
        val edges = linkedMapOf(
            "AB" to GraphEdge(
                "AB", "A", "B", boundary = !ridge,
                semanticRole = if (ridge) EdgeSemantic.RIDGE else if (attic) EdgeSemantic.ATTIC else EdgeSemantic.EAVE,
                adjacentFaceIds = setOf("F")
            ),
            "BC" to GraphEdge("BC", "B", "C", true, EdgeSemantic.EAVE, setOf("F")),
            "CD" to GraphEdge("CD", "C", "D", true, EdgeSemantic.EAVE, setOf("F")),
            "DA" to GraphEdge("DA", "D", "A", true, EdgeSemantic.EAVE, setOf("F"))
        )
        val face = GraphFace(
            "F", listOf("A", "B", "C", "D"), edges.keys.toList(), 60.0,
            plane = plane,
            slopeConstraint = FaceSlopeConstraint(slopeDeg, 0.0, 1.0)
        )
        return RoofGraph(GeoPoint(49.0, 18.0), nodes, edges, mapOf("F" to face)) to face
    }

    @Test
    fun chimneyWithinTwoMetresEndsAtRidgePlus650Millimetres() {
        val plane = RoofPlane(0.0, -tan(Math.toRadians(30.0)), 5.0)
        val (graph, face) = graph(plane, 30.0)
        val result = ChimneyHeightSolver.solve(graph, face, LocalPoint(0.0, 1.0), 0.3, 30.0)!!
        assertEquals(ChimneyHeightRule.RIDGE_WITHIN_TWO_METRES, result.rule)
        assertEquals(5.65, result.topElevationM, 1e-9)
        assertEquals(1.0, result.ridgeDistanceM!!, 1e-9)
    }

    @Test
    fun distantChimneyUsesTenDegreeClearancePlaneAnd650Millimetres() {
        val plane = RoofPlane(0.0, -tan(Math.toRadians(30.0)), 5.0)
        val (graph, face) = graph(plane, 30.0)
        val result = ChimneyHeightSolver.solve(graph, face, LocalPoint(0.0, 4.0), 0.3, 30.0)!!
        val expected = 5.0 - tan(Math.toRadians(10.0)) * 4.0 + 0.65
        assertEquals(ChimneyHeightRule.RIDGE_TEN_DEGREE_CLEARANCE, result.rule)
        assertEquals(expected, result.topElevationM, 1e-9)
    }

    @Test
    fun roofBelowTwentyDegreesUsesParallelPlaneOneMetreAboveRoof() {
        val plane = RoofPlane(0.0, -tan(Math.toRadians(12.0)), 5.0)
        val (graph, face) = graph(plane, 12.0)
        val point = LocalPoint(0.0, 4.0)
        val result = ChimneyHeightSolver.solve(graph, face, point, 0.3, 12.0)!!
        assertEquals(ChimneyHeightRule.LOW_SLOPE_PARALLEL_CLEARANCE, result.rule)
        assertEquals(plane.zAt(point.x, point.y) + 1.0, result.topElevationM, 1e-9)
        assertEquals(1.0, result.heightAboveRoofM, 1e-9)
    }

    @Test
    fun parapetRoofUsesParapetTopPlusOneMetre() {
        val plane = RoofPlane(0.0, 0.0, 4.0)
        val (graph, face) = graph(plane, 2.0, ridge = false, attic = true)
        val result = ChimneyHeightSolver.solve(graph, face, LocalPoint(0.0, 2.0), 0.3, 2.0)!!
        assertEquals(ChimneyHeightRule.ATTIC_CLEARANCE, result.rule)
        // Stored A/B heights are deliberately stale at 5.0 m. The solved anthracite
        // plane is at 4.0 m, so the 300 mm crown plus 1 m clearance ends at 5.3 m.
        assertEquals(5.3, result.topElevationM, 1e-9)
        assertEquals(1.3, result.heightAboveRoofM, 1e-9)
    }

    @Test
    fun roofWithoutRidgeUsesHighestBoundaryPlusOneMetre() {
        val plane = RoofPlane(0.0, -tan(Math.toRadians(25.0)), 5.0)
        val (graph, face) = graph(plane, 25.0, ridge = false)
        val result = ChimneyHeightSolver.solve(graph, face, LocalPoint(0.0, 4.0), 0.3, 25.0)!!
        assertEquals(ChimneyHeightRule.NO_RIDGE_CLEARANCE, result.rule)
        assertEquals(6.0, result.topElevationM, 1e-9)
    }

    @Test
    fun manualHeightLockSurvivesProjectJsonRoundTrip() {
        val project = RoofProject(objects = mutableListOf(
            RoofObject(
                type = ObjectType.CHIMNEY,
                center = GeoPoint(49.0, 18.0),
                value = 1.85,
                chimneyHeightManual = true
            )
        ))
        val decoded = ProjectJson.decode(ProjectJson.encode(project))
        assertTrue(decoded.objects.single().chimneyHeightManual)
        assertEquals(1.85, decoded.objects.single().value, 1e-9)
    }

    @Test
    fun autoActionOverridesPreviousManualHeightAndClearsLock() {
        val plane = RoofPlane(0.0, -tan(Math.toRadians(30.0)), 5.0)
        val (graph, face) = graph(plane, 30.0)
        val chimney = RoofObject(
            type = ObjectType.CHIMNEY,
            center = GeoPoint(49.0, 18.0),
            value = 9.5,
            chimneyHeightManual = true
        )
        val result = ChimneyHeightSolver.applyAutomatic(
            graph, face, LocalPoint(0.0, 1.0), 0.3, 30.0, chimney
        )!!
        assertEquals(result.heightAboveRoofM, chimney.value, 1e-9)
        assertEquals(5.65, result.topElevationM, 1e-9)
        assertTrue(!chimney.chimneyHeightManual)
    }

    @Test
    fun legacyPositiveChimneyHeightIsMigratedAsManual() {
        val project = RoofProject(objects = mutableListOf(
            RoofObject(type = ObjectType.CHIMNEY, center = GeoPoint(49.0, 18.0), value = 1.2)
        ))
        val json = JSONObject(ProjectJson.encode(project))
        json.getJSONArray("objects").getJSONObject(0).remove("chimney_height_manual")
        assertTrue(ProjectJson.decode(json.toString()).objects.single().chimneyHeightManual)
    }
}
