package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class AuthoredRoofReferenceResolverTest {
    private fun project(): RoofProject {
        val topology = RoofTopology(
            origin = GeoPoint(48.0, 17.0),
            nodes = listOf(
                TopologyNode("a", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("b", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("c", 8.0, 5.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("d", 0.0, 5.0, TopologyNodeType.FOOTPRINT)
            ),
            edges = listOf(
                TopologyEdge("edge-bottom", "a", "b", LineType.EAVE, boundary = true),
                TopologyEdge("edge-right", "b", "c", LineType.GABLE, boundary = true),
                TopologyEdge("edge-top", "c", "d", LineType.EAVE, boundary = true),
                TopologyEdge("edge-left", "d", "a", LineType.GABLE, boundary = true)
            )
        )
        return RoofProject(roofTopology = topology)
    }

    @Test
    fun `runtime edge children are persisted as their authored edge`() {
        val project = project()
        assertEquals(
            "edge-bottom",
            AuthoredRoofReferenceResolver.authoredEdgeId(project, "edge-bottom::virtual-2")
        )
        assertEquals(
            "edge-bottom",
            AuthoredRoofReferenceResolver.authoredEdgeId(project, "edge-bottom-segment-003")
        )
        assertFalse(
            AuthoredRoofReferenceResolver.authoredEdgeId(project, "missing::virtual-1")
                .orEmpty().contains("virtual")
        )
    }

    @Test
    fun `runtime point resolves only to an authored face id`() {
        val project = project()
        val graph = AuthoredRoofReferenceResolver.authoredGraph(project)
        val faceId = AuthoredRoofReferenceResolver.authoredFaceIdAt(
            project,
            graph.origin,
            LocalPoint(4.0, 2.5),
            preferredFaceId = "runtime-face"
        )
        assertNotNull(faceId)
        assertEquals(graph.faces.values.single().id, faceId)
        assertFalse(faceId.orEmpty().contains("::virtual-"))
        assertFalse(faceId.orEmpty().contains("-segment-"))
    }
}
