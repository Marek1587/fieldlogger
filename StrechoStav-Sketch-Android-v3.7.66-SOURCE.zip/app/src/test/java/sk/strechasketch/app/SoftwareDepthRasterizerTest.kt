package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class SoftwareDepthRasterizerTest {
    private val aNear = DepthVertex(2f, 2f, 0.40f)
    private val bNear = DepthVertex(18f, 2f, 0.40f)
    private val cNear = DepthVertex(10f, 18f, 0.40f)

    @Test
    fun nearestSurfaceWinsRegardlessOfTriangleSubmissionOrder() {
        val background = 0xffeeeeee.toInt()
        val far = 0xff2244cc.toInt()
        val near = 0xffcc3322.toInt()
        val raster = SoftwareDepthRasterizer(21, 21, background)

        raster.fillTriangle(
            aNear.copy(inverseDepth = 0.20f),
            bNear.copy(inverseDepth = 0.20f),
            cNear.copy(inverseDepth = 0.20f),
            far
        )
        raster.fillTriangle(aNear, bNear, cNear, near)
        raster.fillTriangle(
            aNear.copy(inverseDepth = 0.10f),
            bNear.copy(inverseDepth = 0.10f),
            cNear.copy(inverseDepth = 0.10f),
            far
        )

        assertEquals(near, raster.pixels[9 * 21 + 10])
    }

    @Test
    fun lineBehindOpaqueWallIsNotRenderedButFrontEdgeIsVisible() {
        val background = 0xffffffff.toInt()
        val wall = 0xffe8dabe.toInt()
        val edge = 0xff111111.toInt()
        val raster = SoftwareDepthRasterizer(21, 21, background)
        raster.fillTriangle(aNear, bNear, cNear, wall)

        raster.drawDepthTestedLine(
            DepthVertex(5f, 8f, 0.20f), DepthVertex(15f, 8f, 0.20f), edge, 1f,
            depthBias = 0f
        )
        assertEquals(wall, raster.pixels[8 * 21 + 10])

        raster.drawDepthTestedLine(
            DepthVertex(5f, 8f, 0.50f), DepthVertex(15f, 8f, 0.50f), edge, 1f,
            depthBias = 0f
        )
        assertNotEquals(wall, raster.pixels[8 * 21 + 10])
        assertEquals(edge, raster.pixels[8 * 21 + 10])
    }

    @Test
    fun almostCoplanarRoofLineBehindWallStaysHiddenWithoutPositiveBias() {
        val background = 0xffffffff.toInt()
        val wall = 0xffdfe2e4.toInt()
        val roofLine = 0xff111111.toInt()
        val raster = SoftwareDepthRasterizer(21, 21, background)
        raster.fillTriangle(aNear, bNear, cNear, wall)

        raster.drawDepthTestedLine(
            DepthVertex(5f, 8f, 0.3995f),
            DepthVertex(15f, 8f, 0.3995f),
            roofLine,
            1f,
            depthBias = 0f
        )

        assertEquals(wall, raster.pixels[8 * 21 + 10])
    }
}
