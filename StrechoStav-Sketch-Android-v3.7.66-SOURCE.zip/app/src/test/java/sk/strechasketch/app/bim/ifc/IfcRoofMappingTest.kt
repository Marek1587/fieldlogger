package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset
import sk.strechasketch.app.bim.BimPoint3
import sk.strechasketch.app.bim.RoofBimSnapshotFactory
import sk.strechasketch.app.bim.StrechoStavBimBuilder

class IfcRoofMappingTest {
    @Test fun mapsSpatialTreeRoofAndEveryGraphFaceToSeparateSlab() {
        val result = IfcExporter.export(IfcTestFixtures.gableProject(), fixedClock())
        val text = result.bytes.toString(Charsets.US_ASCII)
        assertEquals(1, result.statistics.roofCount)
        assertEquals(2, result.statistics.faceCount)
        assertTrue(text.contains("IFCPROJECT(")); assertTrue(text.contains("IFCSITE("))
        assertTrue(text.contains("IFCBUILDING(")); assertTrue(text.contains("IFCBUILDINGSTOREY("))
        assertTrue(text.contains("IFCROOF(")); assertEquals(2, Regex("IFCSLAB\\(").findAll(text).count())
        assertTrue(text.contains("IFCPOLYGONALFACESET("))
        assertTrue(text.contains("IFCWINDOW(")); assertTrue(text.contains("IFCCHIMNEY("))
        assertTrue(text.contains("IFCOPENINGELEMENT(")); assertTrue(text.contains("IFCRELVOIDSELEMENT("))
        assertTrue(text.contains("IFCRELFILLSELEMENT("))
    }

    @Test fun faceHoleUsesIndexedPolygonalFaceWithVoidsAndKeepsOneSlabIdentity() {
        val base = StrechoStavBimBuilder.build(RoofBimSnapshotFactory.create(IfcTestFixtures.gableProject()))
        val face = base.faces.first()
        val hole = listOf(
            BimPoint3(4.5, 1.0, face.plane.zAt(4.5, 1.0)),
            BimPoint3(5.5, 1.0, face.plane.zAt(5.5, 1.0)),
            BimPoint3(5.5, 2.0, face.plane.zAt(5.5, 2.0)),
            BimPoint3(4.5, 2.0, face.plane.zAt(4.5, 2.0))
        )
        val withHole = base.copy(faces = base.faces.map { if (it.id == face.id) it.copy(holes = listOf(hole)) else it })
        val mapped = Ifc43Mapper.map(withHole, "3.7.23", Instant.EPOCH, "hole.ifc")
        val text = IfcStepWriter.write(mapped).toString(Charsets.US_ASCII)
        assertTrue(text.contains("IFCINDEXEDPOLYGONALFACEWITHVOIDS("))
        assertEquals(base.faces.size, Regex("IFCSLAB\\(").findAll(text).count())
        assertTrue(text.contains(IfcStepString.quote(face.id)))
    }

    private fun fixedClock() = Clock.fixed(Instant.parse("2026-08-17T10:00:00Z"), ZoneOffset.UTC)
}
