package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

class RainwaterDrainageSolverTest {
    private fun graph(length: Double = 24.0, role: EdgeSemantic = EdgeSemantic.EAVE): RoofGraph {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 4.0), GraphNode("b", length, 0.0, 4.0),
            GraphNode("c", length, 8.0, 7.0), GraphNode("d", 0.0, 8.0, 7.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("eave", "a", "b", true, role, setOf("face")),
            GraphEdge("right", "b", "c", true, EdgeSemantic.GABLE, setOf("face")),
            GraphEdge("high", "c", "d", true, EdgeSemantic.GABLE, setOf("face")),
            GraphEdge("left", "d", "a", true, EdgeSemantic.GABLE, setOf("face"))
        ).associateBy { it.id }
        val face = GraphFace(
            id = "face", orderedNodeIds = listOf("a", "b", "c", "d"),
            orderedEdgeIds = listOf("eave", "right", "high", "left"), signedAreaM2 = length * 8.0,
            plane = RoofPlane(0.0, 0.375, 4.0)
        )
        return RoofGraph(GeoPoint(49.0, 18.0), nodes, edges, mapOf(face.id to face))
    }

    @Test
    fun `manual downspout attached to authored edge follows its runtime child`() {
        val source = graph(length = 6.0)
        val runtimeId = "eave::virtual-1"
        val authoredEdge = requireNotNull(source.edges["eave"])
        val midpoint = GraphNode("eave-runtime-mid", 3.0, 0.0, 4.0)
        val firstRuntimeEdge = authoredEdge.copy(endNodeId = midpoint.id)
        val secondRuntimeEdge = authoredEdge.copy(
            id = runtimeId,
            startNodeId = midpoint.id
        )
        val runtimeGraph = source.copy(
            nodes = source.nodes + (midpoint.id to midpoint),
            edges = source.edges - "eave" +
                (authoredEdge.id to firstRuntimeEdge) + (runtimeId to secondRuntimeEdge),
            faces = source.faces.mapValues { (_, face) ->
                face.copy(
                    orderedNodeIds = listOf("a", midpoint.id, "b", "c", "d"),
                    orderedEdgeIds = listOf(authoredEdge.id, runtimeId, "right", "high", "left")
                )
            }
        )
        val manual = RoofObject(
            id = "manual-authored-reference",
            type = ObjectType.DOWNSPOUT,
            center = Geometry.toGeo(LocalPoint(4.5, 0.0), runtimeGraph.origin),
            attachedEdgeId = "eave"
        )

        val solution = RainwaterDrainageSolver.solve(runtimeGraph, explicitObjects = listOf(manual))

        assertTrue(
            solution.downspouts.joinToString(),
            solution.downspouts.count { it.id == manual.id && it.primaryEdgeId == runtimeId } == 1
        )
    }

    @Test
    fun `gutter has requested plan width and offset`() {
        val gutter = RainwaterDrainageSolver.solve(graph()).gutters.single()
        val corners = gutter.bandCorners()
        assertEquals(0.03, abs(corners[0].y), 1e-9)
        assertEquals(0.15, abs(corners[3].y), 1e-9)
        assertEquals(0.12, hypot(corners[3].x - corners[0].x, corners[3].y - corners[0].y), 1e-9)
        val highPoint = gutter.profile.first { !it.outlet }
        assertEquals(
            4.0 - RainwaterDrainageSolver.GUTTER_TOP_CLEARANCE_M -
                RainwaterDrainageSolver.GUTTER_WIDTH_M / 2.0,
            highPoint.elevationZ,
            1e-9
        )
        assertTrue(
            highPoint.elevationZ + RainwaterDrainageSolver.GUTTER_WIDTH_M / 2.0 <=
                4.0 - RainwaterDrainageSolver.GUTTER_TOP_CLEARANCE_M + 1e-9
        )
    }

    @Test
    fun `gutter follows solved roof plane instead of stale boundary node height`() {
        val source = graph()
        val stale = source.copy(nodes = source.nodes.mapValues { (_, node) -> node.copy(z = node.z + 2.0) })
        val gutter = RainwaterDrainageSolver.solve(stale).gutters.single()
        val highPoint = gutter.profile.first { abs(it.t) < 1e-9 }
        assertEquals(
            4.0 - RainwaterDrainageSolver.GUTTER_TOP_CLEARANCE_M -
                RainwaterDrainageSolver.GUTTER_WIDTH_M / 2.0,
            highPoint.elevationZ,
            1e-9
        )
    }

    @Test
    fun `automatic outlets keep maximum twelve metre spacing`() {
        val solution = RainwaterDrainageSolver.solve(graph(24.0))
        assertEquals(2, solution.downspouts.size)
        val x = solution.downspouts.map { it.eavePoint.x }.sorted()
        assertEquals(8.0, x[0], 1e-9)
        assertEquals(16.0, x[1], 1e-9)
        assertTrue(x[0] <= RainwaterDrainageSolver.MAX_DOWNSPOUT_SPACING_M)
        assertTrue(x[1] - x[0] <= RainwaterDrainageSolver.MAX_DOWNSPOUT_SPACING_M)
        assertTrue(24.0 - x[1] <= RainwaterDrainageSolver.MAX_DOWNSPOUT_SPACING_M)
        assertTrue(x.all { it >= 0.8 && 24.0 - it >= 0.8 })
    }

    @Test
    fun `gutter profile falls toward every outlet`() {
        val profile = RainwaterDrainageSolver.solve(graph(24.0)).gutters.single().profile
        val firstHigh = profile.first { abs(it.t - 0.0) < 1e-9 }
        val firstOutlet = profile.first { abs(it.t - 1.0 / 3.0) < 1e-9 }
        val middleHigh = profile.first { abs(it.t - 0.5) < 1e-9 }
        val lastOutlet = profile.first { abs(it.t - 2.0 / 3.0) < 1e-9 }
        val lastHigh = profile.first { abs(it.t - 1.0) < 1e-9 }
        assertTrue(firstOutlet.elevationZ < firstHigh.elevationZ)
        assertTrue(firstOutlet.elevationZ < middleHigh.elevationZ)
        assertTrue(lastOutlet.elevationZ < middleHigh.elevationZ)
        assertTrue(lastOutlet.elevationZ < lastHigh.elevationZ)
        assertEquals(0.032, firstHigh.elevationZ - firstOutlet.elevationZ, 1e-9)
        assertEquals(4.0, RainwaterDrainageSolver.GUTTER_SLOPE_MM_PER_M, 1e-9)
        assertTrue(!firstHigh.outlet)
        assertTrue(!lastHigh.outlet)
    }

    @Test
    fun `outlet is clamped at least eight tenths metre from both corners`() {
        assertEquals(0.08, RainwaterDrainageSolver.constrainOutletT(10.0, 0.0)!!, 1e-9)
        assertEquals(0.92, RainwaterDrainageSolver.constrainOutletT(10.0, 1.0)!!, 1e-9)
        assertEquals(0.5, RainwaterDrainageSolver.constrainOutletT(10.0, 0.5)!!, 1e-9)
        assertTrue(RainwaterDrainageSolver.constrainOutletT(1.59, 0.5) == null)
    }

    @Test
    fun `two adjacent eaves receive one continuous high corner connector`() {
        val base = graph(24.0)
        val right = base.edges.getValue("right").copy(semanticRole = EdgeSemantic.EAVE)
        val cornerGraph = base.copy(edges = base.edges + (right.id to right))
        val solution = RainwaterDrainageSolver.solve(cornerGraph)
        assertEquals(2, solution.gutters.size)
        assertEquals(1, solution.gutterCorners.size)
        val corner = solution.gutterCorners.single()
        assertEquals("b", corner.nodeId)
        assertEquals(setOf("eave", "right"), corner.edgeIds)
        assertTrue(corner.profile.size >= 2)
        assertTrue(corner.bandPolygon().size >= 4)
        assertEquals(RainwaterDrainageSolver.GutterCornerKind.OUTER_90, corner.kind)
        assertEquals(1, solution.outerCorners90)
        assertEquals(0, solution.innerCorners90)
        val runEnds = solution.gutters.mapNotNull { run ->
            when (corner.nodeId) {
                run.start.id -> run.profile.firstOrNull()
                run.end.id -> run.profile.lastOrNull()
                else -> null
            }
        }
        assertEquals(2, runEnds.size)
        assertTrue(runEnds.all { !it.outlet })
        assertTrue(runEnds.all { abs(it.elevationZ - corner.profile.first().elevationZ) < 1e-9 })
        solution.downspouts.forEach { downspout ->
            val run = solution.gutters.single { it.edgeId == downspout.primaryEdgeId }
            val distanceFromStart = downspout.edgeT * run.lengthM
            val distanceFromEnd = (1.0 - downspout.edgeT) * run.lengthM
            assertTrue(distanceFromStart + 1e-9 >= RainwaterDrainageSolver.MIN_DOWNSPOUT_CORNER_CLEARANCE_M)
            assertTrue(distanceFromEnd + 1e-9 >= RainwaterDrainageSolver.MIN_DOWNSPOUT_CORNER_CLEARANCE_M)
        }
    }

    @Test
    fun `hooks and clamps never exceed system spacing`() {
        val solution = RainwaterDrainageSolver.solve(graph(24.0))
        val hooks = solution.gutterHooks.sortedBy { it.t }
        assertEquals(28, hooks.size)
        hooks.zipWithNext().forEach { (a, b) ->
            assertTrue((b.t - a.t) * 24.0 <= RainwaterDrainageSolver.MAX_GUTTER_HOOK_SPACING_M + 1e-9)
        }
        solution.downspouts.forEach { downspout ->
            val clamps = solution.downspoutClamps.filter { it.downspoutId == downspout.id }
                .sortedBy { it.elevationZ }
            assertTrue(clamps.size >= 2)
            clamps.zipWithNext().forEach { (a, b) ->
                assertTrue(
                    b.elevationZ - a.elevationZ <=
                        RainwaterDrainageSolver.MAX_DOWNSPOUT_CLAMP_SPACING_M + 1e-9
                )
            }
        }
    }

    @Test
    fun `concave right angle is reported as system inner corner`() {
        val nodes = listOf(
            GraphNode("a", 0.0, 0.0, 4.0), GraphNode("b", 8.0, 0.0, 4.0),
            GraphNode("c", 8.0, 3.0, 4.0), GraphNode("d", 3.0, 3.0, 4.0),
            GraphNode("e", 3.0, 8.0, 4.0), GraphNode("f", 0.0, 8.0, 4.0)
        ).associateBy { it.id }
        val ids = listOf("a", "b", "c", "d", "e", "f")
        val edgeIds = listOf("ab", "bc", "cd", "de", "ef", "fa")
        val edges = edgeIds.indices.map { index ->
            GraphEdge(
                id = edgeIds[index], startNodeId = ids[index], endNodeId = ids[(index + 1) % ids.size],
                boundary = true,
                semanticRole = if (edgeIds[index] in setOf("cd", "de")) EdgeSemantic.EAVE else EdgeSemantic.GABLE,
                adjacentFaceIds = setOf("face")
            )
        }.associateBy { it.id }
        val face = GraphFace(
            id = "face", orderedNodeIds = ids, orderedEdgeIds = edgeIds,
            signedAreaM2 = 39.0, plane = RoofPlane(0.0, 0.0, 4.0)
        )
        val solution = RainwaterDrainageSolver.solve(
            RoofGraph(GeoPoint(49.0, 18.0), nodes, edges, mapOf(face.id to face))
        )
        assertEquals(1, solution.innerCorners90)
        assertEquals(0, solution.outerCorners90)
        assertEquals(RainwaterDrainageSolver.GutterCornerKind.INNER_90, solution.gutterCorners.single().kind)
    }

    @Test
    fun `attic and gable boundaries never receive gutter`() {
        assertTrue(RainwaterDrainageSolver.solve(graph(role = EdgeSemantic.ATTIC)).gutters.isEmpty())
        assertTrue(RainwaterDrainageSolver.solve(graph(role = EdgeSemantic.GABLE)).gutters.isEmpty())
    }

    @Test
    fun `all exposed low boundary roles receive gutter from solved surface`() {
        listOf(
            EdgeSemantic.EAVE,
            EdgeSemantic.PULT,
            EdgeSemantic.LOW_EDGE,
            EdgeSemantic.ELEVATED_LOW_EDGE
        ).forEach { role ->
            val source = graph(role = role)
            val stale = source.copy(nodes = source.nodes.mapValues { (_, node) -> node.copy(z = 80.0) })
            val gutter = RainwaterDrainageSolver.solve(stale).gutters.single()
            assertEquals("role=$role", "eave", gutter.edgeId)
            assertEquals(
                "role=$role",
                4.0 - RainwaterDrainageSolver.GUTTER_TOP_CLEARANCE_M -
                    RainwaterDrainageSolver.GUTTER_WIDTH_M / 2.0,
                gutter.profile.first().elevationZ,
                1e-9
            )
        }
    }

    @Test
    fun `wall end boundary never receives gutter`() {
        assertTrue(RainwaterDrainageSolver.solve(graph(role = EdgeSemantic.WALL_END)).gutters.isEmpty())
    }

    @Test
    fun `wall attachment follows changed overhang distance`() {
        val walls = listOf(
            LocalPoint(0.0, 0.6), LocalPoint(24.0, 0.6),
            LocalPoint(24.0, 8.0), LocalPoint(0.0, 8.0)
        )
        val downspout = RainwaterDrainageSolver.solve(graph(), walls).downspouts.first()
        assertEquals(0.6, downspout.wallPoint.y, 1e-9)
        assertEquals(0.69, hypot(
            downspout.gutterPoint.x - downspout.wallPoint.x,
            downspout.gutterPoint.y - downspout.wallPoint.y
        ), 1e-9)
        assertEquals(72.0, RainwaterDrainageSolver.ELBOW_ANGLE_DEG, 1e-9)
    }

    @Test
    fun `automatic downspout can be moved and terminated in soakaway`() {
        val graph = graph(24.0)
        val id = RainwaterDrainageSolver.automaticId("eave", 1)
        val override = RoofObject(
            id = id,
            type = ObjectType.DOWNSPOUT,
            center = Geometry.toGeo(LocalPoint(6.0, 0.0), graph.origin),
            attachedEdgeId = "eave",
            downspoutAutomatic = true,
            downspoutTermination = DownspoutTermination.SOAKAWAY
        )
        val solved = RainwaterDrainageSolver.solve(graph, explicitObjects = listOf(override))
        val moved = solved.downspouts.single { it.id == id }
        assertEquals(6.0, moved.eavePoint.x, 1e-9)
        assertEquals(0.25, moved.edgeT, 1e-9)
        assertEquals(DownspoutTermination.SOAKAWAY, moved.termination)
    }

    @Test
    fun `removed automatic downspout stays suppressed`() {
        val graph = graph(24.0)
        val suppressed = RoofObject(
            id = RainwaterDrainageSolver.automaticId("eave", 1),
            type = ObjectType.DOWNSPOUT,
            center = Geometry.toGeo(LocalPoint(12.0, 0.0), graph.origin),
            attachedEdgeId = "eave",
            downspoutAutomatic = true,
            downspoutSuppressed = true
        )
        val solved = RainwaterDrainageSolver.solve(graph, explicitObjects = listOf(suppressed))
        assertEquals(1, solved.downspouts.size)
        assertEquals(RainwaterDrainageSolver.automaticId("eave", 2), solved.downspouts.single().id)
    }

    @Test
    fun `manual downspout is stored on selected eave`() {
        val graph = graph(24.0)
        val manual = RoofObject(
            id = "manual-downspout",
            type = ObjectType.DOWNSPOUT,
            center = Geometry.toGeo(LocalPoint(4.0, 0.0), graph.origin),
            attachedEdgeId = "eave",
            downspoutTermination = DownspoutTermination.ELBOW_72
        )
        val solved = RainwaterDrainageSolver.solve(graph, explicitObjects = listOf(manual))
        assertTrue(solved.downspouts.any { it.id == manual.id && !it.automatic })
    }

    @Test
    fun `downspout configuration survives project json round trip`() {
        val project = RoofProject(objects = mutableListOf(
            RoofObject(
                id = "configured-downspout",
                type = ObjectType.DOWNSPOUT,
                center = GeoPoint(49.0, 18.0),
                attachedEdgeId = "eave-7",
                downspoutTermination = DownspoutTermination.SOAKAWAY,
                downspoutAutomatic = true,
                downspoutSuppressed = true
            )
        ))
        val decoded = ProjectJson.decode(ProjectJson.encode(project)).objects.single()
        assertEquals(DownspoutTermination.SOAKAWAY, decoded.downspoutTermination)
        assertTrue(decoded.downspoutAutomatic)
        assertTrue(decoded.downspoutSuppressed)
    }

    @Test
    fun `mesh and quantity audit use the same derived rainwater system`() {
        val graph = graph(24.0)
        val polygon = listOf("a", "b", "c", "d").map { nodeId ->
            val node = graph.nodes.getValue(nodeId)
            Geometry.toGeo(LocalPoint(node.x, node.y), graph.origin)
        }.toMutableList()
        val project = RoofProject(
            name = "Dažďová sústava",
            wallHeightM = 4.0,
            polygon = polygon,
            wallFootprint = polygon.map(GeoPoint::copy).toMutableList(),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE, 1 to LineType.GABLE,
                2 to LineType.GABLE, 3 to LineType.GABLE
            ),
            roofGraph = graph,
            roofTopology = graph.toTopology()
        )
        val mesh = RoofMeshBuilder.build(project)
        assertEquals(1, mesh.gutterRunCount)
        assertEquals(2, mesh.automaticDownspoutCount)
        assertEquals(28, mesh.gutterHookCount)
        assertTrue(mesh.downspoutClampCount >= 4)
        assertEquals(3, mesh.rainwaterAnchors.size)
        val selectedId = RainwaterDrainageSolver.automaticId("eave", 1)
        val selectedMesh = RoofMeshBuilder.build(project, selectedId)
        assertTrue(selectedMesh.materials.any { it in 7.5f..8.5f })
        val totals = RoofQuantityEngine.calculate(project).totals
        assertEquals(2, totals.downspouts)
        assertEquals(mesh.gutterHookCount, totals.gutterHooks)
        assertEquals(mesh.downspoutClampCount, totals.downspoutClamps)
    }
}
