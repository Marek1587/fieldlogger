package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset

class IfcExporterTest {
    @Test fun simpleGableMatchesGoldenIfcFixture() {
        val clock = Clock.fixed(Instant.parse("2026-08-17T10:00:00Z"), ZoneOffset.UTC)
        val actual = IfcExporter.export(IfcTestFixtures.gableProject(), clock).bytes
        if (System.getenv("UPDATE_IFC_GOLDEN") == "1") {
            val base = java.nio.file.Paths.get(System.getProperty("user.dir"))
            val fromApp = base.resolve("src/test/resources/ifc/simple_gable.ifc")
            val target = if (java.nio.file.Files.exists(fromApp.parent)) fromApp else base.resolve("app/src/test/resources/ifc/simple_gable.ifc")
            java.nio.file.Files.write(target, actual)
            return
        }
        val expected = requireNotNull(javaClass.getResourceAsStream("/ifc/simple_gable.ifc")) {
            "Missing golden IFC fixture"
        }.use { it.readBytes() }
        assertArrayEquals(expected, actual)
    }

    @Test fun repeatedExportIsByteStableWithInjectedClockAndPassesSanityValidation() {
        val clock = Clock.fixed(Instant.parse("2026-08-17T10:00:00Z"), ZoneOffset.UTC)
        val project = IfcTestFixtures.gableProject()
        val first = IfcExporter.export(project, clock)
        val second = IfcExporter.export(project, clock)
        assertArrayEquals(first.bytes, second.bytes)
        assertTrue(first.validation.errors.joinToString(), first.validation.valid)
        assertEquals(first.statistics, second.statistics)
        assertFalse(first.bytes.toString(Charsets.US_ASCII).contains("NaN"))
        assertFalse(first.bytes.toString(Charsets.US_ASCII).contains("Infinity"))
    }
}
