package sk.strechasketch.app.bim.ifc

import org.junit.Assert.*
import org.junit.Test
import sk.strechasketch.app.RoofQuantityEngine
import java.time.Clock
import java.time.Instant
import java.time.ZoneOffset

class IfcQuantityMappingTest {
    @Test fun qtoUsesSameSolvedQuantityValues() {
        val project = IfcTestFixtures.gableProject()
        val expected = RoofQuantityEngine.calculate(project).totals
        val text = IfcExporter.export(project, Clock.fixed(Instant.EPOCH, ZoneOffset.UTC)).bytes.toString(Charsets.US_ASCII)
        assertTrue(text.contains("Qto_RoofBaseQuantities"))
        assertTrue(text.contains("Qto_SlabBaseQuantities"))
        assertTrue(text.contains("IFCQUANTITYAREA('NetArea',$,$,${decimal(expected.roofAreaM2)},$)"))
        assertTrue(text.contains("IFCQUANTITYAREA('ProjectedArea',$,$,${decimal(expected.footprintAreaM2)},$)"))
    }

    private fun decimal(value: Double): String = java.lang.String.format(java.util.Locale.US, "%.12f", value)
        .trimEnd('0').let { if (it.endsWith('.')) it else it }
}
