package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofPlanAnnotationSolverTest {
    @Test
    fun atticBandsMeetContinuouslyAtRectangleCorners() {
        val graph = rectangleGraph(plane = RoofPlane(0.0, 0.0, 3.0))

        val bands = RoofPlanAnnotationSolver.atticBands(graph, widthM = 0.25)

        assertEquals(4, bands.size)
        val bottom = bands.single { it.edgeId == "E1" }
        val right = bands.single { it.edgeId == "E2" }
        assertEquals(9.75, bottom.innerEnd.x, 1e-9)
        assertEquals(0.25, bottom.innerEnd.y, 1e-9)
        assertEquals(bottom.innerEnd.x, right.innerStart.x, 1e-9)
        assertEquals(bottom.innerEnd.y, right.innerStart.y, 1e-9)
        assertTrue(bottom.joinedAtEnd)
        assertTrue(right.joinedAtStart)
    }

    @Test
    fun edgeHeightsUseSolvedEdgesAndFinishedAnthraciteAtticCrown() {
        val base = rectangleGraph(plane = RoofPlane(0.1, 0.2, 3.0))
        val graph = base.copy(
            nodes = base.nodes + mapOf(
                "R1" to GraphNode("R1", 2.0, 4.0, 6.0),
                "R2" to GraphNode("R2", 8.0, 4.0, 6.0)
            ),
            edges = base.edges + mapOf(
                "RIDGE" to GraphEdge("RIDGE", "R1", "R2", false, EdgeSemantic.RIDGE),
                "EAVE" to GraphEdge("EAVE", "A", "B", true, EdgeSemantic.EAVE)
            )
        )

        val marks = RoofPlanAnnotationSolver.edgeHeights(graph, atticHeightM = 0.3)

        assertEquals(6, marks.size)
        assertEquals(6.0, marks.single { it.edgeId == "RIDGE" }.elevationM, 1e-9)
        assertEquals(0.0, marks.single { it.edgeId == "EAVE" }.elevationM, 1e-9)
        marks.filter { it.semanticRole == EdgeSemantic.ATTIC }.forEach {
            assertEquals(5.9, it.elevationM, 1e-9)
        }
    }

    @Test
    fun faceSlopeUsesSolvedPlaneAndPointsDownhill() {
        val graph = rectangleGraph(plane = RoofPlane(0.1, 0.2, 3.0))

        val mark = RoofPlanAnnotationSolver.faceSlopes(graph).single()

        assertEquals(Math.toDegrees(kotlin.math.atan(kotlin.math.hypot(0.1, 0.2))), mark.slopeDeg, 1e-9)
        assertTrue(mark.downhillX < 0.0)
        assertTrue(mark.downhillY < 0.0)
        assertEquals(1.0, kotlin.math.hypot(mark.downhillX, mark.downhillY), 1e-9)
    }

    @Test
    fun faceSlopeCentroidSubtractsHoleAndRemainsTheOnlyFaceCentroidAnnotation() {
        val base = rectangleGraph(plane = RoofPlane(0.1, 0.0, 3.0))
        val nodes = base.nodes + mapOf(
            "H1" to GraphNode("H1", 6.0, 2.0),
            "H2" to GraphNode("H2", 8.0, 2.0),
            "H3" to GraphNode("H3", 8.0, 4.0),
            "H4" to GraphNode("H4", 6.0, 4.0)
        )
        val face = base.faces.getValue("F1").copy(
            holeNodeIdLoops = listOf(listOf("H1", "H2", "H3", "H4"))
        )

        val mark = RoofPlanAnnotationSolver.faceSlopes(
            base.copy(nodes = nodes, faces = mapOf(face.id to face))
        ).single()

        assertTrue(mark.point.x < 5.0)
        assertEquals(Math.toDegrees(kotlin.math.atan(0.1)), mark.slopeDeg, 1e-9)
    }

    private fun rectangleGraph(plane: RoofPlane): RoofGraph {
        val nodes = listOf(
            GraphNode("A", 0.0, 0.0),
            GraphNode("B", 10.0, 0.0),
            GraphNode("C", 10.0, 8.0),
            GraphNode("D", 0.0, 8.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("E1", "A", "B", true, EdgeSemantic.ATTIC, setOf("F1")),
            GraphEdge("E2", "B", "C", true, EdgeSemantic.ATTIC, setOf("F1")),
            GraphEdge("E3", "C", "D", true, EdgeSemantic.ATTIC, setOf("F1")),
            GraphEdge("E4", "D", "A", true, EdgeSemantic.ATTIC, setOf("F1"))
        ).associateBy { it.id }
        val face = GraphFace(
            id = "F1",
            orderedNodeIds = listOf("A", "B", "C", "D"),
            orderedEdgeIds = listOf("E1", "E2", "E3", "E4"),
            signedAreaM2 = 80.0,
            plane = plane
        )
        return RoofGraph(
            origin = GeoPoint(48.0, 18.0),
            nodes = nodes,
            edges = edges,
            faces = mapOf(face.id to face)
        )
    }
}
