package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofObjectPlanDimensionSolverTest {
    private val rectangle = listOf(
        LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
        LocalPoint(10.0, 6.0), LocalPoint(0.0, 6.0)
    )

    @Test
    fun objectPositionCreatesTwoExternalRowsFromOneCorner() {
        val dimensions = RoofObjectPlanDimensionSolver.solve(
            polygon = rectangle,
            objectPoint = LocalPoint(8.5, 5.25),
            offsetM = 1.0
        )

        assertEquals(listOf('X', 'Y'), dimensions.map { it.axis })
        assertTrue(dimensions.all { it.cornerIndex == 2 })
        assertTrue(dimensions.all { it.referenceCorner == LocalPoint(10.0, 6.0) })
        assertEquals(1.5, dimensions.first { it.axis == 'X' }.lengthM, 1e-9)
        assertEquals(0.75, dimensions.first { it.axis == 'Y' }.lengthM, 1e-9)
        assertTrue(dimensions.all { RoofObjectPlanDimensionSolver.isOutside(rectangle, it) })
    }

    @Test
    fun explicitReferenceCornerDoesNotJumpDuringMovement() {
        val dimensions = RoofObjectPlanDimensionSolver.solve(
            polygon = rectangle,
            objectPoint = LocalPoint(9.5, 5.7),
            offsetM = 1.0,
            cornerIndex = 0
        )

        assertTrue(dimensions.all { it.cornerIndex == 0 })
        assertTrue(dimensions.all { it.referenceCorner == LocalPoint(0.0, 0.0) })
    }
}
