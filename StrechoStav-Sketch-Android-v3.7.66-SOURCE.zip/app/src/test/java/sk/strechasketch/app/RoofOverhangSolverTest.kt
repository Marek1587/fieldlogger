package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RoofOverhangSolverTest {
    private val origin = GeoPoint(48.0, 17.0)
    private fun geo(x: Double, y: Double) = Geometry.toGeo(LocalPoint(x, y), origin)

    private fun unequalOverhangFixture(): RoofOverhangSolver.Solution {
        val project = RoofProject(
            polygon = mutableListOf(
                geo(0.0, 0.0), geo(12.0, 0.0), geo(12.0, 8.0), geo(0.0, 8.0)
            ),
            edgeTypes = mutableMapOf(
                0 to LineType.EAVE,
                1 to LineType.GABLE,
                2 to LineType.EAVE,
                3 to LineType.GABLE
            ),
            lines = mutableListOf(
                RoofLine(type = LineType.RIDGE, start = geo(0.0, 4.0), end = geo(12.0, 4.0))
            ),
            slopeDeg = 35.0,
            wallHeightM = 3.0
        )
        val prepared = Roof3DPreparation.prepare(project)
        // Real measured wall loop: bottom 120 mm, right 350 mm, top 450 mm,
        // left only 80 mm. The 200 mm flat soffit must be capped locally.
        val wall = listOf(
            LocalPoint(0.08, 0.12),
            LocalPoint(11.65, 0.12),
            LocalPoint(11.65, 7.55),
            LocalPoint(0.08, 7.55)
        )
        return RoofOverhangSolver.solve(prepared.planeSolution.graph, wall)
    }

    private fun expectedDepth(section: RoofOverhangSolver.Section): Double {
        val middleX = (section.outerTopA.x + section.outerTopB.x) / 2.0
        val middleY = (section.outerTopA.y + section.outerTopB.y) / 2.0
        return when {
            abs(middleY) < 1e-4 -> 0.12
            abs(middleX - 12.0) < 1e-4 -> 0.35
            abs(middleY - 8.0) < 1e-4 -> 0.45
            else -> 0.08
        }
    }

    private fun supportDistance(section: RoofOverhangSolver.Section, point: GraphNode): Double {
        val dx = section.outerTopB.x - section.outerTopA.x
        val dy = section.outerTopB.y - section.outerTopA.y
        return abs((point.x - section.outerTopA.x) * dy - (point.y - section.outerTopA.y) * dx) /
            hypot(dx, dy)
    }

    @Test
    fun flatSoffitDepthIsCappedByEveryMeasuredLocalOverhang() {
        val solution = unequalOverhangFixture()
        assertTrue(solution.sections.isNotEmpty())
        assertTrue(solution.sections.map { it.overhangM }.distinctBy { (it * 1000).toInt() }.size >= 4)

        solution.sections.forEach { section ->
            val expectedOverhang = expectedDepth(section)
            val expectedFlat = minOf(0.20, expectedOverhang)
            assertEquals(expectedOverhang, section.overhangM, 1e-5)
            assertEquals(expectedFlat, section.flatDepthM, 1e-5)
            // Both shared miter endpoints stay on this section's own local support line.
            assertEquals(expectedFlat, supportDistance(section, section.flatInnerA), 1e-5)
            assertEquals(expectedFlat, supportDistance(section, section.flatInnerB), 1e-5)
        }
    }

    @Test
    fun adjacentEaveAndGableSectionsShareOneContinuous3dMiter() {
        val solution = unequalOverhangFixture()
        data class Endpoint(
            val role: EdgeSemantic,
            val top: GraphNode,
            val bottom: GraphNode,
            val flat: GraphNode,
            val wall: GraphNode
        )
        val corners = solution.sections.flatMap { section ->
            listOf(
                Endpoint(section.semanticRole, section.outerTopA, section.outerBottomA, section.flatInnerA, section.wallInnerA),
                Endpoint(section.semanticRole, section.outerTopB, section.outerBottomB, section.flatInnerB, section.wallInnerB)
            )
        }.groupBy { it.top.id }.values.filter { endpoints ->
            endpoints.map { it.role }.toSet().containsAll(setOf(EdgeSemantic.EAVE, EdgeSemantic.GABLE))
        }
        assertEquals(4, corners.size)
        corners.forEach { endpoints ->
            assertEquals(2, endpoints.size)
            val first = endpoints.first()
            endpoints.drop(1).forEach { other ->
                assertEquals(first.top.x, other.top.x, 1e-9)
                assertEquals(first.top.y, other.top.y, 1e-9)
                assertEquals(first.top.z, other.top.z, 1e-9)
                assertEquals(first.bottom.z, other.bottom.z, 1e-9)
                assertEquals(first.flat.x, other.flat.x, 1e-9)
                assertEquals(first.flat.y, other.flat.y, 1e-9)
                assertEquals(first.flat.z, other.flat.z, 1e-9)
                assertEquals(first.wall.x, other.wall.x, 1e-9)
                assertEquals(first.wall.y, other.wall.y, 1e-9)
                assertEquals(first.wall.z, other.wall.z, 1e-9)
            }
        }
    }
}
