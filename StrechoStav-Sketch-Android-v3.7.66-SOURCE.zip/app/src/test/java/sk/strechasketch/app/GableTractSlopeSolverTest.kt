package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.tan

class GableTractSlopeSolverTest {
    @Test
    fun connectedPerpendicularRidgesUseOneMainTractRiseIndependentOfMapOrder() {
        val graph = connectedRidgeGraph()
        val context = WallFootprintSolver.Context(
            origin = graph.origin,
            parts = listOf(
                WallFootprintSolver.Context.LocalPart(
                    id = "main",
                    type = WallFootprintPartType.MAIN_TRACT,
                    polygon = listOf(
                        LocalPoint(4.0, 0.0), LocalPoint(10.0, 0.0),
                        LocalPoint(10.0, 10.0), LocalPoint(4.0, 10.0)
                    ),
                    areaM2 = 60.0
                ),
                WallFootprintSolver.Context.LocalPart(
                    id = "wing",
                    type = WallFootprintPartType.SEPARATE_WING,
                    polygon = listOf(
                        LocalPoint(-5.0, -8.0), LocalPoint(7.0, -8.0),
                        LocalPoint(7.0, 0.0), LocalPoint(-5.0, 0.0)
                    ),
                    areaM2 = 96.0
                )
            )
        )

        val forward = GableTractSlopeSolver.apply(graph, 40.0, context)
        val reversed = GableTractSlopeSolver.apply(
            graph.copy(
                edges = graph.edges.entries.reversed().associate { it.toPair() },
                faces = graph.faces.entries.reversed().associate { it.toPair() }
            ),
            40.0,
            context
        )

        val runs = mapOf("main-low" to 4.0, "main-high" to 6.0, "wing-left" to 9.0, "wing-right" to 3.0)
        val expectedRise = tan(Math.toRadians(40.0)) * 6.0
        runs.forEach { (faceId, run) ->
            val first = forward.faces.getValue(faceId).slopeConstraint!!
            val second = reversed.faces.getValue(faceId).slopeConstraint!!
            assertEquals(expectedRise, tan(Math.toRadians(first.angleDeg)) * run, 1e-8)
            assertEquals(first.angleDeg, second.angleDeg, 1e-10)
            assertEquals(SlopeConstraintSource.AUTOMATIC_GABLE, first.source)
        }
        assertEquals(40.0, forward.faces.getValue("main-high").slopeConstraint!!.angleDeg, 1e-8)
        assertTrue(forward.faces.getValue("wing-left").slopeConstraint!!.angleDeg < 40.0)
    }

    private fun connectedRidgeGraph(): RoofGraph {
        val nodes = listOf(
            GraphNode("junction", 4.0, 4.0), GraphNode("main-end", 8.0, 4.0),
            GraphNode("wing-end", 4.0, -8.0),
            GraphNode("ml-a", 4.0, 0.0), GraphNode("ml-b", 8.0, 0.0),
            GraphNode("mh-a", 4.0, 10.0), GraphNode("mh-b", 8.0, 10.0),
            GraphNode("wl-a", -5.0, -8.0), GraphNode("wl-b", -5.0, 4.0),
            GraphNode("wr-a", 7.0, -8.0), GraphNode("wr-b", 7.0, 4.0)
        ).associateBy { it.id }
        val edges = listOf(
            GraphEdge("ridge-main", "junction", "main-end", false, EdgeSemantic.RIDGE,
                setOf("main-low", "main-high")),
            GraphEdge("ridge-wing", "junction", "wing-end", false, EdgeSemantic.RIDGE,
                setOf("wing-left", "wing-right")),
            GraphEdge("eave-main-low", "ml-a", "ml-b", true, EdgeSemantic.EAVE,
                setOf("main-low")),
            GraphEdge("eave-main-high", "mh-a", "mh-b", true, EdgeSemantic.EAVE,
                setOf("main-high")),
            GraphEdge("eave-wing-left", "wl-a", "wl-b", true, EdgeSemantic.EAVE,
                setOf("wing-left")),
            GraphEdge("eave-wing-right", "wr-a", "wr-b", true, EdgeSemantic.EAVE,
                setOf("wing-right"))
        ).associateBy { it.id }
        val faces = listOf(
            GraphFace("main-low", emptyList(), listOf("ridge-main", "eave-main-low"), 1.0),
            GraphFace("main-high", emptyList(), listOf("ridge-main", "eave-main-high"), 1.0),
            GraphFace("wing-left", emptyList(), listOf("ridge-wing", "eave-wing-left"), 1.0),
            GraphFace("wing-right", emptyList(), listOf("ridge-wing", "eave-wing-right"), 1.0)
        ).associateBy { it.id }
        return RoofGraph(GeoPoint(49.0, 18.0), nodes, edges, faces)
    }
}
