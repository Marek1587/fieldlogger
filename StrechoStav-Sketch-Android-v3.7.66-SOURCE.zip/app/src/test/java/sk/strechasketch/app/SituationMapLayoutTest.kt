package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SituationMapLayoutTest {
    private val outline = listOf(
        GeoPoint(49.06640, 18.92340),
        GeoPoint(49.06640, 18.92370),
        GeoPoint(49.06620, 18.92370),
        GeoPoint(49.06620, 18.92340)
    )

    @Test
    fun `complete outline stays inside deterministic situation viewport`() {
        val viewport = SituationMapLayout.create(outline, 21, 1400, 1840)

        assertTrue(viewport.polygonPixels.all { it.x in 0.0..1400.0 })
        assertTrue(viewport.polygonPixels.all { it.y in 0.0..1840.0 })
        assertTrue(viewport.polygonPixels.minOf { it.x } > 100.0)
        assertTrue(viewport.polygonPixels.maxOf { it.x } < 1300.0)
    }

    @Test
    fun `editor pan does not affect exported crop`() {
        val first = SituationMapLayout.create(outline, 20, 1200, 1600)
        val second = SituationMapLayout.create(outline, 20, 1200, 1600)

        assertEquals(first.worldLeft, second.worldLeft, 0.0)
        assertEquals(first.worldTop, second.worldTop, 0.0)
        assertEquals(first.polygonPixels, second.polygonPixels)
    }

    @Test
    fun `pdf situation always uses ZBGIS source zoom 20`() {
        val viewport = SituationMapLayout.createForPdf(outline, 1400, 1840)

        assertEquals(20, SituationMapLayout.PDF_SOURCE_ZOOM)
        assertEquals(20, viewport.sourceZoom)
    }

    @Test
    fun `very large outline remains fully visible`() {
        val large = listOf(
            GeoPoint(48.5, 17.0),
            GeoPoint(48.5, 20.0),
            GeoPoint(49.8, 20.0),
            GeoPoint(49.8, 17.0)
        )
        val viewport = SituationMapLayout.create(large, 21, 1400, 1840)

        assertTrue(viewport.polygonPixels.all { it.x in 0.0..1400.0 })
        assertTrue(viewport.polygonPixels.all { it.y in 0.0..1840.0 })
    }
}
