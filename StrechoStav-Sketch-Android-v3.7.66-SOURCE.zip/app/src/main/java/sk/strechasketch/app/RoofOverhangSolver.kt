package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Geometric overhang solver.
 *
 * Eaves and gables form one continuous roof perimeter. Parapets remain on the wall
 * line and never receive an overhang. Every contour is solved as a joined offset
 * polygon, therefore neighbouring sections use exactly the same miter vertex instead
 * of drawing two independent, overlapping rectangular strips.
 */
internal object RoofOverhangSolver {
    const val DEFAULT_FLAT_SOFFIT_DEPTH_M = 0.20
    const val DEFAULT_ROOF_SHELL_THICKNESS_M = 0.18

    internal data class Section(
        val edgeId: String,
        val semanticRole: EdgeSemantic,
        val outerTopA: GraphNode,
        val outerTopB: GraphNode,
        val outerBottomA: GraphNode,
        val outerBottomB: GraphNode,
        val flatInnerA: GraphNode,
        val flatInnerB: GraphNode,
        val wallInnerA: GraphNode,
        val wallInnerB: GraphNode,
        val overhangM: Double,
        val flatDepthM: Double
    )

    internal data class Solution(
        val eligibleEdgeIds: List<String>,
        val representativeOverhangM: Double,
        val sections: List<Section>
    )

    internal data class GableProfileSupport(val t: Double, val node: GraphNode)

    private data class SupportLine(
        val point: LocalPoint,
        val dx: Double,
        val dy: Double,
        val normalX: Double,
        val normalY: Double,
        val distance: Double
    )

    private fun supportsOverhang(role: EdgeSemantic): Boolean =
        role == EdgeSemantic.EAVE || role == EdgeSemantic.GABLE

    private fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx

    /**
     * Produces one mitered contour. The output has one point per input corner. A point
     * is consequently shared by the previous and next section, including hip corners.
     * Collinear solver-created gable splits are retained without making the contour fail.
     */
    internal fun selectiveWallFootprint(
        points: List<LocalPoint>,
        roles: List<EdgeSemantic>,
        overhangM: Double
    ): List<LocalPoint>? {
        if (points.size < 3 || roles.size != points.size || overhangM < 0.0) return null
        if (overhangM <= 1e-9) return points.map { it.copy() }

        val eligibleLengths = points.indices.mapNotNull { index ->
            if (!supportsOverhang(roles[index])) null else {
                val a = points[index]
                val b = points[(index + 1) % points.size]
                hypot(b.x - a.x, b.y - a.y)
            }
        }
        if (eligibleLengths.isEmpty()) return null
        // Do not limit by the shortest segment: a ridge incidence or an L-notch can
        // legitimately create a very short boundary fragment while the common overhang
        // remains valid. Final polygon validation below is the authoritative guard.
        val modelSpan = maxOf(
            points.maxOf { it.x } - points.minOf { it.x },
            points.maxOf { it.y } - points.minOf { it.y }
        ).coerceAtLeast(1e-9)
        if (overhangM >= modelSpan * 0.45) return null

        val twiceArea = points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        }
        val orientation = if (twiceArea >= 0.0) 1.0 else -1.0
        val lines = points.indices.map { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            val distance = if (supportsOverhang(roles[index])) overhangM else 0.0
            val nx = -dy / length * orientation
            val ny = dx / length * orientation
            SupportLine(
                point = LocalPoint(a.x + nx * distance, a.y + ny * distance),
                dx = dx,
                dy = dy,
                normalX = nx,
                normalY = ny,
                distance = distance
            )
        }

        val result = lines.indices.map { index ->
            val previous = lines[(index - 1 + lines.size) % lines.size]
            val current = lines[index]
            val denominator = cross(previous.dx, previous.dy, current.dx, current.dy)
            if (abs(denominator) < 1e-9) {
                // A ridge incidence can split one physical gable into two collinear
                // boundary edges. Both edges must keep one common offset support point.
                val vertex = points[index]
                val px = vertex.x + previous.normalX * previous.distance
                val py = vertex.y + previous.normalY * previous.distance
                val cx = vertex.x + current.normalX * current.distance
                val cy = vertex.y + current.normalY * current.distance
                LocalPoint((px + cx) / 2.0, (py + cy) / 2.0)
            } else {
                val qx = current.point.x - previous.point.x
                val qy = current.point.y - previous.point.y
                val t = cross(qx, qy, current.dx, current.dy) / denominator
                LocalPoint(previous.point.x + previous.dx * t, previous.point.y + previous.dy * t)
            }
        }
        if (result.any { !it.x.isFinite() || !it.y.isFinite() }) return null
        val resultArea = abs(result.indices.sumOf { index ->
            val a = result[index]
            val b = result[(index + 1) % result.size]
            a.x * b.y - b.x * a.y
        }) / 2.0
        if (resultArea <= 1e-5 || result.any { point ->
                !Geometry.pointInPolygon(point, points) && points.indices.none { index ->
                    Geometry.distanceToSegment(point, points[index], points[(index + 1) % points.size]) <= 1e-5
                }
            }
        ) return null
        return result
    }

    /**
     * Joined inset with one measured distance per physical boundary section.
     *
     * Unlike [selectiveWallFootprint], this is not a design-wide offset. It is used for
     * the short flat part of the soffit, whose depth is capped independently by the real
     * wall-to-roof distance of every section. Adjacent non-parallel supports meet in one
     * exact miter. A collinear split with unequal caps uses the smaller cap at the shared
     * node, producing a deterministic transition that can never overshoot either section.
     */
    private fun joinedInsetContour(
        points: List<LocalPoint>,
        distances: List<Double>
    ): List<LocalPoint>? {
        if (points.size < 3 || distances.size != points.size || distances.any { it < 0.0 || !it.isFinite() }) {
            return null
        }
        if (distances.all { it <= 1e-9 }) return points.map(LocalPoint::copy)
        val twiceArea = points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        }
        if (abs(twiceArea) <= 1e-9) return null
        val orientation = if (twiceArea >= 0.0) 1.0 else -1.0
        val lines = points.indices.map { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy)
            if (length <= 1e-9) return null
            val nx = -dy / length * orientation
            val ny = dx / length * orientation
            val distance = distances[index]
            SupportLine(
                point = LocalPoint(a.x + nx * distance, a.y + ny * distance),
                dx = dx,
                dy = dy,
                normalX = nx,
                normalY = ny,
                distance = distance
            )
        }
        val result = lines.indices.map { index ->
            val previous = lines[(index - 1 + lines.size) % lines.size]
            val current = lines[index]
            val denominator = cross(previous.dx, previous.dy, current.dx, current.dy)
            if (abs(denominator) < 1e-9) {
                val vertex = points[index]
                val distance = minOf(previous.distance, current.distance)
                val nx = previous.normalX + current.normalX
                val ny = previous.normalY + current.normalY
                val normalLength = hypot(nx, ny)
                val unitX = if (normalLength <= 1e-9) current.normalX else nx / normalLength
                val unitY = if (normalLength <= 1e-9) current.normalY else ny / normalLength
                LocalPoint(vertex.x + unitX * distance, vertex.y + unitY * distance)
            } else {
                val qx = current.point.x - previous.point.x
                val qy = current.point.y - previous.point.y
                val t = cross(qx, qy, current.dx, current.dy) / denominator
                LocalPoint(previous.point.x + previous.dx * t, previous.point.y + previous.dy * t)
            }
        }
        if (result.any { !it.x.isFinite() || !it.y.isFinite() }) return null
        val resultArea = abs(result.indices.sumOf { index ->
            val a = result[index]
            val b = result[(index + 1) % result.size]
            a.x * b.y - b.x * a.y
        }) / 2.0
        if (resultArea <= 1e-5 || result.any { point ->
                !Geometry.pointInPolygon(point, points) && points.indices.none { index ->
                    Geometry.distanceToSegment(point, points[index], points[(index + 1) % points.size]) <= 1e-5
                }
            }
        ) return null
        return result
    }

    /** EAVE and GABLE supports move; ATTIC and all other roles stay fixed. */
    fun selectiveWallFootprint(graph: RoofGraph, overhangM: Double): List<LocalPoint>? {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology()) ?: return null
        val points = ordered.first.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        val roles = ordered.second.map { graph.edges[it.id]?.semanticRole ?: EdgeSemantic.UNKNOWN }
        return selectiveWallFootprint(points, roles, overhangM)
    }

    /**
     * Projects solver incidence nodes (especially a ridge endpoint) from the outer
     * gable edge to its inset masonry edge. This is a derived construction node: it
     * fills the gable but never splits the saved physical wall or adds a facade seam.
     */
    fun gableProfileSupports(
        graph: RoofGraph,
        roofA: LocalPoint,
        roofB: LocalPoint,
        wallA: LocalPoint,
        wallB: LocalPoint,
        wallHeightM: Double,
        toleranceM: Double
    ): List<GableProfileSupport> {
        val roofDx = roofB.x - roofA.x
        val roofDy = roofB.y - roofA.y
        val roofLengthSquared = roofDx * roofDx + roofDy * roofDy
        if (roofLengthSquared <= 1e-10) return emptyList()
        val wallDx = wallB.x - wallA.x
        val wallDy = wallB.y - wallA.y
        val boundaryNodeIds = graph.edges.values.asSequence()
            .filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
            .toSet()
        val incidenceNodeIds = graph.edges.values.asSequence()
            .filter { it.semanticRole == EdgeSemantic.RIDGE }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
            .toSet()
        return (boundaryNodeIds + incidenceNodeIds).mapNotNull(graph.nodes::get)
            .mapNotNull { source ->
                val t = ((source.x - roofA.x) * roofDx + (source.y - roofA.y) * roofDy) /
                    roofLengthSquared
                if (t !in -1e-6..1.000001 ||
                    Geometry.distanceToSegment(LocalPoint(source.x, source.y), roofA, roofB) > toleranceM
                ) return@mapNotNull null
                val clamped = t.coerceIn(0.0, 1.0)
                GableProfileSupport(
                    clamped,
                    GraphNode(
                        id = "gable-wall-support-${source.id}",
                        x = wallA.x + wallDx * clamped,
                        y = wallA.y + wallDy * clamped,
                        z = maxOf(wallHeightM, source.z)
                    )
                )
            }
            .sortedBy { it.t }
    }

    fun solve(
        graph: RoofGraph,
        wallLoop: List<LocalPoint>,
        roofThicknessM: Double = DEFAULT_ROOF_SHELL_THICKNESS_M,
        flatSoffitDepthM: Double = DEFAULT_FLAT_SOFFIT_DEPTH_M
    ): Solution {
        val surface = SolvedRoofSurfaceGeometry.from(graph)
            ?: return Solution(emptyList(), 0.0, emptyList())
        val nodes = surface.nodeIds.mapNotNull(graph.nodes::get)
        val edges = surface.edges
        if (nodes.size < 3 || edges.size != nodes.size || wallLoop.size < 3) {
            return Solution(emptyList(), 0.0, emptyList())
        }
        val eligibleIds = edges.filter { supportsOverhang(it.semanticRole) }.map { it.id }
        if (eligibleIds.isEmpty()) return Solution(emptyList(), 0.0, emptyList())

        val roofPoints = nodes.map { LocalPoint(it.x, it.y) }
        val innerContour = expandWallContour(roofPoints, wallLoop)
            ?: return Solution(eligibleIds, 0.0, emptyList())
        data class Candidate(
            val section: SolvedRoofSurfaceGeometry.BoundarySection,
            val measuredDepth: Double
        )
        val candidates = surface.sections.mapIndexed { index, section ->
            if (!supportsOverhang(section.edge.semanticRole)) return@mapIndexed null
            val a = roofPoints[index]
            val b = roofPoints[(index + 1) % roofPoints.size]
            val innerA = innerContour[index]
            val innerB = innerContour[(index + 1) % innerContour.size]
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= 1e-8) return@mapIndexed null
            val innerMid = LocalPoint((innerA.x + innerB.x) / 2.0, (innerA.y + innerB.y) / 2.0)
            val depth = abs(
                (innerMid.x - a.x) * (b.y - a.y) -
                    (innerMid.y - a.y) * (b.x - a.x)
            ) / length
            Candidate(section, depth)
        }
        val positiveDepths = candidates.mapNotNull { it?.measuredDepth }
            .filter { it > 0.001 }.sorted()
        val representative = when {
            positiveDepths.isEmpty() -> 0.0
            positiveDepths.size % 2 == 1 -> positiveDepths[positiveDepths.size / 2]
            else -> (positiveDepths[positiveDepths.size / 2 - 1] + positiveDepths[positiveDepths.size / 2]) / 2.0
        }
        if (representative <= 0.001) return Solution(eligibleIds, 0.0, emptyList())

        val maximumFlatDepth = flatSoffitDepthM.coerceAtLeast(0.0)
        val localFlatDepths = candidates.map { candidate ->
            if (candidate == null) 0.0 else minOf(maximumFlatDepth, candidate.measuredDepth)
        }
        val flatContour = joinedInsetContour(roofPoints, localFlatDepths)
            ?: roofPoints.indices.map { index ->
                val depth = listOfNotNull(
                    candidates[index]?.measuredDepth,
                    candidates[(index - 1 + candidates.size) % candidates.size]?.measuredDepth
                ).filter { it > 1e-8 }.minOrNull() ?: representative
                val localDepth = minOf(
                    localFlatDepths[index],
                    localFlatDepths[(index - 1 + localFlatDepths.size) % localFlatDepths.size]
                )
                val fraction = (localDepth / depth).coerceIn(0.0, 1.0)
                LocalPoint(
                    roofPoints[index].x + (innerContour[index].x - roofPoints[index].x) * fraction,
                    roofPoints[index].y + (innerContour[index].y - roofPoints[index].y) * fraction
                )
            }
        val shellThickness = roofThicknessM.coerceIn(0.05, 0.60)

        data class HeightSample(val edgeId: String, val role: EdgeSemantic, val z: Double)
        data class CornerHeights(val flat: Double, val wall: Double)
        fun selectMiterHeight(samples: List<HeightSample>): Double {
            val finite = samples.filter { it.z.isFinite() }
            if (finite.isEmpty()) return 0.0
            if (finite.maxOf { it.z } - finite.minOf { it.z } <= 1e-6) {
                return finite.map { it.z }.average()
            }
            // The eave defines the horizontal fascia/soffit datum. If two solved planes
            // disagree outside the roof boundary, this deterministic owner creates one
            // shared miter vertex instead of two coincident XY vertices at different Z.
            return finite.minWith(
                compareBy<HeightSample> {
                    when (it.role) {
                        EdgeSemantic.EAVE -> 0
                        EdgeSemantic.GABLE -> 1
                        else -> 2
                    }
                }.thenBy { it.edgeId }
            ).z
        }
        val cornerHeights = roofPoints.indices.map { index ->
            val previousIndex = (index - 1 + candidates.size) % candidates.size
            val pointFlat = flatContour[index]
            val pointWall = innerContour[index]
            val flatSamples = buildList {
                candidates[previousIndex]?.let { candidate ->
                    val canonical = candidate.section
                    add(HeightSample(
                        canonical.edge.id,
                        canonical.edge.semanticRole,
                        if (canonical.edge.semanticRole == EdgeSemantic.EAVE) canonical.bottomB(shellThickness).z
                        else canonical.undersideZAt(pointFlat, shellThickness)
                    ))
                }
                candidates[index]?.let { candidate ->
                    val canonical = candidate.section
                    add(HeightSample(
                        canonical.edge.id,
                        canonical.edge.semanticRole,
                        if (canonical.edge.semanticRole == EdgeSemantic.EAVE) canonical.bottomA(shellThickness).z
                        else canonical.undersideZAt(pointFlat, shellThickness)
                    ))
                }
            }
            val wallSamples = buildList {
                candidates[previousIndex]?.section?.let { canonical ->
                    add(HeightSample(
                        canonical.edge.id, canonical.edge.semanticRole,
                        canonical.undersideZAt(pointWall, shellThickness)
                    ))
                }
                candidates[index]?.section?.let { canonical ->
                    add(HeightSample(
                        canonical.edge.id, canonical.edge.semanticRole,
                        canonical.undersideZAt(pointWall, shellThickness)
                    ))
                }
            }
            CornerHeights(selectMiterHeight(flatSamples), selectMiterHeight(wallSamples))
        }

        val sections = edges.indices.mapNotNull { index ->
            val candidate = candidates[index] ?: return@mapNotNull null
            val next = (index + 1) % nodes.size
            val canonical = candidate.section
            val outerTopA = canonical.topA
            val outerTopB = canonical.topB
            val outerBottomA = canonical.bottomA(shellThickness).copy(id = "overhang-fascia-${outerTopA.id}")
            val outerBottomB = canonical.bottomB(shellThickness).copy(id = "overhang-fascia-${outerTopB.id}")
            fun node(id: String, point: LocalPoint, z: Double) = GraphNode(id, point.x, point.y, z)
            val flatA = flatContour[index]
            val flatB = flatContour[next]
            val wallA = innerContour[index]
            val wallB = innerContour[next]
            Section(
                edgeId = canonical.edge.id,
                semanticRole = canonical.edge.semanticRole,
                outerTopA = outerTopA,
                outerTopB = outerTopB,
                outerBottomA = outerBottomA,
                outerBottomB = outerBottomB,
                flatInnerA = node(
                    "overhang-soffit-${outerTopA.id}", flatA,
                    cornerHeights[index].flat
                ),
                flatInnerB = node(
                    "overhang-soffit-${outerTopB.id}", flatB,
                    cornerHeights[next].flat
                ),
                wallInnerA = node(
                    "overhang-wall-${outerTopA.id}", wallA,
                    cornerHeights[index].wall
                ),
                wallInnerB = node(
                    "overhang-wall-${outerTopB.id}", wallB,
                    cornerHeights[next].wall
                ),
                overhangM = candidate.measuredDepth,
                flatDepthM = localFlatDepths[index]
            )
        }
        return Solution(eligibleIds, representative, sections)
    }

    /**
     * Expands a physical masonry loop to the disposable runtime boundary inventory without
     * inventing another offset polygon. Collinear ridge-incidence nodes are interpolated on
     * the corresponding saved wall segment; real corners remain exact wall-footprint corners.
     */
    private fun expandWallContour(
        roof: List<LocalPoint>,
        wall: List<LocalPoint>
    ): List<LocalPoint>? {
        if (roof.size < 3 || wall.size < 3) return null

        fun align(reference: List<LocalPoint>, candidate: List<LocalPoint>): List<LocalPoint>? {
            if (reference.size != candidate.size) return null
            fun shifted(source: List<LocalPoint>, shift: Int) =
                List(source.size) { index -> source[(index + shift) % source.size] }
            return listOf(candidate, candidate.reversed()).flatMap { orientation ->
                orientation.indices.map { shift -> shifted(orientation, shift) }
            }.minByOrNull { loop ->
                loop.indices.sumOf { index ->
                    val dx = loop[index].x - reference[index].x
                    val dy = loop[index].y - reference[index].y
                    dx * dx + dy * dy
                }
            }
        }

        align(roof, wall)?.let { return it.map(LocalPoint::copy) }

        val corners = roof.indices.filter { index ->
            val previous = roof[(index - 1 + roof.size) % roof.size]
            val point = roof[index]
            val next = roof[(index + 1) % roof.size]
            val ax = point.x - previous.x
            val ay = point.y - previous.y
            val bx = next.x - point.x
            val by = next.y - point.y
            val scale = (hypot(ax, ay) * hypot(bx, by)).coerceAtLeast(1.0)
            abs(cross(ax, ay, bx, by)) > 1e-8 * scale || ax * bx + ay * by <= 0.0
        }
        val alignedCorners = align(corners.map(roof::get), wall)
        if (corners.size >= 3 && alignedCorners != null) {
            val expanded = MutableList<LocalPoint?>(roof.size) { null }
            corners.indices.forEach { cornerIndex ->
                val startIndex = corners[cornerIndex]
                val endIndex = corners[(cornerIndex + 1) % corners.size]
                val roofA = roof[startIndex]
                val roofB = roof[endIndex]
                val wallA = alignedCorners[cornerIndex]
                val wallB = alignedCorners[(cornerIndex + 1) % alignedCorners.size]
                val dx = roofB.x - roofA.x
                val dy = roofB.y - roofA.y
                val denominator = dx * dx + dy * dy
                var index = startIndex
                while (true) {
                    val point = roof[index]
                    val t = if (denominator <= 1e-12) 0.0 else
                        (((point.x - roofA.x) * dx + (point.y - roofA.y) * dy) / denominator)
                            .coerceIn(0.0, 1.0)
                    expanded[index] = LocalPoint(
                        wallA.x + (wallB.x - wallA.x) * t,
                        wallA.y + (wallB.y - wallA.y) * t
                    )
                    if (index == endIndex) break
                    index = (index + 1) % roof.size
                }
            }
            if (expanded.all { it != null }) return expanded.map { requireNotNull(it) }
        }

        fun closest(point: LocalPoint): LocalPoint = wall.indices.map { index ->
            val a = wall[index]
            val b = wall[(index + 1) % wall.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val denominator = dx * dx + dy * dy
            val t = if (denominator <= 1e-12) 0.0 else
                (((point.x - a.x) * dx + (point.y - a.y) * dy) / denominator).coerceIn(0.0, 1.0)
            LocalPoint(a.x + dx * t, a.y + dy * t)
        }.minBy { candidate -> hypot(candidate.x - point.x, candidate.y - point.y) }
        return roof.map(::closest)
    }
}
