package sk.strechasketch.app

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class BudgetOfferHeader(
    val title: String,
    val customer: String,
    val siteAddress: String,
    val contact: String,
    val jobCode: String,
    val description: String,
    val technologyStage: String,
    val buildingObject: String,
    val classification: String,
    val processedDate: String,
    val validUntil: String,
    val preparedBy: String
)

data class BudgetOffer(
    val header: BudgetOfferHeader,
    val items: List<ResolvedWorkItem>,
    val subtotal: Double,
    val vatPercent: Double,
    val vat: Double,
    val totalWithVat: Double,
    val missingPriceCount: Int
)

/**
 * Builds the commercial document from exactly the same resolved work-scope quantities
 * that are visible in the application. It never recalculates roof geometry on its own.
 */
object BudgetOfferBuilder {
    private val slovak = Locale("sk", "SK")

    fun build(project: RoofProject, nowMillis: Long = System.currentTimeMillis()): BudgetOffer {
        val selected = WorkScopeEngine.resolve(project)
            .filter { project.selectedWorkItems[it.item.code]?.selected == true }
            .sortedWith(compareBy<ResolvedWorkItem> { it.item.budgetOrder }.thenBy { it.item.code })
        val subtotal = selected.mapNotNull { it.totalPrice }.sum()
        val vatPercent = project.budgetVatPercent.coerceIn(0.0, 100.0)
        val vat = subtotal * vatPercent / 100.0
        val date = Date(nowMillis)
        val validCalendar = Calendar.getInstance(slovak).apply {
            time = date
            add(Calendar.DAY_OF_YEAR, 180)
        }
        val format = SimpleDateFormat("dd.MM.yyyy", slovak)
        return BudgetOffer(
            header = BudgetOfferHeader(
                title = project.name.ifBlank { "Strecha" },
                customer = project.customer.ifBlank { "—" },
                siteAddress = project.address.ifBlank { "—" },
                contact = project.customer.ifBlank { "—" },
                jobCode = project.id.filter(Char::isLetterOrDigit).uppercase().take(20).ifBlank { "—" },
                description = "Kalkulácia prác a materiálov pre realizáciu strechy",
                technologyStage = "Realizácia strešnej konštrukcie a príslušenstva",
                buildingObject = "Strecha objektu",
                classification = "Strešné konštrukcie a práce",
                processedDate = format.format(date),
                validUntil = format.format(validCalendar.time),
                preparedBy = "StrechoStav Sketch"
            ),
            items = selected,
            subtotal = subtotal,
            vatPercent = vatPercent,
            vat = vat,
            totalWithVat = subtotal + vat,
            missingPriceCount = selected.count { it.unitPrice == null }
        )
    }
}
