package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.sqrt

data class FaceQuantityAudit(
    val faceId: String,
    val area3DM2: Double,
    val plane: RoofPlane,
    val underconstrained: Boolean
)

data class EdgeQuantityAudit(
    val edgeId: String,
    val semanticRole: EdgeSemantic,
    val boundary: Boolean,
    val length3DM: Double
)

data class RoofQuantityAudit(
    val graph: RoofGraph,
    val faces: List<FaceQuantityAudit>,
    val edges: List<EdgeQuantityAudit>,
    val totals: ProjectTotals,
    val solverIssues: List<RoofPlaneSolverIssue> = emptyList()
)

object RoofQuantityEngine {
    fun calculate(project: RoofProject): RoofQuantityAudit {
        return calculate(project, Roof3DPreparation.prepare(project))
    }

    /** Uses an already prepared graph so BIM/PDF/export pipelines never solve the same roof twice. */
    fun calculate(project: RoofProject, preparation: Roof3DPreparationResult): RoofQuantityAudit {
        val baseGraph = preparation.graph
        val solution = preparation.planeSolution
        if (solution.hasBlockingIssues) {
            fun count(type: ObjectType) = project.objects.count {
                it.type == type && (type != ObjectType.DOWNSPOUT || !it.downspoutSuppressed)
            }
            val rainwater = RainwaterDrainageSolver.solve(baseGraph, explicitObjects = project.objects)
            return RoofQuantityAudit(baseGraph, emptyList(), emptyList(), ProjectTotals(
                Geometry.areaM2(project.polygon), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                count(ObjectType.CHIMNEY), count(ObjectType.ROOF_WINDOW), count(ObjectType.HATCH), count(ObjectType.VENT),
                count(ObjectType.DRAIN), maxOf(count(ObjectType.DOWNSPOUT), rainwater.downspouts.size),
                count(ObjectType.HEIGHT_MARK), count(ObjectType.SLOPE_MARK),
                rainwater.gutterHooks.size, rainwater.downspoutClamps.size,
                rainwater.innerCorners90, rainwater.outerCorners90
            ), solution.issues)
        }
        val superstructures = RoofSuperstructureSolver.solve(solution.graph, project.objects)
        val solved = superstructures.graphWithOpenings
        fun ringArea(ids: List<String>): Double = abs(ids.mapNotNull(solved.nodes::get).let { nodes ->
            nodes.indices.sumOf { index ->
                val a = nodes[index]; val b = nodes[(index + 1) % nodes.size]
                a.x * b.y - b.x * a.y
            } / 2.0
        })
        fun netPlanArea(face: GraphFace): Double = (ringArea(face.orderedNodeIds) - face.holeNodeIdLoops.sumOf(::ringArea)).coerceAtLeast(0.0)
        val faces = solved.faces.values.sortedBy { it.id }.mapNotNull { face ->
            val plane = face.plane ?: return@mapNotNull null
            FaceQuantityAudit(
                face.id,
                netPlanArea(face) * sqrt(1.0 + plane.a * plane.a + plane.b * plane.b),
                plane,
                face.underconstrained
            )
        }
        val edges = solved.edges.values.sortedBy { it.id }.mapNotNull { edge ->
            val a = solved.nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = solved.nodes[edge.endNodeId] ?: return@mapNotNull null
            EdgeQuantityAudit(
                edge.id,
                edge.semanticRole,
                edge.boundary,
                sqrt((b.x - a.x) * (b.x - a.x) + (b.y - a.y) * (b.y - a.y) + (b.z - a.z) * (b.z - a.z))
            )
        }
        fun length(role: EdgeSemantic) = edges.filter { it.semanticRole == role }.sumOf { it.length3DM }
        fun count(type: ObjectType) = project.objects.count {
            it.type == type && (type != ObjectType.DOWNSPOUT || !it.downspoutSuppressed)
        }
        val rainwater = RainwaterDrainageSolver.solve(solved, explicitObjects = project.objects)
        // Openings for dormers and terraces reduce the covering, not the building footprint.
        val footprint = solved.faces.values.sumOf { ringArea(it.orderedNodeIds) }
            .takeIf { it > 0.0 } ?: Geometry.areaM2(project.polygon)
        val totals = ProjectTotals(
            footprintAreaM2 = footprint,
            roofAreaM2 = (
                faces.sumOf { it.area3DM2 } -
                    superstructures.items.filter { it.projectsBeyondHost }.sumOf { it.openingArea3DM2 } +
                    superstructures.items.sumOf { it.addedRoofAreaM2 }
                ).coerceAtLeast(0.0),
            perimeterM = edges.filter { it.boundary }.sumOf { it.length3DM },
            ridgeM = length(EdgeSemantic.RIDGE),
            valleyM = length(EdgeSemantic.VALLEY),
            hipM = length(EdgeSemantic.HIP),
            atticM = length(EdgeSemantic.ATTIC),
            pultM = length(EdgeSemantic.PULT),
            wallEndM = length(EdgeSemantic.WALL_END),
            eaveM = length(EdgeSemantic.EAVE),
            gableM = length(EdgeSemantic.GABLE),
            chimneys = count(ObjectType.CHIMNEY),
            roofWindows = count(ObjectType.ROOF_WINDOW),
            hatches = count(ObjectType.HATCH),
            vents = count(ObjectType.VENT),
            drains = count(ObjectType.DRAIN),
            downspouts = maxOf(count(ObjectType.DOWNSPOUT), rainwater.downspouts.size),
            heightMarks = count(ObjectType.HEIGHT_MARK),
            slopeMarks = count(ObjectType.SLOPE_MARK),
            gutterHooks = rainwater.gutterHooks.size,
            downspoutClamps = rainwater.downspoutClamps.size,
            innerGutterCorners90 = rainwater.innerCorners90,
            outerGutterCorners90 = rainwater.outerCorners90,
            dormers = count(ObjectType.DORMER),
            machineRooms = count(ObjectType.MACHINE_ROOM),
            shafts = count(ObjectType.SHAFT),
            terraces = count(ObjectType.TERRACE),
            superstructureOpeningAreaM2 = superstructures.items.sumOf { it.openingPlanAreaM2 },
            superstructureRoofAreaM2 = superstructures.items.sumOf { it.addedRoofAreaM2 }
        )
        return RoofQuantityAudit(solved, faces, edges, totals, solution.issues)
    }
}
