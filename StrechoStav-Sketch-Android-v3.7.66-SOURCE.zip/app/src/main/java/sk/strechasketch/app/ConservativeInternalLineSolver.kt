package sk.strechasketch.app

/**
 * Source-compatible entry point retained for integrations compiled against earlier releases.
 * There is no longer a second "conservative" interpretation of the geometry: every call is
 * routed to the same hierarchical project-grid solver used by the internal-lines card.
 */
@Deprecated("Use HierarchicalInternalLineSolver; this name is only a compatibility alias.")
object ConservativeInternalLineSolver {
    fun solve(
        input: RoofTopology,
        angleToleranceDeg: Double = 10.0,
        maximumLengthChangeFraction: Double = 0.10,
        snapToleranceM: Double = 0.35,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofSolverPreview {
        @Suppress("UNUSED_VARIABLE") val retainedAngleTolerance = angleToleranceDeg
        @Suppress("UNUSED_VARIABLE") val retainedLengthLimit = maximumLengthChangeFraction
        return HierarchicalInternalLineSolver.solve(
            input = input,
            footprintContext = footprintContext,
            junctionToleranceM = snapToleranceM
        )
    }
}
