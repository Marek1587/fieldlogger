package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Strict plan-incidence gate for the physical anthracite roof envelope.
 *
 * A partial set of faces must never continue to walls, soffit, outlines or drainage. Those
 * consumers all use [SolvedRoofSurfaceGeometry], therefore preparation blocks before solving Z
 * unless the faces form one complete, simple and triangulatable subdivision of the boundary.
 */
internal object RoofSurfaceCoverageValidator {
    private const val EPSILON = 1e-8

    fun validate(graph: RoofGraph): List<RoofPlaneSolverIssue> {
        val issues = mutableListOf<RoofPlaneSolverIssue>()
        val orderedBoundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())
        if (orderedBoundary == null) {
            return listOf(issue(
                "ROOF_SURFACE_BOUNDARY_CYCLE",
                "Obvod strechy netvorí jeden uzavretý cyklus. Neúplný 3D plášť sa nevytvoril."
            ))
        }
        val boundaryPoints = orderedBoundary.first.map { id ->
            val node = graph.nodes[id]
            if (node == null || !node.x.isFinite() || !node.y.isFinite()) {
                issues += issue(
                    "ROOF_SURFACE_BOUNDARY_NODE",
                    "Obvod strechy odkazuje na chýbajúci alebo neplatný uzol."
                )
                null
            } else LocalPoint(node.x, node.y)
        }
        if (issues.isNotEmpty()) return issues
        val concreteBoundary = boundaryPoints.filterNotNull()
        val boundaryArea = abs(signedArea(concreteBoundary))
        if (concreteBoundary.size < 3 || boundaryArea <= EPSILON || !isSimple(concreteBoundary)) {
            return listOf(issue(
                "ROOF_SURFACE_BOUNDARY_SHAPE",
                "Obvod strechy je degenerovaný alebo sa pretína. Neúplný 3D plášť sa nevytvoril."
            ))
        }

        graph.edges.values.sortedBy { it.id }.forEach { edge ->
            val actualOwners = graph.faces.values.count { edge.id in it.orderedEdgeIds }
            val requiredOwners = if (edge.boundary) 1 else 2
            if (actualOwners != requiredOwners) issues += issue(
                "ROOF_SURFACE_EDGE_INCIDENCE",
                "${if (edge.boundary) "Obvodová" else "Vnútorná"} hrana ${edge.id} má " +
                    "$actualOwners susedných plôch namiesto $requiredOwners."
            )
        }

        var coveredArea = 0.0
        graph.faces.values.sortedBy { it.id }.forEach { face ->
            val points = face.orderedNodeIds.map { id -> graph.nodes[id] }
            val distinctNodeCount = face.orderedNodeIds.toSet().size
            if (points.any { it == null } || face.orderedNodeIds.size < 3 ||
                distinctNodeCount != face.orderedNodeIds.size ||
                face.orderedEdgeIds.size != face.orderedNodeIds.size
            ) {
                issues += issue(
                    "ROOF_SURFACE_FACE_CYCLE",
                    "Strešná plocha ${face.id} nemá úplný cyklus uzlov a hrán.",
                    face.id
                )
                return@forEach
            }
            val concreteNodes = points.filterNotNull()
            val polygon = concreteNodes.map { LocalPoint(it.x, it.y) }
            val edgesMatchCycle = face.orderedEdgeIds.indices.all { index ->
                val edge = graph.edges[face.orderedEdgeIds[index]] ?: return@all false
                val start = face.orderedNodeIds[index]
                val end = face.orderedNodeIds[(index + 1) % face.orderedNodeIds.size]
                (edge.startNodeId == start && edge.endNodeId == end) ||
                    (edge.startNodeId == end && edge.endNodeId == start)
            }
            if (!edgesMatchCycle) {
                issues += issue(
                    "ROOF_SURFACE_FACE_EDGE_ORDER",
                    "Hrany strešnej plochy ${face.id} nenadväzujú na jej uzly v jednom cykle.",
                    face.id
                )
                return@forEach
            }
            val ridgeVectors = face.orderedEdgeIds.mapNotNull(graph.edges::get)
                .filter { it.semanticRole == EdgeSemantic.RIDGE }
                .mapNotNull { edge ->
                    val start = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                    val end = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                    val dx = end.x - start.x
                    val dy = end.y - start.y
                    val length = hypot(dx, dy)
                    if (length <= EPSILON) null else LocalPoint(dx / length, dy / length)
                }
            val hasNonParallelRidges = ridgeVectors.indices.any { first ->
                (first + 1 until ridgeVectors.size).any { second ->
                    abs(ridgeVectors[first].x * ridgeVectors[second].y -
                        ridgeVectors[first].y * ridgeVectors[second].x) > 1e-6
                }
            }
            if (hasNonParallelRidges) {
                issues += issue(
                    "ROOF_SURFACE_MISSING_RIDGE_SPLIT",
                    "Strešná plocha ${face.id} obsahuje neparalelné hrebeňové úseky; " +
                        "v ich spoločnom uzle chýba rozdelenie plochy.",
                    face.id
                )
                return@forEach
            }
            if (!isSimple(polygon)) {
                issues += issue(
                    "ROOF_SURFACE_FACE_SELF_INTERSECTION",
                    "Strešná plocha ${face.id} sa pretína.",
                    face.id
                )
                return@forEach
            }
            val outerArea = abs(signedArea(polygon))
            if (outerArea <= EPSILON || !isTriangulatable(polygon)) {
                issues += issue(
                    "ROOF_SURFACE_FACE_NOT_TRIANGULATABLE",
                    "Strešnú plochu ${face.id} nemožno bezpečne triangulovať.",
                    face.id
                )
                return@forEach
            }
            val holesArea = face.holeNodeIdLoops.sumOf { loop ->
                val hole = loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
                if (hole.size == loop.size && hole.size >= 3 && isSimple(hole)) abs(signedArea(hole))
                else {
                    issues += issue(
                        "ROOF_SURFACE_HOLE_CYCLE",
                        "Otvor v strešnej ploche ${face.id} nemá platný cyklus.",
                        face.id
                    )
                    0.0
                }
            }
            coveredArea += outerArea - holesArea
        }

        val areaTolerance = max(1e-6, boundaryArea * 1e-8)
        if (abs(coveredArea - boundaryArea) > areaTolerance) issues += issue(
            "ROOF_SURFACE_AREA_MISMATCH",
            "Strešné plochy pokrývajú ${"%.3f".format(coveredArea)} m², ale obvod má " +
                "${"%.3f".format(boundaryArea)} m². Čiastočný 3D plášť sa nevytvoril."
        )
        return issues.distinctBy { Triple(it.code, it.faceId, it.message) }
    }

    private fun issue(code: String, message: String, faceId: String? = null) =
        RoofPlaneSolverIssue(code, message, faceId = faceId, blocking = true)

    private fun signedArea(points: List<LocalPoint>): Double = points.indices.sumOf { index ->
        val a = points[index]
        val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    private fun isSimple(points: List<LocalPoint>): Boolean {
        if (points.size < 3) return false
        for (i in points.indices) {
            val a = points[i]
            val b = points[(i + 1) % points.size]
            if ((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) <= EPSILON * EPSILON) {
                return false
            }
            for (j in i + 1 until points.size) {
                if (j == i || j == (i + 1) % points.size || (j + 1) % points.size == i) continue
                val c = points[j]
                val d = points[(j + 1) % points.size]
                if (segmentsIntersect(a, b, c, d)) return false
            }
        }
        return true
    }

    private fun segmentsIntersect(a: LocalPoint, b: LocalPoint, c: LocalPoint, d: LocalPoint): Boolean {
        fun cross(p: LocalPoint, q: LocalPoint, r: LocalPoint) =
            (q.x - p.x) * (r.y - p.y) - (q.y - p.y) * (r.x - p.x)
        fun onSegment(p: LocalPoint, q: LocalPoint, r: LocalPoint): Boolean =
            q.x >= min(p.x, r.x) - EPSILON && q.x <= max(p.x, r.x) + EPSILON &&
                q.y >= min(p.y, r.y) - EPSILON && q.y <= max(p.y, r.y) + EPSILON
        val abC = cross(a, b, c)
        val abD = cross(a, b, d)
        val cdA = cross(c, d, a)
        val cdB = cross(c, d, b)
        if ((abC > EPSILON && abD < -EPSILON || abC < -EPSILON && abD > EPSILON) &&
            (cdA > EPSILON && cdB < -EPSILON || cdA < -EPSILON && cdB > EPSILON)
        ) return true
        return abs(abC) <= EPSILON && onSegment(a, c, b) ||
            abs(abD) <= EPSILON && onSegment(a, d, b) ||
            abs(cdA) <= EPSILON && onSegment(c, a, d) ||
            abs(cdB) <= EPSILON && onSegment(c, b, d)
    }

    /** Mirrors the renderer's deterministic ear-clipping acceptance rule. */
    private fun isTriangulatable(points: List<LocalPoint>): Boolean {
        fun cross(a: LocalPoint, b: LocalPoint, c: LocalPoint) =
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        fun inside(p: LocalPoint, a: LocalPoint, b: LocalPoint, c: LocalPoint): Boolean =
            cross(a, b, p) >= -EPSILON && cross(b, c, p) >= -EPSILON &&
                cross(c, a, p) >= -EPSILON
        val indices = if (signedArea(points) >= 0.0) points.indices.toMutableList()
        else points.indices.reversed().toMutableList()
        var guard = 0
        var triangleCount = 0
        while (indices.size > 3 && guard++ < points.size * points.size) {
            var clipped = false
            for (position in indices.indices) {
                val previous = indices[(position - 1 + indices.size) % indices.size]
                val current = indices[position]
                val next = indices[(position + 1) % indices.size]
                if (cross(points[previous], points[current], points[next]) <= EPSILON) continue
                if (indices.any { candidate ->
                        candidate != previous && candidate != current && candidate != next &&
                            inside(points[candidate], points[previous], points[current], points[next])
                    }
                ) continue
                indices.removeAt(position)
                triangleCount++
                clipped = true
                break
            }
            if (!clipped) return false
        }
        if (indices.size == 3 && abs(cross(points[indices[0]], points[indices[1]], points[indices[2]])) > EPSILON) {
            triangleCount++
        }
        return triangleCount == points.size - 2
    }
}
