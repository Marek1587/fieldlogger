package sk.strechasketch.app.bim.ifc

import java.nio.charset.StandardCharsets
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Locale

object IfcStepWriter {
    fun write(model: Ifc43Model): ByteArray {
        val entities = model.entities.sortedBy { it.stableKey }
        val ids = entities.mapIndexed { index, entity -> entity.stableKey to index + 1 }.toMap()
        fun render(value: IfcStepValue): String = when (value) {
            IfcStepValue.Omitted -> "$"
            IfcStepValue.Derived -> "*"
            is IfcStepValue.Text -> IfcStepString.quote(value.value)
            is IfcStepValue.Number -> formatNumber(value.value)
            is IfcStepValue.Integer -> value.value.toString()
            is IfcStepValue.Enum -> ".${value.value.uppercase()}."
            is IfcStepValue.Boolean -> if (value.value) ".T." else ".F."
            is IfcStepValue.Reference -> "#${ids[value.stableKey] ?: error("Dangling stable reference ${value.stableKey}")}"
            is IfcStepValue.Values -> value.values.joinToString(",", "(", ")", transform = ::render)
            is IfcStepValue.Typed -> "${value.type.uppercase()}(${render(value.value)})"
        }
        val timestamp = DateTimeFormatter.ISO_OFFSET_DATE_TIME.format(model.timestamp.atOffset(ZoneOffset.UTC))
        val text = buildString {
            appendLine("ISO-10303-21;")
            appendLine("HEADER;")
            appendLine("FILE_DESCRIPTION(('StrechoStav Sketch IFC export'),'2;1');")
            appendLine("FILE_NAME(${IfcStepString.quote(model.fileName)},${IfcStepString.quote(timestamp)},(),('StrechoStav'),${IfcStepString.quote("StrechoStav Sketch ${model.applicationVersion}")},'StrechoStav Sketch','');")
            appendLine("FILE_SCHEMA(('IFC4X3_ADD2'));")
            appendLine("ENDSEC;")
            appendLine("DATA;")
            entities.forEachIndexed { index, entity ->
                append('#').append(index + 1).append('=').append(entity.type).append('(')
                append(entity.attributes.joinToString(",", transform = ::render))
                appendLine(");")
            }
            appendLine("ENDSEC;")
            appendLine("END-ISO-10303-21;")
        }
        return text.toByteArray(StandardCharsets.US_ASCII)
    }

    private fun formatNumber(value: Double): String {
        require(value.isFinite()) { "IFC STEP cannot contain NaN or Infinity." }
        if (value == 0.0) return "0."
        val raw = String.format(Locale.US, "%.12f", value).trimEnd('0')
        return if (raw.endsWith('.')) raw else if ('.' in raw) raw else "$raw."
    }
}
