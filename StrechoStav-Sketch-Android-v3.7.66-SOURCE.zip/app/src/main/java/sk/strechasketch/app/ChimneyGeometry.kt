package sk.strechasketch.app

/** Normative LOD100 geometry shared by interactive, bitmap and plan renderers. */
internal object ChimneyGeometry {
    const val CAP_THICKNESS_M = 0.10
    const val CAP_OVERHANG_M = 0.05

    fun capSize(bodySizeM: Double): Double =
        bodySizeM.coerceAtLeast(0.10) + 2.0 * CAP_OVERHANG_M

    /** The regulatory chimney height is measured to the finished cap top. */
    fun bodyTopElevation(finishedTopElevationM: Double): Double =
        finishedTopElevationM - CAP_THICKNESS_M
}
