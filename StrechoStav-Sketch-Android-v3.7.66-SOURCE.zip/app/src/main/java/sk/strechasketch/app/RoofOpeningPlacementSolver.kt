package sk.strechasketch.app

import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.sqrt

data class RoofOpeningPlacementResult(
    val center: LocalPoint,
    val upperEdgeCenter: LocalPoint,
    val lowerEdgeCenter: LocalPoint,
    /** Entered opening length measured on the sloping roof surface. */
    val surfaceLengthM: Double,
    /** Horizontal projection of [surfaceLengthM] used by the XY roof graph. */
    val planLengthM: Double,
    val upperEdgeElevationM: Double,
    val slopeDeg: Double
)

/**
 * Places roof windows and access hatches from the required head height above attic floor.
 * The result is a real XY position on z=a*x+b*y+c, not a renderer-only offset.
 */
object RoofOpeningPlacementSolver {
    const val HEAD_HEIGHT_ABOVE_FLOOR_M = 2.10

    fun solve(
        plane: RoofPlane,
        lateralReference: LocalPoint,
        surfaceLengthM: Double,
        floorElevationM: Double,
        headHeightM: Double = HEAD_HEIGHT_ABOVE_FLOOR_M
    ): RoofOpeningPlacementResult? {
        val gradient = hypot(plane.a, plane.b)
        if (!gradient.isFinite() || gradient <= 1e-8) return null
        val length = surfaceLengthM.coerceAtLeast(0.10)
        val normalizer = sqrt(1.0 + gradient * gradient)
        val planLength = length / normalizer
        val verticalLength = length * gradient / normalizer
        val uphillX = plane.a / gradient
        val uphillY = plane.b / gradient
        val targetUpperZ = floorElevationM + headHeightM
        val targetCenterZ = targetUpperZ - verticalLength / 2.0
        val currentCenterZ = plane.zAt(lateralReference.x, lateralReference.y)
        val shiftAlongGradient = (targetCenterZ - currentCenterZ) / gradient
        val center = LocalPoint(
            lateralReference.x + uphillX * shiftAlongGradient,
            lateralReference.y + uphillY * shiftAlongGradient
        )
        val halfPlan = planLength / 2.0
        val upper = LocalPoint(center.x + uphillX * halfPlan, center.y + uphillY * halfPlan)
        val lower = LocalPoint(center.x - uphillX * halfPlan, center.y - uphillY * halfPlan)
        return RoofOpeningPlacementResult(
            center = center,
            upperEdgeCenter = upper,
            lowerEdgeCenter = lower,
            surfaceLengthM = length,
            planLengthM = planLength,
            upperEdgeElevationM = plane.zAt(upper.x, upper.y),
            slopeDeg = Math.toDegrees(atan(gradient))
        )
    }

    /** Projects a drag vector onto the contour direction, therefore preserving roof elevation. */
    fun constrainMoveAlongEave(plane: RoofPlane, delta: LocalPoint): LocalPoint {
        val gradient = hypot(plane.a, plane.b)
        if (gradient <= 1e-8) return LocalPoint(delta.x, delta.y)
        val levelX = plane.b / gradient
        val levelY = -plane.a / gradient
        val amount = delta.x * levelX + delta.y * levelY
        return LocalPoint(levelX * amount, levelY * amount)
    }

    fun planLength(surfaceLengthM: Double, plane: RoofPlane): Double =
        surfaceLengthM.coerceAtLeast(0.10) / sqrt(1.0 + plane.a * plane.a + plane.b * plane.b)
}
