package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.hypot
import kotlin.math.tan

/**
 * Makes a connected gable-ridge network vertically solvable without moving its authored XY.
 *
 * Equal eave elevations and unequal plan runs cannot use one pitch angle and still meet at one
 * ridge height.  A former per-edge pass solved that locally, which meant that the last ridge in
 * an L/H roof could overwrite a face already solved by another ridge.  This pass solves every
 * connected ridge component at once: the main/highest-priority tract supplies one common rise
 * and automatic child faces derive their pitch from that rise.  A user constraint remains the
 * vertical driver when exactly one compatible value was entered.
 */
internal object GableTractSlopeSolver {
    private data class FaceRun(
        val ridgeId: String,
        val faceId: String,
        val runM: Double,
        val downhillX: Double,
        val downhillY: Double,
        val ridgeAxisX: Double,
        val ridgeAxisY: Double,
        val tractPriority: Int
    )

    private const val PARALLEL_TOLERANCE_DEG = 3.0
    private const val EPSILON = 1e-7

    fun apply(
        input: RoofGraph,
        defaultSlopeDeg: Double,
        footprintContext: WallFootprintSolver.Context? = null
    ): RoofGraph {
        val faces = input.faces.toMutableMap()
        val ridges = input.edges.values
            .filter { it.semanticRole == EdgeSemantic.RIDGE && it.adjacentFaceIds.size == 2 }
            .sortedBy { it.id }
        connectedRidgeComponents(ridges).forEach { component ->
            val runs = component.flatMap { ridge ->
                val ridgeStart = input.nodes[ridge.startNodeId] ?: return@flatMap emptyList()
                val ridgeEnd = input.nodes[ridge.endNodeId] ?: return@flatMap emptyList()
                val ridgeDx = ridgeEnd.x - ridgeStart.x
                val ridgeDy = ridgeEnd.y - ridgeStart.y
                val ridgeLength = hypot(ridgeDx, ridgeDy)
                if (ridgeLength <= EPSILON) return@flatMap emptyList()
                val ridgeMidX = (ridgeStart.x + ridgeEnd.x) / 2.0
                val ridgeMidY = (ridgeStart.y + ridgeEnd.y) / 2.0
                val tractPriority = footprintContext?.structuralPartAt(ridgeMidX, ridgeMidY)
                    ?.let { footprintContext.priorityOf(it.type) }
                    ?: Int.MAX_VALUE

                ridge.adjacentFaceIds.sorted().mapNotNull { faceId ->
                    val face = faces[faceId] ?: return@mapNotNull null
                    val candidates = face.orderedEdgeIds.mapNotNull(input.edges::get)
                        .filter { it.boundary && it.semanticRole == EdgeSemantic.EAVE }
                        .filter { edge ->
                            val a = input.nodes[edge.startNodeId] ?: return@filter false
                            val b = input.nodes[edge.endNodeId] ?: return@filter false
                            val dx = b.x - a.x
                            val dy = b.y - a.y
                            val length = hypot(dx, dy)
                            length > EPSILON && abs(dx * ridgeDy - dy * ridgeDx) /
                                (length * ridgeLength) <= kotlin.math.sin(Math.toRadians(PARALLEL_TOLERANCE_DEG))
                        }
                    val sameTractCandidates = candidates.filter { edge ->
                        val a = input.nodes[edge.startNodeId] ?: return@filter false
                        val b = input.nodes[edge.endNodeId] ?: return@filter false
                        footprintContext?.sameStructuralPart(
                            ridgeMidX, ridgeMidY, (a.x + b.x) / 2.0, (a.y + b.y) / 2.0
                        ) != false
                    }
                    val eave = sameTractCandidates.ifEmpty { candidates }
                        .maxByOrNull { edgeLength(input, it) }
                        ?: return@mapNotNull null
                    val eaveStart = input.nodes.getValue(eave.startNodeId)
                    val eaveEnd = input.nodes.getValue(eave.endNodeId)
                    val eaveMidX = (eaveStart.x + eaveEnd.x) / 2.0
                    val eaveMidY = (eaveStart.y + eaveEnd.y) / 2.0
                    val normalX = -ridgeDy / ridgeLength
                    val normalY = ridgeDx / ridgeLength
                    val signedRun = (eaveMidX - ridgeMidX) * normalX + (eaveMidY - ridgeMidY) * normalY
                    val run = abs(signedRun)
                    if (run <= EPSILON) return@mapNotNull null
                    val sign = if (signedRun < 0.0) -1.0 else 1.0
                    FaceRun(
                        ridgeId = ridge.id,
                        faceId = faceId,
                        runM = run,
                        downhillX = normalX * sign,
                        downhillY = normalY * sign,
                        ridgeAxisX = ridgeDx / ridgeLength,
                        ridgeAxisY = ridgeDy / ridgeLength,
                        tractPriority = tractPriority
                    )
                }
            }
            if (runs.size != component.size * 2) return@forEach

            // A single roof face cannot be governed by perpendicular ridges.  Such a graph is
            // missing a face split; silently taking the last ridge would produce the white gaps
            // and twisted planes seen in 3D.  Leave it untouched so validation/plane solving can
            // report the invalid topology instead of inventing a compromise slope.
            val perFace = runs.groupBy { it.faceId }
            if (perFace.values.any { faceRuns ->
                    faceRuns.drop(1).any { !parallel(faceRuns.first(), it) }
                }
            ) return@forEach
            val uniqueRuns = perFace.values.map { faceRuns ->
                faceRuns.maxWith(compareBy<FaceRun> { it.runM }.thenByDescending { it.ridgeId })
            }

            val pairs = uniqueRuns.map { it to faces.getValue(it.faceId) }
            val userConstraints = pairs.filter {
                it.second.slopeConstraint?.source == SlopeConstraintSource.USER
            }
            val userRises = userConstraints.map {
                riseFor(it.first, it.second.slopeConstraint!!)
            }
            if (userRises.size > 1 && userRises.any { abs(it - userRises.first()) > 0.001 }) {
                // Multiple incompatible explicit pitches are user intent.  Never overwrite them;
                // RoofPlaneSolver will expose the hard-constraint conflict.
                return@forEach
            }

            // Explicit pitch wins.  Otherwise the lowest numeric structural priority wins
            // (MAIN=0 before wing/projection/recess), with the longest run as the stable legacy
            // tie-breaker when no semantic tract context exists.
            val anchor = userConstraints.firstOrNull()
                ?: pairs.minWith(
                    compareBy<Pair<FaceRun, GraphFace>> { it.first.tractPriority }
                        .thenByDescending { it.first.runM }
                        .thenBy { it.first.ridgeId }
                        .thenBy { it.first.faceId }
                )
            val anchorAngle = anchor.second.slopeConstraint
                ?.takeIf { it.source == SlopeConstraintSource.USER }
                ?.angleDeg
                ?: defaultSlopeDeg
            val rise = userRises.firstOrNull()
                ?: (tan(Math.toRadians(anchorAngle.coerceIn(0.0, 75.0))) * anchor.first.runM)
            if (!rise.isFinite() || rise < 0.0) return@forEach

            uniqueRuns.forEach { run ->
                val face = faces.getValue(run.faceId)
                val user = face.slopeConstraint?.takeIf {
                    it.source == SlopeConstraintSource.USER
                }
                val angle = user?.angleDeg?.coerceIn(0.0, 75.0)
                    ?: Math.toDegrees(atan(rise / run.runM)).coerceIn(0.0, 75.0)
                faces[run.faceId] = face.copy(
                    plane = null,
                    slopeConstraint = FaceSlopeConstraint(
                        angleDeg = angle,
                        directionX = run.downhillX,
                        directionY = run.downhillY,
                        hard = true,
                        source = if (user != null) SlopeConstraintSource.USER
                            else SlopeConstraintSource.AUTOMATIC_GABLE
                    )
                )
            }
        }
        return input.copy(faces = faces)
    }

    private fun connectedRidgeComponents(ridges: List<GraphEdge>): List<List<GraphEdge>> {
        val byNode = mutableMapOf<String, MutableList<GraphEdge>>()
        ridges.forEach { ridge ->
            byNode.getOrPut(ridge.startNodeId, ::mutableListOf) += ridge
            byNode.getOrPut(ridge.endNodeId, ::mutableListOf) += ridge
        }
        val remaining = ridges.associateBy { it.id }.toMutableMap()
        val result = mutableListOf<List<GraphEdge>>()
        while (remaining.isNotEmpty()) {
            val first = remaining.values.minBy { it.id }
            val queue = ArrayDeque<GraphEdge>()
            val component = mutableListOf<GraphEdge>()
            remaining.remove(first.id)
            queue.add(first)
            while (queue.isNotEmpty()) {
                val current = queue.removeFirst()
                component += current
                sequenceOf(current.startNodeId, current.endNodeId)
                    .flatMap { byNode[it].orEmpty().asSequence() }
                    .sortedBy { it.id }
                    .forEach { neighbour ->
                        remaining.remove(neighbour.id)?.let(queue::add)
                    }
            }
            result += component.sortedBy { it.id }
        }
        return result
    }

    private fun parallel(a: FaceRun, b: FaceRun): Boolean =
        abs(a.ridgeAxisX * b.ridgeAxisY - a.ridgeAxisY * b.ridgeAxisX) <=
            kotlin.math.sin(Math.toRadians(PARALLEL_TOLERANCE_DEG))

    private fun edgeLength(graph: RoofGraph, edge: GraphEdge): Double {
        val a = graph.nodes[edge.startNodeId] ?: return 0.0
        val b = graph.nodes[edge.endNodeId] ?: return 0.0
        return hypot(b.x - a.x, b.y - a.y)
    }

    private fun riseFor(run: FaceRun, constraint: FaceSlopeConstraint): Double =
        tan(Math.toRadians(constraint.angleDeg.coerceIn(0.0, 75.0))) * run.runM
}
