package sk.strechasketch.app

/**
 * Semantic registry for the roof-element marks used in the finished-roof plan.
 *
 * The four symbols are based on table 2 of STN 01 3420. Keeping the mapping out of
 * the Canvas renderer makes the meaning deterministic and independently testable.
 */
internal enum class StnRoofPlanSymbol {
    VENTILATION_DEVICE,
    PIPE_PENETRATION,
    GUTTER_OUTLET,
    ROOF_INLET
}

internal object StnRoofPlanSymbols {
    fun forObject(type: ObjectType, note: String = ""): StnRoofPlanSymbol? = when (type) {
        ObjectType.VENT -> if (note.contains("vetr", ignoreCase = true)) {
            StnRoofPlanSymbol.VENTILATION_DEVICE
        } else {
            StnRoofPlanSymbol.PIPE_PENETRATION
        }
        ObjectType.DRAIN -> StnRoofPlanSymbol.ROOF_INLET
        ObjectType.DOWNSPOUT -> StnRoofPlanSymbol.GUTTER_OUTLET
        else -> null
    }
}
