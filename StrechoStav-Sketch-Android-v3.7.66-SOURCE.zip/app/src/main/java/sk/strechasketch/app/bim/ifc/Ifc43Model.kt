package sk.strechasketch.app.bim.ifc

import java.time.Instant

sealed interface IfcStepValue {
    data object Omitted : IfcStepValue
    data object Derived : IfcStepValue
    data class Text(val value: String) : IfcStepValue
    data class Number(val value: Double) : IfcStepValue
    data class Integer(val value: Int) : IfcStepValue
    data class Enum(val value: String) : IfcStepValue
    data class Boolean(val value: kotlin.Boolean) : IfcStepValue
    data class Reference(val stableKey: String) : IfcStepValue
    data class Values(val values: List<IfcStepValue>) : IfcStepValue
    data class Typed(val type: String, val value: IfcStepValue) : IfcStepValue
}

data class Ifc43Entity(
    val stableKey: String,
    val type: String,
    val attributes: List<IfcStepValue>
)

data class Ifc43Model(
    val fileName: String,
    val timestamp: Instant,
    val applicationVersion: String,
    val entities: List<Ifc43Entity>,
    val rootStableKeys: Set<String>,
    val faceSlabKeys: Map<String, String>
)

data class IfcExportStatistics(
    val roofCount: Int,
    val faceCount: Int,
    val openingCount: Int,
    val objectCount: Int,
    val propertySetCount: Int,
    val entityCount: Int
)

data class IfcExportResult(
    val bytes: ByteArray,
    val warnings: List<String>,
    val statistics: IfcExportStatistics,
    val validation: IfcValidationResult
)

data class IfcValidationResult(
    val valid: Boolean,
    val errors: List<String>,
    val warnings: List<String> = emptyList()
)

internal class Ifc43ModelBuilder {
    private val values = linkedMapOf<String, Ifc43Entity>()
    val rootKeys = linkedSetOf<String>()
    val faceSlabKeys = linkedMapOf<String, String>()

    fun add(stableKey: String, type: String, vararg attributes: IfcStepValue, root: Boolean = false): String {
        require(stableKey !in values) { "Duplicate IFC stable key: $stableKey" }
        values[stableKey] = Ifc43Entity(stableKey, type.uppercase(), attributes.toList())
        if (root) rootKeys += stableKey
        return stableKey
    }

    fun entities(): List<Ifc43Entity> = values.values.toList()
}
