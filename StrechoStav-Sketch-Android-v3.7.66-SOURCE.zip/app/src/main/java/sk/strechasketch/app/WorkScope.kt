package sk.strechasketch.app

enum class QuantitySource {
    ROOF_AREA, FOOTPRINT_AREA, EAVE_LENGTH, RIDGE_LENGTH, VALLEY_LENGTH, HIP_LENGTH,
    ATTIC_LENGTH, CHIMNEY_COUNT, ROOF_WINDOW_COUNT, MANUAL
}

data class WorkItem(
    val code: String,
    val label: String,
    val unit: String,
    val quantitySource: QuantitySource,
    /** Stable construction sequence used by the offer PDF. */
    val budgetOrder: Int,
    /** Human-readable catalogue code shown in the offer; the internal [code] remains stable. */
    val budgetCode: String,
    val budgetTitle: String,
    val specification: String
)

data class SelectedWorkItem(
    val code: String,
    var selected: Boolean = false,
    var unitPrice: Double? = null,
    var manualQuantityOverride: Double? = null
)

data class ResolvedWorkItem(
    val item: WorkItem,
    val automaticQuantity: Double,
    val quantity: Double,
    val unitPrice: Double?,
    val totalPrice: Double?,
    val manualOverride: Boolean
)

object WorkCatalog {
    val items = listOf(
        WorkItem(
            "ROOF_DISMANTLE", "Demontáž existujúcej krytiny", "m²", QuantitySource.ROOF_AREA,
            10, "050206", "Búracie práce a demontáže strešnej krytiny",
            "Demontáž existujúcej strešnej krytiny vrátane triedenia a prípravy na odvoz."
        ),
        WorkItem(
            "ROOF_COVERING", "Montáž strešnej krytiny", "m²", QuantitySource.ROOF_AREA,
            20, "650101", "Pokrývačské práce, zhotovenie strešnej krytiny",
            "Montáž strešnej krytiny na pripravený podklad vrátane bežného príslušenstva."
        ),
        WorkItem(
            "EAVE_FLASHING", "Odkvapové oplechovanie", "m", QuantitySource.EAVE_LENGTH,
            30, "640405", "Klampiarske práce, odkvapové oplechovanie",
            "Oplechovanie a ukončenie strechy v odkvapovej hrane."
        ),
        WorkItem(
            "VALLEY_DETAIL", "Úžľabie", "m", QuantitySource.VALLEY_LENGTH,
            40, "640302", "Klampiarske práce, lemovanie úžľabí",
            "Zhotovenie úžľabia vrátane tesnenia a napojenia priľahlých strešných plôch."
        ),
        WorkItem(
            "RIDGE_DETAIL", "Hrebeňový detail", "m", QuantitySource.RIDGE_LENGTH,
            50, "640303", "Klampiarske práce, lemovanie hrebeňov",
            "Zhotovenie hrebeňového detailu vrátane tesnenia a odvetrania podľa typu krytiny."
        ),
        WorkItem(
            "HIP_DETAIL", "Nárožie", "m", QuantitySource.HIP_LENGTH,
            60, "640303-N", "Klampiarske práce, lemovanie nároží",
            "Zhotovenie nárožia vrátane tesnenia a napojenia priľahlých strešných plôch."
        ),
        WorkItem(
            "ATTIC_FLASHING", "Oplechovanie atiky", "m", QuantitySource.ATTIC_LENGTH,
            70, "640404", "Klampiarske práce, oplechovanie atiky",
            "Súvislé oplechovanie atiky vrátane rohov, spojov a ukončení."
        ),
        WorkItem(
            "CHIMNEY_FLASHING", "Oplechovanie komína", "ks", QuantitySource.CHIMNEY_COUNT,
            80, "640406", "Klampiarske práce, oplechovanie komínov",
            "Vodotesné oplechovanie komína a napojenie na strešný plášť."
        ),
        WorkItem(
            "ROOF_WINDOW", "Montáž strešného okna", "ks", QuantitySource.ROOF_WINDOW_COUNT,
            90, "650102", "Pokrývačské práce, montáž strešného okna",
            "Montáž strešného okna vrátane rámu a vodotesného napojenia na strešný plášť."
        ),
        WorkItem(
            "MANUAL", "Vlastná položka", "MJ", QuantitySource.MANUAL,
            1000, "VLASTNÁ", "Ostatné práce a materiály",
            "Ručne zadaná položka podľa rozsahu projektu."
        )
    ).sortedBy { it.budgetOrder }
}

object WorkScopeEngine {
    fun resolve(project: RoofProject): List<ResolvedWorkItem> {
        val totals = RoofQuantityEngine.calculate(project).totals
        return WorkCatalog.items.sortedBy { it.budgetOrder }.map { item ->
            val selection = project.selectedWorkItems[item.code] ?: SelectedWorkItem(item.code)
            val automatic = when (item.quantitySource) {
                QuantitySource.ROOF_AREA -> totals.roofAreaM2
                QuantitySource.FOOTPRINT_AREA -> totals.footprintAreaM2
                QuantitySource.EAVE_LENGTH -> totals.eaveM
                QuantitySource.RIDGE_LENGTH -> totals.ridgeM
                QuantitySource.VALLEY_LENGTH -> totals.valleyM
                QuantitySource.HIP_LENGTH -> totals.hipM
                QuantitySource.ATTIC_LENGTH -> totals.atticM
                QuantitySource.CHIMNEY_COUNT -> totals.chimneys.toDouble()
                QuantitySource.ROOF_WINDOW_COUNT -> totals.roofWindows.toDouble()
                QuantitySource.MANUAL -> 0.0
            }
            val quantity = selection.manualQuantityOverride ?: automatic
            ResolvedWorkItem(
                item, automatic, quantity, selection.unitPrice,
                selection.unitPrice?.let { it * quantity }, selection.manualQuantityOverride != null
            )
        }
    }
}
