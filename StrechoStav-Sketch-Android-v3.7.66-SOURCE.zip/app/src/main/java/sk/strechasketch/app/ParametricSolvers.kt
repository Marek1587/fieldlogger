package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin

data class ParametricEditResult(
    val applied: Boolean,
    val graph: RoofGraph,
    val issues: List<String> = emptyList()
)

object TopologyValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = RoofGraphValidator.validate(graph)

    fun sameIncidence(before: RoofGraph, after: RoofGraph): Boolean =
        before.nodes.keys == after.nodes.keys &&
            before.edges.keys == after.edges.keys &&
            before.faces.keys == after.faces.keys &&
            before.edges.all { (id, edge) ->
                after.edges[id]?.let { it.startNodeId == edge.startNodeId && it.endNodeId == edge.endNodeId } == true
            } &&
            before.faces.all { (id, face) ->
                after.faces[id]?.let {
                    it.orderedNodeIds == face.orderedNodeIds && it.orderedEdgeIds == face.orderedEdgeIds
                } == true
            }
}

object PlanConstraintSolver {
    fun setEdgeLength(graph: RoofGraph, edgeId: String, targetLengthM: Double): ParametricEditResult {
        val candidate = RoofGraphOperations.setEdgeLength(graph, edgeId, targetLengthM)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutým uzlom."))
        if (!TopologyValidator.sameIncidence(graph, candidate)) {
            return ParametricEditResult(false, graph, listOf("Parametrická zmena by zmenila topológiu."))
        }
        val issues = TopologyValidator.validate(candidate)
        if (issues.any { it.code in setOf("NON_FINITE_NODE", "ZERO_EDGE", "BROKEN_FACE_REFERENCE") }) {
            return ParametricEditResult(false, graph, issues.map { it.message })
        }
        val events = RoofTopologyEventDetector.detect(candidate)
        if (events.any { it.requiresExplicitRetopology }) {
            return ParametricEditResult(false, graph, events.map { it.message })
        }
        val hardConflicts = validateHardPlanConstraints(candidate)
        if (hardConflicts.isNotEmpty()) return ParametricEditResult(false, graph, hardConflicts)
        return ParametricEditResult(true, candidate)
    }

    fun setDimension(graph: RoofGraph, dimensionId: String, targetDistanceM: Double): ParametricEditResult {
        if (targetDistanceM !in 0.05..5000.0) return ParametricEditResult(false, graph, listOf("Rozmer je mimo povoleného rozsahu."))
        val constraint = graph.dimensions[dimensionId]
            ?: return ParametricEditResult(false, graph, listOf("Rozmer neexistuje."))
        val edgeA = graph.edges[constraint.supportAEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Prvá podpora rozmeru neexistuje."))
        val edgeB = graph.edges[constraint.supportBEdgeId]
            ?: return ParametricEditResult(false, graph, listOf("Druhá podpora rozmeru neexistuje."))
        val length = hypot(constraint.directionX, constraint.directionY)
        if (length < 1e-12) return ParametricEditResult(false, graph, listOf("Rozmer nemá platný smer."))
        val dx = constraint.directionX / length; val dy = constraint.directionY / length
        fun midpoint(edge: GraphEdge): Pair<Double, Double> {
            val a = graph.nodes.getValue(edge.startNodeId); val b = graph.nodes.getValue(edge.endNodeId)
            return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
        }
        val a = midpoint(edgeA); val b = midpoint(edgeB)
        val current = (b.first - a.first) * dx + (b.second - a.second) * dy
        val movingB = constraint.fixedSupportEdgeId != edgeB.id
        val movingEdge = if (movingB) edgeB else edgeA
        val delta = if (movingB) targetDistanceM - current else current - targetDistanceM
        val movingNodes = constraint.movingNodeIds.ifEmpty { setOf(movingEdge.startNodeId, movingEdge.endNodeId) }
        val positions = movingNodes.associateWith { id ->
            val node = graph.nodes[id] ?: return ParametricEditResult(false, graph, listOf("Pohyblivý uzol rozmeru neexistuje."))
            node.x + dx * delta to node.y + dy * delta
        }
        val moved = RoofGraphOperations.moveNodes(graph, positions)
            ?: return ParametricEditResult(false, graph, listOf("Rozmer je v konflikte so zamknutými uzlami."))
        fun movedMidpoint(edge: GraphEdge): Pair<Double, Double> {
            val first = moved.nodes.getValue(edge.startNodeId)
            val second = moved.nodes.getValue(edge.endNodeId)
            return (first.x + second.x) / 2.0 to (first.y + second.y) / 2.0
        }
        val movedA = movedMidpoint(moved.edges.getValue(constraint.supportAEdgeId))
        val movedB = movedMidpoint(moved.edges.getValue(constraint.supportBEdgeId))
        val appliedDistanceM = ((movedB.first - movedA.first) * dx + (movedB.second - movedA.second) * dy)
        val updated = moved.copy(dimensions = moved.dimensions + (
            dimensionId to constraint.copy(valueMm = appliedDistanceM * 1000.0)
        ))
        if (!TopologyValidator.sameIncidence(graph, updated)) return ParametricEditResult(false, graph, listOf("Zmena vyžaduje explicitnú zmenu topológie."))
        val conflicts = validateHardPlanConstraints(updated)
        if (conflicts.isNotEmpty()) return ParametricEditResult(false, graph, conflicts)
        return ParametricEditResult(true, updated)
    }

    private fun validateHardPlanConstraints(graph: RoofGraph): List<String> = buildList {
        graph.edgeLengthConstraints.values.filter { it.hard }.forEach { constraint ->
            val edge = graph.edges[constraint.edgeId] ?: return@forEach
            val a = graph.nodes[edge.startNodeId] ?: return@forEach
            val b = graph.nodes[edge.endNodeId] ?: return@forEach
            if (abs(hypot(b.x - a.x, b.y - a.y) - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer hrany ${edge.id} nie je splnený s presnosťou 0,5 mm.")
            }
        }
        graph.dimensions.values.filter { it.hard }.forEach { constraint ->
            val edgeA = graph.edges[constraint.supportAEdgeId] ?: return@forEach
            val edgeB = graph.edges[constraint.supportBEdgeId] ?: return@forEach
            val directionLength = hypot(constraint.directionX, constraint.directionY)
            if (directionLength < 1e-12) return@forEach
            fun midpoint(edge: GraphEdge): Pair<Double, Double> {
                val a = graph.nodes[edge.startNodeId] ?: return 0.0 to 0.0
                val b = graph.nodes[edge.endNodeId] ?: return 0.0 to 0.0
                return (a.x + b.x) / 2.0 to (a.y + b.y) / 2.0
            }
            val a = midpoint(edgeA); val b = midpoint(edgeB)
            val measured = ((b.first - a.first) * constraint.directionX + (b.second - a.second) * constraint.directionY) / directionLength
            if (abs(measured - constraint.valueMm / 1000.0) > 0.0005) {
                add("Pevný rozmer ${constraint.id} medzi podporami nie je splnený s presnosťou 0,5 mm.")
            }
        }
    }
}

object ParametricEditSolver {
    fun setBoundaryDimension(
        graph: RoofGraph,
        linkedEdgeIds: List<String>,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double,
        footprintContext: WallFootprintSolver.Context? = null
    ): ParametricEditResult {
        if (targetLengthM !in 0.05..5000.0) {
            return ParametricEditResult(false, graph, listOf("Rozmer musí byť v rozsahu 0,05 až 5 000 m."))
        }
        val selectedEdgeId = linkedEdgeIds.firstOrNull()
            ?: return ParametricEditResult(false, graph, listOf("Kóta nemá priradenú hranu."))
        val boundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())
            ?: return ParametricEditResult(false, graph, listOf("Obvod netvorí uzavretý cyklus."))
        val orderedEdges = boundary.second
        val selectedIndex = orderedEdges.indexOfFirst { it.id == selectedEdgeId }
        if (selectedIndex < 0) {
            return ParametricEditResult(false, graph, listOf("Vybraná hrana nie je súčasťou obvodu."))
        }
        val orderedNodeIds = boundary.first
        val orderedNodes = orderedNodeIds.map { id ->
            graph.nodes[id] ?: return ParametricEditResult(false, graph, listOf("Obvod odkazuje na chýbajúci uzol."))
        }
        val start = orderedNodes[selectedIndex]
        val end = orderedNodes[(selectedIndex + 1) % orderedNodes.size]
        val currentLength = hypot(end.x - start.x, end.y - start.y)
        if (currentLength < 1e-9) {
            return ParametricEditResult(false, graph, listOf("Vybraná hrana má nulovú dĺžku."))
        }
        if (abs(targetLengthM - currentLength) <= 0.0005) {
            return ParametricEditResult(true, graph)
        }
        val ux = (end.x - start.x) / currentLength
        val uy = (end.y - start.y) / currentLength
        val selectedMidX = (start.x + end.x) / 2.0
        val selectedMidY = (start.y + end.y) / 2.0
        val selectedPart = footprintContext?.structuralPartAt(selectedMidX, selectedMidY)
        val selectedPriority = selectedPart?.let { footprintContext.priorityOf(it.type) }

        fun ownerOfEdge(index: Int): WallFootprintSolver.Context.LocalPart? {
            val first = orderedNodes[index]
            val second = orderedNodes[(index + 1) % orderedNodes.size]
            return footprintContext?.structuralPartAt(
                (first.x + second.x) / 2.0,
                (first.y + second.y) / 2.0
            )
        }

        fun edgeLength(index: Int): Double {
            val a = orderedNodes[index]
            val b = orderedNodes[(index + 1) % orderedNodes.size]
            return hypot(b.x - a.x, b.y - a.y)
        }
        fun isParallel(index: Int): Boolean {
            val a = orderedNodes[index]
            val b = orderedNodes[(index + 1) % orderedNodes.size]
            val length = edgeLength(index)
            if (length < 1e-9) return false
            val cross = abs(ux * (b.y - a.y) / length - uy * (b.x - a.x) / length)
            if (cross > sin(Math.toRadians(5.0))) return false
            val midX = (a.x + b.x) / 2.0
            val midY = (a.y + b.y) / 2.0
            val normalDistance = abs((midX - selectedMidX) * -uy + (midY - selectedMidY) * ux)
            return normalDistance > 0.05
        }

        // The paired wall is selected geometrically, not by list position. In an L/T/H plan
        // several parallel segments can exist; the longest real opposite wall owns the change.
        val parallelCandidates = orderedEdges.indices.filter { it != selectedIndex && isParallel(it) }
        val samePartCandidates = selectedPart?.let { selected ->
            parallelCandidates.filter { ownerOfEdge(it)?.id == selected.id }
        }.orEmpty()
        val oppositeIndex = (samePartCandidates.ifEmpty { parallelCandidates })
            .maxByOrNull(::edgeLength)
            ?: return ParametricEditResult(
                false, graph,
                listOf("Nenašla sa rovnobežná protiľahlá obvodová stena.")
            )

        val count = orderedNodes.size
        val rotatedNodes = List(count) { offset -> orderedNodes[(selectedIndex + offset) % count] }
        val rotatedOpposite = (oppositeIndex - selectedIndex + count) % count
        val delta = targetLengthM - currentLength

        fun protectByHierarchy(node: GraphNode, target: Pair<Double, Double>): Pair<Double, Double> {
            val context = footprintContext ?: return target
            val selected = selectedPart ?: return target
            val selectedRank = selectedPriority ?: return target
            val higherOwner = context.partsAt(node.x, node.y)
                .firstOrNull { context.priorityOf(it.type) < selectedRank }
                ?: return target
            val moveX = target.first - node.x
            val moveY = target.second - node.y
            var nearestDistance = Double.POSITIVE_INFINITY
            var tangentX = 0.0
            var tangentY = 0.0
            higherOwner.polygon.indices.forEach { index ->
                val first = higherOwner.polygon[index]
                val second = higherOwner.polygon[(index + 1) % higherOwner.polygon.size]
                val distance = Geometry.distanceToSegment(LocalPoint(node.x, node.y), first, second)
                val length = hypot(second.x - first.x, second.y - first.y)
                if (distance < nearestDistance && length > 1e-9) {
                    nearestDistance = distance
                    tangentX = (second.x - first.x) / length
                    tangentY = (second.y - first.y) / length
                }
            }
            // A shared split point may slide along the immutable host support line.  It may not
            // move that line, and all nodes inside the higher-priority tract remain fixed.
            if (nearestDistance <= 0.03) {
                val along = moveX * tangentX + moveY * tangentY
                return node.x + tangentX * along to node.y + tangentY * along
            }
            return node.x to node.y
        }

        fun candidate(moveForwardArc: Boolean): RoofGraph? {
            val movedBoundaryIds: Set<String>
            val dx: Double
            val dy: Double
            val selectedMoving: GraphNode
            val selectedFixed: GraphNode
            val oppositeMoving: GraphNode
            val oppositeFixed: GraphNode
            if (moveForwardArc) {
                movedBoundaryIds = (1..rotatedOpposite).map { rotatedNodes[it].id }.toSet()
                dx = ux * delta
                dy = uy * delta
                selectedMoving = rotatedNodes[1]
                selectedFixed = rotatedNodes[0]
                oppositeMoving = rotatedNodes[rotatedOpposite]
                oppositeFixed = rotatedNodes[(rotatedOpposite + 1) % count]
            } else {
                movedBoundaryIds = (listOf(0) + (rotatedOpposite + 1 until count).toList())
                    .map { rotatedNodes[it].id }.toSet()
                dx = -ux * delta
                dy = -uy * delta
                selectedMoving = rotatedNodes[0]
                selectedFixed = rotatedNodes[1]
                oppositeMoving = rotatedNodes[(rotatedOpposite + 1) % count]
                oppositeFixed = rotatedNodes[rotatedOpposite]
            }
            if (movedBoundaryIds.any { id ->
                    graph.nodes[id]?.let { (it.lockX && abs(dx) > 1e-12) || (it.lockY && abs(dy) > 1e-12) } == true
                }) return null

            val boundaryPositions = orderedNodes.associate { node ->
                node.id to if (node.id in movedBoundaryIds) {
                    node.x + dx to node.y + dy
                } else {
                    node.x to node.y
                }
            }.toMutableMap()
            val selectedSign = if (
                (selectedMoving.x - selectedFixed.x) * ux + (selectedMoving.y - selectedFixed.y) * uy >= 0.0
            ) 1.0 else -1.0
            boundaryPositions[selectedMoving.id] =
                selectedFixed.x + ux * selectedSign * targetLengthM to
                selectedFixed.y + uy * selectedSign * targetLengthM
            val oldOppositeLength = hypot(
                oppositeMoving.x - oppositeFixed.x,
                oppositeMoving.y - oppositeFixed.y
            )
            val desiredOppositeLength = if (orderedEdges[oppositeIndex].id in linkedEdgeIds) {
                targetLengthM
            } else {
                oldOppositeLength + delta
            }
            if (desiredOppositeLength < 0.05) return null
            val oppositeSign = if (
                (oppositeMoving.x - oppositeFixed.x) * ux + (oppositeMoving.y - oppositeFixed.y) * uy >= 0.0
            ) 1.0 else -1.0
            boundaryPositions[oppositeMoving.id] =
                oppositeFixed.x + ux * oppositeSign * desiredOppositeLength to
                oppositeFixed.y + uy * oppositeSign * desiredOppositeLength
            val positions = graph.nodes.mapValues { (id, node) ->
                val rawTarget = boundaryPositions[id] ?: run {
                    // Smoothly deform internal ridges/valleys with the footprint. Boundary
                    // vertices remain exact, while internal topology keeps its incidence.
                    var totalWeight = 0.0
                    var movedWeight = 0.0
                    orderedNodes.forEach { support ->
                        val distance2 = (node.x - support.x).pow(2) + (node.y - support.y).pow(2)
                        val weight = 1.0 / distance2.coerceAtLeast(0.01)
                        totalWeight += weight
                        if (support.id in movedBoundaryIds) movedWeight += weight
                    }
                    val factor = if (totalWeight > 0.0) movedWeight / totalWeight else 0.0
                    val moveX = if (node.lockX) 0.0 else dx * factor
                    val moveY = if (node.lockY) 0.0 else dy * factor
                    node.x + moveX to node.y + moveY
                }
                protectByHierarchy(node, rawTarget)
            }
            val moved = RoofGraphOperations.moveNodes(graph, positions) ?: return null
            if (!TopologyValidator.sameIncidence(graph, moved)) return null
            val movedBoundary = RoofTopologyMigration.orderedBoundary(moved.toTopology()) ?: return null
            val points = movedBoundary.first.mapNotNull(moved.nodes::get)
            if (points.size != count || !isSimpleBoundary(points)) return null
            if (movedBoundary.second.any { changedEdge ->
                    val a = moved.nodes[changedEdge.startNodeId] ?: return@any true
                    val b = moved.nodes[changedEdge.endNodeId] ?: return@any true
                    hypot(b.x - a.x, b.y - a.y) < 0.05
                }) return null
            val selectedAfter = moved.edges[selectedEdgeId] ?: return null
            val selectedAfterStart = moved.nodes[selectedAfter.startNodeId] ?: return null
            val selectedAfterEnd = moved.nodes[selectedAfter.endNodeId] ?: return null
            if (abs(hypot(
                    selectedAfterEnd.x - selectedAfterStart.x,
                    selectedAfterEnd.y - selectedAfterStart.y
                ) - targetLengthM) > 0.001
            ) return null
            return moved
        }

        val moved = candidate(moveForwardArc = true) ?: candidate(moveForwardArc = false)
            ?: return ParametricEditResult(
                false, graph,
                listOf("Rozmer by porušil uzavretý obrys alebo zamknutý uzol.")
            )
        // The boundary edit is followed by a hard plan-view roof pass. HIP and
        // VALLEY support lines own the common junctions at exactly 45 degrees
        // to their EAVEs; connected RIDGEs are allowed to move and change length.
        val regularized = ParametricRoofPlanRegularizer.regularize(moved)
        val protectedRegularizedPositions = regularized.graph.nodes.mapValues { (id, changed) ->
            val original = graph.nodes[id] ?: return@mapValues changed.x to changed.y
            protectByHierarchy(original, changed.x to changed.y)
        }
        val planCorrected = RoofGraphOperations.moveNodes(
            regularized.graph,
            protectedRegularizedPositions
        ) ?: moved
        // Legacy callers without semantic parts retain the established paired-wall behaviour.
        // With tract semantics available, only a wall in the same part may receive the paired
        // hard constraint; a lower-priority attachment must never constrain its host tract.
        val oppositeSharesOwner = footprintContext == null ||
            (selectedPart != null && ownerOfEdge(oppositeIndex)?.id == selectedPart.id)
        val constrainedIds = if (oppositeSharesOwner) {
            setOf(selectedEdgeId, orderedEdges[oppositeIndex].id)
        } else setOf(selectedEdgeId)
        val withoutOld = planCorrected.edgeLengthConstraints.filterValues { it.edgeId !in constrainedIds }.toMutableMap()
        constrainedIds.forEach { id ->
            val changedEdge = planCorrected.edges[id] ?: return@forEach
            withoutOld["edge-length-$id"] = EdgeLengthConstraint(
                id = "edge-length-$id",
                edgeId = id,
                valueMm = run {
                    val a = planCorrected.nodes.getValue(changedEdge.startNodeId)
                    val b = planCorrected.nodes.getValue(changedEdge.endNodeId)
                    hypot(b.x - a.x, b.y - a.y) * 1000.0
                },
                fixedNodeId = changedEdge.startNodeId
            )
        }
        val constrained = planCorrected.copy(edgeLengthConstraints = withoutOld)
        // A plan edit changes the perpendicular runs of a gable. Recompute its two independent
        // pitches before solving Z; stale equal angles would otherwise pull the ridge off the
        // common height or force an approximation.
        val pitchAdjusted = GableTractSlopeSolver.apply(constrained, defaultSlopeDeg)
        val roof = RoofPlaneSolver.solveForRendering(pitchAdjusted, wallHeightM, defaultSlopeDeg)
        // A valid 2D parametric edit must not be discarded only because an unfinished roof has
        // not yet received enough ridge/hip constraints for Z. Preserve the orthogonal plan and
        // let the dedicated 3D preparation complete heights once topology is available.
        if (roof.hasBlockingIssues) return ParametricEditResult(
            true, pitchAdjusted, regularized.issues + roof.issues.map { it.message }
        )
        return ParametricEditResult(true, roof.graph, regularized.issues + roof.issues.map { it.message })
    }

    private fun isSimpleBoundary(points: List<GraphNode>): Boolean {
        if (points.size < 3) return false
        var area2 = 0.0
        points.indices.forEach { index ->
            val next = (index + 1) % points.size
            area2 += points[index].x * points[next].y - points[next].x * points[index].y
        }
        if (abs(area2) < 1e-6) return false
        fun orientation(a: GraphNode, b: GraphNode, c: GraphNode): Double =
            (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
        fun intersects(a: GraphNode, b: GraphNode, c: GraphNode, d: GraphNode): Boolean {
            val abC = orientation(a, b, c)
            val abD = orientation(a, b, d)
            val cdA = orientation(c, d, a)
            val cdB = orientation(c, d, b)
            return abC * abD < -1e-9 && cdA * cdB < -1e-9
        }
        for (first in points.indices) {
            val firstNext = (first + 1) % points.size
            for (second in first + 1 until points.size) {
                val secondNext = (second + 1) % points.size
                if (first == second || firstNext == second || secondNext == first) continue
                if (intersects(points[first], points[firstNext], points[second], points[secondNext])) return false
            }
        }
        return true
    }

    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        wallHeightM: Double,
        defaultSlopeDeg: Double
    ): ParametricEditResult {
        val plan = PlanConstraintSolver.setEdgeLength(graph, edgeId, targetLengthM)
        if (!plan.applied) return plan
        val roof = RoofPlaneSolver.solveForRendering(plan.graph, wallHeightM, defaultSlopeDeg)
        if (roof.hasBlockingIssues) {
            val hardGeometryConflicts = roof.issues.filter { it.blocking && it.code != "AUTO_TOPOLOGY_REQUIRED" }
            if (hardGeometryConflicts.isNotEmpty()) {
                return ParametricEditResult(false, graph, hardGeometryConflicts.map { it.message })
            }
            return ParametricEditResult(true, plan.graph, roof.issues.map { it.message })
        }
        if (!TopologyValidator.sameIncidence(graph, roof.graph)) {
            return ParametricEditResult(false, graph, listOf("RoofPlaneSolver zmenil topologickú incidenciu."))
        }
        return ParametricEditResult(true, roof.graph, roof.issues.map { it.message })
    }
}
