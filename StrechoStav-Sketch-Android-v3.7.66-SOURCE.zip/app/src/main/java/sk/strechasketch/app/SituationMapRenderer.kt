package sk.strechasketch.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import java.io.File
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

data class SituationMapRenderResult(
    val bitmap: Bitmap,
    val loadedTiles: Int,
    val requestedTiles: Int,
    val sourceZoom: Int
)

/** Cache-only renderer for the first PDF page; it never blocks export on a network request. */
object SituationMapRenderer {
    private const val TILE_WORLD_SIZE = 256.0
    private const val OUTPUT_WIDTH = 1400
    private const val OUTPUT_HEIGHT = 1840

    fun render(context: Context, project: RoofProject): SituationMapRenderResult {
        val viewport = SituationMapLayout.createForPdf(
            polygon = project.polygon,
            outputWidth = OUTPUT_WIDTH,
            outputHeight = OUTPUT_HEIGHT
        )
        val bitmap = Bitmap.createBitmap(OUTPUT_WIDTH, OUTPUT_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.rgb(232, 232, 226))
        val cacheRoot = File(
            context.filesDir,
            "project-map-cache/${safeProjectId(project.id)}/tiles-v3/zbgis-ortho"
        )
        val tilePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
            isDither = true
        }
        val firstX = floor(viewport.worldLeft / TILE_WORLD_SIZE).toInt()
        val lastX = floor(
            (viewport.worldLeft + OUTPUT_WIDTH / viewport.scale) / TILE_WORLD_SIZE
        ).toInt()
        val firstY = floor(viewport.worldTop / TILE_WORLD_SIZE).toInt()
        val lastY = floor(
            (viewport.worldTop + OUTPUT_HEIGHT / viewport.scale) / TILE_WORLD_SIZE
        ).toInt()
        val tileCount = 1 shl viewport.sourceZoom
        var loaded = 0
        var requested = 0
        for (rawX in firstX..lastX) {
            val x = floorMod(rawX, tileCount)
            for (y in max(0, firstY)..min(tileCount - 1, lastY)) {
                requested += 1
                val file = File(cacheRoot, "${viewport.sourceZoom}/$x/$y.tile")
                val tile = if (file.isFile) BitmapFactory.decodeFile(file.absolutePath) else null
                if (tile != null) {
                    val left = viewport.screenX(rawX * TILE_WORLD_SIZE).toFloat()
                    val top = viewport.screenY(y * TILE_WORLD_SIZE).toFloat()
                    val right = viewport.screenX((rawX + 1) * TILE_WORLD_SIZE).toFloat() + 1f
                    val bottom = viewport.screenY((y + 1) * TILE_WORLD_SIZE).toFloat() + 1f
                    canvas.drawBitmap(tile, null, RectF(left, top, right, bottom), tilePaint)
                    tile.recycle()
                    loaded += 1
                }
            }
        }
        drawHatchedOutline(canvas, viewport.polygonPixels)
        return SituationMapRenderResult(bitmap, loaded, requested, viewport.sourceZoom)
    }

    private fun drawHatchedOutline(canvas: Canvas, points: List<LocalPoint>) {
        if (points.size < 3) return
        val path = Path().apply {
            moveTo(points.first().x.toFloat(), points.first().y.toFloat())
            points.drop(1).forEach { lineTo(it.x.toFloat(), it.y.toFloat()) }
            close()
        }
        canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = Color.argb(54, 20, 126, 67)
        })
        canvas.save()
        canvas.clipPath(path)
        val minX = points.minOf { it.x }.toFloat()
        val maxX = points.maxOf { it.x }.toFloat()
        val minY = points.minOf { it.y }.toFloat()
        val maxY = points.maxOf { it.y }.toFloat()
        val diagonal = ceil(maxX - minX + maxY - minY).toInt()
        val hatch = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(180, 15, 106, 55)
            strokeWidth = 3f
        }
        var offset = -diagonal
        while (offset <= diagonal * 2) {
            canvas.drawLine(
                minX + offset,
                maxY,
                minX + offset + diagonal,
                minY,
                hatch
            )
            offset += 26
        }
        canvas.restore()
        canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.argb(220, 255, 255, 255)
            strokeWidth = 9f
            strokeJoin = Paint.Join.ROUND
        })
        canvas.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(13, 105, 53)
            strokeWidth = 5f
            strokeJoin = Paint.Join.ROUND
        })
    }

    private fun safeProjectId(value: String): String =
        value.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun floorMod(value: Int, modulus: Int): Int = ((value % modulus) + modulus) % modulus
}
