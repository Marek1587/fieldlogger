package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.hypot

data class PlanAtticBand(
    val edgeId: String,
    val outerStart: LocalPoint,
    val outerEnd: LocalPoint,
    val innerStart: LocalPoint,
    val innerEnd: LocalPoint,
    val joinedAtStart: Boolean,
    val joinedAtEnd: Boolean
)

data class PlanEdgeHeight(
    val edgeId: String,
    val semanticRole: EdgeSemantic,
    val point: LocalPoint,
    val elevationM: Double
)

data class PlanObjectHeight(
    val objectId: String,
    val point: LocalPoint,
    val elevationM: Double
)

data class PlanFaceSlope(
    val faceId: String,
    val point: LocalPoint,
    val downhillX: Double,
    val downhillY: Double,
    val slopeDeg: Double
)

/** Pure geometry used by the STN plan, independent from Android Canvas and PDF. */
object RoofPlanAnnotationSolver {
    fun atticBands(graph: RoofGraph, widthM: Double): List<PlanAtticBand> {
        val width = widthM.coerceIn(0.06, 1.5)
        val atticEdges = graph.edges.values
            .filter { it.boundary && it.semanticRole == EdgeSemantic.ATTIC }
            .sortedBy { it.id }

        data class Offset(
            val edge: GraphEdge,
            val a: GraphNode,
            val b: GraphNode,
            val inwardX: Double,
            val inwardY: Double
        )

        fun offset(edge: GraphEdge): Offset? {
            val a = graph.nodes[edge.startNodeId] ?: return null
            val b = graph.nodes[edge.endNodeId] ?: return null
            val face = edge.adjacentFaceIds.sorted().firstNotNullOfOrNull(graph.faces::get)
                ?: graph.faces.values.firstOrNull { edge.id in it.orderedEdgeIds }
            val faceCentroid = face?.let { faceCentroid(graph, it) }
                ?: LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            var inwardX = -dy / length
            var inwardY = dx / length
            val midX = (a.x + b.x) / 2.0
            val midY = (a.y + b.y) / 2.0
            if (inwardX * (faceCentroid.x - midX) + inwardY * (faceCentroid.y - midY) < 0.0) {
                inwardX = -inwardX
                inwardY = -inwardY
            }
            return Offset(edge, a, b, inwardX, inwardY)
        }

        val offsets = atticEdges.mapNotNull(::offset).associateBy { it.edge.id }
        val edgesAtNode = atticEdges.flatMap { edge ->
            listOf(edge.startNodeId to edge.id, edge.endNodeId to edge.id)
        }.groupBy({ it.first }, { it.second })

        fun intersection(first: Offset, second: Offset): LocalPoint? {
            val ax = first.a.x + first.inwardX * width
            val ay = first.a.y + first.inwardY * width
            val adx = first.b.x - first.a.x
            val ady = first.b.y - first.a.y
            val bx = second.a.x + second.inwardX * width
            val by = second.a.y + second.inwardY * width
            val bdx = second.b.x - second.a.x
            val bdy = second.b.y - second.a.y
            val denominator = adx * bdy - ady * bdx
            if (abs(denominator) <= 1e-9) return null
            val t = ((bx - ax) * bdy - (by - ay) * bdx) / denominator
            return LocalPoint(ax + adx * t, ay + ady * t)
        }

        fun joinedPoint(current: Offset, node: GraphNode): Pair<LocalPoint, Boolean> {
            val raw = LocalPoint(node.x + current.inwardX * width, node.y + current.inwardY * width)
            val neighbour = edgesAtNode[node.id].orEmpty().sorted()
                .firstOrNull { it != current.edge.id }
                ?.let(offsets::get)
                ?: return raw to false
            val candidate = intersection(current, neighbour) ?: return raw to true
            return if (hypot(candidate.x - node.x, candidate.y - node.y) <= width * 6.0) {
                candidate to true
            } else raw to true
        }

        return atticEdges.mapNotNull { edge ->
            val current = offsets[edge.id] ?: return@mapNotNull null
            val (innerStart, joinedStart) = joinedPoint(current, current.a)
            val (innerEnd, joinedEnd) = joinedPoint(current, current.b)
            PlanAtticBand(
                edgeId = edge.id,
                outerStart = LocalPoint(current.a.x, current.a.y),
                outerEnd = LocalPoint(current.b.x, current.b.y),
                innerStart = innerStart,
                innerEnd = innerEnd,
                joinedAtStart = joinedStart,
                joinedAtEnd = joinedEnd
            )
        }
    }

    /**
     * STN elevation marks belong to technically meaningful roof edges, never to a face centroid.
     * ATTIC marks use the horizontal finished crown used by the 3D parapet builder.
     */
    fun edgeHeights(graph: RoofGraph, atticHeightM: Double): List<PlanEdgeHeight> {
        val surface = SolvedRoofSurfaceGeometry.from(graph)
        val atticTop = surface?.atticCrownZ(atticHeightM) ?: graph.edges.values
            .asSequence()
            .filter { it.semanticRole == EdgeSemantic.ATTIC }
            .mapNotNull { SolvedRoofSurfaceGeometry.solvedEdgeSegment(graph, it) }
            .flatMap { (a, b) -> sequenceOf(a.z, b.z) }
            .maxOrNull()
            ?.plus(atticHeightM.coerceIn(0.1, 3.0))

        return graph.edges.values
            .filter { it.semanticRole in setOf(EdgeSemantic.RIDGE, EdgeSemantic.EAVE, EdgeSemantic.ATTIC) }
            .sortedBy { it.id }
            .mapNotNull { edge ->
                val (a, b) = surface?.section(edge.id)?.let { it.topA to it.topB }
                    ?: SolvedRoofSurfaceGeometry.solvedEdgeSegment(graph, edge)
                    ?: run {
                        val start = graph.nodes[edge.startNodeId] ?: return@mapNotNull null
                        val end = graph.nodes[edge.endNodeId] ?: return@mapNotNull null
                        start to end
                    }
                val point = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
                val elevation = if (edge.semanticRole == EdgeSemantic.ATTIC) {
                    atticTop ?: return@mapNotNull null
                } else {
                    (a.z + b.z) / 2.0
                }
                if (!point.x.isFinite() || !point.y.isFinite() || !elevation.isFinite()) return@mapNotNull null
                PlanEdgeHeight(edge.id, edge.semanticRole, point, elevation)
            }
    }

    /** Finished chimney top elevations for STN plan markers. */
    fun chimneyHeights(project: RoofProject, graph: RoofGraph): List<PlanObjectHeight> = project.objects
        .asSequence()
        .filter { it.type == ObjectType.CHIMNEY }
        .sortedBy { it.id }
        .mapNotNull { item ->
            val point = Geometry.toLocal(item.center, graph.origin)
            val face = item.attachedFaceId?.let(graph.faces::get) ?: graph.faces.values
                .sortedBy { it.id }
                .firstOrNull { candidate ->
                    val outer = candidate.orderedNodeIds.mapNotNull(graph.nodes::get)
                        .map { LocalPoint(it.x, it.y) }
                    val insideOuter = outer.size >= 3 && Geometry.pointInPolygon(point, outer)
                    val insideHole = candidate.holeNodeIdLoops.any { loop ->
                        val hole = loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
                        hole.size >= 3 && Geometry.pointInPolygon(point, hole)
                    }
                    insideOuter && !insideHole
                }
            val plane = face?.plane ?: return@mapNotNull null
            val shellHeight = (item.value.takeIf { it > 0.0 } ?: 0.8).coerceIn(0.2, 20.0)
            val elevation = RoofObjectPlacement.topElevation(
                ObjectType.CHIMNEY, plane, point, point, shellHeight
            )
            if (!elevation.isFinite()) return@mapNotNull null
            PlanObjectHeight(item.id, point, elevation)
        }
        .toList()

    fun faceSlopes(graph: RoofGraph): List<PlanFaceSlope> = graph.faces.values
        .sortedBy { it.id }
        .mapNotNull { face ->
            val plane = face.plane ?: return@mapNotNull null
            val point = faceCentroid(graph, face)
            val gradient = hypot(plane.a, plane.b)
            val constrained = face.slopeConstraint
            val rawX = if (gradient > 1e-9) -plane.a else constrained?.directionX ?: 0.0
            val rawY = if (gradient > 1e-9) -plane.b else constrained?.directionY ?: -1.0
            val directionLength = hypot(rawX, rawY).coerceAtLeast(1e-9)
            val slopeDeg = Math.toDegrees(atan(gradient))
            if (!point.x.isFinite() || !point.y.isFinite() || !slopeDeg.isFinite()) return@mapNotNull null
            PlanFaceSlope(
                faceId = face.id,
                point = point,
                downhillX = rawX / directionLength,
                downhillY = rawY / directionLength,
                slopeDeg = slopeDeg
            )
        }

    private data class Ring(val area: Double, val centroid: LocalPoint)

    private fun faceCentroid(graph: RoofGraph, face: GraphFace): LocalPoint {
        val outer = ring(graph, face.orderedNodeIds)
        val holes = face.holeNodeIdLoops.mapNotNull { ring(graph, it) }
        if (outer == null) {
            val nodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            return LocalPoint(
                nodes.map { it.x }.average().takeIf(Double::isFinite) ?: 0.0,
                nodes.map { it.y }.average().takeIf(Double::isFinite) ?: 0.0
            )
        }
        val netArea = outer.area - holes.sumOf { it.area }
        if (netArea <= 1e-9) return outer.centroid
        return LocalPoint(
            (outer.centroid.x * outer.area - holes.sumOf { it.centroid.x * it.area }) / netArea,
            (outer.centroid.y * outer.area - holes.sumOf { it.centroid.y * it.area }) / netArea
        )
    }

    private fun ring(graph: RoofGraph, ids: List<String>): Ring? {
        val points = ids.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        if (points.size < 3) return null
        var crossSum = 0.0
        var xSum = 0.0
        var ySum = 0.0
        points.indices.forEach { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val cross = a.x * b.y - b.x * a.y
            crossSum += cross
            xSum += (a.x + b.x) * cross
            ySum += (a.y + b.y) * cross
        }
        if (abs(crossSum) <= 1e-9) return null
        return Ring(
            area = abs(crossSum) / 2.0,
            centroid = LocalPoint(xSum / (3.0 * crossSum), ySum / (3.0 * crossSum))
        )
    }
}
