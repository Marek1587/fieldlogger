package sk.strechasketch.app.bim.ifc

import sk.strechasketch.app.BuildConfig
import sk.strechasketch.app.ObjectType
import sk.strechasketch.app.RoofProject
import sk.strechasketch.app.bim.RoofBimSnapshotFactory
import sk.strechasketch.app.bim.StrechoStavBimBuilder
import java.time.Clock

object IfcExporter {
    fun export(project: RoofProject, clock: Clock = Clock.systemUTC()): IfcExportResult {
        val snapshot = RoofBimSnapshotFactory.create(project)
        val bim = StrechoStavBimBuilder.build(snapshot)
        val safeName = project.name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-').ifBlank { "strecha" }
        val model = Ifc43Mapper.map(bim, BuildConfig.VERSION_NAME, clock.instant(), "$safeName.ifc")
        val bytes = IfcStepWriter.write(model)
        val validation = IfcSanityValidator.validate(bytes, bim.faces.map { it.id }.toSet())
        require(validation.valid) { "IFC sanity validation zlyhala: ${validation.errors.joinToString("; ")}" }
        val typeCounts = model.entities.groupingBy { it.type }.eachCount()
        return IfcExportResult(
            bytes,
            bim.warnings + buildList {
                val fallback = bim.objects.filter { it.source.type !in setOf(ObjectType.CHIMNEY, ObjectType.ROOF_WINDOW) }
                if (fallback.isNotEmpty()) add("${fallback.size} strešných objektov používa IfcBuildingElementProxy fallback.")
            },
            IfcExportStatistics(
                roofCount = typeCounts["IFCROOF"] ?: 0,
                faceCount = typeCounts["IFCSLAB"] ?: 0,
                openingCount = typeCounts["IFCOPENINGELEMENT"] ?: 0,
                objectCount = bim.objects.size,
                propertySetCount = typeCounts["IFCPROPERTYSET"] ?: 0,
                entityCount = model.entities.size
            ),
            validation
        )
    }
}
