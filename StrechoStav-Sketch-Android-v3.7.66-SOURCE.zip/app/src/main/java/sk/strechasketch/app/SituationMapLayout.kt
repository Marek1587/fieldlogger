package sk.strechasketch.app

import kotlin.math.max
import kotlin.math.min

/** Deterministic north-up viewport used by the PDF situation plan. */
data class SituationMapViewport(
    val sourceZoom: Int,
    val scale: Double,
    val worldLeft: Double,
    val worldTop: Double,
    val outputWidth: Int,
    val outputHeight: Int,
    val polygonPixels: List<LocalPoint>
) {
    fun screenX(worldX: Double): Double = (worldX - worldLeft) * scale
    fun screenY(worldY: Double): Double = (worldY - worldTop) * scale
}

object SituationMapLayout {
    /** Fixed ZBGIS source level required for the PDF site-placement plan. */
    const val PDF_SOURCE_ZOOM = 20

    private const val MIN_SPAN_WORLD_PX = 1.0
    private const val MAX_DIGITAL_SCALE = 4.0
    private const val MIN_SAFE_SCALE = 0.0001

    fun createForPdf(
        polygon: List<GeoPoint>,
        outputWidth: Int,
        outputHeight: Int
    ): SituationMapViewport = create(
        polygon = polygon,
        requestedZoom = PDF_SOURCE_ZOOM,
        outputWidth = outputWidth,
        outputHeight = outputHeight
    )

    /**
     * Fits the complete building outline into the map while retaining useful surroundings.
     * The result depends only on geometry, therefore panning the editor cannot move the PDF crop.
     */
    fun create(
        polygon: List<GeoPoint>,
        requestedZoom: Int,
        outputWidth: Int,
        outputHeight: Int,
        fillFractionX: Double = 0.60,
        fillFractionY: Double = 0.55
    ): SituationMapViewport {
        require(polygon.size >= 3) { "Situácia vyžaduje uzavretý obrys aspoň z troch bodov." }
        require(outputWidth > 0 && outputHeight > 0) { "Neplatný rozmer mapového výstupu." }
        val sourceZoom = requestedZoom.coerceIn(3, 21)
        val xs = polygon.map { Geometry.worldX(it.lon, sourceZoom) }
        val ys = polygon.map { Geometry.worldY(it.lat, sourceZoom) }
        val spanX = max(MIN_SPAN_WORLD_PX, xs.maxOrNull()!! - xs.minOrNull()!!)
        val spanY = max(MIN_SPAN_WORLD_PX, ys.maxOrNull()!! - ys.minOrNull()!!)
        val scale = min(
            outputWidth * fillFractionX.coerceIn(0.25, 0.85) / spanX,
            outputHeight * fillFractionY.coerceIn(0.25, 0.85) / spanY
        ).coerceAtMost(MAX_DIGITAL_SCALE).coerceAtLeast(MIN_SAFE_SCALE)
        val centerX = (xs.minOrNull()!! + xs.maxOrNull()!!) / 2.0
        val centerY = (ys.minOrNull()!! + ys.maxOrNull()!!) / 2.0
        val worldLeft = centerX - outputWidth / (2.0 * scale)
        val worldTop = centerY - outputHeight / (2.0 * scale)
        val pixels = xs.indices.map { index ->
            LocalPoint(
                (xs[index] - worldLeft) * scale,
                (ys[index] - worldTop) * scale
            )
        }
        return SituationMapViewport(
            sourceZoom = sourceZoom,
            scale = scale,
            worldLeft = worldLeft,
            worldTop = worldTop,
            outputWidth = outputWidth,
            outputHeight = outputHeight,
            polygonPixels = pixels
        )
    }
}
