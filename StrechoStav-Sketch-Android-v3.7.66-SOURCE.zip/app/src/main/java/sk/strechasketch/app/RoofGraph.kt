package sk.strechasketch.app

import org.json.JSONArray
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.util.UUID

enum class EdgeSemantic {
    UNKNOWN, EAVE, GABLE, PULT, ATTIC, WALL_END, RIDGE, HIP, VALLEY,
    RAKE, LOW_EDGE, ELEVATED_LOW_EDGE, STEP, OPENING_BOUNDARY;

    fun toLegacy(): LineType = when (this) {
        UNKNOWN -> LineType.UNKNOWN
        EAVE -> LineType.EAVE
        GABLE -> LineType.GABLE
        PULT -> LineType.PULT
        ATTIC -> LineType.ATTIC
        WALL_END -> LineType.WALL_END
        RIDGE -> LineType.RIDGE
        HIP -> LineType.HIP
        VALLEY -> LineType.VALLEY
        RAKE -> LineType.RAKE
        LOW_EDGE -> LineType.LOW_EDGE
        ELEVATED_LOW_EDGE -> LineType.ELEVATED_LOW_EDGE
        STEP -> LineType.STEP
        OPENING_BOUNDARY -> LineType.OPENING_BOUNDARY
    }

    companion object {
        fun fromLegacy(type: LineType): EdgeSemantic = when (type) {
            LineType.UNKNOWN -> UNKNOWN
            LineType.EAVE -> EAVE
            LineType.GABLE -> GABLE
            LineType.PULT -> PULT
            LineType.ATTIC -> ATTIC
            LineType.WALL_END -> WALL_END
            LineType.RIDGE -> RIDGE
            LineType.HIP -> HIP
            LineType.VALLEY -> VALLEY
            LineType.RAKE -> RAKE
            LineType.LOW_EDGE -> LOW_EDGE
            LineType.ELEVATED_LOW_EDGE -> ELEVATED_LOW_EDGE
            LineType.STEP -> STEP
            LineType.OPENING_BOUNDARY -> OPENING_BOUNDARY
        }
    }
}

data class RoofPlane(val a: Double, val b: Double, val c: Double) {
    fun zAt(x: Double, y: Double): Double = a * x + b * y + c
}

enum class SlopeConstraintSource {
    /** A face-specific value entered by the user. */
    USER,
    /** A compatible value derived from the common ridge height of a gable tract. */
    AUTOMATIC_GABLE,
    /** Constraint loaded from a project written before its origin was persisted. */
    LEGACY
}

data class FaceSlopeConstraint(
    val angleDeg: Double,
    /** Unit vector pointing downhill. The plane gradient points in the opposite direction. */
    val directionX: Double,
    val directionY: Double,
    val hard: Boolean = true,
    val source: SlopeConstraintSource = SlopeConstraintSource.USER
)

data class ElevationConstraint(
    val nodeId: String? = null,
    val x: Double? = null,
    val y: Double? = null,
    val elevationZ: Double,
    val hard: Boolean = true
)

data class DimensionConstraint(
    val id: String = UUID.randomUUID().toString(),
    val supportAEdgeId: String,
    val supportBEdgeId: String,
    val directionX: Double,
    val directionY: Double,
    val valueMm: Double,
    val fixedSupportEdgeId: String? = null,
    val hard: Boolean = true,
    val movingNodeIds: Set<String> = emptySet()
)

data class EdgeLengthConstraint(
    val id: String,
    val edgeId: String,
    val valueMm: Double,
    val fixedNodeId: String,
    val hard: Boolean = true
)

data class GraphNode(
    val id: String,
    val x: Double,
    val y: Double,
    val z: Double = 0.0,
    val lockX: Boolean = false,
    val lockY: Boolean = false,
    val lockZ: Boolean = false
)

data class GraphEdge(
    val id: String,
    val startNodeId: String,
    val endNodeId: String,
    val boundary: Boolean,
    val semanticRole: EdgeSemantic = EdgeSemantic.UNKNOWN,
    val adjacentFaceIds: Set<String> = emptySet(),
    val locked: Boolean = false,
    val note: String = "",
    /** Optional absolute elevation for LOW_EDGE/ELEVATED_LOW_EDGE. */
    val elevationZ: Double? = null
)

data class GraphFace(
    val id: String,
    val orderedNodeIds: List<String>,
    val orderedEdgeIds: List<String>,
    val signedAreaM2: Double,
    val plane: RoofPlane? = null,
    val slopeConstraint: FaceSlopeConstraint? = null,
    val elevationConstraints: List<ElevationConstraint> = emptyList(),
    val underconstrained: Boolean = false,
    /** Inner rings use shared NodeIds and never duplicate node coordinates. */
    val holeNodeIdLoops: List<List<String>> = emptyList(),
    val componentId: String = "main",
    val hostFaceId: String? = null
)

data class RoofComponent(
    val id: String,
    val label: String,
    val hostFaceId: String? = null,
    val faceIds: Set<String> = emptySet()
)

data class DrainPointConstraint(
    val id: String,
    val faceIds: Set<String>,
    val nodeId: String? = null,
    val x: Double? = null,
    val y: Double? = null,
    val elevationZ: Double,
    val hard: Boolean = true
)

data class RoofGraph(
    val origin: GeoPoint,
    val nodes: Map<String, GraphNode>,
    val edges: Map<String, GraphEdge>,
    val faces: Map<String, GraphFace>,
    val dimensions: Map<String, DimensionConstraint> = emptyMap(),
    val schemaVersion: Int = 2,
    val edgeLengthConstraints: Map<String, EdgeLengthConstraint> = emptyMap(),
    val components: Map<String, RoofComponent> = mapOf("main" to RoofComponent("main", "Hlavná strecha")),
    val drainPointConstraints: Map<String, DrainPointConstraint> = emptyMap(),
    /** Stable project-local 100 mm grid axis; independent of map zoom and later edge lengths. */
    val gridRotationDeg: Double = Double.NaN
) {
    fun toTopology(): RoofTopology = RoofTopology(
        origin = origin.copy(),
        nodes = nodes.values.sortedBy { it.id }.map { node ->
            TopologyNode(
                id = node.id,
                x = node.x,
                y = node.y,
                type = if (edges.values.any { it.boundary && (it.startNodeId == node.id || it.endNodeId == node.id) }) {
                    TopologyNodeType.FOOTPRINT
                } else TopologyNodeType.JUNCTION,
                locked = node.lockX && node.lockY
            )
        },
        edges = edges.values.sortedBy { it.id }.map { edge ->
            TopologyEdge(
                id = edge.id,
                startNodeId = edge.startNodeId,
                endNodeId = edge.endNodeId,
                type = edge.semanticRole.toLegacy(),
                locked = edge.locked,
                boundary = edge.boundary,
                sourceId = edge.id,
                note = edge.note
            )
        },
        schemaVersion = 3,
        gridRotationDeg = gridRotationDeg
    )

    fun topologySignature(): String = buildString {
        edges.values.sortedBy { it.id }.forEach { edge ->
            append(edge.id).append(':').append(edge.startNodeId).append('>').append(edge.endNodeId)
                .append(':').append(edge.boundary).append(';')
        }
        faces.values.sortedBy { it.id }.forEach { face ->
            append(face.id).append(':').append(face.orderedNodeIds.joinToString(",")).append(';')
        }
    }
}

object RoofGraphFactory {
    /**
     * A graph may seed Z values, constraints and stable face IDs only when its authored XY
     * inventory is exactly the same as the topology source of truth. Runtime incidence graphs
     * contain split/generated IDs and therefore fail this gate.
     */
    internal fun isAuthoredTopologyCompatible(topology: RoofTopology, graph: RoofGraph): Boolean {
        val candidate = graph.toTopology()
        if (topology.origin != candidate.origin ||
            topology.nodes.size != candidate.nodes.size || topology.edges.size != candidate.edges.size
        ) return false
        if (topology.gridRotationDeg.isFinite() != candidate.gridRotationDeg.isFinite()) return false
        if (topology.gridRotationDeg.isFinite() &&
            kotlin.math.abs(topology.gridRotationDeg - candidate.gridRotationDeg) > 1e-9
        ) return false
        val candidateNodes = candidate.nodes.associateBy(TopologyNode::id)
        val candidateEdges = candidate.edges.associateBy(TopologyEdge::id)
        if (candidateNodes.size != candidate.nodes.size || candidateEdges.size != candidate.edges.size) return false
        if (topology.nodes.any { source ->
                val result = candidateNodes[source.id] ?: return@any true
                kotlin.math.abs(source.x - result.x) > 1e-9 ||
                    kotlin.math.abs(source.y - result.y) > 1e-9 || source.locked != result.locked
            }
        ) return false
        return topology.edges.all { source ->
            val result = candidateEdges[source.id] ?: return@all false
            source.startNodeId == result.startNodeId && source.endNodeId == result.endNodeId &&
                source.type == result.type && source.locked == result.locked &&
                source.boundary == result.boundary && source.note == result.note
        }
    }

    fun fromTopology(
        topology: RoofTopology,
        previous: RoofGraph? = null,
        normalizeGrid: Boolean = true
    ): RoofGraph {
        // Editor card 1 is the only workflow that may normalize the physical boundary.
        // Card 3 passes an already confirmed topology with normalizeGrid=false so this
        // conversion can never introduce a second, hidden footprint deformation.
        val normalizedTopology = if (normalizeGrid) MetricPlanGrid.snap(topology) else topology.copy(
            origin = topology.origin.copy(),
            nodes = topology.nodes.map { it.copy() },
            edges = topology.edges.map { it.copy() }
        )
        val previousFacesByCycle = previous?.faces?.values.orEmpty().associateBy {
            canonicalCycle(it.orderedEdgeIds.ifEmpty { it.orderedNodeIds })
        }
        val unusedPreviousFaces = previous?.faces?.values.orEmpty().toMutableSet()
        val topologyFaces = RoofTopologySolver.extractFaces(normalizedTopology)
        val faces = linkedMapOf<String, GraphFace>()
        topologyFaces.forEach { face ->
            val cycleKey = canonicalCycle(face.edgeIds.ifEmpty { face.nodeIds })
            val previousFace = previousFacesByCycle[cycleKey]
                ?: unusedPreviousFaces
                    .filter { isCyclicRefinement(face.nodeIds, it.orderedNodeIds) }
                    .minByOrNull { old -> face.nodeIds.size - old.orderedNodeIds.size }
            if (previousFace != null) unusedPreviousFaces.remove(previousFace)
            val id = previousFace?.id ?: stableFaceId(cycleKey)
            faces[id] = GraphFace(
                id = id,
                orderedNodeIds = face.nodeIds,
                orderedEdgeIds = face.edgeIds,
                signedAreaM2 = face.signedAreaM2,
                plane = previousFace?.plane,
                slopeConstraint = previousFace?.slopeConstraint,
                elevationConstraints = previousFace?.elevationConstraints.orEmpty(),
                underconstrained = previousFace?.underconstrained ?: false,
                holeNodeIdLoops = previousFace?.holeNodeIdLoops.orEmpty(),
                componentId = previousFace?.componentId ?: "main",
                hostFaceId = previousFace?.hostFaceId
            )
        }
        val adjacent = mutableMapOf<String, MutableSet<String>>()
        faces.values.forEach { face ->
            face.orderedEdgeIds.forEach { edgeId -> adjacent.getOrPut(edgeId) { linkedSetOf() } += face.id }
        }
        val previousNodes = previous?.nodes.orEmpty()
        val graphNodes = normalizedTopology.nodes.associate { node ->
            val old = previousNodes[node.id]
            node.id to GraphNode(
                id = node.id,
                x = node.x,
                y = node.y,
                z = old?.z ?: 0.0,
                lockX = old?.lockX ?: node.locked,
                lockY = old?.lockY ?: node.locked,
                lockZ = old?.lockZ ?: false
            )
        }
        val previousEdges = previous?.edges.orEmpty()
        val graphEdges = normalizedTopology.edges.associate { edge ->
            val old = previousEdges[edge.id]
            edge.id to GraphEdge(
                id = edge.id,
                startNodeId = edge.startNodeId,
                endNodeId = edge.endNodeId,
                boundary = edge.boundary,
                semanticRole = EdgeSemantic.fromLegacy(edge.type),
                adjacentFaceIds = adjacent[edge.id].orEmpty(),
                locked = old?.locked ?: edge.locked,
                note = edge.note,
                elevationZ = old?.elevationZ
            )
        }
        return RoofGraph(
            origin = normalizedTopology.origin.copy(),
            nodes = graphNodes,
            edges = graphEdges,
            faces = faces,
            dimensions = previous?.dimensions.orEmpty(),
            edgeLengthConstraints = previous?.edgeLengthConstraints.orEmpty(),
            components = previous?.components ?: mapOf("main" to RoofComponent("main", "Hlavná strecha")),
            drainPointConstraints = previous?.drainPointConstraints.orEmpty(),
            gridRotationDeg = normalizedTopology.gridRotationDeg
        )
    }

    private fun stableFaceId(cycleKey: String): String = "face-" + UUID.nameUUIDFromBytes(
        cycleKey.toByteArray(StandardCharsets.UTF_8)
    )

    private fun canonicalCycle(values: List<String>): String {
        if (values.isEmpty()) return ""
        fun rotations(input: List<String>) = input.indices.map { index ->
            (input.drop(index) + input.take(index)).joinToString("|")
        }
        return (rotations(values) + rotations(values.asReversed())).minOrNull().orEmpty()
    }

    /** Keeps a face identity when an edge is split by inserting nodes into its cycle. */
    private fun isCyclicRefinement(candidate: List<String>, previous: List<String>): Boolean {
        if (previous.isEmpty() || candidate.size < previous.size) return false
        val previousSet = previous.toSet()
        if (!candidate.containsAll(previousSet)) return false
        return canonicalCycle(candidate.filter { it in previousSet }) == canonicalCycle(previous)
    }
}

data class RoofGraphValidationIssue(
    val code: String,
    val message: String,
    val nodeIds: Set<String> = emptySet(),
    val edgeIds: Set<String> = emptySet(),
    val faceIds: Set<String> = emptySet()
)

object RoofGraphValidator {
    fun validate(graph: RoofGraph): List<RoofGraphValidationIssue> = buildList {
        graph.nodes.values.forEach { node ->
            if (!node.x.isFinite() || !node.y.isFinite() || !node.z.isFinite()) {
                add(RoofGraphValidationIssue("NON_FINITE_NODE", "Uzol obsahuje neplatnú súradnicu.", nodeIds = setOf(node.id)))
            }
        }
        graph.edges.values.forEach { edge ->
            val a = graph.nodes[edge.startNodeId]
            val b = graph.nodes[edge.endNodeId]
            if (a == null || b == null) {
                add(RoofGraphValidationIssue("MISSING_EDGE_NODE", "Hrana odkazuje na chýbajúci uzol.", edgeIds = setOf(edge.id)))
            } else if (kotlin.math.hypot(b.x - a.x, b.y - a.y) < 0.001) {
                add(RoofGraphValidationIssue("ZERO_EDGE", "Hrana má nulovú dĺžku.", nodeIds = setOf(a.id, b.id), edgeIds = setOf(edge.id)))
            }
        }
        graph.faces.values.forEach { face ->
            val missingNodes = (face.orderedNodeIds + face.holeNodeIdLoops.flatten()).filterNot(graph.nodes::containsKey).toSet()
            val missingEdges = face.orderedEdgeIds.filterNot(graph.edges::containsKey).toSet()
            if (missingNodes.isNotEmpty() || missingEdges.isNotEmpty()) {
                add(RoofGraphValidationIssue("BROKEN_FACE_REFERENCE", "Plocha odkazuje na chýbajúci prvok.", missingNodes, missingEdges, setOf(face.id)))
            }
            if (kotlin.math.abs(face.signedAreaM2) <= 1e-8) {
                add(RoofGraphValidationIssue("DEGENERATE_FACE", "Plocha je degenerovaná.", faceIds = setOf(face.id)))
            }
            if (face.signedAreaM2 < 0.0) {
                add(RoofGraphValidationIssue("FACE_ORIENTATION", "Vonkajší okruh plochy nemá kladnú orientáciu.", faceIds = setOf(face.id)))
            }
            if (face.componentId !in graph.components) {
                add(RoofGraphValidationIssue("MISSING_COMPONENT", "Plocha odkazuje na neexistujúci strešný komponent.", faceIds = setOf(face.id)))
            }
            face.hostFaceId?.takeIf { it !in graph.faces }?.let {
                add(RoofGraphValidationIssue("MISSING_HOST_FACE", "Sekundárna plocha odkazuje na neexistujúcu hostiteľskú plochu.", faceIds = setOf(face.id, it)))
            }
            face.plane?.let { plane ->
                val residual = face.orderedNodeIds.mapNotNull(graph.nodes::get)
                    .maxOfOrNull { kotlin.math.abs(it.z - plane.zAt(it.x, it.y)) } ?: 0.0
                if (residual > 1e-6) add(RoofGraphValidationIssue(
                    "PLANE_INCIDENCE", "Uzly plochy neležia na rovine s presnosťou 0,001 mm.",
                    faceIds = setOf(face.id), nodeIds = face.orderedNodeIds.toSet()
                ))
            }
        }
        graph.edges.values.forEach { edge ->
            val actual = graph.faces.values.filter { edge.id in it.orderedEdgeIds }.map { it.id }.toSet()
            if (actual != edge.adjacentFaceIds) {
                add(RoofGraphValidationIssue("FACE_INCIDENCE_MISMATCH", "Väzba hrana–plocha nie je konzistentná.", edgeIds = setOf(edge.id), faceIds = actual + edge.adjacentFaceIds))
            }
            val required = if (edge.boundary) 1 else 2
            if (actual.size != required) add(RoofGraphValidationIssue(
                "INVALID_FACE_COUNT", "${if (edge.boundary) "Obvodová" else "Vnútorná"} hrana musí mať $required susedné plochy.",
                edgeIds = setOf(edge.id), faceIds = actual
            ))
            if (edge.semanticRole == EdgeSemantic.ELEVATED_LOW_EDGE && edge.elevationZ == null) {
                add(RoofGraphValidationIssue("MISSING_LOW_EDGE_HEIGHT", "Zvýšená nízka hrana nemá zadanú výšku.", edgeIds = setOf(edge.id)))
            }
        }
        graph.drainPointConstraints.values.forEach { drain ->
            if (drain.faceIds.isEmpty() || drain.faceIds.any { it !in graph.faces }) {
                add(RoofGraphValidationIssue("BROKEN_DRAIN_REFERENCE", "Vpust odkazuje na neexistujúcu alebo žiadnu plochu.", faceIds = drain.faceIds))
            }
            if (drain.nodeId != null && drain.nodeId !in graph.nodes) {
                add(RoofGraphValidationIssue("BROKEN_DRAIN_NODE", "Vpust odkazuje na neexistujúci uzol.", nodeIds = setOf(drain.nodeId)))
            }
        }
        RoofTopologySolver.validate(graph.toTopology()).forEach { issue ->
            add(RoofGraphValidationIssue("PLAN_${issue.code}", issue.message, issue.nodeIds.toSet(), issue.edgeIds.toSet()))
        }
        if (graph.faces.values.none { it.holeNodeIdLoops.isNotEmpty() } && graph.nodes.isNotEmpty()) {
            val euler = graph.nodes.size - graph.edges.size + graph.faces.size
            if (euler != 1) add(RoofGraphValidationIssue(
                "EULER_INVARIANT", "Topologická sieť nespĺňa invariant V−E+F=1 (výsledok $euler)."
            ))
        }
    }
}

/** Pure graph operations. One call is one undoable user transaction. */
object RoofGraphOperations {
    fun moveNodes(graph: RoofGraph, positions: Map<String, Pair<Double, Double>>): RoofGraph? {
        if (positions.isEmpty()) return graph
        val gridRotation = MetricPlanGrid.axisDeg(graph) ?: 0.0
        val changed = graph.nodes.toMutableMap()
        positions.forEach { (id, position) ->
            val node = graph.nodes[id] ?: return null
            if (!position.first.isFinite() || !position.second.isFinite()) return null
            val snapped = MetricPlanGrid.snap(LocalPoint(position.first, position.second), gridRotation)
            if ((node.lockX && snapped.x != node.x) || (node.lockY && snapped.y != node.y)) return null
            changed[id] = node.copy(x = snapped.x, y = snapped.y)
        }
        return rebuild(graph, changed, graph.edges)
    }

    fun moveNode(graph: RoofGraph, nodeId: String, x: Double, y: Double, z: Double? = null): RoofGraph? {
        val node = graph.nodes[nodeId] ?: return null
        if (!x.isFinite() || !y.isFinite() || (z != null && !z.isFinite())) return null
        val snapped = MetricPlanGrid.snap(LocalPoint(x, y), MetricPlanGrid.axisDeg(graph) ?: 0.0)
        if ((node.lockX && snapped.x != node.x) || (node.lockY && snapped.y != node.y) || (z != null && node.lockZ && z != node.z)) return null
        val moved = node.copy(x = snapped.x, y = snapped.y, z = z ?: node.z)
        return rebuild(graph, graph.nodes + (nodeId to moved), graph.edges)
    }

    fun translateEdge(graph: RoofGraph, edgeId: String, deltaX: Double, deltaY: Double): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        val a = graph.nodes[edge.startNodeId] ?: return null
        val b = graph.nodes[edge.endNodeId] ?: return null
        if (a.lockX || a.lockY || b.lockX || b.lockY || edge.locked) return null
        val rotation = MetricPlanGrid.axisDeg(graph) ?: 0.0
        val movedA = MetricPlanGrid.snap(LocalPoint(a.x + deltaX, a.y + deltaY), rotation)
        val movedB = MetricPlanGrid.snap(LocalPoint(b.x + deltaX, b.y + deltaY), rotation)
        val movedNodes = graph.nodes + mapOf(
            a.id to a.copy(x = movedA.x, y = movedA.y),
            b.id to b.copy(x = movedB.x, y = movedB.y)
        )
        return rebuild(graph, movedNodes, graph.edges)
    }

    fun setSemanticRole(graph: RoofGraph, edgeId: String, role: EdgeSemantic): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        return graph.copy(edges = graph.edges + (edgeId to edge.copy(semanticRole = role)))
    }

    fun setEdgeLength(
        graph: RoofGraph,
        edgeId: String,
        targetLengthM: Double,
        fixedNodeId: String? = null
    ): RoofGraph? {
        if (targetLengthM !in 0.05..5000.0) return null
        val edge = graph.edges[edgeId] ?: return null
        val fixedId = fixedNodeId?.takeIf { it == edge.startNodeId || it == edge.endNodeId } ?: edge.startNodeId
        val movingId = if (fixedId == edge.startNodeId) edge.endNodeId else edge.startNodeId
        val fixed = graph.nodes[fixedId] ?: return null
        val moving = graph.nodes[movingId] ?: return null
        if (moving.lockX || moving.lockY) return null
        val dx = moving.x - fixed.x
        val dy = moving.y - fixed.y
        val length = kotlin.math.hypot(dx, dy)
        if (length < 1e-9) return null
        val raw = LocalPoint(
            x = fixed.x + dx / length * targetLengthM,
            y = fixed.y + dy / length * targetLengthM
        )
        val snapped = MetricPlanGrid.snap(raw, MetricPlanGrid.axisDeg(graph) ?: 0.0)
        val moved = moving.copy(x = snapped.x, y = snapped.y)
        val appliedLengthM = kotlin.math.hypot(moved.x - fixed.x, moved.y - fixed.y)
        val constraint = EdgeLengthConstraint(
            id = "edge-length-$edgeId",
            edgeId = edgeId,
            valueMm = appliedLengthM * 1000.0,
            fixedNodeId = fixedId
        )
        return rebuild(graph, graph.nodes + (movingId to moved), graph.edges).copy(
            edgeLengthConstraints = graph.edgeLengthConstraints + (constraint.id to constraint)
        )
    }

    fun splitEdge(graph: RoofGraph, edgeId: String, newNodeId: String = UUID.randomUUID().toString()): RoofGraph? {
        val edge = graph.edges[edgeId] ?: return null
        val a = graph.nodes[edge.startNodeId] ?: return null
        val b = graph.nodes[edge.endNodeId] ?: return null
        if (newNodeId in graph.nodes) return null
        val midpoint = MetricPlanGrid.snap(
            LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0),
            MetricPlanGrid.axisDeg(graph) ?: 0.0
        )
        val middle = GraphNode(
            id = newNodeId,
            x = midpoint.x,
            y = midpoint.y,
            z = (a.z + b.z) / 2.0
        )
        val suffix = newNodeId.filter(Char::isLetterOrDigit).take(8).ifBlank { "mid" }
        val first = edge.copy(
            id = "${edge.id}A-$suffix",
            endNodeId = middle.id,
            adjacentFaceIds = emptySet()
        )
        val second = edge.copy(
            id = "${edge.id}B-$suffix",
            startNodeId = middle.id,
            adjacentFaceIds = emptySet()
        )
        val newEdges = graph.edges.toMutableMap().apply {
            remove(edge.id)
            put(first.id, first)
            put(second.id, second)
        }
        return rebuild(graph, graph.nodes + (middle.id to middle), newEdges).copy(
            edgeLengthConstraints = graph.edgeLengthConstraints.filterValues { it.edgeId != edgeId }
        )
    }

    private fun rebuild(graph: RoofGraph, nodes: Map<String, GraphNode>, edges: Map<String, GraphEdge>): RoofGraph {
        val topology = graph.copy(nodes = nodes, edges = edges, faces = emptyMap()).toTopology()
        val rebuilt = RoofGraphFactory.fromTopology(topology, graph)
        return rebuilt.copy(
            nodes = rebuilt.nodes.mapValues { (id, node) ->
                nodes[id]?.let { source ->
                    node.copy(z = source.z, lockX = source.lockX, lockY = source.lockY, lockZ = source.lockZ)
                } ?: node
            },
            dimensions = graph.dimensions,
            edgeLengthConstraints = graph.edgeLengthConstraints,
            components = graph.components,
            drainPointConstraints = graph.drainPointConstraints
        )
    }
}

data class RoofGraphTransaction(val label: String, val before: RoofGraph, val after: RoofGraph)

class RoofGraphUndoManager(private val capacity: Int = 30) {
    private val undo = ArrayDeque<RoofGraphTransaction>()
    private val redo = ArrayDeque<RoofGraphTransaction>()

    fun commit(label: String, before: RoofGraph, after: RoofGraph) {
        if (before == after) return
        undo.addLast(RoofGraphTransaction(label, before, after))
        while (undo.size > capacity) undo.removeFirst()
        redo.clear()
    }

    fun undo(current: RoofGraph): RoofGraph? {
        val transaction = undo.removeLastOrNull() ?: return null
        if (transaction.after.topologySignature() != current.topologySignature()) return null
        redo.addLast(transaction)
        return transaction.before
    }

    fun redo(current: RoofGraph): RoofGraph? {
        val transaction = redo.removeLastOrNull() ?: return null
        if (transaction.before.topologySignature() != current.topologySignature()) return null
        undo.addLast(transaction)
        return transaction.after
    }
}

object RoofGraphJson {
    fun encode(graph: RoofGraph): JSONObject = JSONObject().apply {
        put("schema_version", graph.schemaVersion)
        put("origin", point(graph.origin))
        if (graph.gridRotationDeg.isFinite()) put("grid_rotation_deg", graph.gridRotationDeg)
        put("nodes", JSONArray().also { array -> graph.nodes.values.sortedBy { it.id }.forEach { node ->
            array.put(JSONObject().apply {
                put("id", node.id); put("x", node.x); put("y", node.y); put("z", node.z)
                put("lock_x", node.lockX); put("lock_y", node.lockY); put("lock_z", node.lockZ)
            })
        } })
        put("edges", JSONArray().also { array -> graph.edges.values.sortedBy { it.id }.forEach { edge ->
            array.put(JSONObject().apply {
                put("id", edge.id); put("start_node_id", edge.startNodeId); put("end_node_id", edge.endNodeId)
                put("boundary", edge.boundary); put("semantic_role", edge.semanticRole.name)
                put("adjacent_face_ids", JSONArray(edge.adjacentFaceIds.sorted()))
                put("locked", edge.locked); put("note", edge.note)
                edge.elevationZ?.let { put("elevation_z", it) }
            })
        } })
        put("faces", JSONArray().also { array -> graph.faces.values.sortedBy { it.id }.forEach { face ->
            array.put(JSONObject().apply {
                put("id", face.id); put("ordered_node_ids", JSONArray(face.orderedNodeIds))
                put("ordered_edge_ids", JSONArray(face.orderedEdgeIds)); put("signed_area_m2", face.signedAreaM2)
                face.plane?.let { put("plane", JSONObject().put("a", it.a).put("b", it.b).put("c", it.c)) }
                face.slopeConstraint?.let { slope -> put("slope_constraint", JSONObject().apply {
                    put("angle_deg", slope.angleDeg); put("direction_x", slope.directionX)
                    put("direction_y", slope.directionY); put("hard", slope.hard)
                    put("source", slope.source.name)
                }) }
                put("elevation_constraints", JSONArray().also { constraints -> face.elevationConstraints.forEach { item ->
                    constraints.put(JSONObject().apply {
                        item.nodeId?.let { put("node_id", it) }; item.x?.let { put("x", it) }; item.y?.let { put("y", it) }
                        put("elevation_z", item.elevationZ); put("hard", item.hard)
                    })
                } })
                put("underconstrained", face.underconstrained)
                put("hole_node_id_loops", JSONArray().also { holes -> face.holeNodeIdLoops.forEach { holes.put(JSONArray(it)) } })
                put("component_id", face.componentId)
                face.hostFaceId?.let { put("host_face_id", it) }
            })
        } })
        put("dimensions", JSONArray().also { array -> graph.dimensions.values.sortedBy { it.id }.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id); put("support_a_edge_id", item.supportAEdgeId)
                put("support_b_edge_id", item.supportBEdgeId); put("direction_x", item.directionX)
                put("direction_y", item.directionY); put("value_mm", item.valueMm)
                item.fixedSupportEdgeId?.let { put("fixed_support_edge_id", it) }; put("hard", item.hard)
                put("moving_node_ids", JSONArray(item.movingNodeIds.sorted()))
            })
        } })
        put("edge_length_constraints", JSONArray().also { array ->
            graph.edgeLengthConstraints.values.sortedBy { it.id }.forEach { item ->
                array.put(JSONObject().apply {
                    put("id", item.id); put("edge_id", item.edgeId); put("value_mm", item.valueMm)
                    put("fixed_node_id", item.fixedNodeId); put("hard", item.hard)
                })
            }
        })
        put("components", JSONArray().also { array -> graph.components.values.sortedBy { it.id }.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id); put("label", item.label)
                item.hostFaceId?.let { put("host_face_id", it) }
                put("face_ids", JSONArray(item.faceIds.sorted()))
            })
        } })
        put("drain_point_constraints", JSONArray().also { array -> graph.drainPointConstraints.values.sortedBy { it.id }.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id); put("face_ids", JSONArray(item.faceIds.sorted()))
                item.nodeId?.let { put("node_id", it) }; item.x?.let { put("x", it) }; item.y?.let { put("y", it) }
                put("elevation_z", item.elevationZ); put("hard", item.hard)
            })
        } })
    }

    fun decode(value: JSONObject): RoofGraph {
        val schemaVersion = value.optInt("schema_version", 1)
        val origin = value.optJSONObject("origin")?.let {
            GeoPoint(it.optDouble("lat"), it.optDouble("lon", it.optDouble("lng")))
        } ?: GeoPoint(49.0663, 18.9236)
        val nodes = linkedMapOf<String, GraphNode>()
        value.optJSONArray("nodes")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            nodes[id] = GraphNode(id, item.optDouble("x"), item.optDouble("y"), item.optDouble("z"),
                item.optBoolean("lock_x"), item.optBoolean("lock_y"), item.optBoolean("lock_z"))
        } }
        val edges = linkedMapOf<String, GraphEdge>()
        value.optJSONArray("edges")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            edges[id] = GraphEdge(id, item.optString("start_node_id"), item.optString("end_node_id"),
                item.optBoolean("boundary"), runCatching { EdgeSemantic.valueOf(item.optString("semantic_role")) }.getOrDefault(EdgeSemantic.UNKNOWN),
                strings(item.optJSONArray("adjacent_face_ids")).toSet(), item.optBoolean("locked"), item.optString("note"),
                item.optDoubleOrNull("elevation_z"))
        } }
        val faces = linkedMapOf<String, GraphFace>()
        value.optJSONArray("faces")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            val plane = item.optJSONObject("plane")?.let { RoofPlane(it.optDouble("a"), it.optDouble("b"), it.optDouble("c")) }
            val slope = item.optJSONObject("slope_constraint")?.let {
                val migrationSign = if (schemaVersion < 2) -1.0 else 1.0
                FaceSlopeConstraint(
                    it.optDouble("angle_deg"), migrationSign * it.optDouble("direction_x"),
                    migrationSign * it.optDouble("direction_y"), it.optBoolean("hard", true),
                    runCatching {
                        SlopeConstraintSource.valueOf(it.optString("source"))
                    }.getOrDefault(SlopeConstraintSource.LEGACY)
                )
            }
            val elevations = mutableListOf<ElevationConstraint>()
            item.optJSONArray("elevation_constraints")?.let { list -> repeat(list.length()) { i ->
                val c = list.getJSONObject(i); elevations += ElevationConstraint(
                    c.optString("node_id").takeIf(String::isNotBlank), c.optDoubleOrNull("x"), c.optDoubleOrNull("y"),
                    c.optDouble("elevation_z"), c.optBoolean("hard", true)
                )
            } }
            val holes = mutableListOf<List<String>>()
            item.optJSONArray("hole_node_id_loops")?.let { list -> repeat(list.length()) { i ->
                holes += strings(list.optJSONArray(i))
            } }
            faces[id] = GraphFace(id, strings(item.optJSONArray("ordered_node_ids")), strings(item.optJSONArray("ordered_edge_ids")),
                item.optDouble("signed_area_m2"), plane, slope, elevations, item.optBoolean("underconstrained"),
                holes, item.optString("component_id", "main"), item.optString("host_face_id").takeIf(String::isNotBlank))
        } }
        val dimensions = linkedMapOf<String, DimensionConstraint>()
        value.optJSONArray("dimensions")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { UUID.randomUUID().toString() }
            dimensions[id] = DimensionConstraint(id, item.optString("support_a_edge_id"), item.optString("support_b_edge_id"),
                item.optDouble("direction_x"), item.optDouble("direction_y"), item.optDouble("value_mm"),
                item.optString("fixed_support_edge_id").takeIf(String::isNotBlank), item.optBoolean("hard", true),
                strings(item.optJSONArray("moving_node_ids")).toSet())
        } }
        val edgeLengths = linkedMapOf<String, EdgeLengthConstraint>()
        value.optJSONArray("edge_length_constraints")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index)
            val id = item.optString("id").ifBlank { "edge-length-${item.optString("edge_id")}" }
            edgeLengths[id] = EdgeLengthConstraint(
                id = id,
                edgeId = item.optString("edge_id"),
                valueMm = item.optDouble("value_mm"),
                fixedNodeId = item.optString("fixed_node_id"),
                hard = item.optBoolean("hard", true)
            )
        } }
        val components = linkedMapOf<String, RoofComponent>()
        value.optJSONArray("components")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { "component-$index" }
            components[id] = RoofComponent(id, item.optString("label", id),
                item.optString("host_face_id").takeIf(String::isNotBlank), strings(item.optJSONArray("face_ids")).toSet())
        } }
        if (components.isEmpty()) components["main"] = RoofComponent("main", "Hlavná strecha", faceIds = faces.keys)
        val drains = linkedMapOf<String, DrainPointConstraint>()
        value.optJSONArray("drain_point_constraints")?.let { array -> repeat(array.length()) { index ->
            val item = array.getJSONObject(index); val id = item.optString("id").ifBlank { "drain-$index" }
            drains[id] = DrainPointConstraint(id, strings(item.optJSONArray("face_ids")).toSet(),
                item.optString("node_id").takeIf(String::isNotBlank), item.optDoubleOrNull("x"), item.optDoubleOrNull("y"),
                item.optDouble("elevation_z"), item.optBoolean("hard", true))
        } }
        return RoofGraph(
            origin = origin,
            nodes = nodes,
            edges = edges,
            faces = faces,
            dimensions = dimensions,
            schemaVersion = 2,
            edgeLengthConstraints = edgeLengths,
            components = components,
            drainPointConstraints = drains,
            gridRotationDeg = value.optDouble("grid_rotation_deg", Double.NaN)
        )
    }

    private fun strings(array: JSONArray?): List<String> = buildList {
        if (array != null) repeat(array.length()) { add(array.optString(it)) }
    }

    private fun point(point: GeoPoint) = JSONObject().put("lat", point.lat).put("lon", point.lon)
    private fun JSONObject.optDoubleOrNull(key: String): Double? = if (has(key) && !isNull(key)) optDouble(key) else null
}
