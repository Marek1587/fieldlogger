package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Visual profile for the deterministic CPU renderer.
 *
 * [TECHNICAL] intentionally remains the default used by the catalogue and live app.
 * [PDF_PHOTOREALISTIC] is opt-in and is currently used only by the PDF exporter.
 */
enum class RoofBitmapStyle {
    TECHNICAL,
    PDF_PHOTOREALISTIC
}

internal data class RoofBitmapRenderProfile(
    val usesModelSpaceMaterial: Boolean,
    val usesFilmicToneMapping: Boolean,
    val usesAmbientOcclusion: Boolean,
    val edgeStrength: Double,
    val backgroundGradientStrength: Double
)

internal fun RoofBitmapStyle.renderProfile(): RoofBitmapRenderProfile = when (this) {
    RoofBitmapStyle.TECHNICAL -> RoofBitmapRenderProfile(
        usesModelSpaceMaterial = false,
        usesFilmicToneMapping = false,
        usesAmbientOcclusion = false,
        edgeStrength = 1.0,
        backgroundGradientStrength = 0.0
    )
    RoofBitmapStyle.PDF_PHOTOREALISTIC -> RoofBitmapRenderProfile(
        usesModelSpaceMaterial = true,
        usesFilmicToneMapping = true,
        usesAmbientOcclusion = true,
        edgeStrength = 0.58,
        backgroundGradientStrength = 0.055
    )
}

/** Pure, deterministic photometry shared by rendering code and JVM tests. */
internal object RoofBitmapPhotometry {
    /** Stable material variation in model space; camera yaw/pitch never enter this function. */
    fun materialGrain(x: Double, y: Double, z: Double): Double {
        val broad = sin(x * 7.13 + z * 9.71 + y * 3.17)
        val fine = cos(x * 21.47 - z * 17.03 + y * 11.29)
        return (0.58 * abs(broad) + 0.42 * abs(fine)).coerceIn(0.0, 1.0)
    }

    /** ACES-inspired shoulder followed by display gamma. */
    fun filmicChannel(baseSrgb: Int, illumination: Double, specular: Double): Int {
        val source = (baseSrgb.coerceIn(0, 255) / 255.0).pow(2.2)
        val exposed = (source * illumination.coerceAtLeast(0.0) * 1.08 + specular.coerceAtLeast(0.0))
            .coerceAtMost(16.0)
        val mapped = if (exposed <= 0.0) 0.0 else {
            ((exposed * (2.51 * exposed + 0.03)) /
                (exposed * (2.43 * exposed + 0.59) + 0.14)).coerceIn(0.0, 1.0)
        }
        return (mapped.pow(1.0 / 2.2) * 255.0).toInt().coerceIn(0, 255)
    }

    /** Soft contact darkening near the wall base and below the roof construction. */
    fun ambientOcclusion(
        material: Float,
        centerY: Double,
        structureMinY: Double,
        structureMaxY: Double,
        normalY: Double
    ): Double {
        val heightSpan = (structureMaxY - structureMinY).coerceAtLeast(1e-6)
        val height01 = ((centerY - structureMinY) / heightSpan).coerceIn(0.0, 1.0)
        val wallOrObject = material < 0.5f || material in 2.5f..5.5f
        val baseContact = if (wallOrObject) ((0.20 - height01) / 0.20).coerceIn(0.0, 1.0) * 0.12 else 0.0
        val underside = if (material in 5.5f..6.5f || normalY < -0.35) 0.075 else 0.0
        val rainwaterContact = if (material in 6.5f..8.5f) 0.025 else 0.0
        return (baseContact + underside + rainwaterContact).coerceIn(0.0, 0.18)
    }
}
