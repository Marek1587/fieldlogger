package sk.strechasketch.app.bim.ifc

object IfcStepString {
    /** ISO 10303-21 string with apostrophe escaping and deterministic UTF-16 \X2\ encoding. */
    fun quote(value: String): String = buildString {
        append('\'')
        var unicodeOpen = false
        fun closeUnicode() {
            if (unicodeOpen) {
                append("\\X0\\")
                unicodeOpen = false
            }
        }
        value.forEach { char ->
            when {
                char == '\'' -> {
                    closeUnicode()
                    append("''")
                }
                char.code in 32..126 && char != '\\' -> {
                    closeUnicode()
                    append(char)
                }
                else -> {
                    if (!unicodeOpen) {
                        append("\\X2\\")
                        unicodeOpen = true
                    }
                    append(char.code.toString(16).uppercase().padStart(4, '0'))
                }
            }
        }
        closeUnicode()
        append('\'')
    }
}
