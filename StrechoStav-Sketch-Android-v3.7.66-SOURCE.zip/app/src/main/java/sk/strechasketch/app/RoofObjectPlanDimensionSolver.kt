package sk.strechasketch.app

/** External 2D position dimensions for one roof object, measured from one stable corner. */
internal object RoofObjectPlanDimensionSolver {
    internal data class PositionDimension(
        val axis: Char,
        val cornerIndex: Int,
        val referenceCorner: LocalPoint,
        val objectPoint: LocalPoint,
        val coordinateEnd: LocalPoint,
        val dimensionA: LocalPoint,
        val dimensionB: LocalPoint,
        val lengthM: Double
    )

    fun solve(
        polygon: List<LocalPoint>,
        objectPoint: LocalPoint,
        offsetM: Double,
        cornerIndex: Int? = null
    ): List<PositionDimension> {
        if (polygon.size < 3 || offsetM <= 0.0) return emptyList()
        val offset = if (cornerIndex != null) {
            RoofObjectPlacement.offsetFromCorner(objectPoint, polygon, cornerIndex)
        } else {
            RoofObjectPlacement.offsetFromNearestCorner(objectPoint, polygon)
        } ?: return emptyList()
        val corner = offset.referenceCorner
        val xPlacement = PlanDimensionPlacementSolver.place(polygon, offset.cornerIndex, offsetM)
        val previousEdge = (offset.cornerIndex - 1 + polygon.size) % polygon.size
        val yPlacement = PlanDimensionPlacementSolver.place(polygon, previousEdge, offsetM)
        val result = arrayListOf<PositionDimension>()
        if (xPlacement != null && offset.xM > 0.0005) {
            val shift = LocalPoint(
                xPlacement.dimensionA.x - corner.x,
                xPlacement.dimensionA.y - corner.y
            )
            result += PositionDimension(
                axis = 'X',
                cornerIndex = offset.cornerIndex,
                referenceCorner = corner,
                objectPoint = objectPoint,
                coordinateEnd = offset.xEnd,
                dimensionA = LocalPoint(corner.x + shift.x, corner.y + shift.y),
                dimensionB = LocalPoint(offset.xEnd.x + shift.x, offset.xEnd.y + shift.y),
                lengthM = offset.xM
            )
        }
        if (yPlacement != null && offset.yM > 0.0005) {
            // The selected corner is the end of the previous polygon edge.
            val shift = LocalPoint(
                yPlacement.dimensionB.x - corner.x,
                yPlacement.dimensionB.y - corner.y
            )
            result += PositionDimension(
                axis = 'Y',
                cornerIndex = offset.cornerIndex,
                referenceCorner = corner,
                objectPoint = objectPoint,
                coordinateEnd = offset.yEnd,
                dimensionA = LocalPoint(corner.x + shift.x, corner.y + shift.y),
                dimensionB = LocalPoint(offset.yEnd.x + shift.x, offset.yEnd.y + shift.y),
                lengthM = offset.yM
            )
        }
        return result
    }

    fun isOutside(polygon: List<LocalPoint>, dimension: PositionDimension): Boolean =
        (0..20).none { step ->
            val t = step / 20.0
            Geometry.pointInPolygon(
                LocalPoint(
                    dimension.dimensionA.x + (dimension.dimensionB.x - dimension.dimensionA.x) * t,
                    dimension.dimensionA.y + (dimension.dimensionB.y - dimension.dimensionA.y) * t
                ),
                polygon
            )
        }
}
