package sk.strechasketch.app

import java.util.Locale
import kotlin.math.abs

/** Text notation shared by STN 01 3420 plan annotations and their tests. */
internal object StnPlanNotation {
    fun elevation(valueM: Double): String {
        if (!valueM.isFinite()) return "-"
        if (abs(valueM) < 0.0005) return "±0,000"
        return String.format(Locale("sk", "SK"), "%+.3f", valueM).replace('.', ',')
    }

    fun slopeDegrees(valueDeg: Double): String {
        if (!valueDeg.isFinite()) return "-"
        return String.format(Locale("sk", "SK"), "%.1f°", valueDeg).replace('.', ',')
    }
}
