package sk.strechasketch.app.bim.ifc

object IfcSanityValidator {
    private val entityPattern = Regex("(?m)^#(\\d+)=([A-Z0-9_]+)\\((.*)\\);$")
    private val referencePattern = Regex("#(\\d+)")
    private val guidPattern = Regex("^([0-3][0-9A-Za-z_$]{21})$")

    fun validate(bytes: ByteArray, expectedFaceIds: Set<String> = emptySet()): IfcValidationResult {
        val text = bytes.toString(Charsets.US_ASCII)
        val errors = mutableListOf<String>()
        fun requireText(value: String, message: String) { if (value !in text) errors += message }
        requireText("ISO-10303-21;", "Chýba ISO-10303-21 header.")
        requireText("HEADER;", "Chýba HEADER sekcia.")
        requireText("DATA;", "Chýba DATA sekcia.")
        requireText("FILE_SCHEMA(('IFC4X3_ADD2'));", "Nesprávna alebo chýbajúca IFC schema.")
        requireText("END-ISO-10303-21;", "Chýba ukončenie STEP súboru.")
        if (Regex("(?i)(NaN|Infinity)").containsMatchIn(text)) errors += "Výstup obsahuje NaN alebo Infinity."
        val entities = entityPattern.findAll(text).toList()
        val ids = entities.map { it.groupValues[1].toInt() }
        if (ids.size != ids.toSet().size) errors += "Duplicitné STEP entity ID."
        val idSet = ids.toSet()
        entities.flatMap { referencePattern.findAll(it.groupValues[3]).map { ref -> ref.groupValues[1].toInt() } }.forEach { ref ->
            if (ref !in idSet) errors += "Dangling STEP referencia #$ref."
        }
        val roots = entities.filter { it.groupValues[2] in IFC_ROOT_TYPES }
        val guids = mutableListOf<String>()
        roots.forEach { match ->
            val first = firstArgument(match.groupValues[3]).trim().removeSurrounding("'")
            if (!guidPattern.matches(first) || !IfcGuid.isValid(first)) errors += "Neplatný IFC GUID v #${match.groupValues[1]} (${match.groupValues[2]})."
            else guids += first
        }
        if (guids.size != guids.toSet().size) errors += "IfcRoot GlobalIds nie sú unikátne."
        expectedFaceIds.forEach { faceId ->
            if (!text.contains("IFCSLAB(") || !text.contains(IfcStepString.quote(faceId))) errors += "GraphFace $faceId nemá IfcSlab/FaceId."
        }
        return IfcValidationResult(errors.isEmpty(), errors.distinct())
    }

    private fun firstArgument(value: String): String {
        var quoted = false
        value.forEachIndexed { index, char ->
            if (char == '\'' && (index == 0 || value[index - 1] != '\'')) quoted = !quoted
            if (char == ',' && !quoted) return value.substring(0, index)
        }
        return value
    }

    private val IFC_ROOT_TYPES = setOf(
        "IFCPROJECT", "IFCSITE", "IFCBUILDING", "IFCBUILDINGSTOREY", "IFCROOF", "IFCSLAB",
        "IFCOPENINGELEMENT", "IFCWINDOW", "IFCCHIMNEY", "IFCBUILDINGELEMENTPROXY",
        "IFCRELAGGREGATES", "IFCRELCONTAINEDINSPATIALSTRUCTURE", "IFCRELDEFINESBYPROPERTIES",
        "IFCRELVOIDSELEMENT", "IFCRELFILLSELEMENT", "IFCPROPERTYSET", "IFCELEMENTQUANTITY"
    )
}
