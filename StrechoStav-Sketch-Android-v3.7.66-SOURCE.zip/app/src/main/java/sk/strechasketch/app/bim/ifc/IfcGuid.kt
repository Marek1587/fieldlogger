package sk.strechasketch.app.bim.ifc

import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.UUID

object IfcGuid {
    private const val ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_$"

    fun fromIdentity(identity: String): String = compress(
        UUID.nameUUIDFromBytes(identity.toByteArray(StandardCharsets.UTF_8))
    )

    fun compress(uuid: UUID): String {
        val bytes = ByteBuffer.allocate(16).putLong(uuid.mostSignificantBits).putLong(uuid.leastSignificantBits).array()
        fun u(i: Int) = bytes[i].toInt() and 0xff
        val data1 = (u(0).toLong() shl 24) or (u(1).toLong() shl 16) or (u(2).toLong() shl 8) or u(3).toLong()
        val data2 = (u(4) shl 8) or u(5)
        val data3 = (u(6) shl 8) or u(7)
        val groups = longArrayOf(
            data1 ushr 24,
            data1 and 0xffffff,
            ((data2.toLong() shl 8) or (data3 ushr 8).toLong()),
            (((data3 and 0xff).toLong() shl 16) or (u(8).toLong() shl 8) or u(9).toLong()),
            ((u(10).toLong() shl 16) or (u(11).toLong() shl 8) or u(12).toLong()),
            ((u(13).toLong() shl 16) or (u(14).toLong() shl 8) or u(15).toLong())
        )
        return buildString(22) {
            groups.forEachIndexed { index, value -> append(encode(value, if (index == 0) 2 else 4)) }
        }
    }

    private fun encode(input: Long, length: Int): String {
        var value = input
        val chars = CharArray(length)
        for (index in length - 1 downTo 0) {
            chars[index] = ALPHABET[(value and 63).toInt()]
            value = value ushr 6
        }
        return String(chars)
    }

    fun isValid(value: String): Boolean = value.length == 22 && value.all(ALPHABET::contains)
}
