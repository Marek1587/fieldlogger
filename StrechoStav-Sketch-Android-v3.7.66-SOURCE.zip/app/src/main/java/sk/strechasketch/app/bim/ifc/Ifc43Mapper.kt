package sk.strechasketch.app.bim.ifc

import sk.strechasketch.app.*
import sk.strechasketch.app.bim.*
import java.security.MessageDigest
import java.time.Instant

object Ifc43Mapper {
    private val OMIT = IfcStepValue.Omitted
    private val DERIVED = IfcStepValue.Derived
    private fun s(value: String?) = value?.let(IfcStepValue::Text) ?: OMIT
    private fun n(value: Double) = IfcStepValue.Number(value)
    private fun i(value: Int) = IfcStepValue.Integer(value)
    private fun e(value: String) = IfcStepValue.Enum(value)
    private fun b(value: Boolean) = IfcStepValue.Boolean(value)
    private fun r(key: String) = IfcStepValue.Reference(key)
    private fun list(vararg values: IfcStepValue) = IfcStepValue.Values(values.toList())
    private fun list(values: List<IfcStepValue>) = IfcStepValue.Values(values)
    private fun typed(type: String, value: IfcStepValue) = IfcStepValue.Typed(type, value)

    fun map(
        model: StrechoStavBimModel,
        applicationVersion: String,
        timestamp: Instant,
        fileName: String
    ): Ifc43Model {
        val out = Ifc43ModelBuilder()
        val identity = { kind: String, source: String -> "${model.projectId}:$kind:$source" }
        fun root(key: String, name: String?, description: String? = null) = arrayOf(
            s(IfcGuid.fromIdentity(identity("guid", key))), OMIT, s(name), s(description)
        )
        fun addRoot(key: String, type: String, name: String?, description: String? = null, vararg tail: IfcStepValue): String =
            out.add(key, type, *root(key, name, description), *tail, root = true)

        // Application metadata is intentionally organization-only; the project does not know a person/author.
        out.add("meta:organization", "IFCORGANIZATION", OMIT, s("StrechoStav"), OMIT, OMIT, OMIT)
        out.add(
            "meta:application", "IFCAPPLICATION", r("meta:organization"), s(applicationVersion),
            s("StrechoStav Sketch"), s("STRECHOSTAV_SKETCH")
        )

        out.add("geometry:origin", "IFCCARTESIANPOINT", list(n(0.0), n(0.0), n(0.0)))
        out.add("geometry:axis-z", "IFCDIRECTION", list(n(0.0), n(0.0), n(1.0)))
        out.add("geometry:axis-x", "IFCDIRECTION", list(n(1.0), n(0.0), n(0.0)))
        out.add("geometry:wcs", "IFCAXIS2PLACEMENT3D", r("geometry:origin"), r("geometry:axis-z"), r("geometry:axis-x"))
        out.add("context:model", "IFCGEOMETRICREPRESENTATIONCONTEXT", s("Model"), s("Model"), i(3), n(1e-7), r("geometry:wcs"), OMIT)
        out.add("unit:length", "IFCSIUNIT", DERIVED, e("LENGTHUNIT"), OMIT, e("METRE"))
        out.add("unit:area", "IFCSIUNIT", DERIVED, e("AREAUNIT"), OMIT, e("SQUARE_METRE"))
        out.add("unit:volume", "IFCSIUNIT", DERIVED, e("VOLUMEUNIT"), OMIT, e("CUBIC_METRE"))
        out.add("unit:assignment", "IFCUNITASSIGNMENT", list(r("unit:length"), r("unit:area"), r("unit:volume")))

        fun placement(key: String, relativeTo: String?): String {
            val point = "$key:point"
            val axis = "$key:axis"
            out.add(point, "IFCCARTESIANPOINT", list(n(0.0), n(0.0), n(0.0)))
            out.add(axis, "IFCAXIS2PLACEMENT3D", r(point), OMIT, OMIT)
            return out.add(key, "IFCLOCALPLACEMENT", relativeTo?.let(::r) ?: OMIT, r(axis))
        }
        val sitePlacement = placement("placement:site", null)
        val buildingPlacement = placement("placement:building", sitePlacement)
        val storeyPlacement = placement("placement:storey", buildingPlacement)
        val roofPlacement = placement("placement:roof", storeyPlacement)

        val projectKey = addRoot(
            "root:project", "IFCPROJECT", model.name, "StrechoStav Sketch BIM export",
            s("STRECHOSTAV_PROJECT"), s(model.name), OMIT, list(r("context:model")), r("unit:assignment")
        )
        val siteKey = addRoot(
            "root:site", "IFCSITE", "Stavenisko", null,
            OMIT, r(sitePlacement), OMIT, OMIT, e("ELEMENT"), OMIT, OMIT, OMIT, OMIT, OMIT
        )
        val buildingKey = addRoot(
            "root:building", "IFCBUILDING", model.name, null,
            OMIT, r(buildingPlacement), OMIT, s(model.name), e("ELEMENT"), OMIT, OMIT, OMIT
        )
        val storeyKey = addRoot(
            "root:storey", "IFCBUILDINGSTOREY", "Strecha", null,
            OMIT, r(storeyPlacement), OMIT, s("Strecha"), e("ELEMENT"), n(model.wallHeightM)
        )
        val roofKey = addRoot(
            "element:roof", "IFCROOF", "Strecha", null,
            s(model.shape.name), r(roofPlacement), OMIT, s("roof:${model.projectId}:main"), e(model.shape.toIfcRoofPredefinedType())
        )

        fun aggregate(key: String, whole: String, parts: List<String>, name: String) = addRoot(
            key, "IFCRELAGGREGATES", name, null, r(whole), list(parts.map(::r))
        )
        aggregate("rel:project-site", projectKey, listOf(siteKey), "Projekt obsahuje stavenisko")
        aggregate("rel:site-building", siteKey, listOf(buildingKey), "Stavenisko obsahuje budovu")
        aggregate("rel:building-storey", buildingKey, listOf(storeyKey), "Budova obsahuje podlažie")

        val contained = mutableListOf(roofKey)
        val faceSlabs = model.faces.map { face ->
            val base = "face:${face.id}"
            val coordinates = face.outer + face.holes.flatten()
            val pointListKey = "$base:points"
            out.add(pointListKey, "IFCCARTESIANPOINTLIST3D", list(coordinates.map { p -> list(n(p.x), n(p.y), n(p.z)) }), OMIT)
            val outerIndices = face.outer.indices.map { IfcStepValue.Integer(it + 1) }
            var offset = face.outer.size
            val innerIndices = face.holes.map { hole ->
                val result = hole.indices.map { IfcStepValue.Integer(offset + it + 1) }
                offset += hole.size
                list(result)
            }
            val polygonKey = "$base:polygon"
            if (innerIndices.isEmpty()) {
                out.add(polygonKey, "IFCINDEXEDPOLYGONALFACE", list(outerIndices))
            } else {
                out.add(polygonKey, "IFCINDEXEDPOLYGONALFACEWITHVOIDS", list(outerIndices), list(innerIndices))
            }
            val faceSetKey = "$base:faceset"
            out.add(faceSetKey, "IFCPOLYGONALFACESET", r(pointListKey), b(false), list(r(polygonKey)), OMIT)
            val shapeKey = "$base:shape"
            out.add(shapeKey, "IFCSHAPEREPRESENTATION", r("context:model"), s("Body"), s("Tessellation"), list(r(faceSetKey)))
            val definitionKey = "$base:definition"
            out.add(definitionKey, "IFCPRODUCTDEFINITIONSHAPE", OMIT, OMIT, list(r(shapeKey)))
            val slabPlacement = placement("$base:placement", roofPlacement)
            val slabKey = addRoot(
                "$base:slab", "IFCSLAB", "Strešná plocha ${face.id}", null,
                s("ROOF_FACE"), r(slabPlacement), r(definitionKey), s(face.id), e("ROOF")
            )
            out.faceSlabKeys[face.id] = slabKey
            addFaceProperties(out, model, face, slabKey, identity)
            addSlabQuantities(out, model, face, slabKey, identity)
            slabKey
        }
        aggregate("rel:roof-faces", roofKey, faceSlabs, "Strecha pozostáva zo strešných plôch")
        addRoofQuantities(out, model, roofKey, identity)
        addRoofProperties(out, model, roofKey, identity)
        addProjectPayload(out, model, projectKey, applicationVersion, identity)

        val openingsByFace = linkedMapOf<String, MutableList<String>>()
        model.faces.forEach { face ->
            face.holes.forEachIndexed { index, hole ->
                val openingKey = addSurfaceOpening(out, model, face, index, hole, roofPlacement, identity)
                openingsByFace.getOrPut(face.id) { mutableListOf() } += openingKey
            }
        }
        model.objects.forEach { item ->
            val product = IfcRoofObjectMapper.add(out, model, item, roofPlacement, openingsByFace, identity)
            contained += product
        }
        addRoot(
            "rel:storey-elements", "IFCRELCONTAINEDINSPATIALSTRUCTURE", "Prvky strechy", null,
            list(contained.distinct().map(::r)), r(storeyKey)
        )

        return Ifc43Model(fileName, timestamp, applicationVersion, out.entities(), out.rootKeys, out.faceSlabKeys)
    }

    private fun RoofShape.toIfcRoofPredefinedType(): String = when (this) {
        RoofShape.FLAT -> "FLAT_ROOF"
        RoofShape.GABLE -> "GABLE_ROOF"
        RoofShape.HIP -> "HIP_ROOF"
        RoofShape.SHED -> "SHED_ROOF"
        RoofShape.AUTO -> "NOTDEFINED"
    }

    private fun property(
        out: Ifc43ModelBuilder,
        key: String,
        name: String,
        type: String,
        value: IfcStepValue
    ): String = out.add(key, "IFCPROPERTYSINGLEVALUE", s(name), OMIT, typed(type, value), OMIT)

    private fun propertySet(
        out: Ifc43ModelBuilder,
        key: String,
        name: String,
        target: String,
        properties: List<String>,
        identity: (String, String) -> String
    ) {
        val pset = "$key:pset"
        out.add(pset, "IFCPROPERTYSET", s(IfcGuid.fromIdentity(identity("guid", pset))), OMIT, s(name), OMIT, list(properties.map(::r)), root = true)
        val rel = "$key:rel"
        out.add(rel, "IFCRELDEFINESBYPROPERTIES", s(IfcGuid.fromIdentity(identity("guid", rel))), OMIT, s("$name assignment"), OMIT, list(r(target)), r(pset), root = true)
    }

    private fun addFaceProperties(
        out: Ifc43ModelBuilder,
        model: StrechoStavBimModel,
        face: BimRoofFace,
        slab: String,
        identity: (String, String) -> String
    ) {
        val base = "props:face:${face.id}"
        val props = mutableListOf<String>()
        fun textProp(name: String, value: String?) {
            if (value != null) props += property(out, "$base:$name", name, "IFCTEXT", s(value))
        }
        fun realProp(name: String, value: Double) {
            props += property(out, "$base:$name", name, "IFCREAL", n(value))
        }
        textProp("ObjectId", "face:${model.projectId}:${face.id}")
        textProp("FaceId", face.id)
        textProp("ComponentId", face.componentId)
        textProp("HostFaceId", face.hostFaceId)
        realProp("PlaneA", face.plane.a); realProp("PlaneB", face.plane.b); realProp("PlaneC", face.plane.c)
        props += property(out, "$base:Underconstrained", "Underconstrained", "IFCBOOLEAN", b(face.underconstrained))
        realProp("PlanAreaM2", face.planAreaM2); realProp("Area3DM2", face.area3DM2)
        textProp("OrderedNodeIds", face.orderedNodeIds.joinToString(","))
        textProp("OrderedEdgeIds", face.orderedEdgeIds.joinToString(","))
        face.slopeConstraint?.let { slope ->
            realProp("SlopeConstraintAngleDeg", slope.angleDeg)
            realProp("SlopeDirectionX", slope.directionX)
            realProp("SlopeDirectionY", slope.directionY)
            props += property(out, "$base:SlopeConstraintHard", "SlopeConstraintHard", "IFCBOOLEAN", b(slope.hard))
        }
        propertySet(out, base, "StrechoStav_RoofFace", slab, props, identity)
    }

    private fun addRoofProperties(
        out: Ifc43ModelBuilder,
        model: StrechoStavBimModel,
        roof: String,
        identity: (String, String) -> String
    ) {
        val base = "props:roof"
        val props = listOf(
            property(out, "$base:ProjectId", "ProjectId", "IFCIDENTIFIER", s(model.projectId)),
            property(out, "$base:RoofShape", "RoofShape", "IFCLABEL", s(model.shape.name)),
            property(out, "$base:DefaultSlopeDeg", "DefaultSlopeDeg", "IFCREAL", n(model.defaultSlopeDeg)),
            property(out, "$base:WallHeightM", "WallHeightM", "IFCREAL", n(model.wallHeightM)),
            property(out, "$base:OriginLatitude", "OriginLatitude", "IFCREAL", n(model.origin.lat)),
            property(out, "$base:OriginLongitude", "OriginLongitude", "IFCREAL", n(model.origin.lon)),
            property(out, "$base:GraphEdgesJson", "GraphEdgesJson", "IFCTEXT", s(model.edges.joinToString(prefix = "[", postfix = "]") {
                "{\"id\":\"${it.id}\",\"role\":\"${it.semanticRole}\",\"start\":\"${it.startNodeId}\",\"end\":\"${it.endNodeId}\"}"
            }))
        )
        propertySet(out, base, "StrechoStav_Roof", roof, props, identity)
    }

    private fun addProjectPayload(
        out: Ifc43ModelBuilder,
        model: StrechoStavBimModel,
        project: String,
        version: String,
        identity: (String, String) -> String
    ) {
        val base = "props:project-data"
        val bytes = model.canonicalProjectJson.toByteArray(Charsets.UTF_8)
        val sha = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
        val chunks = model.canonicalProjectJson.chunked(3000)
        val props = mutableListOf(
            property(out, "$base:Schema", "Schema", "IFCLABEL", s("strechostav-sketch-project-6")),
            property(out, "$base:SchemaVersion", "SchemaVersion", "IFCINTEGER", i(6)),
            property(out, "$base:Application", "Application", "IFCLABEL", s("StrechoStav Sketch")),
            property(out, "$base:ApplicationVersion", "ApplicationVersion", "IFCLABEL", s(version)),
            property(out, "$base:ProjectId", "ProjectId", "IFCIDENTIFIER", s(model.projectId)),
            property(out, "$base:PayloadEncoding", "PayloadEncoding", "IFCLABEL", s("UTF-8 JSON")),
            property(out, "$base:PayloadSha256", "PayloadSha256", "IFCIDENTIFIER", s(sha)),
            property(out, "$base:PayloadChunkCount", "PayloadChunkCount", "IFCINTEGER", i(chunks.size))
        )
        chunks.forEachIndexed { index, chunk ->
            val name = "Payload${(index + 1).toString().padStart(4, '0')}"
            props += property(out, "$base:$name", name, "IFCTEXT", s(chunk))
        }
        propertySet(out, base, "StrechoStav_ProjectData", project, props, identity)
    }

    private fun quantityArea(out: Ifc43ModelBuilder, key: String, name: String, value: Double) =
        out.add(key, "IFCQUANTITYAREA", s(name), OMIT, OMIT, n(value.coerceAtLeast(0.0)), OMIT)

    private fun quantityLength(out: Ifc43ModelBuilder, key: String, name: String, value: Double) =
        out.add(key, "IFCQUANTITYLENGTH", s(name), OMIT, OMIT, n(value.coerceAtLeast(0.0)), OMIT)

    private fun quantitySet(
        out: Ifc43ModelBuilder,
        key: String,
        name: String,
        target: String,
        quantities: List<String>,
        identity: (String, String) -> String
    ) {
        val set = "$key:set"
        out.add(set, "IFCELEMENTQUANTITY", s(IfcGuid.fromIdentity(identity("guid", set))), OMIT, s(name), OMIT, s("BaseQuantities"), list(quantities.map(::r)), root = true)
        val rel = "$key:rel"
        out.add(rel, "IFCRELDEFINESBYPROPERTIES", s(IfcGuid.fromIdentity(identity("guid", rel))), OMIT, s("$name assignment"), OMIT, list(r(target)), r(set), root = true)
    }

    private fun addRoofQuantities(out: Ifc43ModelBuilder, model: StrechoStavBimModel, roof: String, identity: (String, String) -> String) {
        val base = "qto:roof"
        val values = listOf(
            quantityArea(out, "$base:GrossArea", "GrossArea", model.faces.sumOf { it.area3DM2 }),
            quantityArea(out, "$base:NetArea", "NetArea", model.quantities.totals.roofAreaM2),
            quantityArea(out, "$base:ProjectedArea", "ProjectedArea", model.quantities.totals.footprintAreaM2)
        )
        quantitySet(out, base, "Qto_RoofBaseQuantities", roof, values, identity)
    }

    private fun addSlabQuantities(out: Ifc43ModelBuilder, model: StrechoStavBimModel, face: BimRoofFace, slab: String, identity: (String, String) -> String) {
        val base = "qto:slab:${face.id}"
        val gross = face.area3DM2 + face.holes.sumOf { hole ->
            val plan = kotlin.math.abs(hole.indices.sumOf { index ->
                val a = hole[index]; val b = hole[(index + 1) % hole.size]
                a.x * b.y - b.x * a.y
            } / 2.0)
            plan * kotlin.math.sqrt(1.0 + face.plane.a * face.plane.a + face.plane.b * face.plane.b)
        }
        val values = listOf(
            quantityLength(out, "$base:Perimeter", "Perimeter", face.perimeterM),
            quantityArea(out, "$base:GrossArea", "GrossArea", gross),
            quantityArea(out, "$base:NetArea", "NetArea", face.area3DM2)
        )
        quantitySet(out, base, "Qto_SlabBaseQuantities", slab, values, identity)
    }

    private fun addSurfaceOpening(
        out: Ifc43ModelBuilder,
        model: StrechoStavBimModel,
        face: BimRoofFace,
        index: Int,
        hole: List<BimPoint3>,
        roofPlacement: String,
        identity: (String, String) -> String
    ): String {
        val base = "opening:${face.id}:$index"
        val pointList = "$base:points"
        out.add(pointList, "IFCCARTESIANPOINTLIST3D", list(hole.map { list(n(it.x), n(it.y), n(it.z)) }), OMIT)
        val polygon = "$base:polygon"
        out.add(polygon, "IFCINDEXEDPOLYGONALFACE", list(hole.indices.map { i(it + 1) }))
        val set = "$base:faceset"
        out.add(set, "IFCPOLYGONALFACESET", r(pointList), b(false), list(r(polygon)), OMIT)
        val shape = "$base:shape"
        out.add(shape, "IFCSHAPEREPRESENTATION", r("context:model"), s("Body"), s("Tessellation"), list(r(set)))
        val definition = "$base:definition"
        out.add(definition, "IFCPRODUCTDEFINITIONSHAPE", OMIT, OMIT, list(r(shape)))
        val placement = "$base:placement"
        val point = "$placement:point"; val axis = "$placement:axis"
        out.add(point, "IFCCARTESIANPOINT", list(n(0.0), n(0.0), n(0.0)))
        out.add(axis, "IFCAXIS2PLACEMENT3D", r(point), OMIT, OMIT)
        out.add(placement, "IFCLOCALPLACEMENT", r(roofPlacement), r(axis))
        val opening = "$base:element"
        out.add(opening, "IFCOPENINGELEMENT", s(IfcGuid.fromIdentity(identity("guid", opening))), OMIT, s("Otvor ${face.id}/$index"), OMIT, s("ROOF_OPENING"), r(placement), r(definition), s(base), e("OPENING"), root = true)
        val slab = out.faceSlabKeys.getValue(face.id)
        val rel = "$base:voids"
        out.add(rel, "IFCRELVOIDSELEMENT", s(IfcGuid.fromIdentity(identity("guid", rel))), OMIT, s("Otvor v ${face.id}"), OMIT, r(slab), r(opening), root = true)
        return opening
    }
}

internal object IfcRoofObjectMapper {
    private val OMIT = IfcStepValue.Omitted
    private fun s(value: String?) = value?.let(IfcStepValue::Text) ?: OMIT
    private fun n(value: Double) = IfcStepValue.Number(value)
    private fun e(value: String) = IfcStepValue.Enum(value)
    private fun r(key: String) = IfcStepValue.Reference(key)
    private fun list(values: List<IfcStepValue>) = IfcStepValue.Values(values)
    private fun typed(type: String, value: IfcStepValue) = IfcStepValue.Typed(type, value)

    fun add(
        out: Ifc43ModelBuilder,
        model: StrechoStavBimModel,
        item: BimRoofObject,
        roofPlacement: String,
        openingsByFace: Map<String, MutableList<String>>,
        identity: (String, String) -> String
    ): String {
        val source = item.source
        val base = "object:${source.id}"
        val point = "$base:point"
        out.add(point, "IFCCARTESIANPOINT", list(listOf(n(item.center.x), n(item.center.y), n(item.center.z))))
        val axis = "$base:axis"
        out.add(axis, "IFCAXIS2PLACEMENT3D", r(point), OMIT, OMIT)
        val placement = "$base:placement"
        out.add(placement, "IFCLOCALPLACEMENT", r(roofPlacement), r(axis))
        val guid = s(IfcGuid.fromIdentity(identity("guid", base)))
        val product = when (source.type) {
            ObjectType.CHIMNEY -> out.add(base, "IFCCHIMNEY", guid, OMIT, s(source.type.label), s(source.note), s("CHIMNEY"), r(placement), OMIT, s(source.id), e("NOTDEFINED"), root = true)
            ObjectType.ROOF_WINDOW -> {
                val key = out.add(
                    base, "IFCWINDOW", guid, OMIT, s(source.type.label), s(source.note), s("ROOF_WINDOW"),
                    r(placement), OMIT, s(source.id),
                    source.heightMm.takeIf { it > 0.0 }?.div(1000.0)?.let(::n) ?: OMIT,
                    source.widthMm.takeIf { it > 0.0 }?.div(1000.0)?.let(::n) ?: OMIT,
                    e("WINDOW"), e("NOTDEFINED"), OMIT, root = true
                )
                var opening = source.attachedFaceId?.let { openingsByFace[it]?.removeFirstOrNull() }
                if (opening == null && source.attachedFaceId != null) {
                    val openingKey = "$base:opening"
                    out.add(
                        openingKey, "IFCOPENINGELEMENT",
                        s(IfcGuid.fromIdentity(identity("guid", openingKey))), OMIT,
                        s("Otvor pre strešné okno ${source.id}"), OMIT, s("ROOF_WINDOW_OPENING"),
                        r(placement), OMIT, s("opening:${source.id}"), e("OPENING"), root = true
                    )
                    out.faceSlabKeys[source.attachedFaceId]?.let { slab ->
                        val voidRel = "$base:voids"
                        out.add(
                            voidRel, "IFCRELVOIDSELEMENT",
                            s(IfcGuid.fromIdentity(identity("guid", voidRel))), OMIT,
                            s("Otvor pre strešné okno"), OMIT, r(slab), r(openingKey), root = true
                        )
                    }
                    opening = openingKey
                }
                if (opening != null) {
                    val rel = "$base:fills"
                    out.add(rel, "IFCRELFILLSELEMENT", s(IfcGuid.fromIdentity(identity("guid", rel))), OMIT, s("Strešné okno vypĺňa otvor"), OMIT, r(opening), r(key), root = true)
                }
                key
            }
            else -> out.add(base, "IFCBUILDINGELEMENTPROXY", guid, OMIT, s(source.type.label), s(source.note), s(source.type.name), r(placement), OMIT, s(source.id), e("NOTDEFINED"), root = true)
        }
        val propertyKeys = mutableListOf<String>()
        fun prop(name: String, type: String, value: IfcStepValue?) {
            if (value != null) {
                val key = "$base:property:$name"
                out.add(key, "IFCPROPERTYSINGLEVALUE", s(name), OMIT, typed(type, value), OMIT)
                propertyKeys += key
            }
        }
        prop("ObjectId", "IFCIDENTIFIER", s(source.id)); prop("ObjectType", "IFCLABEL", s(source.type.name))
        prop("WidthMm", "IFCREAL", source.widthMm.takeIf { it > 0.0 }?.let(::n))
        prop("HeightMm", "IFCREAL", source.heightMm.takeIf { it > 0.0 }?.let(::n))
        prop("DiameterMm", "IFCREAL", source.diameterMm.takeIf { it > 0.0 }?.let(::n))
        prop("Value", "IFCREAL", source.value.takeIf { it != 0.0 }?.let(::n))
        prop("RotationDeg", "IFCREAL", n(source.rotationDeg)); prop("Note", "IFCTEXT", source.note.takeIf { it.isNotBlank() }?.let(::s))
        prop("AttachedFaceId", "IFCIDENTIFIER", source.attachedFaceId?.let(::s)); prop("AttachedEdgeId", "IFCIDENTIFIER", source.attachedEdgeId?.let(::s))
        prop("DirectionX", "IFCREAL", n(source.directionX)); prop("DirectionY", "IFCREAL", n(source.directionY))
        prop("ChimneyHeightManual", "IFCBOOLEAN", IfcStepValue.Boolean(source.chimneyHeightManual))
        if (source.type in setOf(ObjectType.DORMER, ObjectType.MACHINE_ROOM, ObjectType.SHAFT, ObjectType.TERRACE)) {
            prop("DormerType", "IFCLABEL", source.dormerType.name.let(::s))
            prop("SuperstructureHeightM", "IFCREAL", n(source.superstructureHeightM))
            prop("SuperstructureSlopeDeg", "IFCREAL", n(source.superstructureSlopeDeg))
            if (source.type == ObjectType.DORMER) prop("DormerOverhangMm", "IFCREAL", n(source.dormerOverhangMm))
        }
        if (source.type == ObjectType.DOWNSPOUT) {
            prop("DownspoutTermination", "IFCLABEL", s(source.downspoutTermination.name))
            prop("DownspoutAutomatic", "IFCBOOLEAN", IfcStepValue.Boolean(source.downspoutAutomatic))
            prop("DownspoutSuppressed", "IFCBOOLEAN", IfcStepValue.Boolean(source.downspoutSuppressed))
        }
        val pset = "$base:pset"
        out.add(pset, "IFCPROPERTYSET", s(IfcGuid.fromIdentity(identity("guid", pset))), OMIT, s("StrechoStav_Object"), OMIT, list(propertyKeys.map(::r)), root = true)
        val rel = "$base:properties"
        out.add(rel, "IFCRELDEFINESBYPROPERTIES", s(IfcGuid.fromIdentity(identity("guid", rel))), OMIT, s("StrechoStav object data"), OMIT, list(listOf(r(product))), r(pset), root = true)
        return product
    }
}
