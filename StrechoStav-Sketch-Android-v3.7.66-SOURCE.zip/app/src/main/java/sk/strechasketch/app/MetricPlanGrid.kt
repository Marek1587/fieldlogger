package sk.strechasketch.app

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.round
import kotlin.math.sin
import kotlin.math.abs
import kotlin.math.roundToLong

/**
 * Invisible project-local construction grid.
 *
 * The grid is expressed in metres, never in screen pixels. Its origin and axis are persisted
 * in [RoofProject], therefore map zoom, map rotation and panning cannot move the lattice below
 * already created geometry. Only XY plan coordinates are quantized; solved elevations stay exact.
 */
object MetricPlanGrid {
    /** Confirmed masonry/outline geometry: dimensions are resolved in 50 mm increments. */
    const val STEP_M = 0.05
    /** Ridge, hip, valley and other non-boundary construction nodes use a finer 25 mm grid. */
    const val INTERNAL_STEP_M = 0.025
    private const val EPS = 1e-9

    fun ensureProjectFrame(project: RoofProject, candidates: List<GeoPoint> = emptyList()) {
        if (!project.geometryGridOriginLat.isFinite() || !project.geometryGridOriginLon.isFinite()) {
            val origin = project.roofGraph?.origin
                ?: project.roofTopology?.origin
                ?: candidates.firstOrNull()
                ?: project.polygon.firstOrNull()
                ?: project.lines.firstOrNull()?.start
                ?: GeoPoint(project.centerLat, project.centerLon)
            project.geometryGridOriginLat = origin.lat
            project.geometryGridOriginLon = origin.lon
        }
        if (!project.geometryGridRotationDeg.isFinite()) {
            val origin = projectOrigin(project)
            val source = when {
                candidates.size >= 2 -> candidates
                project.polygon.size >= 2 -> project.polygon
                else -> emptyList()
            }
            project.geometryGridRotationDeg = source.longestAxisDeg(origin)
                ?: project.roofGraph?.let(::axisDeg)
                ?: project.roofTopology?.let(::axisDeg)
                ?: 0.0
        }
        project.geometryGridRotationDeg = normalizeSquareAxis(project.geometryGridRotationDeg)
    }

    fun snap(project: RoofProject, point: GeoPoint, candidates: List<GeoPoint> = emptyList()): GeoPoint {
        ensureProjectFrame(project, candidates)
        val origin = projectOrigin(project)
        return Geometry.toGeo(
            snap(Geometry.toLocal(point, origin), project.geometryGridRotationDeg),
            origin
        )
    }

    fun snap(point: LocalPoint, rotationDeg: Double): LocalPoint {
        return snap(point, rotationDeg, STEP_M)
    }

    fun snapInternal(point: LocalPoint, rotationDeg: Double): LocalPoint {
        return snap(point, rotationDeg, INTERNAL_STEP_M)
    }

    fun snap(point: LocalPoint, rotationDeg: Double, stepM: Double): LocalPoint {
        require(stepM > 0.0 && stepM.isFinite())
        val angle = Math.toRadians(normalizeSquareAxis(rotationDeg))
        val c = cos(angle)
        val s = sin(angle)
        val u = point.x * c + point.y * s
        val v = -point.x * s + point.y * c
        val snappedU = quantize(u, stepM)
        val snappedV = quantize(v, stepM)
        return LocalPoint(
            x = clean(snappedU * c - snappedV * s),
            y = clean(snappedU * s + snappedV * c)
        )
    }

    fun snap(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return topology.copy(
            nodes = topology.nodes.map { node ->
                val point = snap(
                    LocalPoint(node.x, node.y), rotation,
                    if (node.id in boundaryNodeIds) STEP_M else INTERNAL_STEP_M
                )
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    fun snap(graph: RoofGraph): RoofGraph {
        val rotation = axisDeg(graph) ?: 0.0
        val boundaryNodeIds = graph.edges.values.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return graph.copy(
            nodes = graph.nodes.mapValues { (_, node) ->
                val point = snap(
                    LocalPoint(node.x, node.y), rotation,
                    if (node.id in boundaryNodeIds) STEP_M else INTERNAL_STEP_M
                )
                node.copy(x = point.x, y = point.y)
            },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    /** Quantizes only internal nodes. The confirmed boundary is returned byte-for-byte unchanged. */
    fun snapInternal(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return topology.copy(
            nodes = topology.nodes.map { node ->
                if (node.id in boundaryNodeIds) node.copy()
                else snapInternal(LocalPoint(node.x, node.y), rotation).let { node.copy(x = it.x, y = it.y) }
            },
            edges = topology.edges.map { it.copy() },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    /**
     * Removes the tiny angular drift caused by independent 25 mm rounding.
     * Only non-boundary nodes may move. Ridges remain parallel to a grid axis and
     * hips/valleys remain on a 45 degree grid diagonal; the physical outline is immutable.
     */
    fun regularizeInternalDirections(
        topology: RoofTopology,
        angleToleranceDeg: Double = 10.0
    ): RoofTopology {
        // The tolerance is intentionally not used as an acceptance gate any more. It remains
        // in the API for source compatibility, but every internal edge is assigned to one
        // exact discrete direction. A correction must either satisfy the grid or be reported
        // as an error; "almost 45 degrees" is no longer a valid state.
        @Suppress("UNUSED_VARIABLE") val retainedApiParameter = angleToleranceDeg
        return regularizeDirections(
            topology = snapInternal(topology),
            moveBoundary = false,
            stepM = INTERNAL_STEP_M
        )
    }

    /** Quantizes only physical-outline nodes. Previously [snap] also moved already drawn
     * internal endpoints while card 1 was being corrected, which violated the ownership
     * boundary between the outline and internal-line steps. */
    fun snapBoundary(topology: RoofTopology): RoofTopology {
        val rotation = axisDeg(topology) ?: 0.0
        val boundaryNodeIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        return topology.copy(
            nodes = topology.nodes.map { node ->
                if (node.id !in boundaryNodeIds) node.copy()
                else snap(LocalPoint(node.x, node.y), rotation).let {
                    node.copy(x = it.x, y = it.y)
                }
            },
            edges = topology.edges.map { it.copy() },
            gridRotationDeg = normalizeSquareAxis(rotation)
        )
    }

    /** Card 1 counterpart: all physical outline edges use the same persisted 0/45/90/135 axis. */
    fun regularizeBoundaryDirections(topology: RoofTopology): RoofTopology = regularizeDirections(
        topology = snapBoundary(topology),
        moveBoundary = true,
        stepM = STEP_M
    )

    /** Returns edges that are not exactly on a permitted project-grid direction. */
    fun offDirectionEdgeIds(
        topology: RoofTopology,
        includeBoundary: Boolean,
        includeInternal: Boolean,
        toleranceM: Double = 1e-7
    ): Set<String> {
        val rotation = normalizeSquareAxis(axisDeg(topology) ?: 0.0)
        val angle = Math.toRadians(rotation)
        val c = cos(angle)
        val s = sin(angle)
        val nodes = topology.nodes.associateBy { it.id }
        fun grid(node: TopologyNode) = GridPoint(
            u = node.x * c + node.y * s,
            v = -node.x * s + node.y * c
        )
        return topology.edges.asSequence()
            .filter { (it.boundary && includeBoundary) || (!it.boundary && includeInternal) }
            .filter { edge ->
                val a = nodes[edge.startNodeId] ?: return@filter true
                val b = nodes[edge.endNodeId] ?: return@filter true
                val ga = grid(a)
                val gb = grid(b)
                val du = gb.u - ga.u
                val dv = gb.v - ga.v
                if (hypot(du, dv) <= toleranceM) return@filter true
                val residual = directionResidual(du, dv, permittedDirections(edge))
                residual > toleranceM
            }
            .map { it.id }
            .toSet()
    }

    private enum class GridDirection { HORIZONTAL, VERTICAL, DIAGONAL_UP, DIAGONAL_DOWN }

    private data class GridPoint(val u: Double, val v: Double)

    /** A*u + B*v = C in grid-index coordinates. */
    private data class GridLine(val a: Double, val b: Double, val c: Double)

    private data class EdgeDirection(val edge: TopologyEdge, val direction: GridDirection)

    /**
     * Deterministic discrete graph solver. Every node is solved jointly from all incident
     * line constraints, so two hips and a ridge converge to one real shared XY coordinate.
     * Independent per-edge rounding (the former implementation) could leave three visually
     * close endpoints which were not topologically incident.
     */
    private fun regularizeDirections(
        topology: RoofTopology,
        moveBoundary: Boolean,
        stepM: Double
    ): RoofTopology {
        val rotation = normalizeSquareAxis(axisDeg(topology) ?: 0.0)
        val angle = Math.toRadians(rotation)
        val c = cos(angle)
        val s = sin(angle)
        val boundaryIds = topology.edges.asSequence().filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }.toSet()
        val original = topology.nodes.associateBy { it.id }
        val points = topology.nodes.associate { node ->
            node.id to GridPoint(
                u = (node.x * c + node.y * s) / stepM,
                v = (-node.x * s + node.y * c) / stepM
            )
        }.toMutableMap()
        val movable = topology.nodes.asSequence().filter { node ->
            !node.locked && if (moveBoundary) node.id in boundaryIds else node.id !in boundaryIds
        }.map { it.id }.toSet()
        val relevant = topology.edges.filter { edge -> if (moveBoundary) edge.boundary else !edge.boundary }
        val directions = relevant.mapNotNull { edge ->
            val a = points[edge.startNodeId] ?: return@mapNotNull null
            val b = points[edge.endNodeId] ?: return@mapNotNull null
            EdgeDirection(edge, nearestDirection(b.u - a.u, b.v - a.v, permittedDirections(edge)))
        }
        val incident = mutableMapOf<String, MutableList<EdgeDirection>>()
        directions.forEach { item ->
            incident.getOrPut(item.edge.startNodeId) { mutableListOf() } += item
            incident.getOrPut(item.edge.endNodeId) { mutableListOf() } += item
        }
        val originalPoints = points.toMap()
        val order = movable.sortedWith(
            compareByDescending<String> { incident[it]?.size ?: 0 }.thenBy { it }
        )

        repeat(48) { iteration ->
            var changed = false
            val pass = if (iteration % 2 == 0) order else order.asReversed()
            pass.forEach { nodeId ->
                val current = points[nodeId] ?: return@forEach
                val constraints = incident[nodeId].orEmpty().mapNotNull { item ->
                    val otherId = if (item.edge.startNodeId == nodeId) item.edge.endNodeId else item.edge.startNodeId
                    points[otherId]?.let { constraintLine(item.direction, it) }
                }
                if (constraints.isEmpty()) return@forEach
                val candidates = linkedSetOf<Pair<Long, Long>>()
                fun add(u: Double, v: Double) {
                    if (!u.isFinite() || !v.isFinite()) return
                    val ru = u.roundToLong()
                    val rv = v.roundToLong()
                    for (du in -1L..1L) for (dv in -1L..1L) candidates += (ru + du) to (rv + dv)
                }
                add(current.u, current.v)
                constraints.forEach { line -> project(current, line).also { add(it.u, it.v) } }
                for (i in constraints.indices) for (j in i + 1 until constraints.size) {
                    intersect(constraints[i], constraints[j])?.also { add(it.u, it.v) }
                }
                val anchor = originalPoints.getValue(nodeId)
                val best = candidates.minWithOrNull(
                    compareBy<Pair<Long, Long>> { candidate ->
                        val u = candidate.first.toDouble()
                        val v = candidate.second.toDouble()
                        constraints.sumOf { line ->
                            val residual = line.a * u + line.b * v - line.c
                            residual * residual * 100_000.0
                        } + (u - anchor.u) * (u - anchor.u) + (v - anchor.v) * (v - anchor.v)
                    }.thenBy { it.first }.thenBy { it.second }
                ) ?: return@forEach
                if (abs(best.first - current.u) > EPS || abs(best.second - current.v) > EPS) {
                    points[nodeId] = GridPoint(best.first.toDouble(), best.second.toDouble())
                    changed = true
                }
            }
            if (!changed) return@repeat
        }

        return topology.copy(
            nodes = topology.nodes.map { node ->
                val point = points[node.id] ?: return@map node.copy()
                if (node.id !in movable) node.copy() else node.copy(
                    x = clean(point.u * stepM * c - point.v * stepM * s),
                    y = clean(point.u * stepM * s + point.v * stepM * c)
                )
            },
            gridRotationDeg = rotation
        )
    }

    private fun permittedDirections(edge: TopologyEdge): List<GridDirection> = when {
        edge.boundary -> GridDirection.entries
        edge.type == LineType.RIDGE -> listOf(GridDirection.HORIZONTAL, GridDirection.VERTICAL)
        edge.type == LineType.HIP || edge.type == LineType.VALLEY ->
            listOf(GridDirection.DIAGONAL_UP, GridDirection.DIAGONAL_DOWN)
        else -> GridDirection.entries
    }

    private fun nearestDirection(du: Double, dv: Double, permitted: List<GridDirection>): GridDirection =
        permitted.minWith(compareBy<GridDirection> { directionResidual(du, dv, listOf(it)) }.thenBy { it.ordinal })

    private fun directionResidual(du: Double, dv: Double, permitted: List<GridDirection>): Double =
        permitted.minOf { direction ->
            when (direction) {
                GridDirection.HORIZONTAL -> abs(dv)
                GridDirection.VERTICAL -> abs(du)
                // These are two different support lines. Treating both as
                // abs(abs(du) - abs(dv)) made a rising and a falling hip look
                // equally good. At a shared hip-ridge junction the solver
                // could consequently assign both hips to the same diagonal
                // and settle on a visual compromise instead of one exact
                // topological node.
                GridDirection.DIAGONAL_UP -> abs(dv - du) / kotlin.math.sqrt(2.0)
                GridDirection.DIAGONAL_DOWN -> abs(dv + du) / kotlin.math.sqrt(2.0)
            }
        }

    private fun constraintLine(direction: GridDirection, through: GridPoint): GridLine = when (direction) {
        GridDirection.HORIZONTAL -> GridLine(0.0, 1.0, through.v)
        GridDirection.VERTICAL -> GridLine(1.0, 0.0, through.u)
        GridDirection.DIAGONAL_UP -> GridLine(-1.0, 1.0, through.v - through.u)
        GridDirection.DIAGONAL_DOWN -> GridLine(1.0, 1.0, through.u + through.v)
    }

    private fun project(point: GridPoint, line: GridLine): GridPoint {
        val denominator = line.a * line.a + line.b * line.b
        val factor = (line.a * point.u + line.b * point.v - line.c) / denominator
        return GridPoint(point.u - line.a * factor, point.v - line.b * factor)
    }

    private fun intersect(first: GridLine, second: GridLine): GridPoint? {
        val determinant = first.a * second.b - second.a * first.b
        if (abs(determinant) <= EPS) return null
        return GridPoint(
            u = (first.c * second.b - second.c * first.b) / determinant,
            v = (first.a * second.c - second.a * first.c) / determinant
        )
    }

    fun isOnGrid(point: LocalPoint, rotationDeg: Double, toleranceM: Double = 1e-7): Boolean {
        val snapped = snap(point, rotationDeg)
        return hypot(point.x - snapped.x, point.y - snapped.y) <= toleranceM
    }

    fun isOnInternalGrid(point: LocalPoint, rotationDeg: Double, toleranceM: Double = 1e-7): Boolean {
        val snapped = snapInternal(point, rotationDeg)
        return hypot(point.x - snapped.x, point.y - snapped.y) <= toleranceM
    }

    fun axisDeg(topology: RoofTopology): Double? {
        topology.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val nodes = topology.nodes.associateBy { it.id }
        return topology.edges.asSequence().filter { it.boundary }.mapNotNull { edge ->
            val a = nodes[edge.startNodeId] ?: return@mapNotNull null
            val b = nodes[edge.endNodeId] ?: return@mapNotNull null
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    fun axisDeg(graph: RoofGraph): Double? {
        graph.gridRotationDeg.takeIf(Double::isFinite)?.let { return normalizeSquareAxis(it) }
        val topology = graph.toTopology()
        return axisDeg(topology)
    }

    private fun List<GeoPoint>.longestAxisDeg(origin: GeoPoint): Double? {
        if (size < 2) return null
        return indices.mapNotNull { index ->
            val a = Geometry.toLocal(this[index], origin)
            val b = Geometry.toLocal(this[(index + 1) % size], origin)
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= EPS) null else length to Math.toDegrees(atan2(b.y - a.y, b.x - a.x))
        }.maxWithOrNull(compareBy<Pair<Double, Double>> { it.first }.thenBy { it.second })?.second
            ?.let(::normalizeSquareAxis)
    }

    private fun projectOrigin(project: RoofProject) =
        GeoPoint(project.geometryGridOriginLat, project.geometryGridOriginLon)

    private fun quantize(value: Double, stepM: Double): Double = round(value / stepM) * stepM

    private fun clean(value: Double): Double = if (kotlin.math.abs(value) < EPS) 0.0 else value

    private fun normalizeSquareAxis(value: Double): Double {
        if (!value.isFinite()) return 0.0
        var normalized = value % 90.0
        if (normalized < 0.0) normalized += 90.0
        // 90 degrees describes the same square lattice as 0 degrees.
        if (kotlin.math.abs(normalized - 90.0) < 1e-10) normalized = 0.0
        return normalized
    }
}
