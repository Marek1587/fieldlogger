package sk.strechasketch.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Restores the plan-view roof rules after a footprint dimension changes.
 *
 * HIP and VALLEY lines are hard 45 degree constraints relative to the EAVE
 * meeting their boundary anchor. Shared internal junctions are solved as
 * intersections of those support lines. RIDGE endpoints use the same nodes,
 * therefore ridge position and length are derived from the diagonal solution.
 */
internal object ParametricRoofPlanRegularizer {
    internal data class Result(
        val graph: RoofGraph,
        val adjustedDiagonalEdges: Int,
        val adjustedRidgeEdges: Int,
        val issues: List<String> = emptyList()
    )

    private data class DiagonalSupport(
        val edgeId: String,
        val anchorId: String,
        val mobileId: String,
        val anchorX: Double,
        val anchorY: Double,
        val directionX: Double,
        val directionY: Double,
        val originalLength: Double
    )

    fun regularize(graph: RoofGraph, toleranceM: Double = 0.002): Result {
        val boundary = RoofTopologyMigration.orderedBoundary(graph.toTopology())
            ?: return Result(graph, 0, 0, listOf("Obvod netvorí uzavretý cyklus pre korekciu 45°."))
        val boundaryNodeIds = boundary.first.toSet()
        val incidentBoundary = boundary.second
            .flatMap { edge -> listOf(edge.startNodeId to edge, edge.endNodeId to edge) }
            .groupBy({ it.first }, { it.second })
        val supports = mutableListOf<DiagonalSupport>()
        val issues = mutableListOf<String>()

        graph.edges.values.asSequence()
            .filter { !it.boundary && it.semanticRole in setOf(EdgeSemantic.HIP, EdgeSemantic.VALLEY) }
            .sortedBy { it.id }
            .forEach { edge ->
                val a = graph.nodes[edge.startNodeId] ?: return@forEach
                val b = graph.nodes[edge.endNodeId] ?: return@forEach
                val startBoundary = a.id in boundaryNodeIds
                val endBoundary = b.id in boundaryNodeIds
                if (startBoundary == endBoundary) {
                    issues += "Hrana ${edge.id} nemá práve jeden obvodový kotviaci bod pre korekciu 45°."
                    return@forEach
                }
                val anchor = if (startBoundary) a else b
                val mobile = if (startBoundary) b else a
                val incident = incidentBoundary[anchor.id].orEmpty()
                val preferred = incident.filter { it.type == LineType.EAVE }.ifEmpty { incident }
                if (preferred.isEmpty()) {
                    issues += "Hrana ${edge.id} nemá pri kotve odkvapovú podporu."
                    return@forEach
                }
                val rawX = mobile.x - anchor.x
                val rawY = mobile.y - anchor.y
                val rawLength = hypot(rawX, rawY)
                if (rawLength <= 1e-8) {
                    issues += "Hrana ${edge.id} má nulovú dĺžku."
                    return@forEach
                }
                val rawAngle = atan2(rawY, rawX)
                val targetAngle = preferred.flatMap { eave ->
                    val otherId = if (eave.startNodeId == anchor.id) eave.endNodeId else eave.startNodeId
                    val other = graph.nodes[otherId] ?: return@flatMap emptyList()
                    val eaveAngle = atan2(other.y - anchor.y, other.x - anchor.x)
                    listOf(eaveAngle + PI / 4.0, eaveAngle - PI / 4.0)
                }.minWithOrNull(
                    compareBy<Double> { axisAngleDistance(rawAngle, it) }
                        .thenBy { normalizeAxisAngle(it) }
                ) ?: return@forEach
                var dx = cos(targetAngle)
                var dy = sin(targetAngle)
                if (dx * rawX + dy * rawY < 0.0) {
                    dx = -dx
                    dy = -dy
                }
                supports += DiagonalSupport(
                    edge.id, anchor.id, mobile.id, anchor.x, anchor.y,
                    dx, dy, rawLength
                )
            }

        if (supports.isEmpty()) return Result(graph, 0, 0, issues)
        val positions = graph.nodes.mapValues { (_, node) -> node.x to node.y }.toMutableMap()
        supports.groupBy { it.mobileId }.toSortedMap().forEach { (nodeId, constraints) ->
            val original = graph.nodes[nodeId] ?: return@forEach
            val target = solveJunction(original, constraints, toleranceM)
            if (target == null) {
                issues += "Uzol $nodeId nemá spoločný priesečník všetkých 45° nároží/úžľabí."
            } else {
                positions[nodeId] = target
            }
        }

        val gridRotation = MetricPlanGrid.axisDeg(graph) ?: 0.0
        val movedNodes = graph.nodes.mapValues { (id, node) ->
            val point = positions.getValue(id)
            val snapped = MetricPlanGrid.snap(LocalPoint(point.first, point.second), gridRotation)
            node.copy(x = snapped.x, y = snapped.y)
        }
        var updated = graph.copy(nodes = movedNodes)
        val structuralIds = graph.edges.values.filter {
            !it.boundary && it.semanticRole in setOf(EdgeSemantic.HIP, EdgeSemantic.VALLEY, EdgeSemantic.RIDGE)
        }.mapTo(mutableSetOf()) { it.id }
        val synchronizedLengths = updated.edgeLengthConstraints.mapValues { (_, constraint) ->
            if (constraint.edgeId !in structuralIds) constraint else {
                val edge = updated.edges[constraint.edgeId] ?: return@mapValues constraint
                val a = updated.nodes[edge.startNodeId] ?: return@mapValues constraint
                val b = updated.nodes[edge.endNodeId] ?: return@mapValues constraint
                constraint.copy(valueMm = hypot(b.x - a.x, b.y - a.y) * 1000.0)
            }
        }
        updated = updated.copy(edgeLengthConstraints = synchronizedLengths)
        updated = RoofGraphFactory.fromTopology(updated.toTopology(), updated)

        supports.forEach { support ->
            val anchor = updated.nodes[support.anchorId] ?: return@forEach
            val mobile = updated.nodes[support.mobileId] ?: return@forEach
            val actual = atan2(mobile.y - anchor.y, mobile.x - anchor.x)
            val target = atan2(support.directionY, support.directionX)
            if (axisAngleDistance(actual, target) > Math.toRadians(0.02)) {
                issues += "Hrana ${support.edgeId} sa pre konflikt viacerých väzieb nevyrovnala presne na 45°."
            }
        }
        val movedIds = positions.filter { (id, point) ->
            val old = graph.nodes[id] ?: return@filter false
            hypot(point.first - old.x, point.second - old.y) > 1e-7
        }.keys
        val adjustedRidges = graph.edges.values.count { edge ->
            !edge.boundary && edge.semanticRole == EdgeSemantic.RIDGE &&
                (edge.startNodeId in movedIds || edge.endNodeId in movedIds)
        }
        return Result(
            graph = updated,
            adjustedDiagonalEdges = supports.count { it.mobileId in movedIds },
            adjustedRidgeEdges = adjustedRidges,
            issues = issues.distinct()
        )
    }

    private fun solveJunction(
        original: GraphNode,
        constraints: List<DiagonalSupport>,
        toleranceM: Double
    ): Pair<Double, Double>? {
        if (constraints.size == 1) {
            val line = constraints.single()
            return line.anchorX + line.directionX * line.originalLength to
                line.anchorY + line.directionY * line.originalLength
        }
        val candidates = mutableListOf<Pair<Double, Double>>()
        constraints.indices.forEach { first ->
            for (second in first + 1 until constraints.size) {
                lineIntersection(constraints[first], constraints[second])?.let(candidates::add)
            }
        }
        if (candidates.isEmpty()) {
            val first = constraints.first()
            if (constraints.any { distanceToLine(first.anchorX, first.anchorY, it) > toleranceM }) return null
            val along = (original.x - first.anchorX) * first.directionX +
                (original.y - first.anchorY) * first.directionY
            return first.anchorX + first.directionX * along to first.anchorY + first.directionY * along
        }
        val best = candidates.minWithOrNull(
            compareBy<Pair<Double, Double>> { point ->
                constraints.maxOf { distanceToLine(point.first, point.second, it) }
            }.thenBy { point -> hypot(point.first - original.x, point.second - original.y) }
        ) ?: return null
        return best.takeIf { point ->
            constraints.maxOf { distanceToLine(point.first, point.second, it) } <= toleranceM
        }
    }

    private fun lineIntersection(a: DiagonalSupport, b: DiagonalSupport): Pair<Double, Double>? {
        val cross = a.directionX * b.directionY - a.directionY * b.directionX
        if (abs(cross) <= 1e-9) return null
        val qx = b.anchorX - a.anchorX
        val qy = b.anchorY - a.anchorY
        val t = (qx * b.directionY - qy * b.directionX) / cross
        return a.anchorX + a.directionX * t to a.anchorY + a.directionY * t
    }

    private fun distanceToLine(x: Double, y: Double, line: DiagonalSupport): Double = abs(
        (x - line.anchorX) * line.directionY - (y - line.anchorY) * line.directionX
    )

    private fun axisAngleDistance(a: Double, b: Double): Double {
        var delta = abs(a - b) % PI
        if (delta > PI / 2.0) delta = PI - delta
        return abs(delta)
    }

    private fun normalizeAxisAngle(angle: Double): Double {
        var normalized = angle % PI
        if (normalized < 0.0) normalized += PI
        return normalized
    }
}
