package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Bounded plan correction for a ridge joining two opposite physical gables.
 *
 * A gable is often represented by two collinear boundary edges because the ridge
 * creates a contact node in its middle. Those two contacts belong to one roof tract:
 * they must use the same normalized division ratio and their connecting ridge must
 * consequently remain parallel to the eaves. A near-centred tract is snapped exactly
 * to 1/2. A deliberately off-centre tract keeps its common ratio; it is not forced to
 * become a symmetric roof.
 *
 * Real corners, recess corners and boundary topology are immutable. Every individual
 * correction is limited by [MAX_CONTACT_CORRECTION_M].
 */
internal object RoofTractSymmetrySolver {
    data class Result(
        val topology: RoofTopology,
        val movements: List<NodeMovement>,
        val centeredRidgeContacts: Int
    )

    private data class Contact(
        val ridgeNodeId: String,
        val splitNodeId: String,
        val sideStart: TopologyNode,
        val sideEnd: TopologyNode,
        val sideLength: Double
    )

    const val MAX_CONTACT_CORRECTION_M = 0.30
    private const val ATTACHMENT_TOLERANCE_M = 0.35
    private const val STRAIGHT_TOLERANCE_DEG = 3.0
    private const val RIDGE_PERPENDICULAR_TOLERANCE_DEG = 10.0
    private const val EPSILON = 1e-7

    fun solve(
        input: RoofTopology,
        footprintContext: WallFootprintSolver.Context? = null
    ): Result {
        val ordered = RoofTopologyMigration.orderedBoundary(input)
            ?: return Result(copyOf(input), emptyList(), 0)
        val boundaryIds = ordered.first
        if (boundaryIds.size < 4) return Result(copyOf(input), emptyList(), 0)

        val nodes = input.nodes.associateBy { it.id }.toMutableMap()
        val boundaryEdges = input.edges.filter { it.boundary }
        val boundaryIncident = boundaryEdges.flatMap { edge ->
            listOf(edge.startNodeId to edge, edge.endNodeId to edge)
        }.groupBy({ it.first }, { it.second })

        fun boundaryNode(index: Int): TopologyNode =
            requireNotNull(nodes[boundaryIds[(index + boundaryIds.size) % boundaryIds.size]])

        fun isStraight(index: Int): Boolean {
            val previous = boundaryNode(index - 1)
            val center = boundaryNode(index)
            val next = boundaryNode(index + 1)
            val inX = center.x - previous.x
            val inY = center.y - previous.y
            val outX = next.x - center.x
            val outY = next.y - center.y
            val inLength = hypot(inX, inY)
            val outLength = hypot(outX, outY)
            if (inLength <= EPSILON || outLength <= EPSILON) return false
            val cross = abs(inX * outY - inY * outX) / (inLength * outLength)
            val dot = (inX * outX + inY * outY) / (inLength * outLength)
            return cross <= kotlin.math.sin(Math.toRadians(STRAIGHT_TOLERANCE_DEG)) && dot > 0.0
        }

        fun previousCorner(index: Int): TopologyNode {
            var current = index - 1
            repeat(boundaryIds.size) {
                if (!isStraight(current)) return boundaryNode(current)
                current--
            }
            return boundaryNode(index - 1)
        }

        fun nextCorner(index: Int): TopologyNode {
            var current = index + 1
            repeat(boundaryIds.size) {
                if (!isStraight(current)) return boundaryNode(current)
                current++
            }
            return boundaryNode(index + 1)
        }

        fun contactFor(ridgeNodeId: String): Contact? {
            val ridgeNode = nodes[ridgeNodeId] ?: return null
            val candidateIndex = boundaryIds.indices.asSequence()
                .filter(::isStraight)
                .filter { index ->
                    val split = boundaryNode(index)
                    !split.locked && boundaryIncident[split.id].orEmpty().size == 2 &&
                        boundaryIncident[split.id].orEmpty().all { it.type == LineType.GABLE } &&
                        footprintContext?.sameStructuralPart(
                            ridgeNode.x, ridgeNode.y, split.x, split.y
                        ) != false
                }
                .minByOrNull { distance(ridgeNode, boundaryNode(it)) }
                ?: return null
            val split = boundaryNode(candidateIndex)
            if (ridgeNodeId != split.id && distance(ridgeNode, split) > ATTACHMENT_TOLERANCE_M) return null
            val sideStart = previousCorner(candidateIndex)
            val sideEnd = nextCorner(candidateIndex)
            val sideLength = distance(sideStart, sideEnd)
            if (sideLength <= EPSILON) return null
            return Contact(ridgeNodeId, split.id, sideStart, sideEnd, sideLength)
        }

        val movements = mutableListOf<NodeMovement>()
        val movedBoundaryIds = mutableSetOf<String>()
        var correctedContacts = 0

        fun moveContact(contact: Contact, targetX: Double, targetY: Double) {
            val split = nodes.getValue(contact.splitNodeId)
            var moved = false
            val attachedIds = buildSet {
                add(contact.splitNodeId)
                add(contact.ridgeNodeId)
                input.edges.asSequence().filterNot { it.boundary }.forEach { edge ->
                    listOf(edge.startNodeId, edge.endNodeId).forEach endpointLoop@{ endpointId ->
                        val endpoint = nodes[endpointId] ?: return@endpointLoop
                        if (!endpoint.locked && distance(endpoint, split) <= ATTACHMENT_TOLERANCE_M) add(endpointId)
                    }
                }
            }
            attachedIds.sorted().forEach nodeLoop@{ nodeId ->
                val old = nodes[nodeId] ?: return@nodeLoop
                if (old.locked || hypot(targetX - old.x, targetY - old.y) <= EPSILON) return@nodeLoop
                nodes[nodeId] = old.copy(x = targetX, y = targetY)
                moved = true
                movements += NodeMovement(
                    nodeId, nodeId, old.x, old.y, targetX, targetY,
                    "PAIR_OPPOSITE_GABLE_RIDGE_CONTACTS"
                )
            }
            movedBoundaryIds += contact.splitNodeId
            if (moved) correctedContacts++
        }

        input.edges.asSequence()
            .filter { !it.boundary && !it.locked && it.type == LineType.RIDGE }
            .sortedBy { it.id }
            .forEach ridgeLoop@{ ridge ->
                val first = contactFor(ridge.startNodeId)
                val second = contactFor(ridge.endNodeId)
                if (first == null && second == null) return@ridgeLoop

                if (first != null && second != null && first.splitNodeId != second.splitNodeId) {
                    val ridgeStart = nodes.getValue(ridge.startNodeId)
                    val ridgeEnd = nodes.getValue(ridge.endNodeId)
                    val ridgeLength = distance(ridgeStart, ridgeEnd)
                    if (ridgeLength <= EPSILON) return@ridgeLoop

                    val firstDx = first.sideEnd.x - first.sideStart.x
                    val firstDy = first.sideEnd.y - first.sideStart.y
                    val secondDx = second.sideEnd.x - second.sideStart.x
                    val secondDy = second.sideEnd.y - second.sideStart.y
                    val sideParallelError = abs(firstDx * secondDy - firstDy * secondDx) /
                        (first.sideLength * second.sideLength)
                    val ridgePerpendicularError = abs(
                        firstDx * (ridgeEnd.x - ridgeStart.x) +
                            firstDy * (ridgeEnd.y - ridgeStart.y)
                    ) / (first.sideLength * ridgeLength)
                    if (sideParallelError > kotlin.math.sin(Math.toRadians(STRAIGHT_TOLERANCE_DEG)) ||
                        ridgePerpendicularError > kotlin.math.sin(Math.toRadians(RIDGE_PERPENDICULAR_TOLERANCE_DEG))
                    ) return@ridgeLoop

                    // One spatial transverse axis gives both opposite gables the same
                    // orientation even though their polygon traversal directions differ.
                    val axisX = firstDx / first.sideLength
                    val axisY = firstDy / first.sideLength
                    fun orientedSide(contact: Contact): Pair<TopologyNode, TopologyNode> {
                        val projectionStart = contact.sideStart.x * axisX + contact.sideStart.y * axisY
                        val projectionEnd = contact.sideEnd.x * axisX + contact.sideEnd.y * axisY
                        return if (projectionStart <= projectionEnd) contact.sideStart to contact.sideEnd
                        else contact.sideEnd to contact.sideStart
                    }
                    fun ratio(contact: Contact): Double {
                        val (low, high) = orientedSide(contact)
                        val dx = high.x - low.x
                        val dy = high.y - low.y
                        val lengthSquared = dx * dx + dy * dy
                        val split = nodes.getValue(contact.splitNodeId)
                        return (((split.x - low.x) * dx + (split.y - low.y) * dy) / lengthSquared)
                            .coerceIn(0.0, 1.0)
                    }
                    val firstRatio = ratio(first)
                    val secondRatio = ratio(second)
                    val commonRatio = (firstRatio + secondRatio) / 2.0
                    val centredAllowed = listOf(first, second).all { contact ->
                        abs(ratio(contact) - 0.5) * contact.sideLength <= MAX_CONTACT_CORRECTION_M + EPSILON
                    }
                    val targetRatio = if (centredAllowed) 0.5 else commonRatio

                    val targets = listOf(first, second).associateWith { contact ->
                        val (low, high) = orientedSide(contact)
                        (low.x + (high.x - low.x) * targetRatio) to
                            (low.y + (high.y - low.y) * targetRatio)
                    }
                    if (targets.any { (contact, target) ->
                        val split = nodes.getValue(contact.splitNodeId)
                        hypot(target.first - split.x, target.second - split.y) >
                            MAX_CONTACT_CORRECTION_M + EPSILON
                    }) return@ridgeLoop
                    listOf(first, second).forEach { contact ->
                        if (contact.splitNodeId !in movedBoundaryIds) {
                            val target = targets.getValue(contact)
                            moveContact(contact, target.first, target.second)
                        }
                    }
                } else {
                    // A one-sided ridge/hip transition may still use the old conservative
                    // centre snap, but only when it already lies within 300 mm of the centre.
                    val contact = first ?: second ?: return@ridgeLoop
                    if (contact.splitNodeId in movedBoundaryIds) return@ridgeLoop
                    val targetX = (contact.sideStart.x + contact.sideEnd.x) / 2.0
                    val targetY = (contact.sideStart.y + contact.sideEnd.y) / 2.0
                    val split = nodes.getValue(contact.splitNodeId)
                    if (hypot(targetX - split.x, targetY - split.y) <= MAX_CONTACT_CORRECTION_M + EPSILON) {
                        moveContact(contact, targetX, targetY)
                    }
                }
            }

        val proposed = input.copy(nodes = input.nodes.map { nodes.getValue(it.id) })
        return Result(proposed, movements, correctedContacts)
    }

    private fun distance(a: TopologyNode, b: TopologyNode): Double = hypot(a.x - b.x, a.y - b.y)

    private fun copyOf(topology: RoofTopology): RoofTopology = topology.copy(
        nodes = topology.nodes.map(TopologyNode::copy),
        edges = topology.edges.map(TopologyEdge::copy)
    )
}
