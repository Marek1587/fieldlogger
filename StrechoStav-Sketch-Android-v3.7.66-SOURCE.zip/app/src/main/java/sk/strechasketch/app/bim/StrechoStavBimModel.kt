package sk.strechasketch.app.bim

import sk.strechasketch.app.*

data class RoofBimSnapshot(
    val project: RoofProject,
    val preparation: Roof3DPreparationResult,
    val graph: RoofGraph,
    val quantities: RoofQuantityAudit,
    val canonicalProjectJson: String
)

data class BimPoint3(val x: Double, val y: Double, val z: Double)

data class BimRoofFace(
    val id: String,
    val componentId: String,
    val hostFaceId: String?,
    val outer: List<BimPoint3>,
    val holes: List<List<BimPoint3>>,
    val orderedNodeIds: List<String>,
    val orderedEdgeIds: List<String>,
    val plane: RoofPlane,
    val slopeConstraint: FaceSlopeConstraint?,
    val underconstrained: Boolean,
    val planAreaM2: Double,
    val area3DM2: Double,
    val perimeterM: Double
)

data class BimRoofObject(
    val source: RoofObject,
    val center: BimPoint3
)

data class StrechoStavBimModel(
    val projectId: String,
    val name: String,
    val origin: GeoPoint,
    val shape: RoofShape,
    val defaultSlopeDeg: Double,
    val wallHeightM: Double,
    val faces: List<BimRoofFace>,
    val edges: List<GraphEdge>,
    val objects: List<BimRoofObject>,
    val quantities: RoofQuantityAudit,
    val canonicalProjectJson: String,
    val warnings: List<String>
)

object RoofBimSnapshotFactory {
    fun create(project: RoofProject): RoofBimSnapshot {
        val preparation = Roof3DPreparation.prepare(project)
        val quantities = RoofQuantityEngine.calculate(project, preparation)
        return RoofBimSnapshot(
            project = project,
            preparation = preparation,
            graph = preparation.graph,
            quantities = quantities,
            canonicalProjectJson = ProjectJson.encode(project, quantities.totals)
        )
    }
}

object StrechoStavBimBuilder {
    fun build(snapshot: RoofBimSnapshot): StrechoStavBimModel {
        val graph = snapshot.graph
        require(!snapshot.preparation.planeSolution.hasBlockingIssues) {
            "IFC export bol zastavený: solver obsahuje blokujúcu chybu."
        }
        require(graph.faces.isNotEmpty()) { "IFC export vyžaduje aspoň jednu platnú strešnú plochu." }
        fun node(id: String): GraphNode = graph.nodes[id]
            ?: error("GraphFace odkazuje na neexistujúci NodeId: $id")
        fun point(id: String) = node(id).let { BimPoint3(it.x, it.y, it.z) }
        fun finite(value: Double, label: String): Double {
            require(value.isFinite()) { "Neplatná numerická hodnota $label." }
            return value
        }
        fun ringPlanArea(points: List<BimPoint3>): Double = kotlin.math.abs(points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        } / 2.0)
        fun ringLength(points: List<BimPoint3>): Double = points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            kotlin.math.sqrt(
                (b.x - a.x) * (b.x - a.x) +
                    (b.y - a.y) * (b.y - a.y) +
                    (b.z - a.z) * (b.z - a.z)
            )
        }
        val quantityByFace = snapshot.quantities.faces.associateBy { it.faceId }
        val faces = graph.faces.values.sortedBy { it.id }.map { face ->
            require(face.orderedNodeIds.size >= 3) { "GraphFace ${face.id} nemá platný vonkajší polygon." }
            val outer = face.orderedNodeIds.map(::point)
            val holes = face.holeNodeIdLoops.map { loop ->
                require(loop.size >= 3) { "Otvor v GraphFace ${face.id} nemá aspoň tri body." }
                loop.map(::point)
            }
            (outer + holes.flatten()).forEachIndexed { index, p ->
                finite(p.x, "${face.id}.point[$index].x")
                finite(p.y, "${face.id}.point[$index].y")
                finite(p.z, "${face.id}.point[$index].z")
            }
            val plane = face.plane ?: error("GraphFace ${face.id} nemá vyriešenú rovinu.")
            finite(plane.a, "${face.id}.plane.a")
            finite(plane.b, "${face.id}.plane.b")
            finite(plane.c, "${face.id}.plane.c")
            val planArea = (ringPlanArea(outer) - holes.sumOf(::ringPlanArea)).coerceAtLeast(0.0)
            BimRoofFace(
                id = face.id,
                componentId = face.componentId,
                hostFaceId = face.hostFaceId,
                outer = outer,
                holes = holes,
                orderedNodeIds = face.orderedNodeIds,
                orderedEdgeIds = face.orderedEdgeIds,
                plane = plane,
                slopeConstraint = face.slopeConstraint,
                underconstrained = face.underconstrained,
                planAreaM2 = planArea,
                area3DM2 = quantityByFace[face.id]?.area3DM2
                    ?: planArea * kotlin.math.sqrt(1.0 + plane.a * plane.a + plane.b * plane.b),
                perimeterM = ringLength(outer) + holes.sumOf(::ringLength)
            )
        }
        val objects = snapshot.project.objects
            .filterNot { it.type == ObjectType.DOWNSPOUT && it.downspoutSuppressed }
            .sortedBy { it.id }.map { item ->
            val local = Geometry.toLocal(item.center, graph.origin)
            val face = item.attachedFaceId?.let(graph.faces::get)
                ?: graph.faces.values.firstOrNull { candidate ->
                    Geometry.pointInPolygon(local, candidate.orderedNodeIds.map { id ->
                        node(id).let { LocalPoint(it.x, it.y) }
                    })
                }
            val z = face?.plane?.zAt(local.x, local.y) ?: snapshot.project.wallHeightM
            BimRoofObject(item, BimPoint3(local.x, local.y, z))
        }
        val warnings = buildList {
            if (faces.any { it.underconstrained }) add("Niektoré strešné plochy sú underconstrained.")
            if (snapshot.preparation.planeWasApproximated) add("Roviny boli pre renderovanie aproximované.")
            add("Presná projektovaná CRS transformácia nie je známa; export používa lokálny engineering coordinate system.")
            add("Projekt neobsahuje deklarovanú materiálovú skladbu ani hrúbku strechy.")
        }
        return StrechoStavBimModel(
            snapshot.project.id,
            snapshot.project.name,
            graph.origin,
            snapshot.project.shape,
            snapshot.project.slopeDeg,
            snapshot.project.wallHeightM,
            faces,
            graph.edges.values.sortedBy { it.id },
            objects,
            snapshot.quantities,
            snapshot.canonicalProjectJson,
            warnings
        )
    }
}
