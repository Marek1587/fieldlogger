package sk.strechasketch.app

import kotlin.math.abs

/**
 * Derives the physical upper edge of masonry from the already solved roof planes.
 *
 * A footprint recess can sit below a continuous roof face. Such a wall is not a
 * constant-height rectangle: its top follows the underside of that face and can
 * consequently be a trapezoid or a gable polygon. The solver is deliberately a
 * presentation derivation. It never changes RoofGraph, quantities or saved project
 * geometry and both the OpenGL and bitmap/PDF renderers consume its result through
 * the shared RoofMesh.
 */
internal object RoofWallProfileSolver {
    internal data class Sample(
        val t: Double,
        val node: GraphNode
    )

    internal data class Segment(
        val index: Int,
        val samples: List<Sample>
    )

    internal data class Solution(
        val segments: List<Segment>,
        val raisedSegmentCount: Int
    )

    private data class FaceSupport(
        val faceId: String,
        val plane: RoofPlane,
        val outer: List<LocalPoint>,
        val holes: List<List<LocalPoint>>,
        val structuralPartId: String?,
        val structuralPriority: Int
    )

    private const val GEOMETRY_TOLERANCE_M = 1e-5
    private const val MINIMUM_PHYSICAL_WALL_TOP_M = 0.05

    fun solve(
        graph: RoofGraph,
        wallLoop: List<LocalPoint>,
        wallHeightM: Double,
        roofShellThicknessM: Double = RoofOverhangSolver.DEFAULT_ROOF_SHELL_THICKNESS_M,
        footprintContext: WallFootprintSolver.Context? = null
    ): Solution {
        if (wallLoop.size < 3) return Solution(emptyList(), 0)
        val supports = supports(graph, footprintContext)
        val thickness = roofShellThicknessM.coerceIn(0.05, 0.60)
        val segments = wallLoop.indices.map { index ->
            val a = wallLoop[index]
            val b = wallLoop[(index + 1) % wallLoop.size]
            Segment(
                index,
                profile(
                    graph, supports, index, a, b, wallHeightM, thickness,
                    footprintContext
                )
            )
        }
        val raised = segments.count { segment ->
            segment.samples.any { it.node.z > wallHeightM + GEOMETRY_TOLERANCE_M }
        }
        return Solution(segments, raised)
    }

    /** Returns the masonry top at an arbitrary wall support point. */
    fun topZAt(
        graph: RoofGraph,
        point: LocalPoint,
        wallHeightM: Double,
        roofShellThicknessM: Double = RoofOverhangSolver.DEFAULT_ROOF_SHELL_THICKNESS_M,
        footprintContext: WallFootprintSolver.Context? = null
    ): Double {
        val thickness = roofShellThicknessM.coerceIn(0.05, 0.60)
        return topZAt(
            supports(graph, footprintContext), point, wallHeightM, thickness,
            footprintContext
        )
    }

    private fun supports(
        graph: RoofGraph,
        footprintContext: WallFootprintSolver.Context?
    ): List<FaceSupport> = graph.faces.values
        .sortedBy { it.id }
        .mapNotNull { face ->
            val plane = face.plane ?: return@mapNotNull null
            val outer = face.orderedNodeIds.mapNotNull(graph.nodes::get)
                .map { LocalPoint(it.x, it.y) }
            if (outer.size < 3) return@mapNotNull null
            val faceCentre = polygonCentroid(outer)
            val structuralPart = footprintContext?.structuralPartAt(faceCentre.x, faceCentre.y)
            FaceSupport(
                face.id,
                plane,
                outer,
                face.holeNodeIdLoops.map { loop ->
                    loop.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
                }.filter { it.size >= 3 },
                structuralPart?.id,
                structuralPart?.let { footprintContext.priorityOf(it.type) } ?: Int.MAX_VALUE
            )
        }

    private fun profile(
        graph: RoofGraph,
        supports: List<FaceSupport>,
        index: Int,
        a: LocalPoint,
        b: LocalPoint,
        wallHeightM: Double,
        thicknessM: Double,
        footprintContext: WallFootprintSolver.Context?
    ): List<Sample> {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val lengthSquared = dx * dx + dy * dy
        if (lengthSquared <= 1e-12) {
            return listOf(Sample(0.0, node(index, 0.0, a, wallHeightM)))
        }

        // Break the wall wherever a roof-face boundary, ridge, hip or valley crosses it.
        // Each resulting interval is covered by one deterministic solved plane.
        val breakpoints = mutableListOf(0.0, 1.0)
        graph.edges.values.sortedBy { it.id }.forEach { edge ->
            val edgeA = graph.nodes[edge.startNodeId] ?: return@forEach
            val edgeB = graph.nodes[edge.endNodeId] ?: return@forEach
            segmentIntersectionParameter(
                a, b, LocalPoint(edgeA.x, edgeA.y), LocalPoint(edgeB.x, edgeB.y)
            )?.let(breakpoints::add)
            listOf(edgeA, edgeB).forEach { endpoint ->
                val t = ((endpoint.x - a.x) * dx + (endpoint.y - a.y) * dy) / lengthSquared
                if (t in -1e-7..1.0000001 &&
                    Geometry.distanceToSegment(LocalPoint(endpoint.x, endpoint.y), a, b) <= GEOMETRY_TOLERANCE_M
                ) breakpoints += t.coerceIn(0.0, 1.0)
            }
        }
        val ordered = breakpoints.sorted().fold(mutableListOf<Double>()) { result, value ->
            val clamped = value.coerceIn(0.0, 1.0)
            if (result.isEmpty() || abs(result.last() - clamped) > 1e-7) result += clamped
            result
        }

        val raw = mutableListOf<Sample>()
        ordered.zipWithNext().forEach { (fromT, toT) ->
            if (toT - fromT <= 1e-9) return@forEach
            val middleT = (fromT + toT) / 2.0
            val middle = LocalPoint(a.x + dx * middleT, a.y + dy * middleT)
            val support = supportAt(supports, middle, footprintContext)
            if (support == null) {
                raw += Sample(fromT, node(index, fromT, LocalPoint(a.x + dx * fromT, a.y + dy * fromT), wallHeightM))
                raw += Sample(toT, node(index, toT, LocalPoint(a.x + dx * toT, a.y + dy * toT), wallHeightM))
                return@forEach
            }
            val fromPoint = LocalPoint(a.x + dx * fromT, a.y + dy * fromT)
            val toPoint = LocalPoint(a.x + dx * toT, a.y + dy * toT)
            val fromRaw = support.plane.zAt(fromPoint.x, fromPoint.y) - thicknessM
            val toRaw = support.plane.zAt(toPoint.x, toPoint.y) - thicknessM
            raw += Sample(
                fromT,
                node(index, fromT, fromPoint, physicalWallTop(fromRaw))
            )
            raw += Sample(
                toT,
                node(index, toT, toPoint, physicalWallTop(toRaw))
            )
        }

        // At a shared break point two faces can contribute the same height. Numerical noise
        // must not create a vertical slit, therefore one conservative underside value wins.
        val merged = mutableListOf<Sample>()
        raw.sortedBy { it.t }.forEach { sample ->
            val previous = merged.lastOrNull()
            if (previous != null && abs(previous.t - sample.t) <= 1e-7) {
                val z = minOf(previous.node.z, sample.node.z)
                    .coerceAtLeast(MINIMUM_PHYSICAL_WALL_TOP_M)
                merged[merged.lastIndex] = previous.copy(node = previous.node.copy(z = z))
            } else merged += sample
        }
        if (merged.isEmpty()) {
            return listOf(
                Sample(0.0, node(index, 0.0, a, wallHeightM)),
                Sample(1.0, node(index, 1.0, b, wallHeightM))
            )
        }
        return merged
    }

    private fun topZAt(
        supports: List<FaceSupport>,
        point: LocalPoint,
        wallHeightM: Double,
        thicknessM: Double,
        footprintContext: WallFootprintSolver.Context?
    ): Double {
        val support = supportAt(supports, point, footprintContext) ?: return wallHeightM
        return physicalWallTop(support.plane.zAt(point.x, point.y) - thicknessM)
    }

    /**
     * The solved roof plane is the sole vertical authority. A projection can sit
     * below the nominal eave height, therefore applying max(wallHeight, z) would
     * force masonry through the roof and detach soffit/gutter geometry.
     */
    private fun physicalWallTop(raw: Double): Double =
        raw.coerceAtLeast(MINIMUM_PHYSICAL_WALL_TOP_M)

    private fun supportAt(
        supports: List<FaceSupport>,
        point: LocalPoint,
        footprintContext: WallFootprintSolver.Context?
    ): FaceSupport? {
        val direct = supports.asSequence().filter { support ->
            containsInclusive(point, support.outer) &&
                support.holes.none { containsInclusive(point, it) }
        }.toList()
        if (direct.isNotEmpty()) return ownedUnderside(direct, point, footprintContext)

        /*
         * A wall footprint is normally inset from the roof outline by the overhang. At a
         * concave corner that inset can lie in the 2D notch of every GraphFace even though
         * the solved roof plane physically continues above the wall. Falling back to the
         * nominal wall height produced the horizontal gaps visible below such recesses.
         *
         * Continue the nearest solved face plane into this presentation-only support zone.
         * This does not move the roof, change RoofGraph or affect quantities. Equidistant
         * faces use the lower underside, which is the conservative envelope at a valley.
         */
        val distances = supports.map { support -> support to boundaryDistance(point, support) }
        val nearestDistance = distances.minOfOrNull { it.second } ?: return null
        val nearest = distances.asSequence()
            .filter { (_, distance) -> distance <= nearestDistance + GEOMETRY_TOLERANCE_M }
            .map { it.first }
            .toList()
        return ownedUnderside(nearest, point, footprintContext)
    }

    /**
     * Plane ownership follows the same host hierarchy as the footprint classifier. The
     * hierarchy only chooses among already solved anthracite planes; it never invents another
     * wall-height rule. Without semantic context the conservative legacy (lowest plane) order
     * remains unchanged.
     */
    private fun ownedUnderside(
        candidates: List<FaceSupport>,
        point: LocalPoint,
        footprintContext: WallFootprintSolver.Context?
    ): FaceSupport? {
        val pointPartId = footprintContext?.structuralPartAt(point.x, point.y)?.id
        return candidates.minWithOrNull(
            compareBy<FaceSupport> {
                if (pointPartId != null && it.structuralPartId == pointPartId) 0 else 1
            }.thenBy { it.structuralPriority }
                .thenBy { it.plane.zAt(point.x, point.y) }
                .thenBy { it.faceId }
        )
    }

    private fun polygonCentroid(points: List<LocalPoint>): LocalPoint {
        var twiceArea = 0.0
        var xMoment = 0.0
        var yMoment = 0.0
        points.indices.forEach { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val cross = a.x * b.y - b.x * a.y
            twiceArea += cross
            xMoment += (a.x + b.x) * cross
            yMoment += (a.y + b.y) * cross
        }
        if (abs(twiceArea) <= 1e-10) {
            return LocalPoint(points.map { it.x }.average(), points.map { it.y }.average())
        }
        return LocalPoint(xMoment / (3.0 * twiceArea), yMoment / (3.0 * twiceArea))
    }

    private fun lowestUnderside(candidates: List<FaceSupport>, point: LocalPoint): FaceSupport? =
        candidates.minWithOrNull(
            compareBy<FaceSupport> { it.plane.zAt(point.x, point.y) }.thenBy { it.faceId }
        )

    private fun boundaryDistance(point: LocalPoint, support: FaceSupport): Double =
        sequenceOf(support.outer).plus(support.holes.asSequence())
            .flatMap { polygon -> polygon.indices.asSequence().map { index ->
                Geometry.distanceToSegment(point, polygon[index], polygon[(index + 1) % polygon.size])
            } }
            .minOrNull() ?: Double.POSITIVE_INFINITY

    private fun containsInclusive(point: LocalPoint, polygon: List<LocalPoint>): Boolean =
        Geometry.pointInPolygon(point, polygon) || polygon.indices.any { index ->
            Geometry.distanceToSegment(point, polygon[index], polygon[(index + 1) % polygon.size]) <=
                GEOMETRY_TOLERANCE_M
        }

    private fun segmentIntersectionParameter(
        a: LocalPoint,
        b: LocalPoint,
        c: LocalPoint,
        d: LocalPoint
    ): Double? {
        val rx = b.x - a.x
        val ry = b.y - a.y
        val sx = d.x - c.x
        val sy = d.y - c.y
        val denominator = rx * sy - ry * sx
        if (abs(denominator) <= 1e-12) return null
        val qx = c.x - a.x
        val qy = c.y - a.y
        val t = (qx * sy - qy * sx) / denominator
        val u = (qx * ry - qy * rx) / denominator
        return t.coerceIn(0.0, 1.0).takeIf {
            t in -1e-7..1.0000001 && u in -1e-7..1.0000001
        }
    }

    private fun node(index: Int, t: Double, point: LocalPoint, z: Double) = GraphNode(
        id = "wall-profile-$index-${"%.7f".format(java.util.Locale.ROOT, t)}",
        x = point.x,
        y = point.y,
        z = z
    )
}
