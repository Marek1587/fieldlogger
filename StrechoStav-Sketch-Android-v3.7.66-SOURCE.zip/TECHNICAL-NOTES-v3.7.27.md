# Technické poznámky 3.7.27

## STN pôdorys strechy

`StnRoofPlanRenderer` prijíma voliteľný vyriešený `RoofGraph`. PDF exporter mu odovzdáva `RoofQuantityAudit.graph`, preto pôdorys, 3D pohľady a výkaz používajú jednu geometrickú pravdu po príprave a solve fáze.

## Atiky

`RoofPlanAnnotationSolver.atticBands()` vytvára pre každú obvodovú hranu `ATTIC` vnútornú rovnobežku vo vzdialenosti `RoofProject.atticWidthM`. Susedné atikové hrany sa v spoločnom uzle spájajú priesečníkom offsetových priamok. Tým nevznikajú vynechané ani prekrývajúce sa rohy.

## Výškové značky

`RoofPlanAnnotationSolver.faceHeights()` vypočíta geometrické ťažisko vonkajšieho polygonu každej `GraphFace`, odpočíta prípadné vnútorné otvory a výšku vyhodnotí z vyriešenej `RoofPlane`. Výsledok je nezávislý od bitmapového alebo OpenGL rendereru.

## Kóty komína

Pôdorysný obdĺžnik komína dostáva dve kóty v lokálnych osiach objektu. Číselné hodnoty pochádzajú z `RoofObject.widthMm` a `RoofObject.heightMm`, nie zo zväčšenej minimálnej veľkosti značky na výkrese.
