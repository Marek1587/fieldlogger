# StrechoStav Sketch 3.7.45 – profil muriva pod výklenkom

## Skutočná príčina

Vyriešené strešné plochy mali správne rovnice `z = a*x + b*y + c`, ale
`RoofWallProfileSolver` prijal plochu iba vtedy, keď skúmaný bod steny ležal priamo
v jej 2D polygone. Pri odsadení muriva pod presahom sa stena v konkávnom výklenku
dostala tesne mimo všetkých polygonov. Profil preto spadol na konštantnú základnú
výšku a medzi murivom a spodkom strechy ostala medzera.

## Riešenie

Priamo prekrytý bod naďalej používa svoju topologickú `GraphFace`. Ak bod leží v
podpornej zóne presahu mimo plôch, solver nájde najbližšiu hranicu vyriešenej plochy
a analyticky pokračuje jej rovinou do bodu steny. Horná hrana muriva je odvodená ako
`plane.zAt(x, y) - 0,18 m`, s existujúcou nominálnou výškou steny ako bezpečným
minimom pri odkvape.

Táto operácia je iba odvodením prezentačnej geometrie stien. Nemení `RoofGraph`,
strešné uzly, plochy, výmery ani polohu antracitového strešného meshu. Interaktívny
OpenGL model, statické náhľady a PDF naďalej používajú spoločný `RoofMesh`.

## Regresná kontrola

Test vytvára konkávnu strešnú plochu a užší odsadený pôdorys muriva, ktorého obe
bočné steny ležia mimo 2D polygonu strechy. Overuje, že ich koncové výšky sledujú
rovnakú sklonenú rovinu a nezostanú na konštantnej výške.
