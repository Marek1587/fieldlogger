# StrechoStav Sketch 3.7.53 – trapézový vikier s bočnými plochami 75°

## Geometrický model

Trapézový vikier už nie je aproximovaný tromi štvoruholníkmi s rovnakým používateľským sklonom. Je zostavený z troch rovín:

1. centrálnej pultovej strešnej plochy,
2. ľavej bočnej strešnej plochy,
3. pravej bočnej strešnej plochy.

Bočné plochy majú normový geometrický sklon 75° voči horizontále. Keďže zároveň sledujú pozdĺžny smer pultovej plochy, ich priečny gradient sa dopočíta zo vzťahu:

`tan²(75°) = longitudinalSlope² + transverseSlope²`

Takto sa 75° nevynucuje iba v jednom 2D reze, ale platí pre skutočnú 3D rovinu.

## Prienik s hostiteľskou strechou

Všetky konce úžľabných línií sú odvodené z už vyriešenej hostiteľskej roviny `z = a*x + b*y + c`. Centrálna pultová plocha sa ukončí zadnou priamkou na hostiteľskej streche. Každá bočná plocha sa ukončí diagonálnou prienikovou hranou medzi svojim vonkajším bodom a príslušným zadným bodom pultovej plochy.

Tým nevznikajú voľné zadné body ani skrútené plochy. Rovnaké vyriešené `RoofSuperstructureSurface` používa interaktívne 3D, statický Kotlin renderer, PDF, výkaz aj IFC export.

## Hraničné rozmery

Ak je vikier príliš úzky alebo vysoký na požadovanú bočnú plochu, solver zachová tvrdú podmienku 75° a upraví iba výšku čelnej hrany pultovej časti do najväčšej konštrukčne možnej hodnoty. Nevytvorí neplanárny ani prevrátený polygon.

## Regresná kontrola

Test overuje:

- jednu pultovú a dve bočné strešné plochy,
- planárnosť každej plochy,
- sklon oboch bočných rovín 75°,
- presnú polohu štyroch koncov prienikov na hostiteľskej rovine,
- konečné numerické súradnice bez `NaN` a `Infinity`.
