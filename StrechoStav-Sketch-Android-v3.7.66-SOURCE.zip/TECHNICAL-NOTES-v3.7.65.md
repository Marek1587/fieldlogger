# StrechoStav Sketch 3.7.65 – hierarchický solver vnútorných línií

## Jedna interpretácia geometrie

`RoofTopologySolver.solveInternal()` už neskladá výsledok z lokálneho uhlového solvera,
globálneho grid regularizéra a spätnej kópie runtime incidencie. Celý autorský návrh rieši
`HierarchicalInternalLineSolver` v jedinom prechode. Jedinou uhlovou autoritou je uložené
`gridRotationDeg`.

- vnútorné uzly: celočíselná mriežka 25 mm,
- uzly obrysu: párne bunky, teda mriežka 50 mm,
- `RIDGE`: os U alebo V,
- `HIP` a `VALLEY`: presná rovnica `V-U=konštanta` alebo `V+U=konštanta`,
- obvodová hrana: najbližší povolený smer 0/45/90/135°.

Po kvantizácii sa každá tvrdá rovnica znovu overí. Ak neexistuje presné riešenie, solver
vráti pôvodný návrh s `INTERNAL_CONSTRAINTS_INFEASIBLE`; nevytvorí približný kompromis.

## Spoločné fyzické uzly bez straty línií

Konce do vzdialenosti 350 mm sa zoskupujú complete-linkage pravidlom, takže reťaz blízkych
bodov nemôže zlúčiť vzdialené uzly. Všetky ID v skupine dostanú identickú súradnicu, ale
inventár uzlov a hrán, koncové referencie, typy, zámky, `sourceId`, poznámky aj poradie sa
zachovajú. Dočasný runtime graf môže tieto aliasy zlúčiť alebo rozdeliť hranu iba pre
prechod uzavretých plôch; nikdy sa neuloží ako autorská topológia.

Voľný koniec pri vnútri inej konštrukčnej línie dostane virtuálnu point-on-support väzbu.
Tak sa presne stretne s hrebeňom alebo úžľabím bez pridania či odstránenia používateľskej hrany.

## Hierarchia a vystredenie hrebeňa

Vlastník hrebeňa sa vyberá podľa pokrytia jeho úseku v oblastiach `WallFootprintSolver.Context`.
Pri zhode platí stabilná priorita hlavný trakt, samostatné krídlo, výstupok a výklenok.
Smer hrebeňa sleduje dlhšiu os vlastníka a jeho priečna súradnica je presný stred bounding boxu
danej časti. Stred obvodu na 50 mm mriežke vždy leží na 25 mm mriežke vnútorného solvera.

## Obmedzená spolupráca s obrysom

Ak sieť nemožno uzavrieť iba presunom vnútorných bodov, existujúci neuzamknutý bod obrysu
smie prejsť na inú 50 mm bunku najviac o 300 mm. Posun obrysu má v optimalizácii výrazne
vyššiu cenu než posun vnútorného uzla. Kandidát sa odmietne pri prekročení limitu, zmene
orientácie cyklu, samoprieseku alebo zániku krátkej obvodovej hrany.

## Transakčné oprávnenia

`GeometryCorrectionKind.OUTLINE` a `GeometryCorrectionKind.INTERNAL` nahradili nejednoznačný
boolean `allowBoundaryChanges`.

- `OUTLINE` povoľuje iba XY obvodových uzlov.
- `INTERNAL` povoľuje XY vnútorných uzlov a ohraničený XY posun obrysu.
- oba režimy zachovávajú presný usporiadaný inventár a všetky sémantické polia,
- potvrdenie používa `normalizeGrid=false`; solverový náhľad je jediný výsledok,
- polygon, steny, časti a objekty dostanú jednu spoločnú deformáciu,
- chyba synchronizácie, zastaraný kontext alebo porušenie invariantov obnoví celý projekt,
- krok Undo sa pridá až po úspešnom potvrdení.

## Overenie

Lokálna sada obsahuje 206 JUnit testov, 0 zlyhaní. Nové regresie kontrolujú presný spoločný
trojitý uzol, otočenú projektovú mriežku 23°, L-pôdorys, stredovú os traktu, povolenú korekciu
štítových kontaktov, odmietnutie korekcie nad 300 mm, zachovanie poradia/typov a úplný rollback.

3D/PDF reťazec z verzie 3.7.64 nebol zmenený.
