# StrechoStav Sketch 3.7.63 - canonical solved roof surface

## Editor contract

The internal-line correction tool is geometry-only. It preserves every authored edge, edge identifier, endpoint identity, semantic type, lock and note. It may move only finite coordinates of existing unlocked internal nodes. It never deletes, adds, splits or retypes a stored line.

## Runtime incidence

Closed faces still require shared junctions and split intersections. `Roof3DPreparation` therefore builds a disposable incidence graph in memory. This graph may contain derived nodes and split segments, but it is never written back to `RoofProject`. The same prepared graph is shared by 3D, PDF, quantities and IFC.

## Single source of geometric truth

Solved anthracite `GraphFace` surfaces and their planes `z = a*x + b*y + c` are authoritative. The renderer derives from them:

- the visible roof perimeter,
- wall top profiles,
- roof buildup and soffit,
- physical overhang reference,
- rainwater placement.

Each visible boundary segment evaluates both endpoints on the plane of the exact adjacent face owning that boundary edge. A neighbouring face can no longer lift a corner by contributing a different Z value.

## Wall profiles

Wall tops end at the lower face of the solved roof surface. The former secondary projection-height interpretation and the global wall-height floor are not applied to roof-supported wall tops. This keeps projections, recesses and the main tract attached to one canonical surface instead of independently reconstructed layers.

## Regression guarantees

Tests verify exact preservation of authored topology, disposable 3D incidence, solved-plane wall profiles and edge-local roof perimeter heights where adjacent faces have different plane equations.
