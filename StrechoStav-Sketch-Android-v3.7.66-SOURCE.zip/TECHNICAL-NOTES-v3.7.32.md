# StrechoStav Sketch 3.7.32

## Komín

- Komín má spoločnú LOD100 geometriu pre interaktívny 3D pohľad, bitmapové náhľady a PDF.
- Vrchná platňa je vodorovná, hrubá 100 mm a presahuje teleso komína o 50 mm na každej strane.
- Solverom alebo používateľom určená výška komína znamená finálnu výšku po hornú plochu platne; platňa preto nepridáva k zadanej výške ďalších 100 mm.
- V 2D technickom výkrese sa pri komíne zobrazuje STN výšková značka.

## Výškové a sklonové značky

- Výškové značky sa generujú na hranách typu hrebeň, odkvap a atika.
- Výška hrebeňa a odkvapu vychádza zo solved `RoofGraph` uzlov.
- Výška atiky zodpovedá hotovej hornej hrane atiky vrátane parametrickej výšky atiky.
- V ťažisku strešnej plochy zostáva iba značka spádu so sklonom v stupňoch; výšková značka plochy sa tam už nevkladá.

## Overenie

- `:app:testDebugUnitTest`: 111 testov, všetky úspešné.
- `:app:assembleDebug`: úspešné.
