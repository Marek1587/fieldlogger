# Technické poznámky 3.7.31

## Svetelný model

- Smer slnka je uložený v modelových osiach ako normalizovaný vektor smerujúci k juhozápadnému slnku približne o 14:00.
- OpenGL renderer transformuje smer slnka aj zvislú os rovnakou modelovou maticou ako geometriu. Pri otáčaní pohľadu preto ostáva osvetlenie viazané na budovu, nie na displej.
- Fragment shader používa Lambertovu difúznu zložku, mäkký wrapped-diffuse prechod, hemisférické svetlo oblohy a zeme a obmedzený Blinnov odlesk podľa materiálu.
- Antracitová strecha ostáva v tlmenom rozsahu približne 20 %, aby zmena pohľadu nemenila jej materiálový charakter.

## Materiál podbitia

- Hodnota materiálu `6` označuje podbitie a spojitý plášť presahu vrátane čelnej hrany.
- Základná farba podbitia je neutrálna sivá, mierne tmavšia než farba stien.
- Rovnaké rozlíšenie materiálu používa `RoofBitmapRenderer`, preto interaktívny model, PDF a statické náhľady zostávajú vizuálne konzistentné.
