# StrechoStav Sketch 3.7.62 - strict 45-degree plan grid

## Coordinate system

The correction tools share the persisted project-grid axis. Boundary correction quantizes nodes to 50 mm. Internal topology uses a 25 mm grid. The grid is a solver constraint and remains invisible in the editor.

## Allowed directions

- boundary edges: 0, 45, 90 or 135 degrees,
- ridge edges: 0 or 90 degrees,
- hip and valley edges: +45 or -45 degrees,
- other internal construction edges: 0, 45, 90 or 135 degrees.

Angles are measured in the stored project-grid coordinate system, not from the screen, map rotation or device axes.

## Topological junctions

Direction correction is followed by intersection splitting and nearby-node merging. It then runs once more after topology reconstruction. A visual contact is not accepted: incident edges must reference the same `TopologyNode.id`.

## Validation

The correction result is blocked when a relevant node is off its metric grid or an edge is outside its permitted direction family. Card 3 preserves all boundary node coordinates exactly; only card 1 may regularize the footprint.
