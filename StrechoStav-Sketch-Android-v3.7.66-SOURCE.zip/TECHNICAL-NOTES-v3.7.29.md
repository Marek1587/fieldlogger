# Technické poznámky 3.7.29

## Situácia osadenia stavby

- PDF export už nepreberá `RoofProject.zoom` z interaktívneho editora.
- `SituationMapLayout.createForPdf()` vždy používa `PDF_SOURCE_ZOOM = 20`.
- Zdrojové dlaždice, výpočet Web Mercator súradníc aj cesta do lokálnej cache preto používajú úroveň 20.
- Digitálne prispôsobenie výrezu nemení zdrojový mapový zoom; slúži iba na bezpečné umiestnenie celého obrysu do formátu A4.
- Poloha výrezu sa naďalej odvodzuje iba od geometrie polygonu, nie od posunu mapy v editore.

## Overenie

- Unit test kontroluje nemenný zdrojový zoom 20 pre PDF situáciu.
- Existujúce testy úplného zobrazenia obrysu a deterministického výrezu zostávajú zachované.
