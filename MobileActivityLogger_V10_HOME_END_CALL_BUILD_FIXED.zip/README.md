# Mobile Activity Logger V10 - Home End Call Build Fixed

Fixes Kotlin build error from V9:
- removed unresolved isLauncherPackage call
- uses launcherPackages.contains(pkg) directly

Keeps:
- home screen after active call ends the call immediately
- fallback grace about 12 seconds
- battery notification spam filter
- call grouping
- one CALL_NOTE after call
- visible version in app status

Version:
- 2.8-home-end-build-fixed
- code 11
