# FieldLogger Android

Minimal Android field logger.

## Features

- GPS event log to CSV
- manual notes
- camera capture
- compressed photo
- share CSV
