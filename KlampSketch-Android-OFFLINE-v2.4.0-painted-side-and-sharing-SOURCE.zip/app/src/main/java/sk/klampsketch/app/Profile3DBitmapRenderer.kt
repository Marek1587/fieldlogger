package sk.klampsketch.app

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

object Profile3DBitmapRenderer {
    fun render(
        width: Int,
        height: Int,
        frontPoints: List<ProfilePoint>,
        backPoints: List<ProfilePoint>?,
        profileLengthMm: Float,
        ral: String,
        material: String,
        paintedTopSide: Boolean = true
    ): Bitmap {
        val outputWidth = width.coerceAtLeast(2)
        val outputHeight = height.coerceAtLeast(2)
        val supersample = if (max(outputWidth, outputHeight) <= 900) 2 else 1
        val renderWidth = outputWidth * supersample
        val renderHeight = outputHeight * supersample
        val mesh = Profile3DMeshBuilder.build(frontPoints, backPoints, profileLengthMm)
        val pixels = IntArray(renderWidth * renderHeight)
        val depth = FloatArray(renderWidth * renderHeight) { Float.NEGATIVE_INFINITY }
        fillBackground(pixels, renderWidth, renderHeight)

        if (mesh.triangleVertices.isNotEmpty()) {
            val transform = ProjectionTransform.from(
                mesh,
                renderWidth,
                renderHeight,
                yawDegrees = -38f,
                pitchDegrees = 24f
            )
            val baseColor = ProfileMaterialPalette.androidColor(ral, material)
            val undersideColor = ProfileMaterialPalette.androidUndersideColor()
            rasterizeTriangles(
                pixels,
                depth,
                renderWidth,
                renderHeight,
                mesh,
                transform,
                baseColor,
                undersideColor,
                paintedTopSide
            )
            rasterizeEdges(
                pixels,
                depth,
                renderWidth,
                renderHeight,
                mesh,
                transform,
                supersample
            )
        }

        val highResolution = Bitmap.createBitmap(
            pixels,
            renderWidth,
            renderHeight,
            Bitmap.Config.ARGB_8888
        )
        if (supersample == 1) return highResolution
        return Bitmap.createScaledBitmap(
            highResolution,
            outputWidth,
            outputHeight,
            true
        ).also { highResolution.recycle() }
    }

    fun render(
        width: Int,
        height: Int,
        points: List<ProfilePoint>,
        profileLengthMm: Float,
        ral: String,
        material: String,
        paintedTopSide: Boolean = true
    ): Bitmap = render(
        width,
        height,
        points,
        null,
        profileLengthMm,
        ral,
        material,
        paintedTopSide
    )

    private fun fillBackground(pixels: IntArray, width: Int, height: Int) {
        val top = intArrayOf(247, 250, 252)
        val bottom = intArrayOf(232, 239, 243)
        for (y in 0 until height) {
            val t = if (height <= 1) 0f else y.toFloat() / (height - 1).toFloat()
            val r = lerp(top[0], bottom[0], t)
            val g = lerp(top[1], bottom[1], t)
            val b = lerp(top[2], bottom[2], t)
            val color = Color.rgb(r, g, b)
            java.util.Arrays.fill(pixels, y * width, (y + 1) * width, color)
        }
    }

    private fun rasterizeTriangles(
        pixels: IntArray,
        depth: FloatArray,
        width: Int,
        height: Int,
        mesh: Profile3DMesh,
        transform: ProjectionTransform,
        paintedColor: Int,
        undersideColor: Int,
        paintedTopSide: Boolean
    ) {
        var triangleOffset = 0
        while (triangleOffset < mesh.triangleVertices.size) {
            val a = transform.project(mesh.triangleVertices, triangleOffset)
            val b = transform.project(mesh.triangleVertices, triangleOffset + 3)
            val c = transform.project(mesh.triangleVertices, triangleOffset + 6)
            val normal = transform.rotateNormal(
                mesh.triangleNormals[triangleOffset],
                mesh.triangleNormals[triangleOffset + 1],
                mesh.triangleNormals[triangleOffset + 2]
            )
            val cameraSeesTopSide = normal.z >= 0f
            val baseColor = if (cameraSeesTopSide == paintedTopSide) {
                paintedColor
            } else {
                undersideColor
            }
            val color = shadedColor(baseColor, normal)
            rasterizeTriangle(pixels, depth, width, height, a, b, c, color)
            triangleOffset += 9
        }
    }

    private fun rasterizeTriangle(
        pixels: IntArray,
        depth: FloatArray,
        width: Int,
        height: Int,
        a: ProjectedVertex,
        b: ProjectedVertex,
        c: ProjectedVertex,
        color: Int
    ) {
        val area = edge(a.x, a.y, b.x, b.y, c.x, c.y)
        if (abs(area) < 0.000001f) return

        val minX = floor(min(a.x, min(b.x, c.x))).toInt().coerceIn(0, width - 1)
        val maxX = ceil(max(a.x, max(b.x, c.x))).toInt().coerceIn(0, width - 1)
        val minY = floor(min(a.y, min(b.y, c.y))).toInt().coerceIn(0, height - 1)
        val maxY = ceil(max(a.y, max(b.y, c.y))).toInt().coerceIn(0, height - 1)
        val inverseArea = 1f / area

        for (y in minY..maxY) {
            val sampleY = y + 0.5f
            for (x in minX..maxX) {
                val sampleX = x + 0.5f
                val w0 = edge(b.x, b.y, c.x, c.y, sampleX, sampleY) * inverseArea
                val w1 = edge(c.x, c.y, a.x, a.y, sampleX, sampleY) * inverseArea
                val w2 = 1f - w0 - w1
                if (w0 < -0.0001f || w1 < -0.0001f || w2 < -0.0001f) continue
                val z = w0 * a.z + w1 * b.z + w2 * c.z
                val index = y * width + x
                if (z > depth[index]) {
                    depth[index] = z
                    pixels[index] = color
                }
            }
        }
    }

    private fun rasterizeEdges(
        pixels: IntArray,
        depth: FloatArray,
        width: Int,
        height: Int,
        mesh: Profile3DMesh,
        transform: ProjectionTransform,
        supersample: Int
    ) {
        val edgeColor = Color.rgb(24, 38, 48)
        val radius = max(1, supersample)
        var offset = 0
        while (offset < mesh.edgeVertices.size) {
            val start = transform.project(mesh.edgeVertices, offset)
            val end = transform.project(mesh.edgeVertices, offset + 3)
            val dx = end.x - start.x
            val dy = end.y - start.y
            val steps = max(1, max(abs(dx), abs(dy)).roundToInt())
            for (step in 0..steps) {
                val t = step.toFloat() / steps.toFloat()
                val x = start.x + dx * t
                val y = start.y + dy * t
                val z = start.z + (end.z - start.z) * t
                val centerX = x.roundToInt()
                val centerY = y.roundToInt()
                for (py in centerY - radius..centerY + radius) {
                    if (py !in 0 until height) continue
                    for (px in centerX - radius..centerX + radius) {
                        if (px !in 0 until width) continue
                        val index = py * width + px
                        if (z >= depth[index] - 0.025f) {
                            pixels[index] = edgeColor
                            depth[index] = max(depth[index], z)
                        }
                    }
                }
            }
            offset += 6
        }
    }

    private fun shadedColor(baseColor: Int, sourceNormal: Vec3): Int {
        var normal = normalized(sourceNormal)
        if (normal.z < 0f) normal = Vec3(-normal.x, -normal.y, -normal.z)
        val light = normalized(Vec3(-0.38f, 0.72f, 0.58f))
        val view = Vec3(0f, 0f, 1f)
        val half = normalized(Vec3(light.x + view.x, light.y + view.y, light.z + view.z))
        val diffuse = max(0f, dot(normal, light))
        val specular = max(0f, dot(normal, half)).toDouble().pow(36.0).toFloat()
        val fresnel = (1f - max(0f, dot(normal, view))).toDouble().pow(3.0).toFloat()
        val factor = 0.46f + 0.56f * diffuse + 0.12f * fresnel
        val highlight = 78f * specular
        return Color.rgb(
            (Color.red(baseColor) * factor + highlight).roundToInt().coerceIn(0, 255),
            (Color.green(baseColor) * factor + highlight).roundToInt().coerceIn(0, 255),
            (Color.blue(baseColor) * factor + highlight).roundToInt().coerceIn(0, 255)
        )
    }

    private fun normalized(value: Vec3): Vec3 {
        val length = sqrt(value.x * value.x + value.y * value.y + value.z * value.z)
        return if (length < 0.000001f) Vec3(0f, 0f, 1f) else Vec3(
            value.x / length,
            value.y / length,
            value.z / length
        )
    }

    private fun dot(a: Vec3, b: Vec3): Float = a.x * b.x + a.y * b.y + a.z * b.z

    private fun edge(
        ax: Float,
        ay: Float,
        bx: Float,
        by: Float,
        px: Float,
        py: Float
    ): Float = (px - ax) * (by - ay) - (py - ay) * (bx - ax)

    private fun lerp(start: Int, end: Int, t: Float): Int =
        (start + (end - start) * t).roundToInt().coerceIn(0, 255)

    private data class ProjectedVertex(val x: Float, val y: Float, val z: Float)

    private class ProjectionTransform(
        private val yawCos: Float,
        private val yawSin: Float,
        private val pitchCos: Float,
        private val pitchSin: Float,
        private val scale: Float,
        private val centerX: Float,
        private val centerY: Float
    ) {
        fun project(values: FloatArray, offset: Int): ProjectedVertex {
            val rotated = rotate(values[offset], values[offset + 1], values[offset + 2])
            return ProjectedVertex(
                centerX + rotated.x * scale,
                centerY - rotated.y * scale,
                rotated.z
            )
        }

        fun rotateNormal(x: Float, y: Float, z: Float): Vec3 = rotate(x, y, z)

        private fun rotate(x: Float, y: Float, z: Float): Vec3 {
            val yawX = yawCos * x + yawSin * z
            val yawZ = -yawSin * x + yawCos * z
            val pitchY = pitchCos * y - pitchSin * yawZ
            val pitchZ = pitchSin * y + pitchCos * yawZ
            return Vec3(yawX, pitchY, pitchZ)
        }

        companion object {
            fun from(
                mesh: Profile3DMesh,
                width: Int,
                height: Int,
                yawDegrees: Float,
                pitchDegrees: Float
            ): ProjectionTransform {
                val yaw = Math.toRadians(yawDegrees.toDouble())
                val pitch = Math.toRadians(pitchDegrees.toDouble())
                val yawCos = cos(yaw).toFloat()
                val yawSin = sin(yaw).toFloat()
                val pitchCos = cos(pitch).toFloat()
                val pitchSin = sin(pitch).toFloat()

                fun rotate(x: Float, y: Float, z: Float): Vec3 {
                    val yawX = yawCos * x + yawSin * z
                    val yawZ = -yawSin * x + yawCos * z
                    return Vec3(
                        yawX,
                        pitchCos * y - pitchSin * yawZ,
                        pitchSin * y + pitchCos * yawZ
                    )
                }

                var minX = Float.POSITIVE_INFINITY
                var maxX = Float.NEGATIVE_INFINITY
                var minY = Float.POSITIVE_INFINITY
                var maxY = Float.NEGATIVE_INFINITY
                var offset = 0
                while (offset < mesh.triangleVertices.size) {
                    val point = rotate(
                        mesh.triangleVertices[offset],
                        mesh.triangleVertices[offset + 1],
                        mesh.triangleVertices[offset + 2]
                    )
                    minX = min(minX, point.x)
                    maxX = max(maxX, point.x)
                    minY = min(minY, point.y)
                    maxY = max(maxY, point.y)
                    offset += 3
                }
                val spanX = max(0.001f, maxX - minX)
                val spanY = max(0.001f, maxY - minY)
                val scale = min(width * 0.80f / spanX, height * 0.72f / spanY)
                val projectedCenterX = (minX + maxX) / 2f
                val projectedCenterY = (minY + maxY) / 2f
                return ProjectionTransform(
                    yawCos,
                    yawSin,
                    pitchCos,
                    pitchSin,
                    scale,
                    width / 2f - projectedCenterX * scale,
                    height * 0.50f + projectedCenterY * scale
                )
            }
        }
    }
}
