"""Build the small, merchant-independent receipt line classifier used by Android.

The model is intentionally limited to classifying OCR lines. It never generates text
or financial values. Product names are selected from OCR candidates and the local
user-corrected catalogue by deterministic Kotlin code.
"""

from __future__ import annotations

import json
import pathlib
import sys

import flatbuffers
import numpy as np
import tflite


ROOT = pathlib.Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
MODEL_PATH = ASSETS / "receipt_line_classifier.tflite"
MANIFEST_PATH = ASSETS / "receipt_line_classifier.json"

FEATURES = [
    "center_x", "center_y", "width", "height", "letter_ratio", "digit_ratio",
    "amount_count", "has_quantity", "has_ean", "has_total_keyword",
    "has_tax_keyword", "has_payment_keyword", "has_registration_keyword",
    "has_date", "right_aligned", "upper_ratio", "word_count", "price_only",
    "has_item_identifier", "has_legal_suffix", "has_address", "has_currency",
    "is_header_region", "is_items_region",
]

LABELS = [
    "OTHER", "HEADER", "PRODUCT_NAME", "QUANTITY", "ITEM_TOTAL",
    "ITEM_IDENTIFIER", "TOTAL_LABEL", "TAX", "PAYMENT",
]


def clipped_normal(rng: np.random.Generator, mean: float, sd: float) -> float:
    return float(np.clip(rng.normal(mean, sd), 0.0, 1.0))


def sample(role: int, rng: np.random.Generator) -> np.ndarray:
    x = np.zeros(len(FEATURES), dtype=np.float32)
    # Generic line geometry and text composition.
    x[0] = clipped_normal(rng, 0.48, 0.16)
    x[1] = clipped_normal(rng, 0.50, 0.25)
    x[2] = clipped_normal(rng, 0.55, 0.18)
    x[3] = clipped_normal(rng, 0.035, 0.012)
    x[4] = clipped_normal(rng, 0.62, 0.17)
    x[5] = clipped_normal(rng, 0.24, 0.15)
    x[15] = clipped_normal(rng, 0.58, 0.25)
    x[16] = clipped_normal(rng, 0.35, 0.18)
    x[22] = 1.0 if x[1] < 0.28 else 0.0
    x[23] = 1.0 if 0.20 <= x[1] <= 0.82 else 0.0

    if role == 0:  # OTHER
        if rng.random() < 0.25:
            x[20] = 1.0
        if rng.random() < 0.18:
            x[13] = 1.0
    elif role == 1:  # HEADER
        x[1] = clipped_normal(rng, 0.13, 0.08)
        x[4] = clipped_normal(rng, 0.78, 0.10)
        x[5] = clipped_normal(rng, 0.10, 0.08)
        x[15] = clipped_normal(rng, 0.82, 0.13)
        x[19] = 1.0 if rng.random() < 0.55 else 0.0
        x[20] = 1.0 if rng.random() < 0.45 else 0.0
        x[22] = 1.0
        x[23] = 0.0
    elif role == 2:  # PRODUCT_NAME
        x[0] = clipped_normal(rng, 0.36, 0.12)
        x[1] = clipped_normal(rng, 0.49, 0.17)
        x[2] = clipped_normal(rng, 0.62, 0.16)
        x[4] = clipped_normal(rng, 0.83, 0.08)
        x[5] = clipped_normal(rng, 0.07, 0.06)
        x[16] = clipped_normal(rng, 0.48, 0.18)
        x[23] = 1.0
    elif role == 3:  # QUANTITY / UNIT PRICE
        x[0] = clipped_normal(rng, 0.34, 0.11)
        x[1] = clipped_normal(rng, 0.52, 0.17)
        x[4] = clipped_normal(rng, 0.30, 0.12)
        x[5] = clipped_normal(rng, 0.55, 0.14)
        x[6] = clipped_normal(rng, 0.28, 0.10)
        x[7] = 1.0
        x[23] = 1.0
    elif role == 4:  # ITEM TOTAL in the right column
        x[0] = clipped_normal(rng, 0.87, 0.05)
        x[1] = clipped_normal(rng, 0.52, 0.17)
        x[2] = clipped_normal(rng, 0.20, 0.07)
        x[4] = clipped_normal(rng, 0.08, 0.06)
        x[5] = clipped_normal(rng, 0.82, 0.09)
        x[6] = clipped_normal(rng, 0.34, 0.07)
        x[14] = 1.0
        x[17] = 1.0
        x[23] = 1.0
    elif role == 5:  # EAN / article identifier
        x[0] = clipped_normal(rng, 0.39, 0.14)
        x[1] = clipped_normal(rng, 0.52, 0.17)
        x[4] = clipped_normal(rng, 0.22, 0.11)
        x[5] = clipped_normal(rng, 0.69, 0.11)
        x[8] = 1.0 if rng.random() < 0.75 else 0.0
        x[18] = 1.0
        x[23] = 1.0
    elif role == 6:  # GRAND TOTAL / subtotal label
        x[1] = clipped_normal(rng, 0.84, 0.08)
        x[4] = clipped_normal(rng, 0.56, 0.14)
        x[5] = clipped_normal(rng, 0.27, 0.16)
        x[9] = 1.0
        x[21] = 1.0 if rng.random() < 0.65 else 0.0
        x[23] = 0.0
    elif role == 7:  # TAX table / VAT line
        x[1] = clipped_normal(rng, 0.89, 0.06)
        x[5] = clipped_normal(rng, 0.46, 0.17)
        x[6] = clipped_normal(rng, 0.42, 0.16)
        x[10] = 1.0
        x[23] = 0.0
    elif role == 8:  # PAYMENT line
        x[1] = clipped_normal(rng, 0.82, 0.08)
        x[4] = clipped_normal(rng, 0.55, 0.15)
        x[5] = clipped_normal(rng, 0.28, 0.16)
        x[11] = 1.0
        x[21] = 1.0 if rng.random() < 0.70 else 0.0
        x[23] = 0.0

    # Small feature noise makes the model less equivalent to exact keyword rules.
    x += rng.normal(0.0, 0.018, len(FEATURES)).astype(np.float32)
    return np.clip(x, 0.0, 1.0)


def train() -> tuple[np.ndarray, np.ndarray, float]:
    rng = np.random.default_rng(5402)
    samples_per_role = 2600
    x = np.vstack([sample(role, rng) for role in range(len(LABELS)) for _ in range(samples_per_role)])
    y = np.repeat(np.arange(len(LABELS)), samples_per_role)
    order = rng.permutation(len(y))
    x, y = x[order], y[order]
    split = int(len(y) * 0.88)
    train_x, test_x = x[:split], x[split:]
    train_y, test_y = y[:split], y[split:]

    weights = rng.normal(0.0, 0.03, (len(LABELS), len(FEATURES))).astype(np.float32)
    bias = np.zeros(len(LABELS), dtype=np.float32)
    eye = np.eye(len(LABELS), dtype=np.float32)
    for epoch in range(520):
        batch = rng.integers(0, len(train_y), 1024)
        bx, by = train_x[batch], train_y[batch]
        logits = bx @ weights.T + bias
        logits -= logits.max(axis=1, keepdims=True)
        probabilities = np.exp(logits)
        probabilities /= probabilities.sum(axis=1, keepdims=True)
        delta = (probabilities - eye[by]) / len(batch)
        rate = 0.34 * (0.996 ** epoch)
        weights -= rate * (delta.T @ bx + 0.0005 * weights)
        bias -= rate * delta.sum(axis=0)

    prediction = np.argmax(test_x @ weights.T + bias, axis=1)
    accuracy = float(np.mean(prediction == test_y))
    return weights.astype(np.float32), bias.astype(np.float32), accuracy


def int_vector(builder: flatbuffers.Builder, values: list[int]) -> int:
    builder.StartVector(4, len(values), 4)
    for value in reversed(values):
        builder.PrependInt32(value)
    return builder.EndVector()


def offset_vector(builder: flatbuffers.Builder, values: list[int], starter) -> int:
    starter(builder, len(values))
    for value in reversed(values):
        builder.PrependUOffsetTRelative(value)
    return builder.EndVector()


def byte_vector(builder: flatbuffers.Builder, value: bytes) -> int:
    return builder.CreateByteVector(value)


def tensor(builder, name, shape, buffer_index):
    shape_vector = int_vector(builder, shape)
    name_offset = builder.CreateString(name)
    tflite.TensorStart(builder)
    tflite.TensorAddShape(builder, shape_vector)
    tflite.TensorAddType(builder, tflite.TensorType.FLOAT32)
    tflite.TensorAddBuffer(builder, buffer_index)
    tflite.TensorAddName(builder, name_offset)
    return tflite.TensorEnd(builder)


def build_model(weights: np.ndarray, bias: np.ndarray) -> bytes:
    builder = flatbuffers.Builder(64 * 1024)

    empty_data = byte_vector(builder, b"")
    tflite.BufferStart(builder); tflite.BufferAddData(builder, empty_data); empty_buffer = tflite.BufferEnd(builder)
    weights_data = byte_vector(builder, weights.tobytes())
    tflite.BufferStart(builder); tflite.BufferAddData(builder, weights_data); weights_buffer = tflite.BufferEnd(builder)
    bias_data = byte_vector(builder, bias.tobytes())
    tflite.BufferStart(builder); tflite.BufferAddData(builder, bias_data); bias_buffer = tflite.BufferEnd(builder)

    tensors = [
        tensor(builder, "features", [1, len(FEATURES)], 0),
        tensor(builder, "weights", [len(LABELS), len(FEATURES)], 1),
        tensor(builder, "bias", [len(LABELS)], 2),
        tensor(builder, "logits", [1, len(LABELS)], 0),
        tensor(builder, "probabilities", [1, len(LABELS)], 0),
    ]

    fc_inputs = int_vector(builder, [0, 1, 2])
    fc_outputs = int_vector(builder, [3])
    tflite.FullyConnectedOptionsStart(builder)
    tflite.FullyConnectedOptionsAddFusedActivationFunction(builder, tflite.ActivationFunctionType.NONE)
    tflite.FullyConnectedOptionsAddWeightsFormat(builder, tflite.FullyConnectedOptionsWeightsFormat.DEFAULT)
    fc_options = tflite.FullyConnectedOptionsEnd(builder)
    tflite.OperatorStart(builder)
    tflite.OperatorAddOpcodeIndex(builder, 0)
    tflite.OperatorAddInputs(builder, fc_inputs)
    tflite.OperatorAddOutputs(builder, fc_outputs)
    tflite.OperatorAddBuiltinOptionsType(builder, tflite.BuiltinOptions.FullyConnectedOptions)
    tflite.OperatorAddBuiltinOptions(builder, fc_options)
    fc_operator = tflite.OperatorEnd(builder)

    softmax_inputs = int_vector(builder, [3])
    softmax_outputs = int_vector(builder, [4])
    tflite.SoftmaxOptionsStart(builder)
    tflite.SoftmaxOptionsAddBeta(builder, 1.0)
    softmax_options = tflite.SoftmaxOptionsEnd(builder)
    tflite.OperatorStart(builder)
    tflite.OperatorAddOpcodeIndex(builder, 1)
    tflite.OperatorAddInputs(builder, softmax_inputs)
    tflite.OperatorAddOutputs(builder, softmax_outputs)
    tflite.OperatorAddBuiltinOptionsType(builder, tflite.BuiltinOptions.SoftmaxOptions)
    tflite.OperatorAddBuiltinOptions(builder, softmax_options)
    softmax_operator = tflite.OperatorEnd(builder)

    tensors_vector = offset_vector(builder, tensors, tflite.SubGraphStartTensorsVector)
    inputs_vector = int_vector(builder, [0])
    outputs_vector = int_vector(builder, [4])
    operators_vector = offset_vector(builder, [fc_operator, softmax_operator], tflite.SubGraphStartOperatorsVector)
    graph_name = builder.CreateString("receipt_line_classifier")
    tflite.SubGraphStart(builder)
    tflite.SubGraphAddTensors(builder, tensors_vector)
    tflite.SubGraphAddInputs(builder, inputs_vector)
    tflite.SubGraphAddOutputs(builder, outputs_vector)
    tflite.SubGraphAddOperators(builder, operators_vector)
    tflite.SubGraphAddName(builder, graph_name)
    subgraph = tflite.SubGraphEnd(builder)

    tflite.OperatorCodeStart(builder)
    tflite.OperatorCodeAddBuiltinCode(builder, tflite.BuiltinOperator.FULLY_CONNECTED)
    tflite.OperatorCodeAddDeprecatedBuiltinCode(builder, tflite.BuiltinOperator.FULLY_CONNECTED)
    tflite.OperatorCodeAddVersion(builder, 1)
    fc_code = tflite.OperatorCodeEnd(builder)
    tflite.OperatorCodeStart(builder)
    tflite.OperatorCodeAddBuiltinCode(builder, tflite.BuiltinOperator.SOFTMAX)
    tflite.OperatorCodeAddDeprecatedBuiltinCode(builder, tflite.BuiltinOperator.SOFTMAX)
    tflite.OperatorCodeAddVersion(builder, 1)
    softmax_code = tflite.OperatorCodeEnd(builder)

    opcodes_vector = offset_vector(builder, [fc_code, softmax_code], tflite.ModelStartOperatorCodesVector)
    subgraphs_vector = offset_vector(builder, [subgraph], tflite.ModelStartSubgraphsVector)
    buffers_vector = offset_vector(builder, [empty_buffer, weights_buffer, bias_buffer], tflite.ModelStartBuffersVector)
    description = builder.CreateString("Doklady receipt line role classifier v1")
    tflite.ModelStart(builder)
    tflite.ModelAddVersion(builder, 3)
    tflite.ModelAddOperatorCodes(builder, opcodes_vector)
    tflite.ModelAddSubgraphs(builder, subgraphs_vector)
    tflite.ModelAddDescription(builder, description)
    tflite.ModelAddBuffers(builder, buffers_vector)
    model = tflite.ModelEnd(builder)
    builder.Finish(model, file_identifier=b"TFL3")
    return bytes(builder.Output())


def main() -> None:
    weights, bias, accuracy = train()
    model_bytes = build_model(weights, bias)
    parsed = tflite.Model.GetRootAsModel(model_bytes, 0)
    if parsed.SubgraphsLength() != 1 or parsed.OperatorCodesLength() != 2:
        raise RuntimeError("Generated LiteRT model failed structural validation")
    ASSETS.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.write_bytes(model_bytes)
    MANIFEST_PATH.write_text(json.dumps({
        "model": "receipt-line-role-v1",
        "runtime": "LiteRT",
        "features": FEATURES,
        "labels": LABELS,
        "syntheticValidationAccuracy": round(accuracy, 6),
        "safety": "classification-only; never generates text or monetary values",
    }, indent=2), encoding="utf-8")
    print(f"model={MODEL_PATH} bytes={len(model_bytes)} validation_accuracy={accuracy:.4f}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"model generation failed: {exc}", file=sys.stderr)
        raise
