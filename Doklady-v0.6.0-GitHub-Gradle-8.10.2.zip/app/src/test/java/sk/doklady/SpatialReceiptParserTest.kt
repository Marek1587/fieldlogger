package sk.doklady

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import sk.doklady.processing.GenericDocumentParser
import sk.doklady.processing.OcrLine
import sk.doklady.processing.ReceiptReconciler

class SpatialReceiptParserTest {
    @Test
    fun `detached Hornbach price column is associated by geometry and arithmetic`() {
        val lines = mutableListOf(
            line("HORNBACH - Baumarkt SK spol. s r.o.", 80, 60, 720, 90),
            line("IČO: 35838949", 80, 100, 420, 125),
            line("27-08-2026 16:53:34 Č.bloku: 5402", 80, 130, 680, 155),
            line("PPRCT HOT S3.2 SDR7, 1 Kus", 80, 320, 650, 345),
            line("ZÁVITOVÁ TYČ M12 ZN", 80, 370, 600, 395),
            line("3 Kus * 1,85", 100, 400, 430, 425),
            line("Č. art./EAN 8596642001144", 100, 430, 570, 455),
            line("ZÁVITOVÁ TYČ M14 ZN 1 Kus", 80, 470, 650, 495),
            line("Plochá spojka pozink", 80, 520, 590, 545),
            line("12 Kus * 2,07", 100, 550, 440, 575),
            line("MATICA PRESNA 6HR H", 80, 600, 570, 625),
            line("0,172 kg * 9,17", 100, 630, 460, 655),
            line("MATICA PREDLZOVACIA", 80, 680, 580, 705),
            line("0,67 kg * 12,81", 100, 710, 470, 735),
            line("Multifunkčný nástroj", 80, 760, 570, 785),
            line("1 Kus * 16,99", 100, 790, 450, 815),
            OcrLine("Nafukovacie kol eso", 80, 840, 590, 865, alternatives = listOf("Nafukovacie koleso")),
            line("5 Kus * 16,39", 100, 870, 460, 895),
            line("Kovový vozík", 80, 920, 560, 945),
            line("2 ks, 1 Bal", 100, 950, 420, 975),
            line("MEDZISÚČET", 80, 1030, 460, 1055),
            line("NA ÚHRADU EUR", 80, 1060, 500, 1085),
            line("KARTA", 80, 1090, 300, 1115),
            line("Základ", 350, 1120, 520, 1145),
            line("148,37", 380, 1148, 560, 1173),
            line("148,37", 380, 1176, 560, 1201),
        )
        val itemTotals = listOf(300L, 555L, 302L, 2484L, 158L, 858L, 1699L, 8195L, 3699L)
        itemTotals.forEachIndexed { index, cents ->
            lines += line(money(cents), 820, 1205 + index * 22, 960, 1225 + index * 22)
        }
        repeat(3) { index -> lines += line("182,50", 820, 1410 + index * 22, 960, 1430 + index * 22) }
        lines += line("DPH", 650, 1480, 760, 1502)
        lines += line("34,13", 820, 1505, 960, 1527)
        lines += line("34,13", 820, 1530, 960, 1552)

        val parsed = GenericDocumentParser().parse(lines)
        val reconciliation = ReceiptReconciler.evaluate(parsed)

        assertEquals(9, parsed.items.size)
        assertEquals(18_250L, parsed.grossTotalCents)
        assertEquals(14_837L, parsed.netTotalCents)
        assertEquals(3_413L, parsed.vatTotalCents)
        assertEquals(18_250L, reconciliation.itemSumCents)
        assertTrue(reconciliation.financiallyConsistent)
        assertEquals("PPRCT HOT S3.2 SDR7", parsed.items.first().name)
        assertTrue(parsed.items.any { it.ean == "8596642001144" })
        assertTrue(parsed.items.any { it.name == "Nafukovacie koleso" })
        assertEquals("SPATIAL_CONSTRAINTS", parsed.diagnostics.strategy)
        assertEquals(9, parsed.diagnostics.spatialAssociations)
    }

    @Test
    fun `merchant independent spatial parser handles OBI style rows`() {
        val lines = listOf(
            line("OBI Slovensko s.r.o.", 60, 40, 650, 70),
            line("01.09.2026 Doklad: 987654", 60, 80, 600, 110),
            line("Skrutka univerzálna", 70, 260, 590, 290),
            line("4 ks x 0,50", 90, 295, 410, 325),
            line("Hmoždinka nylonová", 70, 350, 590, 380),
            line("2 ks x 1,25", 90, 385, 410, 415),
            line("NA ÚHRADU EUR", 70, 520, 500, 550),
            line("2,00", 820, 600, 950, 625),
            line("2,50", 820, 630, 950, 655),
            line("4,50", 820, 680, 950, 705),
            line("4,50", 820, 710, 950, 735),
        )

        val parsed = GenericDocumentParser().parse(lines)

        assertEquals("OBI", parsed.supplier)
        assertEquals(2, parsed.items.size)
        assertEquals(450L, parsed.grossTotalCents)
        assertTrue(ReceiptReconciler.evaluate(parsed).financiallyConsistent)
    }

    private fun line(text: String, left: Int, top: Int, right: Int, bottom: Int) = OcrLine(text, left, top, right, bottom)
    private fun money(cents: Long) = "%d,%02d".format(cents / 100, cents % 100)
}
