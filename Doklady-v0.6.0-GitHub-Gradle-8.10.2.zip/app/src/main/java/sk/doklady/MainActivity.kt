package sk.doklady

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Build
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import sk.doklady.ui.CameraScanner
import sk.doklady.ui.DetailScreen
import sk.doklady.ui.DiagnosticsScreen
import sk.doklady.ui.HomeScreen
import sk.doklady.ui.GalleryScreen
import sk.doklady.ui.ExportScreen

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = MaterialTheme.colorScheme.copy(
                primary = Color(0xFF1E5B45), secondary = Color(0xFFE5A11A),
                background = Color(0xFFF6F7F2), surface = Color(0xFFF6F7F2),
            )) { DokladyApp(viewModel) }
        }
    }
}

private enum class AppScreen { HOME, CAMERA, DETAIL, GALLERY, EXPORT, DIAGNOSTICS }

@Composable
private fun DokladyApp(viewModel: MainViewModel) {
    val home by viewModel.uiState.collectAsStateWithLifecycle()
    val detail by viewModel.detailState.collectAsStateWithLifecycle()
    val diagnostics by viewModel.diagnosticsState.collectAsStateWithLifecycle()
    val gallery by viewModel.galleryState.collectAsStateWithLifecycle()
    val export by viewModel.exportState.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    val context = viewModel.getApplication<Application>()
    val activityContext = LocalContext.current
    var cameraPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        cameraPermission = granted
        if (granted) screen = AppScreen.CAMERA
    }
    val systemPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(100)) { uris ->
        viewModel.importGallery(uris) { screen = AppScreen.HOME }
    }
    val galleryPermissions = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
        Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES)
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    val galleryPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) {
            viewModel.loadAlbums()
            screen = AppScreen.GALLERY
        } else {
            systemPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }
    val saveExportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    ) { uri -> uri?.let(viewModel::saveExportTo) }

    LaunchedEffect(home.message) {
        home.message?.let { snackbar.showSnackbar(it); viewModel.dismissMessage() }
    }
    BackHandler(screen != AppScreen.HOME) {
        if (screen == AppScreen.GALLERY && viewModel.galleryBack()) return@BackHandler
        screen = AppScreen.HOME
        viewModel.selectDocument(null)
    }

    if (screen == AppScreen.CAMERA && cameraPermission) {
        CameraScanner(
            onBack = { screen = AppScreen.HOME },
            onCapture = { capture, executor, snapshot ->
                viewModel.capture(capture, executor, snapshot) { screen = AppScreen.HOME }
            },
        )
        return
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbar) }) { padding ->
        androidx.compose.foundation.layout.Box(Modifier.padding(padding)) {
            when (screen) {
                AppScreen.HOME -> HomeScreen(
                    state = home,
                    onCamera = {
                        if (cameraPermission) screen = AppScreen.CAMERA
                        else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                    },
                    onGallery = {
                        if (galleryPermissions.any { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }) {
                            viewModel.loadAlbums()
                            screen = AppScreen.GALLERY
                        } else galleryPermissionLauncher.launch(galleryPermissions)
                    },
                    onSystemPicker = { systemPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    onDocument = { viewModel.selectDocument(it); screen = AppScreen.DETAIL },
                    onExport = { screen = AppScreen.EXPORT },
                    onDiagnostics = { screen = AppScreen.DIAGNOSTICS },
                    onRetry = viewModel::retry,
                )
                AppScreen.DETAIL -> DetailScreen(
                    detail,
                    { screen = AppScreen.HOME; viewModel.selectDocument(null) },
                     viewModel::retry,
                     viewModel::saveDocumentEdit,
                     viewModel::saveItemName,
                 )
                AppScreen.DIAGNOSTICS -> DiagnosticsScreen(diagnostics) { screen = AppScreen.HOME }
                AppScreen.EXPORT -> ExportScreen(
                    state = export,
                    suppliers = home.documents.mapNotNull { it.supplierName }.distinct().sorted(),
                    onBack = { screen = AppScreen.HOME },
                    onPeriod = viewModel::setExportPeriod,
                    onSupplier = viewModel::setExportSupplier,
                    onProcessed = viewModel::setIncludeProcessed,
                    onReview = viewModel::setIncludeReview,
                    onCreate = viewModel::createExcel,
                    onShare = {
                        export.createdFile?.let { file ->
                            val uri = FileProvider.getUriForFile(activityContext, "${activityContext.packageName}.files", file)
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            activityContext.startActivity(Intent.createChooser(intent, "Zdieľať Excel"))
                        }
                    },
                    onSaveAs = { export.createdFile?.let { saveExportLauncher.launch(it.name) } },
                )
                AppScreen.GALLERY -> GalleryScreen(
                    state = gallery,
                    importing = home.importing,
                    onBack = {
                        if (!viewModel.galleryBack()) screen = AppScreen.HOME
                    },
                    onAlbum = viewModel::openAlbum,
                    onPhoto = viewModel::togglePhoto,
                    onProcess = { viewModel.importGallerySelection { screen = AppScreen.HOME } },
                )
                AppScreen.CAMERA -> Unit
            }
        }
    }
}
