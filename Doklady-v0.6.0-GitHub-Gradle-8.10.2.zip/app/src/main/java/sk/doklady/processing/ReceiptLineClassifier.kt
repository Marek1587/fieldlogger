package sk.doklady.processing

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.Normalizer
import kotlin.math.max

enum class ReceiptLineRole {
    OTHER,
    HEADER,
    PRODUCT_NAME,
    QUANTITY,
    ITEM_TOTAL,
    ITEM_IDENTIFIER,
    TOTAL_LABEL,
    TAX,
    PAYMENT,
}

data class LinePrediction(
    val role: ReceiptLineRole,
    val confidence: Float,
    val probabilities: FloatArray,
)

interface ReceiptLineClassifier : AutoCloseable {
    val modelName: String
    val aiEnabled: Boolean
    fun classify(line: OcrLine, pageWidth: Int, pageHeight: Int): LinePrediction
    override fun close() = Unit
}

object ReceiptLineClassifierFactory {
    fun create(context: Context): ReceiptLineClassifier = runCatching {
        LiteRtReceiptLineClassifier(context.applicationContext)
    }.getOrElse { HeuristicReceiptLineClassifier }
}

/**
 * Small bundled LiteRT model. It classifies line roles only: it cannot generate a
 * product name or monetary value. This keeps financial extraction deterministic.
 */
private class LiteRtReceiptLineClassifier(context: Context) : ReceiptLineClassifier {
    private val interpreter: Interpreter
    override val modelName: String = MODEL_NAME
    override val aiEnabled: Boolean = true

    init {
        val bytes = context.assets.open(MODEL_ASSET).use { it.readBytes() }
        val model = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        model.put(bytes).rewind()
        interpreter = Interpreter(model, Interpreter.Options().apply { setNumThreads(2) })
        require(interpreter.getInputTensor(0).shape().contentEquals(intArrayOf(1, FEATURE_COUNT)))
        require(interpreter.getOutputTensor(0).shape().contentEquals(intArrayOf(1, ReceiptLineRole.entries.size)))
    }

    @Synchronized
    override fun classify(line: OcrLine, pageWidth: Int, pageHeight: Int): LinePrediction {
        val features = ReceiptLineFeatures.extract(line, pageWidth, pageHeight)
        val output = Array(1) { FloatArray(ReceiptLineRole.entries.size) }
        interpreter.run(arrayOf(features), output)
        val probabilities = output[0]
        val winner = probabilities.indices.maxByOrNull { probabilities[it] } ?: 0
        val modelPrediction = LinePrediction(
            role = ReceiptLineRole.entries[winner],
            confidence = probabilities[winner].coerceIn(0f, 1f),
            probabilities = probabilities,
        )
        // Exact financial labels override probabilistic classification. The model
        // helps with ambiguous lines, while these guards prevent dangerous drift.
        return ReceiptLineFeatures.safetyOverride(line, modelPrediction)
    }

    override fun close() = interpreter.close()

    companion object {
        private const val MODEL_ASSET = "receipt_line_classifier.tflite"
        private const val MODEL_NAME = "receipt-line-role-v1-litert"
        private const val FEATURE_COUNT = 24
    }
}

object HeuristicReceiptLineClassifier : ReceiptLineClassifier {
    override val modelName: String = "receipt-line-role-heuristic-fallback"
    override val aiEnabled: Boolean = false

    override fun classify(line: OcrLine, pageWidth: Int, pageHeight: Int): LinePrediction {
        val f = ReceiptLineFeatures.extract(line, pageWidth, pageHeight)
        val role = when {
            f[9] > 0.5f -> ReceiptLineRole.TOTAL_LABEL
            f[10] > 0.5f -> ReceiptLineRole.TAX
            f[11] > 0.5f -> ReceiptLineRole.PAYMENT
            f[8] > 0.5f || f[18] > 0.5f -> ReceiptLineRole.ITEM_IDENTIFIER
            f[7] > 0.5f -> ReceiptLineRole.QUANTITY
            f[17] > 0.5f && f[14] > 0.5f -> ReceiptLineRole.ITEM_TOTAL
            f[22] > 0.5f && f[4] > 0.55f -> ReceiptLineRole.HEADER
            f[23] > 0.5f && f[4] > 0.55f && f[5] < 0.30f -> ReceiptLineRole.PRODUCT_NAME
            else -> ReceiptLineRole.OTHER
        }
        val probabilities = FloatArray(ReceiptLineRole.entries.size)
        probabilities[role.ordinal] = 0.78f
        return ReceiptLineFeatures.safetyOverride(line, LinePrediction(role, 0.78f, probabilities))
    }
}

internal object ReceiptLineFeatures {
    private val amountRegex = Regex("(?<!\\d)[-+]?\\d{1,6}(?:[ .]\\d{3})*[,.]\\d{2}(?!\\d)")
    private val quantityRegex = Regex("(?i)\\d+(?:[,.]\\d+)?\\s*(?:kus|ks|kg|g|l|m2|m²|m|bal\\.|bal|pc)\\b")
    private val eanRegex = Regex("(?<!\\d)\\d{8,13}(?!\\d)")

    fun extract(line: OcrLine, pageWidth: Int, pageHeight: Int): FloatArray {
        val width = max(1, pageWidth).toFloat()
        val height = max(1, pageHeight).toFloat()
        val text = line.text.trim()
        val normalized = normalized(text)
        val visible = text.count { !it.isWhitespace() }.coerceAtLeast(1)
        val letters = text.count(Char::isLetter)
        val digits = text.count(Char::isDigit)
        val upper = text.count(Char::isUpperCase)
        val words = text.split(Regex("\\s+")).count { it.isNotBlank() }
        val amounts = amountRegex.findAll(text).count()
        val hasQuantity = quantityRegex.containsMatchIn(text)
        val hasEan = eanRegex.containsMatchIn(text)
        val hasTotal = TOTAL_WORDS.any(normalized::contains)
        val hasTax = TAX_WORDS.any(normalized::contains)
        val hasPayment = PAYMENT_WORDS.any(normalized::contains)
        val hasRegistration = REGISTRATION_WORDS.any(normalized::contains)
        val hasDate = DATE_REGEX.containsMatchIn(text)
        val letterRatio = letters.toFloat() / visible
        val digitRatio = digits.toFloat() / visible
        val priceOnly = amounts == 1 && letters <= 3 && visible <= 16
        val centerY = (line.top + line.bottom) / 2f / height
        return floatArrayOf(
            ((line.left + line.right) / 2f / width).coerceIn(0f, 1f),
            centerY.coerceIn(0f, 1f),
            ((line.right - line.left) / width).coerceIn(0f, 1f),
            ((line.bottom - line.top) / height).coerceIn(0f, 1f),
            letterRatio.coerceIn(0f, 1f),
            digitRatio.coerceIn(0f, 1f),
            (amounts / 3f).coerceIn(0f, 1f),
            if (hasQuantity) 1f else 0f,
            if (hasEan) 1f else 0f,
            if (hasTotal) 1f else 0f,
            if (hasTax) 1f else 0f,
            if (hasPayment) 1f else 0f,
            if (hasRegistration) 1f else 0f,
            if (hasDate) 1f else 0f,
            if (line.right / width >= 0.72f) 1f else 0f,
            (upper.toFloat() / letters.coerceAtLeast(1)).coerceIn(0f, 1f),
            (words / 8f).coerceIn(0f, 1f),
            if (priceOnly) 1f else 0f,
            if (ITEM_IDENTIFIER_WORDS.any(normalized::contains)) 1f else 0f,
            if (LEGAL_WORDS.any(normalized::contains)) 1f else 0f,
            if (ADDRESS_WORDS.any(normalized::contains)) 1f else 0f,
            if (CURRENCY_WORDS.any(normalized::contains)) 1f else 0f,
            if (centerY < 0.28f) 1f else 0f,
            if (centerY in 0.20f..0.82f) 1f else 0f,
        )
    }

    fun safetyOverride(line: OcrLine, prediction: LinePrediction): LinePrediction {
        val value = normalized(line.text)
        val forced = when {
            TOTAL_WORDS.any(value::contains) -> ReceiptLineRole.TOTAL_LABEL
            TAX_WORDS.any(value::contains) -> ReceiptLineRole.TAX
            PAYMENT_WORDS.any(value::contains) -> ReceiptLineRole.PAYMENT
            eanRegex.containsMatchIn(line.text) || ITEM_IDENTIFIER_WORDS.any(value::contains) -> ReceiptLineRole.ITEM_IDENTIFIER
            quantityRegex.containsMatchIn(line.text) -> ReceiptLineRole.QUANTITY
            else -> null
        } ?: return prediction
        val probabilities = prediction.probabilities.copyOf()
        probabilities[forced.ordinal] = max(probabilities[forced.ordinal], 0.995f)
        return LinePrediction(forced, max(prediction.confidence, 0.995f), probabilities)
    }

    fun normalized(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "").uppercase()

    private val TOTAL_WORDS = listOf("NA UHRADU", "K UHRADE", "CELKOM", "TOTAL", "MEDZISUCET", "SUBTOTAL")
    private val TAX_WORDS = listOf("DPH", "VAT", "SADZBA", "ZAKLAD", "BEZ DPH")
    private val PAYMENT_WORDS = listOf("KARTA", "CARD", "HOTOVOST", "CASH")
    private val REGISTRATION_WORDS = listOf("ICO", "DIC", "IC DPH")
    private val ITEM_IDENTIFIER_WORDS = listOf("EAN", "ART.", "ART/", "KOD POLOZKY", "PLU")
    private val LEGAL_WORDS = listOf("S.R.O", "SRO", "A.S.", "SPOL.")
    private val ADDRESS_WORDS = listOf("ULICA", "NAM.", "CESTA", "BRATISLAVA", "KOSICE", "ZILINA")
    private val CURRENCY_WORDS = listOf("EUR", "CZK", "USD", "€")
    private val DATE_REGEX = Regex("\\b(?:0?[1-9]|[12]\\d|3[01])[./-](?:0?[1-9]|1[0-2])[./-](?:20)?\\d{2}\\b")
}
