package sk.doklady.processing

import sk.doklady.data.CaptureMode
import java.math.BigDecimal
import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.roundToInt

data class ConfidenceInput(
    val captureMode: CaptureMode,
    val frameCount: Int,
    val selectedFrameCount: Int,
    val imageQualityConfidence: Float?,
    val temporalConsensusConfidence: Float?,
    val ocrConsistencyConfidence: Float?,
    val criticalConsensus: Float?,
    val conflictingTokens: Int,
    val secondPassUsed: Boolean,
    val parsed: ParsedDocument,
)

data class ConfidenceBreakdown(
    val imageQuality: Float?,
    val temporalConsensus: Float?,
    val ocrConsistency: Float?,
    val parserConfidence: Float,
    val mathematicalValidation: Float,
    val headerValidation: Float,
    val lineItemValidation: Float,
    val finalConfidence: Float?,
    val mathPassed: Boolean,
    val parserPassed: Boolean,
    val allItemMathValid: Boolean,
    val strictHundredConditionsMet: Boolean,
    val requiresReview: Boolean,
    val mathResult: String,
    val parserResult: String,
)

class ConfidenceEngine {
    fun calculate(input: ConfidenceInput): ConfidenceBreakdown {
        val parsed = input.parsed
        val reconciliation = ReceiptReconciler.evaluate(parsed)
        val parsableItems = parsed.items.mapNotNull { item ->
            val quantity = item.quantity?.replace(',', '.')?.toBigDecimalOrNull()
            val unit = item.unitPriceGrossCents
            val total = item.totalGrossCents
            if (quantity != null && unit != null && total != null && total >= 0) Triple(quantity, unit, total) else null
        }
        val validItemMath = parsableItems.count { (quantity, unit, total) ->
            val expected = quantity.multiply(BigDecimal(unit)).setScale(0, java.math.RoundingMode.HALF_UP).longValueExact()
            abs(expected - total) <= ITEM_TOLERANCE_CENTS
        }
        val lineItemValidation = when {
            parsed.items.isEmpty() -> 0f
            parsableItems.isEmpty() -> 0.45f
            else -> validItemMath.toFloat() / parsableItems.size
        }
        val allItemMathValid = parsableItems.isNotEmpty() && validItemMath == parsableItems.size
        val itemTotalMatch = reconciliation.financiallyConsistent
        val vatMatch = if (parsed.netTotalCents != null && parsed.vatTotalCents != null && parsed.grossTotalCents != null) {
            abs(parsed.netTotalCents + parsed.vatTotalCents - parsed.grossTotalCents) <= TAX_TOLERANCE_CENTS
        } else false
        val mathValidation = when {
            itemTotalMatch && vatMatch && allItemMathValid -> 1f
            itemTotalMatch && allItemMathValid -> 0.90f
            itemTotalMatch -> 0.78f
            reconciliation.differenceCents != null && reconciliation.differenceCents <= 5 -> 0.60f
            else -> 0.15f
        }
        val mathPassed = itemTotalMatch && (parsableItems.isEmpty() || allItemMathValid)

        val headerChecks = listOf(
            !parsed.supplier.isNullOrBlank(),
            !parsed.documentNumber.isNullOrBlank(),
            isValidDate(parsed.purchaseDate),
            parsed.grossTotalCents != null,
            !parsed.registrationId.isNullOrBlank(),
        )
        val headerValidation = headerChecks.count { it }.toFloat() / headerChecks.size
        val estimatedItems = parsed.diagnostics.estimatedItemCount
        val itemCompleteness = estimatedItems == 0 || parsed.items.size >= estimatedItems
        val parserSignals = listOf(
            !parsed.supplier.isNullOrBlank(),
            parsed.purchaseDate != null,
            !parsed.documentNumber.isNullOrBlank(),
            parsed.grossTotalCents != null,
            parsed.items.isNotEmpty(),
            parsed.items.size >= 2,
            parsed.currency.isNotBlank(),
            itemCompleteness,
        )
        val parserConfidence = parserSignals.count { it }.toFloat() / parserSignals.size
        val parserPassed = parserConfidence >= 0.82f && parsed.grossTotalCents != null && parsed.items.isNotEmpty()

        val components = listOfNotNull(
            input.imageQualityConfidence?.let { it.coerceIn(0f, 1f) to 0.16f },
            input.temporalConsensusConfidence?.let { it.coerceIn(0f, 1f) to 0.22f },
            input.ocrConsistencyConfidence?.let { it.coerceIn(0f, 1f) to 0.14f },
            parserConfidence to 0.12f,
            mathValidation to 0.18f,
            headerValidation to 0.08f,
            lineItemValidation to 0.10f,
        )
        val final = if (components.size < 4 || parsed.grossTotalCents == null) null else {
            val weightSum = components.sumOf { it.second.toDouble() }.toFloat()
            val geometric = components.fold(1.0) { product, (value, weight) ->
                product * value.coerceAtLeast(0.01f).toDouble().pow((weight / weightSum).toDouble())
            }.toFloat()
            geometric * 100f
        }
        val strictHundred = input.captureMode == CaptureMode.MULTI_FRAME &&
            input.frameCount >= 15 && input.selectedFrameCount >= 4 &&
            (input.imageQualityConfidence ?: 0f) >= 0.97f &&
            (input.temporalConsensusConfidence ?: 0f) >= 0.999f &&
            (input.criticalConsensus ?: 0f) >= 0.999f &&
            (input.ocrConsistencyConfidence ?: 0f) >= 0.99f &&
            input.conflictingTokens == 0 && parserPassed && headerChecks.all { it } &&
            mathValidation >= 0.999f && allItemMathValid && vatMatch && !input.secondPassUsed
        val conservativeFinal = final?.let { value ->
            if (strictHundred) 100f else minOf(99f, (value * 10f).roundToInt() / 10f)
        }
        val requiresReview = conservativeFinal == null || conservativeFinal < VERIFIED_THRESHOLD ||
            !mathPassed || input.conflictingTokens > 0 ||
            (input.captureMode == CaptureMode.MULTI_FRAME && (input.criticalConsensus ?: 0f) < 0.75f)
        return ConfidenceBreakdown(
            imageQuality = input.imageQualityConfidence,
            temporalConsensus = input.temporalConsensusConfidence,
            ocrConsistency = input.ocrConsistencyConfidence,
            parserConfidence = parserConfidence,
            mathematicalValidation = mathValidation,
            headerValidation = headerValidation,
            lineItemValidation = lineItemValidation,
            finalConfidence = conservativeFinal,
            mathPassed = mathPassed,
            parserPassed = parserPassed,
            allItemMathValid = allItemMathValid,
            strictHundredConditionsMet = strictHundred,
            requiresReview = requiresReview,
            mathResult = "itemSum=${reconciliation.itemSumCents}; total=${reconciliation.totalCents}; " +
                "difference=${reconciliation.differenceCents}; itemMath=$validItemMath/${parsableItems.size}; vat=$vatMatch",
            parserResult = "supplier=${parsed.supplier != null}; number=${parsed.documentNumber != null}; " +
                "date=${isValidDate(parsed.purchaseDate)}; items=${parsed.items.size}/$estimatedItems; " +
                "strategy=${parsed.diagnostics.strategy}; model=${parsed.diagnostics.modelName}; " +
                "ai=${parsed.diagnostics.aiEnabled}; associations=${parsed.diagnostics.spatialAssociations}; " +
                "nameCorrections=${parsed.diagnostics.correctedNames}; score=${percent(parserConfidence)}%",
        )
    }

    private fun isValidDate(value: String?): Boolean {
        if (value == null || !value.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) return false
        val parts = value.split('-').mapNotNull(String::toIntOrNull)
        return parts.size == 3 && parts[0] in 2000..2100 && parts[1] in 1..12 && parts[2] in 1..31
    }

    private fun percent(value: Float) = (value * 100).roundToInt()

    companion object {
        private const val ITEM_TOLERANCE_CENTS = 2L
        private const val TAX_TOLERANCE_CENTS = 2L
        private const val VERIFIED_THRESHOLD = 92f
    }
}
