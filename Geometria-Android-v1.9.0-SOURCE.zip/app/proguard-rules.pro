-keepclassmembers class sk.geometria.app.MainActivity$GeometriaBridge {
    <methods>;
}
