(function (root) {
  "use strict";
  const TICKS_PER_MM = 100;

  function parseDimension(value, unit) {
    const normalized = String(value).trim().replace(/\s/g, "").replace(",", ".");
    const number = Number(normalized);
    if (!Number.isFinite(number)) return null;
    return Math.round(number * (unit === "cm" ? 1000 : TICKS_PER_MM));
  }

  function formatDimension(ticks, unit, withUnit) {
    const divider = unit === "cm" ? 1000 : TICKS_PER_MM;
    const value = ticks / divider;
    const text = new Intl.NumberFormat("sk-SK", { maximumFractionDigits: unit === "cm" ? 3 : 2 }).format(value);
    return withUnit === false ? text : text + " " + unit;
  }

  function validate(input) {
    const errors = [];
    if (!Number.isInteger(input.targetLength) || input.targetLength <= 0) errors.push("Cieľová dĺžka musí byť väčšia ako nula.");
    if (!Number.isInteger(input.nominalWidth) || input.nominalWidth <= 0) errors.push("Šírka dielu musí byť väčšia ako nula.");
    if ((input.fixedLeft || 0) < 0 || (input.fixedRight || 0) < 0) errors.push("Pevné kraje nemôžu byť záporné.");
    if ((input.fixedLeft || 0) + (input.fixedRight || 0) >= input.targetLength) errors.push("Pevné kraje musia byť spolu menšie než cieľová dĺžka.");
    if ((input.minCorrection || 0) < 0 || (input.maxCorrection || 0) < 0) errors.push("Tolerancia nemôže byť záporná.");
    return errors;
  }

  function calculateBasicLayout(input) {
    const errors = validate(input);
    if (!errors.length && input.nominalWidth > input.targetLength) errors.push("Šírka dielu nemôže byť väčšia než cieľová dĺžka.");
    if (errors.length) return { ok: false, errors: errors };
    const fullPieceCount = Math.floor(input.targetLength / input.nominalWidth);
    const remainder = input.targetLength - fullPieceCount * input.nominalWidth;
    const leftEdge = remainder / 2;
    const rightEdge = remainder - leftEdge;
    return { ok: true, targetLength: input.targetLength, nominalWidth: input.nominalWidth, fullPieceCount: fullPieceCount, remainder: remainder, leftEdge: leftEdge, rightEdge: rightEdge, achievedLength: leftEdge + fullPieceCount * input.nominalWidth + rightEdge };
  }

  function distributeCorrection(input) {
    const minSteps = Math.ceil(-input.minCorrection / input.step);
    const maxSteps = Math.floor(input.maxCorrection / input.step);
    const wantedSteps = Math.round(input.totalCorrection / input.step);
    const totalSteps = Math.max(input.pieceCount * minSteps, Math.min(input.pieceCount * maxSteps, wantedSteps));
    const base = Math.floor(totalSteps / input.pieceCount);
    const raised = totalSteps - base * input.pieceCount;
    return {
      corrections: Array.from({ length: input.pieceCount }, function (_, index) { return (index < raised ? base + 1 : base) * input.step; }),
      appliedCorrection: totalSteps * input.step
    };
  }

  function makeCandidate(input, pieceCount) {
    const nominalTotal = input.fixedLeft + input.fixedRight + pieceCount * input.nominalWidth;
    const requiredCorrection = input.targetLength - nominalTotal;
    const distribution = distributeCorrection({ pieceCount: pieceCount, totalCorrection: requiredCorrection, step: input.step, minCorrection: input.minCorrection, maxCorrection: input.maxCorrection });
    const pieces = distribution.corrections.map(function (correction, index) { return { index: index + 1, nominalWidth: input.nominalWidth, correction: correction, finalWidth: input.nominalWidth + correction }; });
    const achievedLength = nominalTotal + distribution.appliedCorrection;
    return { targetLength: input.targetLength, nominalWidth: input.nominalWidth, pieceCount: pieceCount, fixedLeft: input.fixedLeft, fixedRight: input.fixedRight, nominalTotal: nominalTotal, requiredCorrection: requiredCorrection, correctionPerPiece: requiredCorrection / pieceCount, pieces: pieces, achievedLength: achievedLength, residualError: achievedLength - input.targetLength, exact: achievedLength === input.targetLength, appliedCorrection: distribution.appliedCorrection, averageCorrection: Math.abs(distribution.appliedCorrection / pieceCount) };
  }

  function solveCorrection(input) {
    const errors = validate(input);
    if (!Number.isInteger(input.step) || input.step <= 0) errors.push("Krok korekcie musí byť väčší ako nula.");
    if (errors.length) return { ok: false, errors: errors };
    const available = input.targetLength - input.fixedLeft - input.fixedRight;
    const minimumWidth = Math.max(1, input.nominalWidth - input.minCorrection);
    const maxCount = Math.min(500, Math.max(1, Math.ceil(available / minimumWidth) + 2));
    const counts = input.pieceCount ? [input.pieceCount] : Array.from({ length: maxCount }, function (_, index) { return index + 1; });
    const candidates = counts.map(function (count) { return makeCandidate(input, count); });
    candidates.sort(function (a, b) { return Math.abs(a.residualError) - Math.abs(b.residualError) || a.averageCorrection - b.averageCorrection || Math.abs(a.pieceCount - available / input.nominalWidth) - Math.abs(b.pieceCount - available / input.nominalWidth); });
    const best = candidates[0];
    best.ok = true;
    best.minimumTolerance = Math.abs(best.requiredCorrection / best.pieceCount);
    return best;
  }

  function groupPieces(pieces) {
    const map = new Map();
    pieces.forEach(function (piece) {
      const key = piece.finalWidth + ":" + piece.correction;
      const group = map.get(key) || { count: 0, finalWidth: piece.finalWidth, correction: piece.correction };
      group.count += 1;
      map.set(key, group);
    });
    return Array.from(map.values()).sort(function (a, b) { return b.correction - a.correction; });
  }

  function solveRightTriangle(values, manualSides) {
    const manual = manualSides.slice(-2);
    const computedSide = ["a", "b", "c"].find(function (side) { return !manual.includes(side); });
    if (!computedSide || manual.some(function (side) { return !Number.isFinite(values[side]) || values[side] <= 0; })) {
      return { ok: false, computedSide: computedSide || null, values: Object.assign({}, values) };
    }
    let squared;
    if (computedSide === "c") squared = values.a * values.a + values.b * values.b;
    if (computedSide === "a") squared = values.c * values.c - values.b * values.b;
    if (computedSide === "b") squared = values.c * values.c - values.a * values.a;
    if (!(squared > 0)) return { ok: false, computedSide: computedSide, values: Object.assign({}, values) };
    const result = Object.assign({}, values);
    result[computedSide] = Math.round(Math.sqrt(squared) / TICKS_PER_MM) * TICKS_PER_MM;
    return { ok: true, computedSide: computedSide, values: result };
  }

  function solveRectangleSquaring(values) {
    const l1 = values && (values.l1 || values.length);
    const l2 = values && (values.l2 || values.length);
    const d1 = values && values.d1;
    const d2 = values && values.d2;
    if (![l1, l2, d1, d2].every(function (value) { return Number.isFinite(value) && value > 0; })) {
      return { ok: false, errors: ["Rozmery musia byť kladné čísla."] };
    }
    // Rovnobežné hrany: spodná od 0 po L2, horná od posunu s po s + L1.
    // Rovnice diagonál jednoznačne určia posun ľavej strany aj výšku.
    const rawLeftShift = (d2 * d2 - d1 * d1 - l1 * l1 + l2 * l2) / (2 * (l1 + l2));
    const rawRightShift = rawLeftShift + l1 - l2;
    const heightSquared = d2 * d2 - Math.pow(rawLeftShift + l1, 2);
    if (!(heightSquared > 0)) return { ok: false, errors: ["Z rozmerov nevznikne platný lichobežník."] };
    const height = Math.sqrt(heightSquared);
    const signedLeftShift = Math.round(rawLeftShift / TICKS_PER_MM) * TICKS_PER_MM;
    const signedRightShift = Math.round(rawRightShift / TICKS_PER_MM) * TICKS_PER_MM;
    const bottomLeft = Math.atan2(height, rawLeftShift) * 180 / Math.PI;
    const bottomRight = Math.atan2(height, -rawRightShift) * 180 / Math.PI;
    const angles = {
      topLeft: 180 - bottomLeft,
      topRight: 180 - bottomRight,
      bottomRight: bottomRight,
      bottomLeft: bottomLeft
    };
    const rightAngleCorners = Object.keys(angles).filter(function (corner) { return Math.abs(angles[corner] - 90) <= 0.1; });
    const signedSkewAngleDegrees = 90 - bottomLeft;
    const skewAngleDegrees = Math.abs(signedSkewAngleDegrees);
    return {
      ok: true,
      l1: l1,
      l2: l2,
      x: Math.abs(signedLeftShift),
      signedX: signedLeftShift,
      xLeft: Math.abs(signedLeftShift),
      signedXLeft: signedLeftShift,
      xRight: Math.abs(signedRightShift),
      signedXRight: signedRightShift,
      wholeSideShift: Math.abs(signedLeftShift),
      longerDiagonal: d2 >= d1 ? "d2" : "d1",
      derivedHeight: Math.round(height),
      skewAngleDegrees: skewAngleDegrees,
      signedSkewAngleDegrees: signedSkewAngleDegrees,
      angles: angles,
      rightAngleCorners: rightAngleCorners
    };
  }

  function solveSheetPerpendicular(values) {
    const width = values && values.width;
    const angleDegrees = values && values.angleDegrees;
    if (!Number.isFinite(width) || width <= 0) return { ok: false, errors: ["Šírka pásu musí byť kladná."] };
    if (!Number.isFinite(angleDegrees) || angleDegrees <= 0 || angleDegrees >= 90) {
      return { ok: false, errors: ["Uhol musí byť väčší ako 0° a menší ako 90°."] };
    }
    const angleRadians = angleDegrees * Math.PI / 180;
    return { ok: true, x: Math.round(width * Math.tan(angleRadians) / TICKS_PER_MM) * TICKS_PER_MM, width: width, angleDegrees: angleDegrees };
  }

  function solveClipLayout(values) {
    const length = values && values.length;
    const angleDegrees = values && values.angleDegrees;
    const spacing = values && values.spacing;
    if (!Number.isFinite(length) || length <= 0) return { ok: false, errors: ["Dĺžka pásu musí byť kladná."] };
    if (!Number.isFinite(angleDegrees) || angleDegrees < 3 || angleDegrees >= 90) {
      return { ok: false, errors: ["Sklon musí byť od 3° do 89°."] };
    }
    if (!Number.isFinite(spacing) || spacing <= 0) return { ok: false, errors: ["Rozstup príponiek musí byť kladný."] };
    const fixedZoneLength = Math.min(length, length > 1000000 ? 300000 : 100000);
    let factor;
    if (angleDegrees === 3) factor = 0.5;
    else if (angleDegrees <= 10) factor = 2 / 3;
    else if (angleDegrees <= 30) factor = 3 / 4;
    else factor = null;
    const requestedCenter = factor === null ? length - fixedZoneLength / 2 : length * factor;
    const fixedStart = Math.max(0, Math.min(length - fixedZoneLength, Math.round(requestedCenter - fixedZoneLength / 2)));
    const fixedEnd = fixedStart + fixedZoneLength;
    const clips = [];
    for (let position = spacing, index = 1; position < length; position += spacing, index += 1) {
      clips.push({ index: index, position: position, type: position >= fixedStart && position <= fixedEnd ? "fixed" : "sliding" });
    }
    return {
      ok: true,
      length: length,
      angleDegrees: angleDegrees,
      spacing: spacing,
      fixedZoneLength: fixedZoneLength,
      fixedCenter: fixedStart + fixedZoneLength / 2,
      fixedStart: fixedStart,
      fixedEnd: fixedEnd,
      clips: clips,
      zones: [
        { number: 1, start: fixedEnd, end: length, type: "sliding" },
        { number: 2, start: fixedStart, end: fixedEnd, type: "fixed" },
        { number: 3, start: 0, end: fixedStart, type: "sliding" }
      ]
    };
  }

  function solveUpperSlidingDilatation(values) {
    const panelLength = values && values.panelLength;
    const fixedZoneEnd = values && values.fixedZoneEnd;
    const screwDiameter = values && values.screwDiameter;
    const alphaSteel = Number.isFinite(values && values.alphaSteel) ? values.alphaSteel : 0.012;
    const temperatureRange = Number.isFinite(values && values.temperatureRange) ? values.temperatureRange : 100;
    const installationReserve = Number.isFinite(values && values.installationReserve) ? values.installationReserve : 200;
    if (![panelLength, fixedZoneEnd, screwDiameter].every(function (value) { return Number.isFinite(value) && value >= 0; }) || panelLength <= 0 || screwDiameter <= 0) {
      return { ok: false, errors: ["Dĺžka pásu, pevná zóna a priemer skrutky musia byť platné."] };
    }
    if (fixedZoneEnd > panelLength) return { ok: false, errors: ["Horný okraj pevnej zóny nemôže byť za hrebeňom."] };
    const upperSlidingLength = panelLength - fixedZoneEnd;
    const upperLengthMeters = upperSlidingLength / TICKS_PER_MM / 1000;
    const thermalMovementMm = upperLengthMeters * alphaSteel * temperatureRange;
    const thermalMovement = Math.round(thermalMovementMm * TICKS_PER_MM);
    const theoreticalSlotLength = screwDiameter + thermalMovement;
    const minimumSlotLength = Math.ceil(theoreticalSlotLength / TICKS_PER_MM) * TICKS_PER_MM;
    const requiredWithReserve = theoreticalSlotLength + installationReserve;
    const requiredMm = requiredWithReserve / TICKS_PER_MM;
    const recommendedSlotLength = Math.max(800, Math.ceil(requiredMm / 2) * 200);
    const clearanceWidthMm = screwDiameter / TICKS_PER_MM + 1;
    const recommendedSlotWidth = Math.ceil(clearanceWidthMm / 2) * 200;
    return {
      ok: true,
      panelLength: panelLength,
      fixedZoneEnd: fixedZoneEnd,
      upperSlidingLength: upperSlidingLength,
      alphaSteel: alphaSteel,
      temperatureRange: temperatureRange,
      screwDiameter: screwDiameter,
      installationReserve: installationReserve,
      thermalMovement: thermalMovement,
      theoreticalSlotLength: theoreticalSlotLength,
      minimumSlotLength: minimumSlotLength,
      requiredWithReserve: requiredWithReserve,
      recommendedSlotWidth: recommendedSlotWidth,
      recommendedSlotLength: recommendedSlotLength,
      movementDirection: "k hrebeňu",
      slotOrientation: "pozdĺž smeru spádu / dilatácie"
    };
  }

  const api = { TICKS_PER_MM: TICKS_PER_MM, parseDimension: parseDimension, formatDimension: formatDimension, calculateBasicLayout: calculateBasicLayout, distributeCorrection: distributeCorrection, solveCorrection: solveCorrection, groupPieces: groupPieces, solveRightTriangle: solveRightTriangle, solveRectangleSquaring: solveRectangleSquaring, solveSheetPerpendicular: solveSheetPerpendicular, solveClipLayout: solveClipLayout, solveUpperSlidingDilatation: solveUpperSlidingDilatation };
  root.GeometrySolver = api;
  if (typeof module !== "undefined" && module.exports) module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
