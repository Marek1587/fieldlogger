package sk.strechasketch.app

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Camera for deterministic CPU-rendered previews. No OpenGL context is used. */
data class RoofBitmapCamera(
    val yawDeg: Double = -35.0,
    val pitchDeg: Double = 28.0,
    val distance: Double = 4.8,
    val paddingFraction: Double = 0.09
)

/**
 * Standalone static 3D renderer for lists, exports and PDF documents.
 *
 * It consumes the same validated [RoofMesh] snapshot as the interactive
 * OpenGL view, but projects and shades it entirely through Kotlin + Canvas.
 * Therefore it works without creating, opening or capturing a GLSurfaceView.
 */
object RoofBitmapRenderer {
    private data class Projected(
        val x: Double,
        val y: Double,
        val depth: Double,
        val inverseDepth: Float
    )
    private data class DrawTriangle(
        val a: Projected,
        val b: Projected,
        val c: Projected,
        val color: Int
    )

    fun render(
        project: RoofProject,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera = RoofBitmapCamera(),
        backgroundColor: Int = Color.rgb(246, 247, 247)
    ): Bitmap {
        require(width in 64..4096 && height in 64..4096) { "Neplatná veľkosť statického 3D obrázka." }
        return renderMesh(RoofMeshBuilder.build(project), width, height, camera, backgroundColor)
    }

    internal fun renderMesh(
        mesh: RoofMesh,
        width: Int,
        height: Int,
        camera: RoofBitmapCamera,
        backgroundColor: Int
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(backgroundColor)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            color = Color.rgb(155, 160, 163)
            strokeWidth = max(0.9f, min(width, height) / 520f)
        }
        if (mesh.triangles.isEmpty()) {
            val message = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(78, 91, 82)
                textAlign = Paint.Align.CENTER
                textSize = min(width, height) * 0.045f
            }
            canvas.drawText("3D model nie je dostupný", width / 2f, height / 2f, message)
            canvas.drawRect(0.5f, 0.5f, width - 0.5f, height - 0.5f, frame)
            return bitmap
        }

        val yaw = Math.toRadians(camera.yawDeg)
        val pitch = Math.toRadians(camera.pitchDeg)
        fun rotate(x: Double, y: Double, z: Double): Triple<Double, Double, Double> {
            val yawX = x * cos(yaw) + z * sin(yaw)
            val yawZ = -x * sin(yaw) + z * cos(yaw)
            val pitchY = y * cos(pitch) - yawZ * sin(pitch)
            val pitchZ = y * sin(pitch) + yawZ * cos(pitch)
            return Triple(yawX, pitchY, pitchZ)
        }
        fun project(x: Double, y: Double, z: Double): Projected {
            val rotated = rotate(x, y, z)
            val cameraW = (camera.distance - rotated.third).coerceAtLeast(0.35)
            val perspective = camera.distance / cameraW
            return Projected(
                rotated.first * perspective,
                -rotated.second * perspective,
                rotated.third,
                (1.0 / cameraW).toFloat()
            )
        }

        val projectedVertices = mutableListOf<Projected>()
        var offset = 0
        while (offset + 2 < mesh.triangles.size) {
            projectedVertices += project(
                mesh.triangles[offset].toDouble(),
                mesh.triangles[offset + 1].toDouble(),
                mesh.triangles[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.edges.size) {
            projectedVertices += project(
                mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble()
            )
            offset += 3
        }
        offset = 0
        while (offset + 2 < mesh.logoEdges.size) {
            projectedVertices += project(
                mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble()
            )
            offset += 3
        }
        mesh.logoQuads.forEach { quad ->
            listOf(quad.topLeft, quad.topRight, quad.bottomRight, quad.bottomLeft).forEach { point ->
                projectedVertices += project(point.x.toDouble(), point.y.toDouble(), point.z.toDouble())
            }
        }
        val minX = projectedVertices.minOf { it.x }
        val maxX = projectedVertices.maxOf { it.x }
        val minY = projectedVertices.minOf { it.y }
        val maxY = projectedVertices.maxOf { it.y }
        val padding = min(width, height) * camera.paddingFraction.coerceIn(0.02, 0.25)
        val availableWidth = (width - 2.0 * padding).coerceAtLeast(1.0)
        val availableHeight = (height - 2.0 * padding).coerceAtLeast(1.0)
        val scale = min(availableWidth / max(1e-6, maxX - minX), availableHeight / max(1e-6, maxY - minY))
        fun sx(point: Projected) = (width / 2.0 + (point.x - (minX + maxX) / 2.0) * scale).toFloat()
        fun sy(point: Projected) = (height / 2.0 + (point.y - (minY + maxY) / 2.0) * scale).toFloat()
        fun depthVertex(point: Projected) = DepthVertex(sx(point), sy(point), point.inverseDepth)

        val lightLength = sqrt(0.42 * 0.42 + 0.72 * 0.72 + 0.86 * 0.86)
        val light = Triple(-0.42 / lightLength, 0.72 / lightLength, 0.86 / lightLength)
        val triangles = mutableListOf<DrawTriangle>()
        var vertexOffset = 0
        while (vertexOffset + 8 < mesh.triangles.size) {
            val a = project(mesh.triangles[vertexOffset].toDouble(), mesh.triangles[vertexOffset + 1].toDouble(), mesh.triangles[vertexOffset + 2].toDouble())
            val b = project(mesh.triangles[vertexOffset + 3].toDouble(), mesh.triangles[vertexOffset + 4].toDouble(), mesh.triangles[vertexOffset + 5].toDouble())
            val c = project(mesh.triangles[vertexOffset + 6].toDouble(), mesh.triangles[vertexOffset + 7].toDouble(), mesh.triangles[vertexOffset + 8].toDouble())
            val nx = mesh.normals.getOrElse(vertexOffset) { 0f }.toDouble()
            val ny = mesh.normals.getOrElse(vertexOffset + 1) { 1f }.toDouble()
            val nz = mesh.normals.getOrElse(vertexOffset + 2) { 0f }.toDouble()
            val normal = rotate(nx, ny, nz)
            val diffuse = max(0.0, normal.first * light.first + normal.second * light.second + normal.third * light.third)
            val roof = mesh.materials.getOrElse(vertexOffset / 3) { if (abs(ny) >= 0.42) 1f else 0f } >= 0.5f
            val mineral = abs(sin((a.x + b.x * 1.71 + c.x * 0.63) * 18.7 + (a.y + b.y + c.y) * 11.3))
            val base = if (roof) {
                val materialVariation = 0.97 + mineral * 0.060
                intArrayOf(
                    (40 * materialVariation).toInt(),
                    (46 * materialVariation).toInt(),
                    (50 * materialVariation).toInt()
                )
            } else {
                intArrayOf(232, 218, 190)
            }
            val shade = if (roof) {
                (0.96 + 0.08 * diffuse).coerceIn(0.96, 1.04)
            } else {
                (0.82 + 0.18 * diffuse).coerceIn(0.80, 1.0)
            }
            val color = Color.rgb(
                (base[0] * shade).toInt().coerceIn(0, 255),
                (base[1] * shade).toInt().coerceIn(0, 255),
                (base[2] * shade).toInt().coerceIn(0, 255)
            )
            triangles += DrawTriangle(a, b, c, color)
            vertexOffset += 9
        }
        val raster = SoftwareDepthRasterizer(width, height, backgroundColor)
        // Surfaces are fully opaque and tested fragment by fragment. No triangle stroke is drawn:
        // triangulation diagonals are an implementation detail, not a visible wall/roof edge.
        triangles.forEach { triangle ->
            raster.fillTriangle(
                depthVertex(triangle.a), depthVertex(triangle.b), depthVertex(triangle.c), triangle.color
            )
        }

        val edgeWidth = max(1.0f, min(width, height) / 430f)
        val edgeColor = Color.rgb(19, 23, 25)
        offset = 0
        while (offset + 5 < mesh.edges.size) {
            val a = project(mesh.edges[offset].toDouble(), mesh.edges[offset + 1].toDouble(), mesh.edges[offset + 2].toDouble())
            val b = project(mesh.edges[offset + 3].toDouble(), mesh.edges[offset + 4].toDouble(), mesh.edges[offset + 5].toDouble())
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), edgeColor, edgeWidth)
            offset += 6
        }
        val logoEdgeWidth = max(1.2f, min(width, height) / 320f)
        val logoEdgeColor = Color.rgb(226, 212, 178)
        offset = 0
        while (offset + 5 < mesh.logoEdges.size) {
            val a = project(mesh.logoEdges[offset].toDouble(), mesh.logoEdges[offset + 1].toDouble(), mesh.logoEdges[offset + 2].toDouble())
            val b = project(mesh.logoEdges[offset + 3].toDouble(), mesh.logoEdges[offset + 4].toDouble(), mesh.logoEdges[offset + 5].toDouble())
            raster.drawDepthTestedLine(depthVertex(a), depthVertex(b), logoEdgeColor, logoEdgeWidth, 0.0012f)
            offset += 6
        }
        if (mesh.logoQuads.isNotEmpty()) {
            val logo = StrechoStavLogo.bitmap(1024, 470)
            val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 245 }
            val source = StrechoStavLogo.roofSurfaceSourceCorners(logo.width, logo.height)
            val logoLayer = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val logoCanvas = Canvas(logoLayer)
            val layerPixels = IntArray(width * height)
            mesh.logoQuads.forEach { quad ->
                logoLayer.eraseColor(Color.TRANSPARENT)
                val tl = project(quad.topLeft.x.toDouble(), quad.topLeft.y.toDouble(), quad.topLeft.z.toDouble())
                val tr = project(quad.topRight.x.toDouble(), quad.topRight.y.toDouble(), quad.topRight.z.toDouble())
                val br = project(quad.bottomRight.x.toDouble(), quad.bottomRight.y.toDouble(), quad.bottomRight.z.toDouble())
                val bl = project(quad.bottomLeft.x.toDouble(), quad.bottomLeft.y.toDouble(), quad.bottomLeft.z.toDouble())
                val destination = floatArrayOf(
                    sx(tl), sy(tl), sx(tr), sy(tr), sx(br), sy(br), sx(bl), sy(bl)
                )
                val matrix = Matrix()
                if (matrix.setPolyToPoly(source, 0, destination, 0, 4)) {
                    logoCanvas.drawBitmap(logo, matrix, logoPaint)
                    logoLayer.getPixels(layerPixels, 0, width, 0, 0, width, height)
                    raster.compositeLayerTriangle(
                        depthVertex(tl), depthVertex(tr), depthVertex(br), layerPixels
                    )
                    raster.compositeLayerTriangle(
                        depthVertex(tl), depthVertex(br), depthVertex(bl), layerPixels
                    )
                }
            }
            logoLayer.recycle()
            logo.recycle()
        }

        bitmap.setPixels(raster.pixels, 0, width, 0, 0, width, height)

        // Technical annotations are rendered independently of GLSurfaceView, so PDF/list images
        // use the same semantic dimensions and the same actual model snapshot.
        val dimensionLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(31, 108, 52)
            style = Paint.Style.STROKE
            strokeWidth = max(1.0f, min(width, height) / 520f)
        }
        val dimensionText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(27, 58, 37)
            textAlign = Paint.Align.CENTER
            textSize = max(11f, min(width, height) * 0.025f)
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        }
        val dimensionBox = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(242, 255, 253, 246)
            style = Paint.Style.FILL
        }
        val occupied = mutableListOf<RectF>()
        val modelCenterX = width / 2f
        val modelCenterY = height / 2f
        val dimensionCandidates = mesh.dimensions.groupBy { it.dimensionId }.map { (_, candidates) ->
            candidates.maxBy { dimension ->
                val a = project(dimension.witnessStart.x.toDouble(), dimension.witnessStart.y.toDouble(), dimension.witnessStart.z.toDouble())
                val b = project(dimension.witnessEnd.x.toDouble(), dimension.witnessEnd.y.toDouble(), dimension.witnessEnd.z.toDouble())
                (a.depth + b.depth) / 2.0
            }
        }.sortedWith(compareBy<RoofDimension3D> {
            when (it.kind) {
                RoofDimensionKind.WALL_HEIGHT -> 0
                RoofDimensionKind.ATTIC_HEIGHT -> 1
                RoofDimensionKind.CHIMNEY_HEIGHT -> 2
                RoofDimensionKind.CHIMNEY_WIDTH, RoofDimensionKind.CHIMNEY_LENGTH -> 3
                RoofDimensionKind.ROOF_WINDOW_WIDTH, RoofDimensionKind.ROOF_WINDOW_LENGTH -> 4
                RoofDimensionKind.SLOPE -> 5
                RoofDimensionKind.OVERHANG -> 6
                RoofDimensionKind.PLAN_LENGTH -> 7
            }
        })
        dimensionCandidates.forEach { dimension ->
            val projectedA = project(
                dimension.witnessStart.x.toDouble(), dimension.witnessStart.y.toDouble(), dimension.witnessStart.z.toDouble()
            )
            val projectedB = project(
                dimension.witnessEnd.x.toDouble(), dimension.witnessEnd.y.toDouble(), dimension.witnessEnd.z.toDouble()
            )
            val ax = sx(projectedA); val ay = sy(projectedA)
            val bx = sx(projectedB); val by = sy(projectedB)
            val edgeLength = hypot(bx - ax, by - ay).coerceAtLeast(1f)
            var nx = -(by - ay) / edgeLength
            var ny = (bx - ax) / edgeLength
            val midX = (ax + bx) / 2f
            val midY = (ay + by) / 2f
            fun score(sign: Float): Int {
                var result = 0
                floatArrayOf(18f, 34f, 56f, 82f).forEach { distance ->
                    floatArrayOf(0.18f, 0.5f, 0.82f).forEach { t ->
                        if (raster.isCovered(
                                ax + (bx - ax) * t + nx * sign * distance,
                                ay + (by - ay) * t + ny * sign * distance
                            )) result++
                    }
                }
                return result
            }
            val positiveScore = score(1f)
            val negativeScore = score(-1f)
            if (negativeScore < positiveScore ||
                (negativeScore == positiveScore && nx * (midX - modelCenterX) + ny * (midY - modelCenterY) < 0f)
            ) {
                nx = -nx; ny = -ny
            }
            val drawWitnessLines = minOf(positiveScore, negativeScore) == 0
            val text = when (dimension.kind) {
                RoofDimensionKind.PLAN_LENGTH -> String.format(Locale("sk", "SK"), "%,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.WALL_HEIGHT -> String.format(Locale("sk", "SK"), "H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ATTIC_HEIGHT -> String.format(Locale("sk", "SK"), "Atika  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.OVERHANG -> String.format(Locale("sk", "SK"), "Presah  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.SLOPE -> String.format(Locale("sk", "SK"), "\u2220  %.1f\u00B0", dimension.lengthM)
                RoofDimensionKind.CHIMNEY_WIDTH -> String.format(Locale("sk", "SK"), "Komín Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_LENGTH -> String.format(Locale("sk", "SK"), "Komín D  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.CHIMNEY_HEIGHT -> String.format(Locale("sk", "SK"), "Komín H  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_WIDTH -> String.format(Locale("sk", "SK"), "Okno Š  %,.0f mm", dimension.lengthM * 1000.0)
                RoofDimensionKind.ROOF_WINDOW_LENGTH -> String.format(Locale("sk", "SK"), "Okno D  %,.0f mm", dimension.lengthM * 1000.0)
            }
            val halfWidth = dimensionText.measureText(text) / 2f + min(width, height) * 0.014f
            val halfHeight = dimensionText.textSize * 0.85f
            var placement: Triple<Pair<Float, Float>, Pair<Float, Float>, RectF>? = null
            for (level in 0..4) {
                val distance = min(width, height) * (0.035f + level * 0.042f)
                val start = (ax + nx * distance) to (ay + ny * distance)
                val end = (bx + nx * distance) to (by + ny * distance)
                val cx = (start.first + end.first) / 2f
                val cy = (start.second + end.second) / 2f
                val box = RectF(cx - halfWidth, cy - halfHeight, cx + halfWidth, cy + halfHeight)
                if (box.left >= 3f && box.top >= 3f && box.right <= width - 3f && box.bottom <= height - 3f &&
                    occupied.none { RectF.intersects(it, box) }
                ) {
                    placement = Triple(start, end, box)
                    break
                }
            }
            val selected = placement ?: return@forEach
            if (drawWitnessLines) {
                canvas.drawLine(ax, ay, selected.first.first, selected.first.second, dimensionLine)
                canvas.drawLine(bx, by, selected.second.first, selected.second.second, dimensionLine)
            }
            canvas.drawLine(
                selected.first.first, selected.first.second,
                selected.second.first, selected.second.second,
                dimensionLine
            )
            canvas.drawRoundRect(selected.third, 6f, 6f, dimensionBox)
            canvas.drawRoundRect(selected.third, 6f, 6f, dimensionLine)
            val baseline = selected.third.centerY() - (dimensionText.ascent() + dimensionText.descent()) / 2f
            canvas.drawText(text, selected.third.centerX(), baseline, dimensionText)
            occupied += RectF(selected.third)
        }
        canvas.drawRect(RectF(0.5f, 0.5f, width - 0.5f, height - 0.5f), frame)
        return bitmap
    }
}
