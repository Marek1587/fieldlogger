# StrechoStav Sketch 3.7.19 – trvalá poloha navigácie a aktívne nástroje

## Navigácia pracovných kariet

`MainActivity` uchováva vodorovnú polohu pásu pracovných kariet v `workspaceNavigationScrollX`.
Každá nová obrazovka obnoví túto polohu až po zmeraní pásu, obmedzí ju na jeho skutočný rozsah
a posunie ju iba o nevyhnutné minimum, ak by zvolená karta nebola viditeľná. Hodnota sa zároveň
ukladá do `Bundle`, takže prežije aj opätovné vytvorenie aktivity.

## Jednotný aktívny stav

Aktívna karta a aktívny nástroj používajú spoločný stavový renderer. Aktívny prvok má sýtu zelenú
výplň, kontrastný žltý rám, plnú nepriehľadnosť a mierne vyvýšenie. Neaktívne prvky sú tmavšie
a vizuálne ustupujú. Stav `isSelected` a popis `Aktívne:` zostávajú dostupné aj pomocným
technológiám.

`FreeRoofMapHost` sprostredkuje zmenu režimu editora aj prepnutie mapového podkladu obrazovke.
Zvýraznenie preto vychádza zo skutočného `EditorMode`, `ObjectType` a režimu podkladu, nie iba
z naposledy stlačeného tlačidla.

## Spätná kompatibilita

Zmena nemení formát projektu, RoofGraph, solver, 3D model, výkaz ani exporty. Ide o stav používateľského
rozhrania; existujúce JSON projekty sa načítajú bez migrácie.
