# StrechoStav Sketch 3.7.14 – parametrický pôdorysný rozmer

## Identita hrany

Editor už nepredpokladá, že poradie bodov v legacy polygóne je totožné s poradím
kanonického `RoofGraph`. Hrana sa vyhľadá podľa oboch skutočných koncov v lokálnych
metroch, nezávisle od smeru a cyklického začiatku obvodu.

## Solver protiľahlej steny

`ParametricEditSolver.setBoundaryDimension` vyhľadá rovnobežné obvodové hrany
s uhlovou toleranciou 5° a vyberie najdlhšiu skutočne protiľahlú hranu. Posúva súvislý
oblúk uzlov medzi vybranou a protiľahlou hranou. Tým sa zmenia iba dve podporné steny,
ostatné segmenty sa translatujú bez zmeny dĺžky a pravé uhly ostávajú zachované.

Pri obdĺžniku majú obe spárované hrany cieľový rozmer. Pri L/T/H pôdoryse sa na
najdlhšiu protiľahlú hranu aplikuje rovnaká zmena dĺžky; kratšie paralelné časti
ostávajú nedotknuté.

## Jedna geometrická transakcia

`ProjectPlanSynchronizer` prenáša deformáciu kanonického grafu do:

- `project.polygon`,
- `project.wallFootprint`,
- technických objektov na streche,
- `roofTopology` a legacy zrkadiel línií.

Pôdorys muriva sa emitá v rovnakom kanonickom poradí ako obvod grafu. Odkvapový presah
sa nemení na nulu: 3D koliesko aplikuje rozdiel rozmeru na strechu aj murivo, takže ich
existujúce odsadenie ostáva zachované.

## Regresné testy

Testy pokrývajú obdĺžnik, L pôdorys s viacerými rovnobežnými kandidátmi, zachovanie
90° rohov a synchronizáciu odsadeného pôdorysu stien so zmenenou strechou.
