# StrechoStav Sketch 3.7.4

## Technické kóty a skryté čiary

Interaktívny OpenGL renderer vyhodnocuje obe možné strany kóty proti projekcii nepriehľadných trojuholníkov. Zvolí stranu s menším prekrytím a ak by pomocná čiara prechádzala viditeľnou plochou, nevykreslí ju. Hrany používajú striktný depth test. Statický bitmapový/PDF renderer vykonáva rovnaký výber nad softvérovým pixelovým depth bufferom.

Pôdorysné kóty sú viazané na základovú hranu `wallBottom`, nie na odkvap ani hornú hranu steny. Komíny publikujú samostatné parametrické kóty šírky, dĺžky a výšky; strešné okná šírku a dĺžku. Atika naďalej publikuje spoločnú výškovú kótu pre všetky atikové hrany.

## Jednotné kruhové koliesko

`DimensionDialView` je natívna Kotlin/Canvas implementácia interakcie z `sikma_polvalbova_stn.php`: 60 dielikov, krok po 15°, haptická odozva, stredové OK a ochranné oneskorenie potvrdenia. Používa sa pre geometriu, výšky, sklony, objekty, množstvá aj ceny.
