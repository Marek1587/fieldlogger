package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Geometric overhang solver.
 *
 * Eaves and gables form one continuous roof perimeter. Parapets remain on the wall
 * line and never receive an overhang. Every contour is solved as a joined offset
 * polygon, therefore neighbouring sections use exactly the same miter vertex instead
 * of drawing two independent, overlapping rectangular strips.
 */
internal object RoofOverhangSolver {
    const val DEFAULT_FLAT_SOFFIT_DEPTH_M = 0.20
    const val DEFAULT_ROOF_SHELL_THICKNESS_M = 0.18

    internal data class Section(
        val edgeId: String,
        val semanticRole: EdgeSemantic,
        val outerTopA: GraphNode,
        val outerTopB: GraphNode,
        val outerBottomA: GraphNode,
        val outerBottomB: GraphNode,
        val flatInnerA: GraphNode,
        val flatInnerB: GraphNode,
        val wallInnerA: GraphNode,
        val wallInnerB: GraphNode,
        val overhangM: Double,
        val flatDepthM: Double
    )

    internal data class Solution(
        val eligibleEdgeIds: List<String>,
        val representativeOverhangM: Double,
        val sections: List<Section>
    )

    internal data class GableProfileSupport(val t: Double, val node: GraphNode)

    private data class SupportLine(
        val point: LocalPoint,
        val dx: Double,
        val dy: Double,
        val normalX: Double,
        val normalY: Double,
        val distance: Double
    )

    private fun supportsOverhang(role: EdgeSemantic): Boolean =
        role == EdgeSemantic.EAVE || role == EdgeSemantic.GABLE

    private fun cross(ax: Double, ay: Double, bx: Double, by: Double) = ax * by - ay * bx

    /**
     * Produces one mitered contour. The output has one point per input corner. A point
     * is consequently shared by the previous and next section, including hip corners.
     * Collinear solver-created gable splits are retained without making the contour fail.
     */
    internal fun selectiveWallFootprint(
        points: List<LocalPoint>,
        roles: List<EdgeSemantic>,
        overhangM: Double
    ): List<LocalPoint>? {
        if (points.size < 3 || roles.size != points.size || overhangM < 0.0) return null
        if (overhangM <= 1e-9) return points.map { it.copy() }

        val eligibleLengths = points.indices.mapNotNull { index ->
            if (!supportsOverhang(roles[index])) null else {
                val a = points[index]
                val b = points[(index + 1) % points.size]
                hypot(b.x - a.x, b.y - a.y)
            }
        }
        if (eligibleLengths.isEmpty()) return null
        // Do not limit by the shortest segment: a ridge incidence or an L-notch can
        // legitimately create a very short boundary fragment while the common overhang
        // remains valid. Final polygon validation below is the authoritative guard.
        val modelSpan = maxOf(
            points.maxOf { it.x } - points.minOf { it.x },
            points.maxOf { it.y } - points.minOf { it.y }
        ).coerceAtLeast(1e-9)
        if (overhangM >= modelSpan * 0.45) return null

        val twiceArea = points.indices.sumOf { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            a.x * b.y - b.x * a.y
        }
        val orientation = if (twiceArea >= 0.0) 1.0 else -1.0
        val lines = points.indices.map { index ->
            val a = points[index]
            val b = points[(index + 1) % points.size]
            val dx = b.x - a.x
            val dy = b.y - a.y
            val length = hypot(dx, dy).coerceAtLeast(1e-9)
            val distance = if (supportsOverhang(roles[index])) overhangM else 0.0
            val nx = -dy / length * orientation
            val ny = dx / length * orientation
            SupportLine(
                point = LocalPoint(a.x + nx * distance, a.y + ny * distance),
                dx = dx,
                dy = dy,
                normalX = nx,
                normalY = ny,
                distance = distance
            )
        }

        val result = lines.indices.map { index ->
            val previous = lines[(index - 1 + lines.size) % lines.size]
            val current = lines[index]
            val denominator = cross(previous.dx, previous.dy, current.dx, current.dy)
            if (abs(denominator) < 1e-9) {
                // A ridge incidence can split one physical gable into two collinear
                // boundary edges. Both edges must keep one common offset support point.
                val vertex = points[index]
                val px = vertex.x + previous.normalX * previous.distance
                val py = vertex.y + previous.normalY * previous.distance
                val cx = vertex.x + current.normalX * current.distance
                val cy = vertex.y + current.normalY * current.distance
                LocalPoint((px + cx) / 2.0, (py + cy) / 2.0)
            } else {
                val qx = current.point.x - previous.point.x
                val qy = current.point.y - previous.point.y
                val t = cross(qx, qy, current.dx, current.dy) / denominator
                LocalPoint(previous.point.x + previous.dx * t, previous.point.y + previous.dy * t)
            }
        }
        if (result.any { !it.x.isFinite() || !it.y.isFinite() }) return null
        val resultArea = abs(result.indices.sumOf { index ->
            val a = result[index]
            val b = result[(index + 1) % result.size]
            a.x * b.y - b.x * a.y
        }) / 2.0
        if (resultArea <= 1e-5 || result.any { point ->
                !Geometry.pointInPolygon(point, points) && points.indices.none { index ->
                    Geometry.distanceToSegment(point, points[index], points[(index + 1) % points.size]) <= 1e-5
                }
            }
        ) return null
        return result
    }

    /** EAVE and GABLE supports move; ATTIC and all other roles stay fixed. */
    fun selectiveWallFootprint(graph: RoofGraph, overhangM: Double): List<LocalPoint>? {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology()) ?: return null
        val points = ordered.first.mapNotNull(graph.nodes::get).map { LocalPoint(it.x, it.y) }
        val roles = ordered.second.map { graph.edges[it.id]?.semanticRole ?: EdgeSemantic.UNKNOWN }
        return selectiveWallFootprint(points, roles, overhangM)
    }

    /**
     * Projects solver incidence nodes (especially a ridge endpoint) from the outer
     * gable edge to its inset masonry edge. This is a derived construction node: it
     * fills the gable but never splits the saved physical wall or adds a facade seam.
     */
    fun gableProfileSupports(
        graph: RoofGraph,
        roofA: LocalPoint,
        roofB: LocalPoint,
        wallA: LocalPoint,
        wallB: LocalPoint,
        wallHeightM: Double,
        toleranceM: Double
    ): List<GableProfileSupport> {
        val roofDx = roofB.x - roofA.x
        val roofDy = roofB.y - roofA.y
        val roofLengthSquared = roofDx * roofDx + roofDy * roofDy
        if (roofLengthSquared <= 1e-10) return emptyList()
        val wallDx = wallB.x - wallA.x
        val wallDy = wallB.y - wallA.y
        val boundaryNodeIds = graph.edges.values.asSequence()
            .filter { it.boundary }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
            .toSet()
        val incidenceNodeIds = graph.edges.values.asSequence()
            .filter { it.semanticRole == EdgeSemantic.RIDGE }
            .flatMap { sequenceOf(it.startNodeId, it.endNodeId) }
            .toSet()
        return (boundaryNodeIds + incidenceNodeIds).mapNotNull(graph.nodes::get)
            .mapNotNull { source ->
                val t = ((source.x - roofA.x) * roofDx + (source.y - roofA.y) * roofDy) /
                    roofLengthSquared
                if (t !in -1e-6..1.000001 ||
                    Geometry.distanceToSegment(LocalPoint(source.x, source.y), roofA, roofB) > toleranceM
                ) return@mapNotNull null
                val clamped = t.coerceIn(0.0, 1.0)
                GableProfileSupport(
                    clamped,
                    GraphNode(
                        id = "gable-wall-support-${source.id}",
                        x = wallA.x + wallDx * clamped,
                        y = wallA.y + wallDy * clamped,
                        z = maxOf(wallHeightM, source.z)
                    )
                )
            }
            .sortedBy { it.t }
    }

    fun solve(
        graph: RoofGraph,
        wallLoop: List<LocalPoint>,
        roofThicknessM: Double = DEFAULT_ROOF_SHELL_THICKNESS_M,
        flatSoffitDepthM: Double = DEFAULT_FLAT_SOFFIT_DEPTH_M
    ): Solution {
        val ordered = RoofTopologyMigration.orderedBoundary(graph.toTopology())
            ?: return Solution(emptyList(), 0.0, emptyList())
        val nodes = ordered.first.mapNotNull(graph.nodes::get)
        val edges = ordered.second.mapNotNull { graph.edges[it.id] }
        if (nodes.size < 3 || edges.size != nodes.size || wallLoop.size < 3) {
            return Solution(emptyList(), 0.0, emptyList())
        }
        val roles = edges.map { it.semanticRole }
        val eligibleIds = edges.filter { supportsOverhang(it.semanticRole) }.map { it.id }
        if (eligibleIds.isEmpty()) return Solution(emptyList(), 0.0, emptyList())

        data class Candidate(val edge: GraphEdge, val plane: RoofPlane, val measuredDepth: Double)

        fun raySegmentDepth(origin: LocalPoint, dx: Double, dy: Double): Double? {
            var best = Double.POSITIVE_INFINITY
            wallLoop.indices.forEach { index ->
                val a = wallLoop[index]
                val b = wallLoop[(index + 1) % wallLoop.size]
                val sx = b.x - a.x
                val sy = b.y - a.y
                val denominator = cross(dx, dy, sx, sy)
                if (abs(denominator) <= 1e-10) return@forEach
                val qx = a.x - origin.x
                val qy = a.y - origin.y
                val t = cross(qx, qy, sx, sy) / denominator
                val u = cross(qx, qy, dx, dy) / denominator
                if (t >= -1e-7 && u in -1e-7..1.0000001 && t < best) best = t
            }
            return best.takeIf { it.isFinite() }?.coerceAtLeast(0.0)
        }

        val candidates = edges.mapIndexed { index, edge ->
            if (!supportsOverhang(edge.semanticRole)) return@mapIndexed null
            val a = nodes[index]
            val b = nodes[(index + 1) % nodes.size]
            val face = edge.adjacentFaceIds.asSequence().mapNotNull(graph.faces::get)
                .firstOrNull { it.plane != null } ?: return@mapIndexed null
            val plane = face.plane ?: return@mapIndexed null
            val length = hypot(b.x - a.x, b.y - a.y)
            if (length <= 1e-8) return@mapIndexed null
            val mid = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
            val faceNodes = face.orderedNodeIds.mapNotNull(graph.nodes::get)
            val faceCenterX = faceNodes.map { it.x }.average()
            val faceCenterY = faceNodes.map { it.y }.average()
            var nx = -(b.y - a.y) / length
            var ny = (b.x - a.x) / length
            if ((faceCenterX - mid.x) * nx + (faceCenterY - mid.y) * ny < 0.0) {
                nx = -nx
                ny = -ny
            }
            Candidate(edge, plane, raySegmentDepth(mid, nx, ny) ?: 0.0)
        }
        val positiveDepths = candidates.mapNotNull { it?.measuredDepth }
            .filter { it > 0.001 }.sorted()
        val representative = when {
            positiveDepths.isEmpty() -> 0.0
            positiveDepths.size % 2 == 1 -> positiveDepths[positiveDepths.size / 2]
            else -> (positiveDepths[positiveDepths.size / 2 - 1] + positiveDepths[positiveDepths.size / 2]) / 2.0
        }
        if (representative <= 0.001) return Solution(eligibleIds, 0.0, emptyList())

        val points = nodes.map { LocalPoint(it.x, it.y) }
        val innerContour = selectiveWallFootprint(points, roles, representative)
            ?: return Solution(eligibleIds, representative, emptyList())
        val flatDepth = minOf(flatSoffitDepthM.coerceAtLeast(0.0), representative)
        val flatContour = selectiveWallFootprint(points, roles, flatDepth)
            ?: return Solution(eligibleIds, representative, emptyList())
        val shellThickness = roofThicknessM.coerceIn(0.05, 0.60)

        fun incidentCandidates(vertexIndex: Int): List<Candidate> = listOfNotNull(
            candidates[(vertexIndex - 1 + candidates.size) % candidates.size],
            candidates[vertexIndex]
        )

        fun averagePlaneZ(vertexIndex: Int, point: LocalPoint): Double {
            val incident = incidentCandidates(vertexIndex)
            return if (incident.isEmpty()) nodes[vertexIndex].z
            else incident.map { it.plane.zAt(point.x, point.y) }.average()
        }

        fun flatZ(vertexIndex: Int): Double {
            val incidentIndices = listOf(
                (vertexIndex - 1 + edges.size) % edges.size,
                vertexIndex
            )
            val touchesEave = incidentIndices.any { roles[it] == EdgeSemantic.EAVE }
            return if (touchesEave) nodes[vertexIndex].z - shellThickness
            else averagePlaneZ(vertexIndex, flatContour[vertexIndex]) - shellThickness
        }

        fun node(id: String, point: LocalPoint, z: Double) = GraphNode(id, point.x, point.y, z)
        val outerBottom = nodes.mapIndexed { index, roofNode ->
            roofNode.copy(id = "overhang-fascia-${roofNode.id}", z = roofNode.z - shellThickness)
        }
        val flatInner = nodes.indices.map { index ->
            node("overhang-soffit-${nodes[index].id}", flatContour[index], flatZ(index))
        }
        val wallInner = nodes.indices.map { index ->
            node(
                "overhang-wall-${nodes[index].id}",
                innerContour[index],
                averagePlaneZ(index, innerContour[index]) - shellThickness
            )
        }

        val sections = edges.indices.mapNotNull { index ->
            val candidate = candidates[index] ?: return@mapNotNull null
            val next = (index + 1) % nodes.size
            Section(
                edgeId = candidate.edge.id,
                semanticRole = candidate.edge.semanticRole,
                outerTopA = nodes[index],
                outerTopB = nodes[next],
                outerBottomA = outerBottom[index],
                outerBottomB = outerBottom[next],
                flatInnerA = flatInner[index],
                flatInnerB = flatInner[next],
                wallInnerA = wallInner[index],
                wallInnerB = wallInner[next],
                overhangM = representative,
                flatDepthM = flatDepth
            )
        }
        return Solution(eligibleIds, representative, sections)
    }
}
