package sk.strechasketch.app

import kotlin.math.hypot

/**
 * Applies one plan deformation to every project representation that owns XY geometry.
 * RoofGraph remains canonical; polygon, wall footprint and technical objects are mirrors.
 */
object ProjectPlanSynchronizer {
    fun apply(
        project: RoofProject,
        beforeGraph: RoofGraph,
        afterGraph: RoofGraph,
        sourceWallFootprint: List<GeoPoint> = project.wallFootprint.map(GeoPoint::copy),
        sourceObjects: List<RoofObject> = project.objects.map { it.copy(center = it.center.copy()) }
    ): Boolean {
        val beforeBoundary = boundaryNodes(beforeGraph) ?: return false
        val afterBoundary = boundaryNodes(afterGraph) ?: return false
        if (beforeBoundary.map { it.id } != afterBoundary.map { it.id }) return false

        val displacementById = beforeBoundary.indices.associate { index ->
            val before = beforeBoundary[index]
            val after = afterBoundary[index]
            before.id to LocalPoint(after.x - before.x, after.y - before.y)
        }
        val transformedWalls = transformLoop(
            sourceWallFootprint,
            beforeGraph.origin,
            beforeBoundary,
            displacementById
        )
        val transformedObjects = sourceObjects.map { item ->
            item.copy(center = transformPoint(item.center, beforeGraph.origin, beforeBoundary, displacementById))
        }

        val applied = RoofTopologyMigration.applyToProject(
            project,
            afterGraph.toTopology(),
            requireFullyValid = false
        )
        if (!applied.applied) return false
        project.roofGraph = afterGraph
        project.roofTopology = afterGraph.toTopology()
        project.wallFootprint = transformedWalls.toMutableList()
        project.objects = transformedObjects.toMutableList()
        return true
    }

    private fun boundaryNodes(graph: RoofGraph): List<GraphNode>? {
        val ids = RoofTopologyMigration.orderedBoundary(graph.toTopology())?.first ?: return null
        return ids.map { graph.nodes[it] ?: return null }
    }

    private fun transformLoop(
        loop: List<GeoPoint>,
        origin: GeoPoint,
        boundary: List<GraphNode>,
        displacementById: Map<String, LocalPoint>
    ): List<GeoPoint> {
        if (loop.isEmpty()) return emptyList()
        val local = loop.map { Geometry.toLocal(it, origin) }
        if (local.size == boundary.size) {
            val mapping = bestCyclicMapping(local, boundary)
            if (mapping != null) {
                // Emit the wall loop in canonical boundary order. This also keeps the 3D base
                // dimension index attached to the same real graph edge after a cyclic reorder.
                return boundary.indices.map { supportIndex ->
                    val index = mapping.indexOf(supportIndex)
                    val support = boundary[supportIndex]
                    val delta = displacementById.getValue(support.id)
                    Geometry.toGeo(LocalPoint(local[index].x + delta.x, local[index].y + delta.y), origin)
                }
            }
        }
        return loop.map { transformPoint(it, origin, boundary, displacementById) }
    }

    /** Aligns an inset wall loop with the roof corners independent of cyclic start/winding. */
    private fun bestCyclicMapping(local: List<LocalPoint>, boundary: List<GraphNode>): IntArray? {
        if (local.size != boundary.size || local.isEmpty()) return null
        val count = local.size
        var bestScore = Double.POSITIVE_INFINITY
        var best: IntArray? = null
        listOf(1, -1).forEach { direction ->
            for (shift in 0 until count) {
                val mapping = IntArray(count) { index ->
                    ((shift + direction * index) % count + count) % count
                }
                val score = local.indices.sumOf { index ->
                    val support = boundary[mapping[index]]
                    hypot(local[index].x - support.x, local[index].y - support.y)
                }
                if (score < bestScore) {
                    bestScore = score
                    best = mapping
                }
            }
        }
        return best
    }

    private fun transformPoint(
        point: GeoPoint,
        origin: GeoPoint,
        boundary: List<GraphNode>,
        displacementById: Map<String, LocalPoint>
    ): GeoPoint {
        val local = Geometry.toLocal(point, origin)
        var totalWeight = 0.0
        var dx = 0.0
        var dy = 0.0
        boundary.forEach { support ->
            val distance2 = (local.x - support.x) * (local.x - support.x) +
                (local.y - support.y) * (local.y - support.y)
            if (distance2 < 1e-10) {
                val exact = displacementById.getValue(support.id)
                return Geometry.toGeo(LocalPoint(local.x + exact.x, local.y + exact.y), origin)
            }
            val weight = 1.0 / distance2.coerceAtLeast(0.01)
            val delta = displacementById.getValue(support.id)
            totalWeight += weight
            dx += delta.x * weight
            dy += delta.y * weight
        }
        if (totalWeight > 0.0) {
            dx /= totalWeight
            dy /= totalWeight
        }
        return Geometry.toGeo(LocalPoint(local.x + dx, local.y + dy), origin)
    }
}
