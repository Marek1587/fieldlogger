package sk.strechasketch.app

import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Screen-space vertex. inverseDepth is 1 / camera-space W; larger is nearer. */
internal data class DepthVertex(val x: Float, val y: Float, val inverseDepth: Float)

/**
 * Deterministic per-pixel depth buffer used by static/PDF rendering.
 *
 * Unlike painter sorting, this resolves intersecting and concave roof faces, wall occlusion and
 * hidden technical edges at the same pixel granularity as a GPU depth test.
 */
internal class SoftwareDepthRasterizer(
    val width: Int,
    val height: Int,
    backgroundColor: Int
) {
    val pixels = IntArray(width * height) { backgroundColor }
    private val depth = FloatArray(width * height) { Float.NEGATIVE_INFINITY }

    fun fillTriangle(a: DepthVertex, b: DepthVertex, c: DepthVertex, color: Int) {
        forEachTrianglePixel(a, b, c) { index, _, _, _, inverseDepth ->
            if (inverseDepth > depth[index]) {
                depth[index] = inverseDepth
                pixels[index] = color
            }
        }
    }

    /** Draws only the fragments that are not hidden by a previously rasterized surface. */
    fun drawDepthTestedLine(
        a: DepthVertex,
        b: DepthVertex,
        color: Int,
        thicknessPx: Float,
        depthBias: Float = 0.0008f
    ) {
        val dx = b.x - a.x
        val dy = b.y - a.y
        val steps = ceil(max(abs(dx), abs(dy)).toDouble() * 1.5).toInt().coerceAtLeast(1)
        val radius = max(0, (thicknessPx / 2f).roundToInt())
        for (step in 0..steps) {
            val t = step.toFloat() / steps
            val centerX = (a.x + dx * t).roundToInt()
            val centerY = (a.y + dy * t).roundToInt()
            val inverseDepth = a.inverseDepth + (b.inverseDepth - a.inverseDepth) * t
            for (py in centerY - radius..centerY + radius) {
                if (py !in 0 until height) continue
                for (px in centerX - radius..centerX + radius) {
                    if (px !in 0 until width) continue
                    if (radius > 0) {
                        val ddx = px - centerX
                        val ddy = py - centerY
                        if (ddx * ddx + ddy * ddy > radius * radius + 1) continue
                    }
                    val index = py * width + px
                    if (inverseDepth + depthBias >= depth[index]) pixels[index] = color
                }
            }
        }
    }

    /** Composites an already warped transparent layer through the same depth test. */
    fun compositeLayerTriangle(
        a: DepthVertex,
        b: DepthVertex,
        c: DepthVertex,
        layer: IntArray,
        depthBias: Float = 0.0012f
    ) {
        require(layer.size == pixels.size)
        forEachTrianglePixel(a, b, c) { index, _, _, _, inverseDepth ->
            val source = layer[index]
            val alpha = source ushr 24
            if (alpha > 0 && inverseDepth + depthBias >= depth[index]) {
                pixels[index] = alphaBlend(source, pixels[index])
            }
        }
    }

    internal fun depthAt(x: Int, y: Int): Float = depth[y * width + x]

    internal fun isCovered(x: Float, y: Float): Boolean {
        val px = x.roundToInt()
        val py = y.roundToInt()
        return px in 0 until width && py in 0 until height &&
            depth[py * width + px] > Float.NEGATIVE_INFINITY
    }

    private inline fun forEachTrianglePixel(
        a: DepthVertex,
        b: DepthVertex,
        c: DepthVertex,
        action: (index: Int, wa: Float, wb: Float, wc: Float, inverseDepth: Float) -> Unit
    ) {
        val area = edge(a.x, a.y, b.x, b.y, c.x, c.y)
        if (abs(area) < 1e-7f) return
        val minX = max(0, kotlin.math.floor(min(a.x, min(b.x, c.x)).toDouble()).toInt())
        val maxX = min(width - 1, ceil(max(a.x, max(b.x, c.x)).toDouble()).toInt())
        val minY = max(0, kotlin.math.floor(min(a.y, min(b.y, c.y)).toDouble()).toInt())
        val maxY = min(height - 1, ceil(max(a.y, max(b.y, c.y)).toDouble()).toInt())
        val epsilon = -1e-5f
        for (y in minY..maxY) {
            val py = y + 0.5f
            for (x in minX..maxX) {
                val px = x + 0.5f
                val wa = edge(b.x, b.y, c.x, c.y, px, py) / area
                val wb = edge(c.x, c.y, a.x, a.y, px, py) / area
                val wc = 1f - wa - wb
                if (wa >= epsilon && wb >= epsilon && wc >= epsilon) {
                    action(
                        y * width + x,
                        wa, wb, wc,
                        wa * a.inverseDepth + wb * b.inverseDepth + wc * c.inverseDepth
                    )
                }
            }
        }
    }

    private fun edge(ax: Float, ay: Float, bx: Float, by: Float, px: Float, py: Float): Float =
        (px - ax) * (by - ay) - (py - ay) * (bx - ax)

    private fun alphaBlend(source: Int, destination: Int): Int {
        val alpha = source ushr 24
        if (alpha >= 255) return source
        val inverse = 255 - alpha
        fun channel(shift: Int): Int =
            ((((source ushr shift) and 0xff) * alpha + ((destination ushr shift) and 0xff) * inverse + 127) / 255)
        return (0xff shl 24) or (channel(16) shl 16) or (channel(8) shl 8) or channel(0)
    }
}
