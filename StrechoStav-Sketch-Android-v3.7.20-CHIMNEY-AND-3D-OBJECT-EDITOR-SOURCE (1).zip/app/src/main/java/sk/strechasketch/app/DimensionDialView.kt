package sk.strechasketch.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Native counterpart of the circular dimension dial from sikma_polvalbova_stn.php. */
class DimensionDialView(context: Context) : View(context) {
    var title: String = "ROZMER"
    var unit: String = " mm"
    var decimals: Int = 0
    var minimum: Double = 0.0
    var maximum: Double = 100_000.0
    var step: Double = 1.0
    var value: Double = 0.0
        set(newValue) {
            field = snap(newValue)
            invalidate()
        }
    var onValueChanged: ((Double) -> Unit)? = null
    var onConfirm: ((Double) -> Unit)? = null

    private val density = resources.displayMetrics.density.coerceAtLeast(1f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
    }
    private var dragging = false
    private var pressedOk = false
    private var lastAngle = 0f
    private var accumulatedAngle = 0f
    private var visualAngle = 0f
    private var okEnabledAt = 0L

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Otočné koliesko na nastavenie rozmeru"
    }

    fun armConfirmation(delayMs: Long = 1_000L) {
        okEnabledAt = SystemClock.uptimeMillis() + delayMs
        postInvalidateOnAnimation()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val desired = (390f * density).toInt()
        val width = resolveSize(desired, widthMeasureSpec)
        val height = resolveSize(desired, heightMeasureSpec)
        setMeasuredDimension(width, height)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f + size * 0.045f
        val radius = size * 0.405f

        textPaint.color = Color.rgb(55, 65, 81)
        textPaint.textSize = 12f * density
        canvas.drawText(title.uppercase(Locale("sk", "SK")), cx, size * 0.075f, textPaint)

        val valueText = formattedValue()
        textPaint.textSize = 23f * density
        val valueWidth = textPaint.measureText(valueText) + 30f * density
        val valueRect = RectF(
            cx - valueWidth / 2f, size * 0.095f,
            cx + valueWidth / 2f, size * 0.095f + 43f * density
        )
        paint.color = Color.argb(238, 255, 255, 255)
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(valueRect, 24f * density, 24f * density, paint)
        paint.color = Color.argb(25, 0, 0, 0)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = density
        canvas.drawRoundRect(valueRect, 24f * density, 24f * density, paint)
        textPaint.color = Color.rgb(31, 41, 55)
        canvas.drawText(valueText, cx, valueRect.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)

        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(Color.rgb(244, 244, 244), Color.rgb(236, 236, 236), Color.rgb(217, 217, 217)),
            floatArrayOf(0f, 0.58f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 12f * density
        paint.color = Color.argb(72, 88, 96, 110)
        canvas.drawCircle(cx, cy, radius - 6f * density, paint)

        canvas.save()
        canvas.rotate(visualAngle, cx, cy)
        for (index in 0 until 60) {
            val angle = Math.toRadians(index * 6.0 - 90.0)
            val major = index % 5 == 0
            val inner = radius - (if (major) 28f else 20f) * density
            val outer = radius - 8f * density
            paint.strokeWidth = (if (major) 1.7f else 1f) * density
            paint.color = if (major) Color.rgb(79, 86, 99) else Color.rgb(123, 132, 147)
            canvas.drawLine(
                cx + cos(angle).toFloat() * inner, cy + sin(angle).toFloat() * inner,
                cx + cos(angle).toFloat() * outer, cy + sin(angle).toFloat() * outer,
                paint
            )
        }
        canvas.restore()

        val okRadius = radius * 0.29f
        val enabled = SystemClock.uptimeMillis() >= okEnabledAt
        paint.style = Paint.Style.FILL
        paint.color = if (enabled) Color.argb(242, 255, 255, 255) else Color.argb(160, 225, 225, 225)
        canvas.drawCircle(cx, cy, okRadius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = density
        paint.color = Color.argb(35, 0, 0, 0)
        canvas.drawCircle(cx, cy, okRadius, paint)
        textPaint.textSize = 18f * density
        textPaint.color = if (enabled) Color.rgb(31, 41, 55) else Color.rgb(130, 135, 140)
        canvas.drawText("OK", cx, cy - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)

        textPaint.textSize = 12f * density
        textPaint.color = Color.rgb(75, 85, 99)
        canvas.drawText("Pre zmenu rozmeru otáčajte", cx, height - 10f * density, textPaint)
        if (!enabled) postInvalidateDelayed(80L)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val size = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f + size * 0.045f
        val radius = size * 0.405f
        val dx = event.x - cx
        val dy = event.y - cy
        val distanceSquared = dx * dx + dy * dy
        val okRadius = radius * 0.31f
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                pressedOk = distanceSquared <= okRadius * okRadius
                dragging = !pressedOk && distanceSquared <= radius * radius
                lastAngle = touchAngle(event.x, event.y, cx, cy)
                return pressedOk || dragging
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val angle = touchAngle(event.x, event.y, cx, cy)
                var delta = angle - lastAngle
                if (delta < -180f) delta += 360f
                if (delta > 180f) delta -= 360f
                accumulatedAngle += delta
                visualAngle += delta
                while (accumulatedAngle >= DEGREES_PER_STEP) {
                    applyStep(+1)
                    accumulatedAngle -= DEGREES_PER_STEP
                }
                while (accumulatedAngle <= -DEGREES_PER_STEP) {
                    applyStep(-1)
                    accumulatedAngle += DEGREES_PER_STEP
                }
                lastAngle = angle
                postInvalidateOnAnimation()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val confirm = pressedOk && distanceSquared <= okRadius * okRadius
                dragging = false
                pressedOk = false
                parent?.requestDisallowInterceptTouchEvent(false)
                if (confirm) {
                    if (SystemClock.uptimeMillis() >= okEnabledAt) {
                        performClick()
                        onConfirm?.invoke(value)
                    } else performHapticFeedback(HapticFeedbackConstants.REJECT)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                pressedOk = false
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun applyStep(direction: Int) {
        val old = value
        value = value + direction * step
        if (value != old) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onValueChanged?.invoke(value)
        }
    }

    private fun snap(raw: Double): Double {
        if (!raw.isFinite()) return minimum
        val safeStep = step.takeIf { it > 0.0 } ?: 1.0
        val snapped = minimum + kotlin.math.round((raw - minimum) / safeStep) * safeStep
        return snapped.coerceIn(minimum, maximum)
    }

    private fun formattedValue(): String = String.format(
        Locale("sk", "SK"), "%.${decimals.coerceIn(0, 3)}f%s", value, unit
    )

    private fun touchAngle(x: Float, y: Float, cx: Float, cy: Float): Float {
        var angle = Math.toDegrees(atan2((y - cy).toDouble(), (x - cx).toDouble())).toFloat() + 90f
        if (angle < 0f) angle += 360f
        return angle
    }

    private companion object {
        const val DEGREES_PER_STEP = 15f
    }
}
