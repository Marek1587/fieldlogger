package sk.strechasketch.app

import kotlin.math.hypot
import kotlin.math.max

/** Deterministic placement of perimeter dimensions outside a simple roof polygon. */
internal object PlanDimensionPlacementSolver {
    internal data class Placement(
        val edgeIndex: Int,
        val dimensionA: LocalPoint,
        val dimensionB: LocalPoint,
        val normal: LocalPoint,
        val outsideScore: Int
    )

    private fun signedArea(points: List<LocalPoint>): Double = points.indices.sumOf { index ->
        val a = points[index]
        val b = points[(index + 1) % points.size]
        a.x * b.y - b.x * a.y
    } / 2.0

    /**
     * Tests a complete strip, not only its midpoint. This matters at concave L/T/H
     * corners where a centroid-based normal can point back through another roof wing.
     */
    private fun insideScore(
        polygon: List<LocalPoint>,
        a: LocalPoint,
        b: LocalPoint,
        nx: Double,
        ny: Double,
        offsetM: Double
    ): Int {
        var score = 0
        val edgeLength = hypot(b.x - a.x, b.y - a.y).coerceAtLeast(1e-9)
        val probe = minOf(offsetM * 0.12, maxOf(1e-5, edgeLength * 1e-5))
        val distances = doubleArrayOf(probe, offsetM * 0.30, offsetM * 0.65, offsetM)
        val positions = doubleArrayOf(0.04, 0.18, 0.38, 0.62, 0.82, 0.96)
        distances.forEach { distance ->
            positions.forEach { t ->
                val point = LocalPoint(
                    a.x + (b.x - a.x) * t + nx * distance,
                    a.y + (b.y - a.y) * t + ny * distance
                )
                if (Geometry.pointInPolygon(point, polygon)) score++
            }
        }
        return score
    }

    fun place(polygon: List<LocalPoint>, edgeIndex: Int, offsetM: Double): Placement? {
        if (polygon.size < 3 || edgeIndex !in polygon.indices || offsetM <= 0.0) return null
        val a = polygon[edgeIndex]
        val b = polygon[(edgeIndex + 1) % polygon.size]
        val dx = b.x - a.x
        val dy = b.y - a.y
        val length = hypot(dx, dy)
        if (length <= 1e-9) return null
        val left = LocalPoint(-dy / length, dx / length)
        val right = LocalPoint(-left.x, -left.y)
        // For a consistently wound simple polygon the exterior half-plane is
        // deterministic. A centroid test is not valid for concave L/T/H plans.
        val normal = if (signedArea(polygon) >= 0.0) right else left

        // A locally exterior offset can still run through another wing of a
        // concave building. Move such dimensions to the outer support line of
        // the complete polygon. The requested offset is then measured from the
        // outermost vertex, so the dimension itself is always outside the plan.
        val midpoint = LocalPoint((a.x + b.x) / 2.0, (a.y + b.y) / 2.0)
        val supportDistance = polygon.maxOf { point ->
            (point.x - midpoint.x) * normal.x + (point.y - midpoint.y) * normal.y
        }
        val dimensionDistance = max(0.0, supportDistance) + offsetM
        val chosenScore = insideScore(
            polygon = polygon,
            a = a,
            b = b,
            nx = normal.x,
            ny = normal.y,
            offsetM = dimensionDistance
        )
        return Placement(
            edgeIndex = edgeIndex,
            dimensionA = LocalPoint(a.x + normal.x * dimensionDistance, a.y + normal.y * dimensionDistance),
            dimensionB = LocalPoint(b.x + normal.x * dimensionDistance, b.y + normal.y * dimensionDistance),
            normal = normal,
            outsideScore = chosenScore
        )
    }

    /** Used by regression tests and future collision layers. */
    fun segmentIsOutside(polygon: List<LocalPoint>, placement: Placement): Boolean {
        val a = placement.dimensionA
        val b = placement.dimensionB
        return (0..20).none { step ->
            val t = step / 20.0
            Geometry.pointInPolygon(
                LocalPoint(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t),
                polygon
            )
        }
    }
}
