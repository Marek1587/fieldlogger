package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test

class RoofObjectPlacementTest {
    private val plane = RoofPlane(a = 0.22, b = -0.11, c = 4.0)
    private val center = LocalPoint(5.0, 3.0)

    @Test
    fun chimneyTopIsHorizontalAboveSlopedRoof() {
        val left = RoofObjectPlacement.topElevation(
            ObjectType.CHIMNEY, plane, center, LocalPoint(4.4, 2.7), 1.2
        )
        val right = RoofObjectPlacement.topElevation(
            ObjectType.CHIMNEY, plane, center, LocalPoint(5.6, 3.3), 1.2
        )
        assertEquals(left, right, 1e-9)
        assertEquals(plane.zAt(center.x, center.y) + 1.2, left, 1e-9)
    }

    @Test
    fun roofWindowTopContinuesToFollowItsRoofPlane() {
        val left = RoofObjectPlacement.topElevation(
            ObjectType.ROOF_WINDOW, plane, center, LocalPoint(4.4, 2.7), 0.045
        )
        val right = RoofObjectPlacement.topElevation(
            ObjectType.ROOF_WINDOW, plane, center, LocalPoint(5.6, 3.3), 0.045
        )
        assertNotEquals(left, right, 1e-9)
    }

    @Test
    fun movementReadoutUsesNearestPhysicalRoofCorner() {
        val offset = RoofObjectPlacement.offsetFromNearestCorner(
            LocalPoint(8.5, 5.25),
            listOf(LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0), LocalPoint(10.0, 6.0), LocalPoint(0.0, 6.0))
        )!!
        assertEquals(2, offset.cornerIndex)
        assertEquals(1.5, offset.xM, 1e-9)
        assertEquals(0.75, offset.yM, 1e-9)
    }

    @Test
    fun movementReadoutUsesBuildingAxesWhenFootprintIsRotated() {
        val root = kotlin.math.sqrt(0.5)
        val corners = listOf(
            LocalPoint(0.0, 0.0),
            LocalPoint(10.0 * root, 10.0 * root),
            LocalPoint(0.0, 20.0 * root),
            LocalPoint(-10.0 * root, 10.0 * root)
        )
        val point = LocalPoint(root, 5.0 * root) // 3 m along X and 2 m along Y from corner 0.
        val offset = RoofObjectPlacement.offsetFromNearestCorner(point, corners)!!
        assertEquals(0, offset.cornerIndex)
        assertEquals(3.0, offset.xM, 1e-9)
        assertEquals(2.0, offset.yM, 1e-9)
    }
}
