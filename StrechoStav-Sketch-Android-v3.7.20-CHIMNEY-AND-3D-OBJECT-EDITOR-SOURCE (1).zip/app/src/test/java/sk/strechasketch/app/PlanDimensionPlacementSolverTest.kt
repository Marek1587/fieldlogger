package sk.strechasketch.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanDimensionPlacementSolverTest {
    private val lShape = listOf(
        LocalPoint(0.0, 0.0),
        LocalPoint(25.0, 0.0),
        LocalPoint(25.0, 24.0),
        LocalPoint(20.0, 24.0),
        LocalPoint(20.0, 10.0),
        LocalPoint(0.0, 10.0)
    )

    @Test
    fun everyPerimeterDimensionOfConcaveLShapeStaysOutsideRoof() {
        lShape.indices.forEach { edgeIndex ->
            val placement = PlanDimensionPlacementSolver.place(lShape, edgeIndex, 0.60)!!
            assertEquals(0, placement.outsideScore)
            assertTrue(
                "Kóta hrany $edgeIndex nesmie prechádzať vnútrom L pôdorysu",
                PlanDimensionPlacementSolver.segmentIsOutside(lShape, placement)
            )
        }
    }

    @Test
    fun outsidePlacementIsIndependentOfPolygonWinding() {
        val reversed = lShape.reversed()
        reversed.indices.forEach { edgeIndex ->
            val placement = PlanDimensionPlacementSolver.place(reversed, edgeIndex, 0.60)!!
            assertEquals(0, placement.outsideScore)
            assertTrue(PlanDimensionPlacementSolver.segmentIsOutside(reversed, placement))
        }
    }
}
