package sk.strechasketch.app

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.sqrt

class RoofGraphTest {
    private val origin = GeoPoint(49.0, 18.0)

    private fun rectangle(): RoofGraph {
        val topology = RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("N1", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N2", 10.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N3", 10.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N4", 0.0, 6.0, TopologyNodeType.FOOTPRINT)
            ),
            edges = listOf(
                TopologyEdge("E1", "N1", "N2", LineType.EAVE, boundary = true),
                TopologyEdge("E2", "N2", "N3", LineType.GABLE, boundary = true),
                TopologyEdge("E3", "N3", "N4", LineType.EAVE, boundary = true),
                TopologyEdge("E4", "N4", "N1", LineType.GABLE, boundary = true)
            )
        )
        return RoofGraphFactory.fromTopology(topology)
    }

    private fun lFootprint(): RoofGraph = RoofGraphFactory.fromTopology(
        RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("N1", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N2", 12.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N3", 12.0, 4.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N4", 7.0, 4.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N5", 7.0, 9.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N6", 0.0, 9.0, TopologyNodeType.FOOTPRINT)
            ),
            edges = listOf(
                TopologyEdge("E1", "N1", "N2", LineType.EAVE, boundary = true),
                TopologyEdge("E2", "N2", "N3", LineType.EAVE, boundary = true),
                TopologyEdge("E3", "N3", "N4", LineType.EAVE, boundary = true),
                TopologyEdge("E4", "N4", "N5", LineType.EAVE, boundary = true),
                TopologyEdge("E5", "N5", "N6", LineType.EAVE, boundary = true),
                TopologyEdge("E6", "N6", "N1", LineType.EAVE, boundary = true)
            )
        )
    )

    private fun hippedRectangle(): RoofGraph = RoofGraphFactory.fromTopology(
        RoofTopology(
            origin = origin,
            nodes = listOf(
                TopologyNode("N1", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N2", 10.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N3", 10.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("N4", 0.0, 6.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("J1", 3.0, 3.0, TopologyNodeType.JUNCTION),
                TopologyNode("J2", 7.0, 3.0, TopologyNodeType.JUNCTION)
            ),
            edges = listOf(
                TopologyEdge("E1", "N1", "N2", LineType.EAVE, boundary = true),
                TopologyEdge("E2", "N2", "N3", LineType.EAVE, boundary = true),
                TopologyEdge("E3", "N3", "N4", LineType.EAVE, boundary = true),
                TopologyEdge("E4", "N4", "N1", LineType.EAVE, boundary = true),
                TopologyEdge("H1", "N1", "J1", LineType.HIP),
                TopologyEdge("H2", "N4", "J1", LineType.HIP),
                TopologyEdge("R1", "J1", "J2", LineType.RIDGE),
                TopologyEdge("H3", "N2", "J2", LineType.HIP),
                TopologyEdge("H4", "N3", "J2", LineType.HIP)
            )
        )
    )

    @Test
    fun coordinateChangeKeepsTopologyAndFaceIdentity() {
        val before = rectangle()
        val after = RoofGraphOperations.moveNode(before, "N2", 12.0, 0.0)!!

        assertEquals(before.nodes.keys, after.nodes.keys)
        assertEquals(before.edges.keys, after.edges.keys)
        assertEquals(before.faces.keys, after.faces.keys)
        assertEquals(before.topologySignature(), after.topologySignature())
        assertTrue(RoofGraphValidator.validate(after).isEmpty())
    }

    @Test
    fun edgeSplitCreatesExactlyOneMidpointAndKeepsSemanticMetadata() {
        val before = rectangle()
        val faceId = before.faces.keys.single()
        val after = RoofGraphOperations.splitEdge(before, "E1", "N-MID")!!

        assertEquals(before.nodes.size + 1, after.nodes.size)
        assertEquals(before.edges.size + 1, after.edges.size)
        assertEquals(GraphNode("N-MID", 5.0, 0.0, 0.0), after.nodes["N-MID"])
        val children = after.edges.values.filter { it.startNodeId == "N-MID" || it.endNodeId == "N-MID" }
        assertEquals(2, children.size)
        assertTrue(children.all { it.semanticRole == EdgeSemantic.EAVE && it.boundary })
        assertEquals(setOf(faceId), after.faces.keys)
        assertTrue(RoofGraphValidator.validate(after).isEmpty())
    }

    @Test
    fun translatingWholeEdgePreservesLengthAndDirection() {
        val before = rectangle()
        val edge = before.edges.getValue("E2")
        fun vector(graph: RoofGraph): Pair<Double, Double> {
            val a = graph.nodes.getValue(edge.startNodeId)
            val b = graph.nodes.getValue(edge.endNodeId)
            return (b.x - a.x) to (b.y - a.y)
        }
        val old = vector(before)
        val after = RoofGraphOperations.translateEdge(before, "E2", 1.25, -0.75)!!
        val moved = vector(after)

        assertEquals(hypot(old.first, old.second), hypot(moved.first, moved.second), 1e-10)
        assertEquals(atan2(old.second, old.first), atan2(moved.second, moved.first), 1e-10)
        assertEquals(before.faces.keys, after.faces.keys)
    }

    @Test
    fun edgeLengthDialValueIsStoredAsHardMillimetreConstraint() {
        val before = rectangle()
        val after = RoofGraphOperations.setEdgeLength(before, "E1", 12.35)!!
        val edge = after.edges.getValue("E1")
        val a = after.nodes.getValue(edge.startNodeId)
        val b = after.nodes.getValue(edge.endNodeId)
        assertEquals(12.35, hypot(b.x - a.x, b.y - a.y), 1e-10)
        val constraint = after.edgeLengthConstraints.getValue("edge-length-E1")
        assertEquals(12_350.0, constraint.valueMm, 1e-9)
        assertTrue(constraint.hard)

        val decoded = RoofGraphJson.decode(RoofGraphJson.encode(after))
        assertEquals(constraint, decoded.edgeLengthConstraints.getValue(constraint.id))
    }

    @Test
    fun parametricDimensionEditPreservesAllIncidencesAsOneTransaction() {
        val before = RoofPlaneSolver.solve(rectangle(), 3.0, 20.0).graph
        val result = ParametricEditSolver.setEdgeLength(before, "E1", 14.0, 3.0, 20.0)
        assertTrue(result.applied)
        assertTrue(TopologyValidator.sameIncidence(before, result.graph))
        assertEquals(before.nodes.size, result.graph.nodes.size)
        assertEquals(before.edges.size, result.graph.edges.size)
        assertEquals(before.faces.keys, result.graph.faces.keys)
        assertTrue(result.graph.nodes.values.none { !it.x.isFinite() || !it.y.isFinite() || !it.z.isFinite() })
    }

    @Test
    fun sharedRectangleDimensionOrthogonalizesAndUpdatesOppositeSide() {
        val skewed = RoofGraphOperations.moveNode(rectangle(), "N3", 10.35, 6.25)!!
        val before = RoofPlaneSolver.solveForRendering(skewed, 3.0, 20.0).graph
        val result = ParametricEditSolver.setBoundaryDimension(
            before, listOf("E1", "E3"), 14.0, 3.0, 20.0
        )

        assertTrue(result.issues.joinToString(), result.applied)
        assertTrue(TopologyValidator.sameIncidence(before, result.graph))
        val ordered = RoofTopologyMigration.orderedBoundary(result.graph.toTopology())!!.second
        val vectors = ordered.map { edge ->
            val a = result.graph.nodes.getValue(edge.startNodeId)
            val b = result.graph.nodes.getValue(edge.endNodeId)
            (b.x - a.x) to (b.y - a.y)
        }
        fun length(vector: Pair<Double, Double>) = hypot(vector.first, vector.second)
        fun dot(a: Pair<Double, Double>, b: Pair<Double, Double>) =
            (a.first * b.first + a.second * b.second) / (length(a) * length(b))
        assertEquals(14.0, length(vectors[0]), 1e-6)
        assertEquals(14.0, length(vectors[2]), 1e-6)
        assertEquals(0.0, dot(vectors[0], vectors[1]), 1e-6)
        assertEquals(0.0, dot(vectors[1], vectors[2]), 1e-6)
        assertEquals(14_000.0, result.graph.edgeLengthConstraints.getValue("edge-length-E1").valueMm, 1e-6)
        assertEquals(14_000.0, result.graph.edgeLengthConstraints.getValue("edge-length-E3").valueMm, 1e-6)
    }

    @Test
    fun lPlanChangesOnlyLongestParallelOppositeSegmentAndKeepsRightAngles() {
        val before = lFootprint()
        val result = ParametricEditSolver.setBoundaryDimension(
            before, listOf("E1"), 14.0, 3.0, 20.0
        )

        assertTrue(result.issues.joinToString(), result.applied)
        fun length(edgeId: String): Double {
            val edge = result.graph.edges.getValue(edgeId)
            val a = result.graph.nodes.getValue(edge.startNodeId)
            val b = result.graph.nodes.getValue(edge.endNodeId)
            return hypot(b.x - a.x, b.y - a.y)
        }
        assertEquals(14.0, length("E1"), 1e-6)
        assertEquals(9.0, length("E5"), 1e-6)
        assertEquals(5.0, length("E3"), 1e-6)
        val ordered = RoofTopologyMigration.orderedBoundary(result.graph.toTopology())!!.second
        val vectors = ordered.map { edge ->
            val a = result.graph.nodes.getValue(edge.startNodeId)
            val b = result.graph.nodes.getValue(edge.endNodeId)
            (b.x - a.x) to (b.y - a.y)
        }
        vectors.indices.forEach { index ->
            val first = vectors[index]
            val second = vectors[(index + 1) % vectors.size]
            val dot = first.first * second.first + first.second * second.second
            assertEquals(0.0, dot, 1e-6)
        }
    }

    @Test
    fun footprintResizeRestoresEveryHipTo45DegreesAndLetsRidgeChangeLength() {
        val before = hippedRectangle()
        val result = ParametricEditSolver.setBoundaryDimension(
            before, listOf("E1", "E3"), 14.0, 3.0, 25.0
        )

        assertTrue(result.issues.joinToString(), result.applied)
        val boundaryIds = result.graph.edges.values.filter { it.boundary }
            .flatMap { listOf(it.startNodeId, it.endNodeId) }.toSet()
        result.graph.edges.values.filter { it.semanticRole == EdgeSemantic.HIP }.forEach { hip ->
            val anchorId = if (hip.startNodeId in boundaryIds) hip.startNodeId else hip.endNodeId
            val mobileId = if (anchorId == hip.startNodeId) hip.endNodeId else hip.startNodeId
            val anchor = result.graph.nodes.getValue(anchorId)
            val mobile = result.graph.nodes.getValue(mobileId)
            val eave = result.graph.edges.values.first {
                it.boundary && it.semanticRole == EdgeSemantic.EAVE &&
                    (it.startNodeId == anchorId || it.endNodeId == anchorId)
            }
            val eaveOtherId = if (eave.startNodeId == anchorId) eave.endNodeId else eave.startNodeId
            val eaveOther = result.graph.nodes.getValue(eaveOtherId)
            val hx = mobile.x - anchor.x
            val hy = mobile.y - anchor.y
            val ex = eaveOther.x - anchor.x
            val ey = eaveOther.y - anchor.y
            val cosine = kotlin.math.abs(hx * ex + hy * ey) /
                (hypot(hx, hy) * hypot(ex, ey))
            assertEquals("Hrana ${hip.id} nie je v pôdoryse 45° voči odkvapu", sqrt(0.5), cosine, 1e-8)
        }
        val ridge = result.graph.edges.getValue("R1")
        val ridgeA = result.graph.nodes.getValue(ridge.startNodeId)
        val ridgeB = result.graph.nodes.getValue(ridge.endNodeId)
        assertEquals(8.0, hypot(ridgeB.x - ridgeA.x, ridgeB.y - ridgeA.y), 1e-7)
        assertTrue(TopologyValidator.sameIncidence(before, result.graph))
    }

    @Test
    fun parametricPlanRegularizerAlsoMakesValleyExactly45DegreesToEave() {
        val topology = lFootprint().toTopology().copy(
            nodes = lFootprint().toTopology().nodes +
                TopologyNode("V1", 5.8, 7.1, TopologyNodeType.JUNCTION),
            edges = lFootprint().toTopology().edges +
                TopologyEdge("VALLEY-1", "N4", "V1", LineType.VALLEY)
        )
        val before = RoofGraphFactory.fromTopology(topology)
        val corrected = ParametricRoofPlanRegularizer.regularize(before).graph
        val anchor = corrected.nodes.getValue("N4")
        val mobile = corrected.nodes.getValue("V1")
        val eave = corrected.edges.getValue("E4")
        val otherId = if (eave.startNodeId == anchor.id) eave.endNodeId else eave.startNodeId
        val other = corrected.nodes.getValue(otherId)
        val vx = mobile.x - anchor.x
        val vy = mobile.y - anchor.y
        val ex = other.x - anchor.x
        val ey = other.y - anchor.y
        val cosine = kotlin.math.abs(vx * ex + vy * ey) / (hypot(vx, vy) * hypot(ex, ey))
        assertEquals(sqrt(0.5), cosine, 1e-8)
    }

    @Test
    fun projectSynchronizerMovesWallFootprintWithRoofBoundary() {
        val before = rectangle()
        val changed = ParametricEditSolver.setBoundaryDimension(
            before, listOf("E1"), 14.0, 3.0, 20.0
        )
        assertTrue(changed.issues.joinToString(), changed.applied)
        val wallLocal = listOf(
            LocalPoint(0.4, 0.4), LocalPoint(9.6, 0.4),
            LocalPoint(9.6, 5.6), LocalPoint(0.4, 5.6)
        )
        val project = RoofProject(
            polygon = listOf(
                LocalPoint(0.0, 0.0), LocalPoint(10.0, 0.0),
                LocalPoint(10.0, 6.0), LocalPoint(0.0, 6.0)
            ).map { Geometry.toGeo(it, origin) }.toMutableList(),
            wallFootprint = wallLocal.map { Geometry.toGeo(it, origin) }.toMutableList(),
            roofGraph = before,
            roofTopology = before.toTopology()
        )

        assertTrue(ProjectPlanSynchronizer.apply(project, before, changed.graph))
        val synchronizedWall = project.wallFootprint.map { Geometry.toLocal(it, origin) }
        assertEquals(0.4, synchronizedWall[0].x, 0.002)
        assertEquals(13.6, synchronizedWall[1].x, 0.002)
        assertEquals(13.6, synchronizedWall[2].x, 0.002)
        assertEquals(0.4, synchronizedWall[3].x, 0.002)
        val roofWidth = project.polygon.maxOf { Geometry.toLocal(it, origin).x } -
            project.polygon.minOf { Geometry.toLocal(it, origin).x }
        assertEquals(14.0, roofWidth, 0.002)
    }

    @Test
    fun semanticEditNeverChangesCoordinates() {
        val before = rectangle()
        val after = RoofGraphOperations.setSemanticRole(before, "E1", EdgeSemantic.ATTIC)!!
        assertEquals(before.nodes, after.nodes)
        assertEquals(EdgeSemantic.ATTIC, after.edges.getValue("E1").semanticRole)
    }

    @Test
    fun schemaFourJsonMigratesAndSchemaFiveRoundTripKeepsIds() {
        val old = JSONObject().apply {
            put("schema", "strechostav-sketch-project-4")
            put("schema_version", 4)
            put("id", "legacy-project")
            put("name", "Legacy")
            put("center_lat", 49.0)
            put("center_lon", 18.0)
            put("polygon", org.json.JSONArray().apply {
                listOf(0.0 to 0.0, 0.0 to 0.0001, 0.0001 to 0.0001, 0.0001 to 0.0).forEach { (lat, lon) ->
                    put(JSONObject().put("lat", 49.0 + lat).put("lon", 18.0 + lon))
                }
            })
            put("lines", org.json.JSONArray())
            put("objects", org.json.JSONArray())
            put("edge_types", JSONObject())
        }
        val migrated = ProjectJson.decode(old.toString())
        val firstGraph = migrated.roofGraph
        assertNotNull(firstGraph)
        assertEquals(4, firstGraph!!.nodes.size)
        assertEquals(4, firstGraph.edges.size)

        val encoded = JSONObject(ProjectJson.encode(migrated))
        assertEquals(6, encoded.getInt("schema_version"))
        val reloaded = ProjectJson.decode(encoded.toString()).roofGraph!!
        assertEquals(firstGraph.nodes.keys, reloaded.nodes.keys)
        assertEquals(firstGraph.edges.keys, reloaded.edges.keys)
        assertEquals(firstGraph.faces.keys, reloaded.faces.keys)
    }

    @Test
    fun oneSharedNodeObjectIsUsedByAllIncidentFaces() {
        val topology = RoofTopology(
            origin,
            listOf(
                TopologyNode("A", 0.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("B", 8.0, 0.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("C", 8.0, 8.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("D", 0.0, 8.0, TopologyNodeType.FOOTPRINT),
                TopologyNode("O", 4.0, 4.0, TopologyNodeType.JUNCTION)
            ),
            listOf(
                TopologyEdge("AB", "A", "B", LineType.EAVE, boundary = true),
                TopologyEdge("BC", "B", "C", LineType.EAVE, boundary = true),
                TopologyEdge("CD", "C", "D", LineType.EAVE, boundary = true),
                TopologyEdge("DA", "D", "A", LineType.EAVE, boundary = true),
                TopologyEdge("AO", "A", "O", LineType.HIP),
                TopologyEdge("BO", "B", "O", LineType.HIP),
                TopologyEdge("CO", "C", "O", LineType.HIP),
                TopologyEdge("DO", "D", "O", LineType.HIP)
            )
        )
        val graph = RoofGraphFactory.fromTopology(topology)
        assertEquals(4, graph.faces.values.count { "O" in it.orderedNodeIds })
        val moved = RoofGraphOperations.moveNode(graph, "O", 4.0, 4.0, 3.5)!!
        assertEquals(3.5, moved.nodes.getValue("O").z, 0.0)
        assertTrue(moved.faces.values.filter { "O" in it.orderedNodeIds }.all { face ->
            face.orderedNodeIds.count { it == "O" } == 1
        })
    }

    @Test
    fun oneTransactionUndoRestoresCompleteGraph() {
        val manager = RoofGraphUndoManager()
        val before = rectangle()
        val after = RoofGraphOperations.translateEdge(before, "E1", 0.0, 2.0)!!
        manager.commit("Posun hrany", before, after)
        assertEquals(before, manager.undo(after))
        assertEquals(after, manager.redo(before))
    }
}
