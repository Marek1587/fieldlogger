# Technické poznámky 3.7.10

Po zmene mapovania `X = east`, `Z = -north` sa už zdrojové SVG nesmie horizontálne prevracať. OpenGL preto používa priame UV mapovanie `(left=0, right=1)` a statický Kotlin/PDF renderer priame poradie zdrojových rohov.

Geometrické poradie logovej plochy je samostatná otázka od UV mapovania. OpenGL trojuholníky sú zapísané v opačnom poradí tak, aby `gl_FrontFacing` označovalo vonkajšiu stranu strechy. UV rohy zostávajú na svojich významových pozíciách, takže obrátenie normály nespôsobí zrkadlenie písma.

Strešné objekty majú pri každej kotve uloženú aj vonkajšiu jednotkovú normálu `(-a, 1, b)` v modelových osiach. Regresný test overuje jej kladnú vertikálnu zložku pre okná, výlezy aj prestupy.
