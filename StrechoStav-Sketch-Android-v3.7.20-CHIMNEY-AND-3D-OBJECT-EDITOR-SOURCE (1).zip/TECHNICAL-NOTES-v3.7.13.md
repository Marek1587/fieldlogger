# Technické poznámky 3.7.13 – solver presahu strechy

## Sémantické pravidlo

Presah nie je odvodený iba z geometrickej vzdialenosti. Solver vyberá výlučne obvodové hrany `EdgeSemantic.EAVE`. Hrany `ATTIC`, `GABLE`, `PULT`, `WALL_END` a ostatné typy nemenia polohu steny a nevytvárajú podhľad.

Jedna hodnota kóty presahu posunie dovnútra podporné priamky všetkých odkvapových hrán. Rohy nového pôdorysu muriva vznikajú priesečníkom dvoch susedných podporných priamok. Vďaka tomu zostáva riešenie deterministické aj pri zalomených L/T/H pôdorysoch a pri kombináciách atiky s odkvapom.

## 3D skladba

Každá vyriešená odkvapová sekcia obsahuje:

1. zvislé čelo strešného plášťa s predvolenou hrúbkou 180 mm,
2. prvých 200 mm vodorovného podhľadu,
3. zostávajúci šikmý podhľad podľa rovnice príslušnej plochy `z = a*x + b*y + c`,
4. uzavretie pri murive, ak spodná rovina krokvy leží nad nominálnou výškou steny.

Plochy podhľadu sa renderujú rovnakou nepriehľadnou stenovou vrstvou v OpenGL aj v statickom Kotlin/PDF rendereri. Nevstupujú do plochy strešnej krytiny ani nemenia existujúce `FaceId` a `EdgeId`.

## Regresné prípady

- tri atiky + jeden odkvap: presah a kóta vzniknú iba na jednom odkvape,
- jedna atika + päť odkvapov: vznikne päť sekcií s jednou spoločnou hodnotou,
- prvých 200 mm podhľadu zostáva vodorovných,
- pokračovanie podhľadu rešpektuje vyriešenú strešnú rovinu.
