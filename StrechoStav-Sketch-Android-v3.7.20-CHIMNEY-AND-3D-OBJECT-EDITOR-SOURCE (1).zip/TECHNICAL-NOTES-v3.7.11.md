# Technické poznámky 3.7.11 – PDF A4 a štyri 3D pohľady

## Formát a rozloženie

- Každá strana používa ISO A4 na výšku: `595 × 842 pt`.
- Prvá strana obsahuje mriežku `2 × 2` so štyrmi samostatnými izometrickými pohľadmi.
- Kamery majú azimuty `-45°`, `45°`, `135°` a `225°`, teda sledujú objekt zo všetkých štyroch rohov prezentačnej dosky.
- Parametrické kóty sú v PDF 3D náhľadoch vypnuté, aby model zostal čistý a dobre čitateľný.

## Kvalita rastra

- Každý 3D pohľad sa renderuje do vlastnej bitmapy s mierkou šesť pixelov na jeden PDF bod, približne `432 DPI`.
- Rozmer bitmapy je obmedzený na `3072 px` na os, aby sa zachovala stabilita aj na bežných mobilných telefónoch.
- Bitmapa sa po vložení do príslušného PDF poľa uvoľní; všetky štyri vysokokvalitné pohľady preto nemusia byť naraz v pracovnej pamäti.
- Technický 2D pôdorys zostáva vektorový a pri priblížení sa nerozpixeluje.

## Hrany strechy

- `RoofMesh.edges` obsahuje obvodové a konštrukčne výrazné hrany.
- `RoofMesh.internalEdges` obsahuje vnútorné spoje strešných plôch.
- Interaktívny OpenGL renderer aj statický Kotlin renderer kreslia vnútorné spoje samostatne tenšou bledosivou čiarou; obrys modelu zostáva tmavý a čitateľný.

## Overenie

- Vynútená úplná kompilácia `testDebugUnitTest :app:assembleDebug --rerun-tasks` bola úspešná.
- Regresná sada: `60` testov, `0` zlyhaní, `0` chýb.
- Kontrolný PDF má štyri strany s rozmerom `595 × 842 pt`; prvá strana bola vyrastrovaná a vizuálne skontrolovaná bez prekrývania štyroch polí.
