# Technické poznámky 3.7.9

## Súradnicová konvencia

- 2D editor, technický pôdorys a uložený `RoofGraph` zostávajú v lokálnych osiach `x = východ`, `y = sever`.
- Iba prezentačný prevod do OpenGL používa `X = x`, `Y = z`, `Z = -y`. Tým sa top-view 3D zhoduje s mapou a nevzniká zrkadlenie.
- Prevod je rovnomerné mierkovanie a osová reflexia; dĺžky, kolmosť a 90° rohy zostávajú zachované.

## Prezentačná doska

- Doska sa počíta z vyriešeného obvodu strechy, nie zo starého obdĺžnikového bounding boxu.
- Jej lokálna os `u` sleduje najdlhšiu obvodovú hranu.
- Samostatná vrstva `padEdges` obsahuje vonkajší obvod a dve jemné vnútorné rámové čiary.
- PDF používa túto jemnú vrstvu, ale vypína všetky parametrické kóty v oboch izometrických pohľadoch.

## Strešné objekty

- Strešné okno a výlez používajú rovinu priradeného `FaceId`; všetky štyri rohy preto ležia v rovnakom sklone ako strecha.
- Šírková os okna a výlezu sa odvodzuje od odkvapovej hrany príslušnej plochy.
- Okno, výlez a prestup majú 3D kotvu. Pohyb prsta sa inverziou 2×2 projekčného Jacobianu prevedie späť do lokálnych osí strešnej roviny.
- Pri presune sa kontroluje vonkajší polygon aj otvory plochy a aktualizuje sa `attachedFaceId`.
- Parametre: okno šírka/dĺžka, výlez šírka/dĺžka, prestup priemer.

## Overenie

- 60 JVM testov pokrýva topológiu, solver rovín, pravé uhly, orientáciu severu, dosku, objekty, výmery a exportné dáta.
- `assembleDebug` pre verziu 3.7.9 prešiel úspešne s JDK 17 a Gradle 8.10.2.
