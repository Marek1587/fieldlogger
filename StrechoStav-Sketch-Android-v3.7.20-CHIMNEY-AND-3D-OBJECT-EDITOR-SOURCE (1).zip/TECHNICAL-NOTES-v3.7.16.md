# StrechoStav Sketch 3.7.16 – maximálne využitie PDF 3D rámov

## Rámovanie podľa stavby

`RoofBitmapCamera.fitStructureOnly` oddeľuje geometriu, ktorá určuje mierku kamery,
od geometrie, ktorá sa naďalej vykresľuje. Pri štyroch PDF pohľadoch vstupujú do
výpočtu obálky steny, strecha, atiky, presahy a technické objekty. Prezentačná doska
s materiálom `2` sa do obálky nezapočíta.

Doska sa potom normálne rasterizuje hĺbkovým rendererom, ale môže pokračovať za hranicu
bitmapy. Oreže sa iba doska; samotný dom a strecha majú ochranný okraj 2,5 % kratšej
strany rámu.

## Štyri nezávislé kamery

Každý pohľad A až D počíta min/max projekciu samostatne po príslušnom otočení kamery.
L, T a H pôdorysy preto nie sú zmenšené podľa najnevýhodnejšieho z ostatných pohľadov.
Zmena je obmedzená na prezentačné 3D bitmapy prvej strany PDF.

## Overenie

Projekt sa kompiluje s Android SDK 35 a všetkých 67 geometrických a regresných testov
prechádza bez chyby.
