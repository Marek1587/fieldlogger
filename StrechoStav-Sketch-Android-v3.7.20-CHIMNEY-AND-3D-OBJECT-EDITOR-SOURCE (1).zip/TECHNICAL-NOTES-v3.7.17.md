# StrechoStav Sketch 3.7.17 – vonkajšie obvodové kóty

## Príčina chyby

Pôvodná voľba strany kóty porovnávala normálu hrany s ťažiskom pôdorysu. Takýto test
funguje iba pre konvexný obrys. Pri konkávnom L, T alebo H pôdoryse môže ťažisko ležať
na opačnej strane lokálnej hrany a kóta sa potom vykreslí cez strešnú plochu.

## Deterministický solver

`PlanDimensionPlacementSolver` používa orientáciu uzavretého polygónu na výber
vonkajšej normály každej hrany. Následne premietne všetky body pôdorysu na túto normálu
a kótovaciu priamku umiestni až za najvzdialenejšiu projekciu. Odsadenie 18 obrazových
bodov sa teda meria od vonkajšej obálky celého nákresu, nie iba od lokálnej hrany.

Tým vzniknú súvislé vonkajšie kótovacie pásy aj pri vnútorných rohoch L/T/H pôdorysov.
Výpočet nezávisí od smeru hodinových ručičiek ani od polohy ťažiska.

## Overenie

Regresný test kontroluje každú hranu konkávneho L pôdorysu, vzorkuje celú výslednú
kótovaciu úsečku a opakuje kontrolu aj po obrátení poradia bodov. Spolu prešlo všetkých
69 jednotkových, geometrických a regresných testov.
