# StrechoStav Sketch 3.7.3 – L-strechy a orientácia loga

## Úplnosť topológie

Plošné pokrytie samotné nestačí na posúdenie strešnej siete. Uzavretý vonkajší polygón má vždy plochu zhodnú s pôdorysom, aj keď sú všetky vnútorné línie iba voľné mosty. Nová metrika `TopologyQuality` preto sleduje súčasne:

- podiel plochy pokrytej uzavretými cyklami,
- počet vytvorených plôch,
- počet hrebeňov, nároží a úžľabí, ktoré nepatria dvom rôznym plochám.

Ak existuje nepripojená deliaca hrana, odvodená 3D príprava spustí bezpečné magnetické spojenie uzlov, prieniky a rozdelenie obvodovej hrany. Pôvodný používateľský nákres sa tým potichu neprepisuje; upravená topológia slúži spoločnej ceste pre 3D, PDF a výmeru.

## L-pôdorys so štítmi

Regresný model obsahuje šesť bodov obvodu, dva štíty, dva odkvapy na každom krídle, dva hrebene, jedno nárožie a jedno úžľabie. Výsledkom sú štyri plochy. Všetky štrukturálne vnútorné hrany majú presne dve susedné `FaceId` a rovinný solver vytvorí neprázdny vodotesný mesh.

## Logo

Geometria pôvodného SVG zostáva nezmenená. Opravená je transformácia medzi horizontálnou osou Android bitmapy a lokálnou tangentou strešnej plochy. Funkcie `roofSurfaceU` a `roofSurfaceSourceCorners` poskytujú rovnakú horizontálnu korekciu interaktívnemu OpenGL rendereru aj statickému Kotlin/PDF rendereru.
