# StrechoStav Sketch 3.7.18 – prioritná 45° geometria strechy

## Poradie parametrických podmienok

Po zmene pôdorysného rozmeru solver pracuje v tomto poradí:

1. zmení vybranú a najdlhšiu rovnobežnú protiľahlú obvodovú stenu,
2. zachová pravé uhly a uzavretý obrys budovy,
3. vytvorí pre každé nárožie a úžľabie podpornú priamku ±45° voči pripojenému odkvapu,
4. spoločné vnútorné uzly určí priesečníkom týchto podporných priamok,
5. polohu a dĺžku hrebeňov odvodí z vyriešených spoločných uzlov,
6. z tej istej XY siete znovu vyrieši roviny `z = ax + by + c`.

Nárožia a úžľabia majú teda vyššiu prioritu než pôvodná poloha alebo dĺžka hrebeňa.
Incidencia `Node–Edge–Face`, identifikátory a topológia sa nemenia.

## Viacnásobné uzly

Ak sa v jednom uzle stretáva viac diagonál, solver nevykonáva postupné posuny hrán.
Všetky 45° priamky zostaví naraz a vyberie ich spoločný deterministický priesečník.
Tým nevzniká výsledok závislý od poradia hrán. Kollineárne podmienky sa riešia projekciou
na spoločnú priamku; skutočne nekompatibilná sieť zostane označená v audite.

## Overenie

Regresia rozšíri valbový obdĺžnik z 10 na 14 m, overí všetky štyri nárožia s presným
45° uhlom a očakávanú zmenu hrebeňa zo 4 na 8 m. Samostatný test pokrýva aj úžľabie
v konkávnom L pôdoryse. Všetkých 71 testov prešlo bez chyby.
