# StrechoStav Sketch 3.7.7

## Prezentačná doska a pôdorysné kóty

Doska je iba prezentačná a používa pravidlá referenčného PHP renderera: okraj je `max(1,2 m; 18 % najväčšieho rozmeru vyriešenej strechy)`, hrúbka je `max(0,12 m; 1,4 % tohto rozmeru)` a horná plocha leží v úrovni `-0,08 m`. Doska nevstupuje do výkazu. Pôdorysné kóty ležia na doske; začiatky vynášacích čiar zostávajú na spodnom pôdoryse stien.

## Nerovnako široké L-krídla

Korekcia rieši prepojené diagonálne oporné čiary a hrebene ako jednu lineárnu sieť obmedzení. Nárožia a úžľabia zachovávajú 45-stupňové väzby a pripojené hrebene smer dominantných obvodových hrán. Výpočet je invariantný voči zámene osí, čo zodpovedá primárnej a sekundárnej kanonickej vetve v `sikma_polvalbova_stn.php`. Zachováva ID všetkých uzlov a hrán aj existujúci desaťpercentný limit úprav.

## Orientácia podľa strešnej plochy

Logo používa gradient vyriešenej roviny: horná časť smeruje nahor a spodok po spáde k odkvapu. Šírka komína používa kolmý vrstevnicový smer a je preto rovnobežná s odkvapom. Interaktívny OpenGL aj statický Kotlin/PDF renderer používajú rovnaký pripravený mesh.
