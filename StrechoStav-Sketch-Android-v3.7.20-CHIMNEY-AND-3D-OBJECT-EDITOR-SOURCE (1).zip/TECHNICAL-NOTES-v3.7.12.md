# Technické poznámky 3.7.12 – štítové murivo, skryté švy a logo podľa kamery

## Fyzický obrys stien

- Strešný `RoofGraph` smie rozdeliť štítovú hranu kvôli incidencii hrebeňa a tvorbe strešných plôch.
- Stenový mesh však vždy vychádza zo skutočného `wallFootprint`, prípadne z pôvodného `polygon`; nepoužíva rozdelenú hranicu solvera.
- Každý reálny segment obrysu preto vytvorí jednu súvislú fasádu bez zvislého švu v mieste, kde sa hrebeň iba dotkne štítu.

## Štítové murivo

- Pri hrane typu `GABLE` sa z uzlov vyriešeného grafu zostaví horný profil muriva.
- Profil obsahuje rímsové konce a skutočné výškové body strechy vrátane hrebeňa.
- Plocha pod profilom sa trianguluje bez exportovania triangulačných alebo pomocných hrán.

## Viditeľné línie

- Strešné obrysy a strešné spoje zostávajú samostatné.
- `wallEdges` obsahuje iba spodnú obrysovú hranu každého fyzického segmentu steny.
- Zvislé rohové čiary, diagonály triangulácie a solverové body na stenách sa nevykresľujú.
- OpenGL aj statický PDF renderer používajú pre povolený obrys stien najtenšiu bledosivú čiaru s hĺbkovým testom.

## Logo v štyroch PDF pohľadoch

- Mesh uchováva dve hlavné logá pre interaktívne 3D a zároveň kandidáta pre každú vhodnú strešnú plochu.
- Statický renderer vyhodnotí viditeľnosť stredu kandidáta proti pixelovému depth bufferu aktuálnej kamery.
- Ak hlavné logo v danom rohovom pohľade nie je viditeľné, vyberie sa najväčší viditeľný kandidát; logo zostáva súčasťou strešnej roviny a nepoužíva prekrytie nad modelom.
