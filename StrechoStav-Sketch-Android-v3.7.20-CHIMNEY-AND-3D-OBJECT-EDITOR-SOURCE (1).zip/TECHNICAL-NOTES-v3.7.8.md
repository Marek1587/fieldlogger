# Technické poznámky 3.7.8 – pevné pôdorysné kóty

Pôdorysná kóta je súčasťou modelového priestoru, nie obrazovkového rozloženia. Jej body `start` a `end` ležia na hornej ploche prezentačnej dosky a pri zmene kamery sa iba premietnu rovnakou maticou ako doska, dom a strecha.

Protiľahlé rovnobežné steny môžu reprezentovať jeden spoločný parametrický rozmer. Z ich dvoch prezentačných kandidátov sa pred projekciou vyberá deterministicky jeden kandidát podľa stabilného identifikátora hrany a modelových súradníc. Výber preto nezávisí od uhla kamery.

Pre pôdorysné kóty je vypnuté dodatočné pixelové odsúvanie a vyhľadávanie voľnej polohy. Ostatné technické anotácie si adaptívne rozloženie ponechávajú. Pevná pôdorysná kóta, ktorú zakryje nepriehľadná geometria, sa radšej nezobrazí, než by mala zmeniť fyzickú stranu dosky.

Táto politika je spoločná pre `Roof3DRenderer`, `Roof3DDimensionOverlay` a `RoofBitmapRenderer`, takže interaktívny pohľad, náhľad a PDF používajú rovnakú polohu.
