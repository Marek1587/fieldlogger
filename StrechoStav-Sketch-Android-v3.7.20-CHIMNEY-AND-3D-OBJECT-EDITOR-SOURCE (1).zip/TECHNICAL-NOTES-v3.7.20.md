# StrechoStav Sketch 3.7.20 – 3D geometria a samostatná editácia prvkov

## Rozdelenie pracovného postupu

Pracovná navigácia má dve 3D karty. `3D geometria` filtruje prekryvnú vrstvu na rozmery nosnej
geometrie strechy a budovy. `3D prvky` filtruje rozmery na komíny, strešné okná, výlezy a prestupy
a ako jediná povoľuje presun ich kotiev. Dátový model projektu ani identifikátory FaceId sa nemenia.

## Vodorovný vrch komína

Spodné štyri body komína sa naďalej určujú z rovnice priradenej strešnej plochy
`z = a*x + b*y + c`. Horné štyri body však používajú jednu spoločnú výšku vypočítanú nad stredom
komína. Výsledkom sú zvislé steny a vrch rovnobežný so základovou doskou. Okná a výlezy si ponechali
hornú plochu rovnobežnú so strešnou rovinou.

## Presúvanie a dočasné kóty

Pri stlačení technického prvku dostane jeho trojuholníková sieť OpenGL materiál výberu a shader ju
vykreslí načerveno. Po uvoľnení sa renderer vráti k bežnému materiálu. X/Y vzdialenosti sa počítajú
od najbližšieho bodu fyzického obrysu. Lokálne osi tvoria normalizované smery dvoch susedných strán,
takže kóty neprestanú dávať zmysel pri budove natočenej voči mape.

Kandidát presunu sa prijme iba vtedy, keď leží vo vonkajšom polygóne niektorej strešnej plochy a
zároveň neleží v jej otvore. Po prijatí sa uloží nová geografická poloha a aktuálny FaceId.

## Renderery a kompatibilita

Interaktívny model používa GLSurfaceView/OpenGL ES 3.0. Statický Kotlin bitmapový renderer a PDF
naďalej skladajú rovnaký `RoofMesh`, preto preberajú opravenú geometriu komína. Identifikátor
vybraného prvku sa do statických rendererov neposiela, takže červený pracovný stav sa neexportuje.
