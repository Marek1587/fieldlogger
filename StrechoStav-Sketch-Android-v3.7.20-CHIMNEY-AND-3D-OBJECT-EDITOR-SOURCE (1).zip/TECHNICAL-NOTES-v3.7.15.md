# StrechoStav Sketch 3.7.15 – súvislý presah valby a štítu

## Jeden obal namiesto samostatných pásov

`RoofOverhangSolver` už nekonštruuje každý presah ako nezávislý obdĺžnik. Z obvodových
podporných priamok vytvorí tri spojené kontúry: vonkajšiu hranu strechy, vnútornú hranu
200 mm podhľadu a hranu pri murive. Priesečník susedných priamok je jediný miterovaný
uzol, ktorý používajú obe susedné sekcie. Tým sa v rohoch valby odstránili prekrytia,
otvorené trojuholníky aj rozdielne koncové body.

Kolineárne segmenty vzniknuté rozdelením štítu pri hrebeni sú povolené. Solver ich
nezamietne a ponechá im totožný odsadený uzol. Krátky segment v zalomení L/T/H už
neurčuje neprimerane nízky maximálny presah; rozhodujúca je validita výsledného polygónu.

## Štítový vrchol

Presah je spoločný parameter pre `EAVE` a `GABLE`; `ATTIC` sa neposúva. Hrebeňový
incidenčný bod leží na vonkajšej štítovej hrane strechy. Funkcia
`gableProfileSupports` ho parametricky premietne na odsadenú štítovú stenu, zachová
jeho pozíciu pozdĺž hrany a výšku zo solvera rovín. Ide o odvodený konštrukčný bod:
vyplní murivo po hrebeň, ale nevytvorí fyzický deliaci šev na fasáde.

## Spätná kompatibilita

Staršie projekty mohli mať v `wallFootprint` odsadené iba odkvapy. Renderer najprv
zmeria ich spoločnú hodnotu a následne vytvorí fyzický pôdorys muriva s rovnakým
odsadením aj pri štítoch. Kanonický `RoofGraph`, `FaceId`, uložený JSON ani výmery sa
pri tejto renderovacej migrácii svojvoľne nemenia.

## Overenie

Regresné testy kontrolujú presnú zhodu XYZ spoločných uzlov v štyroch valbových rohoch,
štítový hrebeňový bod, kolineárne rozdelenie štítu, atikové výnimky a pôvodné L/T/H
prípady. Celá sada obsahuje 67 testov a prechádza bez zlyhania.
