# PDF Podpisovač pre Android

Offline Android aplikácia na vloženie vizuálneho podpisu alebo pečiatky do PDF
a obrázkov. Projekt obsahuje dve používateľské predvoľby s transparentným
pozadím:

- samostatný modrý podpis,
- firemnú pečiatku s podpisom.

## Funkcie

- otvorenie PDF, JPG, PNG alebo WebP cez systémový výber súborov,
- podpora viacstranových PDF,
- vloženie pečiatky s podpisom,
- vloženie samostatného podpisu,
- nakreslenie nového podpisu prstom,
- výber modrej, červenej alebo čiernej farby pera,
- nastaviteľná hrúbka čiary ručného podpisu,
- viac vložených prvkov na jednej alebo viacerých stranách,
- presun jedným prstom,
- zmena veľkosti a otočenie dvoma prstami,
- odstránenie vybraného prvku alebo vyčistenie celej strany,
- export do nového PDF bez prepísania originálu,
- otvorenie alebo zdieľanie výsledného PDF,
- úplne lokálne spracovanie bez internetu a bez úložiskových oprávnení.

## Použitie

1. Spustite aplikáciu a stlačte **Vybrať PDF alebo obrázok**.
2. Vyberte dokument.
3. Na požadovanej strane zvoľte **Pečiatka + podpis**, **Podpis** alebo
   **Podpis rukou**.
4. Jedným prstom prvok presuňte. Dvoma prstami upravte veľkosť a otočenie.
5. Pri viacstranovom PDF prechádzajte medzi stranami.
6. Stlačte **Vytvoriť nové podpísané PDF** a vyberte názov a umiestnenie.

## Zostavenie priamo zo zdrojov

Požiadavky:

- JDK 17,
- Android SDK 35,
- Gradle 8.10.2.

Príkaz:

```text
gradle :app:assembleDebug --stacktrace
```

APK vznikne v:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Workflow `.github/workflows/build-apk.yml` zostaví projekt automaticky, ak je
obsah ZIP archívu rozbalený priamo v GitHub repozitári.

Ak chcete v repozitári ponechať iba zdrojový ZIP, skopírujte
`github-actions/build-from-newest-zip.yml` do
`.github/workflows/build-apk.yml` mimo ZIP archívu.

## Technická poznámka

Aplikácia používa systémové Android API `PdfRenderer` a `PdfDocument`.
Pri exporte vytvorí nové, obrazovo zlúčené PDF. Vizuálny výsledok zostane
zachovaný, ale pôvodný vyhľadateľný text, formulárové polia a digitálne podpisy
sa vo výsledku zmenia na obraz stránky.

Vložený obrázok podpisu je vizuálny podpis. Nejde o kvalifikovaný elektronický
podpis ani o kryptografický PAdES podpis.

## Súkromie

Aplikácia neobsahuje povolenie na internet. Podpisy a dokumenty neopúšťajú
zariadenie. Používateľ vyberá vstupný aj výstupný súbor cez systémový Android
výber dokumentov.

### Dôležité upozornenie k uloženým podpisom

Obe predvoľby sú zabalené priamo v APK. Každý, kto získa APK alebo zdrojový
ZIP, ich môže technicky extrahovať. Zdrojový ZIP preto neukladajte do verejného
GitHub repozitára a hotové APK neposkytujte nedôveryhodným osobám. Pre silnejšiu
ochranu by ďalšia verzia mala predvoľby importovať až po inštalácii a uložiť ich
do šifrovaného úložiska chráneného biometriou.
