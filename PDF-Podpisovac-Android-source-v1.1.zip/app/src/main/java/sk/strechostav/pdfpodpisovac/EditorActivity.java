package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class EditorActivity extends Activity {
    public static final String EXTRA_DOCUMENT_URI = "document_uri";
    public static final String EXTRA_MIME_TYPE = "mime_type";

    private static final int REQUEST_CREATE_PDF = 2001;

    private Uri inputUri;
    private String inputName;
    private String mimeType;
    private boolean inputIsPdf;

    private PdfRenderer pdfRenderer;
    private Bitmap imagePreview;
    private Bitmap displayedPageBitmap;
    private int pageCount = 1;
    private int currentPage;
    private boolean documentLoaded;
    private boolean busy;

    private DocumentEditorView editorView;
    private TextView documentTitle;
    private TextView statusText;
    private TextView pageText;
    private ProgressBar progressBar;
    private Button previousButton;
    private Button nextButton;
    private Button deleteButton;
    private Button exportButton;

    private Bitmap presetSignature;
    private Bitmap presetStamp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String uriValue = getIntent().getStringExtra(EXTRA_DOCUMENT_URI);
        if (uriValue == null || uriValue.trim().isEmpty()) {
            Toast.makeText(this, "Dokument nebol zvolený.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        inputUri = Uri.parse(uriValue);
        inputName = DocumentFiles.displayName(this, inputUri);
        mimeType = DocumentFiles.mimeType(
                this,
                inputUri,
                getIntent().getStringExtra(EXTRA_MIME_TYPE)
        );
        inputIsPdf = DocumentFiles.isPdf(mimeType, inputName);

        presetSignature = BitmapFactory.decodeResource(
                getResources(),
                R.drawable.preset_signature
        );
        presetStamp = BitmapFactory.decodeResource(
                getResources(),
                R.drawable.preset_stamp_signature
        );

        buildUi();
        loadDocument();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(243, 246, 250));
        root.setPadding(
                0,
                Ui.dp(this, 8),
                0,
                Ui.dp(this, 14)
        );

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(
                Ui.dp(this, 14),
                Ui.dp(this, 10),
                Ui.dp(this, 14),
                Ui.dp(this, 10)
        );
        header.setBackgroundColor(Color.WHITE);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titlesParams = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        );
        header.addView(titles, titlesParams);

        documentTitle = Ui.text(this, inputName, 18, Color.rgb(24, 34, 49));
        documentTitle.setTypeface(
                documentTitle.getTypeface(),
                android.graphics.Typeface.BOLD
        );
        documentTitle.setSingleLine(true);
        documentTitle.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        titles.addView(documentTitle);

        statusText = Ui.text(this, "Načítavam dokument…", 13, Color.rgb(80, 88, 102));
        titles.addView(statusText);

        Button closeButton = Ui.button(this, "Zavrieť", false);
        closeButton.setOnClickListener(view -> finish());
        header.addView(closeButton);
        root.addView(header);

        LinearLayout pageControls = new LinearLayout(this);
        pageControls.setOrientation(LinearLayout.HORIZONTAL);
        pageControls.setGravity(Gravity.CENTER);
        pageControls.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 7),
                Ui.dp(this, 10),
                Ui.dp(this, 7)
        );

        previousButton = Ui.button(this, "‹ Predchádzajúca", false);
        nextButton = Ui.button(this, "Ďalšia ›", false);
        pageText = Ui.text(this, "Strana 1 / 1", 15, Color.rgb(28, 36, 49));
        pageText.setGravity(Gravity.CENTER);

        pageControls.addView(previousButton);
        LinearLayout.LayoutParams pageLabelParams = new LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
        );
        pageControls.addView(pageText, pageLabelParams);
        pageControls.addView(nextButton);
        root.addView(pageControls);

        previousButton.setOnClickListener(view -> renderPage(currentPage - 1));
        nextButton.setOnClickListener(view -> renderPage(currentPage + 1));

        editorView = new DocumentEditorView(this);
        LinearLayout.LayoutParams editorParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
        );
        editorParams.setMargins(
                Ui.dp(this, 10),
                0,
                Ui.dp(this, 10),
                Ui.dp(this, 8)
        );
        root.addView(editorView, editorParams);

        editorView.setChangeListener(new DocumentEditorView.ChangeListener() {
            @Override
            public void onSelectionChanged(Placement activePlacement) {
                deleteButton.setEnabled(activePlacement != null && !busy);
            }

            @Override
            public void onPlacementChanged() {
                updateStatusForSelection();
            }
        });

        progressBar = new ProgressBar(this);
        progressBar.setIndeterminate(true);
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        progressParams.gravity = Gravity.CENTER_HORIZONTAL;
        progressParams.bottomMargin = Ui.dp(this, 6);
        root.addView(progressBar, progressParams);

        HorizontalScrollView toolsScroll = new HorizontalScrollView(this);
        toolsScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setPadding(
                Ui.dp(this, 10),
                Ui.dp(this, 4),
                Ui.dp(this, 10),
                Ui.dp(this, 6)
        );
        toolsScroll.addView(tools);

        Button stampButton = Ui.button(this, "Pečiatka + podpis", false);
        Button signatureButton = Ui.button(this, "Podpis", false);
        Button handButton = Ui.button(this, "Podpis rukou", false);
        deleteButton = Ui.button(this, "Odstrániť vybrané", false);
        Button clearPageButton = Ui.button(this, "Vyčistiť stranu", false);

        addToolButton(tools, stampButton);
        addToolButton(tools, signatureButton);
        addToolButton(tools, handButton);
        addToolButton(tools, deleteButton);
        addToolButton(tools, clearPageButton);
        root.addView(toolsScroll);

        stampButton.setOnClickListener(view -> {
            if (ensureReady()) {
                editorView.addPlacement(presetStamp, "Pečiatka + podpis", 0.72f);
                statusText.setText("Pečiatku presuňte jedným prstom; dvoma zmeníte veľkosť a otočenie.");
            }
        });
        signatureButton.setOnClickListener(view -> {
            if (ensureReady()) {
                editorView.addPlacement(presetSignature, "Podpis", 0.48f);
                statusText.setText("Podpis presuňte jedným prstom; dvoma zmeníte veľkosť a otočenie.");
            }
        });
        handButton.setOnClickListener(view -> {
            if (!ensureReady()) {
                return;
            }
            SignatureDialog.show(this, bitmap -> {
                editorView.addPlacement(bitmap, "Ručný podpis", 0.48f);
                statusText.setText("Ručný podpis bol vložený. Upravte jeho polohu a veľkosť.");
            });
        });
        deleteButton.setOnClickListener(view -> editorView.removeActivePlacement());
        clearPageButton.setOnClickListener(view -> confirmClearPage());

        exportButton = Ui.button(this, "Vytvoriť nové podpísané PDF", true);
        LinearLayout.LayoutParams exportParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        exportParams.setMargins(
                Ui.dp(this, 10),
                Ui.dp(this, 3),
                Ui.dp(this, 10),
                Ui.dp(this, 10)
        );
        root.addView(exportButton, exportParams);
        exportButton.setOnClickListener(view -> chooseOutputFile());

        deleteButton.setEnabled(false);
        setContentView(root);
        updateControls();
    }

    private void addToolButton(LinearLayout row, Button button) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.rightMargin = Ui.dp(this, 8);
        row.addView(button, params);
    }

    private void loadDocument() {
        setBusy(true, "Načítavam dokument…");
        new Thread(() -> {
            try {
                if (inputIsPdf) {
                    ParcelFileDescriptor descriptor =
                            getContentResolver().openFileDescriptor(inputUri, "r");
                    if (descriptor == null) {
                        throw new IOException("PDF sa nepodarilo otvoriť.");
                    }
                    PdfRenderer renderer = new PdfRenderer(descriptor);
                    if (renderer.getPageCount() <= 0) {
                        renderer.close();
                        throw new IOException("PDF neobsahuje žiadnu stranu.");
                    }
                    pdfRenderer = renderer;
                    pageCount = renderer.getPageCount();
                    runOnUiThread(() -> {
                        documentLoaded = true;
                        setBusy(false, "Dokument je otvorený.");
                        renderPage(0);
                    });
                } else {
                    Bitmap bitmap = DocumentFiles.decodeImage(
                            this,
                            inputUri,
                            2800
                    );
                    imagePreview = bitmap;
                    pageCount = 1;
                    runOnUiThread(() -> {
                        documentLoaded = true;
                        currentPage = 0;
                        setDisplayedBitmap(imagePreview, 0);
                        setBusy(false, "Dokument je pripravený. Vyberte podpis alebo pečiatku.");
                        updateControls();
                    });
                }
            } catch (Exception exception) {
                runOnUiThread(() -> showLoadError(exception));
            }
        }, "document-loader").start();
    }

    private void renderPage(int pageIndex) {
        if (!documentLoaded || busy || pageIndex < 0 || pageIndex >= pageCount) {
            return;
        }
        if (!inputIsPdf) {
            currentPage = 0;
            setDisplayedBitmap(imagePreview, 0);
            updateControls();
            return;
        }

        setBusy(true, "Načítavam stranu " + (pageIndex + 1) + "…");
        new Thread(() -> {
            try {
                Bitmap bitmap = DocumentFiles.renderPdfPage(
                        pdfRenderer,
                        pageIndex,
                        1900
                );
                runOnUiThread(() -> {
                    currentPage = pageIndex;
                    setDisplayedBitmap(bitmap, pageIndex);
                    setBusy(false, "Strana je pripravená. Vyberte podpis alebo pečiatku.");
                    updateControls();
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    setBusy(false, "Stranu sa nepodarilo načítať.");
                    Toast.makeText(
                            this,
                            safeMessage(exception),
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        }, "pdf-page-renderer").start();
    }

    private void setDisplayedBitmap(Bitmap bitmap, int pageIndex) {
        Bitmap previous = displayedPageBitmap;
        displayedPageBitmap = bitmap;
        editorView.setPage(
                bitmap,
                pageIndex,
                bitmap.getWidth(),
                bitmap.getHeight()
        );
        if (previous != null
                && previous != bitmap
                && previous != imagePreview
                && !previous.isRecycled()) {
            previous.recycle();
        }
    }

    private boolean ensureReady() {
        if (!documentLoaded || busy || displayedPageBitmap == null) {
            Toast.makeText(this, "Počkajte na načítanie dokumentu.", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void confirmClearPage() {
        if (!ensureReady()) {
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Vyčistiť stranu?")
                .setMessage("Zo strany sa odstránia všetky vložené podpisy a pečiatky.")
                .setNegativeButton("Zrušiť", null)
                .setPositiveButton("Odstrániť", (dialog, which) -> {
                    editorView.clearCurrentPage();
                    statusText.setText("Vložené prvky boli z tejto strany odstránené.");
                })
                .show();
    }

    private void chooseOutputFile() {
        if (!ensureReady()) {
            return;
        }
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, suggestedOutputName());
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_CREATE_PDF);
        } catch (Exception exception) {
            Toast.makeText(
                    this,
                    "V telefóne nie je dostupné uloženie súboru.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_CREATE_PDF
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }
        exportTo(data.getData());
    }

    private void exportTo(Uri outputUri) {
        List<Placement> snapshot = copyPlacements(editorView.getPlacements());
        setBusy(true, "Pripravujem výsledné PDF…");
        editorView.setEnabled(false);

        new Thread(() -> {
            try {
                PdfExporter.export(
                        this,
                        inputUri,
                        inputIsPdf,
                        snapshot,
                        outputUri,
                        (page, total) -> runOnUiThread(() ->
                                statusText.setText(
                                        String.format(
                                                Locale.getDefault(),
                                                "Vytváram PDF: strana %d z %d…",
                                                page,
                                                total
                                        )
                                )
                        )
                );
                runOnUiThread(() -> {
                    editorView.setEnabled(true);
                    setBusy(false, "PDF bolo úspešne vytvorené.");
                    showExportSuccess(outputUri);
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    editorView.setEnabled(true);
                    setBusy(false, "PDF sa nepodarilo vytvoriť.");
                    new AlertDialog.Builder(this)
                            .setTitle("Export zlyhal")
                            .setMessage(safeMessage(exception))
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        }, "pdf-exporter").start();
    }

    private List<Placement> copyPlacements(List<Placement> source) {
        ArrayList<Placement> copy = new ArrayList<>(source.size());
        for (Placement item : source) {
            Placement cloned = new Placement(
                    item.bitmap,
                    item.label,
                    item.pageIndex,
                    item.centerX,
                    item.centerY,
                    item.width,
                    item.height
            );
            cloned.rotationDegrees = item.rotationDegrees;
            copy.add(cloned);
        }
        return copy;
    }

    private void showExportSuccess(Uri outputUri) {
        new AlertDialog.Builder(this)
                .setTitle("PDF je uložené")
                .setMessage("Nové podpísané PDF bolo vytvorené. Pôvodný súbor zostal nezmenený.")
                .setPositiveButton("Zdieľať", (dialog, which) -> sharePdf(outputUri))
                .setNeutralButton("Otvoriť", (dialog, which) -> openPdf(outputUri))
                .setNegativeButton("Hotovo", null)
                .show();
    }

    private void sharePdf(Uri uri) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("application/pdf");
        share.putExtra(Intent.EXTRA_STREAM, uri);
        share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(share, "Zdieľať podpísané PDF"));
        } catch (Exception exception) {
            Toast.makeText(this, "PDF sa nepodarilo zdieľať.", Toast.LENGTH_LONG).show();
        }
    }

    private void openPdf(Uri uri) {
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, "application/pdf");
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(view);
        } catch (Exception exception) {
            Toast.makeText(
                    this,
                    "V telefóne nie je aplikácia na otvorenie PDF.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void setBusy(boolean isBusy, String message) {
        busy = isBusy;
        progressBar.setVisibility(isBusy ? View.VISIBLE : View.GONE);
        if (message != null) {
            statusText.setText(message);
        }
        updateControls();
    }

    private void updateControls() {
        if (previousButton == null) {
            return;
        }
        pageText.setText(
                String.format(
                        Locale.getDefault(),
                        "Strana %d / %d",
                        currentPage + 1,
                        pageCount
                )
        );
        previousButton.setEnabled(documentLoaded && !busy && currentPage > 0);
        nextButton.setEnabled(documentLoaded && !busy && currentPage < pageCount - 1);
        exportButton.setEnabled(documentLoaded && !busy);
        deleteButton.setEnabled(!busy && editorView.getActivePlacement() != null);
    }

    private void updateStatusForSelection() {
        Placement active = editorView.getActivePlacement();
        if (active != null && !busy) {
            statusText.setText(
                    active.label
                            + ": presuňte jedným prstom, dvoma upravte veľkosť a otočenie."
            );
        }
    }

    private String suggestedOutputName() {
        String base = inputName;
        int dot = base.lastIndexOf('.');
        if (dot > 0) {
            base = base.substring(0, dot);
        }
        return base + "_podpisane.pdf";
    }

    private void showLoadError(Exception exception) {
        setBusy(false, "Dokument sa nepodarilo načítať.");
        new AlertDialog.Builder(this)
                .setTitle("Dokument nemožno otvoriť")
                .setMessage(safeMessage(exception))
                .setCancelable(false)
                .setPositiveButton("Zavrieť", (dialog, which) -> finish())
                .show();
    }

    private static String safeMessage(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.trim().isEmpty()) {
            return "Nastala neočakávaná chyba.";
        }
        return message;
    }

    @Override
    protected void onDestroy() {
        if (pdfRenderer != null) {
            try {
                synchronized (pdfRenderer) {
                    pdfRenderer.close();
                }
            } catch (Exception ignored) {
                // Best effort.
            }
            pdfRenderer = null;
        }
        if (displayedPageBitmap != null
                && displayedPageBitmap != imagePreview
                && !displayedPageBitmap.isRecycled()) {
            displayedPageBitmap.recycle();
        }
        if (imagePreview != null && !imagePreview.isRecycled()) {
            imagePreview.recycle();
        }
        super.onDestroy();
    }
}
