package sk.strechostav.pdfpodpisovac;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_DOCUMENT = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();

        Intent launchIntent = getIntent();
        if (launchIntent != null
                && Intent.ACTION_VIEW.equals(launchIntent.getAction())
                && launchIntent.getData() != null) {
            openEditor(
                    launchIntent.getData(),
                    launchIntent.getType(),
                    launchIntent.getFlags()
            );
        }
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.rgb(243, 246, 250));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                Ui.dp(this, 20),
                Ui.dp(this, 34),
                Ui.dp(this, 20),
                Ui.dp(this, 44)
        );
        scrollView.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView title = Ui.text(this, "PDF Podpisovač", 30, Color.rgb(24, 34, 49));
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView subtitle = Ui.text(
                this,
                "Vložte podpis, pečiatku alebo ručne nakreslený podpis do PDF či obrázka. "
                        + "Spracovanie prebieha iba vo vašom telefóne.",
                16,
                Color.rgb(74, 84, 101)
        );
        subtitle.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams subtitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        subtitleParams.topMargin = Ui.dp(this, 8);
        root.addView(subtitle, subtitleParams);

        Button openButton = Ui.button(this, "Vybrať PDF alebo obrázok", true);
        LinearLayout.LayoutParams openParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        openParams.topMargin = Ui.dp(this, 22);
        root.addView(openButton, openParams);
        openButton.setOnClickListener(view -> chooseDocument());

        TextView presetsTitle = Ui.text(this, "Uložené podpisy", 20, Color.rgb(24, 34, 49));
        presetsTitle.setTypeface(presetsTitle.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams presetTitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        presetTitleParams.topMargin = Ui.dp(this, 28);
        root.addView(presetsTitle, presetTitleParams);

        root.addView(createPresetCard(
                "Samostatný podpis",
                R.drawable.preset_signature
        ));
        root.addView(createPresetCard(
                "Pečiatka s podpisom",
                R.drawable.preset_stamp_signature
        ));

        TextView note = Ui.text(
                this,
                "Pôvodný dokument sa neprepíše. Pri exporte si vždy vyberiete názov "
                        + "a umiestnenie nového PDF.",
                14,
                Color.rgb(80, 88, 102)
        );
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        noteParams.topMargin = Ui.dp(this, 22);
        root.addView(note, noteParams);

        setContentView(scrollView);
    }

    private LinearLayout createPresetCard(String label, int drawableResource) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(
                Ui.dp(this, 14),
                Ui.dp(this, 14),
                Ui.dp(this, 14),
                Ui.dp(this, 14)
        );
        card.setBackground(Ui.cardBackground(this));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        cardParams.topMargin = Ui.dp(this, 12);
        card.setLayoutParams(cardParams);

        TextView title = Ui.text(this, label, 16, Color.rgb(28, 36, 49));
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        card.addView(title);

        Bitmap transparent = BitmapFactory.decodeResource(getResources(), drawableResource);
        int width = Math.max(Ui.dp(this, 280), getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 68));
        int height = label.startsWith("Pečiatka") ? Ui.dp(this, 170) : Ui.dp(this, 140);
        Bitmap preview = DocumentFiles.createCheckerPreview(transparent, width, height);

        ImageView image = new ImageView(this);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageBitmap(preview);
        image.setContentDescription(label);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                height
        );
        imageParams.topMargin = Ui.dp(this, 10);
        card.addView(image, imageParams);
        return card;
    }

    private void chooseDocument() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(
                Intent.EXTRA_MIME_TYPES,
                new String[]{"application/pdf", "image/jpeg", "image/png", "image/webp"}
        );
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_OPEN_DOCUMENT);
        } catch (Exception exception) {
            Toast.makeText(
                    this,
                    "V telefóne nie je dostupný výber súborov.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_OPEN_DOCUMENT
                || resultCode != RESULT_OK
                || data == null
                || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        int flags = data.getFlags();
        try {
            getContentResolver().takePersistableUriPermission(
                    uri,
                    flags & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            );
        } catch (Exception ignored) {
            // Some document providers grant access only for the current task.
        }
        openEditor(uri, data.getType(), flags);
    }

    private void openEditor(Uri uri, String mimeType, int flags) {
        Intent editor = new Intent(this, EditorActivity.class);
        editor.putExtra(EditorActivity.EXTRA_DOCUMENT_URI, uri.toString());
        editor.putExtra(EditorActivity.EXTRA_MIME_TYPE, mimeType);
        editor.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if ((flags & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) != 0) {
            editor.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        }
        startActivity(editor);
    }
}
