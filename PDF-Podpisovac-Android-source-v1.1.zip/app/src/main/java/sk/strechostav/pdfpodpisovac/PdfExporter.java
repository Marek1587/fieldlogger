package sk.strechostav.pdfpodpisovac;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

final class PdfExporter {
    interface ProgressListener {
        void onProgress(int currentPage, int totalPages);
    }

    private static final Paint BITMAP_PAINT =
            new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

    private PdfExporter() {
    }

    static void export(
            Context context,
            Uri inputUri,
            boolean inputIsPdf,
            List<Placement> placements,
            Uri outputUri,
            ProgressListener progressListener
    ) throws IOException {
        if (inputIsPdf) {
            exportPdf(context, inputUri, placements, outputUri, progressListener);
        } else {
            exportImage(context, inputUri, placements, outputUri, progressListener);
        }
    }

    private static void exportPdf(
            Context context,
            Uri inputUri,
            List<Placement> placements,
            Uri outputUri,
            ProgressListener progressListener
    ) throws IOException {
        ParcelFileDescriptor descriptor =
                context.getContentResolver().openFileDescriptor(inputUri, "r");
        if (descriptor == null) {
            throw new IOException("Vstupné PDF sa nepodarilo otvoriť.");
        }

        PdfDocument outputDocument = new PdfDocument();
        try (PdfRenderer renderer = new PdfRenderer(descriptor)) {
            int totalPages = renderer.getPageCount();
            for (int pageIndex = 0; pageIndex < totalPages; pageIndex++) {
                if (progressListener != null) {
                    progressListener.onProgress(pageIndex + 1, totalPages);
                }
                renderPdfPageIntoDocument(
                        renderer,
                        outputDocument,
                        placements,
                        pageIndex
                );
            }
            writeDocument(context, outputDocument, outputUri);
        } catch (SecurityException exception) {
            throw new IOException(
                    "PDF je chránené heslom alebo nepodporovaným zabezpečením.",
                    exception
            );
        } finally {
            outputDocument.close();
        }
    }

    private static void renderPdfPageIntoDocument(
            PdfRenderer renderer,
            PdfDocument outputDocument,
            List<Placement> placements,
            int pageIndex
    ) {
        try (PdfRenderer.Page sourcePage = renderer.openPage(pageIndex)) {
            int pageWidth = Math.max(1, sourcePage.getWidth());
            int pageHeight = Math.max(1, sourcePage.getHeight());
            float scale = Math.min(2.35f, 2600f / Math.max(pageWidth, pageHeight));
            scale = Math.max(0.35f, scale);
            int bitmapWidth = Math.max(1, Math.round(pageWidth * scale));
            int bitmapHeight = Math.max(1, Math.round(pageHeight * scale));

            Bitmap renderedPage =
                    Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888);
            renderedPage.eraseColor(Color.WHITE);
            Matrix renderMatrix = new Matrix();
            renderMatrix.setScale(scale, scale);
            sourcePage.render(
                    renderedPage,
                    null,
                    renderMatrix,
                    PdfRenderer.Page.RENDER_MODE_FOR_PRINT
            );

            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(
                    pageWidth,
                    pageHeight,
                    pageIndex + 1
            ).create();
            PdfDocument.Page outputPage = outputDocument.startPage(pageInfo);
            Canvas canvas = outputPage.getCanvas();
            canvas.drawColor(Color.WHITE);
            canvas.drawBitmap(
                    renderedPage,
                    null,
                    new RectF(0, 0, pageWidth, pageHeight),
                    BITMAP_PAINT
            );
            drawPlacements(canvas, placements, pageIndex, pageWidth, pageHeight);
            outputDocument.finishPage(outputPage);
            renderedPage.recycle();
        }
    }

    private static void exportImage(
            Context context,
            Uri inputUri,
            List<Placement> placements,
            Uri outputUri,
            ProgressListener progressListener
    ) throws IOException {
        if (progressListener != null) {
            progressListener.onProgress(1, 1);
        }
        Bitmap image = DocumentFiles.decodeImage(context, inputUri, 5000);
        int imageWidth = image.getWidth();
        int imageHeight = image.getHeight();

        int pageWidth;
        int pageHeight;
        if (imageWidth >= imageHeight) {
            pageWidth = 842;
            pageHeight = Math.max(72, Math.round(842f * imageHeight / imageWidth));
        } else {
            pageHeight = 842;
            pageWidth = Math.max(72, Math.round(842f * imageWidth / imageHeight));
        }

        PdfDocument document = new PdfDocument();
        try {
            PdfDocument.PageInfo pageInfo =
                    new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();
            canvas.drawColor(Color.WHITE);

            RectF destination = fitInside(
                    imageWidth,
                    imageHeight,
                    0f,
                    0f,
                    pageWidth,
                    pageHeight
            );
            canvas.drawBitmap(image, null, destination, BITMAP_PAINT);
            drawPlacements(canvas, placements, 0, pageWidth, pageHeight);
            document.finishPage(page);
            writeDocument(context, document, outputUri);
        } finally {
            document.close();
            image.recycle();
        }
    }

    private static void drawPlacements(
            Canvas canvas,
            List<Placement> placements,
            int pageIndex,
            float pageWidth,
            float pageHeight
    ) {
        for (Placement placement : placements) {
            if (placement.pageIndex != pageIndex || placement.bitmap == null) {
                continue;
            }
            float centerX = placement.centerX * pageWidth;
            float centerY = placement.centerY * pageHeight;
            float width = placement.width * pageWidth;
            float height = placement.height * pageHeight;
            RectF destination = new RectF(
                    centerX - width / 2f,
                    centerY - height / 2f,
                    centerX + width / 2f,
                    centerY + height / 2f
            );

            canvas.save();
            canvas.rotate(placement.rotationDegrees, centerX, centerY);
            canvas.drawBitmap(placement.bitmap, null, destination, BITMAP_PAINT);
            canvas.restore();
        }
    }

    private static RectF fitInside(
            int sourceWidth,
            int sourceHeight,
            float left,
            float top,
            float right,
            float bottom
    ) {
        float availableWidth = right - left;
        float availableHeight = bottom - top;
        float scale = Math.min(
                availableWidth / sourceWidth,
                availableHeight / sourceHeight
        );
        float width = sourceWidth * scale;
        float height = sourceHeight * scale;
        float x = left + (availableWidth - width) / 2f;
        float y = top + (availableHeight - height) / 2f;
        return new RectF(x, y, x + width, y + height);
    }

    private static void writeDocument(
            Context context,
            PdfDocument document,
            Uri outputUri
    ) throws IOException {
        try (OutputStream stream =
                     context.getContentResolver().openOutputStream(outputUri, "w")) {
            if (stream == null) {
                throw new IOException("Výstupný súbor sa nepodarilo vytvoriť.");
            }
            document.writeTo(stream);
            stream.flush();
        }
    }
}
