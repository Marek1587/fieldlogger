package sk.strechostav.pdfpodpisovac;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

final class SignatureDialog {
    interface Listener {
        void onSignatureReady(Bitmap bitmap);
    }

    private SignatureDialog() {
    }

    static void show(Context context, Listener listener) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                Ui.dp(context, 18),
                Ui.dp(context, 28),
                Ui.dp(context, 18),
                Ui.dp(context, 26)
        );
        root.setBackgroundColor(Color.WHITE);

        TextView title = Ui.text(context, "Podpíšte sa prstom", 21, Color.rgb(28, 36, 49));
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        TextView help = Ui.text(
                context,
                "Podpis nakreslite do bieleho poľa. Sivá čiara je iba pomôcka a do PDF sa neuloží.",
                14,
                Color.rgb(80, 88, 102)
        );
        LinearLayout.LayoutParams helpParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        helpParams.topMargin = Ui.dp(context, 6);
        root.addView(help, helpParams);

        SignatureDrawView drawView = new SignatureDrawView(context);

        TextView colorTitle = Ui.text(
                context,
                "Farba pera",
                15,
                Color.rgb(28, 36, 49)
        );
        colorTitle.setTypeface(
                colorTitle.getTypeface(),
                android.graphics.Typeface.BOLD
        );
        LinearLayout.LayoutParams colorTitleParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        colorTitleParams.topMargin = Ui.dp(context, 14);
        root.addView(colorTitle, colorTitleParams);

        RadioGroup colorGroup = new RadioGroup(context);
        colorGroup.setOrientation(RadioGroup.HORIZONTAL);
        colorGroup.setGravity(Gravity.START);

        int blueColor = Color.rgb(36, 55, 190);
        int redColor = Color.rgb(198, 40, 40);
        int blackColor = Color.BLACK;
        RadioButton blue = createColorOption(context, "Modrá", blueColor);
        RadioButton red = createColorOption(context, "Červená", redColor);
        RadioButton black = createColorOption(context, "Čierna", blackColor);
        colorGroup.addView(blue);
        colorGroup.addView(red);
        colorGroup.addView(black);
        colorGroup.check(blue.getId());
        colorGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == red.getId()) {
                drawView.setInkColor(redColor);
            } else if (checkedId == black.getId()) {
                drawView.setInkColor(blackColor);
            } else {
                drawView.setInkColor(blueColor);
            }
        });
        root.addView(colorGroup);

        TextView thicknessTitle = Ui.text(
                context,
                "Hrúbka čiary: 5",
                15,
                Color.rgb(28, 36, 49)
        );
        thicknessTitle.setTypeface(
                thicknessTitle.getTypeface(),
                android.graphics.Typeface.BOLD
        );
        LinearLayout.LayoutParams thicknessParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        thicknessParams.topMargin = Ui.dp(context, 8);
        root.addView(thicknessTitle, thicknessParams);

        SeekBar thickness = new SeekBar(context);
        thickness.setMax(14);
        thickness.setProgress(3);
        thickness.setContentDescription("Hrúbka čiary podpisu");
        thickness.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int width = progress + 2;
                thicknessTitle.setText("Hrúbka čiary: " + width);
                drawView.setStrokeWidthDp(width);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed.
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No action needed.
            }
        });
        root.addView(thickness, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));

        LinearLayout.LayoutParams drawParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(context, 280)
        );
        drawParams.topMargin = Ui.dp(context, 10);
        root.addView(drawView, drawParams);

        LinearLayout buttons = new LinearLayout(context);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.END);

        Button clear = Ui.button(context, "Vymazať", false);
        Button cancel = Ui.button(context, "Zrušiť", false);
        Button use = Ui.button(context, "Použiť podpis", true);

        LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        buttonParams.setMargins(Ui.dp(context, 6), Ui.dp(context, 14), 0, 0);
        buttons.addView(clear, buttonParams);
        buttons.addView(cancel, buttonParams);
        buttons.addView(use, buttonParams);
        root.addView(buttons);

        clear.setOnClickListener(view -> drawView.clearSignature());
        cancel.setOnClickListener(view -> dialog.dismiss());
        use.setOnClickListener(view -> {
            Bitmap bitmap = drawView.createTransparentSignature();
            if (bitmap == null) {
                Toast.makeText(context, "Najprv nakreslite podpis.", Toast.LENGTH_SHORT).show();
                return;
            }
            listener.onSignatureReady(bitmap);
            dialog.dismiss();
        });

        ScrollView scrollView = new ScrollView(context);
        scrollView.setFillViewport(true);
        scrollView.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        dialog.setContentView(scrollView);
        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setLayout(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT
            );
            window.setGravity(Gravity.CENTER);
        }
    }

    private static RadioButton createColorOption(
            Context context,
            String label,
            int color
    ) {
        RadioButton option = new RadioButton(context);
        option.setId(View.generateViewId());
        option.setText(label);
        option.setTextColor(color);
        option.setTextSize(15);
        option.setPadding(0, 0, Ui.dp(context, 12), 0);
        return option;
    }
}
