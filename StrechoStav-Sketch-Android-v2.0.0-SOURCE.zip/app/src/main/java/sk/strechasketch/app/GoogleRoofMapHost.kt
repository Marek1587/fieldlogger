package sk.strechasketch.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Point
import android.graphics.PointF
import android.os.Bundle
import android.widget.FrameLayout
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import kotlin.math.roundToInt

@SuppressLint("ViewConstructor")
class GoogleRoofMapHost(
    context: Context,
    val project: RoofProject
) : FrameLayout(context), OnMapReadyCallback {
    val editor = RoofMapEditorView(context, project)
    private val mapView = MapView(context)
    private var map: GoogleMap? = null
    private var pendingMapType = project.mapType

    init {
        addView(mapView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(editor, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        mapView.onCreate(null)
        mapView.getMapAsync(this)
        editor.onModeChanged = { mode ->
            map?.uiSettings?.setAllGesturesEnabled(mode == EditorMode.PAN)
        }
        editor.onCameraRequested = { point, zoom ->
            map?.animateCamera(CameraUpdateFactory.newLatLngZoom(point.latLng(), zoom.toFloat()))
        }
        editor.onFitRequested = ::fitToPolygon
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        googleMap.mapType = googleMapType(pendingMapType)
        googleMap.isBuildingsEnabled = true
        googleMap.isIndoorEnabled = false
        googleMap.uiSettings.isMapToolbarEnabled = false
        googleMap.uiSettings.isZoomControlsEnabled = false
        googleMap.uiSettings.isCompassEnabled = true
        googleMap.uiSettings.setAllGesturesEnabled(editor.mode == EditorMode.PAN)
        googleMap.moveCamera(
            CameraUpdateFactory.newLatLngZoom(
                LatLng(project.centerLat, project.centerLon),
                project.zoom.toFloat()
            )
        )
        googleMap.setOnCameraMoveListener { editor.invalidate() }
        googleMap.setOnCameraIdleListener {
            val camera = googleMap.cameraPosition
            project.centerLat = camera.target.latitude
            project.centerLon = camera.target.longitude
            project.zoom = camera.zoom.roundToInt().coerceIn(3, 21)
            editor.invalidate()
        }
        editor.projectPointToScreen = { point ->
            googleMap.projection.toScreenLocation(point.latLng()).let { PointF(it.x.toFloat(), it.y.toFloat()) }
        }
        editor.screenPointToProject = { x, y ->
            googleMap.projection.fromScreenLocation(Point(x.roundToInt(), y.roundToInt())).let {
                GeoPoint(it.latitude, it.longitude)
            }
        }
        editor.invalidate()
    }

    fun setMapType(type: String) {
        pendingMapType = type
        project.mapType = type
        map?.mapType = googleMapType(type)
        editor.invalidate()
    }

    fun onCreate(state: Bundle?) {
        // MapView je vytvorený už v init; metóda ostáva pre symetrické lifecycle API hostiteľa.
    }

    fun onResume() = mapView.onResume()
    fun onPause() = mapView.onPause()
    fun onDestroy() = mapView.onDestroy()
    fun onLowMemory() = mapView.onLowMemory()

    private fun fitToPolygon(points: List<GeoPoint>) {
        val googleMap = map ?: return
        if (points.isEmpty()) return
        if (points.size == 1) {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(points.first().latLng(), 20f))
            return
        }
        val builder = LatLngBounds.Builder()
        points.forEach { builder.include(it.latLng()) }
        post {
            runCatching {
                googleMap.animateCamera(CameraUpdateFactory.newLatLngBounds(builder.build(), 72))
            }
        }
    }

    private fun googleMapType(type: String): Int = when (type.uppercase()) {
        "SATELLITE" -> GoogleMap.MAP_TYPE_SATELLITE
        "TERRAIN" -> GoogleMap.MAP_TYPE_TERRAIN
        "NORMAL" -> GoogleMap.MAP_TYPE_NORMAL
        else -> GoogleMap.MAP_TYPE_HYBRID
    }

    private fun GeoPoint.latLng() = LatLng(lat, lon)
}
