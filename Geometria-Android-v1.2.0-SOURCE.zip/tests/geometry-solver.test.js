const assert = require("node:assert/strict");
const test = require("node:test");
const Solver = require("../app/src/main/assets/geometry-solver.js");

test("655 cm a 55,9 cm vytvorí 11 dielov a kraje 20,05 cm", function () {
  const result = Solver.calculateBasicLayout({ targetLength: Solver.parseDimension("655", "cm"), nominalWidth: Solver.parseDimension("55,9", "cm") });
  assert.equal(result.fullPieceCount, 11);
  assert.equal(result.remainder, Solver.parseDimension("40,1", "cm"));
  assert.equal(result.leftEdge, Solver.parseDimension("20,05", "cm"));
  assert.equal(result.rightEdge, Solver.parseDimension("20,05", "cm"));
});

test("+10 mm sa rozdelí na 10 dielov po +1 mm", function () {
  const result = Solver.solveCorrection({ targetLength: 656000, nominalWidth: 55900, fixedLeft: 20050, fixedRight: 20050, minCorrection: 1000, maxCorrection: 1000, step: 100, pieceCount: 11 });
  assert.equal(result.pieces.filter(function (piece) { return piece.correction === 100; }).length, 10);
  assert.equal(result.pieces.filter(function (piece) { return piece.correction === 0; }).length, 1);
  assert.equal(result.achievedLength, 656000);
  assert.equal(result.residualError, 0);
});

test("-20 mm sa rozdelí na 9 dielov po -2 mm a 2 po -1 mm", function () {
  const result = Solver.solveCorrection({ targetLength: 653000, nominalWidth: 55900, fixedLeft: 20050, fixedRight: 20050, minCorrection: 1000, maxCorrection: 1000, step: 100, pieceCount: 11 });
  assert.equal(result.pieces.filter(function (piece) { return piece.correction === -200; }).length, 9);
  assert.equal(result.pieces.filter(function (piece) { return piece.correction === -100; }).length, 2);
  assert.equal(result.achievedLength, 653000);
});

test("Pytagorova veta počíta vždy tretiu stranu", function () {
  const values = { a: 300000, b: 400000, c: 0 };
  const hypotenuse = Solver.solveRightTriangle(values, ["a", "b"]);
  assert.equal(hypotenuse.computedSide, "c");
  assert.equal(hypotenuse.values.c, 500000);
  const leg = Solver.solveRightTriangle(hypotenuse.values, ["b", "c"]);
  assert.equal(leg.computedSide, "a");
  assert.equal(leg.values.a, 300000);
});

test("uhlovanie obdĺžnika vypočíta symetrickú korekciu každého rohu", function () {
  const result = Solver.solveRectangleSquaring({ length: 400000, d1: 500000, d2: 503200 });
  assert.equal(result.ok, true);
  assert.equal(result.longerDiagonal, "d2");
  assert.equal(result.x, 1003);
  assert.equal(result.wholeSideShift, 2006);
  const reversed = Solver.solveRectangleSquaring({ length: 400000, d1: 503200, d2: 500000 });
  assert.equal(reversed.longerDiagonal, "d1");
  assert.equal(reversed.x, result.x);
});

test("kolmica pásu vypočíta posun X zo šírky a uhla", function () {
  const result = Solver.solveSheetPerpendicular({ width: 10000, angleDegrees: 45 });
  assert.equal(result.ok, true);
  assert.equal(result.x, 10000);
  const shallow = Solver.solveSheetPerpendicular({ width: 10000, angleDegrees: 30 });
  assert.equal(shallow.x, 5774);
});
