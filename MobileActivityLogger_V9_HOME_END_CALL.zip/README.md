# Mobile Activity Logger V9 - Home Ends Call

## Change

- If a call is active and Android switches to the home screen / launcher,
  the app immediately treats the call as ended.
- The "O čom bol hovor?" dialog opens right away after returning home.
- Fallback grace reduced to about 12 seconds.
- Keeps:
  - battery notification spam filter
  - call grouping
  - one CALL_NOTE only
  - navigation start/end only
  - visible version in app status

Version:
- 2.7-home-ends-call
- code 10
