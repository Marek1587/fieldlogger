package sk.strechostav.mobileactivity

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class ScreenContextAccessibilityService : AccessibilityService() {
    private var lastKey: String = ""
    private var lastWriteMillis: Long = 0L

    private var mapsNavActive: Boolean = false
    private var mapsNavStartMillis: Long = 0L
    private var mapsNavStartTitle: String = ""
    private var mapsNavLastTitle: String = ""
    private var mapsNavLastText: String = ""

    private var callActive: Boolean = false
    private var callStartMillis: Long = 0L
    private var callLastSeenMillis: Long = 0L
    private var callContact: String = ""
    private var callNumber: String = ""
    private var callLastText: String = ""
    private var callLastTitle: String = ""
    private var callNoteLaunched: Boolean = false

    // Neukončuj hovor okamžite pri zhasnutí displeja / lockscreen / prebliknutí okna.
    // Ukončí sa až keď sa hovorová obrazovka neukáže cca 12 sekúnd.
    private val callEndGraceMillis = 12_000L

    private val launcherPackages = setOf(
        "com.sec.android.app.launcher",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher"
    )

    private val ignoredPackages = setOf(
        "sk.strechostav.mobileactivity",
        "sk.strechostav.fieldmanual",
        "sk.strechostav.fieldlogger",
        "com.sec.android.app.launcher",
        "com.android.launcher",
        "com.google.android.apps.nexuslauncher",
        "com.android.systemui",
        "com.google.android.inputmethod.latin",
        "com.samsung.android.honeyboard"
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString() ?: return
        val now = System.currentTimeMillis()

        if (ignoredPackages.contains(pkg)) {
            maybeEndMapsNavigation(pkg, now)

            // Ak po hovore príde domovská obrazovka, berieme to ako reálny koniec hovoru.
            // Toto je rýchlejšie než čakať ochrannú lehotu.
            if (callActive && isLauncherPackage(pkg)) {
                finishCall("home_screen_after_call", now)
            } else {
                maybeEndCallWithGrace(pkg, now)
            }

            return
        }

        val appName = appLabel(pkg)
        val cls = event.className?.toString() ?: ""
        val visibleText = collectVisibleText(rootInActiveWindow)
        val eventText = event.text?.joinToString(" ")?.trim() ?: ""
        val title = guessTitle(appName, eventText, visibleText)
        val screenText = visibleText.take(700)

        // Systémový šum: notifikačná lišta / nabíjanie batérie.
        if (isBatteryOrNotificationNoise(title, screenText)) {
            maybeEndCallWithGrace(pkg, now)
            maybeEndMapsNavigation(pkg, now)
            return
        }

        // Vlastné okno poznámky po hovore sa nesmie považovať za nový hovor.
        if (isOwnCallNoteDialog(title, screenText, pkg)) {
            return
        }

        // Telefonát: logujeme iba CALL_START a CALL_END, nie každú zmenu času hovoru.
        if (isRealCallScreen(pkg, screenText, title)) {
            handleCallUpdate(now, title, screenText, pkg, appName, cls)
            return
        } else {
            maybeEndCallWithGrace(pkg, now)
        }

        // Google Maps navigácia: logujeme iba NAVIGATION_START a NAVIGATION_END.
        if (isGoogleMaps(pkg)) {
            val nav = isMapsNavigation(screenText, title)
            if (nav) {
                handleMapsNavigationUpdate(now, title, screenText, pkg, appName, cls)
                return
            } else {
                maybeEndMapsNavigation(pkg, now)
            }
        } else {
            maybeEndMapsNavigation(pkg, now)
        }

        // Bežný screen context: deduplikácia a throttling.
        val key = "$pkg|$title|${screenText.take(160)}"
        if (key == lastKey && now - lastWriteMillis < 90_000L) return
        if (now - lastWriteMillis < 8_000L) return

        val eventMap = baseEvent(
            eventType = "SCREEN_CONTEXT",
            title = title,
            note = screenText
        ).toMutableMap()

        eventMap["package_name"] = pkg
        eventMap["app_name"] = appName
        eventMap["screen_class"] = cls
        eventMap["screen_title"] = title
        eventMap["screen_text"] = screenText
        eventMap["page_title_guess"] = pageTitleGuess(pkg, appName, title, screenText)
        eventMap["url_guess"] = urlGuess(screenText)
        eventMap["chatgpt_topic_guess"] = chatgptTopicGuess(pkg, appName, title, screenText)
        eventMap["capture_method"] = "accessibility_visible_text"
        eventMap["confidence"] = if (screenText.isNotBlank()) "0.70" else "0.35"

        LocalLogStore.appendLocal(this, eventMap)
        GoogleSync.sendOrQueue(this, eventMap)

        lastKey = key
        lastWriteMillis = now
    }

    override fun onInterrupt() {}

    // --------------------
    // CALL SESSION
    // --------------------

    private fun isBatteryOrNotificationNoise(title: String, screenText: String): Boolean {
        val t = (title + " | " + screenText).lowercase()
        val notificationShade = t.contains("oznámenia") || t.contains("notifications") || t.contains("rýchle nastavenia")
        val batteryPercent = Regex("""\d{1,3}\s*%""").containsMatchIn(t)
        val batteryText = t.contains("nabíja sa batéria") || t.contains("batéria") || t.contains("charging")
        return notificationShade && batteryText && batteryPercent
    }

    private fun isOwnCallNoteDialog(title: String, screenText: String, pkg: String): Boolean {
        val t = (title + " | " + screenText).lowercase()
        return pkg == "sk.strechostav.mobileactivity" ||
            t.contains("o čom bol hovor") ||
            t.contains("uložiť poznámku k hovoru") ||
            t.contains("zrušiť bez poznámky")
    }

    private fun isRealCallScreen(pkg: String, screenText: String, title: String): Boolean {
        val p = pkg.lowercase()
        val t = (title + " | " + screenText).lowercase()

        if (isOwnCallNoteDialog(title, screenText, pkg)) return false

        val hasRealCallControls =
            t.contains("uk. hov") ||
            t.contains("ukončiť hovor") ||
            t.contains("pridať hovor") ||
            t.contains("asistent pre hovory") ||
            (t.contains("stlmiť") && t.contains("reproduktor") && t.contains("bluetooth"))

        // Samsung niekedy po zhasnutí/rozsvietení displeja vráti package incallui,
        // ale text je z Kalendára alebo inej overlay obrazovky. Preto package sám nestačí.
        return p.contains("incallui") && hasRealCallControls
    }

    private fun handleCallUpdate(
        now: Long,
        title: String,
        screenText: String,
        pkg: String,
        appName: String,
        cls: String
    ) {
        callLastSeenMillis = now
        callLastText = screenText
        callLastTitle = title

        val contact = extractCallContact(screenText)
        val number = extractPhoneNumber(screenText)

        if (contact.isNotBlank()) callContact = contact
        if (number.isNotBlank()) callNumber = number

        if (!callActive) {
            callActive = true
            callStartMillis = now

            val shownContact = callContact.ifBlank { title.ifBlank { "Neznámy kontakt" } }

            val eventMap = baseEvent(
                eventType = "CALL_START",
                title = "Hovor začal: $shownContact",
                note = screenText
            ).toMutableMap()

            eventMap["package_name"] = pkg
            eventMap["app_name"] = appName
            eventMap["screen_class"] = cls
            eventMap["screen_title"] = title
            eventMap["screen_text"] = screenText
            eventMap["capture_method"] = "accessibility_call_start"
            eventMap["confidence"] = "0.85"

            LocalLogStore.appendLocal(this, eventMap)
            GoogleSync.sendOrQueue(this, eventMap)

            lastKey = "CALL_ACTIVE"
            lastWriteMillis = now
        }

        // Počas hovoru ignorujeme časovač hovoru a zmeny obrazovky.
    }

    private fun maybeEndCallWithGrace(currentPkg: String, now: Long) {
        if (!callActive) return

        val lastSeen = if (callLastSeenMillis > 0L) callLastSeenMillis else callStartMillis
        if (now - lastSeen < callEndGraceMillis) {
            return
        }

        finishCall(currentPkg, now)
    }

    private fun finishCall(currentPkg: String, now: Long) {
        if (!callActive) return

        val duration = ((now - callStartMillis) / 1000L).coerceAtLeast(0L)

        // Falošné mikro-hovory bez čísla ignorujeme.
        if (duration < 5L && callNumber.isBlank()) {
            resetCallState()
            return
        }

        val shownContact = callContact.ifBlank { callLastTitle.ifBlank { "Neznámy kontakt" } }
        val noteText =
            "Kontakt: $shownContact; číslo: $callNumber; trvanie: $duration s; posledný stav: $callLastTitle"

        val eventMap = baseEvent(
            eventType = "CALL_END",
            title = "Hovor ukončený: $shownContact",
            note = noteText
        ).toMutableMap()

        eventMap["package_name"] = "com.samsung.android.incallui"
        eventMap["app_name"] = "Volať"
        eventMap["start_time"] = formatTime(callStartMillis)
        eventMap["end_time"] = formatTime(now)
        eventMap["duration_sec"] = duration.toString()
        eventMap["screen_title"] = callLastTitle
        eventMap["screen_text"] = cleanCallScreenText(callLastText)
        eventMap["capture_method"] = "accessibility_call_end"
        eventMap["confidence"] = "0.85"

        LocalLogStore.appendLocal(this, eventMap)
        GoogleSync.sendOrQueue(this, eventMap)

        if (!callNoteLaunched) {
            callNoteLaunched = true
            launchCallNoteDialog(shownContact, callNumber, callStartMillis, now, duration)
        }

        resetCallState()

        lastKey = "CALL_END_$currentPkg"
        lastWriteMillis = now
    }

    private fun resetCallState() {
        callActive = false
        callStartMillis = 0L
        callLastSeenMillis = 0L
        callContact = ""
        callNumber = ""
        callLastText = ""
        callLastTitle = ""
        callNoteLaunched = false
    }

    private fun cleanCallScreenText(text: String): String {
        return text
            .replace(Regex("""\|\s*Počet minút:\s*\d+\s*Počet sekúnd:\s*\d+"""), "")
            .replace(Regex("""\|\s*\d{1,2}:\d{2}"""), "")
            .take(500)
    }

    private fun launchCallNoteDialog(contact: String, number: String, startMillis: Long, endMillis: Long, duration: Long) {
        try {
            val i = Intent(this, CallNoteActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.putExtra("contact", contact)
            i.putExtra("number", number)
            i.putExtra("start_time", formatTime(startMillis))
            i.putExtra("end_time", formatTime(endMillis))
            i.putExtra("duration_sec", duration.toString())
            startActivity(i)
        } catch (_: Exception) {
        }
    }

    private fun extractPhoneNumber(text: String): String {
        val regex = Regex("""(\+?\d[\d\s]{7,}\d)""")
        return regex.find(text)?.value?.replace(" ", "") ?: ""
    }

    private fun extractCallContact(text: String): String {
        val parts = text.split("|").map { it.trim() }.filter { it.isNotBlank() }

        val bad = setOf(
            "Asistent pre hovory",
            "Pridať hovor",
            "Tlačidlo",
            "Stlmiť",
            "Vypnúť",
            "Bluetooth",
            "Reproduktor",
            "Otvoriť klávesnicu",
            "Klávesnica",
            "Ďalšie",
            "Uk. hov.",
            "Mobil",
            "Slovensko"
        )

        for (p in parts) {
            if (p in bad) continue
            if (p.contains("Počet minút")) continue
            if (p.matches(Regex("""\d{1,2}:\d{2}"""))) continue
            if (p.matches(Regex("""\+?\d[\d\s]{7,}\d"""))) continue
            if (p.lowercase().contains("o čom bol hovor")) continue
            if (p.length in 2..60) return p
        }

        return ""
    }

    // --------------------
    // MAPS NAVIGATION
    // --------------------

    private fun handleMapsNavigationUpdate(
        now: Long,
        title: String,
        screenText: String,
        pkg: String,
        appName: String,
        cls: String
    ) {
        mapsNavLastTitle = title
        mapsNavLastText = screenText

        if (!mapsNavActive) {
            mapsNavActive = true
            mapsNavStartMillis = now
            mapsNavStartTitle = title

            val eventMap = baseEvent(
                eventType = "NAVIGATION_START",
                title = "Navigácia spustená: $title",
                note = screenText
            ).toMutableMap()

            eventMap["package_name"] = pkg
            eventMap["app_name"] = appName
            eventMap["screen_class"] = cls
            eventMap["screen_title"] = title
            eventMap["screen_text"] = screenText
            eventMap["page_title_guess"] = "Google Maps navigácia"
            eventMap["capture_method"] = "accessibility_navigation_start"
            eventMap["confidence"] = "0.85"

            LocalLogStore.appendLocal(this, eventMap)
            GoogleSync.sendOrQueue(this, eventMap)

            lastKey = "MAPS_NAVIGATION_ACTIVE"
            lastWriteMillis = now
        }
    }

    private fun maybeEndMapsNavigation(currentPkg: String, now: Long) {
        if (!mapsNavActive) return

        val duration = ((now - mapsNavStartMillis) / 1000L).coerceAtLeast(0L)

        val eventMap = baseEvent(
            eventType = "NAVIGATION_END",
            title = "Navigácia ukončená",
            note = "Začiatok: $mapsNavStartTitle; posledný stav: $mapsNavLastTitle; trvanie: $duration s"
        ).toMutableMap()

        eventMap["package_name"] = "com.google.android.apps.maps"
        eventMap["app_name"] = "Mapy"
        eventMap["start_time"] = formatTime(mapsNavStartMillis)
        eventMap["end_time"] = formatTime(now)
        eventMap["duration_sec"] = duration.toString()
        eventMap["screen_title"] = mapsNavLastTitle
        eventMap["screen_text"] = mapsNavLastText
        eventMap["page_title_guess"] = "Google Maps navigácia"
        eventMap["capture_method"] = "accessibility_navigation_end"
        eventMap["confidence"] = "0.85"

        LocalLogStore.appendLocal(this, eventMap)
        GoogleSync.sendOrQueue(this, eventMap)

        mapsNavActive = false
        mapsNavStartMillis = 0L
        mapsNavStartTitle = ""
        mapsNavLastTitle = ""
        mapsNavLastText = ""

        lastKey = "MAPS_NAVIGATION_END_$currentPkg"
        lastWriteMillis = now
    }

    private fun isGoogleMaps(pkg: String): Boolean {
        return pkg == "com.google.android.apps.maps"
    }

    private fun isMapsNavigation(screenText: String, title: String): Boolean {
        val t = (title + " | " + screenText).lowercase()

        return (
            t.contains("čas do príchodu") ||
            t.contains("zostávajúca vzdialenosť") ||
            t.contains("zavrieť navigáciu") ||
            t.contains("hľadať na trase") ||
            t.contains("ukážka trasy") ||
            t.contains("obmedzenie rýchlosti") ||
            t.contains("zdieľať priebeh cesty") ||
            (t.contains("km") && t.contains("do príchodu"))
        )
    }

    // --------------------
    // GENERIC SCREEN TEXT
    // --------------------

    private fun collectVisibleText(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val out = ArrayList<String>()
        collectNode(root, out, 0)
        return out
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(" | ")
            .take(900)
    }

    private fun collectNode(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 8 || out.size > 50) return
        if (node.isPassword) return

        val cls = node.className?.toString()?.lowercase() ?: ""
        if (cls.contains("edittext")) return

        val txt = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()

        if (!txt.isNullOrBlank() && txt.length <= 160) out.add(txt)
        if (!desc.isNullOrBlank() && desc.length <= 160) out.add(desc)

        for (i in 0 until node.childCount) {
            collectNode(node.getChild(i), out, depth + 1)
        }
    }

    private fun guessTitle(appName: String, eventText: String, visibleText: String): String {
        val candidates = listOf(eventText, visibleText.split("|").firstOrNull() ?: "", appName)
        return candidates.firstOrNull { it.trim().isNotBlank() }?.trim()?.take(180) ?: appName
    }

    private fun pageTitleGuess(pkg: String, appName: String, title: String, text: String): String {
        val p = pkg.lowercase()
        val a = appName.lowercase()
        return if (p.contains("chrome") || p.contains("browser") || a.contains("browser") || a.contains("chrome")) title else ""
    }

    private fun chatgptTopicGuess(pkg: String, appName: String, title: String, text: String): String {
        val p = pkg.lowercase()
        val a = appName.lowercase()
        val t = (title + " " + text).lowercase()
        return if (p.contains("openai") || a.contains("chatgpt") || t.contains("chatgpt")) title else ""
    }

    private fun urlGuess(text: String): String {
        val regex = Regex("""https?://[^\s|]+""")
        return regex.find(text)?.value ?: ""
    }

    private fun appLabel(pkg: String): String {
        return try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) {
            pkg
        }
    }

    private fun baseEvent(eventType: String, title: String, note: String): Map<String, String> {
        val loc = LocationHelper.bestLocation(this)
        return linkedMapOf(
            "timestamp" to LocalLogStore.now(),
            "source" to "mobile_screen",
            "event_type" to eventType,
            "title" to title,
            "note" to note,
            "lat" to (loc?.latitude?.toString() ?: ""),
            "lon" to (loc?.longitude?.toString() ?: ""),
            "accuracy_m" to (loc?.accuracy?.toString() ?: ""),
            "provider" to (loc?.provider ?: ""),
            "package_name" to "",
            "app_name" to "",
            "start_time" to "",
            "end_time" to "",
            "duration_sec" to ""
        )
    }

    private fun formatTime(millis: Long): String {
        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US)
        return sdf.format(java.util.Date(millis))
    }
}
