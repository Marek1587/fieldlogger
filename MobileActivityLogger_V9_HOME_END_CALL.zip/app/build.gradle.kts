plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "sk.strechostav.mobileactivity"
    compileSdk = 35

    defaultConfig {
        applicationId = "sk.strechostav.mobileactivity"
        minSdk = 26
        targetSdk = 28
        versionCode = 10
        versionName = "2.7-home-ends-call"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
